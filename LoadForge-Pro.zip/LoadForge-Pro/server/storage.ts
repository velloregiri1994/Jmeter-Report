import { db } from "./db";
import {
  users, scripts, scriptVersions, testSchedules, testExecutions, comments,
  type InsertUser, type InsertScript, type InsertScriptVersion,
  type InsertTestSchedule, type InsertTestExecution, type InsertComment,
  type User, type Script, type ScriptVersion, type TestSchedule, type TestExecution, type Comment,
  type ScriptWithVersions, type ScheduleWithDetails, type ExecutionWithDetails, type DashboardStats
} from "@shared/schema";
import { eq, desc, sql, and } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Scripts
  getScripts(): Promise<ScriptWithVersions[]>;
  getScript(id: number): Promise<ScriptWithVersions | undefined>;
  createScript(script: InsertScript): Promise<Script>;
  createScriptVersion(version: InsertScriptVersion): Promise<ScriptVersion>;

  // Schedules
  getSchedules(): Promise<ScheduleWithDetails[]>;
  getSchedule(id: number): Promise<ScheduleWithDetails | undefined>;
  createSchedule(schedule: InsertTestSchedule): Promise<TestSchedule>;
  updateSchedule(id: number, updates: Partial<InsertTestSchedule>): Promise<TestSchedule>;

  // Executions
  getExecutions(limit?: number, status?: string): Promise<ExecutionWithDetails[]>;
  getExecution(id: number): Promise<ExecutionWithDetails | undefined>;
  createExecution(execution: InsertTestExecution): Promise<TestExecution>;
  updateExecution(id: number, updates: Partial<InsertTestExecution>): Promise<TestExecution>;

  // Comments
  createComment(comment: InsertComment): Promise<Comment>;
  
  // Dashboard
  getDashboardStats(): Promise<DashboardStats>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  // Scripts
  async getScripts(): Promise<ScriptWithVersions[]> {
    const allScripts = await db.select().from(scripts).orderBy(desc(scripts.createdAt));
    const results: ScriptWithVersions[] = [];
    
    for (const script of allScripts) {
      const versions = await db.select().from(scriptVersions).where(eq(scriptVersions.scriptId, script.id)).orderBy(desc(scriptVersions.versionNumber));
      results.push({ ...script, versions });
    }
    
    return results;
  }

  async getScript(id: number): Promise<ScriptWithVersions | undefined> {
    const [script] = await db.select().from(scripts).where(eq(scripts.id, id));
    if (!script) return undefined;
    
    const versions = await db.select().from(scriptVersions).where(eq(scriptVersions.scriptId, id)).orderBy(desc(scriptVersions.versionNumber));
    return { ...script, versions };
  }

  async createScript(script: InsertScript): Promise<Script> {
    const [newScript] = await db.insert(scripts).values(script).returning();
    return newScript;
  }

  async createScriptVersion(version: InsertScriptVersion): Promise<ScriptVersion> {
    const [newVersion] = await db.insert(scriptVersions).values(version).returning();
    return newVersion;
  }

  // Schedules
  async getSchedules(): Promise<ScheduleWithDetails[]> {
    const results = await db.query.testSchedules.findMany({
      orderBy: [desc(testSchedules.scheduledTime)],
      with: {
        scriptVersion: {
          with: { script: true }
        },
        creator: true,
        executions: true
      }
    });
    return results;
  }

  async getSchedule(id: number): Promise<ScheduleWithDetails | undefined> {
    const result = await db.query.testSchedules.findFirst({
      where: eq(testSchedules.id, id),
      with: {
        scriptVersion: {
          with: { script: true }
        },
        creator: true,
        executions: true
      }
    });
    return result;
  }

  async createSchedule(schedule: InsertTestSchedule): Promise<TestSchedule> {
    const [newSchedule] = await db.insert(testSchedules).values(schedule).returning();
    return newSchedule;
  }

  async updateSchedule(id: number, updates: Partial<InsertTestSchedule>): Promise<TestSchedule> {
    const [updated] = await db.update(testSchedules).set(updates).where(eq(testSchedules.id, id)).returning();
    return updated;
  }

  // Executions
  async getExecutions(limit?: number, status?: string): Promise<ExecutionWithDetails[]> {
    const conditions = status ? eq(testExecutions.status, status) : undefined;
    
    const results = await db.query.testExecutions.findMany({
      where: conditions,
      limit: limit,
      orderBy: [desc(testExecutions.startTime)],
      with: {
        schedule: {
          with: {
            scriptVersion: {
              with: { script: true }
            }
          }
        },
        comments: {
          with: { user: true },
          orderBy: (comments, { desc }) => [desc(comments.createdAt)]
        }
      }
    });
    return results;
  }

  async getExecution(id: number): Promise<ExecutionWithDetails | undefined> {
    const result = await db.query.testExecutions.findFirst({
      where: eq(testExecutions.id, id),
      with: {
        schedule: {
          with: {
            scriptVersion: {
              with: { script: true }
            }
          }
        },
        comments: {
          with: { user: true },
          orderBy: (comments, { desc }) => [desc(comments.createdAt)]
        }
      }
    });
    return result;
  }

  async createExecution(execution: InsertTestExecution): Promise<TestExecution> {
    const [newExecution] = await db.insert(testExecutions).values(execution).returning();
    return newExecution;
  }

  async updateExecution(id: number, updates: Partial<InsertTestExecution>): Promise<TestExecution> {
    const [updated] = await db.update(testExecutions).set(updates).where(eq(testExecutions.id, id)).returning();
    return updated;
  }

  // Comments
  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    return newComment;
  }

  // Dashboard
  async getDashboardStats(): Promise<DashboardStats> {
    const [scriptCount] = await db.select({ count: sql<number>`count(*)` }).from(scripts);
    const [execCount] = await db.select({ count: sql<number>`count(*)` }).from(testExecutions);
    const [passCount] = await db.select({ count: sql<number>`count(*)` }).from(testExecutions)
      .where(eq(testExecutions.status, 'completed')); // Simplified 'completed' as pass for now
    
    const [activeCount] = await db.select({ count: sql<number>`count(*)` }).from(testExecutions)
      .where(eq(testExecutions.status, 'running'));

    const recentExecutions = await this.getExecutions(5);

    const totalExecutions = Number(execCount.count);
    const passed = Number(passCount.count);
    
    return {
      totalScripts: Number(scriptCount.count),
      totalExecutions,
      passRate: totalExecutions > 0 ? (passed / totalExecutions) * 100 : 0,
      activeTests: Number(activeCount.count),
      recentExecutions
    };
  }
}

export const storage = new DatabaseStorage();
