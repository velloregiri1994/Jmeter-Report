import { exec } from "child_process";
import path from "path";
import fs from "fs";
import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Scripts
  app.get(api.scripts.list.path, async (req, res) => {
    const scripts = await storage.getScripts();
    res.json(scripts);
  });

  // ... (keep existing script routes) ...

  // Executions
  app.get(api.executions.list.path, async (req, res) => {
    const status = req.query.status as string | undefined;
    const limit = req.query.limit ? Number(req.query.limit) : undefined;
    const executions = await storage.getExecutions(limit, status);
    res.json(executions);
  });

  app.get(api.executions.get.path, async (req, res) => {
    const execution = await storage.getExecution(Number(req.params.id));
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    res.json(execution);
  });

  // Generate Report
  app.post("/api/executions/:id/generate-report", async (req, res) => {
    const execution = await storage.getExecution(Number(req.params.id));
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    
    // In a real app, we'd use the actual results.csv from the execution
    // For MVP, we'll create a mock CSV if it doesn't exist
    const mockCsvPath = path.join(process.cwd(), "attached_assets", "mock_results.csv");
    if (!fs.existsSync(mockCsvPath)) {
       const csvContent = "timeStamp,elapsed,label,responseCode,responseMessage,success,allThreads\n" +
                          Date.now() + ",200,Login,200,OK,true,1\n" +
                          (Date.now()+100) + ",450,Checkout,200,OK,true,1\n";
       fs.writeFileSync(mockCsvPath, csvContent);
    }

    const reportName = `report_${execution.id}.html`;
    const reportPath = path.join(process.cwd(), "client", "public", "reports", reportName);
    const publicReportPath = `/reports/${reportName}`;
    
    fs.mkdirSync(path.join(process.cwd(), "client", "public", "reports"), { recursive: true });

    const pythonScript = path.join(process.cwd(), "scripts", "jmeter-report.py");
    const cmd = `python3 ${pythonScript} --input ${mockCsvPath} --output ${reportPath} --test-name "${execution.schedule.name}"`;

    exec(cmd, async (error, stdout, stderr) => {
      if (error) {
        console.error(`Report generation error: ${error}`);
        return res.status(500).json({ message: "Failed to generate report" });
      }
      
      await storage.updateExecution(execution.id, { reportHtmlPath: publicReportPath });
      res.json({ url: publicReportPath });
    });
  });

  // Serve static reports
  app.use("/reports", (req, res, next) => {
    const reportDir = path.join(process.cwd(), "client", "public", "reports");
    if (fs.existsSync(path.join(reportDir, req.path))) {
      next();
    } else {
      res.status(404).send("Report not found");
    }
  });

  // ... (keep existing comments, dashboard, seed routes) ...


  // Dashboard
  app.get(api.dashboard.stats.path, async (req, res) => {
    const stats = await storage.getDashboardStats();
    res.json(stats);
  });
  
  // Seed Data Endpoint (Hidden)
  app.post('/api/seed', async (req, res) => {
    await seedDatabase();
    res.json({ message: "Database seeded" });
  });

  // Auto-seed on startup
  seedDatabase().catch(console.error);

  return httpServer;
}

async function seedDatabase() {
  const existingUsers = await storage.getUser(1);
  if (existingUsers) return; // Already seeded

  // Users
  const admin = await storage.createUser({ username: "admin", password: "password123", role: "admin" });
  const engineer = await storage.createUser({ username: "engineer1", password: "password123", role: "engineer" });

  // Scripts
  const script1 = await storage.createScript({ name: "Login & Checkout Flow", description: "Critical user path for e-commerce", toolType: "JMeter" });
  const script2 = await storage.createScript({ name: "API Stress Test", description: "Backend search API load test", toolType: "K6" });

  // Versions
  const v1 = await storage.createScriptVersion({ scriptId: script1.id, versionNumber: 1, filePath: "/scripts/login_v1.jmx", changesDescription: "Initial commit", uploadedBy: engineer.id });
  const v2 = await storage.createScriptVersion({ scriptId: script1.id, versionNumber: 2, filePath: "/scripts/login_v2.jmx", changesDescription: "Fixed session timeout issue", uploadedBy: engineer.id });
  const sv1 = await storage.createScriptVersion({ scriptId: script2.id, versionNumber: 1, filePath: "/scripts/api_v1.js", changesDescription: "Baseline search test", uploadedBy: engineer.id });

  // Schedules
  const schedule1 = await storage.createSchedule({
    name: "Nightly Regression",
    scriptVersionId: v2.id,
    scheduledTime: new Date(Date.now() - 86400000), // Yesterday
    status: "completed",
    configuration: { environment: "Staging" }, // Simplified config
    createdBy: admin.id
  });

  const schedule2 = await storage.createSchedule({
    name: "Upcoming Load Test",
    scriptVersionId: sv1.id,
    scheduledTime: new Date(Date.now() + 86400000), // Tomorrow
    status: "pending",
    configuration: { environment: "Pre-Prod" }, // Simplified config
    createdBy: admin.id
  });

  const schedule3 = await storage.createSchedule({
    name: "Live Flash Sale Simulation",
    scriptVersionId: v2.id,
    scheduledTime: new Date(),
    status: "running",
    configuration: { environment: "Production" }, // Simplified config
    createdBy: admin.id
  });

  // Executions
  const exec1 = await storage.createExecution({
    scheduleId: schedule1.id,
    startTime: new Date(Date.now() - 90000000),
    endTime: new Date(Date.now() - 86400000),
    status: "completed",
    resultSummary: { totalRequests: 15000, failedRequests: 12, avgResponseTime: 250, throughput: 45.5 },
    artifactsPath: "/results/exec_1.zip"
  });
  
  const exec3 = await storage.createExecution({
    scheduleId: schedule3.id,
    startTime: new Date(Date.now() - 600000), // Started 10 mins ago
    status: "running",
    resultSummary: { totalRequests: 2000, failedRequests: 0, avgResponseTime: 180, throughput: 50 }, // Real-time stats
    artifactsPath: null
  });

  // Comments
  await storage.createComment({ executionId: exec1.id, userId: admin.id, content: "Looks good, response times are stable.", type: "sign-off" });
  await storage.createComment({ executionId: exec1.id, userId: engineer.id, content: "Agreed. Ready for release.", type: "comment" });
}
