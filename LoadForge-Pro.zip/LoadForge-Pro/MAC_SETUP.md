# Local Setup Guide for MacBook

This guide provides instructions on how to set up and run the PerfEngine application on your MacBook.

## Prerequisites

### 1. Node.js & npm
The application is built with Node.js. It's recommended to use Node.js v20 or higher.
- **Check version**: `node -v`
- **Installation**: Use [Homebrew](https://brew.sh/): `brew install node`

### 2. PostgreSQL
The application uses a PostgreSQL database.
- **Installation**: `brew install postgresql@15`
- **Start service**: `brew services start postgresql@15`
- **Create Database**: `createdb perfengine`

### 3. Python 3.11+
The reporting module requires Python with specific scientific libraries.
- **Installation**: `brew install python@3.11`
- **Verify**: `python3 --version`

## Application Setup

1. **Clone the project files** to your local directory.

2. **Install Node.js Dependencies**
   Open your terminal in the project root and run:
   ```bash
   npm install
   ```

3. **Install Python Dependencies**
   The report generator requires several libraries. Run:
   ```bash
   pip3 install numpy scipy openpyxl pyyaml
   ```

4. **Configure Environment Variables**
   Create a file named `.env` in the root directory:
   ```env
   DATABASE_URL=postgresql://localhost:5432/perfengine
   # If you have a username/password:
   # DATABASE_URL=postgresql://user:password@localhost:5432/perfengine
   ```

5. **Initialize Database Schema**
   Sync the database tables using Drizzle:
   ```bash
   npm run db:push
   ```

6. **Start the Application**
   Run the development server (starts both backend and frontend):
   ```bash
   npm run dev
   ```

## Usage on Mac

- **Access the App**: Open your browser and navigate to `http://localhost:5000`.
- **Reports**: When you click "Generate HTML Report", the app will execute the Python script locally. Ensure your Python path is correctly set in your terminal.
- **Scripts**: You can upload `.jmx` or other script files which will be stored in the configured directory.

## Troubleshooting

- **Python errors**: If the app can't find `numpy`, ensure you installed it with the same Python version used by the system (`python3 -m pip install numpy`).
- **Database connection**: Ensure PostgreSQL is running and the `DATABASE_URL` is correct.
- **Permission issues**: You may need to grant execution permissions to the script: `chmod +x scripts/jmeter-report.py`.
