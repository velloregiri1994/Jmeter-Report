import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { LayoutShell } from "@/components/layout-shell";

import Dashboard from "@/pages/dashboard";
import ScriptRepository from "@/pages/scripts/index";
import ScriptDetail from "@/pages/scripts/detail";
import ExecutionsPage from "@/pages/executions/index";
import ExecutionDetail from "@/pages/executions/detail";
import SchedulePage from "@/pages/schedule/index";

function Router() {
  return (
    <LayoutShell>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/scripts" component={ScriptRepository} />
        <Route path="/scripts/:id" component={ScriptDetail} />
        <Route path="/schedule" component={SchedulePage} />
        <Route path="/executions" component={ExecutionsPage} />
        <Route path="/executions/:id" component={ExecutionDetail} />
        <Route component={NotFound} />
      </Switch>
    </LayoutShell>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
