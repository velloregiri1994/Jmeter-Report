import { useScript, useCreateScriptVersion } from "@/hooks/use-scripts";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Upload, FileCode, Clock, User, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";

export default function ScriptDetail() {
  const [, params] = useRoute("/scripts/:id");
  const scriptId = parseInt(params?.id || "0");
  const { data: script, isLoading } = useScript(scriptId);

  if (isLoading) return <DetailSkeleton />;
  if (!script) return <div className="p-8">Script not found</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/scripts">
          <Button variant="ghost" size="icon" className="rounded-full">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-display font-bold">{script.name}</h1>
          <p className="text-muted-foreground flex items-center gap-2 mt-1">
            <span className="bg-secondary px-2 py-0.5 rounded text-xs font-semibold">{script.toolType}</span>
            <span className="text-sm">• {script.description}</span>
          </p>
        </div>
        <div className="ml-auto">
           <UploadVersionDialog scriptId={scriptId} nextVersion={script.versions.length + 1} />
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Version History</CardTitle>
          </CardHeader>
          <CardContent>
             <div className="space-y-6 relative before:absolute before:inset-0 before:ml-5 before:w-0.5 before:-translate-x-px before:bg-gradient-to-b before:from-border before:via-border before:to-transparent">
                {script.versions.length === 0 ? (
                  <div className="pl-10 text-muted-foreground">No versions uploaded yet.</div>
                ) : (
                  [...script.versions].sort((a,b) => b.versionNumber - a.versionNumber).map((version) => (
                    <div key={version.id} className="relative pl-10 group">
                       <div className="absolute left-0 top-1 flex h-10 w-10 items-center justify-center rounded-full bg-background border border-border group-hover:border-primary group-hover:text-primary transition-colors ring-4 ring-background">
                          <FileCode className="h-5 w-5" />
                       </div>
                       <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 p-4 rounded-xl bg-muted/30 border border-border/50 hover:bg-card hover:shadow-md transition-all">
                          <div>
                            <div className="flex items-center gap-2">
                               <h3 className="font-semibold text-lg">v{version.versionNumber}</h3>
                               <span className="text-xs text-muted-foreground bg-background px-2 py-0.5 rounded border">
                                  {version.filePath.split('/').pop()}
                               </span>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">{version.changesDescription}</p>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground shrink-0">
                             <div className="flex items-center gap-1">
                                <User className="w-3 h-3" />
                                <span>User {version.uploadedBy}</span>
                             </div>
                             <div className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                <span>{version.createdAt ? format(new Date(version.createdAt), "PP p") : '-'}</span>
                             </div>
                          </div>
                       </div>
                    </div>
                  ))
                )}
             </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function UploadVersionDialog({ scriptId, nextVersion }: { scriptId: number, nextVersion: number }) {
  const { mutate, isPending } = useCreateScriptVersion();
  const [open, setOpen] = useState(false);
  const [description, setDescription] = useState("");
  const [file, setFile] = useState<File | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    // Simulate file upload by just using the name. Real app would use FormData.
    mutate({
      scriptId,
      versionNumber: nextVersion,
      changesDescription: description,
      // In a real app, this path would come from the file upload response
      filePath: `/uploads/${file.name}` 
    }, {
      onSuccess: () => {
        setOpen(false);
        setDescription("");
        setFile(null);
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
           <Upload className="w-4 h-4 mr-2" /> Upload New Version
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Upload Script Version v{nextVersion}</DialogTitle>
          <DialogDescription>Upload the updated script file and describe changes.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid w-full max-w-sm items-center gap-1.5">
            <Label htmlFor="script-file">Script File</Label>
            <Input 
                id="script-file" 
                type="file" 
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                required
            />
          </div>
          <div className="grid w-full gap-1.5">
             <Label htmlFor="changes">Changes Description</Label>
             <Textarea 
                id="changes" 
                placeholder="What changed in this version?" 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
             />
          </div>
          <DialogFooter>
             <Button type="submit" disabled={isPending || !file}>
                {isPending ? "Uploading..." : "Upload Version"}
             </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function DetailSkeleton() {
  return (
    <div className="space-y-6">
       <Skeleton className="h-12 w-1/3" />
       <Skeleton className="h-64 w-full rounded-xl" />
    </div>
  );
}
