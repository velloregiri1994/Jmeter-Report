import { useSchedules, useCreateSchedule } from "@/hooks/use-schedules";
import { useScripts } from "@/hooks/use-scripts";
import { format } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { CalendarDays, Plus, Search } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { StatusBadge } from "@/components/status-badge";

// Simplified schema for the UI form - we transform this to the API schema on submit
const scheduleFormSchema = z.object({
    name: z.string().min(1, "Name is required"),
    scriptId: z.string().min(1, "Script is required"),
    scriptVersionId: z.string().min(1, "Version is required"),
    date: z.string().min(1, "Date is required"),
    time: z.string().min(1, "Time is required"),
    environment: z.string().min(1)
});

export default function SchedulePage() {
  const { data: schedules, isLoading } = useSchedules();
  
  // Group schedules by date
  const groupedSchedules = schedules?.reduce((acc, schedule) => {
    const dateKey = format(new Date(schedule.scheduledTime), 'yyyy-MM-dd');
    if (!acc[dateKey]) acc[dateKey] = [];
    acc[dateKey].push(schedule);
    return acc;
  }, {} as Record<string, typeof schedules>);

  const sortedDates = Object.keys(groupedSchedules || {}).sort();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
         <h1 className="text-3xl font-display font-bold">Test Schedule</h1>
         <CreateScheduleDialog />
      </div>

      <div className="grid gap-8">
        {isLoading ? (
           <div>Loading schedule...</div>
        ) : sortedDates.length === 0 ? (
           <div className="text-center py-20 bg-muted/20 rounded-xl border border-dashed">
              <CalendarDays className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No tests scheduled</h3>
              <p className="text-muted-foreground mt-1">Schedule your first performance test to get started.</p>
           </div>
        ) : (
           sortedDates.map(dateKey => (
              <div key={dateKey}>
                 <h3 className="text-sm font-semibold text-muted-foreground mb-4 sticky top-0 bg-background/95 backdrop-blur py-2 z-10">
                    {format(new Date(dateKey), 'EEEE, MMMM d, yyyy')}
                 </h3>
                 <div className="grid gap-4">
                    {groupedSchedules![dateKey].map(schedule => (
                       <Card key={schedule.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-0 flex flex-col sm:flex-row">
                             <div className="p-4 sm:w-32 bg-muted/20 border-r flex flex-col items-center justify-center text-center">
                                <span className="text-lg font-bold">{format(new Date(schedule.scheduledTime), 'HH:mm')}</span>
                                <StatusBadge status={schedule.status} className="mt-2" />
                             </div>
                             <div className="p-4 flex-1 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                                <div>
                                   <h4 className="font-semibold text-lg">{schedule.name}</h4>
                                   <div className="text-sm text-muted-foreground mt-1">
                                      {schedule.scriptVersion.script.name} <span className="bg-muted px-1.5 rounded text-xs ml-1">v{schedule.scriptVersion.versionNumber}</span>
                                   </div>
                                </div>
                                <div className="flex gap-6 text-sm">
                                   <div>
                                      <div className="text-muted-foreground text-xs uppercase tracking-wide">Env</div>
                                      <div className="font-medium">{(schedule.configuration as any).environment}</div>
                                   </div>
                                </div>
                             </div>
                          </CardContent>
                       </Card>
                    ))}
                 </div>
              </div>
           ))
        )}
      </div>
    </div>
  );
}

function CreateScheduleDialog() {
  const [open, setOpen] = useState(false);
  const { mutate, isPending } = useCreateSchedule();
  const { data: scripts } = useScripts();

  const form = useForm<z.infer<typeof scheduleFormSchema>>({
    resolver: zodResolver(scheduleFormSchema),
    defaultValues: {
      name: "",
      environment: "Staging",
      date: format(new Date(), 'yyyy-MM-dd'),
      time: "12:00"
    }
  });

  const selectedScriptId = form.watch("scriptId");
  const selectedScript = scripts?.find(s => s.id.toString() === selectedScriptId);

  const onSubmit = (data: z.infer<typeof scheduleFormSchema>) => {
    const scheduledTime = new Date(`${data.date}T${data.time}:00`);
    
    mutate({
        name: data.name,
        scriptVersionId: parseInt(data.scriptVersionId),
        scheduledTime: scheduledTime.toISOString(),
        status: "pending",
        configuration: {
            environment: data.environment
        }
    }, {
        onSuccess: () => {
            setOpen(false);
            form.reset();
        }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="shadow-lg shadow-primary/25">
           <Plus className="w-4 h-4 mr-2" /> Schedule Test
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Schedule Performance Test</DialogTitle>
        </DialogHeader>
        <Form {...form}>
           <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
              <FormField
                 control={form.control}
                 name="name"
                 render={({ field }) => (
                    <FormItem>
                       <FormLabel>Test Name</FormLabel>
                       <FormControl><Input placeholder="e.g. Black Friday Load Test" {...field} /></FormControl>
                       <FormMessage />
                    </FormItem>
                 )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                 <FormField
                    control={form.control}
                    name="scriptId"
                    render={({ field }) => (
                       <FormItem>
                          <FormLabel>Script</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                             <FormControl><SelectTrigger><SelectValue placeholder="Select script" /></SelectTrigger></FormControl>
                             <SelectContent>
                                {scripts?.map(s => <SelectItem key={s.id} value={s.id.toString()}>{s.name}</SelectItem>)}
                             </SelectContent>
                          </Select>
                          <FormMessage />
                       </FormItem>
                    )}
                 />
                 <FormField
                    control={form.control}
                    name="scriptVersionId"
                    render={({ field }) => (
                       <FormItem>
                          <FormLabel>Version</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value} disabled={!selectedScriptId}>
                             <FormControl><SelectTrigger><SelectValue placeholder="Select version" /></SelectTrigger></FormControl>
                             <SelectContent>
                                {selectedScript?.versions.map(v => (
                                   <SelectItem key={v.id} value={v.id.toString()}>v{v.versionNumber} ({v.createdAt ? format(new Date(v.createdAt), 'MM/dd') : '-'})</SelectItem>
                                ))}
                             </SelectContent>
                          </Select>
                          <FormMessage />
                       </FormItem>
                    )}
                 />
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                       <FormItem>
                          <FormLabel>Date</FormLabel>
                          <FormControl><Input type="date" {...field} /></FormControl>
                          <FormMessage />
                       </FormItem>
                    )}
                 />
                 <FormField
                    control={form.control}
                    name="time"
                    render={({ field }) => (
                       <FormItem>
                          <FormLabel>Time</FormLabel>
                          <FormControl><Input type="time" {...field} /></FormControl>
                          <FormMessage />
                       </FormItem>
                    )}
                 />
              </div>

              <div className="space-y-4 border rounded-lg p-4 bg-muted/10">
                 <h4 className="font-semibold text-sm">Environment</h4>
                 <FormField
                    control={form.control}
                    name="environment"
                    render={({ field }) => (
                       <FormItem>
                          <FormLabel>Target Environment</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                             <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                             <SelectContent>
                                <SelectItem value="Dev">Dev</SelectItem>
                                <SelectItem value="Staging">Staging</SelectItem>
                                <SelectItem value="Prod">Prod</SelectItem>
                             </SelectContent>
                          </Select>
                          <FormMessage />
                       </FormItem>
                    )}
                 />
              </div>

              <DialogFooter>
                 <Button type="submit" disabled={isPending}>{isPending ? "Scheduling..." : "Create Schedule"}</Button>
              </DialogFooter>
           </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
