import { useDashboardStats } from "@/hooks/use-executions";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Activity, CheckCircle, FileCode, Play, XCircle } from "lucide-react";
import { StatusBadge } from "@/components/status-badge";
import { Link } from "wouter";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

export default function Dashboard() {
  const { data: stats, isLoading } = useDashboardStats();

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  if (!stats) return null;

  const pieData = [
    { name: 'Passed', value: Math.round(stats.totalExecutions * (stats.passRate / 100)) },
    { name: 'Failed', value: stats.totalExecutions - Math.round(stats.totalExecutions * (stats.passRate / 100)) },
  ];
  
  const COLORS = ['#22c55e', '#ef4444'];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-foreground">Overview</h1>
        <p className="text-muted-foreground mt-2">Welcome back. Here's what's happening with your tests.</p>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard 
          title="Active Tests" 
          value={stats.activeTests} 
          icon={Activity} 
          color="text-blue-500" 
          description="Currently running"
        />
        <MetricCard 
          title="Total Scripts" 
          value={stats.totalScripts} 
          icon={FileCode} 
          color="text-indigo-500" 
          description="In repository"
        />
        <MetricCard 
          title="Pass Rate" 
          value={`${stats.passRate}%`} 
          icon={CheckCircle} 
          color="text-green-500" 
          description="Last 30 days"
        />
        <MetricCard 
          title="Total Executions" 
          value={stats.totalExecutions} 
          icon={Play} 
          color="text-orange-500" 
          description="All time"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <Card className="lg:col-span-2 border shadow-sm">
            <CardHeader>
                <CardTitle>Recent Executions</CardTitle>
                <CardDescription>Latest test runs across all projects</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {stats.recentExecutions.length === 0 ? (
                        <div className="text-center py-10 text-muted-foreground">No recent executions found.</div>
                    ) : (
                        stats.recentExecutions.map((exec) => (
                            <Link key={exec.id} href={`/executions/${exec.id}`}>
                                <div className="flex items-center justify-between p-4 rounded-xl border border-border/50 hover:bg-muted/50 hover:border-border transition-all cursor-pointer group">
                                    <div className="flex items-center gap-4">
                                        <div className={`p-2 rounded-lg ${exec.status === 'failed' ? 'bg-red-100 text-red-600 dark:bg-red-900/20' : 'bg-blue-100 text-blue-600 dark:bg-blue-900/20'}`}>
                                            {exec.status === 'failed' ? <XCircle size={20} /> : <CheckCircle size={20} />}
                                        </div>
                                        <div>
                                            <h4 className="font-semibold text-sm group-hover:text-primary transition-colors">
                                                {exec.schedule.name}
                                            </h4>
                                            <p className="text-xs text-muted-foreground mt-0.5">
                                                {exec.schedule.scriptVersion.script.name} • v{exec.schedule.scriptVersion.versionNumber}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex flex-col items-end gap-2">
                                        <StatusBadge status={exec.status} />
                                        <span className="text-xs text-muted-foreground font-mono">
                                            {exec.startTime ? format(new Date(exec.startTime), "MMM d, HH:mm") : "-"}
                                        </span>
                                    </div>
                                </div>
                            </Link>
                        ))
                    )}
                </div>
            </CardContent>
        </Card>

        {/* Success Rate Chart */}
        <Card className="border shadow-sm">
            <CardHeader>
                <CardTitle>Success Rate</CardTitle>
                <CardDescription>Passed vs Failed executions</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px] flex items-center justify-center">
                {stats.totalExecutions === 0 ? (
                    <div className="text-muted-foreground text-sm">No data available</div>
                ) : (
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={pieData}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={80}
                                fill="#8884d8"
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {pieData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip />
                        </PieChart>
                    </ResponsiveContainer>
                )}
                {stats.totalExecutions > 0 && (
                    <div className="absolute flex flex-col items-center justify-center pointer-events-none">
                        <span className="text-3xl font-bold">{stats.passRate}%</span>
                        <span className="text-xs text-muted-foreground uppercase tracking-wide">Pass Rate</span>
                    </div>
                )}
            </CardContent>
        </Card>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, color, description }: any) {
  return (
    <Card className="border shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <div className="flex items-baseline mt-1">
              <h3 className="text-3xl font-bold tracking-tight">{value}</h3>
            </div>
            {description && <p className="text-xs text-muted-foreground mt-1">{description}</p>}
          </div>
          <div className={`p-3 rounded-xl bg-opacity-10 ${color.replace('text-', 'bg-')}`}>
            <Icon className={`h-6 w-6 ${color}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-4 w-96" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-32 w-full rounded-xl" />
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Skeleton className="lg:col-span-2 h-96 rounded-xl" />
        <Skeleton className="h-96 rounded-xl" />
      </div>
    </div>
  );
}
