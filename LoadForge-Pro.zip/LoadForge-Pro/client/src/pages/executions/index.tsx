import { useExecutions } from "@/hooks/use-executions";
import { StatusBadge } from "@/components/status-badge";
import { Link } from "wouter";
import { format } from "date-fns";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ArrowRight, Activity, Clock, RotateCw } from "lucide-react";

export default function ExecutionsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
         <h1 className="text-3xl font-display font-bold">Executions</h1>
         <Link href="/schedule">
            <Button variant="outline">Schedule New Test</Button>
         </Link>
      </div>

      <Tabs defaultValue="live" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="live">Live / Running</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>
        <TabsContent value="live" className="mt-6">
          <ExecutionsTable status="running" />
        </TabsContent>
        <TabsContent value="history" className="mt-6">
          <ExecutionsTable />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ExecutionsTable({ status }: { status?: 'running' }) {
  const { data: executions, isLoading, refetch } = useExecutions(status ? { status } : { limit: 50 });

  if (isLoading) return <div className="p-10 text-center">Loading executions...</div>;

  if (executions?.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-12 border border-dashed rounded-xl bg-muted/20">
         <Activity className="h-10 w-10 text-muted-foreground mb-4" />
         <h3 className="text-lg font-medium">No executions found</h3>
         <p className="text-muted-foreground text-sm mt-1">
            {status === 'running' ? "There are no tests currently running." : "No execution history available."}
         </p>
      </div>
    );
  }

  return (
    <div className="rounded-xl border shadow-sm overflow-hidden bg-card">
       {status === 'running' && (
          <div className="p-2 bg-blue-50/50 dark:bg-blue-900/10 border-b flex justify-end">
             <Button variant="ghost" size="sm" onClick={() => refetch()} className="text-xs h-7">
                <RotateCw className="w-3 h-3 mr-1" /> Refresh
             </Button>
          </div>
       )}
      <Table>
        <TableHeader className="bg-muted/30">
          <TableRow>
            <TableHead>Test Name</TableHead>
            <TableHead>Script</TableHead>
            <TableHead>Start Time</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Duration</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {executions?.map((exec) => (
            <TableRow key={exec.id} className="group hover:bg-muted/30">
              <TableCell className="font-medium">
                {exec.schedule.name}
              </TableCell>
              <TableCell>
                <div className="text-sm">
                   {exec.schedule.scriptVersion.script.name}
                   <span className="text-xs text-muted-foreground ml-2">v{exec.schedule.scriptVersion.versionNumber}</span>
                </div>
              </TableCell>
              <TableCell>
                 {exec.startTime ? format(new Date(exec.startTime), "MMM d, HH:mm") : "-"}
              </TableCell>
              <TableCell>
                <StatusBadge status={exec.status} />
              </TableCell>
              <TableCell className="text-muted-foreground font-mono text-xs">
                 {exec.status === 'running' ? (
                    <span className="flex items-center text-blue-600 animate-pulse">
                       <Clock className="w-3 h-3 mr-1" /> Running...
                    </span>
                 ) : exec.endTime && exec.startTime ? (
                    `${Math.round((new Date(exec.endTime).getTime() - new Date(exec.startTime).getTime()) / 1000 / 60)} min`
                 ) : "-"}
              </TableCell>
              <TableCell className="text-right">
                <Button variant="ghost" size="sm" asChild className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <Link href={`/executions/${exec.id}`}>
                    Details <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
