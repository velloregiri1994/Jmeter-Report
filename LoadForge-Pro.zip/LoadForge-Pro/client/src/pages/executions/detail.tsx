import { useExecution, useAddComment } from "@/hooks/use-executions";
import { useRoute } from "wouter";
import { StatusBadge } from "@/components/status-badge";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, CheckCircle, Download, FileText, MessageSquare, ShieldCheck, User, BarChart2 } from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export default function ExecutionDetail() {
  const [, params] = useRoute("/executions/:id");
  const id = parseInt(params?.id || "0");
  const { data: execution, isLoading } = useExecution(id);
  const { mutate: addComment, isPending } = useAddComment();
  const [commentText, setCommentText] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const generateReportMutation = useMutation({
    mutationFn: async () => {
      const url = buildUrl(api.executions.generateReport.path, { id });
      const res = await fetch(url, { method: "POST" });
      if (!res.ok) throw new Error("Failed to generate report");
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Success", description: "Report generated successfully" });
      queryClient.invalidateQueries({ queryKey: [api.executions.get.path, id] });
      window.open(data.url, '_blank');
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  if (isLoading) return <DetailSkeleton />;
  if (!execution) return <div>Execution not found</div>;

  const handleCommentSubmit = (type: 'comment' | 'sign-off') => {
    if (!commentText.trim()) return;
    addComment({
        executionId: id,
        content: commentText,
        type: type
    }, {
        onSuccess: () => setCommentText("")
    });
  };

  const config = execution.schedule.configuration as any;
  const results = execution.resultSummary as any;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-4 mb-6">
        <Link href="/executions">
          <Button variant="ghost" size="icon" className="rounded-full">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <div>
           <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold font-display">{execution.schedule.name}</h1>
              <StatusBadge status={execution.status} />
           </div>
           <p className="text-sm text-muted-foreground mt-1">
              Executed on {execution.startTime ? format(new Date(execution.startTime), "PPpp") : "Pending"}
           </p>
        </div>
        <div className="ml-auto flex gap-2">
            <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" /> Logs
            </Button>
            {execution.reportHtmlPath ? (
              <Button variant="outline" size="sm" onClick={() => window.open(execution.reportHtmlPath, '_blank')}>
                <BarChart2 className="w-4 h-4 mr-2" /> View HTML Report
              </Button>
            ) : (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => generateReportMutation.mutate()}
                disabled={generateReportMutation.isPending}
              >
                <FileText className="w-4 h-4 mr-2" /> {generateReportMutation.isPending ? "Generating..." : "Generate HTML Report"}
              </Button>
            )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         {/* Main Stats Column */}
         <div className="md:col-span-2 space-y-6">
            <Card>
               <CardHeader>
                  <CardTitle>Results Summary</CardTitle>
               </CardHeader>
               <CardContent>
                  {!results ? (
                     <div className="p-8 text-center text-muted-foreground bg-muted/20 rounded-lg">
                        Results pending or not available.
                     </div>
                  ) : (
                     <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <ResultBox label="Total Requests" value={results.totalRequests.toLocaleString()} />
                        <ResultBox label="Failed Requests" value={results.failedRequests.toLocaleString()} color="text-red-500" />
                        <ResultBox label="Avg Response" value={`${results.avgResponseTime}ms`} />
                        <ResultBox label="Throughput" value={`${results.throughput}/sec`} />
                     </div>
                  )}
               </CardContent>
            </Card>

            <Card>
               <CardHeader>
                  <CardTitle>Configuration</CardTitle>
               </CardHeader>
               <CardContent className="grid grid-cols-2 gap-x-8 gap-y-4 text-sm">
                  <div className="flex justify-between border-b pb-2">
                     <span className="text-muted-foreground">Script</span>
                     <span className="font-medium">{execution.schedule.scriptVersion.script.name}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                     <span className="text-muted-foreground">Version</span>
                     <span className="font-medium">v{execution.schedule.scriptVersion.versionNumber}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                     <span className="text-muted-foreground">Virtual Users</span>
                     <span className="font-medium">{config?.vusers || '-'}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                     <span className="text-muted-foreground">Duration</span>
                     <span className="font-medium">{config?.duration ? `${config.duration}s` : '-'}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                     <span className="text-muted-foreground">Ramp Up</span>
                     <span className="font-medium">{config?.rampUp ? `${config.rampUp}s` : '-'}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                     <span className="text-muted-foreground">Environment</span>
                     <span className="font-medium">{config?.environment || 'Default'}</span>
                  </div>
               </CardContent>
            </Card>
         </div>

         {/* Comments / Collaboration Sidebar */}
         <div className="md:col-span-1 space-y-6">
            <Card className="h-full flex flex-col">
               <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                     <MessageSquare className="w-5 h-5" /> Team Activity
                  </CardTitle>
               </CardHeader>
               <CardContent className="flex-1 flex flex-col">
                  <div className="flex-1 overflow-y-auto max-h-[400px] space-y-4 pr-2 mb-4 custom-scrollbar">
                     {execution.comments.length === 0 ? (
                        <div className="text-sm text-muted-foreground text-center py-4">No comments yet.</div>
                     ) : (
                        execution.comments.map((comment) => (
                           <div key={comment.id} className={`p-3 rounded-lg text-sm border ${comment.type === 'sign-off' ? 'bg-green-50 border-green-200 dark:bg-green-900/10 dark:border-green-800' : 'bg-muted/40 border-border'}`}>
                              <div className="flex items-center justify-between mb-1">
                                 <span className="font-semibold flex items-center gap-1">
                                    <User className="w-3 h-3" /> User {comment.userId}
                                 </span>
                                 <span className="text-xs text-muted-foreground">{format(new Date(comment.createdAt!), "MMM d, p")}</span>
                              </div>
                              <p>{comment.content}</p>
                              {comment.type === 'sign-off' && (
                                 <div className="mt-2 flex items-center gap-1 text-xs font-bold text-green-700 dark:text-green-500 uppercase tracking-wider">
                                    <ShieldCheck className="w-3 h-3" /> Signed Off
                                 </div>
                              )}
                           </div>
                        ))
                     )}
                  </div>
                  
                  <div className="mt-auto space-y-3 pt-4 border-t">
                     <Textarea 
                        placeholder="Add a comment or observation..." 
                        className="resize-none h-20 text-sm"
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                     />
                     <div className="flex gap-2">
                        <Button size="sm" className="flex-1" onClick={() => handleCommentSubmit('comment')} disabled={isPending || !commentText}>
                           Comment
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1 text-green-600 border-green-200 hover:bg-green-50" onClick={() => handleCommentSubmit('sign-off')} disabled={isPending || !commentText}>
                           <ShieldCheck className="w-4 h-4 mr-1" /> Sign-off
                        </Button>
                     </div>
                  </div>
               </CardContent>
            </Card>
         </div>
      </div>
    </div>
  );
}

function ResultBox({ label, value, color }: { label: string, value: string, color?: string }) {
   return (
      <div className="bg-muted/30 p-4 rounded-xl border text-center">
         <div className="text-xs text-muted-foreground uppercase tracking-wide mb-1">{label}</div>
         <div className={`text-xl font-bold ${color || 'text-foreground'}`}>{value}</div>
      </div>
   );
}

function DetailSkeleton() {
   return (
      <div className="space-y-6">
         <Skeleton className="h-12 w-full" />
         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Skeleton className="col-span-2 h-64" />
            <Skeleton className="col-span-1 h-64" />
         </div>
      </div>
   )
}
