import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertComment } from "@shared/routes";

export function useExecutions(params?: { status?: 'running' | 'completed' | 'failed'; limit?: number }) {
  // Create a unique key based on params
  const queryKey = [api.executions.list.path, JSON.stringify(params)];
  
  return useQuery({
    queryKey,
    queryFn: async () => {
      let url = api.executions.list.path;
      if (params) {
        const queryParams = new URLSearchParams();
        if (params.status) queryParams.set("status", params.status);
        if (params.limit) queryParams.set("limit", String(params.limit));
        url += `?${queryParams.toString()}`;
      }
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch executions");
      return api.executions.list.responses[200].parse(await res.json());
    },
    refetchInterval: (query) => {
        // Poll active executions more frequently
        return params?.status === 'running' ? 5000 : false; 
    }
  });
}

export function useExecution(id: number) {
  return useQuery({
    queryKey: [api.executions.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.executions.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch execution details");
      return api.executions.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useAddComment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ executionId, ...data }: Omit<InsertComment, "userId"> & { executionId: number }) => {
      const url = buildUrl(api.comments.create.path, { executionId });
      const res = await fetch(url, {
        method: api.comments.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to add comment");
      return api.comments.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.executions.get.path, variables.executionId] });
    },
  });
}

export function useDashboardStats() {
    return useQuery({
        queryKey: [api.dashboard.stats.path],
        queryFn: async () => {
            const res = await fetch(api.dashboard.stats.path, { credentials: "include" });
            if (!res.ok) throw new Error("Failed to fetch stats");
            return api.dashboard.stats.responses[200].parse(await res.json());
        }
    });
}
