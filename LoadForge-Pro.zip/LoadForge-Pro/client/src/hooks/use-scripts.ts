import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertScript, type InsertScriptVersion } from "@shared/routes";

export function useScripts() {
  return useQuery({
    queryKey: [api.scripts.list.path],
    queryFn: async () => {
      const res = await fetch(api.scripts.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch scripts");
      return api.scripts.list.responses[200].parse(await res.json());
    },
  });
}

export function useScript(id: number) {
  return useQuery({
    queryKey: [api.scripts.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.scripts.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch script");
      return api.scripts.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateScript() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertScript) => {
      const res = await fetch(api.scripts.create.path, {
        method: api.scripts.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create script");
      return api.scripts.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.scripts.list.path] }),
  });
}

export function useCreateScriptVersion() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ scriptId, ...data }: InsertScriptVersion & { scriptId: number }) => {
      // NOTE: In a real app, we would handle file uploads here via FormData.
      // For this simplified version, we're sending metadata as JSON.
      const url = buildUrl(api.scriptVersions.create.path, { scriptId });
      const res = await fetch(url, {
        method: api.scriptVersions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to upload version");
      return api.scriptVersions.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.scripts.get.path, variables.scriptId] });
      queryClient.invalidateQueries({ queryKey: [api.scripts.list.path] });
    },
  });
}
