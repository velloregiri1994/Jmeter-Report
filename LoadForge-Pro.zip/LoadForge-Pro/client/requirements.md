## Packages
recharts | For visualizing test execution trends and pass/fail rates
date-fns | For formatting dates and times in schedules and logs
framer-motion | For smooth page transitions and micro-interactions

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'Inter'", "sans-serif"],
  display: ["'Outfit'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}
