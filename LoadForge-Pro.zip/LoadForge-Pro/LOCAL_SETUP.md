# PerfEngine - Performance Engineering Platform

Internal web-based application for managing test scripts, scheduling performance tests, monitoring execution, and team collaboration.

## Prerequisites

- Node.js (v20 or higher)
- PostgreSQL
- Python 3.11+ with `numpy`, `scipy`, `openpyxl`, `pyyaml`

## Setup

1. **Clone the repository**
2. **Install Node.js dependencies**
   ```bash
   npm install
   ```
3. **Install Python dependencies**
   ```bash
   pip install numpy scipy openpyxl pyyaml
   ```
4. **Environment Variables**
   Create a `.env` file in the root directory:
   ```env
   DATABASE_URL=postgresql://user:password@localhost:5432/perfengine
   ```
5. **Database Setup**
   ```bash
   npm run db:push
   ```
6. **Start Application**
   ```bash
   npm run dev
   ```

## Development

- Frontend: Vite (React)
- Backend: Express
- Database: Drizzle ORM
- Reporting: Python scripts
