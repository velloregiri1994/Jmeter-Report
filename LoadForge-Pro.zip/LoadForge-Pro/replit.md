# PerfEngine - Performance Engineering Platform

## Overview

PerfEngine is an internal web-based application for performance engineering teams. It provides capabilities for managing test scripts, scheduling performance tests, monitoring test execution, and team collaboration. The platform supports multiple performance testing tools (JMeter, LoadRunner, K6) and includes automated report generation using Python scripts.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, built using Vite
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom theme configuration
- **Charts**: Recharts for data visualization

The frontend follows a standard React application structure with pages in `client/src/pages/`, reusable components in `client/src/components/`, and custom hooks in `client/src/hooks/`. Path aliases are configured (`@/` for client source, `@shared/` for shared code).

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with tsx for development execution
- **API Pattern**: RESTful API with typed route definitions in `shared/routes.ts`
- **Build**: esbuild for production bundling with selective dependency bundling

The backend serves as both an API server and static file server in production. Routes are defined with Zod schemas for validation. Development uses Vite middleware for hot module replacement.

### Data Storage
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with drizzle-zod for schema validation
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Migrations**: Managed via `drizzle-kit push`

Key entities: users, scripts, script versions, test schedules, test executions, and comments. The schema supports versioned test scripts, scheduled test runs, and execution tracking with results.

### Report Generation
- **Language**: Python 3.11+
- **Libraries**: numpy, scipy, openpyxl, pyyaml
- **Location**: `scripts/jmeter-report.py` and `attached_assets/`

Python scripts process JMeter CSV results to generate HTML and Excel performance reports with health scores, root cause analysis, and recommendations.

## External Dependencies

### Database
- PostgreSQL database required
- Connection via `DATABASE_URL` environment variable
- Uses `connect-pg-simple` for session storage

### Python Runtime
- Python 3.11+ required for report generation
- Scientific computing libraries: numpy, scipy
- File handling: openpyxl (Excel), pyyaml

### UI Framework Dependencies
- Radix UI primitives for accessible components
- Recharts for charting
- date-fns for date formatting
- class-variance-authority for component variants

### Development Tools
- Replit-specific Vite plugins for development (cartographer, dev-banner, runtime-error-modal)
- TypeScript for type checking
- Drizzle Kit for database migrations