import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").default("engineer").notNull(), // 'admin', 'engineer', 'manager'
  createdAt: timestamp("created_at").defaultNow(),
});

export const scripts = pgTable("scripts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  toolType: text("tool_type").notNull(), // 'JMeter', 'LoadRunner', 'K6', etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const scriptVersions = pgTable("script_versions", {
  id: serial("id").primaryKey(),
  scriptId: integer("script_id").notNull(),
  versionNumber: integer("version_number").notNull(),
  filePath: text("file_path").notNull(),
  changesDescription: text("changes_description"),
  uploadedBy: integer("uploaded_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const testSchedules = pgTable("test_schedules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  scriptVersionId: integer("script_version_id").notNull(),
  scheduledTime: timestamp("scheduled_time").notNull(),
  status: text("status").default("pending").notNull(), // 'pending', 'running', 'completed', 'failed', 'cancelled'
  configuration: jsonb("configuration").$type<{
    vusers?: number;
    rampUp?: number; // seconds
    duration?: number; // seconds
    environment: string;
  }>(), // Made optional and fields optional
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const testExecutions = pgTable("test_executions", {
  id: serial("id").primaryKey(),
  scheduleId: integer("schedule_id").notNull(),
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  status: text("status").notNull(), // 'running', 'completed', 'failed'
  resultSummary: jsonb("result_summary").$type<{
    totalRequests: number;
    failedRequests: number;
    avgResponseTime: number;
    throughput: number;
  }>(),
  artifactsPath: text("artifacts_path"),
  reportHtmlPath: text("report_html_path"),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  executionId: integer("execution_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  type: text("type").default("comment").notNull(), // 'comment', 'sign-off', 'annotation'
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===

export const scriptsRelations = relations(scripts, ({ many }) => ({
  versions: many(scriptVersions),
}));

export const scriptVersionsRelations = relations(scriptVersions, ({ one, many }) => ({
  script: one(scripts, {
    fields: [scriptVersions.scriptId],
    references: [scripts.id],
  }),
  schedules: many(testSchedules),
  uploader: one(users, {
    fields: [scriptVersions.uploadedBy],
    references: [users.id],
  }),
}));

export const testSchedulesRelations = relations(testSchedules, ({ one, many }) => ({
  scriptVersion: one(scriptVersions, {
    fields: [testSchedules.scriptVersionId],
    references: [scriptVersions.id],
  }),
  creator: one(users, {
    fields: [testSchedules.createdBy],
    references: [users.id],
  }),
  executions: many(testExecutions),
}));

export const testExecutionsRelations = relations(testExecutions, ({ one, many }) => ({
  schedule: one(testSchedules, {
    fields: [testExecutions.scheduleId],
    references: [testSchedules.id],
  }),
  comments: many(comments),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  execution: one(testExecutions, {
    fields: [comments.executionId],
    references: [testExecutions.id],
  }),
  user: one(users, {
    fields: [comments.userId],
    references: [users.id],
  }),
}));

// === BASE SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertScriptSchema = createInsertSchema(scripts).omit({ id: true, createdAt: true });
export const insertScriptVersionSchema = createInsertSchema(scriptVersions).omit({ id: true, createdAt: true });
export const insertTestScheduleSchema = createInsertSchema(testSchedules).omit({ id: true, createdAt: true });
export const insertTestExecutionSchema = createInsertSchema(testExecutions).omit({ id: true });
export const insertCommentSchema = createInsertSchema(comments).omit({ id: true, createdAt: true });

// === EXPLICIT API CONTRACT TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Script = typeof scripts.$inferSelect;
export type InsertScript = z.infer<typeof insertScriptSchema>;

export type ScriptVersion = typeof scriptVersions.$inferSelect;
export type InsertScriptVersion = z.infer<typeof insertScriptVersionSchema>;

export type TestSchedule = typeof testSchedules.$inferSelect;
export type InsertTestSchedule = z.infer<typeof insertTestScheduleSchema>;

export type TestExecution = typeof testExecutions.$inferSelect;
export type InsertTestExecution = z.infer<typeof insertTestExecutionSchema>;

export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export type ScriptWithVersions = Script & { versions: ScriptVersion[] };
export type ScheduleWithDetails = TestSchedule & { 
  scriptVersion: ScriptVersion & { script: Script };
  creator: User;
  executions: TestExecution[];
};
export type ExecutionWithDetails = TestExecution & {
  schedule: TestSchedule & { scriptVersion: ScriptVersion & { script: Script } };
  comments: (Comment & { user: User })[];
};

export type DashboardStats = {
  totalScripts: number;
  totalExecutions: number;
  passRate: number;
  activeTests: number;
  recentExecutions: ExecutionWithDetails[];
};
