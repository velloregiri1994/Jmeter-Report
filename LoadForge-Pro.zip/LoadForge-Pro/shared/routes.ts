import { z } from 'zod';
import { 
  insertUserSchema, 
  insertScriptSchema, 
  insertScriptVersionSchema, 
  insertTestScheduleSchema, 
  insertTestExecutionSchema, 
  insertCommentSchema,
  users,
  scripts,
  scriptVersions,
  testSchedules,
  testExecutions,
  comments
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  users: {
    list: {
      method: 'GET' as const,
      path: '/api/users',
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      },
    },
  },
  scripts: {
    list: {
      method: 'GET' as const,
      path: '/api/scripts',
      responses: {
        200: z.array(z.custom<typeof scripts.$inferSelect & { versions: typeof scriptVersions.$inferSelect[] }>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/scripts',
      input: insertScriptSchema,
      responses: {
        201: z.custom<typeof scripts.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/scripts/:id',
      responses: {
        200: z.custom<typeof scripts.$inferSelect & { versions: typeof scriptVersions.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
  },
  scriptVersions: {
    create: {
      method: 'POST' as const,
      path: '/api/scripts/:scriptId/versions',
      // Note: This input schema is for JSON data. File upload is handled separately via FormData.
      // Ideally we'd separate the file upload endpoint or use a presigned URL flow, 
      // but for simple local storage we might assume a multipart request. 
      // For type safety here, we describe the non-file fields.
      input: insertScriptVersionSchema.omit({ filePath: true, uploadedBy: true }), 
      responses: {
        201: z.custom<typeof scriptVersions.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  schedules: {
    list: {
      method: 'GET' as const,
      path: '/api/schedules',
      responses: {
        200: z.array(z.custom<typeof testSchedules.$inferSelect & { 
          scriptVersion: typeof scriptVersions.$inferSelect & { script: typeof scripts.$inferSelect };
          creator: typeof users.$inferSelect;
        }>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/schedules',
      input: insertTestScheduleSchema.omit({ createdBy: true }), // Backend infers user
      responses: {
        201: z.custom<typeof testSchedules.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/schedules/:id',
      responses: {
        200: z.custom<typeof testSchedules.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'PATCH' as const,
      path: '/api/schedules/:id',
      input: insertTestScheduleSchema.partial(),
      responses: {
        200: z.custom<typeof testSchedules.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  executions: {
    list: {
      method: 'GET' as const,
      path: '/api/executions',
      input: z.object({
        status: z.enum(['running', 'completed', 'failed']).optional(),
        limit: z.coerce.number().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof testExecutions.$inferSelect & {
          schedule: typeof testSchedules.$inferSelect & { scriptVersion: typeof scriptVersions.$inferSelect & { script: typeof scripts.$inferSelect } };
        }>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/executions/:id',
      responses: {
        200: z.custom<typeof testExecutions.$inferSelect & {
          schedule: typeof testSchedules.$inferSelect & { scriptVersion: typeof scriptVersions.$inferSelect & { script: typeof scripts.$inferSelect } };
          comments: (typeof comments.$inferSelect & { user: typeof users.$inferSelect })[];
        }>(),
        404: errorSchemas.notFound,
      },
    },
    generateReport: {
      method: 'POST' as const,
      path: '/api/executions/:id/generate-report',
      responses: {
        200: z.object({ url: z.string() }),
        404: errorSchemas.notFound,
        500: z.object({ message: z.string() }),
      },
    },
  },
  comments: {
    create: {
      method: 'POST' as const,
      path: '/api/executions/:executionId/comments',
      input: insertCommentSchema.omit({ executionId: true, userId: true }),
      responses: {
        201: z.custom<typeof comments.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  dashboard: {
    stats: {
      method: 'GET' as const,
      path: '/api/dashboard/stats',
      responses: {
        200: z.object({
          totalScripts: z.number(),
          totalExecutions: z.number(),
          passRate: z.number(),
          activeTests: z.number(),
          recentExecutions: z.array(z.custom<typeof testExecutions.$inferSelect & {
             schedule: typeof testSchedules.$inferSelect & { scriptVersion: typeof scriptVersions.$inferSelect & { script: typeof scripts.$inferSelect } };
          }>())
        }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
