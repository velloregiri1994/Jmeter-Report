import React, { useState, memo, useCallback, useRef } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Minimize2, Maximize2, ChevronDown, ChevronUp, Expand, Download } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type ChartSize = "compact" | "expanded";

interface CollapsibleChartProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  defaultCollapsed?: boolean;
  defaultSize?: ChartSize;
  collapsed?: boolean;
  onToggleCollapse?: () => void;
  size?: ChartSize;
  onSizeChange?: (s: ChartSize) => void;
  compactHeight?: string;
  expandedHeight?: string;
  className?: string;
  headerStats?: string;
}

const COMPACT_H = "h-[220px] sm:h-[260px]";
const EXPANDED_H = "h-[400px] sm:h-[480px] lg:h-[560px]";

export const CollapsibleChart = memo(function CollapsibleChart({
  title,
  icon,
  children,
  defaultCollapsed = false,
  defaultSize = "compact",
  collapsed: controlledCollapsed,
  onToggleCollapse,
  size: controlledSize,
  onSizeChange,
  compactHeight = COMPACT_H,
  expandedHeight = EXPANDED_H,
  className,
  headerStats,
}: CollapsibleChartProps) {
  const [internalCollapsed, setInternalCollapsed] = useState(defaultCollapsed);
  const [internalSize, setInternalSize] = useState<ChartSize>(defaultSize);
  const [fullscreen, setFullscreen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const chartRef = useRef<HTMLDivElement>(null);
  const fullscreenRef = useRef<HTMLDivElement>(null);

  const isCollapsed = controlledCollapsed !== undefined ? controlledCollapsed : internalCollapsed;
  const toggleCollapse = onToggleCollapse || (() => setInternalCollapsed((v) => !v));
  const size = controlledSize !== undefined ? controlledSize : internalSize;
  const setSize = onSizeChange || setInternalSize;

  const handleExportPng = useCallback(async () => {
    const target = fullscreen
      ? fullscreenRef.current
      : chartRef.current;
    if (!target) return;
    const svgEl = target.querySelector('svg.recharts-surface') as SVGSVGElement;
    if (!svgEl) return;
    setExporting(true);
    try {
      const svgClone = svgEl.cloneNode(true) as SVGSVGElement;
      const w = svgEl.viewBox?.baseVal?.width || svgEl.getBoundingClientRect().width;
      const h = svgEl.viewBox?.baseVal?.height || svgEl.getBoundingClientRect().height;
      svgClone.setAttribute('width', String(w));
      svgClone.setAttribute('height', String(h));
      svgClone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

      const styles = document.querySelectorAll('style, link[rel="stylesheet"]');
      const computedBg = getComputedStyle(document.documentElement).getPropertyValue('--card').trim();
      const bgColor = computedBg ? `hsl(${computedBg})` : '#ffffff';

      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('width', '100%');
      rect.setAttribute('height', '100%');
      rect.setAttribute('fill', bgColor);
      svgClone.insertBefore(rect, svgClone.firstChild);

      const allEls = svgClone.querySelectorAll('*');
      allEls.forEach((el) => {
        const htmlEl = el as SVGElement;
        const classes = htmlEl.getAttribute('class') || '';
        if (classes.includes('stroke-muted')) {
          const computedStroke = getComputedStyle(document.documentElement).getPropertyValue('--muted').trim();
          htmlEl.setAttribute('stroke', computedStroke ? `hsl(${computedStroke})` : '#e5e7eb');
          htmlEl.removeAttribute('class');
        }
      });

      const serializer = new XMLSerializer();
      const svgStr = serializer.serializeToString(svgClone);
      const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);

      const canvas = document.createElement('canvas');
      const scale = 2;
      canvas.width = w * scale;
      canvas.height = h * scale;
      const ctx = canvas.getContext('2d')!;
      ctx.scale(scale, scale);

      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, w, h);
        URL.revokeObjectURL(url);

        canvas.toBlob((pngBlob) => {
          if (!pngBlob) return;
          const a = document.createElement('a');
          a.href = URL.createObjectURL(pngBlob);
          a.download = `${title.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase()}.png`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(a.href);
          setExporting(false);
        }, 'image/png');
      };
      img.onerror = () => { setExporting(false); URL.revokeObjectURL(url); };
      img.src = url;
    } catch {
      setExporting(false);
    }
  }, [title, fullscreen, chartRef, fullscreenRef]);

  return (
    <>
      <Card className={cn("card-shadow overflow-hidden transition-all duration-200", className)} role="region" aria-label={title}>
        <CardHeader
          className="bg-muted/30 border-b py-2 px-4 cursor-pointer select-none"
          onClick={toggleCollapse}
          role="button"
          aria-expanded={!isCollapsed}
          aria-controls={`chart-content-${title.replace(/\s+/g, '-').toLowerCase()}`}
          tabIndex={0}
          onKeyDown={(e: React.KeyboardEvent) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              toggleCollapse();
            }
          }}
        >
          <CardTitle className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2">
              {icon}
              <span>{title}</span>
              {headerStats && !isCollapsed && (
                <span className="text-[10px] font-normal text-muted-foreground ml-1 hidden sm:inline">
                  {headerStats}
                </span>
              )}
            </span>
            <span className="flex items-center gap-0.5" onClick={(e) => e.stopPropagation()}>
              {!isCollapsed && (
                <>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={handleExportPng}
                    title="Download as PNG"
                    aria-label="Download chart as PNG"
                    disabled={exporting}
                  >
                    <Download className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={() => setFullscreen(true)}
                    title="Fullscreen"
                    aria-label="Open chart fullscreen"
                  >
                    <Expand className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={() => setSize(size === "compact" ? "expanded" : "compact")}
                    title={size === "compact" ? "Expand chart" : "Shrink chart"}
                    aria-label={size === "compact" ? "Expand chart" : "Shrink chart"}
                  >
                    {size === "compact" ? (
                      <Maximize2 className="w-3 h-3" />
                    ) : (
                      <Minimize2 className="w-3 h-3" />
                    )}
                  </Button>
                </>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={toggleCollapse}
                title={isCollapsed ? "Show chart" : "Hide chart"}
                aria-label={isCollapsed ? "Show chart" : "Hide chart"}
              >
                {isCollapsed ? (
                  <ChevronDown className="w-3.5 h-3.5" />
                ) : (
                  <ChevronUp className="w-3.5 h-3.5" />
                )}
              </Button>
            </span>
          </CardTitle>
        </CardHeader>
        {!isCollapsed && (
          <CardContent className="p-3" id={`chart-content-${title.replace(/\s+/g, '-').toLowerCase()}`}>
            <div ref={chartRef} className={cn(
              "transition-all duration-200 flex flex-col",
              size === "compact" ? compactHeight : expandedHeight,
            )}>
              {children}
            </div>
          </CardContent>
        )}
      </Card>

      <Dialog open={fullscreen} onOpenChange={setFullscreen}>
        <DialogContent className="max-w-[95vw] w-[95vw] h-[90vh] flex flex-col p-0">
          <DialogHeader className="px-6 py-3 border-b bg-muted/30 flex-shrink-0">
            <DialogTitle className="flex items-center justify-between text-sm">
              <span className="flex items-center gap-2">
                {icon}
                {title}
                {headerStats && (
                  <span className="text-[10px] font-normal text-muted-foreground ml-2">
                    {headerStats}
                  </span>
                )}
              </span>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={handleExportPng}
                disabled={exporting}
              >
                <Download className="w-3 h-3 mr-1" />
                {exporting ? 'Exporting...' : 'PNG'}
              </Button>
            </DialogTitle>
          </DialogHeader>
          <div ref={fullscreenRef} className="flex-1 p-4 min-h-0">
            {children}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
});

interface ChartGridProps {
  children: React.ReactNode;
  columns?: 1 | 2;
}

export const ChartGrid = memo(function ChartGrid({ children, columns = 2 }: ChartGridProps) {
  return (
    <div className={cn(
      "grid gap-4",
      columns === 2 ? "grid-cols-1 lg:grid-cols-2" : "grid-cols-1",
    )}>
      {children}
    </div>
  );
});

interface ChartToolbarProps {
  onExpandAll: () => void;
  onCollapseAll: () => void;
  layout: 1 | 2;
  onLayoutChange: (cols: 1 | 2) => void;
}

export const ChartToolbar = memo(function ChartToolbar({ onExpandAll, onCollapseAll, layout, onLayoutChange }: ChartToolbarProps) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Charts</span>
      <div className="flex items-center gap-1.5">
        <Button variant="ghost" size="sm" className="h-7 text-xs px-2" onClick={onExpandAll} aria-label="Show all charts">
          Show All
        </Button>
        <Button variant="ghost" size="sm" className="h-7 text-xs px-2" onClick={onCollapseAll} aria-label="Hide all charts">
          Hide All
        </Button>
        <span className="w-px h-4 bg-border mx-1" />
        <Button
          variant={layout === 1 ? "secondary" : "ghost"}
          size="sm"
          className="h-7 text-xs px-2"
          onClick={() => onLayoutChange(1)}
          aria-label="Single column layout"
        >
          1 Col
        </Button>
        <Button
          variant={layout === 2 ? "secondary" : "ghost"}
          size="sm"
          className="h-7 text-xs px-2"
          onClick={() => onLayoutChange(2)}
          aria-label="Two column layout"
        >
          2 Col
        </Button>
      </div>
    </div>
  );
});
