import React, { Component, ErrorInfo, ReactNode } from "react";
import { ErrorDisplay } from "./error-dialog";
import { ApiError } from "@/lib/queryClient";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  resetKey: number;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null, resetKey: 0 };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("[ErrorBoundary]", error, errorInfo);
  }

  handleRetry = () => {
    this.setState((prev) => ({ hasError: false, error: null, resetKey: prev.resetKey + 1 }));
    this.props.onReset?.();
  };

  handleGoHome = () => {
    window.location.href = "/";
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      const err = this.state.error;

      if (err instanceof ApiError) {
        return (
          <ErrorDisplay
            severity={err.severity}
            message={err.message}
            errorId={err.errorId}
            correlationId={err.correlationId}
            code={err.code}
            details={err.details}
            action={err.action}
            timestamp={err.timestamp}
            onRetry={this.handleRetry}
            onGoHome={this.handleGoHome}
          />
        );
      }

      return (
        <ErrorDisplay
          severity="error"
          message="We encountered an unexpected error. Please try again or return to the dashboard."
          details={err?.message}
          onRetry={this.handleRetry}
          onGoHome={this.handleGoHome}
        />
      );
    }

    return <React.Fragment key={this.state.resetKey}>{this.props.children}</React.Fragment>;
  }
}

interface QueryErrorFallbackProps {
  error: Error | null;
  onRetry: () => void;
  title?: string;
}

export function QueryErrorFallback({ error, onRetry, title }: QueryErrorFallbackProps) {
  if (error instanceof ApiError) {
    return (
      <ErrorDisplay
        severity={error.severity}
        title={title}
        message={error.message}
        errorId={error.errorId}
        correlationId={error.correlationId}
        code={error.code}
        details={error.details}
        action={error.action}
        timestamp={error.timestamp}
        onRetry={onRetry}
      />
    );
  }

  return (
    <ErrorDisplay
      severity="error"
      title={title || "Failed to load data"}
      message={error?.message || "There was a problem loading this content."}
      onRetry={onRetry}
    />
  );
}
