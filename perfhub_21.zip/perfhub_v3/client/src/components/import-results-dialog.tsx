import { useState, useRef } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryKeys } from "@/lib/query-keys";
import { Upload, FileText, Loader2, AlertCircle } from "lucide-react";

interface ImportResultsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ImportResultsDialog({ open, onOpenChange }: ImportResultsDialogProps) {
  const [file, setFile] = useState<File | null>(null);
  const [testName, setTestName] = useState("");
  const [environment, setEnvironment] = useState("");
  const [scriptId, setScriptId] = useState<string>("");
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();

  const { data: scripts } = useQuery({
    queryKey: queryKeys.scripts.all,
    queryFn: async () => {
      const res = await fetch("/api/scripts", { credentials: "include" });
      return res.json();
    },
    enabled: open,
  });

  const { data: environments } = useQuery({
    queryKey: queryKeys.environments,
    queryFn: async () => {
      const res = await fetch("/api/environments", { credentials: "include" });
      return res.json();
    },
    enabled: open,
  });

  const importMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch("/api/results/import", {
        method: "POST",
        body: formData,
        credentials: "include",
        headers: {
          "X-Requested-With": "XMLHttpRequest",
        },
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Import failed");
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.executions.all });
      toast({
        title: "Results imported successfully",
        description: `${data.resultSummary?.totalRequests?.toLocaleString() || 0} requests parsed from ${file?.name}`,
      });
      resetForm();
      onOpenChange(false);
      navigate(`/executions/${data.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Import failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function resetForm() {
    setFile(null);
    setTestName("");
    setEnvironment("");
    setScriptId("");
  }

  function handleSubmit() {
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);
    if (testName.trim()) formData.append("testName", testName.trim());
    if (environment && environment !== "none") formData.append("environment", environment);
    if (scriptId && scriptId !== "none") formData.append("scriptId", scriptId);

    importMutation.mutate(formData);
  }

  function handleFileSelect(selectedFile: File | null) {
    if (!selectedFile) return;
    const ext = selectedFile.name.toLowerCase();
    if (!ext.endsWith(".csv") && !ext.endsWith(".jtl")) {
      toast({
        title: "Invalid file type",
        description: "Only .csv and .jtl files are accepted",
        variant: "destructive",
      });
      return;
    }
    setFile(selectedFile);
    if (!testName) {
      setTestName(selectedFile.name.replace(/\.(csv|jtl)$/i, ""));
    }
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragOver(false);
    const droppedFile = e.dataTransfer.files[0];
    handleFileSelect(droppedFile);
  }

  return (
    <Dialog open={open} onOpenChange={(val) => {
      if (!val) resetForm();
      onOpenChange(val);
    }}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Import JMeter Results
          </DialogTitle>
          <DialogDescription>
            Upload a JMeter CSV/JTL result file to import it as a completed execution with full analytics.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
              dragOver
                ? "border-primary bg-primary/5"
                : file
                ? "border-green-500/50 bg-green-500/5"
                : "border-muted-foreground/25 hover:border-primary/50"
            }`}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.jtl"
              className="hidden"
              onChange={(e) => handleFileSelect(e.target.files?.[0] || null)}
            />
            {file ? (
              <div className="flex items-center justify-center gap-2 text-sm">
                <FileText className="w-5 h-5 text-green-500" />
                <span className="font-medium">{file.name}</span>
                <span className="text-muted-foreground">
                  ({(file.size / 1024 / 1024).toFixed(1)} MB)
                </span>
              </div>
            ) : (
              <div className="space-y-1">
                <Upload className="w-8 h-8 mx-auto text-muted-foreground/50" />
                <p className="text-sm text-muted-foreground">
                  Drag & drop a .csv or .jtl file, or click to browse
                </p>
                <p className="text-xs text-muted-foreground/70">Max 500 MB</p>
              </div>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="testName">Test Name</Label>
            <Input
              id="testName"
              placeholder="e.g. Login Load Test - 500 VUs"
              value={testName}
              onChange={(e) => setTestName(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Link to Script</Label>
              <Select value={scriptId} onValueChange={setScriptId}>
                <SelectTrigger>
                  <SelectValue placeholder="None (optional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {scripts?.map((s: any) => (
                    <SelectItem key={s.id} value={String(s.id)}>
                      {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>Environment</Label>
              <Select value={environment} onValueChange={setEnvironment}>
                <SelectTrigger>
                  <SelectValue placeholder="None (optional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {environments?.map((env: any) => (
                    <SelectItem key={env.id} value={env.name}>
                      {env.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {importMutation.isError && (
            <div className="flex items-start gap-2 p-3 rounded-md bg-destructive/10 text-destructive text-sm">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{importMutation.error?.message}</span>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => { resetForm(); onOpenChange(false); }} disabled={importMutation.isPending}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!file || importMutation.isPending} className="gap-2">
            {importMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Parsing...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4" />
                Import Results
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
