import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Bell,
  Check,
  CheckCheck,
  AlertTriangle,
  Info,
  X,
  ExternalLink,
  Trash2,
  XCircle,
  CheckCircle2,
  Clock,
  Zap,
  Filter,
} from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import { queryKeys } from "@/lib/query-keys";

type NotificationType = "info" | "warning" | "error" | "sla_violation" | "success";

const typeConfig: Record<NotificationType, { icon: typeof Bell; color: string; bgColor: string; label: string }> = {
  sla_violation: { icon: AlertTriangle, color: "text-amber-500", bgColor: "bg-amber-500/10", label: "SLA Violation" },
  error: { icon: XCircle, color: "text-red-500", bgColor: "bg-red-500/10", label: "Error" },
  warning: { icon: AlertTriangle, color: "text-orange-500", bgColor: "bg-orange-500/10", label: "Warning" },
  success: { icon: CheckCircle2, color: "text-emerald-500", bgColor: "bg-emerald-500/10", label: "Success" },
  info: { icon: Info, color: "text-blue-500", bgColor: "bg-blue-500/10", label: "Info" },
};

function getTypeConfig(type: string) {
  return typeConfig[type as NotificationType] || typeConfig.info;
}

export function NotificationBell() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<"all" | "unread">("all");
  const [open, setOpen] = useState(false);

  const { data: notifications = [] } = useQuery({
    queryKey: [...queryKeys.notifications.all],
    queryFn: async () => {
      const res = await fetch("/api/notifications");
      if (!res.ok) throw new Error("Failed to fetch notifications");
      return res.json();
    },
    refetchInterval: 10000,
  });

  const { data: unreadData } = useQuery({
    queryKey: [...queryKeys.notifications.unreadCount],
    queryFn: async () => {
      const res = await fetch("/api/notifications/unread-count");
      if (!res.ok) throw new Error("Failed to fetch unread count");
      return res.json();
    },
    refetchInterval: 10000,
  });

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.notifications.all });
    queryClient.invalidateQueries({ queryKey: queryKeys.notifications.unreadCount });
  };

  const markReadMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("POST", `/api/notifications/${id}/read`);
    },
    onSuccess: invalidateAll,
  });

  const markAllReadMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/notifications/mark-all-read");
    },
    onSuccess: invalidateAll,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/notifications/${id}`);
    },
    onSuccess: invalidateAll,
  });

  const clearAllMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", "/api/notifications");
    },
    onSuccess: invalidateAll,
  });

  const unreadCount = unreadData?.count || 0;

  const filteredNotifications = tab === "unread"
    ? notifications.filter((n: any) => !n.read)
    : notifications;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
          <Bell className={cn("h-5 w-5 transition-colors", unreadCount > 0 && "text-primary")} />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 flex h-4 min-w-[16px] items-center justify-center" aria-live="polite">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-50" />
              <Badge
                variant="destructive"
                className="relative h-4 min-w-[16px] flex items-center justify-center p-0 px-1 text-[9px] rounded-full"
              >
                {unreadCount > 99 ? "99+" : unreadCount}
              </Badge>
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[380px] p-0" align="end" sideOffset={8}>
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <div className="flex items-center gap-2">
            <Bell className="h-4 w-4 text-muted-foreground" />
            <h4 className="font-semibold text-sm">Notifications</h4>
            {unreadCount > 0 && (
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-5">
                {unreadCount} new
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-1">
            {unreadCount > 0 && (
              <TooltipProvider delayDuration={300}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => markAllReadMutation.mutate()}
                      disabled={markAllReadMutation.isPending}
                    >
                      <CheckCheck className="h-3.5 w-3.5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom"><p>Mark all as read</p></TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            {notifications.length > 0 && (
              <TooltipProvider delayDuration={300}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-muted-foreground hover:text-destructive"
                      onClick={() => clearAllMutation.mutate()}
                      disabled={clearAllMutation.isPending}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom"><p>Clear all notifications</p></TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
        </div>

        <div className="px-3 pt-2 pb-1">
          <Tabs value={tab} onValueChange={(v) => setTab(v as "all" | "unread")}>
            <TabsList className="h-8 w-full">
              <TabsTrigger value="all" className="flex-1 text-xs h-7">
                All ({notifications.length})
              </TabsTrigger>
              <TabsTrigger value="unread" className="flex-1 text-xs h-7">
                Unread ({unreadCount})
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <ScrollArea className="h-[360px]">
          {filteredNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 px-8 text-center">
              <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-3">
                {tab === "unread" ? (
                  <CheckCheck className="h-6 w-6 text-muted-foreground/50" />
                ) : (
                  <Bell className="h-6 w-6 text-muted-foreground/50" />
                )}
              </div>
              <p className="text-sm font-medium text-muted-foreground">
                {tab === "unread" ? "All caught up!" : "No notifications yet"}
              </p>
              <p className="text-xs text-muted-foreground/70 mt-1">
                {tab === "unread"
                  ? "You have no unread notifications"
                  : "Notifications about tests and SLA violations will appear here"}
              </p>
            </div>
          ) : (
            <div className="flex flex-col py-1">
              {filteredNotifications.map((notif: any) => {
                const config = getTypeConfig(notif.type);
                const Icon = config.icon;
                return (
                  <div
                    key={notif.id}
                    className={cn(
                      "group relative px-4 py-3 transition-all duration-150 hover:bg-muted/40",
                      !notif.read && "bg-primary/[0.03]"
                    )}
                  >
                    {!notif.read && (
                      <div className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-primary" />
                    )}
                    <div className="flex gap-3">
                      <div className={cn("mt-0.5 flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center", config.bgColor)}>
                        <Icon className={cn("h-4 w-4", config.color)} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start gap-2">
                          <p className={cn(
                            "text-sm leading-tight",
                            !notif.read ? "font-semibold text-foreground" : "font-medium text-muted-foreground"
                          )}>
                            {notif.title}
                          </p>
                          <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                            {!notif.read && (
                              <TooltipProvider delayDuration={200}>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-6 w-6 hover:bg-primary/10 hover:text-primary"
                                      onClick={(e) => { e.stopPropagation(); markReadMutation.mutate(notif.id); }}
                                    >
                                      <Check className="h-3 w-3" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent side="left"><p>Mark as read</p></TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            )}
                            <TooltipProvider delayDuration={200}>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6 hover:bg-destructive/10 hover:text-destructive"
                                    onClick={(e) => { e.stopPropagation(); deleteMutation.mutate(notif.id); }}
                                  >
                                    <X className="h-3 w-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent side="left"><p>Dismiss</p></TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5 leading-relaxed">
                          {notif.message}
                        </p>
                        <div className="flex items-center gap-2 mt-1.5">
                          <div className="flex items-center gap-1 text-[10px] text-muted-foreground/70">
                            <Clock className="h-2.5 w-2.5" />
                            {formatDistanceToNow(new Date(notif.createdAt), { addSuffix: true })}
                          </div>
                          <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 border-muted-foreground/20">
                            {config.label}
                          </Badge>
                          {notif.link && (
                            <Link href={notif.link} onClick={() => setOpen(false)}>
                              <span className="inline-flex items-center gap-0.5 text-[10px] text-primary font-semibold hover:underline cursor-pointer">
                                View <ExternalLink className="h-2.5 w-2.5" />
                              </span>
                            </Link>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>

        {notifications.length > 0 && (
          <div className="px-3 py-2 border-t bg-muted/30">
            <Link href="/notifications" onClick={() => setOpen(false)}>
              <Button variant="ghost" size="sm" className="w-full text-xs text-muted-foreground hover:text-foreground">
                View all notifications
              </Button>
            </Link>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
