import { Breadcrumbs } from "./breadcrumbs";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  actionsStacked?: boolean;
}

export function PageHeader({ title, subtitle, actions, actionsStacked }: PageHeaderProps) {
  return (
    <div className="mb-6 sm:mb-8">
      <Breadcrumbs />
      <div className={actionsStacked
        ? "flex flex-col gap-3"
        : "flex flex-col sm:flex-row sm:items-start justify-between gap-3 sm:gap-4"
      }>
        <div className="min-w-0 flex-1">
          <h1 className="page-title" role="heading" aria-level={1}>{title}</h1>
          {subtitle && <p className="page-subtitle mt-1">{subtitle}</p>}
        </div>
        {actions && (
          <div className="flex flex-wrap items-center gap-2">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}
