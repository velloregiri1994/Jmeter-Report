import { Link } from "wouter";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface QuickActionFabProps {
  href: string;
  label: string;
}

export function QuickActionFab({ href, label }: QuickActionFabProps) {
  return (
    <div className="fixed bottom-6 right-6 z-40 lg:bottom-8 lg:right-8">
      <Tooltip>
        <TooltipTrigger asChild>
          <Link href={href}>
            <Button
              size="lg"
              className="h-14 w-14 rounded-full shadow-lg shadow-primary/30 hover:shadow-primary/50 hover:scale-105 transition-all duration-200"
              aria-label={label}
            >
              <Plus className="h-6 w-6" />
            </Button>
          </Link>
        </TooltipTrigger>
        <TooltipContent side="left">
          <p>{label}</p>
        </TooltipContent>
      </Tooltip>
    </div>
  );
}
