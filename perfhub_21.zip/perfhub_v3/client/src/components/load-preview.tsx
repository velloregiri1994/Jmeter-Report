import { useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine,
} from "recharts";
import { Users, Clock, TrendingUp, Zap, BarChart3 } from "lucide-react";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS, DynatraceGradients } from "@/components/charts/dynatrace-theme";

interface LoadPreviewProps {
  threads: number;
  rampUp: number;
  duration: number;
  schedulerEnabled: boolean;
  loopCount: number;
  loopForever: boolean;
  throughput?: number;
}

interface DataPoint {
  time: number;
  label: string;
  users: number;
  phase: string;
}

function formatTime(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (s === 0) return `${m}m`;
  return `${m}m ${s}s`;
}

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds} seconds`;
  if (seconds < 3600) {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return s > 0 ? `${m}m ${s}s` : `${m} minute${m > 1 ? "s" : ""}`;
  }
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return m > 0 ? `${h}h ${m}m` : `${h} hour${h > 1 ? "s" : ""}`;
}

function computeLoadCurve(props: LoadPreviewProps): DataPoint[] {
  const { threads, rampUp, duration, schedulerEnabled, loopCount, loopForever } = props;
  const points: DataPoint[] = [];

  if (threads <= 0) return points;

  let testDuration: number;

  if (schedulerEnabled && duration > 0) {
    testDuration = duration;
  } else if (loopForever || loopCount === -1) {
    testDuration = Math.max(rampUp * 2, 300);
  } else {
    const estimatedIterationTime = 5;
    testDuration = Math.max(rampUp + loopCount * estimatedIterationTime, rampUp + 30);
  }

  const effectiveRampUp = Math.min(rampUp, testDuration);
  const numPoints = Math.min(Math.max(40, Math.floor(testDuration / 2)), 200);
  const step = testDuration / numPoints;

  for (let i = 0; i <= numPoints; i++) {
    const t = Math.round(i * step);
    let users: number;
    let phase: string;

    if (effectiveRampUp > 0 && t < effectiveRampUp) {
      users = Math.round((t / effectiveRampUp) * threads);
      phase = "Ramp-Up";
    } else {
      users = threads;
      phase = "Steady State";
    }

    points.push({
      time: t,
      label: formatTime(t),
      users,
      phase,
    });
  }

  return points;
}

function EstimationCard({
  icon: Icon,
  label,
  value,
  sub,
  color,
}: {
  icon: any;
  label: string;
  value: string;
  sub?: string;
  color: string;
}) {
  return (
    <div className={`flex items-start gap-2.5 p-2.5 rounded-lg border ${color}`}>
      <div className="p-1.5 rounded-md bg-background/60 mt-0.5">
        <Icon className="w-3.5 h-3.5" />
      </div>
      <div className="min-w-0">
        <div className="text-[11px] text-muted-foreground uppercase tracking-wide">{label}</div>
        <div className="text-sm font-semibold leading-tight">{value}</div>
        {sub && <div className="text-[11px] text-muted-foreground mt-0.5">{sub}</div>}
      </div>
    </div>
  );
}

export function LoadPreview(props: LoadPreviewProps) {
  const { threads, rampUp, duration, schedulerEnabled, loopCount, loopForever, throughput } = props;

  const dataPoints = useMemo(() => computeLoadCurve(props), [
    threads, rampUp, duration, schedulerEnabled, loopCount, loopForever,
  ]);

  const estimations = useMemo(() => {
    if (threads <= 0) return null;

    let testDuration: number;
    let durationLabel: string;

    if (schedulerEnabled && duration > 0) {
      testDuration = duration;
      durationLabel = formatDuration(duration);
    } else if (loopForever || loopCount === -1) {
      testDuration = 0;
      durationLabel = "Infinite (until stopped)";
    } else {
      const estimatedIterationTime = 5;
      testDuration = rampUp + loopCount * estimatedIterationTime;
      durationLabel = `~${formatDuration(testDuration)}`;
    }

    const steadyStateSec = testDuration > 0 ? Math.max(testDuration - rampUp, 0) : 0;
    const rampUpAvgUsers = threads / 2;
    const effectiveRampUp = testDuration > 0 ? Math.min(rampUp, testDuration) : rampUp;

    let estimatedRequests: string | null = null;
    if (throughput && throughput > 0) {
      const rps = throughput / 60;
      const rampRequests = rps * effectiveRampUp * 0.5;
      const steadyRequests = rps * steadyStateSec;
      const total = Math.round(rampRequests + steadyRequests);
      estimatedRequests = total > 0 ? total.toLocaleString() : null;
    }

    const rampUpPercent = testDuration > 0 ? Math.round((effectiveRampUp / testDuration) * 100) : 0;

    let rampUpWarning: string | null = null;
    if (rampUpPercent > 50 && schedulerEnabled && duration > 0) {
      rampUpWarning = `Ramp-up is ${rampUpPercent}% of total duration`;
    }
    if (rampUp > 0 && threads > 0) {
      const usersPerSec = threads / rampUp;
      if (usersPerSec > 50) {
        rampUpWarning = `Adding ~${Math.round(usersPerSec)} users/sec (aggressive ramp)`;
      }
    }

    return {
      peakUsers: threads,
      testDuration: durationLabel,
      steadyStateSec,
      rampUpSec: effectiveRampUp,
      estimatedRequests,
      rampUpWarning,
      usersPerSecond: rampUp > 0 ? (threads / rampUp).toFixed(1) : threads.toString(),
    };
  }, [threads, rampUp, duration, schedulerEnabled, loopCount, loopForever, throughput]);

  if (threads <= 0 || dataPoints.length === 0) {
    return null;
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <BarChart3 className="w-4 h-4 text-muted-foreground" />
        <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
          Load Preview
        </span>
        <Badge variant="outline" className="text-[10px] font-normal ml-auto">
          Estimated
        </Badge>
      </div>

      <div className="rounded-lg border bg-card/50 p-3">
        <ResponsiveContainer width="100%" height={160}>
          <AreaChart data={dataPoints} margin={{ top: 5, right: 10, left: -15, bottom: 0 }}>
            <DynatraceGradients />
            <CartesianGrid {...DT_GRID_PROPS} />
            <XAxis
              dataKey="label"
              {...DT_AXIS_PROPS}
              interval="preserveStartEnd"
              tickCount={6}
            />
            <YAxis
              {...DT_AXIS_PROPS}
              allowDecimals={false}
              domain={[0, (max: number) => Math.ceil(max * 1.1)]}
            />
            <Tooltip
              contentStyle={{
                borderRadius: '6px',
                border: '1px solid hsl(var(--border))',
                background: 'hsl(var(--card))',
                fontSize: '12px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
              }}
              cursor={DT_CURSOR_PROPS}
              formatter={(value: number, name: string) => [`${value} users`, "Virtual Users"]}
              labelFormatter={(label: string) => `Time: ${label}`}
            />
            {rampUp > 0 && (
              <ReferenceLine
                x={formatTime(Math.min(rampUp, dataPoints[dataPoints.length - 1]?.time || 0))}
                stroke={DT_COLORS.purple}
                strokeDasharray="4 4"
                strokeOpacity={0.6}
                label={{
                  value: "Ramp-Up End",
                  position: "top",
                  fontSize: 10,
                  fill: "hsl(var(--muted-foreground))",
                }}
              />
            )}
            <Area
              type="monotone"
              dataKey="users"
              stroke={DT_COLORS.primary}
              strokeWidth={2}
              fill="url(#dt-grad-primary)"
              animationDuration={400}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {estimations && (
        <div className="grid grid-cols-2 gap-2">
          <EstimationCard
            icon={Users}
            label="Peak Users"
            value={estimations.peakUsers.toLocaleString()}
            sub={`${estimations.usersPerSecond} users/sec ramp`}
            color="bg-blue-500/5 border-blue-500/20"
          />
          <EstimationCard
            icon={Clock}
            label="Est. Duration"
            value={estimations.testDuration}
            sub={estimations.rampUpSec > 0 ? `${formatDuration(estimations.rampUpSec)} ramp-up` : undefined}
            color="bg-purple-500/5 border-purple-500/20"
          />
          {estimations.estimatedRequests && (
            <EstimationCard
              icon={Zap}
              label="Est. Requests"
              value={estimations.estimatedRequests}
              sub={`At ${throughput} req/min`}
              color="bg-emerald-500/5 border-emerald-500/20"
            />
          )}
          {estimations.rampUpWarning && (
            <EstimationCard
              icon={TrendingUp}
              label="Warning"
              value={estimations.rampUpWarning}
              color="bg-amber-500/5 border-amber-500/20"
            />
          )}
        </div>
      )}
    </div>
  );
}
