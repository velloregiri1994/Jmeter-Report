import { memo } from "react";
import { cn } from "@/lib/utils";

type StatusType = "pending" | "queued" | "running" | "completed" | "failed" | "cancelled" | "passed" | "aborted";

const dotColors: Record<StatusType, string> = {
  pending: "bg-amber-500",
  queued: "bg-violet-500",
  running: "bg-sky-500 animate-pulse",
  completed: "bg-emerald-500",
  passed: "bg-emerald-500",
  failed: "bg-red-500",
  cancelled: "bg-gray-400",
  aborted: "bg-orange-500",
};

const variants: Record<StatusType, string> = {
  pending: "bg-amber-500/15 text-amber-700 border-amber-500/25 dark:bg-amber-500/20 dark:text-amber-300 dark:border-amber-500/30",
  queued: "bg-violet-500/15 text-violet-700 border-violet-500/25 dark:bg-violet-500/20 dark:text-violet-300 dark:border-violet-500/30",
  running: "bg-sky-500/15 text-sky-700 border-sky-500/25 dark:bg-sky-500/20 dark:text-sky-300 dark:border-sky-500/30",
  completed: "bg-emerald-500/15 text-emerald-700 border-emerald-500/25 dark:bg-emerald-500/20 dark:text-emerald-300 dark:border-emerald-500/30",
  passed: "bg-emerald-500/15 text-emerald-700 border-emerald-500/25 dark:bg-emerald-500/20 dark:text-emerald-300 dark:border-emerald-500/30",
  failed: "bg-red-500/15 text-red-700 border-red-500/25 dark:bg-red-500/20 dark:text-red-300 dark:border-red-500/30",
  cancelled: "bg-gray-500/15 text-gray-600 border-gray-500/25 dark:bg-gray-500/20 dark:text-gray-300 dark:border-gray-500/30",
  aborted: "bg-orange-500/15 text-orange-700 border-orange-500/25 dark:bg-orange-500/20 dark:text-orange-300 dark:border-orange-500/30",
};

export const StatusBadge = memo(function StatusBadge({ status, className }: { status: string; className?: string }) {
  const key = status.toLowerCase() as StatusType;
  const variant = variants[key] || variants.cancelled;
  const dot = dotColors[key] || dotColors.cancelled;
  
  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold border capitalize",
      variant,
      className
    )} role="status" aria-label={`Status: ${status}`}>
      <span className={cn("w-1.5 h-1.5 rounded-full shrink-0", dot)} />
      {status}
    </span>
  );
});
