import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { ShieldAlert, Plus, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface ExecutionAutoAbortRule {
  id: number;
  executionId: number;
  metric: string;
  comparator: string;
  threshold: number;
  sustainedSeconds: number;
  isEnabled: boolean;
}

interface Props {
  executionId: number;
  executionName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const METRICS = [
  { value: "errorRate", label: "Error Rate (%)" },
  { value: "avgResponseTime", label: "Avg Response Time (ms)" },
  { value: "p90", label: "P90 Response Time (ms)" },
  { value: "p95", label: "P95 Response Time (ms)" },
  { value: "p99", label: "P99 Response Time (ms)" },
  { value: "maxResponseTime", label: "Max Response Time (ms)" },
  { value: "throughput", label: "Throughput (req/s)" },
];

const COMPARATORS = [
  { value: "gt", label: "> (greater than)" },
  { value: "gte", label: ">= (greater or equal)" },
  { value: "lt", label: "< (less than)" },
  { value: "lte", label: "<= (less or equal)" },
];

export function ExecutionAutoAbortDialog({ executionId, executionName, open, onOpenChange }: Props) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [metric, setMetric] = useState("errorRate");
  const [comparator, setComparator] = useState("gt");
  const [threshold, setThreshold] = useState("");
  const [sustainedSeconds, setSustainedSeconds] = useState("30");

  const { data: rules = [], isLoading } = useQuery<ExecutionAutoAbortRule[]>({
    queryKey: [`/api/executions/${executionId}/auto-abort-rules`],
    queryFn: async () => {
      const res = await fetch(`/api/executions/${executionId}/auto-abort-rules`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch rules");
      return res.json();
    },
    enabled: open,
  });

  const createMutation = useMutation({
    mutationFn: async (data: { metric: string; comparator: string; threshold: number; sustainedSeconds: number }) => {
      const res = await fetch(`/api/executions/${executionId}/auto-abort-rules`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to create rule");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/executions/${executionId}/auto-abort-rules`] });
      toast({ title: "Auto-abort rule added" });
      setThreshold("");
      setSustainedSeconds("30");
    },
    onError: (err: Error) => {
      toast({ title: "Failed to add rule", description: err.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (ruleId: number) => {
      const res = await fetch(`/api/execution-auto-abort-rules/${ruleId}`, {
        method: "DELETE",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete rule");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/executions/${executionId}/auto-abort-rules`] });
      toast({ title: "Auto-abort rule removed" });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ ruleId, isEnabled }: { ruleId: number; isEnabled: boolean }) => {
      const res = await fetch(`/api/execution-auto-abort-rules/${ruleId}/toggle`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" },
        credentials: "include",
        body: JSON.stringify({ isEnabled }),
      });
      if (!res.ok) throw new Error("Failed to toggle rule");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/executions/${executionId}/auto-abort-rules`] });
    },
  });

  const handleAdd = () => {
    const thresholdNum = parseFloat(threshold);
    if (isNaN(thresholdNum) || thresholdNum < 0) {
      toast({ title: "Invalid threshold", description: "Please enter a valid number", variant: "destructive" });
      return;
    }
    const sustained = parseInt(sustainedSeconds) || 30;
    createMutation.mutate({
      metric,
      comparator,
      threshold: thresholdNum,
      sustainedSeconds: sustained,
    });
  };

  const getMetricLabel = (m: string) => METRICS.find(x => x.value === m)?.label || m;
  const getComparatorSymbol = (c: string) => {
    const map: Record<string, string> = { gt: ">", gte: ">=", lt: "<", lte: "<=" };
    return map[c] || c;
  };
  const getMetricUnit = (m: string) => {
    if (m === "errorRate") return "%";
    if (m === "throughput") return " req/s";
    return " ms";
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-500" />
            Auto-Abort Rules
          </DialogTitle>
          <DialogDescription className="text-sm">
            {executionName} — Automatically stop this test when metrics breach thresholds for a sustained period. New rules take effect within ~30 seconds.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="border rounded-lg p-4 space-y-3 bg-muted/30">
            <h4 className="text-sm font-medium flex items-center gap-1.5">
              <Plus className="w-4 h-4" /> Add Rule
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Metric</Label>
                <Select value={metric} onValueChange={setMetric}>
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {METRICS.map(m => (
                      <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Condition</Label>
                <Select value={comparator} onValueChange={setComparator}>
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {COMPARATORS.map(c => (
                      <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Threshold</Label>
                <Input
                  type="number"
                  min="0"
                  step="any"
                  placeholder={metric === "errorRate" ? "e.g. 5" : metric === "throughput" ? "e.g. 100" : "e.g. 3000"}
                  value={threshold}
                  onChange={(e) => setThreshold(e.target.value)}
                  className="h-9"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Sustained (seconds)</Label>
                <Input
                  type="number"
                  min="1"
                  placeholder="30"
                  value={sustainedSeconds}
                  onChange={(e) => setSustainedSeconds(e.target.value)}
                  className="h-9"
                />
              </div>
            </div>
            <Button
              size="sm"
              onClick={handleAdd}
              disabled={!threshold || createMutation.isPending}
              className="w-full"
            >
              <Plus className="w-4 h-4 mr-1" />
              {createMutation.isPending ? "Adding..." : "Add Auto-Abort Rule"}
            </Button>
          </div>

          <div className="space-y-2">
            <h4 className="text-sm font-medium flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-rose-500" /> Active Rules ({rules.length})
            </h4>
            {isLoading ? (
              <div className="text-sm text-muted-foreground p-3 text-center">Loading...</div>
            ) : rules.length === 0 ? (
              <div className="text-sm text-muted-foreground p-4 text-center border rounded-lg bg-muted/10">
                No auto-abort rules configured for this execution. Add rules above to automatically stop the test when thresholds are breached.
              </div>
            ) : (
              <div className="space-y-1.5 max-h-[200px] overflow-y-auto">
                {rules.map(rule => (
                  <div key={rule.id} className="flex items-center justify-between p-2.5 border rounded-lg bg-card hover:bg-accent/30 transition-colors">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <Badge variant="outline" className="text-[10px] shrink-0">
                        {getMetricLabel(rule.metric).split(" ")[0]}
                      </Badge>
                      <span className="text-sm truncate">
                        {getComparatorSymbol(rule.comparator)} {rule.threshold}{getMetricUnit(rule.metric)}
                        <span className="text-muted-foreground ml-1.5">for {rule.sustainedSeconds}s</span>
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <Switch
                        checked={rule.isEnabled}
                        onCheckedChange={(checked) => toggleMutation.mutate({ ruleId: rule.id, isEnabled: checked })}
                        className="scale-75"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-muted-foreground hover:text-destructive shrink-0"
                        onClick={() => deleteMutation.mutate(rule.id)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
