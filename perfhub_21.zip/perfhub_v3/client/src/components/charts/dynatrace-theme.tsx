import React, { useState, useCallback } from "react";

export const DT_COLORS = {
  primary: '#1496ff',
  purple: '#7c38bc',
  teal: '#00b4d8',
  green: '#2ab06f',
  amber: '#f5a623',
  red: '#dc3545',
  cyan: '#00a1b2',
  indigo: '#4fd1c5',
  navy: '#14233c',
  deepBlue: '#1a3a5c',
  lavender: '#b388ff',
  orange: '#ff6d00',

  responseTime: '#1496ff',
  p95: '#7c38bc',
  throughput: '#2ab06f',
  threads: '#00b4d8',
  errors: '#dc3545',
  errorRate: '#dc3545',
  cpu: '#ff6d00',
  memory: '#1496ff',
  jmeterCpu: '#7c38bc',
  jmeterMem: '#2ab06f',

  warning: '#f5a623',
  critical: '#dc3545',
  success: '#2ab06f',
  info: '#1496ff',
};

export const DT_PALETTE = [
  DT_COLORS.primary,
  DT_COLORS.purple,
  DT_COLORS.teal,
  DT_COLORS.green,
  DT_COLORS.amber,
  DT_COLORS.red,
  DT_COLORS.cyan,
  DT_COLORS.lavender,
  DT_COLORS.orange,
  DT_COLORS.indigo,
];

export const DT_GRID_PROPS = {
  strokeDasharray: "2 6",
  stroke: "hsl(var(--muted-foreground))",
  opacity: 0.15,
};

export const DT_AXIS_PROPS = {
  tick: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' },
  axisLine: { stroke: 'hsl(var(--border))', strokeWidth: 1 },
  tickLine: false as const,
  minTickGap: 30,
};

export const DT_CURSOR_PROPS = {
  stroke: 'hsl(var(--muted-foreground))',
  strokeWidth: 1,
  strokeDasharray: '3 3',
  opacity: 0.6,
};

export const DT_TOOLTIP_STYLE = {
  backgroundColor: 'hsl(var(--card))',
  border: '1px solid hsl(var(--border))',
  borderRadius: '6px',
  boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
};

export function DynatraceGradients() {
  return (
    <defs>
      <linearGradient id="dt-grad-primary" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={DT_COLORS.primary} stopOpacity={0.25} />
        <stop offset="100%" stopColor={DT_COLORS.primary} stopOpacity={0.02} />
      </linearGradient>
      <linearGradient id="dt-grad-purple" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={DT_COLORS.purple} stopOpacity={0.25} />
        <stop offset="100%" stopColor={DT_COLORS.purple} stopOpacity={0.02} />
      </linearGradient>
      <linearGradient id="dt-grad-teal" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={DT_COLORS.teal} stopOpacity={0.25} />
        <stop offset="100%" stopColor={DT_COLORS.teal} stopOpacity={0.02} />
      </linearGradient>
      <linearGradient id="dt-grad-green" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={DT_COLORS.green} stopOpacity={0.25} />
        <stop offset="100%" stopColor={DT_COLORS.green} stopOpacity={0.02} />
      </linearGradient>
      <linearGradient id="dt-grad-amber" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={DT_COLORS.amber} stopOpacity={0.25} />
        <stop offset="100%" stopColor={DT_COLORS.amber} stopOpacity={0.02} />
      </linearGradient>
      <linearGradient id="dt-grad-red" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={DT_COLORS.red} stopOpacity={0.3} />
        <stop offset="100%" stopColor={DT_COLORS.red} stopOpacity={0.02} />
      </linearGradient>
      <linearGradient id="dt-grad-cyan" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={DT_COLORS.cyan} stopOpacity={0.25} />
        <stop offset="100%" stopColor={DT_COLORS.cyan} stopOpacity={0.02} />
      </linearGradient>
      <linearGradient id="dt-grad-orange" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={DT_COLORS.orange} stopOpacity={0.25} />
        <stop offset="100%" stopColor={DT_COLORS.orange} stopOpacity={0.02} />
      </linearGradient>
      <linearGradient id="dt-grad-lavender" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={DT_COLORS.lavender} stopOpacity={0.25} />
        <stop offset="100%" stopColor={DT_COLORS.lavender} stopOpacity={0.02} />
      </linearGradient>

      <linearGradient id="dt-band-fill" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={DT_COLORS.primary} stopOpacity={0.12} />
        <stop offset="100%" stopColor={DT_COLORS.primary} stopOpacity={0.04} />
      </linearGradient>
    </defs>
  );
}

export function useLegendToggle() {
  const [hiddenSeries, setHiddenSeries] = useState<Set<string>>(new Set());

  const toggleSeries = useCallback((key: string) => {
    setHiddenSeries(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }, []);

  const isVisible = useCallback((key: string) => !hiddenSeries.has(key), [hiddenSeries]);

  return { hiddenSeries, toggleSeries, isVisible };
}

interface LegendItem {
  key: string;
  label: string;
  color: string;
  dashed?: boolean;
}

export function DtLegend({ items, hiddenSeries, onToggle }: {
  items: LegendItem[];
  hiddenSeries: Set<string>;
  onToggle: (key: string) => void;
}) {
  return (
    <div className="flex items-center justify-center gap-3 flex-wrap px-2 pt-1 pb-0.5">
      {items.map((item) => {
        const hidden = hiddenSeries.has(item.key);
        return (
          <button
            key={item.key}
            type="button"
            className="flex items-center gap-1.5 text-[10px] cursor-pointer select-none transition-opacity hover:opacity-80"
            style={{ opacity: hidden ? 0.35 : 1 }}
            onClick={() => onToggle(item.key)}
          >
            <span
              className="inline-block w-3 flex-shrink-0"
              style={{
                height: item.dashed ? 0 : 3,
                backgroundColor: item.dashed ? 'transparent' : item.color,
                borderTop: item.dashed ? `2px dashed ${item.color}` : undefined,
                borderRadius: item.dashed ? 0 : 9999,
              }}
            />
            <span className="text-muted-foreground whitespace-nowrap">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
}
