import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  FileCode,
  Activity,
  CalendarDays,
  BarChart3,
  TrendingUp,
  Database,
  ClipboardList,
  Scale,
  Plus,
  Upload,
  Play,
} from "lucide-react";

interface EmptyStateProps {
  icon?: any;
  title: string;
  description: string;
  actionLabel?: string;
  actionHref?: string;
  actionIcon?: any;
  onAction?: () => void;
  secondaryLabel?: string;
  secondaryHref?: string;
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  actionLabel,
  actionHref,
  actionIcon: ActionIcon = Plus,
  onAction,
  secondaryLabel,
  secondaryHref,
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 sm:py-20 px-4 text-center">
      {Icon && (
        <div className="mb-6 relative">
          <div className="absolute inset-0 bg-primary/5 rounded-full scale-150 blur-xl" />
          <div className="relative p-5 rounded-2xl bg-muted/50 border border-border/50">
            <Icon className="h-10 w-10 sm:h-12 sm:w-12 text-muted-foreground/40" />
          </div>
        </div>
      )}
      <h3 className="text-lg sm:text-xl font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-sm sm:text-base text-muted-foreground max-w-md mb-6 leading-relaxed">{description}</p>
      <div className="flex flex-wrap items-center justify-center gap-3">
        {actionLabel && (actionHref || onAction) && (
          actionHref ? (
            <Link href={actionHref}>
              <Button size="lg" className="btn-primary-glow">
                <ActionIcon className="h-4 w-4 mr-2" />
                {actionLabel}
              </Button>
            </Link>
          ) : (
            <Button size="lg" className="btn-primary-glow" onClick={onAction}>
              <ActionIcon className="h-4 w-4 mr-2" />
              {actionLabel}
            </Button>
          )
        )}
        {secondaryLabel && secondaryHref && (
          <Link href={secondaryHref}>
            <Button variant="outline" size="lg">
              {secondaryLabel}
            </Button>
          </Link>
        )}
      </div>
    </div>
  );
}

export const emptyStates = {
  scripts: {
    icon: FileCode,
    title: "No scripts yet",
    description: "Upload your first JMeter test script to get started with performance testing.",
    actionLabel: "Upload Script",
    actionIcon: Upload,
    actionHref: "/scripts",
  },
  executions: {
    icon: Activity,
    title: "No test executions",
    description: "Run your first performance test to see execution results and metrics here.",
    actionLabel: "Go to Scripts",
    actionIcon: Play,
    actionHref: "/scripts",
  },
  schedules: {
    icon: CalendarDays,
    title: "No schedules created",
    description: "Create a test schedule to automate your performance test runs.",
    actionLabel: "Create Schedule",
    actionIcon: Plus,
  },
  reports: {
    icon: BarChart3,
    title: "No reports available",
    description: "Complete a test execution to generate performance reports with detailed metrics.",
    actionLabel: "View Executions",
    actionIcon: Activity,
    actionHref: "/executions",
  },
  trends: {
    icon: TrendingUp,
    title: "No trend data",
    description: "Run multiple test executions to see performance trends over time.",
    actionLabel: "Start a Test",
    actionIcon: Play,
    actionHref: "/scripts",
  },
  comparison: {
    icon: Scale,
    title: "No data to compare",
    description: "Complete at least two test executions to compare their performance side by side.",
    actionLabel: "View Executions",
    actionIcon: Activity,
    actionHref: "/executions",
  },
  tracker: {
    icon: ClipboardList,
    title: "No tracked tests",
    description: "Test execution data will appear here as tests are completed.",
    actionLabel: "Go to Scripts",
    actionIcon: FileCode,
    actionHref: "/scripts",
  },
  dumps: {
    icon: Database,
    title: "No dump files",
    description: "Upload thread dumps or heap dumps to analyze application performance issues.",
    actionLabel: "Upload Dump",
    actionIcon: Upload,
  },
};
