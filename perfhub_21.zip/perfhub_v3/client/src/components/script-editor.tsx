import { useState, useRef, useCallback, useEffect } from "react";
import Editor, { OnMount, Monaco } from "@monaco-editor/react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Loader2, Save, Maximize2, Minimize2, AlertTriangle, CheckCircle } from "lucide-react";

interface ScriptEditorProps {
  scriptId: number;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ScriptEditor({ scriptId, open, onOpenChange }: ScriptEditorProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const editorRef = useRef<any>(null);
  const [currentContent, setCurrentContent] = useState<string>("");
  const [originalContent, setOriginalContent] = useState<string>("");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [xmlError, setXmlError] = useState<string | null>(null);
  const [showCloseConfirm, setShowCloseConfirm] = useState(false);

  const isReadOnly = user?.role !== "admin" && user?.role !== "engineer" && user?.role !== "lead";
  const hasUnsavedChanges = currentContent !== originalContent;

  const { data, isLoading, error } = useQuery<{ content: string; fileName: string }>({
    queryKey: ["script-content", scriptId],
    queryFn: async () => {
      const res = await fetch(`/api/scripts/${scriptId}/content`, { credentials: "include" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Failed to load script" }));
        throw new Error(err.message);
      }
      return res.json();
    },
    enabled: open,
    staleTime: 0,
    gcTime: 0,
  });

  useEffect(() => {
    if (data?.content) {
      setCurrentContent(data.content);
      setOriginalContent(data.content);
      setXmlError(null);
    }
  }, [data?.content]);

  useEffect(() => {
    if (!open) {
      setCurrentContent("");
      setOriginalContent("");
      setXmlError(null);
      setIsFullscreen(false);
    }
  }, [open]);

  const saveMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await fetch(`/api/scripts/${scriptId}/content`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" },
        credentials: "include",
        body: JSON.stringify({ content }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Failed to save" }));
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: () => {
      setOriginalContent(currentContent);
      queryClient.invalidateQueries({ queryKey: ["script-content", scriptId] });
      toast({ title: "Script saved successfully" });
    },
    onError: (err: Error) => {
      toast({ title: "Save failed", description: err.message, variant: "destructive" });
    },
  });

  const validateXml = useCallback((xml: string): string | null => {
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(xml, "text/xml");
      const parseError = doc.querySelector("parsererror");
      if (parseError) {
        const errorText = parseError.textContent || "Invalid XML";
        const match = errorText.match(/line (\d+)/i);
        return match ? `XML error at line ${match[1]}` : "Invalid XML structure";
      }
      return null;
    } catch {
      return "XML parsing failed";
    }
  }, []);

  const handleEditorChange = useCallback((value: string | undefined) => {
    const val = value || "";
    setCurrentContent(val);
    if (val.trim()) {
      setXmlError(validateXml(val));
    } else {
      setXmlError(null);
    }
  }, [validateXml]);

  const handleSave = useCallback(() => {
    const error = validateXml(currentContent);
    if (error) {
      setXmlError(error);
      toast({ title: "Cannot save", description: error, variant: "destructive" });
      return;
    }
    saveMutation.mutate(currentContent);
  }, [currentContent, validateXml, saveMutation, toast]);

  const monacoRef = useRef<Monaco | null>(null);

  const handleEditorMount: OnMount = useCallback((editor, monaco) => {
    editorRef.current = editor;
    monacoRef.current = monaco;
    editor.addCommand(
      monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS,
      () => handleSave()
    );
  }, [handleSave]);

  const handleClose = useCallback(() => {
    if (hasUnsavedChanges) {
      setShowCloseConfirm(true);
    } else {
      onOpenChange(false);
    }
  }, [hasUnsavedChanges, onOpenChange]);

  const dialogHeight = isFullscreen ? "h-[95vh]" : "h-[70vh]";
  const dialogWidth = isFullscreen ? "max-w-[95vw]" : "max-w-5xl";

  return (
    <>
      <Dialog open={open} onOpenChange={(val) => { if (!val) handleClose(); else onOpenChange(val); }}>
        <DialogContent
          className={`${dialogWidth} ${dialogHeight} flex flex-col gap-0 p-0 overflow-hidden`}
          onPointerDownOutside={(e) => { if (hasUnsavedChanges) e.preventDefault(); }}
          onEscapeKeyDown={(e) => { if (hasUnsavedChanges) { e.preventDefault(); handleClose(); } }}
        >
          <div className="flex items-center justify-between px-6 py-4 border-b">
            <div>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {data?.fileName || "Script Editor"}
                  {isReadOnly && (
                    <span className="text-xs font-normal bg-muted px-2 py-0.5 rounded">Read Only</span>
                  )}
                </DialogTitle>
                <DialogDescription className="sr-only">
                  View and edit the JMeter JMX script file
                </DialogDescription>
              </DialogHeader>
            </div>
            <div className="flex items-center gap-2">
              {xmlError && (
                <div className="flex items-center gap-1.5 text-destructive text-xs mr-2">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span className="max-w-[200px] truncate">{xmlError}</span>
                </div>
              )}
              {!xmlError && currentContent.trim() && (
                <div className="flex items-center gap-1.5 text-emerald-600 text-xs mr-2">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Valid XML</span>
                </div>
              )}
              {hasUnsavedChanges && (
                <span className="text-xs text-amber-600 font-medium mr-1">Unsaved</span>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setIsFullscreen(!isFullscreen)}
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>
              {!isReadOnly && (
                <Button
                  size="sm"
                  onClick={handleSave}
                  disabled={!hasUnsavedChanges || !!xmlError || saveMutation.isPending}
                >
                  {saveMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-1.5" />
                  )}
                  Save
                </Button>
              )}
            </div>
          </div>

          <div className="flex-1 min-h-0">
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
              </div>
            ) : error ? (
              <div className="flex items-center justify-center h-full text-destructive">
                <AlertTriangle className="w-5 h-5 mr-2" />
                {(error as Error).message}
              </div>
            ) : (
              <Editor
                height="100%"
                language="xml"
                theme="vs-dark"
                value={currentContent}
                onChange={handleEditorChange}
                onMount={handleEditorMount}
                options={{
                  readOnly: isReadOnly,
                  minimap: { enabled: true },
                  fontSize: 13,
                  lineNumbers: "on",
                  folding: true,
                  bracketPairColorization: { enabled: true },
                  autoIndent: "full",
                  formatOnPaste: true,
                  wordWrap: "on",
                  scrollBeyondLastLine: false,
                  automaticLayout: true,
                  tabSize: 2,
                }}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showCloseConfirm} onOpenChange={setShowCloseConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Unsaved Changes</AlertDialogTitle>
            <AlertDialogDescription>
              You have unsaved changes. Are you sure you want to close the editor? Your changes will be lost.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep Editing</AlertDialogCancel>
            <AlertDialogAction onClick={() => { setShowCloseConfirm(false); onOpenChange(false); }}>
              Discard Changes
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
