import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Target, Save, Trash2, Loader2, FileText, Pencil, ArrowLeft } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface WorkloadTargetsData {
  threads?: number | null;
  tph?: number | null;
  tps?: number | null;
}

interface TargetsResponse {
  source: "execution" | "script" | null;
  targets: WorkloadTargetsData | null;
  scriptName?: string;
  scriptId?: number;
}

interface Props {
  executionId: number;
  executionName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ExecutionWorkloadTargetsDialog({ executionId, executionName, open, onOpenChange }: Props) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editMode, setEditMode] = useState(false);

  const [threads, setThreads] = useState("");
  const [tph, setTph] = useState("");
  const [tps, setTps] = useState("");

  const { data: existing, isLoading } = useQuery<TargetsResponse>({
    queryKey: [`/api/executions/${executionId}/workload-targets`],
    queryFn: async () => {
      const res = await fetch(`/api/executions/${executionId}/workload-targets`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch targets");
      return res.json();
    },
    enabled: open,
  });

  useEffect(() => {
    if (!open) {
      setEditMode(false);
    }
  }, [open]);

  useEffect(() => {
    if (existing?.targets) {
      const t = existing.targets;
      setThreads(t.threads ? String(t.threads) : "");
      setTph(t.tph ? String(t.tph) : "");
      setTps(t.tps ? String(t.tps) : "");
    }
  }, [existing]);

  const saveMutation = useMutation({
    mutationFn: async (data: Record<string, any>) => {
      const res = await fetch(`/api/executions/${executionId}/workload-targets`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to save targets");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/executions/${executionId}/workload-targets`] });
      queryClient.invalidateQueries({ queryKey: ["workload-achievement", executionId] });
      toast({ title: "Workload targets saved" });
      setEditMode(false);
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/executions/${executionId}/workload-targets`, {
        method: "DELETE",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete targets");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/executions/${executionId}/workload-targets`] });
      queryClient.invalidateQueries({ queryKey: ["workload-achievement", executionId] });
      setThreads(""); setTph(""); setTps("");
      toast({ title: "Workload targets removed" });
      setEditMode(false);
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const handleSave = () => {
    const threadsVal = threads ? parseInt(threads) : undefined;
    const tphVal = tph ? parseFloat(tph) : undefined;
    const tpsVal = tps ? parseFloat(tps) : undefined;
    if (!threadsVal && !tphVal) {
      toast({ title: "Validation", description: "At least Threads or TPH is required", variant: "destructive" });
      return;
    }
    saveMutation.mutate({
      threads: threadsVal,
      tph: tphVal,
      tps: tpsVal,
    });
  };

  const hasTargets = existing?.targets && (existing.targets.threads || existing.targets.tph);
  const showSummary = hasTargets && !editMode;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Workload Targets
          </DialogTitle>
          <DialogDescription>
            {showSummary
              ? <>Validation targets for <strong>{executionName}</strong>. After test completion, actual Threads and TPH/TPS are compared against these targets.</>
              : <>Set Threads and TPH/TPS targets for <strong>{executionName}</strong> to validate after completion.</>
            }
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-6">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : showSummary ? (
          <div className="space-y-4">
            {existing?.source === "script" && existing.scriptName && (
              <div className="flex items-center gap-2 bg-primary/5 border border-primary/10 rounded-lg p-3">
                <FileText className="w-4 h-4 text-primary flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{existing.scriptName}</p>
                  <p className="text-xs text-muted-foreground">From Workload Model Calculator</p>
                </div>
                <Badge variant="outline" className="text-xs flex-shrink-0">Script</Badge>
              </div>
            )}

            {existing?.source === "execution" && (
              <Badge variant="outline" className="text-xs">Execution-level override</Badge>
            )}

            <div className="space-y-2">
              {existing?.targets?.threads != null && (
                <div className="flex items-center justify-between py-2.5 px-4 rounded-lg bg-muted/40">
                  <span className="text-sm text-muted-foreground">Threads</span>
                  <span className="text-lg font-bold tabular-nums">{existing.targets.threads.toLocaleString()}</span>
                </div>
              )}
              {existing?.targets?.tph != null && (
                <div className="flex items-center justify-between py-2.5 px-4 rounded-lg bg-muted/40">
                  <span className="text-sm text-muted-foreground">TPH</span>
                  <span className="text-lg font-bold tabular-nums">
                    {existing.targets.tph.toLocaleString()}
                    <span className="text-xs font-normal text-muted-foreground ml-1">txn/hr</span>
                  </span>
                </div>
              )}
              {existing?.targets?.tps != null && (
                <div className="flex items-center justify-between py-2.5 px-4 rounded-lg bg-muted/40">
                  <span className="text-sm text-muted-foreground">TPS</span>
                  <span className="text-lg font-bold tabular-nums">
                    {existing.targets.tps.toLocaleString()}
                    <span className="text-xs font-normal text-muted-foreground ml-1">txn/sec</span>
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-2 border-t">
              <div>
                {existing?.source === "execution" && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={() => deleteMutation.mutate()}
                    disabled={deleteMutation.isPending}
                  >
                    {deleteMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Trash2 className="w-4 h-4 mr-1" />}
                    Remove
                  </Button>
                )}
              </div>
              <Button variant="outline" size="sm" onClick={() => setEditMode(true)}>
                <Pencil className="w-4 h-4 mr-1" />
                {existing?.source === "script" ? "Override" : "Edit"}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {editMode && hasTargets && (
              <Button variant="ghost" size="sm" className="text-muted-foreground -mt-2" onClick={() => setEditMode(false)}>
                <ArrowLeft className="w-4 h-4 mr-1" />
                Back
              </Button>
            )}

            {existing?.source === "script" && editMode && (
              <div className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-2">
                Saving here creates an execution-level override for this run only.
              </div>
            )}

            <div className="space-y-3">
              <div>
                <Label className="text-xs font-medium">Threads</Label>
                <Input
                  type="number"
                  min={1}
                  placeholder="e.g. 50"
                  value={threads}
                  onChange={(e) => setThreads(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-xs font-medium">TPH (Transactions per Hour)</Label>
                <Input
                  type="number"
                  min={1}
                  placeholder="e.g. 18000"
                  value={tph}
                  onChange={(e) => setTph(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-xs font-medium">TPS (Transactions per Second)</Label>
                <Input
                  type="number"
                  min={0}
                  step="0.01"
                  placeholder="e.g. 5.0"
                  value={tps}
                  onChange={(e) => setTps(e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t">
              <div>
                {existing?.source === "execution" && !editMode && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={() => deleteMutation.mutate()}
                    disabled={deleteMutation.isPending}
                  >
                    {deleteMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Trash2 className="w-4 h-4 mr-1" />}
                    Remove
                  </Button>
                )}
              </div>
              <Button onClick={handleSave} disabled={saveMutation.isPending}>
                {saveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Save className="w-4 h-4 mr-1" />}
                Save Targets
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
