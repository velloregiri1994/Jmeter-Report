import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  FileCode,
  Activity,
  LayoutDashboard,
  CalendarDays,
  Scale,
  TrendingUp,
  FileText,
  ClipboardList,
  Database,
  Settings,
  Search,
  Mail,
  Users,
  Network,
  Archive,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from "@/components/ui/dialog";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
import { queryKeys } from "@/lib/query-keys";
import { useAuth } from "@/hooks/use-auth";

interface SearchResult {
  id: string;
  label: string;
  description?: string;
  href: string;
  icon: any;
  category: string;
}

const pages: SearchResult[] = [
  { id: "dashboard", label: "Dashboard", href: "/", icon: LayoutDashboard, category: "Pages" },
  { id: "scripts", label: "Script Repository", href: "/scripts", icon: FileCode, category: "Pages" },
  { id: "schedule", label: "Test Schedule", href: "/schedule", icon: CalendarDays, category: "Pages" },
  { id: "executions", label: "Executions", href: "/executions", icon: Activity, category: "Pages" },
  { id: "comparison", label: "Comparison", href: "/comparison", icon: Scale, category: "Pages" },
  { id: "trends", label: "Trends", href: "/trends", icon: TrendingUp, category: "Pages" },
  { id: "reports", label: "HTML Reports", href: "/reports", icon: FileText, category: "Pages" },
  { id: "tracker", label: "Tracker", href: "/tracker", icon: ClipboardList, category: "Pages" },
  { id: "dumps", label: "Dump Analyzer", href: "/dumps", icon: Database, category: "Pages" },
  { id: "platform-general", label: "General Settings", href: "/platform/general", icon: Mail, category: "Platform Settings" },
  { id: "platform-distributed", label: "Distributed Testing", href: "/platform/distributed", icon: Network, category: "Platform Settings" },
  { id: "platform-users", label: "User Management", href: "/platform/users", icon: Users, category: "Admin" },
  { id: "platform-retention", label: "Data Retention", href: "/platform/retention", icon: Archive, category: "Admin" },
];

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [, setLocation] = useLocation();
  const [selectedIndex, setSelectedIndex] = useState(0);
  const { isAdmin } = useAuth();

  const { data: scripts = [] } = useQuery<any[]>({
    queryKey: [...queryKeys.scripts.all],
    queryFn: async () => {
      const res = await fetch("/api/scripts", { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    staleTime: 30000,
  });

  const { data: executionsResponse } = useQuery<any>({
    queryKey: [...queryKeys.executions.all, { limit: 20 }],
    queryFn: async () => {
      const res = await fetch("/api/executions?limit=20", { credentials: "include" });
      if (!res.ok) return { data: [] };
      return res.json();
    },
    staleTime: 30000,
  });

  const executions = executionsResponse?.data || [];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen(prev => !prev);
        setQuery("");
        setSelectedIndex(0);
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  const getFilteredResults = useCallback((): SearchResult[] => {
    const q = query.toLowerCase().trim();
    const results: SearchResult[] = [];

    const filteredPages = pages.filter(p => {
      if (p.category === "Admin" && !isAdmin) return false;
      return p.label.toLowerCase().includes(q) || p.category.toLowerCase().includes(q);
    });
    results.push(...filteredPages);

    const filteredScripts = scripts
      .filter((s: any) => s.name?.toLowerCase().includes(q) || !q)
      .slice(0, 5)
      .map((s: any) => ({
        id: `script-${s.id}`,
        label: s.name,
        description: s.toolType,
        href: `/scripts/${s.id}`,
        icon: FileCode,
        category: "Scripts",
      }));
    results.push(...filteredScripts);

    const filteredExecs = executions
      .filter((e: any) => {
        const name = e.schedule?.name || e.executionId || "";
        return name.toLowerCase().includes(q) || e.executionId?.toLowerCase().includes(q) || !q;
      })
      .slice(0, 5)
      .map((e: any) => ({
        id: `exec-${e.id}`,
        label: e.schedule?.name || e.executionId,
        description: e.status,
        href: `/executions/${e.id}`,
        icon: Activity,
        category: "Executions",
      }));
    results.push(...filteredExecs);

    return results;
  }, [query, scripts, executions]);

  const results = getFilteredResults();

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  const handleSelect = (result: SearchResult) => {
    setOpen(false);
    setQuery("");
    setLocation(result.href);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex(prev => Math.min(prev + 1, results.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex(prev => Math.max(prev - 1, 0));
    } else if (e.key === "Enter" && results[selectedIndex]) {
      e.preventDefault();
      handleSelect(results[selectedIndex]);
    }
  };

  const groupedResults = results.reduce<Record<string, SearchResult[]>>((acc, r) => {
    if (!acc[r.category]) acc[r.category] = [];
    acc[r.category].push(r);
    return acc;
  }, {});

  let flatIndex = 0;

  return (
    <>
      <button
        onClick={() => { setOpen(true); setQuery(""); setSelectedIndex(0); }}
        className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border bg-muted/50 text-muted-foreground text-sm hover:bg-muted hover:text-foreground transition-colors"
        aria-label="Search"
      >
        <Search className="h-4 w-4" />
        <span>Search...</span>
        <kbd className="hidden xl:inline-flex h-5 items-center gap-0.5 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
          <span className="text-xs">&#8984;</span>K
        </kbd>
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[550px] p-0 gap-0 overflow-hidden">
          <VisuallyHidden><DialogTitle>Search</DialogTitle></VisuallyHidden>
          <div className="flex items-center border-b px-4" role="search">
            <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Search pages, scripts, executions..."
              className="flex-1 h-12 bg-transparent px-3 text-sm outline-none placeholder:text-muted-foreground"
            />
            <kbd className="hidden sm:inline-flex h-5 items-center rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
              ESC
            </kbd>
          </div>

          <div className="max-h-[350px] overflow-y-auto p-2" role="listbox">
            {results.length === 0 ? (
              <div className="py-8 text-center text-sm text-muted-foreground">
                No results found for "{query}"
              </div>
            ) : (
              Object.entries(groupedResults).map(([category, items]) => (
                <div key={category} className="mb-2">
                  <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    {category}
                  </div>
                  {items.map((result) => {
                    const currentIndex = flatIndex++;
                    const isSelected = currentIndex === selectedIndex;
                    return (
                      <button
                        key={result.id}
                        onClick={() => handleSelect(result)}
                        onMouseEnter={() => setSelectedIndex(currentIndex)}
                        role="option"
                        aria-selected={isSelected}
                        className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm transition-colors text-left ${
                          isSelected
                            ? "bg-primary/10 text-primary"
                            : "text-foreground hover:bg-muted"
                        }`}
                      >
                        <result.icon className={`h-4 w-4 shrink-0 ${isSelected ? "text-primary" : "text-muted-foreground"}`} />
                        <div className="flex-1 min-w-0">
                          <span className="font-medium truncate block">{result.label}</span>
                          {result.description && (
                            <span className="text-xs text-muted-foreground truncate block">{result.description}</span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
