import { useState } from "react";
import { copyToClipboard } from "@/lib/clipboard";
import {
  AlertTriangle,
  AlertCircle,
  Info,
  XOctagon,
  RefreshCw,
  Home,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
  LogIn,
  Shield,
  ArrowLeft,
  Settings,
  RotateCcw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { ErrorSeverity, SuggestedAction } from "@/lib/queryClient";

interface ErrorDisplayProps {
  severity?: ErrorSeverity;
  title?: string;
  message: string;
  errorId?: string;
  correlationId?: string;
  code?: string;
  details?: string;
  action?: SuggestedAction;
  timestamp?: string;
  onRetry?: () => void;
  onGoHome?: () => void;
  compact?: boolean;
}

const severityConfig: Record<ErrorSeverity, { icon: typeof AlertTriangle; bg: string; border: string; text: string; badge: string; label: string }> = {
  info: {
    icon: Info,
    bg: "bg-blue-500/10",
    border: "border-blue-500/30",
    text: "text-blue-500",
    badge: "bg-blue-500/15 text-blue-600 dark:text-blue-400",
    label: "Info",
  },
  warning: {
    icon: AlertTriangle,
    bg: "bg-amber-500/10",
    border: "border-amber-500/30",
    text: "text-amber-500",
    badge: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
    label: "Warning",
  },
  error: {
    icon: AlertCircle,
    bg: "bg-destructive/10",
    border: "border-destructive/30",
    text: "text-destructive",
    badge: "bg-destructive/15 text-destructive",
    label: "Error",
  },
  critical: {
    icon: XOctagon,
    bg: "bg-red-600/10",
    border: "border-red-600/30",
    text: "text-red-600",
    badge: "bg-red-600/15 text-red-600 dark:text-red-400",
    label: "Critical",
  },
};

const actionConfig: Record<SuggestedAction, { icon: typeof RefreshCw; label: string }> = {
  retry: { icon: RefreshCw, label: "Try Again" },
  contact_admin: { icon: Shield, label: "Contact Admin" },
  check_config: { icon: Settings, label: "Check Configuration" },
  login: { icon: LogIn, label: "Sign In" },
  check_permissions: { icon: Shield, label: "Request Access" },
  go_back: { icon: ArrowLeft, label: "Go Back" },
  refresh: { icon: RotateCcw, label: "Refresh Page" },
};

export function ErrorDisplay({
  severity = "error",
  title,
  message,
  errorId,
  correlationId,
  code,
  details,
  action = "retry",
  timestamp,
  onRetry,
  onGoHome,
  compact = false,
}: ErrorDisplayProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [copied, setCopied] = useState(false);

  const sev = severityConfig[severity];
  const Icon = sev.icon;
  const act = actionConfig[action];
  const ActionIcon = act.icon;

  const handleCopyErrorId = async () => {
    if (errorId) {
      await copyToClipboard(errorId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleAction = () => {
    if (action === "login") {
      window.location.href = "/";
    } else if (action === "go_back") {
      window.history.back();
    } else if (action === "refresh") {
      window.location.reload();
    } else if (onRetry) {
      onRetry();
    }
  };

  const hasDetails = details || code || correlationId || timestamp;

  if (compact) {
    return (
      <div className={cn("flex items-start gap-3 p-4 rounded-lg border", sev.bg, sev.border)}>
        <Icon className={cn("h-5 w-5 mt-0.5 shrink-0", sev.text)} />
        <div className="flex-1 min-w-0 space-y-1">
          <p className="text-sm font-medium">{message}</p>
          {errorId && (
            <p className="text-xs text-muted-foreground font-mono">
              Ref: {errorId}
            </p>
          )}
        </div>
        {onRetry && (
          <Button size="sm" variant="ghost" onClick={handleAction} className="shrink-0">
            <ActionIcon className="h-3.5 w-3.5 mr-1.5" />
            {act.label}
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className={cn("min-h-[300px] flex items-center justify-center p-6", compact && "min-h-0")}>
      <Card className="max-w-lg w-full shadow-lg">
        <CardHeader className="text-center pb-2">
          <div className={cn("mx-auto mb-3 p-3 rounded-full w-fit", sev.bg)}>
            <Icon className={cn("h-8 w-8", sev.text)} />
          </div>
          <div className="flex items-center justify-center gap-2 mb-1">
            <span className={cn("text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full", sev.badge)}>
              {sev.label}
            </span>
          </div>
          <h3 className="text-lg font-semibold mt-1">
            {title || getDefaultTitle(severity)}
          </h3>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground text-center text-sm leading-relaxed">
            {message}
          </p>

          {errorId && (
            <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
              <span className="font-mono bg-muted px-2 py-1 rounded">
                {errorId}
              </span>
              <button
                onClick={handleCopyErrorId}
                className="p-1 hover:bg-muted rounded transition-colors"
                title="Copy error reference"
              >
                {copied ? (
                  <Check className="h-3.5 w-3.5 text-green-500" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
              </button>
            </div>
          )}

          {hasDetails && (
            <div>
              <button
                onClick={() => setShowDetails(!showDetails)}
                className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors mx-auto"
              >
                {showDetails ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
                Technical Details
              </button>

              {showDetails && (
                <div className="mt-3 p-3 bg-muted/50 rounded-lg border text-xs space-y-1.5 font-mono">
                  {code && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Code</span>
                      <span>{code}</span>
                    </div>
                  )}
                  {correlationId && correlationId !== "unknown" && correlationId !== "network" && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Correlation</span>
                      <span className="truncate ml-2">{correlationId}</span>
                    </div>
                  )}
                  {timestamp && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Time</span>
                      <span>{new Date(timestamp).toLocaleString()}</span>
                    </div>
                  )}
                  {details && (
                    <div className="pt-1.5 border-t">
                      <span className="text-muted-foreground block mb-1">Details</span>
                      <p className="break-all whitespace-pre-wrap text-[11px]">{details}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          <div className="flex gap-3 justify-center pt-1">
            <Button onClick={handleAction} size="sm">
              <ActionIcon className="h-4 w-4 mr-2" />
              {act.label}
            </Button>
            {onGoHome && action !== "go_back" && (
              <Button onClick={onGoHome} variant="outline" size="sm">
                <Home className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function getDefaultTitle(severity: ErrorSeverity): string {
  switch (severity) {
    case "info": return "Heads Up";
    case "warning": return "Warning";
    case "error": return "Something Went Wrong";
    case "critical": return "Service Unavailable";
  }
}
