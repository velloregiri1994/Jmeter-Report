import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Loader2, Save, Settings2, AlertTriangle, Users, Gauge } from "lucide-react";
import { LoadPreview } from "@/components/load-preview";

interface SchemaField {
  key: string;
  label: string;
  type: "number" | "text" | "boolean" | "select";
  required?: boolean;
  min?: number;
  max?: number;
  step?: number;
  options?: { value: string; label: string }[];
  defaultValue?: any;
  group?: string;
  helpText?: string;
  visibleWhen?: { field: string; value: any };
}

interface ThreadGroupInfo {
  index: number;
  name: string;
  type: string;
  typeLabel: string;
  enabled: boolean;
  adapterType: string;
  schema: { fields: SchemaField[] };
  values: Record<string, any>;
}

interface TimerData {
  index: number;
  name: string;
  enabled: boolean;
  throughput: number;
  calcMode: number;
}

interface QuickConfigProps {
  scriptId: number;
  hasFile: boolean;
  embedded?: boolean;
}

const CALC_MODE_OPTIONS = [
  { value: 0, label: "This Thread Only" },
  { value: 1, label: "All Active Threads" },
  { value: 2, label: "All Threads in Current Thread Group" },
  { value: 3, label: "All Threads in Thread Group (shared)" },
  { value: 4, label: "All Active Threads (shared)" },
  { value: 5, label: "All Threads in Thread Group (shared)" },
];

function SchemaFieldRenderer({
  field,
  value,
  onChange,
  disabled,
  allValues,
}: {
  field: SchemaField;
  value: any;
  onChange: (value: any) => void;
  disabled: boolean;
  allValues: Record<string, any>;
}) {
  if (field.visibleWhen) {
    const depValue = allValues[field.visibleWhen.field];
    if (depValue !== field.visibleWhen.value) {
      return null;
    }
  }

  switch (field.type) {
    case "number":
      return (
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground uppercase tracking-wide">
            {field.label}
          </Label>
          <Input
            type="number"
            min={field.min}
            max={field.max}
            step={field.step || 1}
            value={value ?? field.defaultValue ?? ""}
            onChange={(e) => {
              const parsed = field.step && field.step < 1
                ? parseFloat(e.target.value)
                : parseInt(e.target.value, 10);
              onChange(isNaN(parsed) ? 0 : parsed);
            }}
            disabled={disabled}
          />
          {field.helpText && (
            <p className="text-xs text-muted-foreground">{field.helpText}</p>
          )}
        </div>
      );

    case "text":
      return (
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground uppercase tracking-wide">
            {field.label}
          </Label>
          <Input
            type="text"
            value={value ?? field.defaultValue ?? ""}
            onChange={(e) => onChange(e.target.value)}
            disabled={disabled}
          />
          {field.helpText && (
            <p className="text-xs text-muted-foreground">{field.helpText}</p>
          )}
        </div>
      );

    case "boolean":
      return (
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground uppercase tracking-wide">
            {field.label}
          </Label>
          <div className="flex items-center gap-3">
            <Switch
              checked={!!value}
              onCheckedChange={(checked) => onChange(checked)}
              disabled={disabled}
            />
            <span className="text-sm text-muted-foreground">
              {value ? "Enabled" : "Disabled"}
            </span>
          </div>
          {field.helpText && (
            <p className="text-xs text-muted-foreground">{field.helpText}</p>
          )}
        </div>
      );

    case "select":
      return (
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground uppercase tracking-wide">
            {field.label}
          </Label>
          <Select
            value={String(value ?? field.defaultValue ?? "")}
            onValueChange={(v) => onChange(v)}
            disabled={disabled}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {field.helpText && (
            <p className="text-xs text-muted-foreground">{field.helpText}</p>
          )}
        </div>
      );

    default:
      return null;
  }
}

export function QuickConfig({ scriptId, hasFile, embedded }: QuickConfigProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isReadOnly = user?.role !== "admin" && user?.role !== "engineer" && user?.role !== "lead";

  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const [formValues, setFormValues] = useState<Record<string, any>>({});
  const [dirty, setDirty] = useState(false);

  const [selectedTimerIndex, setSelectedTimerIndex] = useState<number>(0);
  const [timerForm, setTimerForm] = useState({
    throughput: 0,
    calcMode: 0,
    enabled: true,
  });
  const [timerDirty, setTimerDirty] = useState(false);

  const { data, isLoading, error } = useQuery<{ threadGroups: ThreadGroupInfo[]; testName: string }>({
    queryKey: ["thread-groups", scriptId],
    queryFn: async () => {
      const res = await fetch(`/api/scripts/${scriptId}/thread-groups`, { credentials: "include" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Failed to load" }));
        throw new Error(err.message);
      }
      return res.json();
    },
    enabled: hasFile,
  });

  const { data: timerData, isLoading: timerLoading } = useQuery<{ timers: TimerData[]; calcModeLabels: Record<string, string> }>({
    queryKey: ["timers", scriptId],
    queryFn: async () => {
      const res = await fetch(`/api/scripts/${scriptId}/timers`, { credentials: "include" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Failed to load" }));
        throw new Error(err.message);
      }
      return res.json();
    },
    enabled: hasFile,
  });

  const threadGroups = data?.threadGroups || [];
  const selectedTg = threadGroups.find(tg => tg.index === selectedIndex);
  const timers = timerData?.timers || [];
  const selectedTimer = timers.find(t => t.index === selectedTimerIndex);

  useEffect(() => {
    if (selectedTg) {
      setFormValues({ ...selectedTg.values });
      setDirty(false);
    }
  }, [selectedTg?.index, selectedTg?.adapterType, JSON.stringify(selectedTg?.values)]);

  useEffect(() => {
    if (threadGroups.length > 0 && !threadGroups.find(tg => tg.index === selectedIndex)) {
      setSelectedIndex(threadGroups[0].index);
    }
  }, [threadGroups, selectedIndex]);

  useEffect(() => {
    if (selectedTimer) {
      setTimerForm({
        throughput: selectedTimer.throughput,
        calcMode: selectedTimer.calcMode,
        enabled: selectedTimer.enabled,
      });
      setTimerDirty(false);
    }
  }, [selectedTimer?.index, selectedTimer?.throughput, selectedTimer?.calcMode, selectedTimer?.enabled]);

  useEffect(() => {
    if (timers.length > 0 && !timers.find(t => t.index === selectedTimerIndex)) {
      setSelectedTimerIndex(timers[0].index);
    }
  }, [timers, selectedTimerIndex]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/scripts/${scriptId}/thread-groups`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" },
        credentials: "include",
        body: JSON.stringify({ index: selectedIndex, values: formValues }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Failed to save" }));
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: () => {
      setDirty(false);
      queryClient.invalidateQueries({ queryKey: ["thread-groups", scriptId] });
      queryClient.invalidateQueries({ queryKey: ["script-content", scriptId] });
      toast({ title: "Configuration saved" });
    },
    onError: (err: Error) => {
      toast({ title: "Save failed", description: err.message, variant: "destructive" });
    },
  });

  const saveTimerMutation = useMutation({
    mutationFn: async () => {
      const update = {
        index: selectedTimerIndex,
        throughput: timerForm.throughput,
        calcMode: timerForm.calcMode,
        enabled: timerForm.enabled,
      };
      const res = await fetch(`/api/scripts/${scriptId}/timers`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" },
        credentials: "include",
        body: JSON.stringify({ updates: [update] }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Failed to save" }));
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: () => {
      setTimerDirty(false);
      queryClient.invalidateQueries({ queryKey: ["timers", scriptId] });
      queryClient.invalidateQueries({ queryKey: ["script-content", scriptId] });
      toast({ title: "Timer settings saved" });
    },
    onError: (err: Error) => {
      toast({ title: "Save failed", description: err.message, variant: "destructive" });
    },
  });

  const updateField = (key: string, value: any) => {
    setFormValues(prev => ({ ...prev, [key]: value }));
    setDirty(true);
  };

  const updateTimerField = (field: string, value: any) => {
    setTimerForm(prev => ({ ...prev, [field]: value }));
    setTimerDirty(true);
  };

  const validationErrors = useMemo(() => {
    if (!selectedTg) return [];
    const errors: string[] = [];
    const schema = selectedTg.schema;

    for (const field of schema.fields) {
      if (field.visibleWhen) {
        if (formValues[field.visibleWhen.field] !== field.visibleWhen.value) continue;
      }

      const val = formValues[field.key];

      if (field.required && (val === undefined || val === null || val === "")) {
        errors.push(`${field.label} is required`);
      }

      if (field.type === "number" && val !== undefined && val !== null) {
        if (field.min !== undefined && Number(val) < field.min) {
          errors.push(`${field.label} must be at least ${field.min}`);
        }
        if (field.max !== undefined && Number(val) > field.max) {
          errors.push(`${field.label} must be at most ${field.max}`);
        }
      }
    }

    if (formValues.schedulerEnabled && formValues.duration > 0 && formValues.rampUp > formValues.duration) {
      errors.push("Ramp-up exceeds duration (test may not reach full load)");
    }

    return errors;
  }, [formValues, selectedTg]);

  const hasErrors = validationErrors.filter(e => !e.includes("may not reach")).length > 0;

  const timerValidationErrors: string[] = [];
  if (timerForm.throughput <= 0) timerValidationErrors.push("Throughput must be greater than 0");
  if (timerForm.throughput > 0 && formValues.threads) {
    const rpsPerThread = timerForm.throughput / 60 / (formValues.threads || 1);
    if (rpsPerThread > 10) {
      timerValidationErrors.push(`High throughput: ~${rpsPerThread.toFixed(1)} req/sec per thread (may exceed capacity)`);
    }
  }
  const timerHasErrors = timerValidationErrors.filter(e => !e.includes("may exceed")).length > 0;

  const groupedFields = useMemo(() => {
    if (!selectedTg) return {};
    const groups: Record<string, SchemaField[]> = {};
    for (const field of selectedTg.schema.fields) {
      const group = field.group || "General";
      if (!groups[group]) groups[group] = [];
      groups[group].push(field);
    }
    return groups;
  }, [selectedTg]);

  if (!hasFile) return null;

  const content = (
    <>
      {isLoading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      ) : error ? (
        <div className="text-center py-6 text-muted-foreground">
          <AlertTriangle className="w-8 h-8 mx-auto mb-2 text-amber-500" />
          <p className="text-sm">{(error as Error).message}</p>
        </div>
      ) : threadGroups.length === 0 ? (
        <div className="text-center py-6 text-muted-foreground">
          <p className="text-sm">No thread groups found in this script.</p>
        </div>
      ) : (
        <div className="space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold flex items-center gap-1.5">
                <Users className="w-4 h-4" />
                Thread Group Settings
              </h3>
              {dirty && !isReadOnly && (
                <Button
                  size="sm"
                  onClick={() => saveMutation.mutate()}
                  disabled={hasErrors || saveMutation.isPending}
                >
                  {saveMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-1.5" />
                  )}
                  Save
                </Button>
              )}
            </div>

            {threadGroups.length > 1 ? (
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">Thread Group</Label>
                <Select value={String(selectedIndex)} onValueChange={(v) => setSelectedIndex(Number(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {threadGroups.map((tg) => (
                      <SelectItem key={tg.index} value={String(tg.index)}>
                        <span className="flex items-center gap-2">
                          {tg.name}
                          <Badge variant="outline" className="text-[10px] font-normal">{tg.typeLabel}</Badge>
                          {!tg.enabled && <Badge variant="secondary" className="text-[10px]">Disabled</Badge>}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <div className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                {threadGroups[0].name}
                <Badge variant="outline" className="text-[10px] font-normal">{threadGroups[0].typeLabel}</Badge>
                {!threadGroups[0].enabled && <Badge variant="secondary" className="text-[10px]">Disabled</Badge>}
              </div>
            )}

            {selectedTg && Object.entries(groupedFields).map(([groupName, fields]) => {
              const visibleFields = fields.filter(f => {
                if (!f.visibleWhen) return true;
                return formValues[f.visibleWhen.field] === f.visibleWhen.value;
              });
              if (visibleFields.length === 0) return null;

              return (
                <div key={groupName}>
                  {Object.keys(groupedFields).length > 1 && (
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">{groupName}</p>
                  )}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {fields.map((field) => (
                      <SchemaFieldRenderer
                        key={field.key}
                        field={field}
                        value={formValues[field.key]}
                        onChange={(val) => updateField(field.key, val)}
                        disabled={isReadOnly}
                        allValues={formValues}
                      />
                    ))}
                  </div>
                </div>
              );
            })}

            {validationErrors.length > 0 && (
              <div className="space-y-1.5">
                {validationErrors.map((err, i) => (
                  <div
                    key={i}
                    className={`flex items-center gap-1.5 text-xs ${err.includes("may not reach") ? "text-amber-600" : "text-destructive"}`}
                  >
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    {err}
                  </div>
                ))}
              </div>
            )}

            {selectedTg && formValues.threads > 0 && (
              <>
                <Separator />
                <LoadPreview
                  threads={Number(formValues.threads) || 0}
                  rampUp={Number(formValues.rampUp) || 0}
                  duration={Number(formValues.duration) || 0}
                  schedulerEnabled={!!formValues.schedulerEnabled}
                  loopCount={Number(formValues.loopCount) || 1}
                  loopForever={!!formValues.loopForever}
                  throughput={timerForm.enabled && timerForm.throughput > 0 ? timerForm.throughput : undefined}
                />
              </>
            )}

            {timers.length > 0 && (
              <>
                <Separator />
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold flex items-center gap-1.5">
                    <Gauge className="w-4 h-4" />
                    Throughput Timer
                  </h3>
                  {timerDirty && !isReadOnly && (
                    <Button
                      size="sm"
                      onClick={() => saveTimerMutation.mutate()}
                      disabled={timerHasErrors || saveTimerMutation.isPending}
                    >
                      {saveTimerMutation.isPending ? (
                        <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                      ) : (
                        <Save className="w-4 h-4 mr-1.5" />
                      )}
                      Save Timer
                    </Button>
                  )}
                </div>

                {timers.length > 1 && (
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground uppercase tracking-wide">Select Timer</Label>
                    <Select value={String(selectedTimerIndex)} onValueChange={(v) => setSelectedTimerIndex(Number(v))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {timers.map((t) => (
                          <SelectItem key={t.index} value={String(t.index)}>
                            <span className="flex items-center gap-2">
                              {t.name}
                              {!t.enabled && <Badge variant="secondary" className="text-[10px]">Disabled</Badge>}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {timers.length === 1 && (
                  <div className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    {timers[0].name}
                    {!timers[0].enabled && <Badge variant="secondary" className="text-[10px]">Disabled</Badge>}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="throughput" className="flex items-center gap-1.5 text-xs text-muted-foreground uppercase tracking-wide">
                      <Gauge className="w-3.5 h-3.5" />
                      Target Throughput (req/min)
                    </Label>
                    <Input
                      id="throughput"
                      type="number"
                      min={0.1}
                      step={0.1}
                      value={timerForm.throughput}
                      onChange={(e) => updateTimerField("throughput", parseFloat(e.target.value) || 0)}
                      disabled={isReadOnly}
                    />
                    {timerForm.throughput > 0 && (
                      <p className="text-xs text-muted-foreground">
                        = {(timerForm.throughput / 60).toFixed(2)} req/sec
                      </p>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <Label className="flex items-center gap-1.5 text-xs text-muted-foreground uppercase tracking-wide">
                      <Gauge className="w-3.5 h-3.5" />
                      Calculation Mode
                    </Label>
                    <Select
                      value={String(timerForm.calcMode)}
                      onValueChange={(v) => updateTimerField("calcMode", Number(v))}
                      disabled={isReadOnly}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {CALC_MODE_OPTIONS.map((opt) => (
                          <SelectItem key={opt.value} value={String(opt.value)}>
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-1.5">
                    <Label className="flex items-center gap-1.5 text-xs text-muted-foreground uppercase tracking-wide">
                      Enabled
                    </Label>
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={timerForm.enabled}
                        onCheckedChange={(checked) => updateTimerField("enabled", checked)}
                        disabled={isReadOnly}
                      />
                      <span className="text-sm text-muted-foreground">
                        {timerForm.enabled ? "Enabled" : "Disabled"}
                      </span>
                    </div>
                  </div>
                </div>

                {timerValidationErrors.length > 0 && (
                  <div className="space-y-1.5">
                    {timerValidationErrors.map((err, i) => (
                      <div
                        key={i}
                        className={`flex items-center gap-1.5 text-xs ${err.includes("may exceed") ? "text-amber-600" : "text-destructive"}`}
                      >
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        {err}
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            {isReadOnly && (
              <p className="text-xs text-muted-foreground">You have read-only access. Only admins and engineers can modify configurations.</p>
            )}
          </div>
        )}
    </>
  );

  if (embedded) {
    return content;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Settings2 className="w-5 h-5 text-primary" />
          <CardTitle>Quick Configuration</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        {content}
      </CardContent>
    </Card>
  );
}
