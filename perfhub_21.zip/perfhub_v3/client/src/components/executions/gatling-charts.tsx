import React, { useMemo } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import {
  BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, Cell, ComposedChart, Line,
  ScatterChart, Scatter, ZAxis, ReferenceLine,
} from "recharts";
import { BarChart2, Layers, Users, GitCompareArrows, TrendingUp, AlertCircle, Zap } from "lucide-react";
import { formatTimeseriesData as normalizeTimeseries } from "@/pages/executions/components/detail-utils";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS, DT_TOOLTIP_STYLE, DynatraceGradients } from "@/components/charts/dynatrace-theme";

const tooltipStyle = DT_TOOLTIP_STYLE;

function EmptyChart({ title, icon }: { title: string; icon: React.ReactNode }) {
  return (
    <Card className="card-shadow overflow-hidden">
      <CardHeader className="bg-muted/30 border-b py-2.5 px-4">
        <CardTitle className="flex items-center gap-2 text-sm">
          {icon}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <p className="text-sm text-muted-foreground text-center">No data available</p>
      </CardContent>
    </Card>
  );
}

export function LatencyStabilityChart({ timeseries, startTime }: { timeseries: any[]; startTime?: any }) {
  const data = useMemo(() => {
    if (!timeseries || timeseries.length === 0) return [];
    const normalized = normalizeTimeseries(timeseries, startTime);
    return normalized.map((p) => ({
      ...p,
      spread: Math.max(0, p.p95Ms - p.avgMs),
    }));
  }, [timeseries, startTime]);

  if (!data.length) return <EmptyChart title="Latency Stability (Avg vs P95)" icon={<Layers className="w-4 h-4 text-violet-500" />} />;

  const avgOfAvg = Math.round(data.reduce((s, d) => s + d.avgMs, 0) / data.length);
  const maxSpread = Math.max(...data.map(d => d.spread));
  const avgSpread = Math.round(data.reduce((s, d) => s + d.spread, 0) / data.length);

  return (
    <Card className="card-shadow overflow-hidden">
      <CardHeader className="bg-muted/30 border-b py-2.5 px-4">
        <CardTitle className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-violet-500" />
            Latency Stability (Avg vs P95)
          </span>
          <span className="flex items-center gap-3 text-xs font-normal text-muted-foreground">
            <span>Avg spread: <span className={avgSpread > 500 ? "text-red-500 font-medium" : avgSpread > 200 ? "text-amber-500 font-medium" : "text-emerald-500 font-medium"}>{avgSpread}ms</span></span>
            <span>Peak: {maxSpread}ms</span>
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <div className="h-[260px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <DynatraceGradients />
              <CartesianGrid {...DT_GRID_PROPS} />
              <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
              <YAxis {...DT_AXIS_PROPS} label={{ value: 'ms', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
              <Tooltip
                contentStyle={tooltipStyle}
                cursor={DT_CURSOR_PROPS}
                formatter={(value: number, name: string) => [`${Math.floor(value)} ms`, name]}
                labelFormatter={(label) => `Time: ${label}`}
              />
              <Legend />
              <ReferenceLine y={avgOfAvg} stroke={DT_COLORS.primary} strokeDasharray="6 3" strokeOpacity={0.5} label={{ value: `Avg: ${avgOfAvg}ms`, position: 'right', fontSize: 10, fill: DT_COLORS.primary }} />
              <Area type="monotone" dataKey="p95Ms" name="P95 Latency" stroke={DT_COLORS.red} fill="url(#dt-grad-red)" strokeWidth={2} dot={false} />
              <Area type="monotone" dataKey="avgMs" name="Avg Latency" stroke={DT_COLORS.primary} fill="url(#dt-grad-primary)" strokeWidth={2} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

export function ErrorRateOverTime({ timeseries, startTime }: { timeseries: any[]; startTime?: any }) {
  const data = useMemo(() => {
    if (!timeseries || timeseries.length === 0) return [];
    return normalizeTimeseries(timeseries, startTime);
  }, [timeseries, startTime]);

  if (!data.length) return <EmptyChart title="Error Rate Over Time" icon={<AlertCircle className="w-4 h-4 text-red-500" />} />;

  const maxErrorRate = Math.max(...data.map(d => d.errorRate));
  const avgErrorRate = (data.reduce((s, d) => s + d.errorRate, 0) / data.length).toFixed(2);
  const totalErrors = data.reduce((s, d) => s + d.errors, 0);

  return (
    <Card className="card-shadow overflow-hidden">
      <CardHeader className="bg-muted/30 border-b py-2.5 px-4">
        <CardTitle className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-500" />
            Error Rate Over Time
          </span>
          <span className="flex items-center gap-3 text-xs font-normal text-muted-foreground">
            <span>Avg: <span className={Number(avgErrorRate) > 5 ? "text-red-500 font-medium" : Number(avgErrorRate) > 1 ? "text-amber-500 font-medium" : "text-emerald-500 font-medium"}>{avgErrorRate}%</span></span>
            <span>Peak: {maxErrorRate.toFixed(1)}%</span>
            <span>Total: {totalErrors}</span>
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <div className="h-[260px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data}>
              <DynatraceGradients />
              <CartesianGrid {...DT_GRID_PROPS} />
              <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
              <YAxis yAxisId="left" {...DT_AXIS_PROPS} label={{ value: '%', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
              <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} allowDecimals={false} label={{ value: 'count', angle: 90, position: 'insideRight', style: { fontSize: 11 } }} />
              <Tooltip
                contentStyle={tooltipStyle}
                cursor={DT_CURSOR_PROPS}
                formatter={(value: number, name: string) => {
                  if (name.includes('%')) return [`${value.toFixed(2)}%`, name];
                  return [value, name];
                }}
              />
              <Legend />
              <Area yAxisId="left" type="monotone" dataKey="errorRate" name="Error Rate (%)" stroke={DT_COLORS.red} fill="url(#dt-grad-red)" strokeWidth={2} dot={false} />
              <Bar yAxisId="right" dataKey="errors" name="Error Count" fill={DT_COLORS.red} fillOpacity={0.5} barSize={4} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

export function ThroughputLatencyCorrelation({ timeseries, startTime }: { timeseries: any[]; startTime?: any }) {
  const { data, saturationPoint } = useMemo(() => {
    if (!timeseries || timeseries.length === 0) return { data: [], saturationPoint: null };
    const normalized = normalizeTimeseries(timeseries, startTime);
    const scatter = normalized
      .filter(p => p.rps > 0)
      .map(p => ({
        throughput: Math.round(p.rps * 100) / 100,
        latency: Math.floor(p.avgMs),
        p95: Math.floor(p.p95Ms),
        errors: p.errors,
        time: p.time,
      }));

    let satPoint: { throughput: number; latency: number } | null = null;
    if (scatter.length > 10) {
      const sorted = [...scatter].sort((a, b) => a.throughput - b.throughput);
      const windowSize = Math.max(3, Math.floor(sorted.length / 10));
      let maxSlopeChange = 0;
      for (let i = windowSize; i < sorted.length - windowSize; i++) {
        const leftSlope = (sorted[i].latency - sorted[i - windowSize].latency) /
          (sorted[i].throughput - sorted[i - windowSize].throughput + 0.001);
        const rightSlope = (sorted[i + windowSize].latency - sorted[i].latency) /
          (sorted[i + windowSize].throughput - sorted[i].throughput + 0.001);
        const change = Math.abs(rightSlope - leftSlope);
        if (change > maxSlopeChange && rightSlope > leftSlope * 1.5) {
          maxSlopeChange = change;
          satPoint = { throughput: sorted[i].throughput, latency: sorted[i].latency };
        }
      }
    }

    return { data: scatter, saturationPoint: satPoint };
  }, [timeseries, startTime]);

  if (!data.length) return <EmptyChart title="Throughput vs Latency" icon={<Zap className="w-4 h-4 text-amber-500" />} />;

  const maxThroughput = Math.max(...data.map(d => d.throughput));
  const maxLatency = Math.max(...data.map(d => d.latency));

  return (
    <Card className="card-shadow overflow-hidden">
      <CardHeader className="bg-muted/30 border-b py-2.5 px-4">
        <CardTitle className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-500" />
            Throughput vs Latency Correlation
          </span>
          {saturationPoint && (
            <span className="text-xs font-normal text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 px-2 py-0.5 rounded-full border border-amber-200 dark:border-amber-700/50">
              Saturation ~{saturationPoint.throughput.toFixed(1)} req/s
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <div className="h-[260px]">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 30, bottom: 10, left: 10 }}>
              <CartesianGrid {...DT_GRID_PROPS} />
              <XAxis type="number" dataKey="throughput" name="Throughput" unit=" req/s" {...DT_AXIS_PROPS} domain={[0, Math.ceil(maxThroughput * 1.1)]} label={{ value: 'Throughput (req/s)', position: 'insideBottom', offset: -5, style: { fontSize: 11 } }} />
              <YAxis type="number" dataKey="latency" name="Latency" unit=" ms" {...DT_AXIS_PROPS} domain={[0, Math.ceil(maxLatency * 1.1)]} label={{ value: 'Avg Response (ms)', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
              <ZAxis range={[25, 25]} />
              <Tooltip
                contentStyle={tooltipStyle}
                cursor={DT_CURSOR_PROPS}
                formatter={(value: number, name: string) => {
                  if (name === 'Throughput') return [`${value} req/s`, name];
                  if (name === 'Latency') return [`${value} ms`, 'Avg Response'];
                  return [value, name];
                }}
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload;
                  return (
                    <div style={tooltipStyle} className="p-2 text-xs shadow-lg">
                      <p className="font-medium mb-1">{d.time}</p>
                      <p>Throughput: <span className="font-medium">{d.throughput} req/s</span></p>
                      <p>Avg Latency: <span className="font-medium">{d.latency} ms</span></p>
                      {d.p95 > 0 && <p>P95 Latency: <span className="font-medium">{d.p95} ms</span></p>}
                      {d.errors > 0 && <p className="text-red-500">Errors: {d.errors}</p>}
                    </div>
                  );
                }}
              />
              {saturationPoint && (
                <ReferenceLine x={saturationPoint.throughput} stroke={DT_COLORS.amber} strokeDasharray="6 3" strokeWidth={2} label={{ value: 'Saturation', position: 'top', fontSize: 10, fill: DT_COLORS.amber }} />
              )}
              <Scatter
                data={data}
                fill={DT_COLORS.primary}
                fillOpacity={0.6}
                shape={(props: any) => {
                  const { cx, cy, payload } = props;
                  const hasErrors = payload.errors > 0;
                  return (
                    <circle
                      cx={cx}
                      cy={cy}
                      r={hasErrors ? 5 : 3.5}
                      fill={hasErrors ? DT_COLORS.red : DT_COLORS.primary}
                      fillOpacity={hasErrors ? 0.8 : 0.5}
                      stroke={hasErrors ? DT_COLORS.red : DT_COLORS.primary}
                      strokeWidth={1}
                    />
                  );
                }}
              />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

export function ActiveUsersTimeline({ timeseries, startTime }: { timeseries: any[]; startTime?: number }) {
  const data = useMemo(() => {
    if (!timeseries || timeseries.length === 0) return [];
    return normalizeTimeseries(timeseries, startTime);
  }, [timeseries, startTime]);

  if (!data.length) return <EmptyChart title="Active Users & Response Trend" icon={<Users className="w-4 h-4 text-blue-500" />} />;

  const peakUsers = Math.max(...data.map(d => d.activeThreads));

  return (
    <Card className="card-shadow overflow-hidden">
      <CardHeader className="bg-muted/30 border-b py-2.5 px-4">
        <CardTitle className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-500" />
            Active Users & Response Trend
          </span>
          <span className="text-xs font-normal text-muted-foreground">
            Peak: {peakUsers} users
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <div className="h-[260px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data}>
              <DynatraceGradients />
              <CartesianGrid {...DT_GRID_PROPS} />
              <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
              <YAxis yAxisId="left" {...DT_AXIS_PROPS} label={{ value: 'users', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
              <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} label={{ value: 'ms', angle: 90, position: 'insideRight', style: { fontSize: 11 } }} />
              <Tooltip
                contentStyle={tooltipStyle}
                cursor={DT_CURSOR_PROPS}
                formatter={(value: number, name: string) => {
                  if (name.includes('ms')) return [`${Math.floor(value)} ms`, name];
                  return [Math.floor(value), name];
                }}
              />
              <Legend />
              <Area yAxisId="left" type="monotone" dataKey="activeThreads" name="Active Users" stroke={DT_COLORS.primary} fill="url(#dt-grad-primary)" strokeWidth={2} dot={false} />
              <Line yAxisId="right" type="monotone" dataKey="avgMs" name="Avg Response (ms)" stroke={DT_COLORS.amber} strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
              <Line yAxisId="right" type="monotone" dataKey="p95Ms" name="P95 (ms)" stroke={DT_COLORS.red} strokeWidth={1.5} dot={false} strokeDasharray="2 2" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

export function TransactionPerformanceChart({ transactionDetails }: { transactionDetails: any[] }) {
  const { chartData } = useMemo(() => {
    if (!transactionDetails || transactionDetails.length === 0) return { chartData: [] };
    const sorted = [...transactionDetails].sort((a, b) => (b.p95 || 0) - (a.p95 || 0));
    const maxP95 = sorted[0]?.p95 || 1;
    const data = sorted.map((tx) => ({
      fullName: tx.label,
      avg: Math.floor(tx.avg || 0),
      p50: Math.floor(tx.p50 || 0),
      p95: Math.floor(tx.p95 || 0),
      p99: Math.floor(tx.p99 || 0),
      errorRate: tx.errorRate || 0,
      count: tx.count || 0,
      throughput: tx.throughput || tx.hitsPerSec || 0,
      isBottleneck: (tx.p95 || 0) > maxP95 * 0.7,
    }));
    return { chartData: data };
  }, [transactionDetails]);

  if (!chartData.length) return <EmptyChart title="Transaction Bottleneck Analysis" icon={<GitCompareArrows className="w-4 h-4 text-blue-500" />} />;

  const bottleneckCount = chartData.filter(d => d.isBottleneck).length;
  const maxP99 = Math.max(...chartData.map(d => d.p99));

  return (
    <Card className="card-shadow overflow-hidden">
      <CardHeader className="bg-muted/30 border-b py-2.5 px-4">
        <CardTitle className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-2">
            <GitCompareArrows className="w-4 h-4 text-blue-500" />
            Transaction Bottleneck Analysis
          </span>
          <span className="flex items-center gap-2">
            {bottleneckCount > 0 && (
              <span className="text-xs font-normal text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 px-2 py-0.5 rounded-full border border-red-200 dark:border-red-700/50">
                {bottleneckCount} bottleneck{bottleneckCount !== 1 ? "s" : ""}
              </span>
            )}
            <span className="text-xs font-normal text-muted-foreground">
              {chartData.length} transactions (sorted by P95)
            </span>
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b bg-muted/20">
                <th className="text-left font-medium text-muted-foreground px-3 py-2 w-[180px] min-w-[140px]">Transaction</th>
                <th className="text-right font-medium text-muted-foreground px-2 py-2 w-[60px]">Requests</th>
                <th className="text-right font-medium text-muted-foreground px-2 py-2 w-[55px]">RPS</th>
                <th className="text-right font-medium text-muted-foreground px-2 py-2 w-[50px]">Err%</th>
                <th className="text-left font-medium text-muted-foreground px-3 py-2">
                  <span className="flex items-center gap-4">
                    <span>Response Time Distribution</span>
                    <span className="flex items-center gap-3 font-normal">
                      <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded-sm bg-blue-500" /> Avg</span>
                      <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded-sm bg-amber-500" /> P95</span>
                      <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded-sm bg-red-400/70" /> P99</span>
                    </span>
                  </span>
                </th>
              </tr>
            </thead>
            <tbody>
              {chartData.map((tx, idx) => {
                const avgPct = maxP99 > 0 ? (tx.avg / maxP99) * 100 : 0;
                const p95Pct = maxP99 > 0 ? (tx.p95 / maxP99) * 100 : 0;
                const p99Pct = maxP99 > 0 ? (tx.p99 / maxP99) * 100 : 0;

                return (
                  <tr key={idx} className={`border-b last:border-b-0 transition-colors hover:bg-muted/20 ${tx.isBottleneck ? 'bg-red-50/40 dark:bg-red-950/10' : ''}`}>
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-1.5 min-w-0">
                        {tx.isBottleneck && <span className="shrink-0 h-1.5 w-1.5 rounded-full bg-red-500" />}
                        <span className="truncate font-medium" title={tx.fullName}>{tx.fullName}</span>
                      </div>
                    </td>
                    <td className="text-right px-2 py-2 font-mono text-muted-foreground">{tx.count.toLocaleString()}</td>
                    <td className="text-right px-2 py-2 font-mono text-muted-foreground">{tx.throughput.toFixed(1)}</td>
                    <td className={`text-right px-2 py-2 font-mono ${tx.errorRate > 0 ? 'text-red-500 font-medium' : 'text-muted-foreground'}`}>
                      {tx.errorRate > 0 ? tx.errorRate.toFixed(1) : '0'}
                    </td>
                    <td className="px-3 py-2">
                      <div className="relative h-6 bg-muted/30 rounded overflow-hidden" title={`Avg: ${tx.avg}ms | P95: ${tx.p95}ms | P99: ${tx.p99}ms`}>
                        <div className="absolute inset-y-0 left-0 bg-red-400/30 rounded-r" style={{ width: `${Math.max(p99Pct, 0.5)}%` }} />
                        <div className={`absolute inset-y-0 left-0 rounded-r ${tx.isBottleneck ? 'bg-amber-500/70' : 'bg-amber-500/50'}`} style={{ width: `${Math.max(p95Pct, 0.5)}%` }} />
                        <div className="absolute inset-y-0 left-0 bg-blue-500/80 rounded-r" style={{ width: `${Math.max(avgPct, 0.5)}%` }} />
                        <div className="absolute inset-0 flex items-center justify-end px-2 gap-2 text-[10px]">
                          <span className="font-mono font-medium text-foreground/80">
                            {tx.avg}<span className="text-muted-foreground/60">ms</span>
                            {' / '}
                            <span className={tx.isBottleneck ? 'text-red-600 dark:text-red-400' : 'text-amber-600 dark:text-amber-400'}>{tx.p95}</span>
                            <span className="text-muted-foreground/60">ms</span>
                            {' / '}
                            <span className="text-red-500/70">{tx.p99}</span>
                            <span className="text-muted-foreground/60">ms</span>
                          </span>
                        </div>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

export function TransactionErrorBreakdown({ transactionDetails }: { transactionDetails: any[] }) {
  const chartData = useMemo(() => {
    if (!transactionDetails || transactionDetails.length === 0) return [];
    return transactionDetails
      .filter(tx => (tx.errorRate || 0) > 0 || (tx.errorCount || 0) > 0)
      .sort((a, b) => (b.errorRate || 0) - (a.errorRate || 0))
      .map(tx => ({
        name: tx.label?.length > 25 ? tx.label.substring(0, 22) + "..." : tx.label,
        fullName: tx.label,
        errorRate: tx.errorRate || 0,
        errorCount: tx.errorCount || 0,
        count: tx.count || 0,
      }));
  }, [transactionDetails]);

  if (!chartData.length) return null;

  return (
    <Card className="card-shadow overflow-hidden border-red-200/50 dark:border-red-800/30">
      <CardHeader className="bg-red-50/50 dark:bg-red-900/10 border-b border-red-200/50 dark:border-red-800/30 py-2.5 px-4">
        <CardTitle className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-2 text-red-700 dark:text-red-400">
            <AlertCircle className="w-4 h-4" />
            Transaction Error Breakdown
          </span>
          <span className="text-xs font-normal text-muted-foreground">
            {chartData.length} transaction{chartData.length !== 1 ? "s" : ""} with errors
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <div style={{ height: Math.max(180, chartData.length * 40 + 60) }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} layout="vertical" barCategoryGap="25%">
              <CartesianGrid {...DT_GRID_PROPS} horizontal={false} />
              <XAxis type="number" {...DT_AXIS_PROPS} label={{ value: 'Error Rate (%)', position: 'insideBottom', offset: -5, style: { fontSize: 11 } }} />
              <YAxis type="category" dataKey="name" {...DT_AXIS_PROPS} width={150} />
              <Tooltip
                contentStyle={tooltipStyle}
                cursor={DT_CURSOR_PROPS}
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload;
                  return (
                    <div style={tooltipStyle} className="p-2 text-xs shadow-lg">
                      <p className="font-medium mb-1">{d.fullName}</p>
                      <p className="text-red-500">Error Rate: <span className="font-bold">{d.errorRate.toFixed(2)}%</span></p>
                      <p>Failed: {d.errorCount} / {d.count} requests</p>
                    </div>
                  );
                }}
              />
              <Bar dataKey="errorRate" name="Error Rate (%)" radius={[0, 4, 4, 0]} barSize={12}>
                {chartData.map((entry, i) => (
                  <Cell key={i} fill={entry.errorRate > 10 ? DT_COLORS.critical : entry.errorRate > 5 ? DT_COLORS.red : DT_COLORS.amber} fillOpacity={0.8} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

