import React, { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useWebSocket, type LiveMetricsSnapshot, type SlaViolation, type Anomaly, type PerformanceInsight } from "@/hooks/use-websocket";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceDot,
  Legend,
} from "recharts";
import {
  Activity,
  Gauge,
  Clock,
  AlertTriangle,
  Users,
  TrendingUp,
  Zap,
  Timer,
  WifiOff,
  ShieldAlert,
  TriangleAlert,
  Cpu,
  MemoryStick,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import { LatencyStabilityChart, ErrorRateOverTime, ThroughputLatencyCorrelation, ActiveUsersTimeline, TransactionPerformanceChart, TransactionErrorBreakdown } from "./gatling-charts";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS, DT_TOOLTIP_STYLE, DynatraceGradients } from "@/components/charts/dynatrace-theme";

interface LiveMetricsProps {
  executionId: number;
}

const STALE_THRESHOLD_MS = 10000;

const ANOMALY_ICONS: Record<string, string> = {
  error_spike: "🔴",
  server_overloaded: "🔥",
  throughput_collapse: "📉",
  backend_slowdown: "🐌",
  gradual_degradation: "📈",
  tail_latency: "📊",
};

const INSIGHT_LABELS: Record<string, string> = {
  error_spike: "High Error Rate",
  server_overloaded: "Server Overloaded",
  throughput_collapse: "Throughput Collapse",
  backend_slowdown: "Backend Slowdown",
  gradual_degradation: "Gradual Performance Decline",
  tail_latency: "Tail Latency Issue",
};

type TimeRange = "1m" | "5m" | "15m" | "30m" | "1h" | "all";
const TIME_RANGE_POINTS: Record<TimeRange, number> = {
  "1m": 12,
  "5m": 60,
  "15m": 180,
  "30m": 360,
  "1h": 720,
  "all": Infinity,
};

function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

function formatNumber(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(1) + "K";
  return n.toLocaleString();
}

function formatComparator(comparator: string): string {
  switch (comparator) {
    case "gt": return ">";
    case "gte": return ">=";
    case "lt": return "<";
    case "lte": return "<=";
    default: return comparator;
  }
}

function formatMetricName(metric: string): string {
  switch (metric) {
    case "avg": return "Avg Response Time";
    case "p90": return "P90";
    case "p95": return "P95";
    case "p99": return "P99";
    case "max": return "Max Response Time";
    case "errorRate": return "Error Rate";
    case "throughput": return "Throughput";
    default: return metric;
  }
}

function formatMetricUnit(metric: string): string {
  switch (metric) {
    case "errorRate": return "%";
    case "throughput": return " req/s";
    default: return " ms";
  }
}

interface FetchResult {
  active: boolean;
  snapshot: LiveMetricsSnapshot | null;
  warning: string | null;
}

function fetchSnapshot(executionId: number): Promise<FetchResult> {
  return fetch(`/api/executions/${executionId}/live-metrics`)
    .then((res) => res.json())
    .catch(() => ({ active: false, snapshot: null, warning: null }));
}

const POLL_INTERVAL_MS = 3000;
const POLL_BACKOFF_MAX_MS = 10000;

export default function LiveMetrics({ executionId }: LiveMetricsProps) {
  const [snapshot, setSnapshot] = useState<LiveMetricsSnapshot | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [isStale, setIsStale] = useState(false);
  const [timeRange, setTimeRange] = useState<TimeRange>("all");
  const [warning, setWarning] = useState<string | null>(null);
  const [expandedTx, setExpandedTx] = useState<number | null>(null);
  const staleTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const wsReceivedRef = useRef(false);
  const pollTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pollAttemptsRef = useRef(0);


  const applySnapshot = useCallback((data: FetchResult) => {
    if (data.active && data.snapshot) {
      setSnapshot(data.snapshot);
      setLastUpdate(new Date());
      setIsStale(false);
    }
    setWarning(data.warning ?? null);
  }, []);

  const startPolling = useCallback(() => {
    if (pollTimerRef.current) clearTimeout(pollTimerRef.current);
    const poll = () => {
      if (wsReceivedRef.current) return;
      fetchSnapshot(executionId).then((data) => {
        applySnapshot(data);
        if (data.active && data.snapshot) {
          pollAttemptsRef.current = 0;
        } else {
          pollAttemptsRef.current++;
        }
        if (!wsReceivedRef.current) {
          const delay = Math.min(POLL_INTERVAL_MS + pollAttemptsRef.current * 1000, POLL_BACKOFF_MAX_MS);
          pollTimerRef.current = setTimeout(poll, delay);
        }
      });
    };
    pollTimerRef.current = setTimeout(poll, POLL_INTERVAL_MS);
  }, [executionId, applySnapshot]);

  useEffect(() => {
    wsReceivedRef.current = false;
    pollAttemptsRef.current = 0;
    fetchSnapshot(executionId).then(applySnapshot);
    startPolling();
    return () => {
      if (pollTimerRef.current) clearTimeout(pollTimerRef.current);
    };
  }, [executionId, applySnapshot, startPolling]);

  useEffect(() => {
    staleTimerRef.current = setInterval(() => {
      if (lastUpdate) {
        const elapsed = Date.now() - lastUpdate.getTime();
        if (elapsed > STALE_THRESHOLD_MS) {
          setIsStale(true);
          if (wsReceivedRef.current) {
            wsReceivedRef.current = false;
            pollAttemptsRef.current = 0;
            startPolling();
          }
        } else {
          setIsStale(false);
        }
      }
    }, 2000);
    return () => {
      if (staleTimerRef.current) clearInterval(staleTimerRef.current);
    };
  }, [lastUpdate, startPolling]);

  const [idleWarning, setIdleWarning] = useState<{ idleSeconds: number; timeoutSeconds: number; remainingSeconds: number } | null>(null);
  const [autoAbortWarning, setAutoAbortWarning] = useState<{
    ruleId: number;
    metric: string;
    comparator: string;
    threshold: number;
    actualValue: number;
    sustainedSeconds: number;
    breachStartedAt: number;
  } | null>(null);

  const handleExecutionUpdate = useCallback(
    (data: { executionId: number; status: string; resultSummary?: any }) => {
      if (data.executionId === executionId && data.resultSummary?._autoAbortWarning) {
        setAutoAbortWarning(data.resultSummary._autoAbortWarning);
      }
    },
    [executionId]
  );

  const handleLiveMetrics = useCallback(
    (data: { executionId: number; snapshot: LiveMetricsSnapshot & { _idleWarning?: { idleSeconds: number; timeoutSeconds: number; remainingSeconds: number } } }) => {
      if (data.executionId === executionId) {
        wsReceivedRef.current = true;
        if (pollTimerRef.current) {
          clearTimeout(pollTimerRef.current);
          pollTimerRef.current = null;
        }
        if (data.snapshot._idleWarning) {
          setIdleWarning(data.snapshot._idleWarning);
        } else {
          setIdleWarning(null);
        }
        setSnapshot(data.snapshot);
        setLastUpdate(new Date());
        setIsStale(false);
        if (data.snapshot.summary.totalRequests > 0) {
          setWarning(null);
        }
      }
    },
    [executionId]
  );

  const handleReconnect = useCallback(() => {
    wsReceivedRef.current = false;
    pollAttemptsRef.current = 0;
    fetchSnapshot(executionId).then(applySnapshot);
    startPolling();
  }, [executionId, applySnapshot, startPolling]);

  useWebSocket({ onLiveMetrics: handleLiveMetrics, onReconnect: handleReconnect, onExecutionUpdate: handleExecutionUpdate });

  const chartData = useMemo(() => {
    if (!snapshot) return [];
    const maxPoints = TIME_RANGE_POINTS[timeRange];
    const series = snapshot.series;
    const sliced = series.length > maxPoints ? series.slice(-maxPoints) : series;
    return sliced.map((point) => {
      const date = new Date(point.t);
      return {
        time: `${date.getHours().toString().padStart(2, "0")}:${date.getMinutes().toString().padStart(2, "0")}:${date.getSeconds().toString().padStart(2, "0")}`,
        t: point.t,
        throughput: point.throughput,
        avgRT: point.avgRT,
        p95: point.p95,
        errorRate: point.errorRate,
        activeThreads: point.activeThreads,
      };
    });
  }, [snapshot, timeRange]);

  const chartAnomalies = useMemo(() => {
    if (!snapshot?.anomalies || !chartData.length) return { responseTime: [] as any[], throughput: [] as any[], errorRate: [] as any[] };
    const timeMap = new Map<number, { time: string; data: typeof chartData[0] }>();
    for (const d of chartData) {
      timeMap.set(d.t, { time: d.time, data: d });
    }
    const findNearest = (ts: number) => {
      let match = timeMap.get(ts);
      if (!match) {
        for (let delta = 1; delta <= 3000; delta += 1000) {
          match = timeMap.get(ts - delta) || timeMap.get(ts + delta);
          if (match) break;
        }
      }
      return match;
    };
    const result = { responseTime: [] as any[], throughput: [] as any[], errorRate: [] as any[] };
    for (const a of snapshot.anomalies) {
      const match = findNearest(a.timestamp);
      if (!match) continue;
      const entry = { time: match.time, ...a };
      if (a.metricType === "response_time") result.responseTime.push(entry);
      else if (a.metricType === "throughput") result.throughput.push(entry);
      else if (a.metricType === "error_rate") result.errorRate.push(entry);
    }
    return result;
  }, [snapshot?.anomalies, chartData]);

  const sysChartData = useMemo(() => {
    const history = snapshot?.systemMetrics?.history;
    if (!history?.length) return [];
    const firstTs = history[0].ts;
    return history.map(s => {
      const elapsed = Math.round((s.ts - firstTs) / 1000);
      const m = Math.floor(elapsed / 60);
      const sec = elapsed % 60;
      return {
        time: `${m}:${sec.toString().padStart(2, "0")}`,
        cpuPercent: s.cpuPercent,
        memPercent: s.memPercent,
        diskReadMbps: s.diskReadMbps,
        diskWriteMbps: s.diskWriteMbps,
        jmeterCpu: s.jmeterCpuPercent ?? 0,
      };
    });
  }, [snapshot?.systemMetrics?.history]);

  if (!snapshot) {
    return (
      <Card className="border-dashed border-2 border-muted-foreground/20">
        <CardContent className="py-12 text-center">
          <Activity className="w-10 h-10 text-muted-foreground mx-auto mb-3 animate-pulse" />
          <p className="text-muted-foreground text-sm">
            Waiting for live metrics...
          </p>
          <p className="text-muted-foreground/60 text-xs mt-1">
            Data will appear once JMeter starts producing results
          </p>
          {warning && (
            <div className="mt-3 flex items-center justify-center gap-1.5 text-amber-500 text-xs">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{warning}</span>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  const { summary, topErrors, topSlow, slaViolations, anomalySummary, systemMetrics } = snapshot;
  const allTransactions = snapshot.allTransactions || [];
  const insights = snapshot.insights || [];
  const insightSummary = snapshot.insightSummary || null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {isStale ? (
            <>
              <WifiOff className="w-3.5 h-3.5 text-amber-500" />
              <span className="text-sm font-medium text-amber-500">
                Data may be stale
              </span>
            </>
          ) : (
            <>
              <div className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
              </div>
              <span className="text-sm font-medium text-muted-foreground">
                Live Monitoring
              </span>
            </>
          )}
          <Badge variant="outline" className="text-xs">
            <Timer className="w-3 h-3 mr-1" />
            {formatDuration(summary.elapsedSeconds)}
          </Badge>
          {insights.length > 0 && (
            <Badge variant={(insightSummary?.critical || 0) > 0 ? "destructive" : "secondary"} className="text-xs">
              <Zap className="w-3 h-3 mr-1" />
              {insights.length} insight{insights.length !== 1 ? "s" : ""}
              {(insightSummary?.critical || 0) > 0 && ` (${insightSummary!.critical} critical)`}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          {isStale && lastUpdate && (
            <span className="text-xs text-amber-500">
              Last update {Math.round((Date.now() - lastUpdate.getTime()) / 1000)}s ago
            </span>
          )}
          {lastUpdate && (
            <span className="text-xs text-muted-foreground">
              {formatNumber(summary.totalRequests)} samples
            </span>
          )}
        </div>
      </div>

      {idleWarning && (
        <Card className="border-amber-400/60 dark:border-amber-600/40 bg-amber-50/30 dark:bg-amber-950/20">
          <CardContent className="py-3 px-4">
            <div className="flex items-center gap-2">
              <WifiOff className="w-4 h-4 text-amber-500 shrink-0" />
              <div>
                <p className="text-sm font-medium text-amber-700 dark:text-amber-400">
                  No data received for {idleWarning.idleSeconds}s — connection may be interrupted
                </p>
                <p className="text-xs text-amber-600 dark:text-amber-500 mt-0.5">
                  Test will auto-complete in ~{idleWarning.remainingSeconds}s if no samples arrive. Total timeout: {idleWarning.timeoutSeconds}s.
                  If your test is still running, check the network connection between JMeter and PerfHub.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {autoAbortWarning && (
        <Card className="border-orange-400/60 dark:border-orange-600/40 bg-orange-50/30 dark:bg-orange-950/20">
          <CardContent className="py-3 px-4">
            <div className="flex items-center gap-2">
              <TriangleAlert className="w-4 h-4 text-orange-500 shrink-0" />
              <div>
                <p className="text-sm font-medium text-orange-700 dark:text-orange-400">
                  Auto-Abort Threshold Breached — {formatMetricName(autoAbortWarning.metric)} {formatComparator(autoAbortWarning.comparator)} {autoAbortWarning.threshold}{formatMetricUnit(autoAbortWarning.metric)}
                </p>
                <p className="text-xs text-orange-600 dark:text-orange-500 mt-0.5">
                  Current value: {autoAbortWarning.actualValue.toFixed(autoAbortWarning.metric === 'errorRate' ? 2 : 0)}{formatMetricUnit(autoAbortWarning.metric)}.
                  Test will be auto-aborted if breach persists for {autoAbortWarning.sustainedSeconds}s.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {slaViolations && slaViolations.length > 0 && (
        <Card className="border-red-400/60 dark:border-red-600/40 bg-red-50/30 dark:bg-red-950/20">
          <CardContent className="py-3 px-4">
            <div className="flex items-center gap-2 mb-2">
              <ShieldAlert className="w-4 h-4 text-red-500" />
              <span className="text-sm font-semibold text-red-600 dark:text-red-400">
                SLA Violations ({slaViolations.length})
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {slaViolations.map((v, i) => (
                <Badge
                  key={i}
                  variant="outline"
                  className="text-xs border-red-300 dark:border-red-700 text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/40"
                >
                  {v.transactionLabel ? `${v.transactionLabel}: ` : ""}
                  {formatMetricName(v.metric)} = {v.actualValue.toFixed(v.metric === "errorRate" ? 2 : 0)}{formatMetricUnit(v.metric)}
                  {" "}(threshold: {formatComparator(v.comparator)} {v.threshold}{formatMetricUnit(v.metric)})
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          icon={<Gauge className="w-4 h-4" />}
          label="Throughput"
          value={`${summary.throughput.toFixed(1)}`}
          unit="req/s"
          color={DT_COLORS.throughput}
        />
        <MetricCard
          icon={<Clock className="w-4 h-4" />}
          label="Avg Response"
          value={`${summary.avgResponseTime.toFixed(0)}`}
          unit="ms"
          color={DT_COLORS.responseTime}
        />
        <MetricCard
          icon={<TrendingUp className="w-4 h-4" />}
          label="P95"
          value={`${summary.p95.toFixed(0)}`}
          unit="ms"
          color={DT_COLORS.p95}
        />
        <MetricCard
          icon={<TrendingUp className="w-4 h-4" />}
          label="P99"
          value={`${(summary.p99 ?? 0).toFixed(0)}`}
          unit="ms"
          color={DT_COLORS.orange}
        />
        <MetricCard
          icon={<AlertTriangle className="w-4 h-4" />}
          label="Error Rate"
          value={`${summary.errorRate.toFixed(2)}`}
          unit="%"
          color={summary.errorRate > 1 ? DT_COLORS.red : DT_COLORS.green}
        />
        <MetricCard
          icon={<Users className="w-4 h-4" />}
          label="Active Threads"
          value={`${summary.activeThreads}`}
          unit=""
          color={DT_COLORS.purple}
        />
      </div>

      {allTransactions.length > 0 && (
        <Card className="card-shadow overflow-hidden">
          <CardHeader className="bg-muted/30 border-b">
            <CardTitle className="flex items-center gap-2 text-base">
              <Activity className="w-5 h-5 text-primary" />
              Transaction Details
              <Badge variant="outline" className="ml-2 text-[10px] animate-pulse">Live</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto rounded-xl border border-border/60 bg-card">
              <table className="w-full text-sm text-left">
                <thead className="bg-muted/50 text-muted-foreground font-bold text-xs uppercase tracking-wider">
                  <tr>
                    <th className="px-4 py-3">Transaction</th>
                    <th className="px-4 py-3">Count</th>
                    <th className="px-4 py-3">Avg (ms)</th>
                    <th className="px-4 py-3">P50 (ms)</th>
                    <th className="px-4 py-3">P90 (ms)</th>
                    <th className="px-4 py-3">P95 (ms)</th>
                    <th className="px-4 py-3">P99 (ms)</th>
                    <th className="px-4 py-3">Max (ms)</th>
                    <th className="px-4 py-3">Throughput</th>
                    <th className="px-4 py-3">Error %</th>
                    <th className="px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {allTransactions.map((tx, idx) => (
                    <React.Fragment key={idx}>
                      <tr
                        className="hover:bg-muted/30 transition-colors cursor-pointer"
                        onClick={() => setExpandedTx(expandedTx === idx ? null : idx)}
                      >
                        <td className="px-4 py-3 font-semibold text-foreground flex items-center gap-1.5">
                          {expandedTx === idx ? <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" /> : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />}
                          {tx.label}
                        </td>
                        <td className="px-4 py-3">{formatNumber(tx.count)}</td>
                        <td className="px-4 py-3">{Math.round(tx.avg)}</td>
                        <td className="px-4 py-3">{Math.round(tx.p50)}</td>
                        <td className="px-4 py-3">{Math.round(tx.p90)}</td>
                        <td className="px-4 py-3">{Math.round(tx.p95)}</td>
                        <td className="px-4 py-3">{Math.round(tx.p99)}</td>
                        <td className="px-4 py-3">{Math.round(tx.max)}</td>
                        <td className="px-4 py-3">{tx.throughput.toFixed(2)}/s</td>
                        <td className="px-4 py-3 font-medium text-red-500">{tx.errorRate.toFixed(2)}%</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                            tx.errorRate < 2
                              ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                              : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                          }`}>
                            {tx.errorRate < 2 ? 'PASS' : 'FAIL'}
                          </span>
                        </td>
                      </tr>
                      {expandedTx === idx && (
                        <tr className="bg-muted/10">
                          <td colSpan={11} className="px-4 py-4">
                            <div className="max-w-lg">
                              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Response Time Summary</p>
                              <div className="grid grid-cols-4 gap-3 text-xs">
                                <div className="p-2 rounded bg-muted/30">
                                  <span className="text-muted-foreground">Min</span>
                                  <p className="font-semibold">{Math.round(tx.min)} ms</p>
                                </div>
                                <div className="p-2 rounded bg-muted/30">
                                  <span className="text-muted-foreground">Avg</span>
                                  <p className="font-semibold">{Math.round(tx.avg)} ms</p>
                                </div>
                                <div className="p-2 rounded bg-muted/30">
                                  <span className="text-muted-foreground">P95</span>
                                  <p className="font-semibold">{Math.round(tx.p95)} ms</p>
                                </div>
                                <div className="p-2 rounded bg-muted/30">
                                  <span className="text-muted-foreground">Max</span>
                                  <p className="font-semibold">{Math.round(tx.max)} ms</p>
                                </div>
                              </div>
                              {tx.errors > 0 && (
                                <div className="mt-3 p-2 rounded bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800">
                                  <span className="text-xs text-red-600 dark:text-red-400 font-medium">
                                    {tx.errors} error{tx.errors !== 1 ? 's' : ''} out of {formatNumber(tx.count)} requests ({tx.errorRate.toFixed(2)}%)
                                  </span>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {chartData.length > 2 && (
        <>
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-muted-foreground tracking-wide uppercase">Time Window</span>
            <div className="inline-flex rounded-lg border border-border/50 overflow-hidden shadow-sm">
              {(["1m", "5m", "15m", "30m", "1h", "all"] as TimeRange[]).map((range) => (
                <button
                  key={range}
                  onClick={() => setTimeRange(range)}
                  className={`px-3.5 py-1.5 text-xs font-medium transition-all duration-150 ${
                    timeRange === range
                      ? "bg-primary text-primary-foreground shadow-inner"
                      : "bg-background text-muted-foreground hover:bg-muted/60 hover:text-foreground"
                  }`}
                >
                  {range === "all" ? "All" : range}
                </button>
              ))}
            </div>
          </div>

          <Card className="card-shadow border border-border/40">
            <CardHeader className="pb-1 pt-4 px-5">
              <CardTitle className="text-sm font-semibold text-foreground flex items-center gap-2">
                <div className="p-1.5 rounded-md bg-blue-500/10"><Zap className="w-4 h-4 text-blue-500" /></div>
                Throughput & Response Time
              </CardTitle>
            </CardHeader>
            <CardContent className="px-3 pb-3">
              <div className="h-[320px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 8, right: 16, left: 0, bottom: 0 }}>
                    <DynatraceGradients />
                    <CartesianGrid {...DT_GRID_PROPS} vertical={false} />
                    <XAxis
                      dataKey="time"
                      {...DT_AXIS_PROPS}
                      interval="preserveStartEnd"
                      dy={4}
                    />
                    <YAxis
                      yAxisId="left"
                      {...DT_AXIS_PROPS}
                      axisLine={false}
                      width={52}
                      label={{ value: "req/s", angle: -90, position: "insideLeft", fontSize: 10, fill: "hsl(var(--muted-foreground))", dx: -4 }}
                    />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      {...DT_AXIS_PROPS}
                      axisLine={false}
                      width={52}
                      label={{ value: "ms", angle: 90, position: "insideRight", fontSize: 10, fill: "hsl(var(--muted-foreground))", dx: 4 }}
                    />
                    <Tooltip
                      cursor={DT_CURSOR_PROPS}
                      contentStyle={DT_TOOLTIP_STYLE}
                      labelStyle={{ fontWeight: 600, marginBottom: 4, color: "hsl(var(--foreground))" }}
                      itemStyle={{ padding: "2px 0" }}
                    />
                    <Legend
                      verticalAlign="top"
                      align="right"
                      iconType="circle"
                      iconSize={8}
                      wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }}
                    />
                    <Area
                      yAxisId="left"
                      type="monotone"
                      dataKey="throughput"
                      stroke={DT_COLORS.throughput}
                      strokeWidth={2}
                      fill="url(#dt-grad-green)"
                      dot={false}
                      activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }}
                      name="Throughput (req/s)"
                    />
                    <Area
                      yAxisId="right"
                      type="monotone"
                      dataKey="avgRT"
                      stroke={DT_COLORS.primary}
                      strokeWidth={2}
                      fill="url(#dt-grad-primary)"
                      dot={false}
                      activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }}
                      name="Avg RT (ms)"
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="p95"
                      stroke={DT_COLORS.amber}
                      strokeWidth={1.5}
                      strokeDasharray="5 3"
                      dot={false}
                      activeDot={{ r: 3, strokeWidth: 2, stroke: "#fff" }}
                      name="P95 (ms)"
                    />
                    {chartAnomalies.responseTime.map((a, i) => (
                      <ReferenceDot
                        key={`rt-${i}`}
                        x={a.time}
                        y={a.value}
                        yAxisId="right"
                        r={6}
                        fill={a.severity === "critical" ? DT_COLORS.critical : DT_COLORS.warning}
                        stroke="#fff"
                        strokeWidth={2}
                        isFront
                      />
                    ))}
                    {chartAnomalies.throughput.map((a, i) => (
                      <ReferenceDot
                        key={`tp-${i}`}
                        x={a.time}
                        y={a.value}
                        yAxisId="left"
                        r={6}
                        fill={a.severity === "critical" ? DT_COLORS.critical : DT_COLORS.warning}
                        stroke="#fff"
                        strokeWidth={2}
                        isFront
                      />
                    ))}
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="card-shadow border border-border/40">
            <CardHeader className="pb-1 pt-4 px-5">
              <CardTitle className="text-sm font-semibold text-foreground flex items-center gap-2">
                <div className="p-1.5 rounded-md bg-purple-500/10"><Users className="w-4 h-4 text-purple-500" /></div>
                Virtual Users & Error Rate
              </CardTitle>
            </CardHeader>
            <CardContent className="px-3 pb-3">
              <div className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 8, right: 16, left: 0, bottom: 0 }}>
                    <DynatraceGradients />
                    <CartesianGrid {...DT_GRID_PROPS} vertical={false} />
                    <XAxis
                      dataKey="time"
                      {...DT_AXIS_PROPS}
                      interval="preserveStartEnd"
                      dy={4}
                    />
                    <YAxis
                      yAxisId="left"
                      {...DT_AXIS_PROPS}
                      axisLine={false}
                      width={52}
                      label={{ value: "users", angle: -90, position: "insideLeft", fontSize: 10, fill: "hsl(var(--muted-foreground))", dx: -4 }}
                    />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      {...DT_AXIS_PROPS}
                      axisLine={false}
                      width={52}
                      domain={[0, (dataMax: number) => Math.max(dataMax, 5)]}
                      label={{ value: "error %", angle: 90, position: "insideRight", fontSize: 10, fill: "hsl(var(--muted-foreground))", dx: 4 }}
                    />
                    <Tooltip
                      cursor={DT_CURSOR_PROPS}
                      contentStyle={DT_TOOLTIP_STYLE}
                      labelStyle={{ fontWeight: 600, marginBottom: 4, color: "hsl(var(--foreground))" }}
                      itemStyle={{ padding: "2px 0" }}
                    />
                    <Legend
                      verticalAlign="top"
                      align="right"
                      iconType="circle"
                      iconSize={8}
                      wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }}
                    />
                    <Area
                      yAxisId="left"
                      type="stepAfter"
                      dataKey="activeThreads"
                      stroke={DT_COLORS.purple}
                      strokeWidth={2}
                      fill="url(#dt-grad-purple)"
                      dot={false}
                      activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }}
                      name="Active Threads"
                    />
                    <Area
                      yAxisId="right"
                      type="monotone"
                      dataKey="errorRate"
                      stroke={DT_COLORS.red}
                      strokeWidth={2}
                      fill="url(#dt-grad-red)"
                      dot={false}
                      activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }}
                      name="Error Rate (%)"
                    />
                    {chartAnomalies.errorRate.map((a, i) => (
                      <ReferenceDot
                        key={`er-${i}`}
                        x={a.time}
                        y={a.value}
                        yAxisId="right"
                        r={6}
                        fill={a.severity === "critical" ? DT_COLORS.critical : DT_COLORS.warning}
                        stroke="#fff"
                        strokeWidth={2}
                        isFront
                      />
                    ))}
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {insights.length > 0 && (() => {
        const criticalCount = insights.filter(i => i.severity === "critical").length;
        const warningCount = insights.filter(i => i.severity === "warning").length;
        const borderColor = criticalCount > 0 ? "border-l-red-500" : "border-l-amber-500";
        return (
          <Card className={`card-shadow border-l-4 ${borderColor}`}>
            <CardHeader className="pb-2 pt-3 px-4 bg-gradient-to-r from-violet-500/5 via-violet-500/2 to-transparent">
              <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-violet-500" />
                Live Anomaly Detection
                <div className="flex items-center gap-1 ml-1">
                  {criticalCount > 0 && <Badge variant="destructive" className="text-[10px] px-1 py-0">{criticalCount}</Badge>}
                  {warningCount > 0 && <Badge variant="outline" className="text-[10px] px-1 py-0 border-amber-400 text-amber-600">{warningCount}</Badge>}
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="px-3 pb-3">
              <div className="space-y-2">
                {insights.slice(-8).reverse().map((ins, i) => (
                  <div key={`ins-${i}`} className={`flex items-start gap-2 p-2 rounded-lg text-xs ${ins.severity === "critical" ? "bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800/50" : "bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50"}`}>
                    <span className="text-sm shrink-0">{ANOMALY_ICONS[ins.type] || "⚠️"}</span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className={`font-medium ${ins.severity === "critical" ? "text-red-700 dark:text-red-400" : "text-amber-700 dark:text-amber-400"}`}>
                          {ins.title || INSIGHT_LABELS[ins.type] || ins.type}
                        </span>
                        <span className={`text-[9px] px-1 py-0 rounded-full font-medium uppercase ${ins.severity === "critical" ? "bg-red-200 dark:bg-red-800/50 text-red-700 dark:text-red-300" : "bg-amber-200 dark:bg-amber-800/50 text-amber-700 dark:text-amber-300"}`}>
                          {ins.severity}
                        </span>
                      </div>
                      <p className="text-muted-foreground leading-relaxed">{ins.description}</p>
                      {ins.evidence && (
                        <div className="flex flex-wrap gap-1.5 mt-1.5">
                          {ins.evidence.responseTime && (
                            <span className="text-[10px] bg-muted/60 px-1.5 py-0.5 rounded font-mono">RT: {Math.round(ins.evidence.responseTime.value)}ms (was {Math.round(ins.evidence.responseTime.baseline)}ms)</span>
                          )}
                          {ins.evidence.errorRate && (
                            <span className="text-[10px] bg-muted/60 px-1.5 py-0.5 rounded font-mono">Err: {ins.evidence.errorRate.value.toFixed(1)}% (was {ins.evidence.errorRate.baseline.toFixed(1)}%)</span>
                          )}
                          {ins.evidence.throughput && (
                            <span className="text-[10px] bg-muted/60 px-1.5 py-0.5 rounded font-mono">TP: {ins.evidence.throughput.value.toFixed(1)} req/s (was {ins.evidence.throughput.baseline.toFixed(1)})</span>
                          )}
                          {ins.evidence.p95 && (
                            <span className="text-[10px] bg-muted/60 px-1.5 py-0.5 rounded font-mono">P95: {Math.round(ins.evidence.p95.value)}ms (was {Math.round(ins.evidence.p95.baseline)}ms)</span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );
      })()}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {topSlow.length > 0 && (
          <Card className="card-shadow">
            <CardHeader className="pb-2 pt-3 px-4">
              <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-500" />
                Slowest Transactions
              </CardTitle>
            </CardHeader>
            <CardContent className="px-3 pb-3">
              <div className="overflow-x-auto rounded-lg border border-border/60">
                <table className="w-full text-xs">
                  <thead className="bg-muted/50 text-muted-foreground">
                    <tr>
                      <th className="px-3 py-2 text-left font-medium">Transaction</th>
                      <th className="px-3 py-2 text-right font-medium">Avg (ms)</th>
                      <th className="px-3 py-2 text-right font-medium">P95 (ms)</th>
                      <th className="px-3 py-2 text-right font-medium">P99 (ms)</th>
                      <th className="px-3 py-2 text-right font-medium">Count</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topSlow.map((tx, i) => (
                      <tr key={i} className="border-t border-border/40">
                        <td className="px-3 py-1.5 font-mono text-xs truncate max-w-[180px]" title={tx.label}>
                          {tx.label}
                        </td>
                        <td className="px-3 py-1.5 text-right text-amber-600 dark:text-amber-400 font-medium">
                          {tx.avg.toFixed(0)}
                        </td>
                        <td className="px-3 py-1.5 text-right">
                          {tx.p95.toFixed(0)}
                        </td>
                        <td className="px-3 py-1.5 text-right text-orange-600 dark:text-orange-400">
                          {(tx.p99 ?? 0).toFixed(0)}
                        </td>
                        <td className="px-3 py-1.5 text-right text-muted-foreground">
                          {formatNumber(tx.count)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {topErrors.length > 0 && (
          <Card className="card-shadow border-red-200/50 dark:border-red-800/30">
            <CardHeader className="pb-2 pt-3 px-4">
              <CardTitle className="text-xs font-medium text-red-600 dark:text-red-400 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                Failing Transactions
              </CardTitle>
            </CardHeader>
            <CardContent className="px-3 pb-3">
              <div className="overflow-x-auto rounded-lg border border-red-200/50 dark:border-red-800/30">
                <table className="w-full text-xs">
                  <thead className="bg-red-50/50 dark:bg-red-900/10 text-red-700 dark:text-red-400">
                    <tr>
                      <th className="px-3 py-2 text-left font-medium">Transaction</th>
                      <th className="px-3 py-2 text-left font-medium">Error Codes</th>
                      <th className="px-3 py-2 text-right font-medium">Error %</th>
                      <th className="px-3 py-2 text-right font-medium">Errors</th>
                      <th className="px-3 py-2 text-right font-medium">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topErrors.map((tx, i) => (
                      <tr key={i} className="border-t border-red-200/30 dark:border-red-800/20">
                        <td className="px-3 py-1.5 font-mono text-xs truncate max-w-[150px]" title={tx.label}>
                          {tx.label}
                        </td>
                        <td className="px-3 py-1.5">
                          <div className="flex flex-wrap gap-1">
                            {(tx.errorCodes ?? []).map((ec, j) => (
                              <Badge
                                key={j}
                                variant="outline"
                                className="text-[10px] px-1.5 py-0 border-red-300/50 dark:border-red-700/50 text-red-600 dark:text-red-400"
                              >
                                {ec.code} ({ec.count})
                              </Badge>
                            ))}
                          </div>
                        </td>
                        <td className="px-3 py-1.5 text-right text-red-600 dark:text-red-400 font-medium">
                          {tx.errorRate.toFixed(1)}%
                        </td>
                        <td className="px-3 py-1.5 text-right">
                          {formatNumber(tx.errorCount)}
                        </td>
                        <td className="px-3 py-1.5 text-right text-muted-foreground">
                          {formatNumber(tx.totalCount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {topErrors.length === 0 && topSlow.length > 0 && (
          <Card className="border-dashed border-2 border-emerald-200/50 dark:border-emerald-800/30">
            <CardContent className="py-8 text-center">
              <div className="text-emerald-500 text-sm font-medium">No Errors Detected</div>
              <p className="text-xs text-muted-foreground mt-1">All transactions are passing</p>
            </CardContent>
          </Card>
        )}
      </div>

      {snapshot.series && snapshot.series.length > 2 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <LatencyStabilityChart timeseries={snapshot.series} />
          <ErrorRateOverTime timeseries={snapshot.series} />
        </div>
      )}

      {snapshot.series && snapshot.series.length > 2 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <ThroughputLatencyCorrelation timeseries={snapshot.series} />
          <ActiveUsersTimeline timeseries={snapshot.series} />
        </div>
      )}

      {allTransactions.length > 1 && (
        <TransactionPerformanceChart transactionDetails={allTransactions.map(tx => ({ ...tx, errorCount: tx.errors || 0 }))} />
      )}

      {allTransactions.length > 1 && (
        <TransactionErrorBreakdown transactionDetails={allTransactions.map(tx => ({ ...tx, errorCount: tx.errors || 0 }))} />
      )}

      {(systemMetrics?.latest || sysChartData.length > 2) && (
        <Card className="card-shadow border border-border/40">
          <CardHeader className="pb-2 pt-4 px-5">
            <CardTitle className="text-sm font-semibold text-foreground flex items-center gap-2">
              <div className="p-1.5 rounded-md bg-orange-500/10"><Cpu className="w-4 h-4 text-orange-500" /></div>
              System Resources
              {systemMetrics?.latest && (
                <div className="flex items-center gap-3 ml-auto">
                  <span className="text-xs font-normal" style={{ color: DT_COLORS.cpu }}>CPU {systemMetrics.latest.cpuPercent.toFixed(1)}%</span>
                  <span className="text-xs font-normal" style={{ color: DT_COLORS.memory }}>Mem {systemMetrics.latest.memPercent.toFixed(1)}%</span>
                </div>
              )}
            </CardTitle>
          </CardHeader>
          {sysChartData.length > 2 && (
            <CardContent className="px-3 pb-3">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="h-[220px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={sysChartData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                      <DynatraceGradients />
                      <CartesianGrid {...DT_GRID_PROPS} vertical={false} />
                      <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" dy={4} />
                      <YAxis {...DT_AXIS_PROPS} axisLine={false} width={42} domain={[0, 100]} unit="%" />
                      <Tooltip cursor={DT_CURSOR_PROPS} contentStyle={DT_TOOLTIP_STYLE} labelStyle={{ fontWeight: 600, marginBottom: 4, color: "hsl(var(--foreground))" }} />
                      <Legend verticalAlign="top" align="right" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }} />
                      <Area type="monotone" dataKey="cpuPercent" name="Host CPU %" stroke={DT_COLORS.cpu} strokeWidth={2} fill="url(#dt-grad-orange)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} />
                      <Area type="monotone" dataKey="jmeterCpu" name="JMeter CPU %" stroke={DT_COLORS.jmeterCpu} strokeWidth={2} fill="url(#dt-grad-purple)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                <div className="h-[220px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={sysChartData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                      <DynatraceGradients />
                      <CartesianGrid {...DT_GRID_PROPS} vertical={false} />
                      <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" dy={4} />
                      <YAxis {...DT_AXIS_PROPS} axisLine={false} width={42} domain={[0, 100]} unit="%" />
                      <Tooltip cursor={DT_CURSOR_PROPS} contentStyle={DT_TOOLTIP_STYLE} labelStyle={{ fontWeight: 600, marginBottom: 4, color: "hsl(var(--foreground))" }} />
                      <Legend verticalAlign="top" align="right" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }} />
                      <Area type="monotone" dataKey="memPercent" name="Memory %" stroke={DT_COLORS.memory} strokeWidth={2} fill="url(#dt-grad-primary)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </CardContent>
          )}
        </Card>
      )}

    </div>
  );
}

function MetricCard({
  icon,
  label,
  value,
  unit,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  unit: string;
  color: string;
}) {
  return (
    <Card className="card-shadow">
      <CardContent className="p-3">
        <div className="flex items-center gap-1.5 mb-1">
          <span style={{ color }}>{icon}</span>
          <span className="text-xs text-muted-foreground">{label}</span>
        </div>
        <div className="flex items-baseline gap-1">
          <span className="text-xl font-bold" style={{ color }}>{value}</span>
          {unit && <span className="text-xs text-muted-foreground">{unit}</span>}
        </div>
      </CardContent>
    </Card>
  );
}
