import { Link, useLocation } from "wouter";
import { ChevronRight, Home } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/lib/query-keys";

interface BreadcrumbItem {
  label: string;
  href?: string;
}

const routeLabels: Record<string, string> = {
  "": "Dashboard",
  "scripts": "Scripts",
  "schedule": "Schedule & Calendar",
  "executions": "Executions",
  "comparison": "Comparison",
  "trends": "Trends",
  "reports": "HTML Reports",
  "completion-reports": "Sign-Off Reports",
  "new": "New Report",
  "tracker": "Tracker",
  "dumps": "Dump Analyzer",
  "platform": "Platform Settings",
  "general": "General",
  "users": "Users",
  "distributed": "Distributed Testing",
  "retention": "Data Retention",
  "admin": "Admin",
  "settings": "Settings",
  "ingest-tokens": "Ingest Tokens",
  "distributed-testing": "Distributed Testing",
  "calendar": "Calendar",
  "notifications": "Notifications",
  "compare": "Compare",
};

function useDynamicLabel(segment: string, parentSegment: string): string | null {
  const isNumericId = /^\d+$/.test(segment);

  const { data: scriptName } = useQuery({
    queryKey: queryKeys.scripts.breadcrumbName(segment),
    queryFn: async () => {
      const res = await fetch(`/api/scripts/${segment}`, { credentials: "include" });
      if (!res.ok) return null;
      const data = await res.json();
      return data.name || null;
    },
    enabled: isNumericId && parentSegment === "scripts",
    staleTime: 60000,
  });

  const { data: executionName } = useQuery({
    queryKey: queryKeys.executions.breadcrumbName(segment),
    queryFn: async () => {
      const res = await fetch(`/api/executions/${segment}`, { credentials: "include" });
      if (!res.ok) return null;
      const data = await res.json();
      return data.executionId || null;
    },
    enabled: isNumericId && parentSegment === "executions",
    staleTime: 60000,
  });

  const { data: dumpName } = useQuery({
    queryKey: queryKeys.dumps.breadcrumbName(segment),
    queryFn: async () => {
      const res = await fetch(`/api/dumps/${segment}`, { credentials: "include" });
      if (!res.ok) return null;
      const data = await res.json();
      return data.name || null;
    },
    enabled: isNumericId && parentSegment === "dumps",
    staleTime: 60000,
  });

  const { data: completionReportTitle } = useQuery({
    queryKey: queryKeys.completionReports.breadcrumbName(segment),
    queryFn: async () => {
      const res = await fetch(`/api/completion-reports/${segment}`, { credentials: "include" });
      if (!res.ok) return null;
      const data = await res.json();
      return data.title || null;
    },
    enabled: isNumericId && parentSegment === "completion-reports",
    staleTime: 60000,
  });

  if (parentSegment === "scripts" && scriptName) return scriptName;
  if (parentSegment === "executions" && executionName) return executionName;
  if (parentSegment === "dumps" && dumpName) return dumpName;
  if (parentSegment === "completion-reports" && completionReportTitle) return completionReportTitle;
  
  if (parentSegment === "platform") {
    const platformRoutes: Record<string, string> = {
      "general": "General",
      "users": "Users",
      "distributed": "Distributed Testing",
      "retention": "Data Retention",
    };
    if (platformRoutes[segment]) return platformRoutes[segment];
  }

  if (parentSegment === "admin") {
    const adminRoutes: Record<string, string> = {
      "users": "User Management",
      "settings": "Email Settings",
      "distributed-testing": "Distributed Testing",
    };
    if (adminRoutes[segment]) return adminRoutes[segment];
  }
  
  return null;
}

function BreadcrumbSegment({ segment, parentSegment }: { segment: string; parentSegment: string }) {
  const dynamicLabel = useDynamicLabel(segment, parentSegment);
  
  if (dynamicLabel) {
    return <span className="truncate max-w-[200px]">{dynamicLabel}</span>;
  }
  
  return <span>{routeLabels[segment] || segment}</span>;
}

export function Breadcrumbs() {
  const [location] = useLocation();

  if (location === "/") return null;

  const segments = location.split("/").filter(Boolean);
  const items: BreadcrumbItem[] = [{ label: "Dashboard", href: "/" }];

  const nonClickableParents = new Set(["platform"]);
  const adminSubRoutes = new Set(["users", "retention"]);

  segments.forEach((segment, index) => {
    const href = "/" + segments.slice(0, index + 1).join("/");
    const isLast = index === segments.length - 1;
    const isNonClickable = nonClickableParents.has(segment) && !isLast;
    let label = segment;
    if (segment === "platform" && !isLast) {
      const nextSegment = segments[index + 1];
      if (nextSegment && adminSubRoutes.has(nextSegment)) {
        label = "admin";
      }
    }
    items.push({
      label,
      href: isLast || isNonClickable ? undefined : href,
    });
  });

  return (
    <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4 min-h-[28px]">
      {items.map((item, index) => {
        const isLast = index === items.length - 1;
        const parentSegment = index > 0 ? segments[index - 2] || "" : "";
        
        return (
          <span key={index} className="flex items-center gap-1.5">
            {index > 0 && <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground/50" />}
            {index === 0 ? (
              <Link href="/">
                <span className="flex items-center gap-1 hover:text-foreground transition-colors cursor-pointer">
                  <Home className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Dashboard</span>
                </span>
              </Link>
            ) : isLast ? (
              <span className="text-foreground font-medium">
                <BreadcrumbSegment segment={item.label} parentSegment={parentSegment} />
              </span>
            ) : (
              <Link href={item.href!}>
                <span className="hover:text-foreground transition-colors cursor-pointer">
                  <BreadcrumbSegment segment={item.label} parentSegment={parentSegment} />
                </span>
              </Link>
            )}
          </span>
        );
      })}
    </nav>
  );
}
