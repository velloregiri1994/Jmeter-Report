import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { ShieldAlert, Plus, Trash2, Pencil } from "lucide-react";

const METRICS = [
  { value: "errorRate", label: "Error Rate", unit: "%" },
  { value: "avgResponseTime", label: "Avg Response Time", unit: "ms" },
  { value: "p90", label: "P90 Response Time", unit: "ms" },
  { value: "p95", label: "P95 Response Time", unit: "ms" },
  { value: "p99", label: "P99 Response Time", unit: "ms" },
  { value: "maxResponseTime", label: "Max Response Time", unit: "ms" },
  { value: "throughput", label: "Throughput", unit: "req/s" },
];

const COMPARATORS = [
  { value: "gt", label: ">" },
  { value: "gte", label: "≥" },
  { value: "lt", label: "<" },
  { value: "lte", label: "≤" },
];

type AutoAbortRule = {
  id: number;
  scriptId: number;
  metric: string;
  comparator: string;
  threshold: number;
  sustainedSeconds: number;
  isEnabled: boolean;
  createdBy: number;
  createdAt: string;
  updatedAt: string;
};

export function AutoAbortRulesSection({ scriptId, canWrite = true }: { scriptId: number; canWrite?: boolean }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [createOpen, setCreateOpen] = useState(false);
  const [editRule, setEditRule] = useState<AutoAbortRule | null>(null);

  const { data: rules = [], isLoading } = useQuery<AutoAbortRule[]>({
    queryKey: ["autoAbortRules", scriptId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/scripts/${scriptId}/auto-abort-rules`);
      return res.json();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/scripts/${scriptId}/auto-abort-rules/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["autoAbortRules", scriptId] });
      toast({ title: "Auto-abort rule deleted" });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, isEnabled }: { id: number; isEnabled: boolean }) =>
      apiRequest("PUT", `/api/scripts/${scriptId}/auto-abort-rules/${id}`, { isEnabled }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["autoAbortRules", scriptId] });
    },
  });

  const getMetricLabel = (metric: string) => METRICS.find(m => m.value === metric)?.label || metric;
  const getMetricUnit = (metric: string) => METRICS.find(m => m.value === metric)?.unit || "";
  const getComparatorLabel = (comp: string) => COMPARATORS.find(c => c.value === comp)?.label || comp;

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-muted/30 border-b">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <ShieldAlert className="w-5 h-5 text-rose-500" />
              Auto-Abort Rules
            </CardTitle>
            <CardDescription className="text-xs mt-1">
              Automatically stop tests when metrics breach thresholds for a sustained period
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-[10px]">
              {rules.filter(r => r.isEnabled).length} active
            </Badge>
            {canWrite && (
              <Dialog open={createOpen} onOpenChange={setCreateOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" variant="outline">
                    <Plus className="w-4 h-4 mr-1" /> Add Rule
                  </Button>
                </DialogTrigger>
                <RuleFormDialog
                  scriptId={scriptId}
                  onClose={() => setCreateOpen(false)}
                />
              </Dialog>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2 py-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : rules.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <ShieldAlert className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p>No auto-abort rules configured.</p>
            <p className="text-sm mt-1">Add rules to automatically stop tests when thresholds are breached.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Metric</TableHead>
                  <TableHead>Condition</TableHead>
                  <TableHead>Sustained</TableHead>
                  <TableHead className="text-center">Enabled</TableHead>
                  <TableHead className="w-20"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rules.map((rule) => (
                  <TableRow key={rule.id}>
                    <TableCell className="font-medium text-sm">{getMetricLabel(rule.metric)}</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center gap-1 font-mono text-sm">
                        {getComparatorLabel(rule.comparator)} {rule.threshold}
                        <span className="text-xs text-muted-foreground">{getMetricUnit(rule.metric)}</span>
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{rule.sustainedSeconds}s</TableCell>
                    <TableCell className="text-center">
                      <Switch
                        checked={rule.isEnabled}
                        onCheckedChange={(checked) => toggleMutation.mutate({ id: rule.id, isEnabled: checked })}
                        disabled={!canWrite}
                      />
                    </TableCell>
                    {canWrite && (
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Dialog open={editRule?.id === rule.id} onOpenChange={(open) => !open && setEditRule(null)}>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditRule(rule)}>
                                <Pencil className="w-3.5 h-3.5" />
                              </Button>
                            </DialogTrigger>
                            {editRule?.id === rule.id && (
                              <RuleFormDialog
                                scriptId={scriptId}
                                rule={editRule}
                                onClose={() => setEditRule(null)}
                              />
                            )}
                          </Dialog>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-destructive"
                            onClick={() => deleteMutation.mutate(rule.id)}
                            disabled={deleteMutation.isPending}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function RuleFormDialog({
  scriptId,
  rule,
  onClose,
}: {
  scriptId: number;
  rule?: AutoAbortRule;
  onClose: () => void;
}) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEdit = !!rule;

  const [metric, setMetric] = useState(rule?.metric || "errorRate");
  const [comparator, setComparator] = useState(rule?.comparator || "gt");
  const [threshold, setThreshold] = useState(rule?.threshold?.toString() || "");
  const [sustainedSeconds, setSustainedSeconds] = useState(rule?.sustainedSeconds?.toString() || "30");
  const [isEnabled, setIsEnabled] = useState(rule?.isEnabled !== false);

  const mutation = useMutation({
    mutationFn: (data: any) => {
      if (isEdit) {
        return apiRequest("PUT", `/api/scripts/${scriptId}/auto-abort-rules/${rule!.id}`, data);
      }
      return apiRequest("POST", `/api/scripts/${scriptId}/auto-abort-rules`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["autoAbortRules", scriptId] });
      toast({ title: isEdit ? "Rule updated" : "Rule created" });
      onClose();
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const thresholdNum = parseFloat(threshold);
    if (isNaN(thresholdNum)) return;

    mutation.mutate({
      metric,
      comparator,
      threshold: thresholdNum,
      sustainedSeconds: parseInt(sustainedSeconds) || 30,
      isEnabled,
    });
  };

  const selectedMetric = METRICS.find(m => m.value === metric);

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>{isEdit ? "Edit Auto-Abort Rule" : "Add Auto-Abort Rule"}</DialogTitle>
        <DialogDescription>
          {isEdit
            ? "Modify the conditions for this auto-abort rule."
            : "Define when a running test should be automatically stopped."}
        </DialogDescription>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label>Metric</Label>
          <Select value={metric} onValueChange={setMetric}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {METRICS.map(m => (
                <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>Comparator</Label>
            <Select value={comparator} onValueChange={setComparator}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {COMPARATORS.map(c => (
                  <SelectItem key={c.value} value={c.value}>
                    {c.label} ({c.value === "gt" ? "greater than" : c.value === "gte" ? "greater or equal" : c.value === "lt" ? "less than" : "less or equal"})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Threshold ({selectedMetric?.unit})</Label>
            <Input
              type="number"
              placeholder={`e.g. ${metric === "errorRate" ? "5" : metric === "throughput" ? "100" : "3000"}`}
              value={threshold}
              onChange={(e) => setThreshold(e.target.value)}
              required
              min={0}
              step="any"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Sustained Duration (seconds)</Label>
          <Input
            type="number"
            placeholder="30"
            value={sustainedSeconds}
            onChange={(e) => setSustainedSeconds(e.target.value)}
            min={1}
            required
          />
          <p className="text-xs text-muted-foreground">
            The threshold must be breached continuously for this duration before aborting.
          </p>
        </div>

        <div className="flex items-center justify-between">
          <Label>Enabled</Label>
          <Switch checked={isEnabled} onCheckedChange={setIsEnabled} />
        </div>

        <DialogFooter>
          <Button type="submit" disabled={mutation.isPending || !threshold}>
            {mutation.isPending ? "Saving..." : isEdit ? "Update Rule" : "Create Rule"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}
