import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { PageHeader } from "@/components/page-header";
import { format } from "date-fns";
import {
  ArrowLeft, Save, RefreshCw, Activity,
  Shield, Pencil, FileText, Download,
  TrendingUp, Hash, Timer, Layers,
  AlertOctagon, Gauge,
  UserCheck, Eye
} from "lucide-react";
import {
  ResponsiveContainer, RadialBarChart, RadialBar
} from "recharts";
import { DT_COLORS } from "@/components/charts/dynatrace-theme";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { Skeleton } from "@/components/ui/skeleton";

import { getVerdictConfig } from "./components/report-detail-utils";
import { ApprovalWorkflowPanel } from "./components/approval-workflow-panel";
import { RequestReviewDialog } from "./components/request-review-dialog";
import { ExecutiveSummaryTab } from "./components/executive-summary-tab";
import { TestResultsTab } from "./components/test-results-tab";
import { SlaComplianceTab } from "./components/sla-compliance-tab";
import { RunComparisonTab } from "./components/run-comparison-tab";
import { TransactionsTab } from "./components/transactions-tab";

export default function CompletionReportDetail() {
  const [, params] = useRoute("/completion-reports/:id");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, canWrite } = useAuth();
  const reportId = parseInt(params?.id || "0");
  const [editing, setEditing] = useState(false);
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [selectedReviewers, setSelectedReviewers] = useState<number[]>([]);
  const [approvalComment, setApprovalComment] = useState("");

  const { data: report, isLoading, isError, error, refetch } = useQuery<any>({
    queryKey: [...queryKeys.completionReports.detail(reportId)],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/completion-reports/${reportId}`);
      return res.json();
    },
    enabled: reportId > 0,
  });

  const [editData, setEditData] = useState<any>(null);

  const startEditing = () => {
    setEditData({
      title: report.title,
      objective: report.objective || '',
      scope: report.scope || '',
      environmentNotes: report.environmentNotes || '',
      recommendations: report.recommendations || '',
      overallVerdict: report.overallVerdict || 'pending',
      verdictNotes: report.verdictNotes || '',
      status: report.status,
    });
    setEditing(true);
  };

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", `/api/completion-reports/${reportId}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.detail(reportId) });
      setEditing(false);
      toast({ title: "Report updated" });
    },
  });

  const refreshMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/completion-reports/${reportId}/refresh-snapshot`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.detail(reportId) });
      toast({ title: "Report data refreshed from latest execution results" });
    },
  });

  const { data: approvals = [] } = useQuery<any[]>({
    queryKey: [...queryKeys.completionReports.approvals(reportId)],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/completion-reports/${reportId}/approvals`);
      return res.json();
    },
    enabled: reportId > 0,
  });

  const { data: allUsers = [] } = useQuery<any[]>({
    queryKey: ["completion-reports", "reviewers"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/completion-reports/reviewers");
      return res.json();
    },
  });

  const requestReviewMutation = useMutation({
    mutationFn: async (reviewers: number[]) => {
      const res = await apiRequest("POST", `/api/completion-reports/${reportId}/request-review`, { reviewers });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.detail(reportId) });
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.approvals(reportId) });
      setShowReviewDialog(false);
      setSelectedReviewers([]);
      toast({ title: "Review requested", description: "Reviewers have been notified" });
    },
    onError: (err: Error) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const approvalActionMutation = useMutation({
    mutationFn: async ({ approvalId, action, comment }: { approvalId: number; action: string; comment?: string }) => {
      const res = await apiRequest("POST", `/api/completion-reports/${reportId}/approvals/${approvalId}`, { action, comment });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.detail(reportId) });
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.approvals(reportId) });
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.all });
      setApprovalComment("");
      toast({ title: "Review submitted" });
    },
    onError: (err: Error) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const cancelReviewMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/completion-reports/${reportId}/approvals`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.detail(reportId) });
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.approvals(reportId) });
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.all });
      toast({ title: "Review cancelled" });
    },
  });

  const handleDownloadReport = async () => {
    const res = await fetch(`/api/completion-reports/${reportId}/docx`, { credentials: 'include' });
    if (res.ok) {
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `signoff-report-${reportId}.docx`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      toast({ title: 'Error', description: 'Failed to export report', variant: 'destructive' });
    }
  };

  if (isLoading) {
    return (
      <div className="section-gap">
        <div className="space-y-4">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-48 w-full rounded-xl" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  if (isError) return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load report" />;

  if (!report) {
    return (
      <div className="section-gap">
        <div className="text-center py-16">
          <h3 className="text-lg font-semibold">Report not found</h3>
          <Button variant="outline" className="mt-4" onClick={() => navigate("/completion-reports")}>
            <ArrowLeft className="h-4 w-4 mr-2" />Back to Reports
          </Button>
        </div>
      </div>
    );
  }

  const snapshot = report.reportSnapshot;
  const sections = snapshot?.sections || [];
  const sla = snapshot?.consolidatedSla;

  const totalRequests = sections.reduce((s: number, sec: any) => s + (sec.totalRequests || 0), 0);
  const totalFailed = sections.reduce((s: number, sec: any) => s + (sec.failedRequests || 0), 0);
  const avgRT = sections.length > 0 ? (sections.reduce((s: number, sec: any) => s + (sec.avgResponseTime || 0), 0) / sections.length) : 0;
  const avgThroughput = sections.length > 0 ? (sections.reduce((s: number, sec: any) => s + (sec.throughput || 0), 0) / sections.length) : 0;
  const overallErrorRate = totalRequests > 0 ? (totalFailed / totalRequests * 100) : 0;
  const slaViolations = sla?.violations?.length || 0;
  const slaPassed = sla?.passed || 0;
  const slaTotal = slaPassed + (sla?.failed || 0);
  const avgP95 = sections.length > 0 ? (sections.reduce((s: number, sec: any) => s + (sec.p95 || sec.avgResponseTime || 0), 0) / sections.length) : 0;

  let healthScore = 100;
  if (overallErrorRate > 5) healthScore -= 40;
  else if (overallErrorRate > 1) healthScore -= 20;
  else if (overallErrorRate > 0.1) healthScore -= 5;
  healthScore -= Math.min(slaViolations * 10, 40);
  healthScore = Math.max(0, Math.min(100, healthScore));

  const verdictConfig = getVerdictConfig(report.overallVerdict);
  const VerdictIcon = verdictConfig.icon;

  return (
    <div className="section-gap">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>

      <PageHeader
        title={report.title}
        subtitle={[report.projectName, report.featureName].filter(Boolean).join(" / ") || "Performance Sign-Off Report"}
        actions={
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outline" size="sm" onClick={() => navigate("/completion-reports")}>
              <ArrowLeft className="h-4 w-4 mr-1" />Back
            </Button>
            <Button variant="outline" size="sm" onClick={() => refreshMutation.mutate()} disabled={refreshMutation.isPending}>
              <RefreshCw className={`h-4 w-4 mr-1 ${refreshMutation.isPending ? 'animate-spin' : ''}`} />Refresh
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownloadReport}>
              <Download className="h-4 w-4 mr-1" />Export Word
            </Button>
            {canWrite && !editing ? (
              <Button size="sm" onClick={startEditing}>
                <Pencil className="h-4 w-4 mr-1" />Edit
              </Button>
            ) : canWrite && editing ? (
              <>
                <Button variant="outline" size="sm" onClick={() => setEditing(false)}>Cancel</Button>
                <Button size="sm" onClick={() => updateMutation.mutate(editData)} disabled={updateMutation.isPending}>
                  <Save className="h-4 w-4 mr-1" />{updateMutation.isPending ? 'Saving...' : 'Save'}
                </Button>
              </>
            ) : null}
          </div>
        }
      />

      <div className={`rounded-xl border ${verdictConfig.border} bg-gradient-to-r ${verdictConfig.gradient} p-5 sm:p-6`} style={{ animation: 'fadeSlideIn 0.4s ease-out both' }}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className={`flex items-center justify-center w-16 h-16 rounded-xl ${verdictConfig.bg} border ${verdictConfig.border}`} style={{ animation: 'scaleIn 0.5s ease-out 0.2s both' }}>
            <VerdictIcon className={`h-8 w-8 ${verdictConfig.color}`} />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3 flex-wrap">
              <span className={`text-2xl font-bold tracking-tight ${verdictConfig.color}`}>
                {verdictConfig.label}
              </span>
              <Badge variant={report.status === 'finalized' ? 'default' : 'secondary'} className="text-xs">
                {report.status === 'finalized' ? 'Finalized' : 'Draft'}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mt-0.5">{verdictConfig.subtitle}</p>
            {report.verdictNotes && (
              <p className="text-sm mt-1.5 italic text-muted-foreground">"{report.verdictNotes}"</p>
            )}
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
            <span>{sections.length} test type(s)</span>
            <span className="hidden sm:inline">&middot;</span>
            <span>Created {report.createdAt ? format(new Date(report.createdAt), "MMM d, yyyy") : ''}</span>
            {snapshot?.generatedAt && (
              <>
                <span className="hidden sm:inline">&middot;</span>
                <span className="text-xs">Snapshot: {format(new Date(snapshot.generatedAt), "MMM d, h:mm a")}</span>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-4" style={{ animation: 'fadeSlideIn 0.3s ease-out 0.1s both' }}>
        <Card className="flex flex-col items-center justify-center p-5">
          <div className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground mb-2">Health Score</div>
          <div className="w-[160px] h-[120px]">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart
                cx="50%" cy="100%" innerRadius="70%" outerRadius="100%"
                startAngle={180} endAngle={0}
                data={[{ value: healthScore, fill: healthScore >= 80 ? DT_COLORS.green : healthScore >= 50 ? DT_COLORS.amber : DT_COLORS.red }]}
              >
                <RadialBar dataKey="value" background={{ fill: 'hsl(var(--muted))' }} cornerRadius={6} />
              </RadialBarChart>
            </ResponsiveContainer>
          </div>
          <div className={`text-3xl font-bold -mt-4 ${healthScore >= 80 ? 'text-emerald-600' : healthScore >= 50 ? 'text-amber-600' : 'text-red-600'}`}>
            {healthScore}%
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            {healthScore >= 90 ? 'Excellent' : healthScore >= 80 ? 'Good' : healthScore >= 60 ? 'Fair' : healthScore >= 40 ? 'Poor' : 'Critical'}
          </div>
          {slaTotal > 0 && (
            <div className="mt-3 w-full">
              <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                <span>SLA Compliance</span>
                <span>{slaPassed}/{slaTotal}</span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div className={`h-full rounded-full transition-all ${sla?.failed === 0 ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${(slaPassed / slaTotal) * 100}%` }} />
              </div>
            </div>
          )}
        </Card>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Test Types', value: sections.length, sub: `${sections.filter((s: any) => s.status === 'completed').length} completed`, icon: Layers, color: 'text-indigo-600 dark:text-indigo-400' },
            { label: 'Total Requests', value: totalRequests > 999999 ? `${(totalRequests / 1000000).toFixed(1)}M` : totalRequests > 999 ? `${(totalRequests / 1000).toFixed(1)}K` : totalRequests.toLocaleString(), sub: `${totalFailed.toLocaleString()} failed`, icon: Hash, color: 'text-blue-600 dark:text-blue-400' },
            { label: 'Error Rate', value: `${overallErrorRate.toFixed(2)}%`, sub: overallErrorRate < 0.1 ? 'Within target' : overallErrorRate < 1 ? 'Acceptable' : 'Above threshold', icon: AlertOctagon, color: overallErrorRate > 1 ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400' },
            { label: 'Avg Response', value: `${avgRT.toFixed(0)}ms`, sub: `P95: ${avgP95.toFixed(0)}ms`, icon: Timer, color: 'text-orange-600 dark:text-orange-400' },
            { label: 'P95 Latency', value: `${avgP95.toFixed(0)}ms`, sub: sections.length > 1 ? `across ${sections.length} tests` : '', icon: Gauge, color: 'text-purple-600 dark:text-purple-400' },
            { label: 'Throughput', value: `${avgThroughput.toFixed(1)}/s`, sub: `${totalRequests.toLocaleString()} total`, icon: TrendingUp, color: 'text-teal-600 dark:text-teal-400' },
            { label: 'SLA Violations', value: slaViolations, sub: slaViolations === 0 ? 'All passed' : `${slaViolations} breach(es)`, icon: Shield, color: slaViolations === 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400' },
            { label: 'Approval', value: approvals.filter((a: any) => a.status === 'approved').length + '/' + approvals.length, sub: report.reviewStatus === 'approved' ? 'Signed off' : report.reviewStatus === 'in_review' ? 'In review' : 'Draft', icon: UserCheck, color: report.reviewStatus === 'approved' ? 'text-emerald-600 dark:text-emerald-400' : 'text-blue-600 dark:text-blue-400' },
          ].map((kpi, i) => {
            const KpiIcon = kpi.icon;
            return (
              <div key={i} className="rounded-lg border bg-card p-3" style={{ animation: `fadeSlideIn 0.3s ease-out ${0.1 + i * 0.03}s both` }}>
                <div className="flex items-center gap-2 mb-2">
                  <KpiIcon className={`h-3.5 w-3.5 ${kpi.color}`} />
                  <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">{kpi.label}</span>
                </div>
                <div className={`text-xl font-bold ${kpi.color}`}>{kpi.value}</div>
                {kpi.sub && <div className="text-[10px] text-muted-foreground mt-0.5">{kpi.sub}</div>}
              </div>
            );
          })}
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="flex-wrap">
          <TabsTrigger value="overview">Executive Summary</TabsTrigger>
          <TabsTrigger value="results">Test Results</TabsTrigger>
          <TabsTrigger value="sla">SLA Compliance</TabsTrigger>
          {snapshot?.runComparison && <TabsTrigger value="run-comparison">Run Comparison</TabsTrigger>}
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="preview" className="gap-1.5">
            <FileText className="h-3.5 w-3.5" />
            Document Preview
          </TabsTrigger>
          <TabsTrigger value="approvals" className="gap-1.5">
            <UserCheck className="h-3.5 w-3.5" />
            Approvals
            {approvals.length > 0 && (
              <Badge variant="secondary" className="ml-1 text-[10px] h-4 px-1">{approvals.filter((a: any) => a.status === "approved").length}/{approvals.length}</Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <ExecutiveSummaryTab editing={editing} editData={editData} setEditData={setEditData} report={report} sections={sections} />
        </TabsContent>

        <TabsContent value="results" className="space-y-4">
          <TestResultsTab sections={sections} />
        </TabsContent>

        <TabsContent value="sla" className="space-y-4">
          <SlaComplianceTab sla={sla} sections={sections} slaPassed={slaPassed} slaTotal={slaTotal} />
        </TabsContent>

        {snapshot?.runComparison && (
          <TabsContent value="run-comparison" className="space-y-4">
            <RunComparisonTab snapshot={snapshot} />
          </TabsContent>
        )}

        <TabsContent value="transactions" className="space-y-4">
          <TransactionsTab sections={sections} />
        </TabsContent>

        <TabsContent value="preview" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Eye className="h-4 w-4" />Document Preview
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={handleDownloadReport}>
                    <Download className="h-4 w-4 mr-1" />Download Word
                  </Button>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">Preview of the generated document. The downloaded Word file will have the same content with professional formatting and charts.</p>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden bg-white" style={{ minHeight: '600px' }}>
                <iframe
                  src={`/api/completion-reports/${reportId}/preview`}
                  className="w-full border-0"
                  style={{ minHeight: '800px', height: '100%' }}
                  title="Report Preview"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="approvals" className="space-y-4">
          <ApprovalWorkflowPanel
            report={report}
            approvals={approvals}
            currentUser={user}
            onRequestReview={() => { setSelectedReviewers([]); setShowReviewDialog(true); }}
            onApprove={(approvalId) => approvalActionMutation.mutate({ approvalId, action: "approved", comment: approvalComment || undefined })}
            onReject={(approvalId) => approvalActionMutation.mutate({ approvalId, action: "rejected", comment: approvalComment || undefined })}
            onRequestChanges={(approvalId) => approvalActionMutation.mutate({ approvalId, action: "changes_requested", comment: approvalComment || undefined })}
            onCancelReview={() => cancelReviewMutation.mutate()}
            onDownloadReport={handleDownloadReport}
            approvalComment={approvalComment}
            setApprovalComment={setApprovalComment}
            isActing={approvalActionMutation.isPending}
            isCancelling={cancelReviewMutation.isPending}
          />
        </TabsContent>
      </Tabs>

      <RequestReviewDialog
        open={showReviewDialog}
        onOpenChange={setShowReviewDialog}
        allUsers={allUsers}
        currentUserId={user?.id}
        selectedReviewers={selectedReviewers}
        setSelectedReviewers={setSelectedReviewers}
        onSubmit={() => requestReviewMutation.mutate(selectedReviewers)}
        isSubmitting={requestReviewMutation.isPending}
      />
    </div>
  );
}
