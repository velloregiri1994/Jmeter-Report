import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Link, useLocation } from "wouter";
import { format } from "date-fns";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Plus, CheckCircle, XCircle, AlertTriangle,
  Clock, Trash2, Eye, ClipboardCheck, Search,
  Shield, Layers, UserCheck, RotateCcw,
  Pencil, Download, Save, Loader2,
  Upload, X, Send, Ban, Users, MessageCircle,
  ArrowUpRight, ArrowDownRight, LayoutTemplate,
  MoreVertical, Copy, Star, StarOff
} from "lucide-react";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";

type TemplateSection = {
  id: string;
  type: 'builtin' | 'custom';
  key?: string;
  title: string;
  defaultContent?: string;
  enabled: boolean;
};

type ReportTemplate = {
  id: number;
  name: string;
  description: string | null;
  sections: TemplateSection[];
  isDefault: boolean;
  createdBy: number;
  createdAt: string;
  updatedAt: string;
};

interface CompletionReport {
  id: number;
  title: string;
  projectName: string | null;
  featureName: string | null;
  overallVerdict: string | null;
  status: string;
  reviewStatus?: string | null;
  executionIds: number[];
  compareExecutionIds?: number[];
  reportSnapshot?: any;
  createdAt: string;
  updatedAt: string;
}

const IMG_MARKER_RE = /<<IMG:([^|]+)\|(data:image\/[^>]+)>>/g;

function ImagePreviewStrip({ text, onRemove }: { text: string; onRemove: (filename: string) => void }) {
  const images = useMemo(() => {
    const results: { name: string; dataUrl: string }[] = [];
    const re = new RegExp(IMG_MARKER_RE.source, 'g');
    let m: RegExpExecArray | null;
    while ((m = re.exec(text)) !== null) {
      results.push({ name: m[1], dataUrl: m[2] });
    }
    return results;
  }, [text]);
  if (images.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-2 mt-2">
      {images.map((img, i) => (
        <div key={i} className="relative group rounded-md border border-border overflow-hidden" style={{ width: 72, height: 54 }}>
          <img src={img.dataUrl} alt={img.name} className="w-full h-full object-cover" />
          <button type="button" onClick={() => onRemove(img.name)}
            className="absolute -top-0.5 -right-0.5 bg-destructive text-destructive-foreground rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity" title={`Remove ${img.name}`}>
            <X className="h-3 w-3" />
          </button>
          <div className="absolute bottom-0 left-0 right-0 bg-black/60 px-1 py-0.5 text-[9px] text-white truncate">{img.name}</div>
        </div>
      ))}
    </div>
  );
}

export default function CompletionReportsPage() {
  const { toast } = useToast();
  const { user, canWrite } = useAuth();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState('reports');
  const [reportSearch, setReportSearch] = useState('');
  const [verdictFilter, setVerdictFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingReport, setEditingReport] = useState<CompletionReport | null>(null);
  const [editData, setEditData] = useState<any>(null);

  const [approvalsDialogOpen, setApprovalsDialogOpen] = useState(false);
  const [approvalsReportId, setApprovalsReportId] = useState<number | null>(null);
  const [approvalsReport, setApprovalsReport] = useState<CompletionReport | null>(null);
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [selectedReviewers, setSelectedReviewers] = useState<number[]>([]);
  const [approvalComment, setApprovalComment] = useState("");

  const [deleteTemplateId, setDeleteTemplateId] = useState<number | null>(null);

  const { data: templates = [], isLoading: templatesLoading } = useQuery<ReportTemplate[]>({
    queryKey: ["/api/report-templates"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/report-templates");
      return res.json();
    },
  });

  const deleteTemplateMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/report-templates/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/report-templates"] });
      toast({ title: "Template deleted" });
      setDeleteTemplateId(null);
    },
  });

  const duplicateTemplateMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/report-templates/${id}/duplicate`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/report-templates"] });
      toast({ title: "Template duplicated" });
    },
  });

  const setDefaultTemplateMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("PATCH", `/api/report-templates/${id}/default`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/report-templates"] });
      toast({ title: "Default template updated" });
    },
  });

  const { data: reports = [], isLoading: reportsLoading, isError, error, refetch } = useQuery<CompletionReport[]>({
    queryKey: [...queryKeys.completionReports.all],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/completion-reports");
      return res.json();
    },
  });

  const stats = useMemo(() => {
    const total = reports.length;
    const go = reports.filter(r => r.overallVerdict === 'go').length;
    const noGo = reports.filter(r => r.overallVerdict === 'no_go').length;
    const conditional = reports.filter(r => r.overallVerdict === 'conditional').length;
    const pending = reports.filter(r => !r.overallVerdict || r.overallVerdict === 'pending').length;
    const finalized = reports.filter(r => r.status === 'finalized').length;
    const draft = reports.filter(r => r.status === 'draft').length;
    return { total, go, noGo, conditional, pending, finalized, draft };
  }, [reports]);

  const filteredReports = useMemo(() => {
    return reports.filter(r => {
      const searchLower = reportSearch.toLowerCase();
      const matchesSearch = !reportSearch ||
        r.title.toLowerCase().includes(searchLower) ||
        (r.projectName || '').toLowerCase().includes(searchLower) ||
        (r.featureName || '').toLowerCase().includes(searchLower);
      const matchesVerdict = verdictFilter === 'all' || (r.overallVerdict || 'pending') === verdictFilter;
      const matchesStatus = statusFilter === 'all' || r.status === statusFilter;
      return matchesSearch && matchesVerdict && matchesStatus;
    });
  }, [reports, reportSearch, verdictFilter, statusFilter]);

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/completion-reports/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.all });
      toast({ title: "Report deleted" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const res = await apiRequest("PATCH", `/api/completion-reports/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.all });
      if (editingReport) {
        queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.detail(editingReport.id) });
      }
      setEditDialogOpen(false);
      setEditingReport(null);
      setEditData(null);
      toast({ title: "Report updated" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const { data: approvals = [] } = useQuery<any[]>({
    queryKey: [...queryKeys.completionReports.approvals(approvalsReportId || 0)],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/completion-reports/${approvalsReportId}/approvals`);
      return res.json();
    },
    enabled: approvalsDialogOpen && approvalsReportId !== null && approvalsReportId > 0,
  });

  const { data: allUsers = [] } = useQuery<any[]>({
    queryKey: ["completion-reports", "reviewers"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/completion-reports/reviewers");
      return res.json();
    },
    enabled: approvalsDialogOpen || showReviewDialog,
  });

  const requestReviewMutation = useMutation({
    mutationFn: async ({ reportId, reviewers }: { reportId: number; reviewers: number[] }) => {
      const res = await apiRequest("POST", `/api/completion-reports/${reportId}/request-review`, { reviewers });
      return res.json();
    },
    onSuccess: () => {
      if (approvalsReportId) {
        queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.detail(approvalsReportId) });
        queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.approvals(approvalsReportId) });
      }
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.all });
      setShowReviewDialog(false);
      setSelectedReviewers([]);
      toast({ title: "Review requested", description: "Reviewers have been notified" });
    },
    onError: (err: Error) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const approvalActionMutation = useMutation({
    mutationFn: async ({ reportId, approvalId, action, comment }: { reportId: number; approvalId: number; action: string; comment?: string }) => {
      const res = await apiRequest("POST", `/api/completion-reports/${reportId}/approvals/${approvalId}`, { action, comment });
      return res.json();
    },
    onSuccess: () => {
      if (approvalsReportId) {
        queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.detail(approvalsReportId) });
        queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.approvals(approvalsReportId) });
      }
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.all });
      setApprovalComment("");
      toast({ title: "Review submitted" });
    },
    onError: (err: Error) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const cancelReviewMutation = useMutation({
    mutationFn: async (reportId: number) => {
      const res = await apiRequest("DELETE", `/api/completion-reports/${reportId}/approvals`);
      return res.json();
    },
    onSuccess: () => {
      if (approvalsReportId) {
        queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.detail(approvalsReportId) });
        queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.approvals(approvalsReportId) });
      }
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.all });
      toast({ title: "Review cancelled" });
    },
  });

  const openEditDialog = async (report: CompletionReport) => {
    setEditingReport(report);
    setEditDialogOpen(true);
    try {
      const res = await apiRequest("GET", `/api/completion-reports/${report.id}`);
      const fullReport = await res.json();
      setEditData({
        title: fullReport.title || report.title,
        objective: fullReport.objective || '',
        scope: fullReport.scope || '',
        environmentNotes: fullReport.environmentNotes || '',
        recommendations: fullReport.recommendations || '',
        overallVerdict: fullReport.overallVerdict || 'pending',
        verdictNotes: fullReport.verdictNotes || '',
        status: fullReport.status || report.status,
      });
    } catch {
      setEditData({
        title: report.title,
        objective: '',
        scope: '',
        environmentNotes: '',
        recommendations: '',
        overallVerdict: report.overallVerdict || 'pending',
        verdictNotes: '',
        status: report.status,
      });
    }
  };

  const openApprovalsDialog = (report: CompletionReport) => {
    setApprovalsReportId(report.id);
    setApprovalsReport(report);
    setApprovalComment("");
    setApprovalsDialogOpen(true);
  };

  const handleExportDocx = async (reportId: number) => {
    try {
      const res = await fetch(`/api/completion-reports/${reportId}/docx`, { credentials: 'include' });
      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `signoff-report-${reportId}.docx`;
        a.click();
        URL.revokeObjectURL(url);
      } else {
        toast({ title: 'Error', description: 'Failed to export report', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Error', description: 'Failed to export report', variant: 'destructive' });
    }
  };

  const removeEditImage = (field: string, filename: string) => {
    setEditData((prev: any) => ({
      ...prev,
      [field]: ((prev[field] || '') as string).replace(new RegExp(`\\n?<<IMG:${filename.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\|[^>]+>>\\n?`, 'g'), '').trim()
    }));
  };

  const getVerdictConfig = (verdict: string | null) => {
    switch (verdict) {
      case 'go':
        return { label: 'Go', icon: CheckCircle, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800', strip: 'bg-emerald-500' };
      case 'no_go':
        return { label: 'No Go', icon: XCircle, color: 'text-red-600 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800', strip: 'bg-red-500' };
      case 'conditional':
        return { label: 'Conditional', icon: AlertTriangle, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800', strip: 'bg-amber-500' };
      default:
        return { label: 'Pending', icon: Clock, color: 'text-slate-500 dark:text-slate-400', bg: 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700', strip: 'bg-slate-400' };
    }
  };

  const getReportHealthScore = (report: CompletionReport) => {
    const snapshot = report.reportSnapshot;
    if (!snapshot?.sections?.length) return null;
    const sections = snapshot.sections;
    const totalReq = sections.reduce((s: number, sec: any) => s + (sec.totalRequests || 0), 0);
    const totalFailed = sections.reduce((s: number, sec: any) => s + (sec.failedRequests || 0), 0);
    const errorRate = totalReq > 0 ? (totalFailed / totalReq) * 100 : 0;
    const slaViolations = snapshot.consolidatedSla?.violations?.length || 0;
    let score = 100;
    if (errorRate > 5) score -= 40;
    else if (errorRate > 1) score -= 20;
    else if (errorRate > 0.1) score -= 5;
    score -= Math.min(slaViolations * 10, 40);
    return Math.max(0, Math.min(100, score));
  };

  if (isError) return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load sign-off reports" />;

  return (
    <div className="section-gap">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <PageHeader
        title="Sign-Off Reports"
        subtitle="Consolidated performance sign-off reports for stakeholder review and production readiness decisions"
        actions={
          activeTab === 'reports' ? (
            canWrite ? (
              <Link href="/completion-reports/new">
                <Button><Plus className="h-4 w-4 mr-2" />New Report</Button>
              </Link>
            ) : null
          ) : (
            canWrite ? (
              <Button className="gap-2" onClick={() => navigate("/report-templates/new")}>
                <Plus className="h-4 w-4" />
                Create Template
              </Button>
            ) : null
          )
        }
      />

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="reports" className="gap-1.5">
            <ClipboardCheck className="h-3.5 w-3.5" />
            Reports
          </TabsTrigger>
          <TabsTrigger value="templates" className="gap-1.5">
            <LayoutTemplate className="h-3.5 w-3.5" />
            Templates
            {templates.length > 0 && (
              <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px]">{templates.length}</Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-4 mt-4">

      {!reportsLoading && reports.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3" style={{ animation: 'fadeSlideIn 0.3s ease-out both' }}>
          <div className="rounded-xl border bg-card p-3 text-center">
            <div className="text-2xl font-bold">{stats.total}</div>
            <div className="text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Total</div>
          </div>
          <div className="rounded-xl border bg-emerald-50 dark:bg-emerald-950/30 p-3 text-center border-emerald-200 dark:border-emerald-800">
            <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{stats.go}</div>
            <div className="text-[11px] text-emerald-600/70 dark:text-emerald-400/70 uppercase tracking-wider font-medium">Go</div>
          </div>
          <div className="rounded-xl border bg-red-50 dark:bg-red-950/30 p-3 text-center border-red-200 dark:border-red-800">
            <div className="text-2xl font-bold text-red-600 dark:text-red-400">{stats.noGo}</div>
            <div className="text-[11px] text-red-600/70 dark:text-red-400/70 uppercase tracking-wider font-medium">No Go</div>
          </div>
          <div className="rounded-xl border bg-amber-50 dark:bg-amber-950/30 p-3 text-center border-amber-200 dark:border-amber-800">
            <div className="text-2xl font-bold text-amber-600 dark:text-amber-400">{stats.conditional}</div>
            <div className="text-[11px] text-amber-600/70 dark:text-amber-400/70 uppercase tracking-wider font-medium">Conditional</div>
          </div>
          <div className="rounded-xl border bg-slate-50 dark:bg-slate-800/30 p-3 text-center border-slate-200 dark:border-slate-700">
            <div className="text-2xl font-bold text-slate-500">{stats.pending}</div>
            <div className="text-[11px] text-slate-500/70 uppercase tracking-wider font-medium">Pending</div>
          </div>
          <div className="rounded-xl border bg-card p-3 text-center">
            <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{stats.finalized}</div>
            <div className="text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Finalized</div>
          </div>
          <div className="rounded-xl border bg-card p-3 text-center">
            <div className="text-2xl font-bold text-orange-500">{stats.draft}</div>
            <div className="text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Drafts</div>
          </div>
        </div>
      )}

      {!reportsLoading && reports.length > 0 && (
        <div className="flex items-center gap-3 flex-wrap" style={{ animation: 'fadeSlideIn 0.3s ease-out 0.1s both' }}>
          <div className="relative flex-1 min-w-[200px]">
            <Search className="h-4 w-4 absolute left-3 top-2.5 text-muted-foreground" />
            <Input
              placeholder="Search reports by title, project, or feature..."
              value={reportSearch}
              onChange={(e) => setReportSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={verdictFilter} onValueChange={setVerdictFilter}>
            <SelectTrigger className="w-[150px]"><SelectValue placeholder="All Verdicts" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Verdicts</SelectItem>
              <SelectItem value="go">Go</SelectItem>
              <SelectItem value="no_go">No Go</SelectItem>
              <SelectItem value="conditional">Conditional</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]"><SelectValue placeholder="All Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="finalized">Finalized</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="grid gap-4">
        {reportsLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <div className="flex">
                <Skeleton className="w-1.5 h-full" />
                <div className="flex-1 p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Skeleton className="h-5 w-5 rounded" />
                      <Skeleton className="h-5 w-56" />
                      <Skeleton className="h-5 w-16 rounded-full" />
                    </div>
                    <Skeleton className="h-8 w-20 rounded-md" />
                  </div>
                  <div className="flex items-center gap-3">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-28" />
                  </div>
                  <div className="flex items-center gap-2">
                    <Skeleton className="h-6 w-20 rounded-full" />
                    <Skeleton className="h-6 w-24 rounded-full" />
                  </div>
                </div>
              </div>
            </Card>
          ))
        ) : reports.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-16 border border-dashed rounded-xl bg-muted/20" style={{ animation: 'fadeSlideIn 0.4s ease-out both' }}>
            <div className="mb-4 rounded-full p-4" style={{ background: 'linear-gradient(135deg, hsl(var(--primary) / 0.12), hsl(var(--primary) / 0.04))' }}>
              <ClipboardCheck className="h-12 w-12 text-primary/60" />
            </div>
            <h3 className="text-lg font-semibold">No sign-off reports yet</h3>
            <p className="text-muted-foreground text-sm mt-1 text-center max-w-md">
              Create a sign-off report to combine results from multiple test types (load, endurance, stress, spike, soak) into a single consolidated document for stakeholder review.
            </p>
            {canWrite && (
              <Link href="/completion-reports/new">
                <Button className="mt-4">
                  <Plus className="h-4 w-4 mr-2" />Create Your First Report
                </Button>
              </Link>
            )}
          </div>
        ) : filteredReports.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Search className="h-8 w-8 mx-auto mb-2 opacity-40" />
            <p>No reports match your filters</p>
          </div>
        ) : (
          filteredReports.map((report, index) => {
            const verdict = getVerdictConfig(report.overallVerdict);
            const VerdictIcon = verdict.icon;
            const healthScore = getReportHealthScore(report);
            const snapshot = report.reportSnapshot;
            const sections = snapshot?.sections || [];
            const slaViolations = snapshot?.consolidatedSla?.violations?.length || 0;
            const slaPassed = snapshot?.consolidatedSla?.passed || 0;
            const slaFailed = snapshot?.consolidatedSla?.failed || 0;
            const slaTotal = slaPassed + slaFailed;
            const totalRequests = sections.reduce((s: number, sec: any) => s + (sec.totalRequests || 0), 0);
            const totalFailed = sections.reduce((s: number, sec: any) => s + (sec.failedRequests || 0), 0);
            const avgRT = sections.length > 0 ? (sections.reduce((s: number, sec: any) => s + (sec.avgResponseTime || 0), 0) / sections.length) : 0;
            const avgThroughput = sections.length > 0 ? (sections.reduce((s: number, sec: any) => s + (sec.throughput || 0), 0) / sections.length) : 0;
            const overallErrorRate = totalRequests > 0 ? (totalFailed / totalRequests * 100) : 0;
            const testTypes = Array.from(new Set(sections.map((s: any) => s.testType))) as string[];

            return (
              <Card
                key={report.id}
                className="overflow-hidden hover:shadow-lg transition-all duration-300 group"
                style={{ animation: `fadeSlideIn 0.3s ease-out ${index * 0.05}s both` }}
              >
                <div className="flex">
                  <div className={`w-1.5 ${verdict.strip} flex-shrink-0`} />
                  <div className="flex-1 p-4 sm:p-5">
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2.5 flex-wrap mb-1.5">
                          <Link href={`/completion-reports/${report.id}`}>
                            <span className="font-semibold text-base hover:text-primary cursor-pointer transition-colors">
                              {report.title}
                            </span>
                          </Link>
                          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold border ${verdict.bg} ${verdict.color}`}>
                            <VerdictIcon className="h-3.5 w-3.5" />
                            {verdict.label}
                          </div>
                          <Badge variant={report.status === 'finalized' ? 'default' : 'secondary'} className="text-xs">
                            {report.status === 'finalized' ? 'Finalized' : 'Draft'}
                          </Badge>
                          {report.reviewStatus && report.reviewStatus !== 'draft' && (
                            <Badge
                              variant="outline"
                              className={`text-[10px] gap-1 ${
                                report.reviewStatus === 'approved' ? 'border-emerald-300 text-emerald-600' :
                                report.reviewStatus === 'rejected' ? 'border-red-300 text-red-600' :
                                report.reviewStatus === 'changes_requested' ? 'border-amber-300 text-amber-600' :
                                'border-blue-300 text-blue-600'
                              }`}
                            >
                              {report.reviewStatus === 'approved' && <CheckCircle className="h-3 w-3" />}
                              {report.reviewStatus === 'rejected' && <XCircle className="h-3 w-3" />}
                              {report.reviewStatus === 'changes_requested' && <RotateCcw className="h-3 w-3" />}
                              {report.reviewStatus === 'in_review' && <UserCheck className="h-3 w-3" />}
                              {report.reviewStatus === 'approved' ? 'Approved' :
                               report.reviewStatus === 'rejected' ? 'Rejected' :
                               report.reviewStatus === 'changes_requested' ? 'Changes Requested' :
                               'In Review'}
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                          {report.projectName && <span className="flex items-center gap-1"><Layers className="h-3 w-3" />{report.projectName}</span>}
                          {report.featureName && <span>{report.featureName}</span>}
                          {testTypes.map((tt: string) => (
                            <Badge key={tt} variant="outline" className="text-[10px] font-normal h-5">{tt}</Badge>
                          ))}
                          {report.createdAt && (
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {format(new Date(report.createdAt), "MMM d, yyyy")}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        {canWrite && (
                          <Button variant="outline" size="sm" className="h-8 px-2.5 gap-1.5" onClick={() => openApprovalsDialog(report)}>
                            <UserCheck className="h-3.5 w-3.5" />Approvals
                          </Button>
                        )}
                        {canWrite && (
                          <Button variant="outline" size="sm" className="h-8 px-2.5 gap-1.5" onClick={() => openEditDialog(report)}>
                            <Pencil className="h-3.5 w-3.5" />Edit
                          </Button>
                        )}
                        <Button variant="outline" size="sm" className="h-8 px-2.5 gap-1.5" onClick={() => handleExportDocx(report.id)}>
                          <Download className="h-3.5 w-3.5" />Word
                        </Button>
                        <Button variant="outline" size="sm" className="h-8 px-2.5 gap-1.5" asChild>
                          <Link href={`/completion-reports/${report.id}`}>
                            <Eye className="h-3.5 w-3.5" />View
                          </Link>
                        </Button>
                        {canWrite && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive">
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Report</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete "{report.title}". This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => deleteMutation.mutate(report.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    </div>

                    {sections.length > 0 && (
                      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 pt-3 border-t">
                        <div className="p-2 rounded-lg bg-muted/30 text-center">
                          <div className="text-xs font-bold">{sections.length}</div>
                          <div className="text-[9px] text-muted-foreground uppercase tracking-wider">Tests</div>
                        </div>
                        <div className="p-2 rounded-lg bg-muted/30 text-center">
                          <div className="text-xs font-bold">{totalRequests > 999999 ? `${(totalRequests / 1000000).toFixed(1)}M` : totalRequests > 999 ? `${(totalRequests / 1000).toFixed(1)}K` : totalRequests}</div>
                          <div className="text-[9px] text-muted-foreground uppercase tracking-wider">Requests</div>
                        </div>
                        <div className="p-2 rounded-lg bg-muted/30 text-center">
                          <div className={`text-xs font-bold ${overallErrorRate > 1 ? 'text-red-600' : 'text-emerald-600'}`}>{overallErrorRate.toFixed(2)}%</div>
                          <div className="text-[9px] text-muted-foreground uppercase tracking-wider">Error Rate</div>
                        </div>
                        <div className="p-2 rounded-lg bg-muted/30 text-center">
                          <div className="text-xs font-bold">{avgRT.toFixed(0)}ms</div>
                          <div className="text-[9px] text-muted-foreground uppercase tracking-wider">Avg RT</div>
                        </div>
                        <div className="p-2 rounded-lg bg-muted/30 text-center">
                          <div className="text-xs font-bold">{avgThroughput.toFixed(1)}/s</div>
                          <div className="text-[9px] text-muted-foreground uppercase tracking-wider">TPS</div>
                        </div>
                        <div className="p-2 rounded-lg text-center" style={{ background: healthScore !== null ? (healthScore >= 80 ? 'rgba(16,185,129,0.1)' : healthScore >= 50 ? 'rgba(245,158,11,0.1)' : 'rgba(239,68,68,0.1)') : undefined }}>
                          <div className={`text-xs font-bold ${healthScore !== null ? (healthScore >= 80 ? 'text-emerald-600' : healthScore >= 50 ? 'text-amber-600' : 'text-red-600') : ''}`}>
                            {healthScore !== null ? `${healthScore}%` : 'N/A'}
                          </div>
                          <div className="text-[9px] text-muted-foreground uppercase tracking-wider">Health</div>
                        </div>
                      </div>
                    )}

                    {slaTotal > 0 && (
                      <div className="mt-2 flex items-center gap-2">
                        <Shield className={`h-3 w-3 ${slaFailed > 0 ? 'text-red-500' : 'text-emerald-500'}`} />
                        <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div className={`h-full rounded-full ${slaFailed === 0 ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${(slaPassed / slaTotal) * 100}%` }} />
                        </div>
                        <span className={`text-[10px] font-medium ${slaFailed > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                          {slaPassed}/{slaTotal} SLA
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            );
          })
        )}
      </div>

        </TabsContent>

        <TabsContent value="templates" className="mt-4">
          {templatesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-56 rounded-xl" />
              ))}
            </div>
          ) : templates.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-16 border-2 border-dashed rounded-xl bg-muted/10">
              <div className="mb-4 rounded-full p-5" style={{ background: 'linear-gradient(135deg, hsl(var(--primary) / 0.12), hsl(var(--primary) / 0.04))' }}>
                <LayoutTemplate className="h-12 w-12 text-primary/60" />
              </div>
              <h3 className="text-lg font-semibold">No report templates yet</h3>
              <p className="text-muted-foreground text-sm mt-1.5 text-center max-w-md">
                Templates let you standardize your sign-off reports. Define which sections appear, their order, and default content — so every report follows a consistent format.
              </p>
              <Button className="mt-5 gap-2" onClick={() => navigate("/report-templates/new")}>
                <Plus className="h-4 w-4" />
                Create Your First Template
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {templates.map((template, tIdx) => {
                const enabledSections = template.sections.filter(s => s.enabled);
                const builtinCount = enabledSections.filter(s => s.type === 'builtin').length;
                const customCount = enabledSections.filter(s => s.type === 'custom').length;

                return (
                  <Card
                    key={template.id}
                    className="group hover:shadow-lg transition-all duration-300 hover:border-primary/30 overflow-hidden cursor-pointer"
                    style={{ animation: `fadeSlideIn 0.3s ease-out ${tIdx * 0.05}s both` }}
                    onClick={() => navigate(`/report-templates/${template.id}`)}
                  >
                    <div className={`h-1 w-full ${template.isDefault ? 'bg-gradient-to-r from-amber-400 to-amber-500' : 'bg-gradient-to-r from-primary/40 to-primary/20'}`} />
                    <CardHeader className="pb-2 pt-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                              <LayoutTemplate className="h-4 w-4 text-primary" />
                            </div>
                            <div className="min-w-0">
                              <CardTitle className="text-sm font-semibold truncate">{template.name}</CardTitle>
                              {template.isDefault && (
                                <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400 text-[9px] mt-0.5 border-amber-200 dark:border-amber-800" variant="outline">Default Template</Badge>
                              )}
                            </div>
                          </div>
                          {template.description && (
                            <p className="text-xs text-muted-foreground mt-2 line-clamp-2 leading-relaxed">{template.description}</p>
                          )}
                        </div>
                        {canWrite && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" onClick={(e) => e.stopPropagation()}>
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                              <DropdownMenuItem onClick={() => navigate(`/report-templates/${template.id}`)}>
                                <Pencil className="h-4 w-4 mr-2" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => duplicateTemplateMutation.mutate(template.id)}>
                                <Copy className="h-4 w-4 mr-2" /> Duplicate
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => setDefaultTemplateMutation.mutate(template.id)}>
                                {template.isDefault ? <StarOff className="h-4 w-4 mr-2" /> : <Star className="h-4 w-4 mr-2" />}
                                {template.isDefault ? "Remove Default" : "Set as Default"}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-destructive" onClick={() => setDeleteTemplateId(template.id)}>
                                <Trash2 className="h-4 w-4 mr-2" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="pt-2 pb-4">
                      <div className="space-y-3">
                        <div className="flex flex-wrap gap-1">
                          {enabledSections.slice(0, 4).map((s, i) => (
                            <div key={s.id} className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-muted/60 text-[10px] text-muted-foreground">
                              <span className="font-medium text-foreground/70">{i + 1}.</span>
                              {s.title}
                            </div>
                          ))}
                          {enabledSections.length > 4 && (
                            <div className="flex items-center px-2 py-0.5 rounded-md bg-primary/5 text-[10px] text-primary font-medium">
                              +{enabledSections.length - 4} more
                            </div>
                          )}
                        </div>
                        <Separator />
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Layers className="h-3 w-3" />
                              <span className="font-medium">{enabledSections.length}</span> sections
                            </div>
                            {customCount > 0 && (
                              <div className="text-xs text-muted-foreground">
                                <span className="font-medium">{customCount}</span> custom
                              </div>
                            )}
                          </div>
                          <span className="text-[10px] text-muted-foreground">{format(new Date(template.createdAt), 'MMM d, yyyy')}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <AlertDialog open={deleteTemplateId !== null} onOpenChange={(open) => !open && setDeleteTemplateId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Template</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this report template. Existing reports created from this template will not be affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleteTemplateId && deleteTemplateMutation.mutate(deleteTemplateId)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={editDialogOpen} onOpenChange={(open) => { if (!open) { setEditDialogOpen(false); setEditingReport(null); setEditData(null); } }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="h-5 w-5 text-primary" />
              Edit Report
            </DialogTitle>
            <DialogDescription>
              Update report details and verdict
            </DialogDescription>
          </DialogHeader>
          {!editData ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              <span className="ml-2 text-sm text-muted-foreground">Loading report details...</span>
            </div>
          ) : (
            <div className="space-y-4 pt-2">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Title</label>
                <Input value={editData.title} onChange={(e) => setEditData({ ...editData, title: e.target.value })} />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-sm font-medium">Objective</label>
                  <Button type="button" variant="ghost" size="sm" className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground" onClick={() => {
                    const input = document.createElement('input');
                    input.type = 'file'; input.accept = '.txt,.text,.md,.csv,.jpg,.jpeg,.png';
                    input.onchange = async (e) => {
                      const f = (e.target as HTMLInputElement).files?.[0]; if (!f) return;
                      const isImg = /\.(jpe?g|png)$/i.test(f.name);
                      if (f.size > (isImg ? 2*1024*1024 : 512*1024)) { toast({ title: "File too large", variant: "destructive" }); return; }
                      try {
                        if (isImg) {
                          const dataUrl = await new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result as string); r.onerror = rej; r.readAsDataURL(f); });
                          setEditData((p: any) => ({ ...p, objective: (p.objective || '') + `\n<<IMG:${f.name}|${dataUrl}>>\n` }));
                          toast({ title: "Image attached", description: `"${f.name}" added` });
                        } else {
                          const t = await f.text(); setEditData((p: any) => ({ ...p, objective: p.objective ? p.objective + '\n' + t : t }));
                          toast({ title: "File loaded", description: `"${f.name}" added` });
                        }
                      } catch { toast({ title: "Error reading file", variant: "destructive" }); }
                    };
                    input.click();
                  }}>
                    <Upload className="h-3 w-3" />Upload
                  </Button>
                </div>
                <Textarea value={editData.objective} onChange={(e) => setEditData({ ...editData, objective: e.target.value })} className="min-h-[80px]" />
                <ImagePreviewStrip text={editData.objective || ''} onRemove={(name) => removeEditImage('objective', name)} />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-sm font-medium">Scope</label>
                  <Button type="button" variant="ghost" size="sm" className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground" onClick={() => {
                    const input = document.createElement('input');
                    input.type = 'file'; input.accept = '.txt,.text,.md,.csv,.jpg,.jpeg,.png';
                    input.onchange = async (e) => {
                      const f = (e.target as HTMLInputElement).files?.[0]; if (!f) return;
                      const isImg = /\.(jpe?g|png)$/i.test(f.name);
                      if (f.size > (isImg ? 2*1024*1024 : 512*1024)) { toast({ title: "File too large", variant: "destructive" }); return; }
                      try {
                        if (isImg) {
                          const dataUrl = await new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result as string); r.onerror = rej; r.readAsDataURL(f); });
                          setEditData((p: any) => ({ ...p, scope: (p.scope || '') + `\n<<IMG:${f.name}|${dataUrl}>>\n` }));
                          toast({ title: "Image attached", description: `"${f.name}" added` });
                        } else {
                          const t = await f.text(); setEditData((p: any) => ({ ...p, scope: p.scope ? p.scope + '\n' + t : t }));
                          toast({ title: "File loaded", description: `"${f.name}" added` });
                        }
                      } catch { toast({ title: "Error reading file", variant: "destructive" }); }
                    };
                    input.click();
                  }}>
                    <Upload className="h-3 w-3" />Upload
                  </Button>
                </div>
                <Textarea value={editData.scope} onChange={(e) => setEditData({ ...editData, scope: e.target.value })} className="min-h-[60px]" />
                <ImagePreviewStrip text={editData.scope || ''} onRemove={(name) => removeEditImage('scope', name)} />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-sm font-medium">Environment Notes</label>
                  <Button type="button" variant="ghost" size="sm" className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground" onClick={() => {
                    const input = document.createElement('input');
                    input.type = 'file'; input.accept = '.txt,.text,.md,.csv,.jpg,.jpeg,.png';
                    input.onchange = async (e) => {
                      const f = (e.target as HTMLInputElement).files?.[0]; if (!f) return;
                      const isImg = /\.(jpe?g|png)$/i.test(f.name);
                      if (f.size > (isImg ? 2*1024*1024 : 512*1024)) { toast({ title: "File too large", variant: "destructive" }); return; }
                      try {
                        if (isImg) {
                          const dataUrl = await new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result as string); r.onerror = rej; r.readAsDataURL(f); });
                          setEditData((p: any) => ({ ...p, environmentNotes: (p.environmentNotes || '') + `\n<<IMG:${f.name}|${dataUrl}>>\n` }));
                          toast({ title: "Image attached", description: `"${f.name}" added` });
                        } else {
                          const t = await f.text(); setEditData((p: any) => ({ ...p, environmentNotes: p.environmentNotes ? p.environmentNotes + '\n' + t : t }));
                          toast({ title: "File loaded", description: `"${f.name}" added` });
                        }
                      } catch { toast({ title: "Error reading file", variant: "destructive" }); }
                    };
                    input.click();
                  }}>
                    <Upload className="h-3 w-3" />Upload
                  </Button>
                </div>
                <Textarea value={editData.environmentNotes} onChange={(e) => setEditData({ ...editData, environmentNotes: e.target.value })} className="min-h-[60px]" />
                <ImagePreviewStrip text={editData.environmentNotes || ''} onRemove={(name) => removeEditImage('environmentNotes', name)} />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Recommendations</label>
                <Textarea value={editData.recommendations} onChange={(e) => setEditData({ ...editData, recommendations: e.target.value })} className="min-h-[60px]" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Verdict</label>
                  <Select value={editData.overallVerdict} onValueChange={(v) => setEditData({ ...editData, overallVerdict: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="go">Go</SelectItem>
                      <SelectItem value="no_go">No Go</SelectItem>
                      <SelectItem value="conditional">Conditional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Status</label>
                  <Select value={editData.status} onValueChange={(v) => setEditData({ ...editData, status: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="finalized">Finalized</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Verdict Notes</label>
                  <Input value={editData.verdictNotes} onChange={(e) => setEditData({ ...editData, verdictNotes: e.target.value })} />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => { setEditDialogOpen(false); setEditingReport(null); setEditData(null); }}>Cancel</Button>
                <Button onClick={() => editingReport && updateMutation.mutate({ id: editingReport.id, data: editData })} disabled={updateMutation.isPending}>
                  <Save className="h-4 w-4 mr-1" />{updateMutation.isPending ? 'Saving...' : 'Save Changes'}
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={approvalsDialogOpen} onOpenChange={(open) => { if (!open) { setApprovalsDialogOpen(false); setApprovalsReportId(null); setApprovalsReport(null); setApprovalComment(""); } }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserCheck className="h-5 w-5 text-primary" />
              Approval Workflow
            </DialogTitle>
            <DialogDescription>
              {approvalsReport?.title || 'Report'} — Manage review approvals
            </DialogDescription>
          </DialogHeader>
          {approvalsReport && (
            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={`text-xs gap-1 ${
                    approvalsReport.reviewStatus === 'approved' ? 'border-emerald-300 text-emerald-600' :
                    approvalsReport.reviewStatus === 'rejected' ? 'border-red-300 text-red-600' :
                    approvalsReport.reviewStatus === 'changes_requested' ? 'border-amber-300 text-amber-600' :
                    approvalsReport.reviewStatus === 'in_review' ? 'border-blue-300 text-blue-600' :
                    'border-slate-300 text-slate-600'
                  }`}>
                    {approvalsReport.reviewStatus === 'approved' && <CheckCircle className="h-3 w-3" />}
                    {approvalsReport.reviewStatus === 'rejected' && <XCircle className="h-3 w-3" />}
                    {approvalsReport.reviewStatus === 'changes_requested' && <RotateCcw className="h-3 w-3" />}
                    {approvalsReport.reviewStatus === 'in_review' && <UserCheck className="h-3 w-3" />}
                    {!approvalsReport.reviewStatus || approvalsReport.reviewStatus === 'draft' ? 'Draft' :
                     approvalsReport.reviewStatus === 'approved' ? 'Approved' :
                     approvalsReport.reviewStatus === 'rejected' ? 'Rejected' :
                     approvalsReport.reviewStatus === 'changes_requested' ? 'Changes Requested' :
                     'In Review'}
                  </Badge>
                  {approvals.length > 0 && (
                    <span className="text-xs text-muted-foreground">
                      {approvals.filter((a: any) => a.status === "approved").length} of {approvals.length} approved
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {(!approvalsReport.reviewStatus || approvalsReport.reviewStatus === 'draft' || approvalsReport.reviewStatus === 'changes_requested') && (
                    <Button size="sm" onClick={() => { setSelectedReviewers([]); setShowReviewDialog(true); }} className="gap-1.5">
                      <Send className="h-3.5 w-3.5" />
                      {approvals.length > 0 ? "Re-submit" : "Request Sign-Off"}
                    </Button>
                  )}
                  {approvalsReport.reviewStatus === 'in_review' && (
                    <Button variant="outline" size="sm" onClick={() => approvalsReportId && cancelReviewMutation.mutate(approvalsReportId)} disabled={cancelReviewMutation.isPending} className="gap-1.5">
                      <Ban className="h-3.5 w-3.5" />
                      Cancel Review
                    </Button>
                  )}
                </div>
              </div>

              {approvals.length > 0 && (
                <div className="w-full bg-muted rounded-full h-1.5">
                  <div
                    className="bg-emerald-500 h-1.5 rounded-full transition-all duration-500"
                    style={{ width: `${approvals.length > 0 ? (approvals.filter((a: any) => a.status === "approved").length / approvals.length) * 100 : 0}%` }}
                  />
                </div>
              )}

              {approvals.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Users className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  <p className="font-medium">No reviewers assigned</p>
                  <p className="text-xs mt-1">Click "Request Sign-Off" to select reviewers and start the approval process.</p>
                </div>
              ) : (
                <div className="divide-y border rounded-lg">
                  {approvals.map((approval: any, idx: number) => {
                    const statusConfig = approval.status === "approved"
                      ? { label: "Approved", color: "text-emerald-600", bg: "bg-emerald-100 dark:bg-emerald-900/30", ringColor: "ring-emerald-500", icon: CheckCircle }
                      : approval.status === "rejected"
                      ? { label: "Rejected", color: "text-red-600", bg: "bg-red-100 dark:bg-red-900/30", ringColor: "ring-red-500", icon: XCircle }
                      : approval.status === "changes_requested"
                      ? { label: "Changes Requested", color: "text-amber-600", bg: "bg-amber-100 dark:bg-amber-900/30", ringColor: "ring-amber-500", icon: RotateCcw }
                      : { label: "Pending", color: "text-slate-400", bg: "bg-slate-100 dark:bg-slate-800", ringColor: "ring-slate-300", icon: Clock };
                    const StepIcon = statusConfig.icon;
                    const isMyStep = approval.reviewerUserId === user?.id;
                    const canAct = isMyStep && approval.status === "pending" && approvalsReport.reviewStatus === "in_review";

                    return (
                      <div key={approval.id} className={`p-4 ${canAct ? 'bg-blue-50/50 dark:bg-blue-950/20' : ''}`}>
                        <div className="flex items-start gap-3">
                          <div className="flex flex-col items-center gap-1 pt-0.5">
                            <div className={`flex items-center justify-center w-8 h-8 rounded-full ring-2 ${statusConfig.ringColor} ${statusConfig.bg}`}>
                              <StepIcon className={`h-4 w-4 ${statusConfig.color}`} />
                            </div>
                            {idx < approvals.length - 1 && (
                              <div className="w-0.5 h-6 bg-muted-foreground/20 rounded-full" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Step {approval.stepOrder}</span>
                              <Avatar className="h-5 w-5">
                                <AvatarFallback className="text-[9px] bg-primary/10 text-primary">
                                  {(approval.reviewerUsername || "?").substring(0, 2).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium text-sm">{approval.reviewerUsername || `User #${approval.reviewerUserId}`}</span>
                              <Badge variant="outline" className="text-[10px] capitalize">{approval.reviewerRole || "user"}</Badge>
                              <Badge variant={approval.status === "approved" ? "default" : approval.status === "rejected" ? "destructive" : "secondary"} className="text-[10px]">
                                {statusConfig.label}
                              </Badge>
                              {isMyStep && <Badge variant="outline" className="text-[10px] border-blue-300 text-blue-600">You</Badge>}
                            </div>
                            {approval.comment && (
                              <div className="mt-1.5 p-2 rounded-md bg-muted/50 border text-xs text-muted-foreground flex items-start gap-1.5">
                                <MessageCircle className="h-3 w-3 mt-0.5 shrink-0" />
                                <span>{approval.comment}</span>
                              </div>
                            )}
                            {approval.actedAt && (
                              <p className="text-[10px] text-muted-foreground mt-1">
                                {format(new Date(approval.actedAt), "MMM d, yyyy 'at' h:mm a")}
                              </p>
                            )}
                            {canAct && (
                              <div className="mt-3 space-y-2">
                                <Textarea
                                  value={approvalComment}
                                  onChange={(e) => setApprovalComment(e.target.value)}
                                  placeholder="Add a comment (optional)..."
                                  className="min-h-[60px] resize-none text-sm"
                                />
                                <div className="flex gap-2">
                                  <Button size="sm" onClick={() => approvalsReportId && approvalActionMutation.mutate({ reportId: approvalsReportId, approvalId: approval.id, action: "approved", comment: approvalComment || undefined })} disabled={approvalActionMutation.isPending} className="gap-1.5 bg-emerald-600 hover:bg-emerald-700">
                                    <CheckCircle className="h-3.5 w-3.5" />Approve
                                  </Button>
                                  <Button size="sm" variant="outline" onClick={() => approvalsReportId && approvalActionMutation.mutate({ reportId: approvalsReportId, approvalId: approval.id, action: "changes_requested", comment: approvalComment || undefined })} disabled={approvalActionMutation.isPending} className="gap-1.5 text-amber-600 border-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/20">
                                    <RotateCcw className="h-3.5 w-3.5" />Changes
                                  </Button>
                                  <Button size="sm" variant="outline" onClick={() => approvalsReportId && approvalActionMutation.mutate({ reportId: approvalsReportId, approvalId: approval.id, action: "rejected", comment: approvalComment || undefined })} disabled={approvalActionMutation.isPending} className="gap-1.5 text-red-600 border-red-300 hover:bg-red-50 dark:hover:bg-red-950/20">
                                    <XCircle className="h-3.5 w-3.5" />Reject
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="h-5 w-5 text-blue-500" />
              Request Sign-Off
            </DialogTitle>
            <DialogDescription>
              Select reviewers who need to approve this report. They will review in the order shown below.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="text-sm font-medium">Select Reviewers</div>
            <div className="max-h-[200px] overflow-y-auto space-y-1 rounded-md border p-2">
              {allUsers.filter(u => u.id !== user?.id && u.isApproved).length === 0 ? (
                <p className="text-xs text-muted-foreground py-4 text-center">No other approved users available</p>
              ) : (
                allUsers.filter(u => u.id !== user?.id && u.isApproved).map(u => (
                  <label key={u.id} className="flex items-center gap-2.5 p-2 rounded-md hover:bg-muted/50 cursor-pointer transition-colors">
                    <Checkbox
                      checked={selectedReviewers.includes(u.id)}
                      onCheckedChange={() => setSelectedReviewers(
                        selectedReviewers.includes(u.id)
                          ? selectedReviewers.filter(id => id !== u.id)
                          : [...selectedReviewers, u.id]
                      )}
                    />
                    <Avatar className="h-6 w-6">
                      <AvatarFallback className="text-[10px] bg-primary/10 text-primary">
                        {u.username.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <span className="text-sm font-medium">{u.username}</span>
                      {u.email && <span className="text-xs text-muted-foreground ml-2">{u.email}</span>}
                    </div>
                    <Badge variant="outline" className="text-[10px] capitalize">{u.role}</Badge>
                  </label>
                ))
              )}
            </div>

            {selectedReviewers.length > 0 && (
              <>
                <Separator />
                <div className="text-sm font-medium">Review Order</div>
                <div className="space-y-1">
                  {selectedReviewers.map((reviewerId, idx) => {
                    const reviewer = allUsers.find(u => u.id === reviewerId);
                    return (
                      <div key={reviewerId} className="flex items-center gap-2 p-2 rounded-md border bg-muted/30">
                        <span className="text-xs font-bold text-muted-foreground w-5 text-center">{idx + 1}</span>
                        <Avatar className="h-5 w-5">
                          <AvatarFallback className="text-[9px] bg-primary/10 text-primary">
                            {(reviewer?.username || "?").substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm flex-1">{reviewer?.username || `User #${reviewerId}`}</span>
                        <div className="flex gap-0.5">
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => {
                            if (idx === 0) return;
                            const arr = [...selectedReviewers];
                            [arr[idx - 1], arr[idx]] = [arr[idx], arr[idx - 1]];
                            setSelectedReviewers(arr);
                          }} disabled={idx === 0}>
                            <ArrowUpRight className="h-3 w-3 rotate-[-45deg]" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => {
                            if (idx >= selectedReviewers.length - 1) return;
                            const arr = [...selectedReviewers];
                            [arr[idx], arr[idx + 1]] = [arr[idx + 1], arr[idx]];
                            setSelectedReviewers(arr);
                          }} disabled={idx === selectedReviewers.length - 1}>
                            <ArrowDownRight className="h-3 w-3 rotate-[45deg]" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReviewDialog(false)}>Cancel</Button>
            <Button onClick={() => approvalsReportId && requestReviewMutation.mutate({ reportId: approvalsReportId, reviewers: selectedReviewers })} disabled={selectedReviewers.length === 0 || requestReviewMutation.isPending} className="gap-1.5">
              <Send className="h-3.5 w-3.5" />
              {requestReviewMutation.isPending ? "Submitting..." : `Submit for Review (${selectedReviewers.length})`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
