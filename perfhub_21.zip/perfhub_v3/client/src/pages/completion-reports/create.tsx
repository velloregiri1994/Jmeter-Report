import { useState, useMemo, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useExecutions } from "@/hooks/use-executions";
import { PageHeader } from "@/components/page-header";
import { useLocation } from "wouter";
import { format } from "date-fns";
import {
  FileText, CheckCircle, XCircle, AlertTriangle,
  Clock, Shield, Activity,
  Layers, Loader2, Upload, X, ArrowLeft, ArrowRight,
  Plus, Trash2, GripVertical
} from "lucide-react";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";

const IMG_MARKER_RE = /<<IMG:([^|]+)\|(data:image\/[^>]+)>>/g;

function ImagePreviewStrip({ text, onRemove }: { text: string; onRemove: (filename: string) => void }) {
  const images = useMemo(() => {
    const results: { name: string; dataUrl: string }[] = [];
    const re = new RegExp(IMG_MARKER_RE.source, 'g');
    let m: RegExpExecArray | null;
    while ((m = re.exec(text)) !== null) {
      results.push({ name: m[1], dataUrl: m[2] });
    }
    return results;
  }, [text]);
  if (images.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-2 mt-2">
      {images.map((img, i) => (
        <div key={i} className="relative group rounded-md border border-border overflow-hidden" style={{ width: 72, height: 54 }}>
          <img src={img.dataUrl} alt={img.name} className="w-full h-full object-cover" />
          <button type="button" onClick={() => onRemove(img.name)}
            className="absolute -top-0.5 -right-0.5 bg-destructive text-destructive-foreground rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity" title={`Remove ${img.name}`}>
            <X className="h-3 w-3" />
          </button>
          <div className="absolute bottom-0 left-0 right-0 bg-black/60 px-1 py-0.5 text-[9px] text-white truncate">{img.name}</div>
        </div>
      ))}
    </div>
  );
}

interface CustomSection {
  id: string;
  title: string;
  content: string;
  enabled: boolean;
}

const DEFAULT_SECTIONS: CustomSection[] = [
  { id: 'objective', title: 'Test Objective', content: '', enabled: true },
  { id: 'scope', title: 'Scope', content: '', enabled: true },
  { id: 'environmentNotes', title: 'Environment Notes', content: '', enabled: true },
];

export default function CreateCompletionReportPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();

  const [createStep, setCreateStep] = useState(0);
  const [selectedCurrentExecution, setSelectedCurrentExecution] = useState<number | null>(null);
  const [selectedBaselineExecution, setSelectedBaselineExecution] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    projectName: '',
    featureName: '',
    recommendations: '',
    overallVerdict: 'pending',
    verdictNotes: '',
  });

  const [customSections, setCustomSections] = useState<CustomSection[]>(DEFAULT_SECTIONS);
  const [appliedTemplateId, setAppliedTemplateId] = useState<string>("");

  const { data: templates } = useQuery<any[]>({
    queryKey: ["/api/report-templates"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/report-templates");
      return res.json();
    },
  });

  useEffect(() => {
    if (templates && templates.length > 0 && !appliedTemplateId) {
      const defaultTemplate = templates.find((t: any) => t.isDefault);
      if (defaultTemplate) {
        applyTemplate(defaultTemplate);
        setAppliedTemplateId(String(defaultTemplate.id));
      }
    }
  }, [templates]);

  function applyTemplate(template: any) {
    if (!template?.sections) return;

    const builtinFormFields: Record<string, string> = {
      objective: 'objective',
      scope: 'scope',
      environment_notes: 'environmentNotes',
    };

    const newSections: CustomSection[] = template.sections
      .filter((s: any) => s.enabled)
      .map((s: any) => {
        if (s.type === 'builtin' && s.key) {
          const mappedId = builtinFormFields[s.key];
          if (mappedId) {
            return { id: mappedId, title: s.title, content: s.defaultContent || '', enabled: true };
          }
          return { id: s.key, title: s.title, content: s.defaultContent || '', enabled: true };
        }
        return {
          id: s.id || `custom_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          title: s.title,
          content: s.defaultContent || '',
          enabled: true,
        };
      });

    const hasObjective = newSections.some((s: CustomSection) => s.id === 'objective');
    const hasScope = newSections.some((s: CustomSection) => s.id === 'scope');
    const hasEnvNotes = newSections.some((s: CustomSection) => s.id === 'environmentNotes');
    if (!hasObjective) newSections.unshift({ id: 'objective', title: 'Test Objective', content: '', enabled: false });
    if (!hasScope) {
      const objIdx = newSections.findIndex((s: CustomSection) => s.id === 'objective');
      newSections.splice(objIdx + 1, 0, { id: 'scope', title: 'Scope', content: '', enabled: false });
    }
    if (!hasEnvNotes) {
      const scopeIdx = newSections.findIndex((s: CustomSection) => s.id === 'scope');
      newSections.splice(scopeIdx + 1, 0, { id: 'environmentNotes', title: 'Environment Notes', content: '', enabled: false });
    }

    setCustomSections(newSections);
    toast({ title: "Template applied", description: `${newSections.filter((s: CustomSection) => s.enabled).length} sections loaded from "${template.name}"` });
  }

  const { data: executionsResponse } = useExecutions({ limit: 100 });
  const executions = executionsResponse?.data || [];
  const completedExecutions = executions.filter((e: any) => e.status === "completed");

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/completion-reports", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.completionReports.all });
      toast({ title: "Report created successfully" });
      navigate(data?.id ? `/completion-reports/${data.id}` : "/completion-reports");
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const handleCreate = () => {
    if (!formData.title.trim()) {
      toast({ title: "Error", description: "Report title is required", variant: "destructive" });
      return;
    }
    if (!selectedCurrentExecution) {
      toast({ title: "Error", description: "Select a current test execution", variant: "destructive" });
      return;
    }

    const enabledSections = customSections.filter(s => s.enabled);
    const sectionData: Record<string, string> = {};
    enabledSections.forEach(s => {
      if (s.content.trim()) {
        sectionData[s.id] = s.content;
      }
    });

    const topLevelFields = ['objective', 'scope', 'environmentNotes', 'recommendations'];
    const customSectionsPayload = customSections
      .filter(s => !topLevelFields.includes(s.id))
      .filter(s => s.enabled)
      .map(s => ({ title: s.title, content: s.content }));

    createMutation.mutate({
      ...formData,
      objective: sectionData['objective'] || null,
      scope: sectionData['scope'] || null,
      environmentNotes: sectionData['environmentNotes'] || null,
      recommendations: sectionData['recommendations'] || null,
      executionIds: [selectedCurrentExecution],
      compareExecutionIds: selectedBaselineExecution ? [selectedBaselineExecution] : undefined,
      customSections: customSectionsPayload.length > 0 ? customSectionsPayload : undefined,
    });
  };

  const handleFileUpload = (sectionId: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.txt,.text,.md,.csv,.jpg,.jpeg,.png';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      const isImage = /\.(jpe?g|png)$/i.test(file.name);
      const maxSize = isImage ? 2 * 1024 * 1024 : 512 * 1024;
      if (file.size > maxSize) {
        toast({ title: "File too large", description: isImage ? "Images must be under 2 MB" : "Text files must be under 512 KB", variant: "destructive" });
        return;
      }
      try {
        if (isImage) {
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });
          const marker = `\n<<IMG:${file.name}|${dataUrl}>>\n`;
          updateSectionContent(sectionId, (prev) => (prev || '') + marker);
          toast({ title: "Image attached", description: `"${file.name}" has been added` });
        } else {
          const text = await file.text();
          updateSectionContent(sectionId, (prev) => prev ? prev + '\n' + text : text);
          toast({ title: "File loaded", description: `Content from "${file.name}" has been added` });
        }
      } catch {
        toast({ title: "Error reading file", variant: "destructive" });
      }
    };
    input.click();
  };

  const updateSectionContent = (sectionId: string, updater: (prev: string) => string) => {
    setCustomSections(prev => prev.map(s =>
      s.id === sectionId ? { ...s, content: updater(s.content) } : s
    ));
  };

  const removeSectionImage = (sectionId: string, filename: string) => {
    setCustomSections(prev => prev.map(s =>
      s.id === sectionId ? {
        ...s,
        content: (s.content || '').replace(new RegExp(`\\n?<<IMG:${filename.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\|[^>]+>>\\n?`, 'g'), '').trim()
      } : s
    ));
  };

  const addCustomSection = () => {
    const id = `custom_${Date.now()}`;
    setCustomSections(prev => [...prev, { id, title: 'New Section', content: '', enabled: true }]);
  };

  const removeCustomSection = (id: string) => {
    if (['objective', 'scope', 'environmentNotes'].includes(id)) {
      setCustomSections(prev => prev.map(s => s.id === id ? { ...s, enabled: false } : s));
    } else {
      setCustomSections(prev => prev.filter(s => s.id !== id));
    }
  };

  const toggleSection = (id: string) => {
    setCustomSections(prev => prev.map(s => s.id === id ? { ...s, enabled: !s.enabled } : s));
  };

  const updateSectionTitle = (id: string, title: string) => {
    setCustomSections(prev => prev.map(s => s.id === id ? { ...s, title } : s));
  };

  const getVerdictConfig = (verdict: string | null) => {
    switch (verdict) {
      case 'go':
        return { label: 'Go', icon: CheckCircle, color: 'text-emerald-600 dark:text-emerald-400' };
      case 'no_go':
        return { label: 'No Go', icon: XCircle, color: 'text-red-600 dark:text-red-400' };
      case 'conditional':
        return { label: 'Conditional', icon: AlertTriangle, color: 'text-amber-600 dark:text-amber-400' };
      default:
        return { label: 'Pending', icon: Clock, color: 'text-slate-500 dark:text-slate-400' };
    }
  };

  const getSelectedExecution = (id: number | null) => {
    if (!id) return null;
    return completedExecutions.find((e: any) => e.id === id);
  };

  const currentExec = getSelectedExecution(selectedCurrentExecution);
  const baselineExec = getSelectedExecution(selectedBaselineExecution);

  const steps = [
    { label: "Report Details", icon: FileText, description: "Basic information and custom sections" },
    { label: "Test Runs", icon: Layers, description: "Select current and baseline test" },
    { label: "Assessment", icon: Shield, description: "Verdict and recommendations" },
  ];

  const renderExecutionOption = (exec: any) => {
    const config = exec.schedule?.configuration;
    const result = exec.resultSummary;
    const name = exec.schedule?.name || 'Unknown Test';
    const env = config?.environment || '';
    const testType = config?.testTypeName || '';
    const dateStr = exec.endTime ? format(new Date(exec.endTime), "MMM d, h:mm a") : '';
    const avgRT = result?.avgResponseTime ? `${result.avgResponseTime.toFixed(0)}ms` : '';
    const tps = result?.throughput ? `${result.throughput.toFixed(1)} rps` : '';

    return `${name}${testType ? ` [${testType}]` : ''}${env ? ` - ${env}` : ''}${dateStr ? ` (${dateStr})` : ''}`;
  };

  return (
    <div className="section-gap">
      <PageHeader
        title="Create Sign-Off Report"
        subtitle="Consolidate test executions into a stakeholder-ready sign-off report"
        actions={
          <Button variant="outline" onClick={() => navigate("/completion-reports")}>
            <ArrowLeft className="h-4 w-4 mr-2" />Back to Reports
          </Button>
        }
      />

      <div className="flex items-center gap-2 mb-8">
        {steps.map((s, i) => {
          const StepIcon = s.icon;
          const isActive = createStep === i;
          const isCompleted = createStep > i;
          return (
            <div key={i} className="flex items-center flex-1">
              <button
                type="button"
                onClick={() => {
                  if (i < createStep) setCreateStep(i);
                  else if (i === createStep + 1) {
                    if (createStep === 0 && !formData.title.trim()) {
                      toast({ title: "Report title is required", variant: "destructive" });
                      return;
                    }
                    if (createStep === 1 && !selectedCurrentExecution) {
                      toast({ title: "Select a current test execution", variant: "destructive" });
                      return;
                    }
                    setCreateStep(i);
                  }
                }}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all w-full border ${
                  isActive
                    ? 'bg-primary text-primary-foreground shadow-md border-primary'
                    : isCompleted
                    ? 'bg-primary/10 text-primary border-primary/30 hover:bg-primary/15'
                    : 'text-muted-foreground border-border hover:bg-muted/60'
                }`}
              >
                <div className={`flex items-center justify-center h-7 w-7 rounded-full text-xs font-bold shrink-0 ${
                  isActive ? 'bg-primary-foreground/20' : isCompleted ? 'bg-primary/20' : 'bg-muted'
                }`}>
                  {isCompleted ? <CheckCircle className="h-4 w-4" /> : i + 1}
                </div>
                <div className="text-left hidden sm:block">
                  <div className="font-semibold">{s.label}</div>
                  <div className={`text-[11px] ${isActive ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>{s.description}</div>
                </div>
              </button>
              {i < 2 && <div className={`h-px w-6 mx-1 shrink-0 ${createStep > i ? 'bg-primary/40' : 'bg-border'}`} />}
            </div>
          );
        })}
      </div>

      <Card>
        <CardContent className="p-6 sm:p-8">
          {createStep === 0 && (
            <div className="space-y-5 max-w-3xl">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Report Title <span className="text-destructive">*</span></label>
                <Input
                  placeholder="e.g., Payment Gateway - Release 2.5 Performance Sign-Off"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  autoFocus
                  className="text-base"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Project Name</label>
                  <Input
                    placeholder="e.g., Payment Gateway"
                    value={formData.projectName}
                    onChange={(e) => setFormData({ ...formData, projectName: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Feature / Release</label>
                  <Input
                    placeholder="e.g., Checkout Flow v2.5"
                    value={formData.featureName}
                    onChange={(e) => setFormData({ ...formData, featureName: e.target.value })}
                  />
                </div>
              </div>

              <Separator />

              {templates && templates.length > 0 && (
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Apply Template</label>
                  <Select
                    value={appliedTemplateId}
                    onValueChange={(val) => {
                      setAppliedTemplateId(val);
                      if (val === "__none__") {
                        setCustomSections([...DEFAULT_SECTIONS]);
                      } else {
                        const tmpl = templates.find((t: any) => String(t.id) === val);
                        if (tmpl) applyTemplate(tmpl);
                      }
                    }}
                  >
                    <SelectTrigger className="w-full sm:w-[300px]">
                      <SelectValue placeholder="Choose a template (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">No Template (default sections)</SelectItem>
                      {templates.map((t: any) => (
                        <SelectItem key={t.id} value={String(t.id)}>
                          {t.name} {t.isDefault ? '(Default)' : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">Templates define which sections appear and their default content.</p>
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-3">
                  <label className="text-sm font-semibold">Report Sections</label>
                  <Button type="button" variant="outline" size="sm" className="h-7 text-xs gap-1.5" onClick={addCustomSection}>
                    <Plus className="h-3 w-3" />Add Section
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mb-4">Toggle sections on/off and add custom content. Each section will appear in the generated document.</p>

                <div className="space-y-4">
                  {customSections.map((section) => {
                    const coreFields = ['objective', 'scope', 'environmentNotes'];
                    const autoGeneratedKeys = ['executive_summary', 'test_results', 'sla_compliance', 'transactions', 'run_comparison', 'recommendations'];
                    const isCoreField = coreFields.includes(section.id);
                    const isAutoGenerated = autoGeneratedKeys.includes(section.id);
                    const isBuiltIn = isCoreField || isAutoGenerated;

                    const placeholders: Record<string, string> = {
                      objective: "Describe the purpose: e.g., Validate system handles 500 concurrent users with <2s response time...",
                      scope: "Flows, APIs, or modules tested...",
                      environmentNotes: "Server specs, differences from production...",
                      executive_summary: "High-level overview of test results, key findings, and go/no-go recommendation...",
                      test_results: "Summary of test results: throughput achieved, average/P95 response times, error rates, duration...",
                      sla_compliance: "SLA targets and compliance status: which SLAs passed or failed, breach details...",
                      transactions: "Per-transaction breakdown: response times, error rates, throughput for each API/flow...",
                      run_comparison: "Comparison with baseline run: performance changes, regressions, improvements...",
                      recommendations: "Actionable recommendations based on test findings, tuning suggestions, next steps...",
                    };

                    return (
                      <div key={section.id} className={`rounded-lg border transition-all ${section.enabled ? 'border-border bg-background' : 'border-dashed border-muted-foreground/30 bg-muted/20'}`}>
                        <div className="flex items-center gap-3 px-4 py-2.5 border-b border-border/50">
                          <Checkbox
                            checked={section.enabled}
                            onCheckedChange={() => toggleSection(section.id)}
                          />
                          {isBuiltIn ? (
                            <span className="text-sm font-medium flex-1">{section.title}</span>
                          ) : (
                            <Input
                              value={section.title}
                              onChange={(e) => updateSectionTitle(section.id, e.target.value)}
                              className="h-7 text-sm font-medium border-none bg-transparent p-0 focus-visible:ring-0 flex-1"
                              placeholder="Section title..."
                            />
                          )}
                          <div className="flex items-center gap-1">
                            {isAutoGenerated && (
                              <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded-full font-medium">Auto-generated + Notes</span>
                            )}
                            {section.enabled && (
                              <Button type="button" variant="ghost" size="sm" className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground" onClick={() => handleFileUpload(section.id)}>
                                <Upload className="h-3 w-3" />Upload
                              </Button>
                            )}
                            {!isBuiltIn && (
                              <Button type="button" variant="ghost" size="sm" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive" onClick={() => removeCustomSection(section.id)}>
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            )}
                          </div>
                        </div>
                        {section.enabled && (
                          <div className="p-4">
                            {isAutoGenerated && (
                              <p className="text-xs text-blue-600 bg-blue-50 dark:bg-blue-950/30 dark:text-blue-400 px-3 py-1.5 rounded mb-3">
                                Data tables are auto-generated from execution results. Add your observations, analysis, or notes below — they will appear alongside the auto-generated data in the report.
                              </p>
                            )}
                            <Textarea
                              placeholder={placeholders[section.id] || "Enter content for this section..."}
                              value={section.content}
                              onChange={(e) => updateSectionContent(section.id, () => e.target.value)}
                              className="min-h-[150px] resize-y"
                            />
                            <ImagePreviewStrip text={section.content} onRemove={(name) => removeSectionImage(section.id, name)} />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {createStep === 1 && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <label className="text-sm font-semibold mb-2 block">Current Test Execution <span className="text-destructive">*</span></label>
                <p className="text-xs text-muted-foreground mb-3">Select the test run you want to report on.</p>

                {completedExecutions.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground border rounded-xl">
                    <Activity className="h-10 w-10 mb-3 opacity-40" />
                    <p className="text-sm font-medium">No completed executions</p>
                    <p className="text-xs mt-1">Run some tests first to include them in this report</p>
                  </div>
                ) : (
                  <Select
                    value={selectedCurrentExecution ? String(selectedCurrentExecution) : undefined}
                    onValueChange={(val) => {
                      const id = parseInt(val);
                      setSelectedCurrentExecution(id);
                      if (selectedBaselineExecution === id) {
                        setSelectedBaselineExecution(null);
                      }
                    }}
                  >
                    <SelectTrigger className="h-auto min-h-[48px] text-left">
                      <SelectValue placeholder="Choose a test execution..." />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      {completedExecutions.map((exec: any) => (
                        <SelectItem key={exec.id} value={String(exec.id)} className="py-2">
                          <div className="flex flex-col gap-0.5">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-medium text-sm">{exec.schedule?.name || 'Unknown Test'}</span>
                              {exec.schedule?.configuration?.testTypeName && (
                                <Badge variant="outline" className="text-[10px] h-4 px-1.5">{exec.schedule.configuration.testTypeName}</Badge>
                              )}
                              {exec.schedule?.configuration?.environment && (
                                <Badge variant="secondary" className="text-[10px] h-4 px-1.5">{exec.schedule.configuration.environment}</Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-3 text-xs text-muted-foreground">
                              <span className="font-mono bg-muted px-1 py-0.5 rounded text-[10px]">{exec.executionId}</span>
                              {exec.endTime && <span>{format(new Date(exec.endTime), "MMM d 'at' h:mm a")}</span>}
                              {exec.resultSummary && (
                                <>
                                  <span>{(exec.resultSummary.totalRequests || 0).toLocaleString()} req</span>
                                  <span>Avg {(exec.resultSummary.avgResponseTime || 0).toFixed(0)}ms</span>
                                </>
                              )}
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}

                {currentExec && (
                  <div className="mt-3 rounded-lg bg-primary/5 border border-primary/20 px-4 py-3">
                    <div className="flex items-center gap-2 text-sm font-medium text-primary">
                      <CheckCircle className="h-4 w-4" />
                      Selected: {currentExec.schedule?.name || 'Unknown Test'}
                    </div>
                    {currentExec.resultSummary && (
                      <div className="flex items-center gap-4 text-xs text-muted-foreground mt-1.5 ml-6">
                        <span>{(currentExec.resultSummary.totalRequests || 0).toLocaleString()} requests</span>
                        <span>Avg {(currentExec.resultSummary.avgResponseTime || 0).toFixed(0)}ms</span>
                        <span>{(currentExec.resultSummary.throughput || 0).toFixed(1)} rps</span>
                        {(currentExec.resultSummary.failedRequests || 0) > 0 && (
                          <span className="text-red-500">{currentExec.resultSummary.failedRequests} failed</span>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <Separator />

              <div>
                <label className="text-sm font-semibold mb-2 block">Baseline Test Execution (Optional)</label>
                <p className="text-xs text-muted-foreground mb-3">Optionally select a previous/baseline run to compare against. The report will include a comparison section.</p>

                <Select
                  value={selectedBaselineExecution ? String(selectedBaselineExecution) : "none"}
                  onValueChange={(val) => {
                    setSelectedBaselineExecution(val === "none" ? null : parseInt(val));
                  }}
                >
                  <SelectTrigger className="h-auto min-h-[48px] text-left">
                    <SelectValue placeholder="No baseline selected" />
                  </SelectTrigger>
                  <SelectContent className="max-h-[300px]">
                    <SelectItem value="none">No baseline (skip comparison)</SelectItem>
                    {completedExecutions
                      .filter((exec: any) => exec.id !== selectedCurrentExecution)
                      .map((exec: any) => (
                        <SelectItem key={exec.id} value={String(exec.id)} className="py-2">
                          <div className="flex flex-col gap-0.5">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-medium text-sm">{exec.schedule?.name || 'Unknown Test'}</span>
                              {exec.schedule?.configuration?.testTypeName && (
                                <Badge variant="outline" className="text-[10px] h-4 px-1.5">{exec.schedule.configuration.testTypeName}</Badge>
                              )}
                              {exec.schedule?.configuration?.environment && (
                                <Badge variant="secondary" className="text-[10px] h-4 px-1.5">{exec.schedule.configuration.environment}</Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-3 text-xs text-muted-foreground">
                              <span className="font-mono bg-muted px-1 py-0.5 rounded text-[10px]">{exec.executionId}</span>
                              {exec.endTime && <span>{format(new Date(exec.endTime), "MMM d 'at' h:mm a")}</span>}
                              {exec.resultSummary && (
                                <>
                                  <span>{(exec.resultSummary.totalRequests || 0).toLocaleString()} req</span>
                                  <span>Avg {(exec.resultSummary.avgResponseTime || 0).toFixed(0)}ms</span>
                                </>
                              )}
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>

                {baselineExec && (
                  <div className="mt-3 rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 px-4 py-3">
                    <div className="flex items-center gap-2 text-sm font-medium text-blue-600 dark:text-blue-400">
                      <CheckCircle className="h-4 w-4" />
                      Baseline: {baselineExec.schedule?.name || 'Unknown Test'}
                    </div>
                    {baselineExec.resultSummary && (
                      <div className="flex items-center gap-4 text-xs text-muted-foreground mt-1.5 ml-6">
                        <span>{(baselineExec.resultSummary.totalRequests || 0).toLocaleString()} requests</span>
                        <span>Avg {(baselineExec.resultSummary.avgResponseTime || 0).toFixed(0)}ms</span>
                        <span>{(baselineExec.resultSummary.throughput || 0).toFixed(1)} rps</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {createStep === 2 && (
            <div className="space-y-5 max-w-3xl">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Recommendations</label>
                <Textarea
                  placeholder="Suggested fixes, optimizations, infrastructure changes..."
                  value={formData.recommendations}
                  onChange={(e) => setFormData({ ...formData, recommendations: e.target.value })}
                  className="min-h-[100px] resize-none"
                />
              </div>
              <Separator />
              <div>
                <label className="text-sm font-medium mb-3 block">Overall Verdict</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {([
                    { value: 'pending', label: 'Pending Review', icon: Clock, desc: 'Decision deferred', color: 'border-slate-200 dark:border-slate-700 hover:border-slate-400', activeColor: 'border-slate-500 bg-slate-50 dark:bg-slate-800/50 ring-1 ring-slate-300' },
                    { value: 'go', label: 'Go', icon: CheckCircle, desc: 'Ready for production', color: 'border-slate-200 dark:border-slate-700 hover:border-emerald-400', activeColor: 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 ring-1 ring-emerald-300' },
                    { value: 'no_go', label: 'No Go', icon: XCircle, desc: 'Not ready', color: 'border-slate-200 dark:border-slate-700 hover:border-red-400', activeColor: 'border-red-500 bg-red-50 dark:bg-red-950/40 ring-1 ring-red-300' },
                    { value: 'conditional', label: 'Conditional', icon: AlertTriangle, desc: 'Ready with caveats', color: 'border-slate-200 dark:border-slate-700 hover:border-amber-400', activeColor: 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 ring-1 ring-amber-300' },
                  ] as const).map(opt => {
                    const VIcon = opt.icon;
                    const isActive = formData.overallVerdict === opt.value;
                    return (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => setFormData({ ...formData, overallVerdict: opt.value })}
                        className={`flex items-center gap-3 rounded-xl border p-4 text-left transition-all ${isActive ? opt.activeColor : opt.color}`}
                      >
                        <VIcon className={`h-5 w-5 shrink-0 ${isActive ? '' : 'text-muted-foreground'}`} />
                        <div>
                          <div className="text-sm font-semibold">{opt.label}</div>
                          <div className="text-xs text-muted-foreground">{opt.desc}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Verdict Notes</label>
                <Input
                  placeholder="Brief notes on the decision..."
                  value={formData.verdictNotes}
                  onChange={(e) => setFormData({ ...formData, verdictNotes: e.target.value })}
                />
              </div>

              {(formData.title || selectedCurrentExecution) && (
                <div className="rounded-xl border bg-muted/30 p-5 space-y-3">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Summary</p>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
                    <div className="text-muted-foreground">Title</div>
                    <div className="font-medium truncate">{formData.title || '\u2014'}</div>
                    <div className="text-muted-foreground">Project</div>
                    <div className="font-medium">{formData.projectName || '\u2014'}</div>
                    <div className="text-muted-foreground">Feature / Release</div>
                    <div className="font-medium">{formData.featureName || '\u2014'}</div>
                    <div className="text-muted-foreground">Current Test</div>
                    <div className="font-medium">{currentExec?.schedule?.name || '\u2014'}</div>
                    <div className="text-muted-foreground">Baseline Test</div>
                    <div className="font-medium">{baselineExec?.schedule?.name || 'None'}</div>
                    <div className="text-muted-foreground">Sections</div>
                    <div className="font-medium">{customSections.filter(s => s.enabled).length} enabled</div>
                    <div className="text-muted-foreground">Verdict</div>
                    <div className="font-medium">{getVerdictConfig(formData.overallVerdict).label}</div>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex items-center justify-between mt-6">
        <Button
          variant="outline"
          onClick={() => createStep === 0 ? navigate("/completion-reports") : setCreateStep(createStep - 1)}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          {createStep === 0 ? 'Cancel' : 'Back'}
        </Button>
        <div className="flex items-center gap-3">
          {createStep < 2 ? (
            <Button
              onClick={() => {
                if (createStep === 0 && !formData.title.trim()) {
                  toast({ title: "Report title is required", variant: "destructive" });
                  return;
                }
                if (createStep === 1 && !selectedCurrentExecution) {
                  toast({ title: "Select a current test execution", variant: "destructive" });
                  return;
                }
                setCreateStep(createStep + 1);
              }}
            >
              Continue<ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          ) : (
            <Button onClick={handleCreate} disabled={createMutation.isPending}>
              {createMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {createMutation.isPending ? 'Creating...' : 'Create Report'}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
