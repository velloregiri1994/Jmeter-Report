import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  CheckCircle, XCircle, AlertTriangle,
  Target, Pencil, BarChart2, Timer, Server, Layers,
  TrendingUp
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip,
  ResponsiveContainer, ComposedChart, Line, Legend
} from "recharts";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS } from "@/components/charts/dynatrace-theme";
import { getTestTypeColor } from "./report-detail-utils";

export function ExecutiveSummaryTab({ editing, editData, setEditData, report, sections }: {
  editing: boolean;
  editData: any;
  setEditData: (data: any) => void;
  report: any;
  sections: any[];
}) {
  if (editing) {
    return (
      <Card>
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><Pencil className="h-4 w-4" />Edit Report Details</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Title</label>
            <Input value={editData.title} onChange={(e) => setEditData({ ...editData, title: e.target.value })} />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Objective</label>
            <Textarea value={editData.objective} onChange={(e) => setEditData({ ...editData, objective: e.target.value })} className="min-h-[80px]" />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Scope</label>
            <Textarea value={editData.scope} onChange={(e) => setEditData({ ...editData, scope: e.target.value })} className="min-h-[60px]" />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Environment Notes</label>
            <Textarea value={editData.environmentNotes} onChange={(e) => setEditData({ ...editData, environmentNotes: e.target.value })} className="min-h-[60px]" />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Recommendations</label>
            <Textarea value={editData.recommendations} onChange={(e) => setEditData({ ...editData, recommendations: e.target.value })} className="min-h-[60px]" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Verdict</label>
              <Select value={editData.overallVerdict} onValueChange={(v) => setEditData({ ...editData, overallVerdict: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="go">Go</SelectItem>
                  <SelectItem value="no_go">No Go</SelectItem>
                  <SelectItem value="conditional">Conditional</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Status</label>
              <Select value={editData.status} onValueChange={(v) => setEditData({ ...editData, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="finalized">Finalized</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Verdict Notes</label>
              <Input value={editData.verdictNotes} onChange={(e) => setEditData({ ...editData, verdictNotes: e.target.value })} />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {report.objective && (
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2 text-blue-600 dark:text-blue-400">
                <Target className="h-4 w-4" />Test Objective
              </CardTitle>
            </CardHeader>
            <CardContent><p className="text-sm whitespace-pre-wrap leading-relaxed">{report.objective}</p></CardContent>
          </Card>
        )}
        {report.scope && (
          <Card className="border-l-4 border-l-purple-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2 text-purple-600 dark:text-purple-400">
                <Layers className="h-4 w-4" />Scope
              </CardTitle>
            </CardHeader>
            <CardContent><p className="text-sm whitespace-pre-wrap leading-relaxed">{report.scope}</p></CardContent>
          </Card>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {report.environmentNotes && (
          <Card className="border-l-4 border-l-teal-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2 text-teal-600 dark:text-teal-400">
                <Server className="h-4 w-4" />Test Environment
              </CardTitle>
            </CardHeader>
            <CardContent><p className="text-sm whitespace-pre-wrap leading-relaxed">{report.environmentNotes}</p></CardContent>
          </Card>
        )}
        {report.recommendations && (
          <Card className="border-l-4 border-l-amber-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2 text-amber-600 dark:text-amber-400">
                <AlertTriangle className="h-4 w-4" />Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent><p className="text-sm whitespace-pre-wrap leading-relaxed">{report.recommendations}</p></CardContent>
          </Card>
        )}
      </div>

      {sections.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Timer className="h-4 w-4 text-orange-500" />
                Response Time by Test Type
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[260px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={sections.map((s: any) => ({
                    name: s.testType.length > 12 ? s.testType.substring(0, 12) + '...' : s.testType,
                    avg: Math.round(s.avgResponseTime || 0),
                    p90: Math.round(s.p90 || 0),
                    p95: Math.round(s.p95 || 0),
                    p99: Math.round(s.p99 || 0),
                  }))} barGap={2} barCategoryGap="20%">
                    <CartesianGrid {...DT_GRID_PROPS} />
                    <XAxis dataKey="name" {...DT_AXIS_PROPS} />
                    <YAxis {...DT_AXIS_PROPS} />
                    <RechartsTooltip cursor={DT_CURSOR_PROPS} contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} formatter={(v: any) => `${v}ms`} />
                    <Bar dataKey="avg" name="Avg" fill={DT_COLORS.primary} radius={[3, 3, 0, 0]} />
                    <Bar dataKey="p90" name="P90" fill={DT_COLORS.purple} radius={[3, 3, 0, 0]} />
                    <Bar dataKey="p95" name="P95" fill={DT_COLORS.amber} radius={[3, 3, 0, 0]} />
                    <Bar dataKey="p99" name="P99" fill={DT_COLORS.red} radius={[3, 3, 0, 0]} />
                    <Legend iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-teal-500" />
                Throughput & Error Rate
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[260px]">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={sections.map((s: any) => ({
                    name: s.testType.length > 12 ? s.testType.substring(0, 12) + '...' : s.testType,
                    throughput: parseFloat((s.throughput || 0).toFixed(1)),
                    errorRate: parseFloat((s.errorRate || 0).toFixed(2)),
                  }))}>
                    <CartesianGrid {...DT_GRID_PROPS} />
                    <XAxis dataKey="name" {...DT_AXIS_PROPS} />
                    <YAxis yAxisId="left" {...DT_AXIS_PROPS} />
                    <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} />
                    <RechartsTooltip cursor={DT_CURSOR_PROPS} contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} />
                    <Bar yAxisId="left" dataKey="throughput" name="Throughput (req/s)" fill={DT_COLORS.teal} radius={[3, 3, 0, 0]} />
                    <Line yAxisId="right" type="monotone" dataKey="errorRate" name="Error Rate (%)" stroke={DT_COLORS.red} strokeWidth={2} dot={{ r: 4, fill: DT_COLORS.red }} />
                    <Legend iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <BarChart2 className="h-4 w-4 text-primary" />
            Test Execution Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/30">
                  <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Test Type</th>
                  <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Script</th>
                  <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Env</th>
                  <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">VUsers</th>
                  <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Requests</th>
                  <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Avg RT</th>
                  <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">TPS</th>
                  <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Error %</th>
                  <th className="text-center py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody>
                {sections.map((section: any, idx: number) => (
                  <tr key={idx} className="border-b hover:bg-muted/20 transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${getTestTypeColor(section.testType)}`} />
                        <span className="font-medium">{section.testType}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-muted-foreground max-w-[150px] truncate">{section.scriptName}</td>
                    <td className="py-2.5 px-3">
                      <Badge variant="outline" className="text-[10px] font-normal">{section.environment}</Badge>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono">{section.vusers}</td>
                    <td className="py-2.5 px-3 text-right font-mono">{(section.totalRequests || 0).toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right font-mono">{(section.avgResponseTime || 0).toFixed(0)}ms</td>
                    <td className="py-2.5 px-3 text-right font-mono">{(section.throughput || 0).toFixed(1)}</td>
                    <td className={`py-2.5 px-3 text-right font-mono font-medium ${(section.errorRate || 0) > 1 ? 'text-red-600' : 'text-emerald-600'}`}>
                      {(section.errorRate || 0).toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {section.status === 'completed' ? (
                        <CheckCircle className="h-4 w-4 text-emerald-500 mx-auto" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500 mx-auto" />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
