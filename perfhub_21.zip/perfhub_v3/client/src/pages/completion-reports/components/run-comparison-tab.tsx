import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, GitCompare } from "lucide-react";
import { getTestTypeColor, renderChangePercent } from "./report-detail-utils";

export function RunComparisonTab({ snapshot }: { snapshot: any }) {
  const runComparison = snapshot?.runComparison;
  if (!runComparison) return null;

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4" style={{ animation: 'fadeSlideIn 0.3s ease-out both' }}>
        <Card className="text-center p-4 border-l-4 border-l-blue-500">
          <div className="text-2xl font-bold">{runComparison.pairComparisons?.length || 0}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Matched Pairs</div>
        </Card>
        <Card className="text-center p-4 border-l-4 border-l-amber-500">
          <div className="text-2xl font-bold">{runComparison.unmatchedCurrent?.length || 0}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Unmatched Current</div>
        </Card>
        <Card className="text-center p-4 border-l-4 border-l-slate-400">
          <div className="text-2xl font-bold">{runComparison.unmatchedCompare?.length || 0}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Unmatched Compare</div>
        </Card>
      </div>

      {(runComparison.pairComparisons || []).map((pair: any, idx: number) => (
        <Card key={idx} className="overflow-hidden" style={{ animation: `fadeSlideIn 0.3s ease-out ${idx * 0.08}s both` }}>
          <CardHeader className="border-b bg-muted/20">
            <CardTitle className="text-base flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <GitCompare className="h-4 w-4 text-blue-500" />
                <div className={`w-2.5 h-2.5 rounded-full ${getTestTypeColor(pair.testType)}`} />
                <span className="font-semibold">{pair.testType}</span>
              </div>
              <span className="text-muted-foreground font-normal text-sm">{pair.scheduleName}</span>
              <Badge variant="outline" className="text-xs ml-auto font-mono">
                #{pair.currentExecutionId} vs #{pair.compareExecutionId}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="overflow-x-auto rounded-lg border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/30 border-b">
                    <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Metric</th>
                    <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Current</th>
                    <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Previous</th>
                    <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Change</th>
                  </tr>
                </thead>
                <tbody>
                  {pair.metrics?.avgResponseTime && (
                    <tr className="border-b hover:bg-muted/20">
                      <td className="py-2.5 px-3 font-medium">Avg Response Time</td>
                      <td className="text-right py-2.5 px-3 font-mono">{pair.metrics.avgResponseTime.current?.toFixed(0)}ms</td>
                      <td className="text-right py-2.5 px-3 font-mono text-muted-foreground">{pair.metrics.avgResponseTime.compare?.toFixed(0)}ms</td>
                      <td className="text-right py-2.5 px-3">{renderChangePercent(pair.metrics.avgResponseTime.changePercent, true)}</td>
                    </tr>
                  )}
                  {pair.metrics?.throughput && (
                    <tr className="border-b hover:bg-muted/20">
                      <td className="py-2.5 px-3 font-medium">Throughput (TPS)</td>
                      <td className="text-right py-2.5 px-3 font-mono">{pair.metrics.throughput.current?.toFixed(1)}</td>
                      <td className="text-right py-2.5 px-3 font-mono text-muted-foreground">{pair.metrics.throughput.compare?.toFixed(1)}</td>
                      <td className="text-right py-2.5 px-3">{renderChangePercent(pair.metrics.throughput.changePercent, false)}</td>
                    </tr>
                  )}
                  {pair.metrics?.errorRate && (
                    <tr className="border-b hover:bg-muted/20">
                      <td className="py-2.5 px-3 font-medium">Error Rate</td>
                      <td className="text-right py-2.5 px-3 font-mono">{pair.metrics.errorRate.current?.toFixed(2)}%</td>
                      <td className="text-right py-2.5 px-3 font-mono text-muted-foreground">{pair.metrics.errorRate.compare?.toFixed(2)}%</td>
                      <td className="text-right py-2.5 px-3">{renderChangePercent(pair.metrics.errorRate.changePercent, true)}</td>
                    </tr>
                  )}
                  {pair.metrics?.p90 && (
                    <tr className="border-b hover:bg-muted/20">
                      <td className="py-2.5 px-3 font-medium">P90 Response Time</td>
                      <td className="text-right py-2.5 px-3 font-mono">{pair.metrics.p90.current?.toFixed(0)}ms</td>
                      <td className="text-right py-2.5 px-3 font-mono text-muted-foreground">{pair.metrics.p90.compare?.toFixed(0)}ms</td>
                      <td className="text-right py-2.5 px-3">{renderChangePercent(pair.metrics.p90.changePercent, true)}</td>
                    </tr>
                  )}
                  {pair.metrics?.p95 && (
                    <tr className="border-b hover:bg-muted/20">
                      <td className="py-2.5 px-3 font-medium">P95 Response Time</td>
                      <td className="text-right py-2.5 px-3 font-mono">{pair.metrics.p95.current?.toFixed(0)}ms</td>
                      <td className="text-right py-2.5 px-3 font-mono text-muted-foreground">{pair.metrics.p95.compare?.toFixed(0)}ms</td>
                      <td className="text-right py-2.5 px-3">{renderChangePercent(pair.metrics.p95.changePercent, true)}</td>
                    </tr>
                  )}
                  {pair.metrics?.totalRequests && (
                    <tr className="border-b hover:bg-muted/20">
                      <td className="py-2.5 px-3 font-medium">Total Requests</td>
                      <td className="text-right py-2.5 px-3 font-mono">{pair.metrics.totalRequests.current?.toLocaleString()}</td>
                      <td className="text-right py-2.5 px-3 font-mono text-muted-foreground">{pair.metrics.totalRequests.compare?.toLocaleString()}</td>
                      <td className="text-right py-2.5 px-3 text-muted-foreground">-</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {pair.transactionComparison && pair.transactionComparison.length > 0 && (
              <div className="mt-4">
                <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                  <Activity className="h-4 w-4 text-muted-foreground" />
                  Transaction-Level Comparison
                </h4>
                <div className="overflow-x-auto rounded-lg border">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted/30 border-b">
                        <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Transaction</th>
                        <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Avg (Curr)</th>
                        <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Avg (Prev)</th>
                        <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Change</th>
                        <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">P90 (Curr)</th>
                        <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">P90 (Prev)</th>
                        <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Change</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pair.transactionComparison.map((txn: any, tIdx: number) => (
                        <tr key={tIdx} className="border-b hover:bg-muted/20 transition-colors">
                          <td className="py-2.5 px-3 font-medium max-w-[180px] truncate">{txn.label}</td>
                          <td className="text-right py-2.5 px-3 font-mono">{txn.avgCurrent?.toFixed(0)}ms</td>
                          <td className="text-right py-2.5 px-3 font-mono text-muted-foreground">{txn.avgCompare?.toFixed(0)}ms</td>
                          <td className="text-right py-2.5 px-3">{renderChangePercent(txn.avgChange, true)}</td>
                          <td className="text-right py-2.5 px-3 font-mono">{txn.p90Current?.toFixed(0)}ms</td>
                          <td className="text-right py-2.5 px-3 font-mono text-muted-foreground">{txn.p90Compare?.toFixed(0)}ms</td>
                          <td className="text-right py-2.5 px-3">{renderChangePercent(txn.p90Change, true)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ))}

      {(runComparison.pairComparisons || []).length === 0 && (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <GitCompare className="h-8 w-8 mx-auto mb-2 opacity-40" />
            <p className="font-medium">No matching test pairs found</p>
            <p className="text-xs mt-1">Tests are matched by schedule name or script name between current and compare runs.</p>
          </CardContent>
        </Card>
      )}
    </>
  );
}
