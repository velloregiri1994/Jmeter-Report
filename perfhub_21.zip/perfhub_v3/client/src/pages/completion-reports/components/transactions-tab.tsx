import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity } from "lucide-react";
import {
  ResponsiveContainer, ComposedChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip as RechartsTooltip, Legend
} from "recharts";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS } from "@/components/charts/dynatrace-theme";
import { getTestTypeColor } from "./report-detail-utils";

export function TransactionsTab({ sections }: { sections: any[] }) {
  return (
    <>
      {sections.map((section: any, idx: number) => {
        if (!section.transactionDetails || section.transactionDetails.length === 0) return null;
        const txnChartData = section.transactionDetails
          .slice(0, 15)
          .map((txn: any) => ({
            name: (txn.label || '').length > 20 ? txn.label.substring(0, 20) + '...' : txn.label,
            avg: Math.round(txn.avg || 0),
            p95: Math.round(txn.p95 || 0),
            errorRate: parseFloat((txn.errorRate || 0).toFixed(2)),
          }));
        return (
          <Card key={idx} className="overflow-hidden" style={{ animation: `fadeSlideIn 0.3s ease-out ${idx * 0.08}s both` }}>
            <CardHeader className="border-b bg-muted/20">
              <CardTitle className="text-base flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${getTestTypeColor(section.testType)}`} />
                  <span className="font-semibold">{section.testType}</span>
                </div>
                <span className="text-muted-foreground font-normal text-sm">Transaction Details</span>
                <Badge variant="outline" className="text-xs font-normal">{section.scheduleName}</Badge>
                <Badge variant="secondary" className="text-xs ml-auto">{section.transactionDetails.length} transactions</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              {txnChartData.length > 1 && (
                <div className="h-[240px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={txnChartData} layout="vertical" margin={{ left: 20 }}>
                      <CartesianGrid {...DT_GRID_PROPS} />
                      <XAxis type="number" {...DT_AXIS_PROPS} />
                      <YAxis dataKey="name" type="category" {...DT_AXIS_PROPS} width={120} />
                      <RechartsTooltip cursor={DT_CURSOR_PROPS} contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} />
                      <Bar dataKey="avg" name="Avg RT (ms)" fill={DT_COLORS.primary} radius={[0, 3, 3, 0]} barSize={10} />
                      <Bar dataKey="p95" name="P95 RT (ms)" fill={DT_COLORS.amber} radius={[0, 3, 3, 0]} barSize={10} />
                      <Legend iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              )}
              <div className="overflow-x-auto rounded-lg border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/30 border-b">
                      <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Transaction</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Count</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Avg</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">P90</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">P95</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">P99</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Max</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">TPS</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Error %</th>
                    </tr>
                  </thead>
                  <tbody>
                    {section.transactionDetails.map((txn: any, i: number) => (
                      <tr key={i} className="border-b hover:bg-muted/20 transition-colors">
                        <td className="py-2.5 px-3 font-mono text-xs max-w-[200px] truncate font-medium">{txn.label}</td>
                        <td className="py-2.5 px-3 text-right font-mono">{(txn.count || 0).toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right font-mono">{(txn.avg || 0).toFixed(0)}ms</td>
                        <td className="py-2.5 px-3 text-right font-mono">{(txn.p90 || 0).toFixed(0)}ms</td>
                        <td className="py-2.5 px-3 text-right font-mono">{(txn.p95 || 0).toFixed(0)}ms</td>
                        <td className="py-2.5 px-3 text-right font-mono">{(txn.p99 || 0).toFixed(0)}ms</td>
                        <td className="py-2.5 px-3 text-right font-mono">{(txn.max || 0).toFixed(0)}ms</td>
                        <td className="py-2.5 px-3 text-right font-mono">{(txn.throughput || 0).toFixed(1)}</td>
                        <td className={`py-2.5 px-3 text-right font-mono font-medium ${(txn.errorRate || 0) > 1 ? 'text-red-600' : (txn.errorRate || 0) > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                          {(txn.errorRate || 0).toFixed(2)}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        );
      })}
      {sections.every((s: any) => !s.transactionDetails || s.transactionDetails.length === 0) && (
        <div className="text-center py-12 text-muted-foreground">
          <Activity className="h-8 w-8 mx-auto mb-2 opacity-40" />
          <p>No transaction-level details available</p>
        </div>
      )}
    </>
  );
}
