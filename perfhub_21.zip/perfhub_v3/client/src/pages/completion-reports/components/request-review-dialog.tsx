import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Send, ArrowUpRight, ArrowDownRight } from "lucide-react";

export function RequestReviewDialog({ open, onOpenChange, allUsers, currentUserId, selectedReviewers, setSelectedReviewers, onSubmit, isSubmitting }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  allUsers: any[];
  currentUserId?: number;
  selectedReviewers: number[];
  setSelectedReviewers: (v: number[]) => void;
  onSubmit: () => void;
  isSubmitting: boolean;
}) {
  const availableUsers = allUsers.filter(u => u.id !== currentUserId && u.isApproved);

  const toggleReviewer = (userId: number) => {
    setSelectedReviewers(
      selectedReviewers.includes(userId)
        ? selectedReviewers.filter(id => id !== userId)
        : [...selectedReviewers, userId]
    );
  };

  const moveUp = (idx: number) => {
    if (idx === 0) return;
    const arr = [...selectedReviewers];
    [arr[idx - 1], arr[idx]] = [arr[idx], arr[idx - 1]];
    setSelectedReviewers(arr);
  };

  const moveDown = (idx: number) => {
    if (idx >= selectedReviewers.length - 1) return;
    const arr = [...selectedReviewers];
    [arr[idx], arr[idx + 1]] = [arr[idx + 1], arr[idx]];
    setSelectedReviewers(arr);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="h-5 w-5 text-blue-500" />
            Request Sign-Off
          </DialogTitle>
          <DialogDescription>
            Select reviewers who need to approve this report. They will review in the order shown below.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 py-2">
          <div className="text-sm font-medium">Select Reviewers</div>
          <div className="max-h-[200px] overflow-y-auto space-y-1 rounded-md border p-2">
            {availableUsers.length === 0 ? (
              <p className="text-xs text-muted-foreground py-4 text-center">No other approved users available</p>
            ) : (
              availableUsers.map(u => (
                <label key={u.id} className="flex items-center gap-2.5 p-2 rounded-md hover:bg-muted/50 cursor-pointer transition-colors">
                  <Checkbox
                    checked={selectedReviewers.includes(u.id)}
                    onCheckedChange={() => toggleReviewer(u.id)}
                  />
                  <Avatar className="h-6 w-6">
                    <AvatarFallback className="text-[10px] bg-primary/10 text-primary">
                      {u.username.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <span className="text-sm font-medium">{u.username}</span>
                    {u.email && <span className="text-xs text-muted-foreground ml-2">{u.email}</span>}
                  </div>
                  <Badge variant="outline" className="text-[10px] capitalize">{u.role}</Badge>
                </label>
              ))
            )}
          </div>

          {selectedReviewers.length > 0 && (
            <>
              <Separator />
              <div className="text-sm font-medium">Review Order</div>
              <div className="space-y-1">
                {selectedReviewers.map((reviewerId, idx) => {
                  const reviewer = allUsers.find(u => u.id === reviewerId);
                  return (
                    <div key={reviewerId} className="flex items-center gap-2 p-2 rounded-md border bg-muted/30">
                      <span className="text-xs font-bold text-muted-foreground w-5 text-center">{idx + 1}</span>
                      <Avatar className="h-5 w-5">
                        <AvatarFallback className="text-[9px] bg-primary/10 text-primary">
                          {(reviewer?.username || "?").substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm flex-1">{reviewer?.username || `User #${reviewerId}`}</span>
                      <div className="flex gap-0.5">
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => moveUp(idx)} disabled={idx === 0}>
                          <ArrowUpRight className="h-3 w-3 rotate-[-45deg]" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => moveDown(idx)} disabled={idx === selectedReviewers.length - 1}>
                          <ArrowDownRight className="h-3 w-3 rotate-[45deg]" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={onSubmit} disabled={selectedReviewers.length === 0 || isSubmitting} className="gap-1.5">
            <Send className="h-3.5 w-3.5" />
            {isSubmitting ? "Submitting..." : `Submit for Review (${selectedReviewers.length})`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
