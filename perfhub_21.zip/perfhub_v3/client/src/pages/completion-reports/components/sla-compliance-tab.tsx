import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  XCircle, AlertTriangle, Shield, ThumbsUp
} from "lucide-react";
import {
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip as RechartsTooltip
} from "recharts";
import { DT_COLORS } from "@/components/charts/dynatrace-theme";
import { getTestTypeColor } from "./report-detail-utils";

export function SlaComplianceTab({ sla, sections, slaPassed, slaTotal }: {
  sla: any;
  sections: any[];
  slaPassed: number;
  slaTotal: number;
}) {
  return (
    <Card>
      <CardHeader className="border-b bg-muted/20">
        <CardTitle className="text-base flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          SLA Compliance Dashboard
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        {sla ? (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-[200px_1fr] gap-4">
              <div className="flex flex-col items-center justify-center p-4 rounded-xl border bg-card">
                <div className="w-[140px] h-[140px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Passed', value: sla.passed || 0, fill: DT_COLORS.green },
                          { name: 'Failed', value: sla.failed || 0, fill: DT_COLORS.red },
                        ].filter(d => d.value > 0)}
                        cx="50%" cy="50%" innerRadius={40} outerRadius={60}
                        paddingAngle={3} dataKey="value" strokeWidth={0}
                      >
                        {[{ fill: DT_COLORS.green }, { fill: DT_COLORS.red }].filter((_, i) => i === 0 ? (sla.passed || 0) > 0 : (sla.failed || 0) > 0).map((entry, i) => (
                          <Cell key={i} fill={entry.fill} />
                        ))}
                      </Pie>
                      <RechartsTooltip contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className={`text-2xl font-bold -mt-2 ${slaTotal > 0 && sla.failed === 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {slaTotal > 0 ? `${Math.round((slaPassed / slaTotal) * 100)}%` : 'N/A'}
                </div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Pass Rate</div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-4 rounded-xl bg-muted/30 border flex flex-col items-center justify-center">
                  <div className="text-3xl font-bold">{sections.length}</div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Tests Evaluated</div>
                </div>
                <div className="text-center p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 flex flex-col items-center justify-center">
                  <div className="text-3xl font-bold text-emerald-600">{sla.passed}</div>
                  <div className="text-xs text-emerald-600/70 uppercase tracking-wider mt-1">Passed SLA</div>
                </div>
                <div className="text-center p-4 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 flex flex-col items-center justify-center">
                  <div className="text-3xl font-bold text-red-600">{sla.failed}</div>
                  <div className="text-xs text-red-600/70 uppercase tracking-wider mt-1">Failed SLA</div>
                </div>
              </div>
            </div>

            {sla.violations && sla.violations.length > 0 ? (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                  <h4 className="font-semibold text-sm">SLA Violations ({sla.violations.length})</h4>
                </div>
                <div className="overflow-x-auto rounded-lg border">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-red-50/50 dark:bg-red-950/20 border-b">
                        <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Test Type</th>
                        <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Metric</th>
                        <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Transaction</th>
                        <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Threshold</th>
                        <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Actual</th>
                        <th className="text-center py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sla.violations.map((v: any, i: number) => (
                        <tr key={i} className="border-b hover:bg-muted/20 transition-colors">
                          <td className="py-2.5 px-3">
                            <div className="flex items-center gap-2">
                              <div className={`w-2 h-2 rounded-full ${getTestTypeColor(v.testType)}`} />
                              {v.testType}
                            </div>
                          </td>
                          <td className="py-2.5 px-3 font-medium">{v.metric}</td>
                          <td className="py-2.5 px-3 font-mono text-xs">{v.label || 'Global'}</td>
                          <td className="py-2.5 px-3 text-right font-mono">{v.threshold}</td>
                          <td className="py-2.5 px-3 text-right font-mono text-red-600 font-medium">{typeof v.actual === 'number' ? v.actual.toFixed(1) : v.actual}</td>
                          <td className="py-2.5 px-3 text-center">
                            <XCircle className="h-4 w-4 text-red-500 mx-auto" />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 rounded-xl border border-dashed border-emerald-300 dark:border-emerald-700 bg-emerald-50/50 dark:bg-emerald-950/20">
                <ThumbsUp className="h-10 w-10 mx-auto mb-2 text-emerald-500" />
                <p className="font-semibold text-emerald-700 dark:text-emerald-400">All SLA Requirements Met</p>
                <p className="text-xs text-muted-foreground mt-1">No threshold violations detected across all test types</p>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            <Shield className="h-8 w-8 mx-auto mb-2 opacity-40" />
            <p>No SLA data available</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
