import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { format } from "date-fns";
import {
  CheckCircle, XCircle, Clock,
  Send, MessageCircle, UserCheck, Ban, RotateCcw, Pencil, Users, Download
} from "lucide-react";

function getReviewStatusConfig(status: string | null) {
  switch (status) {
    case "in_review":
      return { label: "In Review", color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-50 dark:bg-blue-950/40", border: "border-blue-200 dark:border-blue-700", icon: Clock };
    case "approved":
      return { label: "Approved", color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-50 dark:bg-emerald-950/40", border: "border-emerald-200 dark:border-emerald-700", icon: CheckCircle };
    case "rejected":
      return { label: "Rejected", color: "text-red-600 dark:text-red-400", bg: "bg-red-50 dark:bg-red-950/40", border: "border-red-200 dark:border-red-700", icon: XCircle };
    case "changes_requested":
      return { label: "Changes Requested", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-950/40", border: "border-amber-200 dark:border-amber-700", icon: RotateCcw };
    default:
      return { label: "Draft", color: "text-slate-500 dark:text-slate-400", bg: "bg-slate-50 dark:bg-slate-800/40", border: "border-slate-200 dark:border-slate-700", icon: Pencil };
  }
}

function getApprovalStepConfig(status: string) {
  switch (status) {
    case "approved":
      return { label: "Approved", color: "text-emerald-600", bg: "bg-emerald-100 dark:bg-emerald-900/30", ringColor: "ring-emerald-500", icon: CheckCircle };
    case "rejected":
      return { label: "Rejected", color: "text-red-600", bg: "bg-red-100 dark:bg-red-900/30", ringColor: "ring-red-500", icon: XCircle };
    case "changes_requested":
      return { label: "Changes Requested", color: "text-amber-600", bg: "bg-amber-100 dark:bg-amber-900/30", ringColor: "ring-amber-500", icon: RotateCcw };
    default:
      return { label: "Pending", color: "text-slate-400", bg: "bg-slate-100 dark:bg-slate-800", ringColor: "ring-slate-300", icon: Clock };
  }
}

export function ApprovalWorkflowPanel({ report, approvals, currentUser, onRequestReview, onApprove, onReject, onRequestChanges, onCancelReview, onDownloadReport, approvalComment, setApprovalComment, isActing, isCancelling }: {
  report: any;
  approvals: any[];
  currentUser: any;
  onRequestReview: () => void;
  onApprove: (id: number) => void;
  onReject: (id: number) => void;
  onRequestChanges: (id: number) => void;
  onCancelReview: () => void;
  onDownloadReport: () => void;
  approvalComment: string;
  setApprovalComment: (v: string) => void;
  isActing: boolean;
  isCancelling: boolean;
}) {
  const reviewConfig = getReviewStatusConfig(report.reviewStatus);
  const ReviewIcon = reviewConfig.icon;
  const isAuthor = currentUser?.id === report.createdBy;
  const isAdmin = currentUser?.role === "admin";
  const isLead = currentUser?.role === "lead";
  const canManageReview = isAuthor || isAdmin || isLead;

  const myApproval = approvals.find(a => a.reviewerUserId === currentUser?.id && a.status === "pending");
  const approvedCount = approvals.filter(a => a.status === "approved").length;
  const totalCount = approvals.length;

  return (
    <div className="space-y-4">
      <Card className={`border ${reviewConfig.border} overflow-hidden`}>
        <CardHeader className={`${reviewConfig.bg} border-b pb-4`}>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div className={`flex items-center justify-center w-10 h-10 rounded-lg ${reviewConfig.bg} border ${reviewConfig.border}`}>
                <ReviewIcon className={`h-5 w-5 ${reviewConfig.color}`} />
              </div>
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  Approval Workflow
                  <Badge variant="outline" className={`${reviewConfig.color} ${reviewConfig.border} text-xs`}>
                    {reviewConfig.label}
                  </Badge>
                </CardTitle>
                {totalCount > 0 && (
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {approvedCount} of {totalCount} reviewer(s) approved
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              {canManageReview && (!report.reviewStatus || report.reviewStatus === "draft" || report.reviewStatus === "changes_requested") && (
                <Button size="sm" onClick={onRequestReview} className="gap-1.5">
                  <Send className="h-3.5 w-3.5" />
                  {approvals.length > 0 ? "Re-submit for Review" : "Request Sign-Off"}
                </Button>
              )}
              {canManageReview && report.reviewStatus === "in_review" && (
                <Button variant="outline" size="sm" onClick={onCancelReview} disabled={isCancelling} className="gap-1.5">
                  <Ban className="h-3.5 w-3.5" />
                  Cancel Review
                </Button>
              )}
            </div>
          </div>
          {totalCount > 0 && (
            <div className="mt-3">
              <div className="w-full bg-muted rounded-full h-1.5">
                <div
                  className="bg-emerald-500 h-1.5 rounded-full transition-all duration-500"
                  style={{ width: `${totalCount > 0 ? (approvedCount / totalCount) * 100 : 0}%` }}
                />
              </div>
            </div>
          )}
        </CardHeader>
        <CardContent className="p-0">
          {approvals.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="h-8 w-8 mx-auto mb-2 opacity-40" />
              <p className="font-medium">No reviewers assigned</p>
              <p className="text-xs mt-1">
                {canManageReview
                  ? 'Click "Request Sign-Off" to select reviewers and start the approval process.'
                  : "The report author hasn't requested any reviews yet."}
              </p>
            </div>
          ) : (
            <div className="divide-y">
              {approvals.map((approval: any, idx: number) => {
                const stepConfig = getApprovalStepConfig(approval.status);
                const StepIcon = stepConfig.icon;
                const isMyStep = approval.reviewerUserId === currentUser?.id;
                const canAct = isMyStep && approval.status === "pending" && report.reviewStatus === "in_review";

                return (
                  <div key={approval.id} className={`p-4 ${canAct ? 'bg-blue-50/50 dark:bg-blue-950/20' : ''}`}>
                    <div className="flex items-start gap-3">
                      <div className="flex flex-col items-center gap-1 pt-0.5">
                        <div className={`flex items-center justify-center w-8 h-8 rounded-full ring-2 ${stepConfig.ringColor} ${stepConfig.bg}`}>
                          <StepIcon className={`h-4 w-4 ${stepConfig.color}`} />
                        </div>
                        {idx < approvals.length - 1 && (
                          <div className="w-0.5 h-6 bg-muted-foreground/20 rounded-full" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Step {approval.stepOrder}</span>
                          <Avatar className="h-5 w-5">
                            <AvatarFallback className="text-[9px] bg-primary/10 text-primary">
                              {(approval.reviewerUsername || "?").substring(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium text-sm">{approval.reviewerUsername || `User #${approval.reviewerUserId}`}</span>
                          <Badge variant="outline" className="text-[10px] capitalize">{approval.reviewerRole || "user"}</Badge>
                          <Badge variant={approval.status === "approved" ? "default" : approval.status === "rejected" ? "destructive" : "secondary"} className="text-[10px]">
                            {stepConfig.label}
                          </Badge>
                          {isMyStep && <Badge variant="outline" className="text-[10px] border-blue-300 text-blue-600">You</Badge>}
                        </div>
                        {approval.comment && (
                          <div className="mt-1.5 p-2 rounded-md bg-muted/50 border text-xs text-muted-foreground flex items-start gap-1.5">
                            <MessageCircle className="h-3 w-3 mt-0.5 shrink-0" />
                            <span>{approval.comment}</span>
                          </div>
                        )}
                        {approval.actedAt && (
                          <p className="text-[10px] text-muted-foreground mt-1">
                            {format(new Date(approval.actedAt), "MMM d, yyyy 'at' h:mm a")}
                          </p>
                        )}
                        {canAct && (
                          <div className="mt-3 space-y-2">
                            <div className="flex items-center gap-2 mb-2">
                              <Button size="sm" variant="outline" onClick={onDownloadReport} className="gap-1.5">
                                <Download className="h-3.5 w-3.5" />Download Report
                              </Button>
                              <span className="text-xs text-muted-foreground">Review the full report before signing off</span>
                            </div>
                            <Textarea
                              value={approvalComment}
                              onChange={(e) => setApprovalComment(e.target.value)}
                              placeholder="Add a comment (optional)..."
                              className="min-h-[60px] resize-none text-sm"
                            />
                            <div className="flex gap-2">
                              <Button size="sm" onClick={() => onApprove(approval.id)} disabled={isActing} className="gap-1.5 bg-emerald-600 hover:bg-emerald-700">
                                <CheckCircle className="h-3.5 w-3.5" />Approve
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => onRequestChanges(approval.id)} disabled={isActing} className="gap-1.5 text-amber-600 border-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/20">
                                <RotateCcw className="h-3.5 w-3.5" />Request Changes
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => onReject(approval.id)} disabled={isActing} className="gap-1.5 text-red-600 border-red-300 hover:bg-red-50 dark:hover:bg-red-950/20">
                                <XCircle className="h-3.5 w-3.5" />Reject
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {report.finalApprovedAt && (
        <Card className="border-emerald-200 dark:border-emerald-700 bg-emerald-50/50 dark:bg-emerald-950/20">
          <CardContent className="flex items-center gap-3 py-4">
            <CheckCircle className="h-5 w-5 text-emerald-600" />
            <div>
              <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400">Fully Approved</p>
              <p className="text-xs text-muted-foreground">
                All reviewers signed off on {format(new Date(report.finalApprovedAt), "MMM d, yyyy 'at' h:mm a")}
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
