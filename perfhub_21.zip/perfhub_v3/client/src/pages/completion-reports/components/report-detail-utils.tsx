import {
  CheckCircle, XCircle, AlertTriangle, Clock,
  ArrowUpRight, ArrowDownRight, Minus
} from "lucide-react";

export function getVerdictConfig(verdict: string | null) {
  switch (verdict) {
    case 'go':
      return { label: 'GO', subtitle: 'Ready for Production', icon: CheckCircle, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-950/40', border: 'border-emerald-200 dark:border-emerald-700', gradient: 'from-emerald-500/10 via-emerald-500/5 to-transparent' };
    case 'no_go':
      return { label: 'NO GO', subtitle: 'Not Ready', icon: XCircle, color: 'text-red-600 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-950/40', border: 'border-red-200 dark:border-red-700', gradient: 'from-red-500/10 via-red-500/5 to-transparent' };
    case 'conditional':
      return { label: 'CONDITIONAL', subtitle: 'With Caveats', icon: AlertTriangle, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-950/40', border: 'border-amber-200 dark:border-amber-700', gradient: 'from-amber-500/10 via-amber-500/5 to-transparent' };
    default:
      return { label: 'PENDING', subtitle: 'Under Review', icon: Clock, color: 'text-slate-500 dark:text-slate-400', bg: 'bg-slate-50 dark:bg-slate-800/40', border: 'border-slate-200 dark:border-slate-700', gradient: 'from-slate-500/10 via-slate-500/5 to-transparent' };
  }
}

export function renderChangePercent(change: number | null | undefined, higherIsBad: boolean) {
  if (change === null || change === undefined || isNaN(change)) return <span className="text-muted-foreground">-</span>;
  const abs = Math.abs(change);
  const isUp = change > 0;
  const isBad = higherIsBad ? isUp : !isUp;
  if (abs < 0.5) return <span className="text-muted-foreground flex items-center justify-end gap-1"><Minus className="h-3 w-3" />{abs.toFixed(1)}%</span>;
  return (
    <span className={`flex items-center justify-end gap-1 font-medium ${isBad ? 'text-red-600' : 'text-emerald-600'}`}>
      {isUp ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
      {isUp ? '+' : ''}{change.toFixed(1)}%
    </span>
  );
}

export function getTestTypeColor(testType: string) {
  const lower = testType.toLowerCase();
  if (lower.includes('load')) return 'bg-blue-500';
  if (lower.includes('stress')) return 'bg-red-500';
  if (lower.includes('endurance') || lower.includes('soak')) return 'bg-purple-500';
  if (lower.includes('spike')) return 'bg-orange-500';
  if (lower.includes('volume')) return 'bg-teal-500';
  if (lower.includes('scalab')) return 'bg-indigo-500';
  return 'bg-slate-500';
}
