import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity } from "lucide-react";
import { format } from "date-fns";
import { getTestTypeColor } from "./report-detail-utils";

export function TestResultsTab({ sections }: { sections: any[] }) {
  return (
    <>
      {sections.map((section: any, idx: number) => (
        <Card key={idx} className="overflow-hidden" style={{ animation: `fadeSlideIn 0.3s ease-out ${idx * 0.08}s both` }}>
          <CardHeader className="border-b bg-muted/20">
            <CardTitle className="text-base flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${getTestTypeColor(section.testType)}`} />
                <span className="font-semibold">{section.testType}</span>
              </div>
              <Badge variant="outline" className="text-xs font-normal">{section.scheduleName}</Badge>
              <Badge variant={section.status === 'completed' ? 'default' : 'destructive'} className="text-xs">
                {section.status}
              </Badge>
              {section.errorRate > 1 && (
                <Badge variant="destructive" className="text-xs ml-auto">High Error Rate</Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 mb-4">
              {[
                { label: 'Script', value: section.scriptName },
                { label: 'Environment', value: section.environment },
                { label: 'Virtual Users', value: section.vusers },
                { label: 'Duration', value: section.duration > 0 ? `${Math.round(section.duration / 60)}m` : 'N/A' },
                { label: 'Start', value: section.startTime ? format(new Date(section.startTime), "MMM d, h:mm a") : 'N/A' },
                { label: 'End', value: section.endTime ? format(new Date(section.endTime), "MMM d, h:mm a") : 'N/A' },
              ].map((item, i) => (
                <div key={i} className="p-2 rounded-lg bg-muted/30 text-center">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">{item.label}</div>
                  <div className="text-sm font-medium truncate mt-0.5">{item.value}</div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="p-3 rounded-lg border text-center">
                <div className="text-xl font-bold">{(section.totalRequests || 0).toLocaleString()}</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Total Requests</div>
              </div>
              <div className="p-3 rounded-lg border text-center">
                <div className={`text-xl font-bold ${section.failedRequests > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                  {(section.failedRequests || 0).toLocaleString()}
                </div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Failed</div>
              </div>
              <div className="p-3 rounded-lg border text-center">
                <div className="text-xl font-bold">{(section.avgResponseTime || 0).toFixed(0)}<span className="text-xs font-normal text-muted-foreground ml-0.5">ms</span></div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Avg RT</div>
              </div>
              <div className="p-3 rounded-lg border text-center">
                <div className="text-xl font-bold">{(section.throughput || 0).toFixed(1)}<span className="text-xs font-normal text-muted-foreground ml-0.5">/s</span></div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Throughput</div>
              </div>
              <div className="p-3 rounded-lg border text-center">
                <div className={`text-xl font-bold ${(section.errorRate || 0) > 1 ? 'text-red-600' : 'text-emerald-600'}`}>
                  {(section.errorRate || 0).toFixed(2)}<span className="text-xs font-normal ml-0.5">%</span>
                </div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Error Rate</div>
              </div>
            </div>

            {(section.p50 || section.p90 || section.p95 || section.p99) && (
              <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { label: 'P50', value: section.p50 },
                  { label: 'P90', value: section.p90 },
                  { label: 'P95', value: section.p95 },
                  { label: 'P99', value: section.p99 },
                ].filter(p => p.value).map((p, i) => (
                  <div key={i} className="p-2 rounded bg-muted/30 text-center">
                    <div className="text-xs font-medium">{p.value?.toFixed(0)}ms</div>
                    <div className="text-[10px] text-muted-foreground">{p.label}</div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      ))}
      {sections.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Activity className="h-8 w-8 mx-auto mb-2 opacity-40" />
          <p>No test execution data available</p>
        </div>
      )}
    </>
  );
}
