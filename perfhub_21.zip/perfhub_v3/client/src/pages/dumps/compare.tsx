import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { PageHeader } from "@/components/page-header";
import { GitCompare, TrendingUp, AlertTriangle, Search, Clock, Plus, X, ArrowRight } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from "recharts";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS, DT_PALETTE } from "@/components/charts/dynatrace-theme";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { formatDistanceToNow } from "date-fns";

interface DumpFile {
  id: number;
  name: string;
  type: 'heap' | 'thread';
  fileSize: number;
  status: string;
  createdAt: string;
}

interface DumpComparison {
  id: number;
  name: string;
  dumpFileIds: number[];
  comparisonType: string;
  results: {
    growthTrends?: {
      className: string;
      instanceCounts: number[];
      sizeTrends: number[];
      growthRate: number;
    }[];
    threadStateTrends?: {
      timestamp: string;
      runnable: number;
      blocked: number;
      waiting: number;
    }[];
    stuckThreads?: {
      threadName: string;
      state: string;
      stackSignature: string;
      appearsInDumps: number;
      totalDumps: number;
    }[];
    detectedIssues?: {
      type: string;
      severity: 'warning' | 'critical';
      description: string;
      relatedThreads: string[];
    }[];
    memoryTrends?: {
      timestamp: string;
      usedHeap: number;
      totalHeap: number;
    }[];
  };
  createdAt: string;
}

interface ThreadTimeline {
  threadName: string;
  states: (string | null)[];
}

function ThreadTimelineView({ 
  stuckThreads, 
  threadStateTrends, 
  dumpFileIds,
  searchQuery,
  onSearchChange 
}: {
  stuckThreads: any[];
  threadStateTrends: any[];
  dumpFileIds: number[];
  searchQuery: string;
  onSearchChange: (query: string) => void;
}) {
  const [dumpAnalyses, setDumpAnalyses] = useState<any[]>([]);

  useEffect(() => {
    const fetchDumps = async () => {
      try {
        const results = await Promise.all(
          dumpFileIds.map(id =>
            apiRequest("GET", `/api/dumps/${id}`).then(r => r.json()).catch(() => null)
          )
        );
        setDumpAnalyses(results.filter(Boolean));
      } catch { /* ignore */ }
    };
    if (dumpFileIds.length > 0) fetchDumps();
  }, [dumpFileIds.join(',')]);

  const getStateColor = (state: string | null) => {
    if (!state) return 'bg-gray-200 dark:bg-gray-700';
    switch (state.toUpperCase()) {
      case 'RUNNABLE':
        return 'bg-green-400 dark:bg-green-600';
      case 'BLOCKED':
        return 'bg-red-400 dark:bg-red-600';
      case 'WAITING':
        return 'bg-orange-400 dark:bg-orange-600';
      case 'TIMED_WAITING':
        return 'bg-yellow-400 dark:bg-yellow-600';
      default:
        return 'bg-gray-300 dark:bg-gray-600';
    }
  };

  const getStateLabel = (state: string | null) => {
    if (!state) return 'N/A';
    return state.replace(/_/g, ' ');
  };

  const buildThreadTimelines = useMemo(() => {
    const threadMap = new Map<string, (string | null)[]>();
    const numDumps = dumpFileIds.length;
    
    dumpAnalyses.forEach((dump, dumpIndex) => {
      if (!dump?.analyses?.[0]?.threads) return;
      const threads: any[] = dump.analyses[0].threads;
      threads.forEach((thread: any) => {
        if (!threadMap.has(thread.name)) {
          threadMap.set(thread.name, Array(numDumps).fill(null));
        }
        threadMap.get(thread.name)![dumpIndex] = thread.state;
      });
    });

    if (threadMap.size === 0) {
      stuckThreads.forEach((st) => {
        if (!threadMap.has(st.threadName)) {
          threadMap.set(st.threadName, Array(numDumps).fill(null));
        }
        const timeline = threadMap.get(st.threadName)!;
        for (let i = 0; i < timeline.length; i++) {
          if (timeline[i] === null) {
            timeline[i] = st.state;
          }
        }
      });
    }

    return Array.from(threadMap.entries()).map(([name, states]) => ({
      threadName: name,
      states,
    }));
  }, [stuckThreads, dumpFileIds, dumpAnalyses]);

  const filteredTimelines = useMemo(() => {
    return buildThreadTimelines.filter(t => 
      t.threadName.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [buildThreadTimelines, searchQuery]);

  const dumpLabels = useMemo(() => {
    return threadStateTrends.map((_, i) => `Dump ${i + 1}`);
  }, [threadStateTrends]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-blue-500" />
          <h3 className="font-medium">Thread Timeline View</h3>
        </div>
      </div>

      <div className="flex items-center gap-2 mb-4">
        <Search className="h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search threads by name..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="flex-1 h-8"
        />
        <span className="text-xs text-muted-foreground">
          {filteredTimelines.length} of {buildThreadTimelines.length} threads
        </span>
      </div>

      <div className="overflow-x-auto border rounded-lg bg-muted/30">
        <div className="min-w-max p-4">
          {/* Column headers (dump labels) */}
          <div className="flex gap-2 mb-4">
            <div className="w-48 flex-shrink-0"></div>
            {dumpLabels.map((label, i) => (
              <div key={i} className="w-12 flex-shrink-0 text-center text-xs font-medium">
                {label}
              </div>
            ))}
          </div>

          {/* Thread rows */}
          {filteredTimelines.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {buildThreadTimelines.length === 0 
                ? 'No thread data available for timeline'
                : 'No threads match the search query'}
            </div>
          ) : (
            <div className="space-y-2">
              {filteredTimelines.map((timeline, i) => (
                <div key={i} className="flex gap-2 items-center">
                  <div className="w-48 flex-shrink-0">
                    <div className="text-xs font-mono text-muted-foreground truncate" title={timeline.threadName}>
                      {timeline.threadName}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {timeline.states.map((state, j) => (
                      <div
                        key={j}
                        className={`w-10 h-10 rounded-md flex items-center justify-center cursor-help border border-gray-300 dark:border-gray-600 flex-shrink-0`}
                        title={getStateLabel(state)}
                      >
                        <div className={`w-8 h-8 rounded ${getStateColor(state)}`}></div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Legend */}
          <div className="mt-6 pt-4 border-t flex flex-wrap gap-4 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-green-400 dark:bg-green-600"></div>
              <span>RUNNABLE</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-red-400 dark:bg-red-600"></div>
              <span>BLOCKED</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-orange-400 dark:bg-orange-600"></div>
              <span>WAITING</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-yellow-400 dark:bg-yellow-600"></div>
              <span>TIMED_WAITING</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-gray-300 dark:bg-gray-600"></div>
              <span>NOT PRESENT</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CompareDumpsPage() {
  const [baseDumpId, setBaseDumpId] = useState<string>("");
  const [currentDumpId, setCurrentDumpId] = useState<string>("");
  const [additionalDumpIds, setAdditionalDumpIds] = useState<string[]>([]);
  const [comparisonName, setComparisonName] = useState("");
  const [comparisonType, setComparisonType] = useState<'heap' | 'thread'>('heap');
  const [timelineThreadSearch, setTimelineThreadSearch] = useState<{[key: number]: string}>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: dumps = [], isError: dumpsError, error: dumpsErr, refetch: refetchDumps } = useQuery<DumpFile[]>({
    queryKey: [...queryKeys.dumps.all],
  });

  const { data: comparisons = [], isError: comparisonsError, error: comparisonsErr, refetch: refetchComparisons } = useQuery<DumpComparison[]>({
    queryKey: [...queryKeys.dumps.comparisons],
  });

  const createComparisonMutation = useMutation({
    mutationFn: async (data: { name: string; dumpFileIds: number[]; comparisonType: string }) => {
      const response = await apiRequest("POST", '/api/dump-comparisons', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.dumps.comparisons });
      setBaseDumpId("");
      setCurrentDumpId("");
      setAdditionalDumpIds([]);
      setComparisonName("");
      toast({ title: 'Comparison created', description: 'Trend analysis complete' });
    },
    onError: (error: any) => {
      toast({ title: 'Failed', description: error.message, variant: 'destructive' });
    }
  });

  const filteredDumps = dumps.filter(d => d.status === 'completed' && d.type === comparisonType);

  const selectedDumpIds = useMemo(() => {
    const ids: number[] = [];
    if (baseDumpId) ids.push(Number(baseDumpId));
    if (currentDumpId) ids.push(Number(currentDumpId));
    additionalDumpIds.forEach(id => { if (id) ids.push(Number(id)); });
    return ids;
  }, [baseDumpId, currentDumpId, additionalDumpIds]);

  const getAvailableDumpsFor = (excludeIds: string[]) => {
    return filteredDumps.filter(d => !excludeIds.includes(String(d.id)));
  };

  const handleCreateComparison = () => {
    if (selectedDumpIds.length < 2) {
      toast({ title: 'Select at least a base and current dump', variant: 'destructive' });
      return;
    }
    if (!comparisonName.trim()) {
      toast({ title: 'Enter a comparison name', variant: 'destructive' });
      return;
    }
    createComparisonMutation.mutate({
      name: comparisonName,
      dumpFileIds: selectedDumpIds,
      comparisonType,
    });
  };

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  };

  const getDumpLabel = (dump: DumpFile) => {
    return `${dump.name} (${formatBytes(dump.fileSize)} - ${formatDistanceToNow(new Date(dump.createdAt), { addSuffix: true })})`;
  };

  const handleTypeChange = (v: 'heap' | 'thread') => {
    setComparisonType(v);
    setBaseDumpId("");
    setCurrentDumpId("");
    setAdditionalDumpIds([]);
  };

  const addAdditionalDump = () => {
    setAdditionalDumpIds(prev => [...prev, ""]);
  };

  const removeAdditionalDump = (index: number) => {
    setAdditionalDumpIds(prev => prev.filter((_, i) => i !== index));
  };

  const updateAdditionalDump = (index: number, value: string) => {
    setAdditionalDumpIds(prev => prev.map((id, i) => i === index ? value : id));
  };

  const allSelectedIds = [baseDumpId, currentDumpId, ...additionalDumpIds].filter(Boolean);

  if (dumpsError) {
    return <QueryErrorFallback error={dumpsErr} onRetry={() => refetchDumps()} title="Failed to load dump files" />;
  }

  if (comparisonsError) {
    return <QueryErrorFallback error={comparisonsErr} onRetry={() => refetchComparisons()} title="Failed to load comparisons" />;
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Compare Dumps"
        subtitle="Analyze trends across multiple dump files by selecting a base (previous) and current dump"
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GitCompare className="h-5 w-5" />
              Create New Comparison
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <label className="text-sm font-medium">Comparison Name</label>
              <Input
                value={comparisonName}
                onChange={(e) => setComparisonName(e.target.value)}
                placeholder="e.g., Memory Growth Analysis"
                className="mt-1"
              />
            </div>

            <div>
              <label className="text-sm font-medium">Dump Type</label>
              <Select value={comparisonType} onValueChange={handleTypeChange}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="heap">Heap Dumps</SelectItem>
                  <SelectItem value="thread">Thread Dumps</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {filteredDumps.length === 0 ? (
              <div className="p-6 text-center border rounded-lg bg-muted/30">
                <p className="text-muted-foreground">No completed {comparisonType} dumps available.</p>
                <p className="text-xs text-muted-foreground mt-1">Upload and analyze dump files first.</p>
              </div>
            ) : filteredDumps.length < 2 ? (
              <div className="p-6 text-center border rounded-lg bg-muted/30">
                <p className="text-muted-foreground">Only {filteredDumps.length} completed {comparisonType} dump available.</p>
                <p className="text-xs text-muted-foreground mt-1">You need at least 2 dumps to create a comparison.</p>
              </div>
            ) : (
              <>
                <div className="space-y-4">
                  <div className="p-4 rounded-lg border bg-muted/20">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-200">Base</Badge>
                      <span className="text-sm text-muted-foreground">Previous / baseline dump</span>
                    </div>
                    <Select value={baseDumpId} onValueChange={setBaseDumpId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select base dump..." />
                      </SelectTrigger>
                      <SelectContent>
                        {getAvailableDumpsFor([currentDumpId, ...additionalDumpIds]).map(dump => (
                          <SelectItem key={dump.id} value={String(dump.id)}>
                            {getDumpLabel(dump)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex justify-center">
                    <ArrowRight className="h-5 w-5 text-muted-foreground rotate-90" />
                  </div>

                  <div className="p-4 rounded-lg border bg-muted/20">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-200">Current</Badge>
                      <span className="text-sm text-muted-foreground">Latest / current dump</span>
                    </div>
                    <Select value={currentDumpId} onValueChange={setCurrentDumpId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select current dump..." />
                      </SelectTrigger>
                      <SelectContent>
                        {getAvailableDumpsFor([baseDumpId, ...additionalDumpIds]).map(dump => (
                          <SelectItem key={dump.id} value={String(dump.id)}>
                            {getDumpLabel(dump)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {additionalDumpIds.map((dumpId, index) => (
                    <div key={index} className="p-4 rounded-lg border bg-muted/20">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="bg-purple-500/10 text-purple-600 border-purple-200">Extra {index + 1}</Badge>
                          <span className="text-sm text-muted-foreground">Additional dump</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-muted-foreground hover:text-destructive"
                          onClick={() => removeAdditionalDump(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                      <Select value={dumpId} onValueChange={(v) => updateAdditionalDump(index, v)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select dump..." />
                        </SelectTrigger>
                        <SelectContent>
                          {getAvailableDumpsFor([baseDumpId, currentDumpId, ...additionalDumpIds.filter((_, i) => i !== index)]).map(dump => (
                            <SelectItem key={dump.id} value={String(dump.id)}>
                              {getDumpLabel(dump)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  ))}
                </div>

                {filteredDumps.length > 2 + additionalDumpIds.length && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={addAdditionalDump}
                    className="w-full"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Another Dump
                  </Button>
                )}

                <Button
                  onClick={handleCreateComparison}
                  disabled={!baseDumpId || !currentDumpId || !comparisonName.trim() || createComparisonMutation.isPending}
                  className="w-full"
                >
                  {createComparisonMutation.isPending ? 'Creating...' : `Compare ${selectedDumpIds.length} Dumps`}
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Previous Comparisons</CardTitle>
          </CardHeader>
          <CardContent>
            {comparisons.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No comparisons created yet
              </div>
            ) : (
              <div className="space-y-3">
                {comparisons.map((comparison) => {
                  const compDumps = comparison.dumpFileIds.map(id => dumps.find(d => d.id === id)).filter(Boolean) as DumpFile[];
                  return (
                    <div key={comparison.id} className="border rounded-lg p-4 hover:bg-muted/30 transition-colors">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{comparison.name}</span>
                        <Badge>{comparison.comparisonType}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">
                        {comparison.dumpFileIds.length} dumps compared
                      </p>
                      {compDumps.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {compDumps.map((d, i) => (
                            <Badge key={d.id} variant="outline" className="text-xs">
                              {i === 0 ? 'Base: ' : i === 1 ? 'Current: ' : ''}{d.name}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {comparisons.length > 0 && (
        <div className="space-y-6">
          {comparisons.map((comparison) => (
            <Card key={comparison.id}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  {comparison.name}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {comparison.comparisonType === 'heap' && comparison.results?.growthTrends ? (
                  <div className="space-y-4">
                    <h3 className="font-medium">Memory Growth Trends (Top Growing Classes)</h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2">Class Name</th>
                            <th className="text-right py-2">Growth Rate</th>
                            <th className="text-right py-2">Instance Trend</th>
                          </tr>
                        </thead>
                        <tbody>
                          {comparison.results.growthTrends.slice(0, 10).map((trend, i) => (
                            <tr key={i} className="border-b">
                              <td className="py-2 font-mono text-xs">{trend.className}</td>
                              <td className={`py-2 text-right ${trend.growthRate > 0 ? 'text-red-500' : 'text-green-500'}`}>
                                {trend.growthRate > 0 ? '+' : ''}{trend.growthRate.toFixed(1)}%
                              </td>
                              <td className="py-2 text-right">
                                {trend.instanceCounts.join(' → ')}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {comparison.results.memoryTrends && comparison.results.memoryTrends.length > 0 && (
                      <div>
                        <h3 className="font-medium mb-2">Memory Usage Over Time</h3>
                        <div className="h-48 sm:h-64">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={comparison.results.memoryTrends}>
                              <CartesianGrid {...DT_GRID_PROPS} />
                              <XAxis dataKey="timestamp" {...DT_AXIS_PROPS} />
                              <YAxis tickFormatter={(v) => formatBytes(v)} {...DT_AXIS_PROPS} />
                              <Tooltip formatter={(v: number) => formatBytes(v)} contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} cursor={DT_CURSOR_PROPS} />
                              <Legend />
                              <Line type="monotone" dataKey="usedHeap" stroke={DT_COLORS.primary} name="Used Heap" />
                              <Line type="monotone" dataKey="totalHeap" stroke={DT_COLORS.green} name="Total Heap" />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    )}
                  </div>
                ) : comparison.comparisonType === 'thread' && comparison.results?.threadStateTrends ? (
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-medium mb-4">Thread State Trends</h3>
                      <div className="h-48 sm:h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={comparison.results.threadStateTrends}>
                            <CartesianGrid {...DT_GRID_PROPS} />
                            <XAxis dataKey="timestamp" {...DT_AXIS_PROPS} />
                            <YAxis {...DT_AXIS_PROPS} />
                            <Tooltip contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} cursor={DT_CURSOR_PROPS} />
                            <Legend />
                            <Bar dataKey="runnable" fill={DT_COLORS.green} name="Runnable" />
                            <Bar dataKey="blocked" fill={DT_COLORS.red} name="Blocked" />
                            <Bar dataKey="waiting" fill={DT_COLORS.orange} name="Waiting" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {comparison.results.detectedIssues && comparison.results.detectedIssues.length > 0 && (
                      <div>
                        <h3 className="font-medium mb-3 flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4 text-orange-500" />
                          Cross-Dump Issues
                        </h3>
                        <div className="space-y-2">
                          {comparison.results.detectedIssues.map((issue, i) => (
                            <div key={i} className={`p-3 rounded-lg border ${issue.severity === 'critical' ? 'bg-red-50 dark:bg-red-950 border-red-200' : 'bg-yellow-50 dark:bg-yellow-950 border-yellow-200'}`}>
                              <div className="flex items-center gap-2 mb-1">
                                <Badge variant={issue.severity === 'critical' ? 'destructive' : 'secondary'}>{issue.severity}</Badge>
                                <span className="font-medium text-sm">{issue.type.replace(/_/g, ' ')}</span>
                              </div>
                              <p className="text-sm">{issue.description}</p>
                              {issue.relatedThreads.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {issue.relatedThreads.slice(0, 10).map((t, j) => (
                                    <Badge key={j} variant="outline" className="text-xs font-mono">{t}</Badge>
                                  ))}
                                  {issue.relatedThreads.length > 10 && (
                                    <Badge variant="outline" className="text-xs">+{issue.relatedThreads.length - 10} more</Badge>
                                  )}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {comparison.results.stuckThreads && comparison.results.stuckThreads.length > 0 && (
                      <div>
                        <h3 className="font-medium mb-3">Stuck Threads ({comparison.results.stuckThreads.length})</h3>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-2 pr-4">Thread Name</th>
                                <th className="text-left py-2 pr-4">State</th>
                                <th className="text-left py-2 pr-4">Top Stack Frame</th>
                                <th className="text-right py-2">Consecutive Dumps</th>
                              </tr>
                            </thead>
                            <tbody>
                              {comparison.results.stuckThreads.map((st, i) => (
                                <tr key={i} className="border-b">
                                  <td className="py-2 pr-4 font-mono text-xs">{st.threadName}</td>
                                  <td className="py-2 pr-4">
                                    <Badge variant={st.state === 'BLOCKED' ? 'destructive' : 'secondary'} className="text-xs">{st.state}</Badge>
                                  </td>
                                  <td className="py-2 pr-4 font-mono text-xs max-w-xs truncate">{st.stackSignature}</td>
                                  <td className="py-2 text-right">
                                    <span className={st.appearsInDumps >= st.totalDumps ? 'text-red-500 font-semibold' : ''}>
                                      {st.appearsInDumps}/{st.totalDumps}
                                    </span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}

                    {comparison.results.threadStateTrends && comparison.results.threadStateTrends.length > 0 && (
                      <ThreadTimelineView 
                        stuckThreads={comparison.results.stuckThreads || []}
                        threadStateTrends={comparison.results.threadStateTrends}
                        dumpFileIds={comparison.dumpFileIds}
                        searchQuery={timelineThreadSearch[comparison.id] || ''}
                        onSearchChange={(query) => setTimelineThreadSearch(prev => ({ ...prev, [comparison.id]: query }))}
                      />
                    )}
                  </div>
                ) : (
                  <div className="text-center py-4 text-muted-foreground">
                    No trend data available
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
