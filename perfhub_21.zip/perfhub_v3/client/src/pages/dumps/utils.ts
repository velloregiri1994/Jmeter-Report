import { useState, useEffect } from "react";
import type { ThreadInfo, FlameNode, DetectedIssue, ContentionInfo, ThreadSummary, GcMetrics, Recommendation } from "./types";

export function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

export function useDebounce(value: string, delay: number) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}

export function categorizeThread(name: string): string {
  const lower = name.toLowerCase();
  if (lower.includes('http-nio') || lower.includes('http-')) return 'HTTP/Tomcat Pool';
  if (lower.includes('hikaripool') || lower.includes('hikari')) return 'Database Pool (HikariCP)';
  if (lower.includes('pool-') || lower.includes('scheduled') || lower.includes('executor')) return 'Scheduled/Executor Pool';
  if (lower.includes('gc') || lower.includes('g1')) return 'GC Threads';
  if (lower.includes('c1 compiler') || lower.includes('c2 compiler')) return 'JIT Compiler';
  if (lower.includes('finalizer') || lower.includes('reference handler')) return 'JVM Internal';
  return 'Application Threads';
}

export function getPackageColor(method: string): string {
  if (method.startsWith('java.') || method.startsWith('javax.')) return '#3b82f6';
  if (method.startsWith('com.example.') || method.startsWith('com.myapp.')) return '#22c55e';
  if (method.startsWith('org.apache.')) return '#f97316';
  if (method.startsWith('org.springframework.')) return '#a855f7';
  if (method.startsWith('sun.') || method.startsWith('jdk.')) return '#6366f1';
  if (method.startsWith('org.hibernate.') || method.startsWith('com.zaxxer.')) return '#ec4899';
  return '#64748b';
}

export function buildFlameGraph(threads: ThreadInfo[]): FlameNode {
  const root: FlameNode = { name: 'all threads', fullPath: 'all threads', value: 0, children: [] };

  for (const thread of threads) {
    if (!thread.stackTrace || thread.stackTrace.length === 0) continue;
    const reversed = [...thread.stackTrace].reverse();
    let current = root;
    root.value++;
    for (const frame of reversed) {
      let child = current.children.find(c => c.name === frame);
      if (!child) {
        child = { name: frame, fullPath: frame, value: 0, children: [] };
        current.children.push(child);
      }
      child.value++;
      current = child;
    }
  }
  return root;
}

export function getFlameDepth(node: FlameNode, current: number = 0): number {
  if (node.children.length === 0) return current;
  return Math.max(...node.children.map(c => getFlameDepth(c, current + 1)));
}

export function generateRecommendations(
  detectedIssues: DetectedIssue[],
  contention: ContentionInfo[],
  summary: ThreadSummary | undefined,
  threads: ThreadInfo[],
  gcMetrics?: GcMetrics
): Recommendation[] {
  const recs: Recommendation[] = [];

  for (const issue of detectedIssues) {
    if (issue.type === 'deadlock') {
      recs.push({
        severity: 'critical',
        category: 'Deadlock',
        message: `Deadlock involving ${issue.relatedThreads.length} threads (${issue.relatedThreads.join(', ')}) - review lock ordering and consider using tryLock() with timeout`,
      });
    }
    if (issue.type === 'thread_pool_saturation') {
      recs.push({
        severity: 'critical',
        category: 'Thread Pool',
        message: `${issue.description} - consider increasing thread pool size or reducing task duration`,
      });
    }
    if (issue.type === 'blocked_contention') {
      recs.push({
        severity: 'warning',
        category: 'Lock Contention',
        message: `${issue.description} - consider reducing synchronized block scope or using ConcurrentHashMap`,
      });
    }
    if (issue.type === 'stuck_thread') {
      recs.push({
        severity: 'warning',
        category: 'Stuck Thread',
        message: `${issue.description} - check for infinite loops or long I/O operations`,
      });
    }
    if (issue.type === 'high_blocked_ratio') {
      recs.push({
        severity: 'warning',
        category: 'Blocked Threads',
        message: `${issue.description} - review contended locks and consider lock-free alternatives`,
      });
    }
  }

  for (const c of contention) {
    if (c.waitingThreads >= 3) {
      recs.push({
        severity: c.waitingThreads >= 5 ? 'critical' : 'warning',
        category: 'Lock Contention',
        message: `Lock contention on ${c.lockName} - ${c.waitingThreads} threads waiting, held by ${c.holdingThread}. Consider using ReadWriteLock or ConcurrentHashMap`,
      });
    }
  }

  if (summary) {
    const total = summary.totalThreads || 1;
    const waitingPct = ((summary.waiting + summary.timedWaiting) / total) * 100;
    if (waitingPct > 60) {
      recs.push({
        severity: 'warning',
        category: 'Thread States',
        message: `High ratio of WAITING threads (${waitingPct.toFixed(1)}%) - check for thread pool sizing and ensure tasks complete in a timely manner`,
      });
    }
    const blockedPct = (summary.blocked / total) * 100;
    if (blockedPct > 20) {
      recs.push({
        severity: 'critical',
        category: 'Thread States',
        message: `${blockedPct.toFixed(1)}% of threads are BLOCKED - significant lock contention detected. Review synchronized blocks and consider concurrent data structures`,
      });
    }
  }

  if (gcMetrics?.gcThreads && gcMetrics.gcThreads.gcOverheadPct > 10) {
    recs.push({
      severity: gcMetrics.gcThreads.gcOverheadPct > 25 ? 'critical' : 'warning',
      category: 'GC Performance',
      message: `GC overhead is ${gcMetrics.gcThreads.gcOverheadPct.toFixed(1)}% - consider tuning heap size or GC algorithm. High GC overhead reduces application throughput`,
    });
  }

  if (recs.length === 0) {
    recs.push({
      severity: 'info',
      category: 'General',
      message: 'No significant issues detected. Thread dump appears healthy.',
    });
  }

  return recs;
}
