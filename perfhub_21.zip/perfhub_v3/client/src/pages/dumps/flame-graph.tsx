import { useState } from "react";
import type { FlameNode } from "./types";
import { getPackageColor } from "./utils";

export function FlameGraphRenderer({ node, totalValue, depth = 0, xOffset = 0, width = 100 }: { node: FlameNode; totalValue: number; depth?: number; xOffset?: number; width?: number }) {
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const barHeight = 22;
  const maxDepth = 15;

  if (depth > maxDepth) return null;

  const nodeWidth = (node.value / totalValue) * width;
  if (nodeWidth < 0.3) return null;

  const shortName = node.name.split('.').pop() || node.name;
  const color = depth === 0 ? '#475569' : getPackageColor(node.name);

  let childXOffset = xOffset;

  return (
    <>
      <div
        style={{
          position: 'absolute',
          left: `${xOffset}%`,
          bottom: `${depth * barHeight}px`,
          width: `${nodeWidth}%`,
          height: `${barHeight - 1}px`,
          backgroundColor: hoveredNode === `${depth}-${node.name}` ? '#fbbf24' : color,
          cursor: 'pointer',
          overflow: 'hidden',
          whiteSpace: 'nowrap',
          textOverflow: 'ellipsis',
          fontSize: '11px',
          lineHeight: `${barHeight - 1}px`,
          paddingLeft: '2px',
          paddingRight: '2px',
          color: '#fff',
          borderRight: '1px solid rgba(0,0,0,0.1)',
          transition: 'background-color 0.15s',
        }}
        title={`${node.fullPath}\n${node.value} thread(s)`}
        onMouseEnter={() => setHoveredNode(`${depth}-${node.name}`)}
        onMouseLeave={() => setHoveredNode(null)}
      >
        {nodeWidth > 3 ? shortName : ''}
      </div>
      {node.children.map((child, i) => {
        const childWidth = (child.value / totalValue) * width;
        const currentOffset = childXOffset;
        childXOffset += childWidth;
        return (
          <FlameGraphRenderer
            key={`${depth}-${i}-${child.name}`}
            node={child}
            totalValue={totalValue}
            depth={depth + 1}
            xOffset={currentOffset}
            width={childWidth}
          />
        );
      })}
    </>
  );
}
