import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { PageHeader } from "@/components/page-header";
import { Skeleton } from "@/components/ui/skeleton";
import { queryKeys } from "@/lib/query-keys";
import { QueryErrorFallback } from "@/components/error-boundary";
import type { DumpFile } from "./types";
import { formatBytes } from "./utils";
import { ThreadDumpAnalysis } from "./thread-dump-analysis";
import { HeapDumpAnalysis } from "./heap-dump-analysis";

export default function DumpDetailPage() {
  const params = useParams();
  const dumpId = parseInt(params.id as string);

  const { data: dump, isLoading, isError, error, refetch } = useQuery<DumpFile>({
    queryKey: [...queryKeys.dumps.detail(dumpId)],
    enabled: !isNaN(dumpId),
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="space-y-2">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-40" />
        </div>
        <Card>
          <CardContent className="py-8 space-y-4">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isError) return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load dump analysis" />;

  if (!dump) {
    return <div className="p-6 text-center">Dump not found</div>;
  }

  const analysis = dump.analyses?.[0];

  return (
    <div className="space-y-6">
      <PageHeader
        title={dump.name}
        subtitle={`${dump.type === 'heap' ? 'Heap Dump' : 'Thread Dump'} · ${dump.status}`}
      />

      {!analysis ? (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            Analysis not yet available. Please wait for processing to complete.
          </CardContent>
        </Card>
      ) : dump.type === 'thread' ? (
        <ThreadDumpAnalysis analysis={analysis} formatBytes={formatBytes} dumpId={dumpId} />
      ) : (
        <HeapDumpAnalysis analysis={analysis} formatBytes={formatBytes} dumpId={dump.id} />
      )}
    </div>
  );
}
