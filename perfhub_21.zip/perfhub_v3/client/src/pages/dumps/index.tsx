import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Upload, Trash2, FileText, Database, RefreshCw, Eye, GitCompare } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { PageHeader } from "@/components/page-header";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { EmptyState, emptyStates } from "@/components/empty-state";

interface DumpFile {
  id: number;
  name: string;
  type: 'heap' | 'thread';
  fileSize: number;
  status: string;
  createdAt: string;
}

export default function DumpsPage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dumpType, setDumpType] = useState<'thread' | 'heap'>('thread');
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: dumps = [], isLoading, isError, error, refetch } = useQuery<DumpFile[]>({
    queryKey: [...queryKeys.dumps.all],
  });

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/dumps/upload', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: formData,
        credentials: 'include',
      });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.message || 'Upload failed');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.dumps.all });
      setSelectedFile(null);
      toast({ title: 'Upload successful', description: 'Analysis will start automatically' });
    },
    onError: (error: any) => {
      toast({ title: 'Upload failed', description: error.message, variant: 'destructive' });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/dumps/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.dumps.all });
      toast({ title: 'Deleted', description: 'Dump file removed' });
    }
  });

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      setSelectedFile(files[0]);
      const ext = files[0].name.toLowerCase();
      if (ext.endsWith('.hprof') || ext.endsWith('.bin')) {
        setDumpType('heap');
      } else {
        setDumpType('thread');
      }
    }
  };

  const handleUpload = () => {
    if (!selectedFile) return;
    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('type', dumpType);
    uploadMutation.mutate(formData);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const getStatusBadgeStyle = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20 hover:bg-emerald-500/20';
      case 'analyzing':
        return 'bg-blue-500/10 text-blue-600 border-blue-500/20 hover:bg-blue-500/20';
      case 'failed':
        return 'bg-rose-500/10 text-rose-600 border-rose-500/20 hover:bg-rose-500/20';
      case 'pending':
        return 'bg-amber-500/10 text-amber-600 border-amber-500/20 hover:bg-amber-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  if (isError) return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load dumps" />;

  return (
    <div className="section-gap">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes dashRotate {
          to { stroke-dashoffset: -20; }
        }
      `}</style>

      <PageHeader
        title="Dump Analyzer"
        subtitle="Upload and analyze thread dumps and heap dumps"
        actions={
          <Link href="/dumps/compare">
            <Button variant="outline" className="shrink-0">
              <GitCompare className="h-4 w-4 mr-2" />
              Compare Dumps
            </Button>
          </Link>
        }
      />

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Upload Dump File
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div
            className={`upload-zone relative overflow-hidden transition-all duration-300 ${isDragging ? 'upload-zone-active bg-gradient-to-br from-primary/5 to-primary/10' : 'hover:bg-gradient-to-br hover:from-muted/30 hover:to-muted/50'}`}
            style={{
              borderStyle: 'dashed',
              borderWidth: '2px',
              animation: isDragging ? 'none' : undefined,
            }}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
          >
            {selectedFile ? (
              <div className="space-y-4">
                <div className="flex items-center justify-center gap-2">
                  <FileText className="h-8 w-8 text-muted-foreground" />
                  <div className="text-left">
                    <p className="font-medium">{selectedFile.name}</p>
                    <p className="text-sm text-muted-foreground">{formatFileSize(selectedFile.size)}</p>
                  </div>
                </div>
                <div className="flex flex-wrap items-center justify-center gap-4">
                  <Select value={dumpType} onValueChange={(v: 'thread' | 'heap') => setDumpType(v)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="thread">Thread Dump</SelectItem>
                      <SelectItem value="heap">Heap Dump</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button onClick={handleUpload} disabled={uploadMutation.isPending}>
                    {uploadMutation.isPending ? 'Uploading...' : 'Analyze'}
                  </Button>
                  <Button variant="outline" onClick={() => setSelectedFile(null)}>Cancel</Button>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <Upload className="h-12 w-12 mx-auto text-muted-foreground" />
                <p className="text-lg font-medium">Drag and drop a dump file here</p>
                <p className="text-sm text-muted-foreground">
                  Supports .hprof, .txt, .tdump, .log files (max 500MB)
                </p>
                <Input
                  type="file"
                  accept=".hprof,.txt,.tdump,.log,.dump,.bin"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      setSelectedFile(e.target.files[0]);
                      const ext = e.target.files[0].name.toLowerCase();
                      if (ext.endsWith('.hprof') || ext.endsWith('.bin')) {
                        setDumpType('heap');
                      }
                    }
                  }}
                  className="max-w-xs mx-auto"
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Uploaded Dumps ({dumps.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="p-4 rounded-lg border bg-muted/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <Skeleton className="h-12 w-12 rounded-xl" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-40" />
                      <div className="flex items-center gap-2">
                        <Skeleton className="h-5 w-14 rounded-full" />
                        <Skeleton className="h-3 w-24" />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Skeleton className="h-8 w-20 rounded-md" />
                    <Skeleton className="h-8 w-20 rounded-md" />
                  </div>
                </div>
              ))}
            </div>
          ) : dumps.length === 0 ? (
            <EmptyState {...emptyStates.dumps} />
          ) : (
            <div className="space-y-3">
              {dumps.map((dump, index) => (
                <div
                  key={dump.id}
                  className="p-4 rounded-lg border bg-muted/20 hover:bg-muted/40 hover:shadow-md hover:border-border transition-all duration-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  style={{ animation: `fadeSlideIn 0.3s ease-out ${index * 0.05}s both` }}
                >
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl ${dump.type === 'heap' ? 'bg-orange-500/10' : 'bg-blue-500/10'}`}>
                      {dump.type === 'heap' ? (
                        <Database className="h-6 w-6 text-orange-500" />
                      ) : (
                        <FileText className="h-6 w-6 text-blue-500" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium">{dump.name}</p>
                      <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground mt-1">
                        <Badge variant={dump.type === 'heap' ? 'default' : 'secondary'} className="text-xs">
                          {dump.type === 'heap' ? 'Heap' : 'Thread'}
                        </Badge>
                        <span className="text-xs">{formatFileSize(dump.fileSize)}</span>
                        <span className="text-xs hidden sm:inline">•</span>
                        <span className="text-xs hidden sm:inline">{formatDistanceToNow(new Date(dump.createdAt), { addSuffix: true })}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 ml-auto sm:ml-0">
                    <Badge variant="outline" className={`text-xs ${getStatusBadgeStyle(dump.status)}`}>
                      {dump.status === 'analyzing' && <RefreshCw className="h-3 w-3 mr-1 animate-spin" />}
                      {dump.status}
                    </Badge>
                    {dump.status === 'completed' && (
                      <Link href={`/dumps/${dump.id}`}>
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </Link>
                    )}
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete this dump file? Analysis data will be lost.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteMutation.mutate(dump.id)}>
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
