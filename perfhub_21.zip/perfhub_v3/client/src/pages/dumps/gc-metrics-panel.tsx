import { useState, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Activity, Cpu, Layers, TrendingUp, Database, Recycle, Gauge, Info } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS, DT_PALETTE } from "@/components/charts/dynatrace-theme";
import type { GcMetrics } from "./types";
import { COLORS } from "./types";

export function GcMetricsPanel({ gcMetrics, type, formatBytes, dumpId }: { gcMetrics?: GcMetrics; type: 'thread' | 'heap'; formatBytes: (bytes: number) => string; dumpId: number }) {
  const [uploading, setUploading] = useState(false);
  const queryClient = useQueryClient();

  const [uploadError, setUploadError] = useState<string | null>(null);

  const handleGcLogUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !dumpId) return;

    setUploading(true);
    setUploadError(null);
    try {
      const formData = new FormData();
      formData.append('gcLog', file);
      const res = await fetch(`/api/dumps/${dumpId}/gc-log`, {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: formData,
        credentials: 'include',
      });
      if (!res.ok) {
        throw new Error(`Upload failed: ${res.statusText}`);
      }
      queryClient.invalidateQueries({ queryKey: queryKeys.dumps.detail(dumpId) });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'GC log upload failed';
      setUploadError(message);
      console.error('GC log upload failed:', err);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  }, [dumpId, queryClient]);

  if (!gcMetrics) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          GC metrics not available for this analysis. Re-upload the dump to generate GC metrics.
        </CardContent>
      </Card>
    );
  }

  const pressureLevelColors: Record<string, string> = {
    low: 'text-green-500',
    moderate: 'text-yellow-500',
    high: 'text-orange-500',
    critical: 'text-red-500',
  };

  const pressureLevelBg: Record<string, string> = {
    low: 'bg-green-500',
    moderate: 'bg-yellow-500',
    high: 'bg-orange-500',
    critical: 'bg-red-500',
  };

  return (
    <>
      {type === 'thread' && gcMetrics.gcThreads && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{gcMetrics.gcThreads.total}</div>
                <p className="text-sm text-muted-foreground">GC Threads</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{gcMetrics.gcThreads.types.length}</div>
                <p className="text-sm text-muted-foreground">GC Types Detected</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{gcMetrics.gcThreads.totalCpuMs.toFixed(1)} ms</div>
                <p className="text-sm text-muted-foreground">Total GC CPU Time</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className={`text-2xl font-bold ${gcMetrics.gcThreads.gcOverheadPct > 10 ? 'text-red-500' : gcMetrics.gcThreads.gcOverheadPct > 5 ? 'text-orange-500' : 'text-green-500'}`}>
                  {gcMetrics.gcThreads.gcOverheadPct.toFixed(1)}%
                </div>
                <p className="text-sm text-muted-foreground">GC Overhead</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Recycle className="h-5 w-5" />
                  GC Thread Types
                </CardTitle>
              </CardHeader>
              <CardContent>
                {gcMetrics.gcThreads.types.length > 0 ? (
                  <div className="h-48 sm:h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={gcMetrics.gcThreads.types}
                          cx="50%"
                          cy="50%"
                          innerRadius={50}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="count"
                          nameKey="name"
                          label={({ name, count }) => `${name}: ${count}`}
                        >
                          {gcMetrics.gcThreads.types.map((_, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} cursor={DT_CURSOR_PROPS} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm">No GC thread types detected.</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="h-5 w-5" />
                  GC Thread CPU Usage
                </CardTitle>
              </CardHeader>
              <CardContent>
                {gcMetrics.gcThreads.threads.length > 0 ? (
                  <div className="h-48 sm:h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={gcMetrics.gcThreads.threads.slice(0, 10)} layout="vertical">
                        <CartesianGrid {...DT_GRID_PROPS} />
                        <XAxis type="number" {...DT_AXIS_PROPS} />
                        <YAxis type="category" dataKey="name" width={120} {...DT_AXIS_PROPS} />
                        <Tooltip formatter={(value: number) => `${value.toFixed(1)} ms`} contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} cursor={DT_CURSOR_PROPS} />
                        <Bar dataKey="cpuMs" fill={DT_COLORS.primary} name="CPU Time (ms)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm">No CPU data available.</p>
                )}
              </CardContent>
            </Card>
          </div>

          {gcMetrics.gcThreads.threads.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>GC Threads Detail</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 pr-4">Thread Name</th>
                        <th className="text-right py-2 pr-4">CPU (ms)</th>
                        <th className="text-left py-2">State</th>
                      </tr>
                    </thead>
                    <tbody>
                      {gcMetrics.gcThreads.threads.map((t, i) => (
                        <tr key={i} className="border-b last:border-0">
                          <td className="py-2 pr-4 font-mono text-xs">{t.name}</td>
                          <td className="py-2 pr-4 text-right">{t.cpuMs.toFixed(1)}</td>
                          <td className="py-2">
                            <Badge variant={t.state === 'RUNNABLE' ? 'default' : 'secondary'}>{t.state}</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {type === 'heap' && (
        <>
          {gcMetrics.gcPerformance?.source === 'heap_estimate' && dumpId > 0 && (
            <Card className="border-dashed">
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Info className="h-5 w-5 text-blue-500 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium">GC metrics are estimated from heap snapshot data</p>
                      <p className="text-xs text-muted-foreground">Upload a GC log file (-Xlog:gc* or -verbose:gc) for precise metrics from actual GC events</p>
                    </div>
                  </div>
                  <label>
                    <input type="file" className="hidden" accept=".log,.txt,.gc" onChange={handleGcLogUpload} disabled={uploading} />
                    <Button variant="outline" size="sm" disabled={uploading} asChild>
                      <span>{uploading ? 'Uploading...' : 'Upload GC Log'}</span>
                    </Button>
                  </label>
                </div>
                {uploadError && (
                  <div className="mt-2 text-sm text-red-500 flex items-center gap-2">
                    <Info className="h-4 w-4" />
                    {uploadError}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {gcMetrics.gcPerformance && (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Gauge className="h-5 w-5" />
                    GC Performance Metrics
                    {gcMetrics.gcPerformance.source === 'heap_estimate' && (
                      <Badge variant="secondary" className="text-xs">Estimated from Heap</Badge>
                    )}
                    {gcMetrics.gcPerformance.source === 'gc_log' && (
                      <Badge variant="default" className="text-xs bg-green-600">From GC Log</Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                    <div className="border rounded-lg p-3 text-center">
                      <div className={`text-xl font-bold ${gcMetrics.gcPerformance.maxGcPauseTimeMs > 500 ? 'text-red-500' : gcMetrics.gcPerformance.maxGcPauseTimeMs > 200 ? 'text-orange-500' : 'text-green-500'}`}>
                        {gcMetrics.gcPerformance.maxGcPauseTimeMs.toFixed(1)} ms
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">Max GC Pause</div>
                    </div>
                    <div className="border rounded-lg p-3 text-center">
                      <div className={`text-xl font-bold ${gcMetrics.gcPerformance.avgGcPauseTimeMs > 200 ? 'text-red-500' : gcMetrics.gcPerformance.avgGcPauseTimeMs > 100 ? 'text-orange-500' : 'text-green-500'}`}>
                        {gcMetrics.gcPerformance.avgGcPauseTimeMs.toFixed(1)} ms
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">Avg GC Pause</div>
                    </div>
                    <div className="border rounded-lg p-3 text-center">
                      <div className="text-xl font-bold">
                        {gcMetrics.gcPerformance.totalPauseTimeMs > 1000
                          ? `${(gcMetrics.gcPerformance.totalPauseTimeMs / 1000).toFixed(2)} s`
                          : `${gcMetrics.gcPerformance.totalPauseTimeMs.toFixed(1)} ms`}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">Total Pause Time</div>
                    </div>
                    <div className="border rounded-lg p-3 text-center">
                      <div className={`text-xl font-bold ${gcMetrics.gcPerformance.gcThroughputPct < 95 ? 'text-red-500' : gcMetrics.gcPerformance.gcThroughputPct < 98 ? 'text-orange-500' : 'text-green-500'}`}>
                        {gcMetrics.gcPerformance.gcThroughputPct.toFixed(2)}%
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">GC Throughput</div>
                    </div>
                    <div className="border rounded-lg p-3 text-center">
                      <div className="text-xl font-bold">{gcMetrics.gcPerformance.totalGcEvents}</div>
                      <div className="text-xs text-muted-foreground mt-1">Total GC Events</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="h-5 w-5" />
                      GC Rates (per minute)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div>
                          <div className="font-medium">Minor GC Rate</div>
                          <div className="text-xs text-muted-foreground">Young generation collections</div>
                        </div>
                        <div className="text-right">
                          <div className={`text-lg font-bold ${gcMetrics.gcPerformance.minorGcRate > 20 ? 'text-orange-500' : 'text-green-500'}`}>
                            {gcMetrics.gcPerformance.minorGcRate.toFixed(1)}/min
                          </div>
                          <div className="text-xs text-muted-foreground">{gcMetrics.gcPerformance.minorGcCount} total</div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div>
                          <div className="font-medium">Major/Full GC Rate</div>
                          <div className="text-xs text-muted-foreground">Old generation / full collections</div>
                        </div>
                        <div className="text-right">
                          <div className={`text-lg font-bold ${gcMetrics.gcPerformance.majorGcRate > 1 ? 'text-red-500' : gcMetrics.gcPerformance.majorGcRate > 0.5 ? 'text-orange-500' : 'text-green-500'}`}>
                            {gcMetrics.gcPerformance.majorGcRate.toFixed(2)}/min
                          </div>
                          <div className="text-xs text-muted-foreground">{gcMetrics.gcPerformance.majorGcCount} total</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Layers className="h-5 w-5" />
                      Heap: Used vs Committed vs Max
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Used</span>
                          <span>{formatBytes(gcMetrics.gcPerformance.heapUsedBytes)}</span>
                        </div>
                        <Progress value={gcMetrics.gcPerformance.heapMaxBytes > 0 ? (gcMetrics.gcPerformance.heapUsedBytes / gcMetrics.gcPerformance.heapMaxBytes) * 100 : 0} className="h-3" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Committed</span>
                          <span>{formatBytes(gcMetrics.gcPerformance.heapCommittedBytes)}</span>
                        </div>
                        <Progress value={gcMetrics.gcPerformance.heapMaxBytes > 0 ? (gcMetrics.gcPerformance.heapCommittedBytes / gcMetrics.gcPerformance.heapMaxBytes) * 100 : 0} className="h-3" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Max</span>
                          <span>{formatBytes(gcMetrics.gcPerformance.heapMaxBytes)}</span>
                        </div>
                        <Progress value={100} className="h-3" />
                      </div>
                    </div>
                    <div className="mt-3 h-40">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={[
                          { name: 'Used', value: gcMetrics.gcPerformance.heapUsedBytes, fill: DT_COLORS.primary },
                          { name: 'Committed', value: gcMetrics.gcPerformance.heapCommittedBytes, fill: DT_COLORS.green },
                          { name: 'Max', value: gcMetrics.gcPerformance.heapMaxBytes, fill: DT_COLORS.purple },
                        ]}>
                          <CartesianGrid {...DT_GRID_PROPS} />
                          <XAxis dataKey="name" {...DT_AXIS_PROPS} />
                          <YAxis tickFormatter={(v) => formatBytes(v)} {...DT_AXIS_PROPS} />
                          <Tooltip formatter={(value: number) => formatBytes(value)} contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} cursor={DT_CURSOR_PROPS} />
                          <Bar dataKey="value" name="Size">
                            <Cell fill={DT_COLORS.primary} />
                            <Cell fill={DT_COLORS.green} />
                            <Cell fill={DT_COLORS.purple} />
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Allocation Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-2xl font-bold ${gcMetrics.gcPerformance.allocationRateMBps > 500 ? 'text-red-500' : gcMetrics.gcPerformance.allocationRateMBps > 200 ? 'text-orange-500' : 'text-green-500'}`}>
                      {gcMetrics.gcPerformance.allocationRateMBps.toFixed(2)} MB/s
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Rate of new object allocation in the heap</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Promotion Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-2xl font-bold ${gcMetrics.gcPerformance.promotionRateMBps > 50 ? 'text-red-500' : gcMetrics.gcPerformance.promotionRateMBps > 20 ? 'text-orange-500' : 'text-green-500'}`}>
                      {gcMetrics.gcPerformance.promotionRateMBps.toFixed(2)} MB/s
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Rate objects are promoted from Young to Old Gen</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Reclaimed per Cycle</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-blue-500">
                      {gcMetrics.gcPerformance.reclaimedPerCycleKB > 1024
                        ? `${(gcMetrics.gcPerformance.reclaimedPerCycleKB / 1024).toFixed(1)} MB`
                        : `${gcMetrics.gcPerformance.reclaimedPerCycleKB.toFixed(0)} KB`}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Average memory reclaimed per GC cycle</p>
                  </CardContent>
                </Card>
              </div>

              {gcMetrics.gcPerformance.pauseDistribution.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Pause Time Distribution
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-48">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={gcMetrics.gcPerformance.pauseDistribution}>
                          <CartesianGrid {...DT_GRID_PROPS} />
                          <XAxis dataKey="range" {...DT_AXIS_PROPS} />
                          <YAxis {...DT_AXIS_PROPS} />
                          <Tooltip contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} cursor={DT_CURSOR_PROPS} />
                          <Bar dataKey="count" fill={DT_COLORS.primary} name="GC Events" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}

          {gcMetrics.heapPressure && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className={`text-2xl font-bold ${pressureLevelColors[gcMetrics.heapPressure.pressureLevel]}`}>
                      {gcMetrics.heapPressure.utilizationPct.toFixed(1)}%
                    </div>
                    <p className="text-sm text-muted-foreground">Heap Utilization</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2">
                      <div className={`h-3 w-3 rounded-full ${pressureLevelBg[gcMetrics.heapPressure.pressureLevel]}`} />
                      <span className={`text-2xl font-bold capitalize ${pressureLevelColors[gcMetrics.heapPressure.pressureLevel]}`}>
                        {gcMetrics.heapPressure.pressureLevel}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">Pressure Level</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-2xl font-bold">{formatBytes(gcMetrics.heapPressure.estimatedOldGenSize)}</div>
                    <p className="text-sm text-muted-foreground">Est. Old Gen</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-2xl font-bold">{formatBytes(gcMetrics.heapPressure.estimatedYoungGenSize)}</div>
                    <p className="text-sm text-muted-foreground">Est. Young Gen</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Layers className="h-5 w-5" />
                      Generation Distribution
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-48 sm:h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={[
                              { name: 'Young Gen', value: gcMetrics.heapPressure.estimatedYoungGenSize },
                              { name: 'Old Gen', value: gcMetrics.heapPressure.estimatedOldGenSize },
                              { name: 'Survivor', value: gcMetrics.heapPressure.estimatedSurvivorSize },
                              { name: 'Metaspace', value: gcMetrics.heapPressure.estimatedMetaspaceSize },
                            ].filter(d => d.value > 0)}
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                            label={({ name }) => name}
                          >
                            <Cell fill={DT_COLORS.green} />
                            <Cell fill={DT_COLORS.primary} />
                            <Cell fill={DT_COLORS.amber} />
                            <Cell fill={DT_COLORS.purple} />
                          </Pie>
                          <Tooltip formatter={(value: number) => formatBytes(value)} contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} cursor={DT_CURSOR_PROPS} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                {gcMetrics.gcRootAnalysis && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Database className="h-5 w-5" />
                        GC Root Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-48 sm:h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={[
                            { name: 'ThreadLocals', value: gcMetrics.gcRootAnalysis.threadLocalRoots },
                            { name: 'Finalizers', value: gcMetrics.gcRootAnalysis.finalizerObjects },
                            { name: 'Weak Refs', value: gcMetrics.gcRootAnalysis.weakReferences },
                            { name: 'Soft Refs', value: gcMetrics.gcRootAnalysis.softReferences },
                            { name: 'Phantom Refs', value: gcMetrics.gcRootAnalysis.phantomReferences },
                          ].filter(d => d.value > 0)}>
                            <CartesianGrid {...DT_GRID_PROPS} />
                            <XAxis dataKey="name" {...DT_AXIS_PROPS} />
                            <YAxis {...DT_AXIS_PROPS} />
                            <Tooltip contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} cursor={DT_CURSOR_PROPS} />
                            <Bar dataKey="value" fill={DT_COLORS.purple} name="Count" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </>
          )}

          {gcMetrics.objectLifecycle && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Object Lifecycle Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                  <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg">
                    <div className="text-lg font-bold text-green-600">{gcMetrics.objectLifecycle.shortLived.count.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">Short-lived objects</div>
                    <div className="text-xs text-muted-foreground">{formatBytes(gcMetrics.objectLifecycle.shortLived.size)}</div>
                  </div>
                  <div className="bg-yellow-50 dark:bg-yellow-950 p-4 rounded-lg">
                    <div className="text-lg font-bold text-yellow-600">{gcMetrics.objectLifecycle.mediumLived.count.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">Medium-lived objects</div>
                    <div className="text-xs text-muted-foreground">{formatBytes(gcMetrics.objectLifecycle.mediumLived.size)}</div>
                  </div>
                  <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
                    <div className="text-lg font-bold text-blue-600">{gcMetrics.objectLifecycle.longLived.count.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">Long-lived objects</div>
                    <div className="text-xs text-muted-foreground">{formatBytes(gcMetrics.objectLifecycle.longLived.size)}</div>
                  </div>
                </div>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={[
                      { name: 'Short-lived', count: gcMetrics.objectLifecycle.shortLived.count, size: gcMetrics.objectLifecycle.shortLived.size },
                      { name: 'Medium-lived', count: gcMetrics.objectLifecycle.mediumLived.count, size: gcMetrics.objectLifecycle.mediumLived.size },
                      { name: 'Long-lived', count: gcMetrics.objectLifecycle.longLived.count, size: gcMetrics.objectLifecycle.longLived.size },
                    ]}>
                      <CartesianGrid {...DT_GRID_PROPS} />
                      <XAxis dataKey="name" {...DT_AXIS_PROPS} />
                      <YAxis yAxisId="left" {...DT_AXIS_PROPS} />
                      <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} />
                      <Tooltip formatter={(value: number, name: string) => name === 'size' ? formatBytes(value) : value.toLocaleString()} contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} cursor={DT_CURSOR_PROPS} />
                      <Legend />
                      <Bar yAxisId="left" dataKey="count" fill={DT_COLORS.green} name="Instance Count" />
                      <Bar yAxisId="right" dataKey="size" fill={DT_COLORS.primary} name="Size (bytes)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {gcMetrics.recommendations && gcMetrics.recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5" />
              GC Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {gcMetrics.recommendations.map((rec, i) => (
                <div key={i} className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <Gauge className="h-5 w-5 mt-0.5 text-blue-500 flex-shrink-0" />
                  <p className="text-sm">{rec}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}
