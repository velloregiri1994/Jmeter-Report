export const COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#8b5cf6', '#ec4899'];

export interface ThreadSummary {
  totalThreads: number;
  runnable: number;
  blocked: number;
  waiting: number;
  timedWaiting: number;
  terminated: number;
  daemonCount: number;
}

export interface ThreadInfo {
  id: string;
  name: string;
  state: string;
  daemon: boolean;
  priority: number;
  stackTrace: string[];
  blockedBy?: string;
  holding?: string[];
}

export interface DeadlockInfo {
  threads: string[];
  locks: string[];
  cycle: string[];
}

export interface HotspotInfo {
  method: string;
  count: number;
  percentage: number;
  callers: string[];
}

export interface StackCluster {
  id: number;
  pattern: string[];
  threadCount: number;
  threadNames: string[];
  similarity: number;
}

export interface ContentionInfo {
  lockName: string;
  waitingThreads: number;
  holdingThread: string;
}

export interface HeapSummary {
  totalHeapSize: number;
  usedHeapSize: number;
  totalClasses: number;
  totalInstances: number;
}

export interface ClassHistogramEntry {
  className: string;
  instanceCount: number;
  shallowSize: number;
  retainedSize?: number;
}

export interface LeakSuspect {
  className: string;
  instanceCount: number;
  retainedSize: number;
  probability: 'high' | 'medium' | 'low';
  reason: string;
  referenceChain?: string[];
}

export interface DominatorNode {
  className: string;
  shallowSize: number;
  retainedSize: number;
  retainedPercentage: number;
}

export interface GcPerformanceMetrics {
  maxGcPauseTimeMs: number;
  avgGcPauseTimeMs: number;
  totalPauseTimeMs: number;
  gcThroughputPct: number;
  minorGcRate: number;
  majorGcRate: number;
  heapUsedBytes: number;
  heapCommittedBytes: number;
  heapMaxBytes: number;
  allocationRateMBps: number;
  promotionRateMBps: number;
  reclaimedPerCycleKB: number;
  totalGcEvents: number;
  minorGcCount: number;
  majorGcCount: number;
  pauseDistribution: { range: string; count: number }[];
  source: 'gc_log' | 'heap_estimate';
}

export interface GcMetrics {
  gcThreads?: {
    total: number;
    types: { name: string; count: number }[];
    totalCpuMs: number;
    gcOverheadPct: number;
    threads: { name: string; cpuMs: number; state: string }[];
  };
  heapPressure?: {
    utilizationPct: number;
    pressureLevel: 'low' | 'moderate' | 'high' | 'critical';
    estimatedSurvivorSize: number;
    estimatedOldGenSize: number;
    estimatedYoungGenSize: number;
    estimatedMetaspaceSize: number;
  };
  gcRootAnalysis?: {
    threadLocalRoots: number;
    finalizerObjects: number;
    weakReferences: number;
    softReferences: number;
    phantomReferences: number;
    jniGlobalRefs: number;
  };
  objectLifecycle?: {
    shortLived: { count: number; size: number };
    mediumLived: { count: number; size: number };
    longLived: { count: number; size: number };
  };
  gcPerformance?: GcPerformanceMetrics;
  recommendations: string[];
}

export interface DetectedIssue {
  type: 'deadlock' | 'thread_pool_saturation' | 'blocked_contention' | 'stuck_thread' | 'high_blocked_ratio';
  severity: 'warning' | 'critical';
  description: string;
  relatedThreads: string[];
}

export interface DumpAnalysis {
  id: number;
  dumpFileId: number;
  analysisType: 'thread' | 'heap';
  threadSummary?: ThreadSummary;
  threads?: ThreadInfo[];
  deadlocks?: DeadlockInfo[];
  hotspots?: HotspotInfo[];
  stackClusters?: StackCluster[];
  contentionInfo?: ContentionInfo[];
  detectedIssues?: DetectedIssue[];
  heapSummary?: HeapSummary;
  classHistogram?: ClassHistogramEntry[];
  leakSuspects?: LeakSuspect[];
  dominatorTree?: DominatorNode[];
  topObjects?: ClassHistogramEntry[];
  gcMetrics?: GcMetrics;
}

export interface DumpFile {
  id: number;
  name: string;
  type: 'heap' | 'thread';
  fileSize: number;
  status: string;
  analyses: DumpAnalysis[];
}

export interface Annotation {
  id: number;
  dumpFileId: number;
  note: string;
  threadName?: string;
  issueIndex?: number;
  createdAt: string;
}

export interface BookmarkEntry {
  id: number;
  dumpFileId: number;
  threadName: string;
}

export interface Recommendation {
  severity: 'critical' | 'warning' | 'info';
  category: string;
  message: string;
}

export interface FlameNode {
  name: string;
  fullPath: string;
  value: number;
  children: FlameNode[];
}

export interface ThreadPool {
  name: string;
  threads: ThreadInfo[];
  icon: React.ReactNode;
}
