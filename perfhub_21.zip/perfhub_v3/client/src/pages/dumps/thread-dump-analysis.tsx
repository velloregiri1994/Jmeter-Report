import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, Activity, Cpu, Lock, Layers, Recycle, Info, Search, Star, StarOff, MessageSquare, Lightbulb, Filter, Server, Trash2, Plus, Send, X } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS, DT_PALETTE } from "@/components/charts/dynatrace-theme";
import type { DumpAnalysis, Annotation, BookmarkEntry } from "./types";
import { useDebounce, categorizeThread, buildFlameGraph, getFlameDepth, generateRecommendations } from "./utils";
import { FlameGraphRenderer } from "./flame-graph";
import { GcMetricsPanel } from "./gc-metrics-panel";

export function ThreadDumpAnalysis({ analysis, formatBytes, dumpId }: { analysis: DumpAnalysis; formatBytes: (bytes: number) => string; dumpId: number }) {
  const queryClient = useQueryClient();
  const summary = analysis.threadSummary;
  const threads = analysis.threads || [];
  const deadlocks = analysis.deadlocks || [];
  const hotspots = analysis.hotspots || [];
  const clusters = analysis.stackClusters || [];
  const contention = analysis.contentionInfo || [];
  const detectedIssues = analysis.detectedIssues || [];

  const [searchText, setSearchText] = useState('');
  const [stateFilter, setStateFilter] = useState('All');
  const debouncedSearch = useDebounce(searchText, 300);

  const [noteText, setNoteText] = useState('');
  const [noteThreadName, setNoteThreadName] = useState<string | undefined>(undefined);
  const [noteIssueIndex, setNoteIssueIndex] = useState<number | undefined>(undefined);
  const [showNotePanel, setShowNotePanel] = useState(false);

  const { data: annotations = [], isLoading: annotationsLoading, isError: annotationsError, error: annotationsErr, refetch: refetchAnnotations } = useQuery<Annotation[]>({
    queryKey: [...queryKeys.dumps.annotations(dumpId)],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/dumps/${dumpId}/annotations`);
      return res.json();
    },
  });

  const { data: bookmarks = [], isLoading: bookmarksLoading, isError: bookmarksError, error: bookmarksErr, refetch: refetchBookmarks } = useQuery<BookmarkEntry[]>({
    queryKey: [...queryKeys.dumps.bookmarks(dumpId)],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/dumps/${dumpId}/bookmarks`);
      return res.json();
    },
  });

  const addAnnotation = useMutation({
    mutationFn: async (body: { note: string; threadName?: string; issueIndex?: number }) => {
      const res = await apiRequest("POST", `/api/dumps/${dumpId}/annotations`, body);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.dumps.annotations(dumpId) });
      setNoteText('');
      setNoteThreadName(undefined);
      setNoteIssueIndex(undefined);
    },
  });

  const deleteAnnotation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/dumps/${dumpId}/annotations/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.dumps.annotations(dumpId) });
    },
  });

  const toggleBookmark = useMutation({
    mutationFn: async (threadName: string) => {
      const res = await apiRequest("POST", `/api/dumps/${dumpId}/bookmarks/toggle`, { threadName });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.dumps.bookmarks(dumpId) });
    },
  });

  const bookmarkedNames = useMemo(() => new Set(bookmarks.map(b => b.threadName)), [bookmarks]);

  const filteredThreads = useMemo(() => {
    let result = [...threads];
    if (debouncedSearch) {
      const lower = debouncedSearch.toLowerCase();
      result = result.filter(t =>
        t.name.toLowerCase().includes(lower) ||
        t.state.toLowerCase().includes(lower) ||
        t.stackTrace.some(line => line.toLowerCase().includes(lower))
      );
    }
    if (stateFilter !== 'All') {
      result = result.filter(t => t.state === stateFilter);
    }
    result.sort((a, b) => {
      const aBookmarked = bookmarkedNames.has(a.name) ? 0 : 1;
      const bBookmarked = bookmarkedNames.has(b.name) ? 0 : 1;
      return aBookmarked - bBookmarked;
    });
    return result;
  }, [threads, debouncedSearch, stateFilter, bookmarkedNames]);

  const recommendations = useMemo(
    () => generateRecommendations(detectedIssues, contention, summary, threads, analysis.gcMetrics),
    [detectedIssues, contention, summary, threads, analysis.gcMetrics]
  );

  const flameRoot = useMemo(() => buildFlameGraph(threads), [threads]);
  const flameDepth = useMemo(() => getFlameDepth(flameRoot), [flameRoot]);

  const threadPools = useMemo(() => {
    const poolMap = new Map<string, typeof threads>();
    for (const thread of threads) {
      const pool = categorizeThread(thread.name);
      if (!poolMap.has(pool)) poolMap.set(pool, []);
      poolMap.get(pool)!.push(thread);
    }
    const poolOrder = ['HTTP/Tomcat Pool', 'Database Pool (HikariCP)', 'Scheduled/Executor Pool', 'GC Threads', 'JIT Compiler', 'JVM Internal', 'Application Threads'];
    return poolOrder
      .filter(name => poolMap.has(name))
      .map(name => ({ name, threads: poolMap.get(name)! }));
  }, [threads]);

  const stateData = summary ? [
    { name: 'Runnable', value: summary.runnable, color: DT_COLORS.green },
    { name: 'Blocked', value: summary.blocked, color: DT_COLORS.red },
    { name: 'Waiting', value: summary.waiting, color: DT_COLORS.orange },
    { name: 'Timed Waiting', value: summary.timedWaiting, color: DT_COLORS.amber },
    { name: 'Terminated', value: summary.terminated, color: '#6b7280' },
  ].filter(d => d.value > 0) : [];

  const issueTypeLabels: Record<string, string> = {
    deadlock: 'Deadlock',
    thread_pool_saturation: 'Pool Saturation',
    blocked_contention: 'Lock Contention',
    stuck_thread: 'Stuck Thread',
    high_blocked_ratio: 'High Blocked Ratio',
  };

  const issueTypeColors: Record<string, string> = {
    deadlock: 'text-red-600 bg-red-50 dark:bg-red-950 border-red-200',
    thread_pool_saturation: 'text-orange-600 bg-orange-50 dark:bg-orange-950 border-orange-200',
    blocked_contention: 'text-yellow-600 bg-yellow-50 dark:bg-yellow-950 border-yellow-200',
    stuck_thread: 'text-purple-600 bg-purple-50 dark:bg-purple-950 border-purple-200',
    high_blocked_ratio: 'text-red-600 bg-red-50 dark:bg-red-950 border-red-200',
  };

  const severityIcon = (severity: string) => {
    if (severity === 'critical') return <AlertTriangle className="h-4 w-4 text-red-500" />;
    if (severity === 'warning') return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    return <Info className="h-4 w-4 text-blue-500" />;
  };

  const handleAddNote = (threadName?: string, issueIndex?: number) => {
    setNoteThreadName(threadName);
    setNoteIssueIndex(issueIndex);
    setShowNotePanel(true);
  };

  const submitNote = () => {
    if (!noteText.trim()) return;
    addAnnotation.mutate({ note: noteText.trim(), threadName: noteThreadName, issueIndex: noteIssueIndex });
  };

  if (annotationsError) {
    return <QueryErrorFallback error={annotationsErr} onRetry={() => refetchAnnotations()} title="Failed to load annotations" />;
  }

  if (bookmarksError) {
    return <QueryErrorFallback error={bookmarksErr} onRetry={() => refetchBookmarks()} title="Failed to load bookmarks" />;
  }

  if (annotationsLoading || bookmarksLoading) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <Skeleton className="h-8 w-20 mb-2" />
                <Skeleton className="h-4 w-32" />
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader><Skeleton className="h-6 w-48" /></CardHeader>
            <CardContent><Skeleton className="h-48 w-full" /></CardContent>
          </Card>
          <Card>
            <CardHeader><Skeleton className="h-6 w-48" /></CardHeader>
            <CardContent><Skeleton className="h-48 w-full" /></CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="overview">
        <TabsList className="flex-wrap">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          {detectedIssues.length > 0 && (
            <TabsTrigger value="issues">
              Detected Issues <Badge variant={detectedIssues.some(i => i.severity === 'critical') ? 'destructive' : 'secondary'} className="ml-1">{detectedIssues.length}</Badge>
            </TabsTrigger>
          )}
          <TabsTrigger value="recommendations">
            <Lightbulb className="h-4 w-4 mr-1" /> Recommendations
          </TabsTrigger>
          <TabsTrigger value="thread-pools">
            <Server className="h-4 w-4 mr-1" /> Thread Pools
          </TabsTrigger>
          <TabsTrigger value="flame-graph">
            <Activity className="h-4 w-4 mr-1" /> Flame Graph
          </TabsTrigger>
          <TabsTrigger value="deadlocks">
            Deadlocks {deadlocks.length > 0 && <Badge variant="destructive" className="ml-1">{deadlocks.length}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="hotspots">Hotspots</TabsTrigger>
          <TabsTrigger value="contention">Lock Contention</TabsTrigger>
          <TabsTrigger value="clusters">Stack Clusters</TabsTrigger>
          <TabsTrigger value="threads">All Threads</TabsTrigger>
          <TabsTrigger value="gc-metrics">
            <Recycle className="h-4 w-4 mr-1" /> GC Metrics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{summary?.totalThreads || 0}</div>
                <p className="text-sm text-muted-foreground">Total Threads</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-red-500">{summary?.blocked || 0}</div>
                <p className="text-sm text-muted-foreground">Blocked</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-orange-500">{summary?.waiting || 0}</div>
                <p className="text-sm text-muted-foreground">Waiting</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{summary?.daemonCount || 0}</div>
                <p className="text-sm text-muted-foreground">Daemon Threads</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Thread State Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-48 sm:h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={stateData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}`}
                      >
                        {stateData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }} cursor={DT_CURSOR_PROPS} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {deadlocks.length > 0 && (
              <Card className="border-red-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-500">
                    <AlertTriangle className="h-5 w-5" />
                    Deadlock Detected!
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    {deadlocks.length} deadlock(s) found. These threads are waiting for each other in a circular dependency.
                  </p>
                  {deadlocks.map((dl, i) => (
                    <div key={i} className="bg-red-50 dark:bg-red-950 p-4 rounded-lg mb-2">
                      <p className="font-medium">Deadlock #{i + 1}</p>
                      <p className="text-sm">Threads: {dl.cycle.join(' → ')} → {dl.cycle[0]}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>

          {detectedIssues.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Detected Issues Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {detectedIssues.map((issue, i) => (
                    <div key={i} className={`flex items-start gap-3 p-3 rounded-lg border ${issueTypeColors[issue.type] || 'bg-muted'}`}>
                      <Badge variant={issue.severity === 'critical' ? 'destructive' : 'secondary'} className="mt-0.5 shrink-0">
                        {issue.severity}
                      </Badge>
                      <div className="min-w-0">
                        <p className="font-medium text-sm">{issueTypeLabels[issue.type] || issue.type}</p>
                        <p className="text-xs mt-0.5 opacity-80">{issue.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {detectedIssues.length > 0 && (
          <TabsContent value="issues" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  All Detected Issues ({detectedIssues.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {detectedIssues.map((issue, i) => (
                    <div key={i} className={`p-4 rounded-lg border ${issueTypeColors[issue.type] || 'bg-muted'}`}>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <Badge variant={issue.severity === 'critical' ? 'destructive' : 'secondary'}>
                            {issue.severity}
                          </Badge>
                          <span className="font-semibold text-sm">{issueTypeLabels[issue.type] || issue.type}</span>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => handleAddNote(undefined, i)}>
                          <MessageSquare className="h-4 w-4 mr-1" /> Note
                        </Button>
                      </div>
                      <p className="text-sm mb-3">{issue.description}</p>
                      {issue.relatedThreads.length > 0 && (
                        <div>
                          <p className="text-xs font-medium mb-1.5 opacity-70">Related Threads:</p>
                          <div className="flex flex-wrap gap-1.5">
                            {issue.relatedThreads.map((t, j) => (
                              <Badge key={j} variant="outline" className="text-xs font-mono">{t}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      {annotations.filter(a => a.issueIndex === i).map(a => (
                        <div key={a.id} className="mt-2 flex items-start gap-2 bg-muted/50 p-2 rounded text-xs">
                          <MessageSquare className="h-3 w-3 mt-0.5 shrink-0" />
                          <div className="flex-1">
                            <p>{a.note}</p>
                            <p className="text-muted-foreground mt-0.5">{new Date(a.createdAt).toLocaleString()}</p>
                          </div>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => deleteAnnotation.mutate(a.id)}>
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        <TabsContent value="recommendations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5" />
                Smart Recommendations ({recommendations.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recommendations.map((rec, i) => (
                  <div key={i} className={`flex items-start gap-3 p-4 rounded-lg border ${
                    rec.severity === 'critical' ? 'bg-red-50 dark:bg-red-950 border-red-200' :
                    rec.severity === 'warning' ? 'bg-yellow-50 dark:bg-yellow-950 border-yellow-200' :
                    'bg-blue-50 dark:bg-blue-950 border-blue-200'
                  }`}>
                    {severityIcon(rec.severity)}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="text-xs">{rec.category}</Badge>
                        <Badge variant={rec.severity === 'critical' ? 'destructive' : rec.severity === 'warning' ? 'default' : 'secondary'} className="text-xs">
                          {rec.severity}
                        </Badge>
                      </div>
                      <p className="text-sm">{rec.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="thread-pools" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Server className="h-5 w-5" />
                Thread Pool Analysis ({threadPools.length} pools)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {threadPools.map((pool, i) => {
                  const runnable = pool.threads.filter(t => t.state === 'RUNNABLE').length;
                  const blocked = pool.threads.filter(t => t.state === 'BLOCKED').length;
                  const waiting = pool.threads.filter(t => t.state === 'WAITING' || t.state === 'TIMED_WAITING').length;
                  const blockedRatio = pool.threads.length > 0 ? blocked / pool.threads.length : 0;
                  const healthColor = blockedRatio > 0.3 ? 'bg-red-500' : blockedRatio > 0.1 ? 'bg-yellow-500' : 'bg-green-500';
                  const healthLabel = blockedRatio > 0.3 ? 'Unhealthy' : blockedRatio > 0.1 ? 'Degraded' : 'Healthy';

                  return (
                    <details key={i} className="border rounded-lg">
                      <summary className="cursor-pointer p-4 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`h-3 w-3 rounded-full ${healthColor}`} />
                          <span className="font-medium">{pool.name}</span>
                          <Badge variant="outline">{pool.threads.length} threads</Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs">{healthLabel}</Badge>
                          <div className="flex gap-1 text-xs">
                            {runnable > 0 && <span className="text-green-600">{runnable}R</span>}
                            {blocked > 0 && <span className="text-red-600">{blocked}B</span>}
                            {waiting > 0 && <span className="text-orange-600">{waiting}W</span>}
                          </div>
                        </div>
                      </summary>
                      <div className="px-4 pb-4 space-y-2">
                        <div className="grid grid-cols-3 gap-2 text-center text-sm">
                          <div className="bg-green-50 dark:bg-green-950 p-2 rounded">
                            <div className="font-bold text-green-600">{runnable}</div>
                            <div className="text-xs text-muted-foreground">Runnable</div>
                          </div>
                          <div className="bg-red-50 dark:bg-red-950 p-2 rounded">
                            <div className="font-bold text-red-600">{blocked}</div>
                            <div className="text-xs text-muted-foreground">Blocked</div>
                          </div>
                          <div className="bg-orange-50 dark:bg-orange-950 p-2 rounded">
                            <div className="font-bold text-orange-600">{waiting}</div>
                            <div className="text-xs text-muted-foreground">Waiting</div>
                          </div>
                        </div>
                        <div className="space-y-1 max-h-48 overflow-auto">
                          {pool.threads.map((thread, j) => (
                            <div key={j} className="flex items-center justify-between text-sm p-2 bg-muted/50 rounded">
                              <span className="font-mono text-xs truncate mr-2">{thread.name}</span>
                              <Badge variant={
                                thread.state === 'RUNNABLE' ? 'default' :
                                thread.state === 'BLOCKED' ? 'destructive' :
                                'secondary'
                              } className="text-xs shrink-0">
                                {thread.state}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    </details>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flame-graph">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Flame Graph
              </CardTitle>
            </CardHeader>
            <CardContent>
              {threads.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No thread data for flame graph</div>
              ) : (
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-3 text-xs">
                    <span className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#1496ff' }} /> java.*</span>
                    <span className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#22c55e' }} /> com.example.*</span>
                    <span className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#ff6d00' }} /> org.apache.*</span>
                    <span className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#a855f7' }} /> org.springframework.*</span>
                    <span className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#64748b' }} /> other</span>
                  </div>
                  <div
                    className="relative w-full overflow-x-auto border rounded-lg bg-muted/30"
                    style={{ height: `${Math.min(Math.max(flameDepth + 2, 5), 20) * 22 + 20}px` }}
                  >
                    <FlameGraphRenderer node={flameRoot} totalValue={flameRoot.value} />
                  </div>
                  <p className="text-xs text-muted-foreground">Hover over bars to see full method path. Width represents number of threads at that frame. Root is at the bottom.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="deadlocks">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Deadlock Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              {deadlocks.length === 0 ? (
                <div className="text-center py-8 text-green-500">
                  No deadlocks detected
                </div>
              ) : (
                <div className="space-y-6">
                  {deadlocks.map((dl, i) => (
                    <div key={i} className="border rounded-lg p-4">
                      <h3 className="font-bold text-lg mb-2 text-red-500">Deadlock #{i + 1}</h3>
                      <div className="space-y-2">
                        <p><strong>Cycle:</strong></p>
                        <div className="flex flex-wrap items-center gap-2">
                          {dl.cycle.map((thread, j) => (
                            <span key={j} className="flex items-center gap-1">
                              <Badge variant="outline">{thread}</Badge>
                              {j < dl.cycle.length - 1 && <span>→</span>}
                            </span>
                          ))}
                          <span>→</span>
                          <Badge variant="outline">{dl.cycle[0]}</Badge>
                        </div>
                        {dl.locks.length > 0 && (
                          <div className="mt-2">
                            <p><strong>Locks involved:</strong></p>
                            <ul className="list-disc list-inside">
                              {dl.locks.map((lock, j) => (
                                <li key={j} className="text-sm font-mono">{lock}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="hotspots">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Cpu className="h-5 w-5" />
                Hotspot Analysis (Top Stack Frames)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {hotspots.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No hotspots detected</div>
              ) : (
                <div className="space-y-3">
                  {hotspots.slice(0, 20).map((hs, i) => (
                    <div key={i} className="border rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <code className="text-sm font-mono break-all">{hs.method}</code>
                        <Badge>{hs.count} occurrences</Badge>
                      </div>
                      <Progress value={hs.percentage} className="h-2" />
                      <p className="text-xs text-muted-foreground mt-1">{hs.percentage.toFixed(1)}% of stack frames</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contention">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Lock Contention Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              {contention.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No lock contention detected</div>
              ) : (
                <div className="space-y-3">
                  {contention.map((c, i) => (
                    <div key={i} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <code className="text-sm font-mono break-all">{c.lockName}</code>
                        <Badge variant={c.waitingThreads > 5 ? 'destructive' : 'secondary'}>
                          {c.waitingThreads} waiting
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Held by: <span className="font-medium">{c.holdingThread}</span>
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="clusters">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Layers className="h-5 w-5" />
                Stack Trace Clusters
              </CardTitle>
            </CardHeader>
            <CardContent>
              {clusters.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No clusters found</div>
              ) : (
                <div className="space-y-4">
                  {clusters.slice(0, 10).map((cluster, i) => (
                    <div key={i} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">Cluster #{cluster.id + 1}</span>
                        <div className="flex items-center gap-2">
                          <Badge>{cluster.threadCount} threads</Badge>
                          <Badge variant="outline">{(cluster.similarity * 100).toFixed(0)}% similar</Badge>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">Common pattern:</p>
                      <div className="bg-muted p-2 rounded text-xs font-mono max-h-32 overflow-auto">
                        {cluster.pattern.slice(0, 5).map((line, j) => (
                          <div key={j}>{line}</div>
                        ))}
                        {cluster.pattern.length > 5 && <div>... and {cluster.pattern.length - 5} more</div>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="threads">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>All Threads ({threads.length})</span>
                <Button variant="ghost" size="sm" onClick={() => setShowNotePanel(!showNotePanel)}>
                  <MessageSquare className="h-4 w-4 mr-1" /> Notes ({annotations.length})
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-3 mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <input
                    type="text"
                    placeholder="Search threads by name, state, or stack trace..."
                    value={searchText}
                    onChange={e => setSearchText(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-muted-foreground" />
                  <select
                    value={stateFilter}
                    onChange={e => setStateFilter(e.target.value)}
                    className="text-sm border rounded-md bg-background px-2 py-2 focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="All">All States</option>
                    <option value="RUNNABLE">RUNNABLE</option>
                    <option value="BLOCKED">BLOCKED</option>
                    <option value="WAITING">WAITING</option>
                    <option value="TIMED_WAITING">TIMED_WAITING</option>
                  </select>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mb-3">
                Showing {filteredThreads.length} of {threads.length} threads
                {debouncedSearch && ` matching "${debouncedSearch}"`}
                {stateFilter !== 'All' && ` in ${stateFilter} state`}
              </p>
              <div className="space-y-2 max-h-[600px] overflow-auto">
                {filteredThreads.map((thread, i) => {
                  const isBookmarked = bookmarkedNames.has(thread.name);
                  const threadAnnotations = annotations.filter(a => a.threadName === thread.name);
                  return (
                    <details key={i} className={`border rounded-lg p-3 ${isBookmarked ? 'border-yellow-400 dark:border-yellow-600' : ''}`}>
                      <summary className="cursor-pointer flex items-center justify-between">
                        <div className="flex items-center gap-2 min-w-0">
                          <button
                            className="shrink-0 hover:scale-110 transition-transform"
                            onClick={e => { e.preventDefault(); toggleBookmark.mutate(thread.name); }}
                          >
                            {isBookmarked ? <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" /> : <StarOff className="h-4 w-4 text-muted-foreground" />}
                          </button>
                          <span className="font-medium truncate">{thread.name}</span>
                          {isBookmarked && <Badge variant="outline" className="text-xs border-yellow-400 text-yellow-600 shrink-0">Bookmarked</Badge>}
                        </div>
                        <div className="flex items-center gap-2 shrink-0 ml-2">
                          <Badge variant={
                            thread.state === 'RUNNABLE' ? 'default' :
                            thread.state === 'BLOCKED' ? 'destructive' :
                            'secondary'
                          }>
                            {thread.state}
                          </Badge>
                          {thread.daemon && <Badge variant="outline">daemon</Badge>}
                        </div>
                      </summary>
                      <div className="mt-2 text-sm">
                        <div className="flex justify-end mb-1">
                          <Button variant="ghost" size="sm" onClick={() => handleAddNote(thread.name)}>
                            <Plus className="h-3 w-3 mr-1" /> Add Note
                          </Button>
                        </div>
                        {thread.blockedBy && (
                          <p className="text-red-500">Blocked by: {thread.blockedBy}</p>
                        )}
                        {thread.holding && thread.holding.length > 0 && (
                          <p>Holding: {thread.holding.join(', ')}</p>
                        )}
                        <div className="bg-muted p-2 rounded mt-2 font-mono text-xs max-h-40 overflow-auto">
                          {thread.stackTrace.map((line, j) => (
                            <div key={j}>at {line}</div>
                          ))}
                        </div>
                        {threadAnnotations.length > 0 && (
                          <div className="mt-2 space-y-1">
                            {threadAnnotations.map(a => (
                              <div key={a.id} className="flex items-start gap-2 bg-muted/50 p-2 rounded text-xs">
                                <MessageSquare className="h-3 w-3 mt-0.5 shrink-0" />
                                <div className="flex-1">
                                  <p>{a.note}</p>
                                  <p className="text-muted-foreground mt-0.5">{new Date(a.createdAt).toLocaleString()}</p>
                                </div>
                                <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => deleteAnnotation.mutate(a.id)}>
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </details>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gc-metrics" className="space-y-4">
          <GcMetricsPanel gcMetrics={analysis.gcMetrics} type="thread" formatBytes={formatBytes} dumpId={0} />
        </TabsContent>
      </Tabs>

      {showNotePanel && (
        <Card className="border-2 border-primary/20">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between text-base">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Annotations & Notes
                {noteThreadName && <Badge variant="outline" className="text-xs">Thread: {noteThreadName}</Badge>}
                {noteIssueIndex !== undefined && <Badge variant="outline" className="text-xs">Issue #{noteIssueIndex + 1}</Badge>}
              </div>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => { setShowNotePanel(false); setNoteThreadName(undefined); setNoteIssueIndex(undefined); }}>
                <X className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                placeholder="Add a note..."
                value={noteText}
                onChange={e => setNoteText(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') submitNote(); }}
                className="flex-1 text-sm border rounded-md bg-background px-3 py-2 focus:outline-none focus:ring-2 focus:ring-ring"
              />
              <Button size="sm" onClick={submitNote} disabled={!noteText.trim() || addAnnotation.isPending}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-2 max-h-64 overflow-auto">
              {annotations.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">No notes yet</p>
              ) : (
                annotations.map(a => (
                  <div key={a.id} className="flex items-start gap-2 p-3 border rounded-lg text-sm">
                    <MessageSquare className="h-4 w-4 mt-0.5 shrink-0 text-muted-foreground" />
                    <div className="flex-1 min-w-0">
                      <p>{a.note}</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {a.threadName && <Badge variant="outline" className="text-xs">Thread: {a.threadName}</Badge>}
                        {a.issueIndex !== undefined && a.issueIndex !== null && <Badge variant="outline" className="text-xs">Issue #{a.issueIndex + 1}</Badge>}
                        <span className="text-xs text-muted-foreground">{new Date(a.createdAt).toLocaleString()}</span>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0 shrink-0" onClick={() => deleteAnnotation.mutate(a.id)}>
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
