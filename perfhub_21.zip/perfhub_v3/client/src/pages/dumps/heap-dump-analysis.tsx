import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, TrendingUp, Database, Recycle, Layers } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS, DT_PALETTE } from "@/components/charts/dynatrace-theme";
import type { DumpAnalysis } from "./types";
import { GcMetricsPanel } from "./gc-metrics-panel";

export function HeapDumpAnalysis({ analysis, formatBytes, dumpId }: { analysis: DumpAnalysis; formatBytes: (bytes: number) => string; dumpId: number }) {
  const summary = analysis.heapSummary;
  const histogram = analysis.classHistogram || [];
  const leakSuspects = analysis.leakSuspects || [];
  const dominators = analysis.dominatorTree || [];
  const topObjects = analysis.topObjects || [];

  const topClassesData = topObjects.slice(0, 10).map(c => ({
    name: c.className.split('.').pop() || c.className,
    fullName: c.className,
    size: c.shallowSize,
    instances: c.instanceCount,
  }));

  return (
    <Tabs defaultValue="overview">
      <TabsList>
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="leaks">
          Leak Suspects {leakSuspects.length > 0 && <Badge variant="destructive" className="ml-1">{leakSuspects.length}</Badge>}
        </TabsTrigger>
        <TabsTrigger value="top-objects">Top Objects</TabsTrigger>
        <TabsTrigger value="dominators">Dominator Tree</TabsTrigger>
        <TabsTrigger value="histogram">Class Histogram</TabsTrigger>
        <TabsTrigger value="gc-metrics">
          <Recycle className="h-4 w-4 mr-1" /> GC Metrics
        </TabsTrigger>
      </TabsList>

      <TabsContent value="overview" className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{formatBytes(summary?.usedHeapSize || 0)}</div>
              <p className="text-sm text-muted-foreground">Used Heap</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{formatBytes(summary?.totalHeapSize || 0)}</div>
              <p className="text-sm text-muted-foreground">Total Heap</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{summary?.totalClasses || 0}</div>
              <p className="text-sm text-muted-foreground">Classes</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{(summary?.totalInstances || 0).toLocaleString()}</div>
              <p className="text-sm text-muted-foreground">Instances</p>
            </CardContent>
          </Card>
        </div>

        {summary && (
          <Card>
            <CardHeader>
              <CardTitle>Heap Usage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Used: {formatBytes(summary.usedHeapSize)}</span>
                  <span>Total: {formatBytes(summary.totalHeapSize)}</span>
                </div>
                <Progress value={(summary.usedHeapSize / summary.totalHeapSize) * 100} className="h-4" />
                <p className="text-sm text-muted-foreground text-center">
                  {((summary.usedHeapSize / summary.totalHeapSize) * 100).toFixed(1)}% utilized
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Top Memory Consumers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 sm:h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topClassesData} layout="vertical">
                  <CartesianGrid {...DT_GRID_PROPS} />
                  <XAxis type="number" tickFormatter={(v) => formatBytes(v)} {...DT_AXIS_PROPS} />
                  <YAxis type="category" dataKey="name" width={150} {...DT_AXIS_PROPS} />
                  <Tooltip
                    formatter={(value: number) => formatBytes(value)}
                    labelFormatter={(label) => topClassesData.find(d => d.name === label)?.fullName || label}
                    contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }}
                    cursor={DT_CURSOR_PROPS}
                  />
                  <Bar dataKey="size" fill={DT_COLORS.primary} name="Size" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="leaks">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Memory Leak Suspects
            </CardTitle>
          </CardHeader>
          <CardContent>
            {leakSuspects.length === 0 ? (
              <div className="text-center py-8 text-green-500">
                No memory leak suspects detected
              </div>
            ) : (
              <div className="space-y-4">
                {leakSuspects.map((suspect, i) => (
                  <div key={i} className={`border rounded-lg p-4 ${
                    suspect.probability === 'high' ? 'border-red-500 bg-red-50 dark:bg-red-950' :
                    suspect.probability === 'medium' ? 'border-orange-500 bg-orange-50 dark:bg-orange-950' :
                    'border-yellow-500 bg-yellow-50 dark:bg-yellow-950'
                  }`}>
                    <div className="flex items-center justify-between mb-2">
                      <code className="text-sm font-mono break-all font-bold">{suspect.className}</code>
                      <Badge variant={
                        suspect.probability === 'high' ? 'destructive' :
                        suspect.probability === 'medium' ? 'default' : 'secondary'
                      }>
                        {suspect.probability.toUpperCase()} probability
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm mb-2">
                      <div>
                        <span className="text-muted-foreground">Instances:</span>
                        <span className="ml-2 font-medium">{suspect.instanceCount.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Retained Size:</span>
                        <span className="ml-2 font-medium">{formatBytes(suspect.retainedSize)}</span>
                      </div>
                    </div>
                    <p className="text-sm">{suspect.reason}</p>
                    {suspect.referenceChain && suspect.referenceChain.length > 0 && (
                      <div className="mt-2">
                        <p className="text-sm text-muted-foreground">Reference chain:</p>
                        <div className="bg-muted p-2 rounded text-xs font-mono mt-1">
                          {suspect.referenceChain.map((ref, j) => (
                            <div key={j}>{j > 0 && '→ '}{ref}</div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="top-objects">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Top Objects by Size
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2">#</th>
                    <th className="text-left py-2">Class Name</th>
                    <th className="text-right py-2">Instances</th>
                    <th className="text-right py-2">Shallow Size</th>
                    <th className="text-right py-2">Retained Size</th>
                  </tr>
                </thead>
                <tbody>
                  {topObjects.map((obj, i) => (
                    <tr key={i} className="border-b">
                      <td className="py-2">{i + 1}</td>
                      <td className="py-2 font-mono text-xs break-all">{obj.className}</td>
                      <td className="py-2 text-right">{obj.instanceCount.toLocaleString()}</td>
                      <td className="py-2 text-right">{formatBytes(obj.shallowSize)}</td>
                      <td className="py-2 text-right">{formatBytes(obj.retainedSize || 0)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="dominators">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Layers className="h-5 w-5" />
              Dominator Tree
            </CardTitle>
          </CardHeader>
          <CardContent>
            {dominators.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No dominator data available</div>
            ) : (
              <div className="space-y-2">
                {dominators.map((node, i) => (
                  <div key={i} className="border rounded-lg p-3">
                    <div className="flex items-center justify-between mb-1">
                      <code className="text-sm font-mono break-all">{node.className}</code>
                      <Badge>{node.retainedPercentage.toFixed(1)}%</Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Shallow: {formatBytes(node.shallowSize)} | Retained: {formatBytes(node.retainedSize)}
                    </div>
                    <Progress value={node.retainedPercentage} className="h-2 mt-2" />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="histogram">
        <Card>
          <CardHeader>
            <CardTitle>Class Histogram ({histogram.length} classes)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-auto max-h-[600px] overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-background">
                  <tr className="border-b">
                    <th className="text-left py-2">#</th>
                    <th className="text-left py-2">Class Name</th>
                    <th className="text-right py-2">Instances</th>
                    <th className="text-right py-2">Size</th>
                  </tr>
                </thead>
                <tbody>
                  {histogram.slice(0, 100).map((entry, i) => (
                    <tr key={i} className="border-b hover:bg-muted/50">
                      <td className="py-1">{i + 1}</td>
                      <td className="py-1 font-mono text-xs break-all">{entry.className}</td>
                      <td className="py-1 text-right">{entry.instanceCount.toLocaleString()}</td>
                      <td className="py-1 text-right">{formatBytes(entry.shallowSize)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="gc-metrics" className="space-y-4">
        <GcMetricsPanel gcMetrics={analysis.gcMetrics} type="heap" formatBytes={formatBytes} dumpId={dumpId} />
      </TabsContent>
    </Tabs>
  );
}
