import { formatInTimeZone } from "date-fns-tz";
import { addDays, addWeeks, addMonths } from "date-fns";
import { z } from "zod";

export const COMMON_TIMEZONES = [
  { value: "UTC", label: "UTC", offset: "+00:00" },
  { value: "America/New_York", label: "Eastern Time (US)", offset: "-05:00" },
  { value: "America/Chicago", label: "Central Time (US)", offset: "-06:00" },
  { value: "America/Denver", label: "Mountain Time (US)", offset: "-07:00" },
  { value: "America/Los_Angeles", label: "Pacific Time (US)", offset: "-08:00" },
  { value: "America/Anchorage", label: "Alaska Time", offset: "-09:00" },
  { value: "Pacific/Honolulu", label: "Hawaii Time", offset: "-10:00" },
  { value: "America/Toronto", label: "Eastern Time (Canada)", offset: "-05:00" },
  { value: "America/Vancouver", label: "Pacific Time (Canada)", offset: "-08:00" },
  { value: "America/Sao_Paulo", label: "Brasilia Time", offset: "-03:00" },
  { value: "Europe/London", label: "London (GMT/BST)", offset: "+00:00" },
  { value: "Europe/Paris", label: "Central European Time", offset: "+01:00" },
  { value: "Europe/Berlin", label: "Berlin (CET/CEST)", offset: "+01:00" },
  { value: "Europe/Helsinki", label: "Eastern European Time", offset: "+02:00" },
  { value: "Europe/Moscow", label: "Moscow Time", offset: "+03:00" },
  { value: "Asia/Dubai", label: "Gulf Standard Time", offset: "+04:00" },
  { value: "Asia/Kolkata", label: "India Standard Time", offset: "+05:30" },
  { value: "Asia/Bangkok", label: "Indochina Time", offset: "+07:00" },
  { value: "Asia/Singapore", label: "Singapore Time", offset: "+08:00" },
  { value: "Asia/Shanghai", label: "China Standard Time", offset: "+08:00" },
  { value: "Asia/Tokyo", label: "Japan Standard Time", offset: "+09:00" },
  { value: "Asia/Seoul", label: "Korea Standard Time", offset: "+09:00" },
  { value: "Australia/Sydney", label: "Australian Eastern Time", offset: "+11:00" },
  { value: "Australia/Perth", label: "Australian Western Time", offset: "+08:00" },
  { value: "Pacific/Auckland", label: "New Zealand Time", offset: "+13:00" },
];

export function getBrowserTimezone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  } catch {
    return "UTC";
  }
}

export function getTimezoneAbbreviation(tz: string): string {
  try {
    const now = new Date();
    const parts = new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: 'short' }).formatToParts(now);
    const tzPart = parts.find(p => p.type === 'timeZoneName');
    return tzPart?.value || tz;
  } catch {
    return tz;
  }
}

export function getCurrentOffset(tz: string): string {
  try {
    return formatInTimeZone(new Date(), tz, 'xxx');
  } catch {
    return "";
  }
}

export const scheduleFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  scriptId: z.string().min(1, "Script is required"),
  date: z.string().min(1, "Date is required"),
  time: z.string().min(1, "Time is required"),
  timezone: z.string().min(1, "Timezone is required"),
  environment: z.string().min(1),
  recurrence: z.string().default("none"),
  isDistributed: z.boolean().default(false),
  workerNodes: z.string().optional(),
  testTypeId: z.string().optional(),
  volume: z.string().optional(),
  avgResponseTime: z.string().optional(),
  throughput: z.string().optional(),
  p90: z.string().optional(),
  p95: z.string().optional(),
  errorRate: z.string().optional(),
  releaseTag: z.string().optional(),
});

export type TestTypeRecord = { id: number; name: string; description?: string | null; };

export interface CustomEnvironment {
  id: number;
  name: string;
  description: string | null;
  createdBy: number;
  createdAt: string;
}

export const DEFAULT_ENVIRONMENTS = ["Dev", "Staging", "Prod"];

export function getNextRunDate(scheduledTime: Date, recurrence: string): Date | null {
  if (!recurrence || recurrence === 'none') return null;
  const now = new Date();
  let next = new Date(scheduledTime);
  while (next <= now) {
    if (recurrence === 'daily') next = addDays(next, 1);
    else if (recurrence === 'weekly') next = addWeeks(next, 1);
    else if (recurrence === 'monthly') next = addMonths(next, 1);
    else return null;
  }
  return next;
}
