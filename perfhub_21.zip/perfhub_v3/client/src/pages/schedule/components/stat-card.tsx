export function StatCard({ label, value, icon: Icon, color }: { label: string; value: number; icon: any; color: string }) {
  return (
    <div className={`flex items-center gap-3 p-3 rounded-lg border bg-gradient-to-br ${color}`}>
      <div className="p-2 rounded-md bg-background/60">
        <Icon className="w-4 h-4" />
      </div>
      <div>
        <div className="text-2xl font-bold">{value}</div>
        <div className="text-xs text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}
