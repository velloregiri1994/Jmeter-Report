import { useState, useEffect } from "react";
import { format } from "date-fns";
import { fromZonedTime } from "date-fns-tz";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryKeys } from "@/lib/query-keys";
import { useScripts } from "@/hooks/use-scripts";
import { useCreateSchedule } from "@/hooks/use-schedules";
import { useToast } from "@/hooks/use-toast";
import {
  Plus, AlertTriangle, PlusCircle, Globe, Tag,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
  DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from "@/components/ui/tabs";
import { EmailNotificationSection } from "./email-notification-section";
import {
  COMMON_TIMEZONES, getBrowserTimezone, getCurrentOffset,
  scheduleFormSchema, DEFAULT_ENVIRONMENTS,
  type TestTypeRecord, type CustomEnvironment,
} from "./schedule-utils";

export function CreateScheduleDialog({ open: controlledOpen, setOpen: controlledSetOpen, initialScriptId }: { open?: boolean, setOpen?: (open: boolean) => void, initialScriptId?: string }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [internalOpen, setInternalOpen] = useState(false);
  const open = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const setOpen = controlledSetOpen !== undefined ? controlledSetOpen : setInternalOpen;

  const { mutate, isPending } = useCreateSchedule();
  const { data: scripts } = useScripts();
  const [newEnvName, setNewEnvName] = useState("");
  const [showAddEnv, setShowAddEnv] = useState(false);
  const [newTestTypeName, setNewTestTypeName] = useState("");
  const [showAddTestType, setShowAddTestType] = useState(false);
  const [emailRecipients, setEmailRecipients] = useState<string[]>([]);
  const [emailSendOnSuccess, setEmailSendOnSuccess] = useState(true);
  const [emailSendOnFailure, setEmailSendOnFailure] = useState(true);
  const [emailSendOnSlaBreach, setEmailSendOnSlaBreach] = useState(true);

  const { data: customEnvironments = [] } = useQuery<CustomEnvironment[]>({
    queryKey: [...queryKeys.environments],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/environments");
      return res.json();
    }
  });

  const { data: testTypes = [] } = useQuery<TestTypeRecord[]>({
    queryKey: [...queryKeys.testTypes],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/test-types");
      return res.json();
    }
  });

  const createEnvironment = useMutation({
    mutationFn: async (name: string) => {
      const res = await apiRequest("POST", "/api/environments", { name });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.environments });
      toast({ title: "Environment Created", description: `"${data.name}" added` });
      setNewEnvName("");
      setShowAddEnv(false);
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });

  const createTestType = useMutation({
    mutationFn: async (name: string) => {
      const res = await apiRequest("POST", "/api/test-types", { name });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.testTypes });
      toast({ title: "Test Type Created", description: `"${data.name}" added` });
      setNewTestTypeName("");
      setShowAddTestType(false);
    }
  });

  const allEnvironments = [...DEFAULT_ENVIRONMENTS, ...customEnvironments.map(e => e.name)];

  const form = useForm<z.infer<typeof scheduleFormSchema>>({
    resolver: zodResolver(scheduleFormSchema),
    defaultValues: {
      name: "",
      environment: "Staging",
      recurrence: "none",
      date: format(new Date(), 'yyyy-MM-dd'),
      time: format(new Date(), 'HH:mm'),
      timezone: getBrowserTimezone(),
      isDistributed: false,
      scriptId: initialScriptId || ""
    }
  });

  useEffect(() => {
    if (initialScriptId) {
      form.setValue("scriptId", initialScriptId);
      const script = scripts?.find((s: any) => s.id.toString() === initialScriptId);
      if (script && !form.getValues("name")) {
        form.setValue("name", script.name);
      }
    }
  }, [initialScriptId, scripts, form]);

  const selectedScriptId = form.watch("scriptId");
  const selectedScript = scripts?.find((s: any) => s.id.toString() === selectedScriptId);

  const onSubmit = (data: z.infer<typeof scheduleFormSchema>) => {
    const localDateTime = new Date(`${data.date}T${data.time}:00`);
    const scheduledTime = fromZonedTime(localDateTime, data.timezone);

    const scriptId = parseInt(data.scriptId);
    if (!scriptId) {
      toast({ title: "Error", description: "Please select a script.", variant: "destructive" });
      return;
    }

    const selectedTestType = data.testTypeId ? testTypes.find(t => t.id === parseInt(data.testTypeId!)) : null;

    const payload = {
      name: data.name,
      scriptId: scriptId,
      scheduledTime: scheduledTime.toISOString(),
      status: "pending",
      recurrence: data.recurrence || "none",
      configuration: {
        environment: data.environment || "Staging",
        timezone: data.timezone,
        isDistributed: data.isDistributed || false,
        workerNodes: (data.isDistributed && data.workerNodes) ? parseInt(data.workerNodes) : undefined,
        testTypeId: data.testTypeId ? parseInt(data.testTypeId) : undefined,
        testTypeName: selectedTestType?.name || undefined,
        volume: data.volume || undefined,
        slas: {
          avgResponseTime: (data.avgResponseTime && String(data.avgResponseTime).trim() !== "") ? parseFloat(data.avgResponseTime) : undefined,
          throughput: (data.throughput && String(data.throughput).trim() !== "") ? parseFloat(data.throughput) : undefined,
          p90: (data.p90 && String(data.p90).trim() !== "") ? parseFloat(data.p90) : undefined,
          p95: (data.p95 && String(data.p95).trim() !== "") ? parseFloat(data.p95) : undefined,
          errorRate: (data.errorRate && String(data.errorRate).trim() !== "") ? parseFloat(data.errorRate) : undefined,
        },
        releaseTag: data.releaseTag || undefined,
        emailNotification: emailRecipients.length > 0 ? {
          recipients: emailRecipients,
          sendOnSuccess: emailSendOnSuccess,
          sendOnFailure: emailSendOnFailure,
          sendOnSlaBreach: emailSendOnSlaBreach,
        } : undefined,
      }
    };

    mutate(payload as any, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
        setEmailRecipients([]);
        toast({ title: "Success", description: "Test scheduled successfully" });
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err.message || "Failed to create schedule", variant: "destructive" });
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="shadow-lg shadow-primary/25">
          <Plus className="w-4 h-4 mr-2" /> Schedule Test
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Schedule Performance Test</DialogTitle>
          <DialogDescription>Configure and schedule a new performance test run.</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Test Name</FormLabel>
                  <FormControl><Input placeholder="e.g. Black Friday Load Test" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="scriptId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Script</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Select script" /></SelectTrigger></FormControl>
                    <SelectContent>
                      {scripts?.map((s: any) => (
                        <SelectItem key={s.id} value={s.id.toString()}>
                          <span className="flex items-center gap-2">
                            {s.name} ({s.toolType})
                            {!s.filePath && (
                              <span className="text-amber-500 text-xs flex items-center gap-1">
                                <AlertTriangle className="h-3 w-3" /> No file
                              </span>
                            )}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedScript && !selectedScript.filePath && (
                    <p className="text-amber-500 text-sm flex items-center gap-1 mt-1">
                      <AlertTriangle className="h-4 w-4" />
                      This script has no test file uploaded. Please upload a file before scheduling.
                    </p>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="time"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time</FormLabel>
                    <FormControl><Input type="time" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="timezone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5" /> Timezone
                    </FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select timezone" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="max-h-[300px]">
                        {COMMON_TIMEZONES.map((tz) => (
                          <SelectItem key={tz.value} value={tz.value}>
                            <span className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground font-mono w-16">{getCurrentOffset(tz.value)}</span>
                              {tz.label}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="recurrence"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Repeat</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || "none"}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">No Repeat</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4 border rounded-xl p-4 bg-muted/20">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-semibold text-sm">Service Level Agreements (SLAs)</h4>
                <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-muted shrink-0">Optional</span>
              </div>
              <Tabs defaultValue="avg" className="w-full">
                <TabsList className="grid grid-cols-3 sm:grid-cols-5 w-full">
                  <TabsTrigger value="avg">Avg</TabsTrigger>
                  <TabsTrigger value="tps">TPS</TabsTrigger>
                  <TabsTrigger value="p90">P90</TabsTrigger>
                  <TabsTrigger value="p95">P95</TabsTrigger>
                  <TabsTrigger value="err">Error</TabsTrigger>
                </TabsList>
                <div className="pt-4">
                  <TabsContent value="avg">
                    <FormField control={form.control} name="avgResponseTime" render={({ field }) => (
                      <FormItem><FormLabel>Avg Response Time (ms)</FormLabel><FormControl><Input type="number" placeholder="e.g. 500" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </TabsContent>
                  <TabsContent value="tps">
                    <FormField control={form.control} name="throughput" render={({ field }) => (
                      <FormItem><FormLabel>Throughput (req/s)</FormLabel><FormControl><Input type="number" placeholder="e.g. 100" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </TabsContent>
                  <TabsContent value="p90">
                    <FormField control={form.control} name="p90" render={({ field }) => (
                      <FormItem><FormLabel>90th Percentile (ms)</FormLabel><FormControl><Input type="number" placeholder="e.g. 800" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </TabsContent>
                  <TabsContent value="p95">
                    <FormField control={form.control} name="p95" render={({ field }) => (
                      <FormItem><FormLabel>95th Percentile (ms)</FormLabel><FormControl><Input type="number" placeholder="e.g. 1000" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </TabsContent>
                  <TabsContent value="err">
                    <FormField control={form.control} name="errorRate" render={({ field }) => (
                      <FormItem><FormLabel>Error Rate (%)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 1.0" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </TabsContent>
                </div>
              </Tabs>
            </div>

            <div className="space-y-4 border rounded-lg p-4 bg-muted/10">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Environment (Optional)</h4>
              <FormField
                control={form.control}
                name="environment"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Target Environment</FormLabel>
                    {showAddEnv ? (
                      <div className="flex gap-2">
                        <Input
                          placeholder="New environment name"
                          value={newEnvName}
                          onChange={(e) => setNewEnvName(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" && newEnvName.trim()) {
                              e.preventDefault();
                              createEnvironment.mutate(newEnvName.trim());
                            }
                          }}
                        />
                        <Button type="button" size="sm" onClick={() => { if (newEnvName.trim()) createEnvironment.mutate(newEnvName.trim()); }} disabled={!newEnvName.trim() || createEnvironment.isPending}>Add</Button>
                        <Button type="button" variant="ghost" size="sm" onClick={() => { setShowAddEnv(false); setNewEnvName(""); }}>Cancel</Button>
                      </div>
                    ) : (
                      <Select onValueChange={field.onChange} value={field.value || "Staging"}>
                        <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                        <SelectContent>
                          {allEnvironments.map((env) => (
                            <SelectItem key={env} value={env}>{env}</SelectItem>
                          ))}
                          <div className="border-t mt-1 pt-1">
                            <button type="button" className="w-full flex items-center gap-2 px-2 py-1.5 text-sm text-muted-foreground hover:bg-muted rounded cursor-pointer" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setShowAddEnv(true); }}>
                              <PlusCircle className="h-4 w-4" /> Add custom environment
                            </button>
                          </div>
                        </SelectContent>
                      </Select>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4 border rounded-lg p-4 bg-muted/10">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Test Configuration (Optional)</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="testTypeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Test Type</FormLabel>
                      {showAddTestType ? (
                        <div className="flex gap-2">
                          <Input placeholder="e.g. Load, Stress, Smoke" value={newTestTypeName} onChange={(e) => setNewTestTypeName(e.target.value)} />
                          <Button type="button" size="sm" onClick={() => newTestTypeName.trim() && createTestType.mutate(newTestTypeName.trim())} disabled={!newTestTypeName.trim()}>Add</Button>
                          <Button type="button" variant="ghost" size="sm" onClick={() => setShowAddTestType(false)}>Cancel</Button>
                        </div>
                      ) : (
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl><SelectTrigger><SelectValue placeholder="Select test type" /></SelectTrigger></FormControl>
                          <SelectContent>
                            {testTypes.map((t) => (
                              <SelectItem key={t.id} value={String(t.id)}>{t.name}</SelectItem>
                            ))}
                            <div className="border-t mt-1 pt-1">
                              <button type="button" className="w-full flex items-center gap-2 px-2 py-1.5 text-sm text-muted-foreground hover:bg-muted rounded cursor-pointer" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setShowAddTestType(true); }}>
                                <PlusCircle className="h-4 w-4" /> Add test type
                              </button>
                            </div>
                          </SelectContent>
                        </Select>
                      )}
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="volume"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Volume</FormLabel>
                      <FormControl><Input placeholder="e.g. 100 users, 1000 TPS" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className="space-y-4 border rounded-lg p-4 bg-muted/10">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5" /> Release Tag (Optional)
              </h4>
              <FormField
                control={form.control}
                name="releaseTag"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Release / Build Version</FormLabel>
                    <FormControl><Input placeholder="e.g. v2.1.0, Sprint 42, build-4521" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {selectedScript?.toolType === "JMeter" && (
              <div className="space-y-4 border rounded-lg p-4 bg-muted/10">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Distributed Testing</h4>
                  <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-muted">Optional</span>
                </div>
                <FormField
                  control={form.control}
                  name="isDistributed"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm bg-background">
                      <div className="space-y-0.5">
                        <FormLabel className="text-sm">Enable Distributed Test</FormLabel>
                        <div className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">Run across worker nodes</div>
                      </div>
                      <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                    </FormItem>
                  )}
                />
                {form.watch("isDistributed") && (
                  <FormField
                    control={form.control}
                    name="workerNodes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Number of Worker Nodes</FormLabel>
                        <FormControl><Input type="number" min={1} max={10} placeholder="e.g. 3" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </div>
            )}

            <EmailNotificationSection
              recipients={emailRecipients}
              setRecipients={setEmailRecipients}
              sendOnSuccess={emailSendOnSuccess}
              setSendOnSuccess={setEmailSendOnSuccess}
              sendOnFailure={emailSendOnFailure}
              setSendOnFailure={setEmailSendOnFailure}
              sendOnSlaBreach={emailSendOnSlaBreach}
              setSendOnSlaBreach={setEmailSendOnSlaBreach}
            />

            <DialogFooter>
              <Button type="submit" disabled={isPending}>{isPending ? "Scheduling..." : "Create Schedule"}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
