import { useState } from "react";
import { format } from "date-fns";
import { formatInTimeZone, fromZonedTime, toZonedTime } from "date-fns-tz";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryKeys } from "@/lib/query-keys";
import { useScripts } from "@/hooks/use-scripts";
import { useUpdateSchedule } from "@/hooks/use-schedules";
import { useToast } from "@/hooks/use-toast";
import {
  Edit2, AlertTriangle, PlusCircle, Globe,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from "@/components/ui/tabs";
import { EmailNotificationSection } from "./email-notification-section";
import {
  COMMON_TIMEZONES, getBrowserTimezone, getCurrentOffset,
  scheduleFormSchema, DEFAULT_ENVIRONMENTS,
  type TestTypeRecord, type CustomEnvironment,
} from "./schedule-utils";

export function EditScheduleDialog({ schedule, open, setOpen }: { schedule: any; open: boolean; setOpen: (open: boolean) => void }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { mutate: updateSchedule, isPending } = useUpdateSchedule();
  const { data: scripts } = useScripts();
  const [newEnvName, setNewEnvName] = useState("");
  const [showAddEnv, setShowAddEnv] = useState(false);

  const existingEmailConfig = (schedule.configuration as any)?.emailNotification;
  const [emailRecipients, setEmailRecipients] = useState<string[]>(existingEmailConfig?.recipients || []);
  const [emailSendOnSuccess, setEmailSendOnSuccess] = useState(existingEmailConfig?.sendOnSuccess ?? true);
  const [emailSendOnFailure, setEmailSendOnFailure] = useState(existingEmailConfig?.sendOnFailure ?? true);
  const [emailSendOnSlaBreach, setEmailSendOnSlaBreach] = useState(existingEmailConfig?.sendOnSlaBreach ?? true);

  const { data: customEnvironments = [] } = useQuery<CustomEnvironment[]>({
    queryKey: [...queryKeys.environments],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/environments");
      return res.json();
    }
  });

  const { data: testTypes = [] } = useQuery<TestTypeRecord[]>({
    queryKey: [...queryKeys.testTypes],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/test-types");
      return res.json();
    }
  });

  const createEnvironment = useMutation({
    mutationFn: async (name: string) => {
      const res = await apiRequest("POST", "/api/environments", { name });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.environments });
      setNewEnvName(""); setShowAddEnv(false);
    }
  });

  const allEnvironments = [...DEFAULT_ENVIRONMENTS, ...customEnvironments.map(e => e.name)];

  const config = schedule.configuration as any;
  const slas = config?.slas || {};

  const editTimezone = config?.timezone || getBrowserTimezone();
  const scheduledInTz = config?.timezone
    ? toZonedTime(new Date(schedule.scheduledTime), config.timezone)
    : new Date(schedule.scheduledTime);

  const form = useForm<z.infer<typeof scheduleFormSchema>>({
    resolver: zodResolver(scheduleFormSchema),
    defaultValues: {
      name: schedule.name || "",
      scriptId: String(schedule.scriptId),
      date: config?.timezone
        ? formatInTimeZone(new Date(schedule.scheduledTime), config.timezone, 'yyyy-MM-dd')
        : format(new Date(schedule.scheduledTime), 'yyyy-MM-dd'),
      time: config?.timezone
        ? formatInTimeZone(new Date(schedule.scheduledTime), config.timezone, 'HH:mm')
        : format(new Date(schedule.scheduledTime), 'HH:mm'),
      timezone: editTimezone,
      environment: config?.environment || "Staging",
      recurrence: schedule.recurrence || "none",
      isDistributed: config?.isDistributed || false,
      workerNodes: config?.workerNodes ? String(config.workerNodes) : "",
      testTypeId: config?.testTypeId ? String(config.testTypeId) : "",
      volume: config?.volume || "",
      avgResponseTime: slas.avgResponseTime ? String(slas.avgResponseTime) : "",
      throughput: slas.throughput ? String(slas.throughput) : "",
      p90: slas.p90 ? String(slas.p90) : "",
      p95: slas.p95 ? String(slas.p95) : "",
      errorRate: slas.errorRate ? String(slas.errorRate) : "",
    }
  });

  const selectedScriptId = form.watch("scriptId");
  const selectedScript = scripts?.find((s: any) => s.id.toString() === selectedScriptId);

  const onSubmit = (data: z.infer<typeof scheduleFormSchema>) => {
    const localDateTime = new Date(`${data.date}T${data.time}:00`);
    const scheduledTime = fromZonedTime(localDateTime, data.timezone);
    const selectedTestType = data.testTypeId ? testTypes.find(t => t.id === parseInt(data.testTypeId!)) : null;

    updateSchedule({
      id: schedule.id,
      name: data.name,
      scriptId: parseInt(data.scriptId),
      scheduledTime: scheduledTime.toISOString() as any,
      recurrence: data.recurrence || "none",
      configuration: {
        environment: data.environment || "Staging",
        timezone: data.timezone,
        isDistributed: data.isDistributed || false,
        workerNodes: (data.isDistributed && data.workerNodes) ? parseInt(data.workerNodes) : undefined,
        testTypeId: data.testTypeId ? parseInt(data.testTypeId) : undefined,
        testTypeName: selectedTestType?.name || undefined,
        volume: data.volume || undefined,
        slas: {
          avgResponseTime: data.avgResponseTime ? parseFloat(data.avgResponseTime) : undefined,
          throughput: data.throughput ? parseFloat(data.throughput) : undefined,
          p90: data.p90 ? parseFloat(data.p90) : undefined,
          p95: data.p95 ? parseFloat(data.p95) : undefined,
          errorRate: data.errorRate ? parseFloat(data.errorRate) : undefined,
        },
        emailNotification: emailRecipients.length > 0 ? {
          recipients: emailRecipients,
          sendOnSuccess: emailSendOnSuccess,
          sendOnFailure: emailSendOnFailure,
          sendOnSlaBreach: emailSendOnSlaBreach,
        } : undefined,
      } as any
    }, {
      onSuccess: () => {
        setOpen(false);
        toast({ title: "Schedule Updated", description: "Changes saved successfully" });
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Edit2 className="w-5 h-5" />
            Edit Schedule
          </DialogTitle>
          <DialogDescription>Modify the schedule configuration and save changes.</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Test Name</FormLabel>
                  <FormControl><Input placeholder="e.g. Black Friday Load Test" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="scriptId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Script</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Select script" /></SelectTrigger></FormControl>
                    <SelectContent>
                      {scripts?.map((s: any) => (
                        <SelectItem key={s.id} value={s.id.toString()}>
                          <span className="flex items-center gap-2">
                            {s.name} ({s.toolType})
                            {!s.filePath && (
                              <span className="text-amber-500 text-xs flex items-center gap-1">
                                <AlertTriangle className="h-3 w-3" /> No file
                              </span>
                            )}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="time"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time</FormLabel>
                    <FormControl><Input type="time" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="timezone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5" /> Timezone
                    </FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select timezone" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="max-h-[300px]">
                        {COMMON_TIMEZONES.map((tz) => (
                          <SelectItem key={tz.value} value={tz.value}>
                            <span className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground font-mono w-16">{getCurrentOffset(tz.value)}</span>
                              {tz.label}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="recurrence"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Repeat</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || "none"}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">No Repeat</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4 border rounded-xl p-4 bg-muted/20">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-semibold text-sm">Service Level Agreements (SLAs)</h4>
                <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-muted shrink-0">Optional</span>
              </div>
              <Tabs defaultValue="avg" className="w-full">
                <TabsList className="grid grid-cols-3 sm:grid-cols-5 w-full">
                  <TabsTrigger value="avg">Avg</TabsTrigger>
                  <TabsTrigger value="tps">TPS</TabsTrigger>
                  <TabsTrigger value="p90">P90</TabsTrigger>
                  <TabsTrigger value="p95">P95</TabsTrigger>
                  <TabsTrigger value="err">Error</TabsTrigger>
                </TabsList>
                <div className="pt-4">
                  <TabsContent value="avg">
                    <FormField control={form.control} name="avgResponseTime" render={({ field }) => (
                      <FormItem><FormLabel>Avg Response Time (ms)</FormLabel><FormControl><Input type="number" placeholder="e.g. 500" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </TabsContent>
                  <TabsContent value="tps">
                    <FormField control={form.control} name="throughput" render={({ field }) => (
                      <FormItem><FormLabel>Throughput (req/s)</FormLabel><FormControl><Input type="number" placeholder="e.g. 100" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </TabsContent>
                  <TabsContent value="p90">
                    <FormField control={form.control} name="p90" render={({ field }) => (
                      <FormItem><FormLabel>90th Percentile (ms)</FormLabel><FormControl><Input type="number" placeholder="e.g. 800" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </TabsContent>
                  <TabsContent value="p95">
                    <FormField control={form.control} name="p95" render={({ field }) => (
                      <FormItem><FormLabel>95th Percentile (ms)</FormLabel><FormControl><Input type="number" placeholder="e.g. 1000" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </TabsContent>
                  <TabsContent value="err">
                    <FormField control={form.control} name="errorRate" render={({ field }) => (
                      <FormItem><FormLabel>Error Rate (%)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 1.0" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </TabsContent>
                </div>
              </Tabs>
            </div>

            <div className="space-y-4 border rounded-lg p-4 bg-muted/10">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Environment</h4>
              <FormField
                control={form.control}
                name="environment"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Target Environment</FormLabel>
                    {showAddEnv ? (
                      <div className="flex gap-2">
                        <Input placeholder="New environment name" value={newEnvName} onChange={(e) => setNewEnvName(e.target.value)} />
                        <Button type="button" size="sm" onClick={() => newEnvName.trim() && createEnvironment.mutate(newEnvName.trim())} disabled={!newEnvName.trim()}>Add</Button>
                        <Button type="button" variant="ghost" size="sm" onClick={() => { setShowAddEnv(false); setNewEnvName(""); }}>Cancel</Button>
                      </div>
                    ) : (
                      <Select onValueChange={field.onChange} value={field.value || "Staging"}>
                        <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                        <SelectContent>
                          {allEnvironments.map((env) => (
                            <SelectItem key={env} value={env}>{env}</SelectItem>
                          ))}
                          <div className="border-t mt-1 pt-1">
                            <button type="button" className="w-full flex items-center gap-2 px-2 py-1.5 text-sm text-muted-foreground hover:bg-muted rounded cursor-pointer" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setShowAddEnv(true); }}>
                              <PlusCircle className="h-4 w-4" /> Add custom environment
                            </button>
                          </div>
                        </SelectContent>
                      </Select>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4 border rounded-lg p-4 bg-muted/10">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Test Configuration</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="testTypeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Test Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl><SelectTrigger><SelectValue placeholder="Select test type" /></SelectTrigger></FormControl>
                        <SelectContent>
                          {testTypes.map((t) => (
                            <SelectItem key={t.id} value={String(t.id)}>{t.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="volume"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Volume</FormLabel>
                      <FormControl><Input placeholder="e.g. 100 users, 1000 TPS" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {selectedScript?.toolType === "JMeter" && (
              <div className="space-y-4 border rounded-lg p-4 bg-muted/10">
                <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Distributed Testing</h4>
                <FormField
                  control={form.control}
                  name="isDistributed"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm bg-background">
                      <div className="space-y-0.5">
                        <FormLabel className="text-sm">Enable Distributed Test</FormLabel>
                        <div className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">Run across worker nodes</div>
                      </div>
                      <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                    </FormItem>
                  )}
                />
                {form.watch("isDistributed") && (
                  <FormField
                    control={form.control}
                    name="workerNodes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Number of Worker Nodes</FormLabel>
                        <FormControl><Input type="number" min={1} max={10} placeholder="e.g. 3" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </div>
            )}

            <EmailNotificationSection
              recipients={emailRecipients}
              setRecipients={setEmailRecipients}
              sendOnSuccess={emailSendOnSuccess}
              setSendOnSuccess={setEmailSendOnSuccess}
              sendOnFailure={emailSendOnFailure}
              setSendOnFailure={setEmailSendOnFailure}
              sendOnSlaBreach={emailSendOnSlaBreach}
              setSendOnSlaBreach={setEmailSendOnSlaBreach}
            />

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={isPending}>{isPending ? "Saving..." : "Save Changes"}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
