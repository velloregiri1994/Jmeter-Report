import { useState } from "react";
import { XCircle, Mail } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function EmailNotificationSection({ recipients, setRecipients, sendOnSuccess, setSendOnSuccess, sendOnFailure, setSendOnFailure, sendOnSlaBreach, setSendOnSlaBreach }: {
  recipients: string[];
  setRecipients: (r: string[]) => void;
  sendOnSuccess: boolean;
  setSendOnSuccess: (v: boolean) => void;
  sendOnFailure: boolean;
  setSendOnFailure: (v: boolean) => void;
  sendOnSlaBreach: boolean;
  setSendOnSlaBreach: (v: boolean) => void;
}) {
  const [recipientInput, setRecipientInput] = useState("");

  const addRecipient = () => {
    const email = recipientInput.trim();
    if (email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && !recipients.includes(email)) {
      setRecipients([...recipients, email]);
      setRecipientInput("");
    }
  };

  const removeRecipient = (email: string) => {
    setRecipients(recipients.filter(r => r !== email));
  };

  return (
    <div className="space-y-4 border rounded-xl p-4 bg-muted/20">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Mail className="w-4 h-4 text-muted-foreground" />
          <h4 className="font-semibold text-sm">Email Notifications</h4>
        </div>
        <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-muted shrink-0">Optional</span>
      </div>
      <p className="text-xs text-muted-foreground">Get email alerts when this test completes. Leave empty to use default recipients from admin settings.</p>

      <div>
        <Label className="text-sm">Recipients</Label>
        <div className="flex gap-2 mt-1">
          <Input
            placeholder="email@example.com"
            value={recipientInput}
            onChange={(e) => setRecipientInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addRecipient(); } }}
          />
          <Button type="button" variant="outline" size="sm" onClick={addRecipient} disabled={!recipientInput.trim()}>Add</Button>
        </div>
        {recipients.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {recipients.map((email) => (
              <Badge key={email} variant="secondary" className="text-xs gap-1 pr-1">
                {email}
                <button type="button" onClick={() => removeRecipient(email)} className="ml-1 hover:text-destructive">
                  <XCircle className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </div>

      <div className="space-y-2">
        <Label className="text-sm">Send email when</Label>
        <div className="flex flex-col gap-2">
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <Switch checked={sendOnSuccess} onCheckedChange={setSendOnSuccess} />
            <span>Test passes</span>
          </label>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <Switch checked={sendOnFailure} onCheckedChange={setSendOnFailure} />
            <span>Test fails</span>
          </label>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <Switch checked={sendOnSlaBreach} onCheckedChange={setSendOnSlaBreach} />
            <span>SLA breached</span>
          </label>
        </div>
      </div>
    </div>
  );
}
