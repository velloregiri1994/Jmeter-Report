import { useSchedules, useQueueTest } from "@/hooks/use-schedules";
import { useScripts } from "@/hooks/use-scripts";
import { format, formatDistanceToNow, isToday, isTomorrow, isPast } from "date-fns";
import { formatInTimeZone } from "date-fns-tz";
import { useState, useEffect, useMemo, lazy, Suspense } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryKeys } from "@/lib/query-keys";
import {
  CalendarDays, Play, Repeat, Copy, Trash2, XCircle,
  CheckSquare, Square, AlertTriangle, Clock, Timer,
  ChevronDown, Edit2, ExternalLink,
  Activity, CheckCircle2, Ban, Loader2, Zap, Target, BarChart3,
  ListFilter, Calendar, List, Globe
} from "lucide-react";

const TestCalendar = lazy(() => import("@/pages/calendar/index"));
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Search } from "lucide-react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { StatusBadge } from "@/components/status-badge";
import { PageHeader } from "@/components/page-header";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Skeleton } from "@/components/ui/skeleton";
import { QueryErrorFallback } from "@/components/error-boundary";

import { getTimezoneAbbreviation, getNextRunDate } from "./components/schedule-utils";
import { StatCard } from "./components/stat-card";
import { CreateScheduleDialog } from "./components/create-schedule-dialog";
import { EditScheduleDialog } from "./components/edit-schedule-dialog";
import { useAuth } from "@/hooks/use-auth";

export default function SchedulePage() {
  const { canWrite } = useAuth();
  const queryClient = useQueryClient();
  const { data: schedules, isLoading, isError, error, refetch } = useSchedules();
  const { data: scripts } = useScripts();
  const { mutate: queueTest, isPending: isQueueing } = useQueueTest();
  const { toast } = useToast();
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [envFilter, setEnvFilter] = useState<string>("all");
  const [scriptFilter, setScriptFilter] = useState<string>("all");
  const [editingSchedule, setEditingSchedule] = useState<any>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);
  const [bulkDeleteConfirm, setBulkDeleteConfirm] = useState(false);
  const [viewMode, setViewMode] = useState<"list" | "calendar">("list");
  const [schedulePage, setSchedulePage] = useState(1);
  const SCHEDULES_PER_PAGE = 12;
  const [, navigate] = useLocation();

  const bulkRun = useMutation({
    mutationFn: async (ids: number[]) => {
      return apiRequest("POST", "/api/schedules/bulk/run", { ids });
    },
    onSuccess: (data: any) => {
      toast({ title: "Tests Queued", description: `${data.queued} test(s) added to queue` });
      queryClient.invalidateQueries({ queryKey: queryKeys.schedules.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.executions.all });
      setSelectedIds(new Set());
    }
  });

  const bulkCancel = useMutation({
    mutationFn: async (ids: number[]) => {
      return apiRequest("POST", "/api/schedules/bulk/cancel", { ids });
    },
    onSuccess: () => {
      toast({ title: "Schedules Cancelled" });
      queryClient.invalidateQueries({ queryKey: queryKeys.schedules.all });
      setSelectedIds(new Set());
    }
  });

  const bulkDelete = useMutation({
    mutationFn: async (ids: number[]) => {
      return apiRequest("POST", "/api/schedules/bulk/delete", { ids });
    },
    onSuccess: () => {
      toast({ title: "Schedules Deleted" });
      queryClient.invalidateQueries({ queryKey: queryKeys.schedules.all });
      setSelectedIds(new Set());
    }
  });

  const cloneSchedule = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("POST", `/api/schedules/${id}/clone`, {});
    },
    onSuccess: () => {
      toast({ title: "Schedule Cloned" });
      queryClient.invalidateQueries({ queryKey: queryKeys.schedules.all });
    }
  });

  const cancelSchedule = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("POST", `/api/schedules/${id}/cancel`, {});
    },
    onSuccess: () => {
      toast({ title: "Schedule Cancelled" });
      queryClient.invalidateQueries({ queryKey: queryKeys.schedules.all });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });

  const deleteSchedule = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("POST", "/api/schedules/bulk/delete", { ids: [id] });
    },
    onSuccess: () => {
      toast({ title: "Schedule Deleted" });
      queryClient.invalidateQueries({ queryKey: queryKeys.schedules.all });
      setDeleteConfirmId(null);
    }
  });

  const toggleSelect = (id: number) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const stats = useMemo(() => {
    if (!schedules) return { total: 0, pending: 0, running: 0, completed: 0, cancelled: 0 };
    return {
      total: schedules.length,
      pending: schedules.filter((s: any) => s.status === 'pending' || s.status === 'queued').length,
      running: schedules.filter((s: any) => s.status === 'running').length,
      completed: schedules.filter((s: any) => s.status === 'completed').length,
      cancelled: schedules.filter((s: any) => s.status === 'cancelled' || s.status === 'failed').length,
    };
  }, [schedules]);

  const environments = useMemo(() => {
    if (!schedules) return [];
    const envs = new Set<string>();
    schedules.forEach((s: any) => {
      const env = (s.configuration as any)?.environment;
      if (env) envs.add(env);
    });
    return Array.from(envs).sort();
  }, [schedules]);

  const filteredSchedules = useMemo(() => {
    if (!schedules) return [];
    return schedules.filter((s: any) => {
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const nameMatch = s.name?.toLowerCase().includes(q);
        const scriptMatch = s.script?.name?.toLowerCase().includes(q);
        if (!nameMatch && !scriptMatch) return false;
      }
      if (statusFilter !== "all") {
        if (statusFilter === "pending" && s.status !== "pending" && s.status !== "queued") return false;
        if (statusFilter === "running" && s.status !== "running") return false;
        if (statusFilter === "completed" && s.status !== "completed") return false;
        if (statusFilter === "cancelled" && s.status !== "cancelled" && s.status !== "failed") return false;
      }
      if (envFilter !== "all") {
        const env = (s.configuration as any)?.environment;
        if (env !== envFilter) return false;
      }
      if (scriptFilter !== "all") {
        if (String(s.scriptId) !== scriptFilter) return false;
      }
      return true;
    });
  }, [schedules, searchQuery, statusFilter, envFilter, scriptFilter]);

  useEffect(() => {
    setSchedulePage(1);
  }, [searchQuery, statusFilter, envFilter, scriptFilter]);

  const scheduleTotalPages = Math.ceil(filteredSchedules.length / SCHEDULES_PER_PAGE);
  const paginatedSchedules = filteredSchedules.slice((schedulePage - 1) * SCHEDULES_PER_PAGE, schedulePage * SCHEDULES_PER_PAGE);

  const groupedSchedules = useMemo(() => {
    const groups: Record<string, any[]> = {};
    paginatedSchedules.forEach((schedule: any) => {
      const config = schedule.configuration as any;
      const tz = config?.timezone;
      const dateKey = tz
        ? formatInTimeZone(new Date(schedule.scheduledTime), tz, 'yyyy-MM-dd')
        : format(new Date(schedule.scheduledTime), 'yyyy-MM-dd');
      if (!groups[dateKey]) groups[dateKey] = [];
      groups[dateKey].push(schedule);
    });
    return groups;
  }, [paginatedSchedules]);

  const sortedDates = Object.keys(groupedSchedules).sort((a, b) => b.localeCompare(a));

  const selectAllVisible = () => {
    setSelectedIds(new Set(filteredSchedules.map((s: any) => s.id)));
  };

  const clearSelection = () => setSelectedIds(new Set());

  const [location] = useLocation();
  const [initialDialogOpen, setInitialDialogOpen] = useState(false);
  const [initialScriptId, setInitialScriptId] = useState<string | undefined>();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const scriptId = params.get("scriptId");
    if (scriptId) {
      setInitialScriptId(scriptId);
      setInitialDialogOpen(true);
    }
  }, [location]);

  const getDateLabel = (dateKey: string) => {
    const date = new Date(dateKey + 'T00:00:00');
    if (isToday(date)) return "Today";
    if (isTomorrow(date)) return "Tomorrow";
    return format(date, 'EEEE, MMMM d, yyyy');
  };

  const getLastExecution = (schedule: any) => {
    if (!schedule.executions || schedule.executions.length === 0) return null;
    const sorted = [...schedule.executions].sort((a: any, b: any) => 
      new Date(b.startTime || b.createdAt).getTime() - new Date(a.startTime || a.createdAt).getTime()
    );
    return sorted[0];
  };

  const hasSLAs = (schedule: any) => {
    const slas = (schedule.configuration as any)?.slas;
    if (!slas) return false;
    return Object.values(slas).some(v => v !== undefined && v !== null && v !== "");
  };

  const hasActiveFilters = statusFilter !== "all" || envFilter !== "all" || scriptFilter !== "all" || searchQuery !== "";

  if (isError) return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load schedules" />;

  return (
    <div className="section-gap">
      <PageHeader
        title="Schedule & Calendar"
        subtitle="Schedule, manage, and visualize performance tests"
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center rounded-lg border bg-muted/50 p-0.5 mr-1">
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                className="h-7 px-3 text-xs"
                onClick={() => setViewMode("list")}
                aria-label="List view"
              >
                <List className="w-3.5 h-3.5 mr-1.5" /> List
              </Button>
              <Button
                variant={viewMode === "calendar" ? "default" : "ghost"}
                size="sm"
                className="h-7 px-3 text-xs"
                onClick={() => setViewMode("calendar")}
                aria-label="Calendar view"
              >
                <CalendarDays className="w-3.5 h-3.5 mr-1.5" /> Calendar
              </Button>
            </div>
            {canWrite && viewMode === "list" && selectedIds.size > 0 && (
              <>
                <span className="text-sm font-medium text-primary mr-1">{selectedIds.size} selected</span>
                <Button variant="outline" size="sm" onClick={() => bulkRun.mutate(Array.from(selectedIds))} disabled={bulkRun.isPending}>
                  <Play className="w-4 h-4 mr-1" /> Run
                </Button>
                <Button variant="outline" size="sm" onClick={() => bulkCancel.mutate(Array.from(selectedIds))} disabled={bulkCancel.isPending}>
                  <XCircle className="w-4 h-4 mr-1" /> Cancel
                </Button>
                <Button variant="destructive" size="sm" onClick={() => setBulkDeleteConfirm(true)} disabled={bulkDelete.isPending}>
                  <Trash2 className="w-4 h-4 mr-1" /> Delete
                </Button>
                <Button variant="ghost" size="sm" onClick={clearSelection}>Clear</Button>
              </>
            )}
            {canWrite && viewMode === "list" && <CreateScheduleDialog open={initialDialogOpen} setOpen={setInitialDialogOpen} initialScriptId={initialScriptId} />}
          </div>
        }
      />

      {viewMode === "calendar" ? (
        <Suspense fallback={<div className="flex items-center justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>}>
          <TestCalendar />
        </Suspense>
      ) : (
      <>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <StatCard label="Total" value={stats.total} icon={Calendar} color="from-blue-500/10 to-blue-600/5 border-blue-500/20" />
        <StatCard label="Pending" value={stats.pending} icon={Clock} color="from-amber-500/10 to-amber-600/5 border-amber-500/20" />
        <StatCard label="Running" value={stats.running} icon={Activity} color="from-cyan-500/10 to-cyan-600/5 border-cyan-500/20" />
        <StatCard label="Completed" value={stats.completed} icon={CheckCircle2} color="from-emerald-500/10 to-emerald-600/5 border-emerald-500/20" />
        <StatCard label="Cancelled / Failed" value={stats.cancelled} icon={Ban} color="from-rose-500/10 to-rose-600/5 border-rose-500/20" />
      </div>

      <Card className="card-shadow">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or script..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                aria-label="Schedule search"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[130px]" aria-label="Filter by status">
                  <ListFilter className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="running">Running</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
              <Select value={envFilter} onValueChange={setEnvFilter}>
                <SelectTrigger className="w-[130px]" aria-label="Filter by environment">
                  <Target className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
                  <SelectValue placeholder="Environment" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Envs</SelectItem>
                  {environments.map(env => (
                    <SelectItem key={env} value={env}>{env}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={scriptFilter} onValueChange={setScriptFilter}>
                <SelectTrigger className="w-[150px]" aria-label="Filter by script">
                  <BarChart3 className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
                  <SelectValue placeholder="Script" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Scripts</SelectItem>
                  {scripts?.map((s: any) => (
                    <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {hasActiveFilters && (
                <Button variant="ghost" size="sm" onClick={() => { setSearchQuery(""); setStatusFilter("all"); setEnvFilter("all"); setScriptFilter("all"); }}>
                  Clear Filters
                </Button>
              )}
            </div>
          </div>
          {hasActiveFilters && (
            <div className="mt-2 text-xs text-muted-foreground">
              Showing {filteredSchedules.length} of {schedules?.length || 0} schedules
              {selectedIds.size === 0 && filteredSchedules.length > 0 && (
                <Button variant="ghost" size="sm" className="text-xs h-auto px-1 py-0 ml-2" onClick={selectAllVisible}>
                  Select all visible
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-6">
        {isLoading ? (
          <div className="space-y-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="h-5 w-48" />
                <div className="grid gap-3">
                  {[...Array(2)].map((_, j) => (
                    <div key={j} className="rounded-xl border p-5 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Skeleton className="h-5 w-5 rounded" />
                          <Skeleton className="h-5 w-40" />
                          <Skeleton className="h-5 w-16 rounded-full" />
                        </div>
                        <Skeleton className="h-8 w-20 rounded-md" />
                      </div>
                      <div className="flex items-center gap-4">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-4 w-20" />
                        <Skeleton className="h-4 w-32" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : sortedDates.length === 0 ? (
          <div className="text-center py-20 bg-muted/20 rounded-xl border border-dashed">
            <CalendarDays className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">{hasActiveFilters ? "No matching schedules" : "No tests scheduled"}</h3>
            <p className="text-muted-foreground mt-1">
              {hasActiveFilters ? "Try adjusting your filters or search query." : "Schedule your first performance test to get started."}
            </p>
          </div>
        ) : (
          sortedDates.map(dateKey => (
            <div key={dateKey}>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3 sticky top-0 bg-background/95 backdrop-blur py-2 z-10 flex items-center gap-2">
                <CalendarDays className="w-4 h-4 text-primary/60" />
                {getDateLabel(dateKey)}
                {getDateLabel(dateKey) !== "Today" && getDateLabel(dateKey) !== "Tomorrow" && (
                  <span className="text-xs font-normal text-muted-foreground/50">
                    ({formatDistanceToNow(new Date(dateKey + 'T00:00:00'), { addSuffix: true })})
                  </span>
                )}
                <span className="text-xs text-muted-foreground/60 font-normal ml-1">
                  ({groupedSchedules[dateKey].length} {groupedSchedules[dateKey].length === 1 ? 'test' : 'tests'})
                </span>
              </h3>
              <div className="grid gap-3">
                {groupedSchedules[dateKey].map((schedule: any, idx: number) => {
                  const config = schedule.configuration as any;
                  const lastExec = getLastExecution(schedule);
                  const nextRun = getNextRunDate(new Date(schedule.scheduledTime), schedule.recurrence);
                  const scheduledDate = new Date(schedule.scheduledTime);
                  const isOverdue = isPast(scheduledDate) && (schedule.status === 'pending');

                  return (
                    <Card
                      key={schedule.id}
                      className={`hover:shadow-md transition-all duration-200 ${selectedIds.has(schedule.id) ? 'ring-2 ring-primary bg-primary/5' : ''} ${isOverdue ? 'border-amber-500/40' : ''}`}
                      style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: `${idx * 40}ms` }}
                    >
                      <CardContent className="p-0 flex flex-col sm:flex-row">
                        <div className="p-4 sm:w-28 bg-muted/20 border-r flex flex-col items-center justify-center text-center shrink-0">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 mb-1.5"
                            onClick={() => toggleSelect(schedule.id)}
                          >
                            {selectedIds.has(schedule.id) ? <CheckSquare className="w-4 h-4 text-primary" /> : <Square className="w-4 h-4" />}
                          </Button>
                          <span className="text-lg font-bold">
                            {config?.timezone
                              ? formatInTimeZone(scheduledDate, config.timezone, 'HH:mm')
                              : format(scheduledDate, 'HH:mm')}
                          </span>
                          {config?.timezone && (
                            <span className="text-[10px] text-muted-foreground mt-0.5">{getTimezoneAbbreviation(config.timezone)}</span>
                          )}
                          <StatusBadge status={schedule.status} className="mt-1.5" />
                          {isOverdue && (
                            <span className="text-[10px] text-amber-500 mt-1 font-medium">Overdue</span>
                          )}
                        </div>

                        <div className="p-4 flex-1 min-w-0">
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h4 className="font-semibold text-base truncate">{schedule.name}</h4>
                                {schedule.recurrence && schedule.recurrence !== 'none' && (
                                  <Badge variant="secondary" className="text-[10px] gap-1 px-1.5 py-0 h-5">
                                    <Repeat className="w-3 h-3" />
                                    {schedule.recurrence}
                                  </Badge>
                                )}
                                {hasSLAs(schedule) && (
                                  <Badge variant="outline" className="text-[10px] gap-1 px-1.5 py-0 h-5 border-blue-500/30 text-blue-500">
                                    <Target className="w-3 h-3" />
                                    SLA
                                  </Badge>
                                )}
                                {config?.isDistributed && (
                                  <Badge variant="outline" className="text-[10px] gap-1 px-1.5 py-0 h-5 border-violet-500/30 text-violet-500">
                                    <Zap className="w-3 h-3" />
                                    Distributed
                                  </Badge>
                                )}
                                {config?.timezone && (
                                  <Badge variant="outline" className="text-[10px] gap-1 px-1.5 py-0 h-5 border-emerald-500/30 text-emerald-500">
                                    <Globe className="w-3 h-3" />
                                    {getTimezoneAbbreviation(config.timezone)}
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center gap-3 mt-1.5 text-sm text-muted-foreground flex-wrap">
                                <span className="truncate max-w-[200px]">
                                  {schedule.script?.name || <span className="italic text-destructive">Script deleted</span>}
                                </span>
                                <span className="text-xs px-1.5 py-0.5 rounded bg-muted font-medium">{config?.environment || "—"}</span>
                                {config?.testTypeName && (
                                  <span className="text-xs text-muted-foreground/70">{config.testTypeName}</span>
                                )}
                                {config?.volume && (
                                  <span className="text-xs text-muted-foreground/70">{config.volume}</span>
                                )}
                              </div>

                              {nextRun && (
                                <div className="mt-1.5 text-xs text-primary/80 flex items-center gap-1">
                                  <Timer className="w-3 h-3" />
                                  Next run: {config?.timezone
                                    ? formatInTimeZone(nextRun, config.timezone, 'MMM d, HH:mm')
                                    : format(nextRun, 'MMM d, HH:mm')}
                                  {config?.timezone && <span className="text-muted-foreground">({getTimezoneAbbreviation(config.timezone)})</span>}
                                  {' '}({formatDistanceToNow(nextRun, { addSuffix: true })})
                                </div>
                              )}

                              {lastExec && (
                                <div className="mt-1.5 flex items-center gap-2 text-xs text-muted-foreground">
                                  <span className="flex items-center gap-1">
                                    <Activity className="w-3 h-3" />
                                    Last run:
                                  </span>
                                  <StatusBadge status={lastExec.status} className="text-[10px] scale-90" />
                                  {lastExec.resultSummary && (
                                    <span className="text-muted-foreground/70">
                                      {(lastExec.resultSummary as any).totalRequests?.toLocaleString() || 0} req, {((lastExec.resultSummary as any).avgResponseTime || 0).toFixed(0)}ms avg
                                    </span>
                                  )}
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-xs h-auto px-1 py-0 text-primary/70 hover:text-primary"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      navigate(`/executions/${lastExec.executionId || lastExec.id}`);
                                    }}
                                  >
                                    <ExternalLink className="w-3 h-3 mr-0.5" />
                                    View
                                  </Button>
                                </div>
                              )}
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              {canWrite && (
                              <TooltipProvider delayDuration={300}>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-8 w-8"
                                      onClick={(e) => { e.stopPropagation(); setEditingSchedule(schedule); }}
                                      title="Edit"
                                    >
                                      <Edit2 className="w-4 h-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Edit schedule</TooltipContent>
                                </Tooltip>

                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-8 w-8"
                                      onClick={(e) => { e.stopPropagation(); cloneSchedule.mutate(schedule.id); }}
                                      title="Clone"
                                    >
                                      <Copy className="w-4 h-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Clone schedule</TooltipContent>
                                </Tooltip>

                                {(schedule.status === 'pending' || schedule.status === 'queued') && (
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        size="icon"
                                        variant="ghost"
                                        className="h-8 w-8 text-destructive hover:text-destructive"
                                        onClick={(e) => { e.stopPropagation(); cancelSchedule.mutate(schedule.id); }}
                                        disabled={cancelSchedule.isPending}
                                      >
                                        <XCircle className="w-4 h-4" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>Cancel schedule</TooltipContent>
                                  </Tooltip>
                                )}

                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-8 w-8 text-destructive/70 hover:text-destructive"
                                      onClick={(e) => { e.stopPropagation(); setDeleteConfirmId(schedule.id); }}
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Delete schedule</TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                              )}

                              {canWrite && <Button
                                size="sm"
                                variant="outline"
                                disabled={isQueueing || schedule.status === 'running' || schedule.status === 'queued' || schedule.status === 'cancelled'}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  queueTest(schedule.id, {
                                    onSuccess: () => toast({ title: "Test queued", description: "Test has been added to the queue" }),
                                    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" })
                                  });
                                }}
                                className="ml-1"
                              >
                                <Play className="w-3 h-3 mr-1" /> Run Now
                              </Button>}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>

      {scheduleTotalPages > 1 && (
        <div className="flex items-center justify-between pt-4 border-t border-border/50" aria-label="Pagination">
          <p className="text-sm text-muted-foreground">
            Showing {((schedulePage - 1) * SCHEDULES_PER_PAGE) + 1}-{Math.min(schedulePage * SCHEDULES_PER_PAGE, filteredSchedules.length)} of {filteredSchedules.length} schedules
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSchedulePage(p => Math.max(1, p - 1))}
              disabled={schedulePage === 1}
            >
              Previous
            </Button>
            {Array.from({ length: Math.min(5, scheduleTotalPages) }, (_, i) => {
              let pageNum: number;
              if (scheduleTotalPages <= 5) {
                pageNum = i + 1;
              } else if (schedulePage <= 3) {
                pageNum = i + 1;
              } else if (schedulePage >= scheduleTotalPages - 2) {
                pageNum = scheduleTotalPages - 4 + i;
              } else {
                pageNum = schedulePage - 2 + i;
              }
              return (
                <Button
                  key={pageNum}
                  variant={schedulePage === pageNum ? "default" : "outline"}
                  size="sm"
                  className="w-8 h-8 p-0"
                  onClick={() => setSchedulePage(pageNum)}
                >
                  {pageNum}
                </Button>
              );
            })}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSchedulePage(p => Math.min(scheduleTotalPages, p + 1))}
              disabled={schedulePage === scheduleTotalPages}
            >
              Next
            </Button>
          </div>
        </div>
      )}

      <AlertDialog open={deleteConfirmId !== null} onOpenChange={(open) => !open && setDeleteConfirmId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Schedule</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this schedule? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleteConfirmId && deleteSchedule.mutate(deleteConfirmId)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={bulkDeleteConfirm} onOpenChange={setBulkDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {selectedIds.size} Schedules</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {selectedIds.size} selected schedule(s)? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => { bulkDelete.mutate(Array.from(selectedIds)); setBulkDeleteConfirm(false); }}
            >
              Delete All
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {editingSchedule && (
        <EditScheduleDialog
          schedule={editingSchedule}
          open={!!editingSchedule}
          setOpen={(open) => !open && setEditingSchedule(null)}
        />
      )}

      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
      </>
      )}
    </div>
  );
}
