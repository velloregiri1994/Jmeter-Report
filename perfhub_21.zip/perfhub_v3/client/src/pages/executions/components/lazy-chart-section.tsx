import React, { useRef, useState, useEffect } from "react";

interface LazyChartSectionProps {
  children: React.ReactNode;
  minHeight?: number;
}

export function LazyChartSection({ children, minHeight = 200 }: LazyChartSectionProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(() => typeof IntersectionObserver === "undefined");

  useEffect(() => {
    if (isVisible) return;
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { rootMargin: "200px" }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [isVisible]);

  if (!isVisible) {
    return <div ref={ref} style={{ minHeight }} />;
  }

  return <div ref={ref}>{children}</div>;
}
