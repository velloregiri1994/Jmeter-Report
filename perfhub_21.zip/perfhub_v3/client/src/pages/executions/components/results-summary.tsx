export function ResultBox({ label, value, color, gradient }: { label: string, value: string, color?: string, gradient?: string }) {
   return (
      <div className={`p-4 rounded-xl border text-center ${gradient || 'bg-muted/30'}`}>
         <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground/70 mb-1.5">{label}</div>
         <div className={`text-xl font-bold ${color || 'text-foreground'}`}>{value}</div>
      </div>
   );
}

export function formatSlaMetric(metric: string): string {
  const labels: Record<string, string> = {
    avg: "Avg Response",
    p90: "P90",
    p95: "P95",
    p99: "P99",
    max: "Max Response",
    errorRate: "Error Rate",
    throughput: "Throughput",
  };
  return labels[metric] || metric;
}

export function formatComparator(comp: string): string {
  const symbols: Record<string, string> = { lt: "<", lte: "≤", gt: ">", gte: "≥" };
  return symbols[comp] || comp;
}

export function getMetricUnit(metric: string): string {
  if (metric === "errorRate") return "%";
  if (metric === "throughput") return "/s";
  return "ms";
}
