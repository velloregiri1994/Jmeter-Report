import React, { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { BarChart2, ChevronDown, ChevronRight } from "lucide-react";
import { toPercent } from "./detail-utils";

export function BreakdownBar({ label, value, total, color }: { label: string; value: number; total: number; color: string }) {
  const pct = total > 0 ? Math.min((value / total) * 100, 100) : 0;
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs text-muted-foreground w-36 shrink-0">{label}</span>
      <div className="flex-1 h-5 bg-muted/30 rounded-full overflow-hidden">
        <div className={`h-full ${color} rounded-full transition-all`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-semibold w-20 text-right">{value.toFixed(0)} ms ({pct.toFixed(1)}%)</span>
    </div>
  );
}

export function TransactionDetailsTable({ results }: { results: any }) {
  const [expandedTx, setExpandedTx] = useState<number | null>(null);

  if (!results?.transactionDetails || results.transactionDetails.length === 0) return null;

  return (
    <Card className="card-shadow overflow-hidden">
      <CardHeader className="bg-muted/30 border-b">
        <CardTitle className="flex items-center gap-2 text-base">
          <BarChart2 className="w-5 h-5 text-primary" />
          Transaction Details
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto rounded-xl border border-border/60 bg-card">
          <table className="w-full text-sm text-left">
            <thead className="bg-muted/50 text-muted-foreground font-bold text-xs uppercase tracking-wider">
              <tr>
                <th className="px-4 py-3">Transaction</th>
                <th className="px-4 py-3">Count</th>
                <th className="px-4 py-3">Avg (ms)</th>
                <th className="px-4 py-3">P50 (ms)</th>
                <th className="px-4 py-3">P90 (ms)</th>
                <th className="px-4 py-3">P95 (ms)</th>
                <th className="px-4 py-3">P99 (ms)</th>
                <th className="px-4 py-3">Max (ms)</th>
                <th className="px-4 py-3">Throughput</th>
                <th className="px-4 py-3">Error %</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40">
              {results.transactionDetails.map((tx: any, idx: number) => (
                <React.Fragment key={idx}>
                  <tr 
                    className="hover:bg-muted/30 transition-colors cursor-pointer"
                    onClick={() => setExpandedTx(expandedTx === idx ? null : idx)}
                  >
                    <td className="px-4 py-3 font-semibold text-foreground flex items-center gap-1.5">
                      {expandedTx === idx ? <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" /> : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />}
                      {tx.label}
                    </td>
                    <td className="px-4 py-3">{tx.count || 0}</td>
                    <td className="px-4 py-3">{Math.floor(tx.avg || 0)}</td>
                    <td className="px-4 py-3">{Math.floor(tx.p50 ?? 0)}</td>
                    <td className="px-4 py-3">{Math.floor(tx.p90 ?? 0)}</td>
                    <td className="px-4 py-3">{Math.floor(tx.p95 ?? 0)}</td>
                    <td className="px-4 py-3">{Math.floor(tx.p99 ?? 0)}</td>
                    <td className="px-4 py-3">{Math.floor(tx.max ?? 0)}</td>
                    <td className="px-4 py-3">{tx.throughput ? `${tx.throughput.toFixed(2)}/s` : '-'}</td>
                    <td className="px-4 py-3 font-medium text-red-500">{toPercent(tx.errorRate).toFixed(2)}%</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        toPercent(tx.errorRate) < 2 
                          ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' 
                          : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                      }`}>
                        {toPercent(tx.errorRate) < 2 ? 'PASS' : 'FAIL'}
                      </span>
                    </td>
                  </tr>
                  {expandedTx === idx && (
                    <tr className="bg-muted/10">
                      <td colSpan={11} className="px-4 py-4">
                        <div className="max-w-lg">
                          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Response Time Breakdown</p>
                          <div className="space-y-2.5">
                            <BreakdownBar 
                              label="Connect" 
                              value={tx.avgConnect || 0} 
                              total={tx.avg || 1} 
                              color="bg-blue-500" 
                            />
                            <BreakdownBar 
                              label="Processing & Transfer" 
                              value={tx.avgLatency || (tx.avg - (tx.avgConnect || 0)) || 0} 
                              total={tx.avg || 1} 
                              color="bg-emerald-500" 
                            />
                          </div>
                          {(tx.p50Connect !== undefined) && (
                            <div className="mt-3 grid grid-cols-3 gap-3 text-xs">
                              <div className="p-2 rounded bg-muted/30">
                                <span className="text-muted-foreground">P50 Connect</span>
                                <p className="font-semibold">{(tx.p50Connect || 0).toFixed(0)} ms</p>
                              </div>
                              <div className="p-2 rounded bg-muted/30">
                                <span className="text-muted-foreground">P90 Connect</span>
                                <p className="font-semibold">{(tx.p90Connect || 0).toFixed(0)} ms</p>
                              </div>
                              <div className="p-2 rounded bg-muted/30">
                                <span className="text-muted-foreground">P95 Connect</span>
                                <p className="font-semibold">{(tx.p95Connect || 0).toFixed(0)} ms</p>
                              </div>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
