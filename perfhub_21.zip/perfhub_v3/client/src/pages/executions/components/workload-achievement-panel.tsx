import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Target, CheckCircle2, AlertTriangle, XCircle, Loader2, Lightbulb, TrendingDown, TrendingUp, ChevronDown, ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";

interface MetricComparison {
  metric: string;
  label: string;
  target: number;
  actual: number;
  unit: string;
  achieved: boolean;
  deviationPercent: number;
}

interface DiagnosticFinding {
  category: string;
  severity: "info" | "warning" | "critical";
  title: string;
  detail: string;
  metric?: string;
  targetValue?: number;
  actualValue?: number;
  deviation?: number;
}

interface PerTransactionResult {
  name: string;
  targetTph: number;
  actualTph: number;
  achieved: boolean;
  deviationPercent: number;
}

interface AchievementResult {
  verdict: "achieved" | "partially_achieved" | "not_achieved";
  comparisons: MetricComparison[];
  findings: DiagnosticFinding[];
  suggestions: string[];
  perTransaction?: PerTransactionResult[];
}

interface AchievementResponse {
  available: boolean;
  source?: "script" | "execution";
  result?: AchievementResult;
}

const VERDICT_CONFIG = {
  achieved: {
    label: "Targets Achieved",
    color: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300",
    border: "border-l-emerald-500",
    gradient: "from-emerald-500/5 via-emerald-500/2 to-transparent",
    icon: CheckCircle2,
    iconColor: "text-emerald-500",
  },
  partially_achieved: {
    label: "Partially Achieved",
    color: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
    border: "border-l-amber-500",
    gradient: "from-amber-500/5 via-amber-500/2 to-transparent",
    icon: AlertTriangle,
    iconColor: "text-amber-500",
  },
  not_achieved: {
    label: "Targets Not Achieved",
    color: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
    border: "border-l-red-500",
    gradient: "from-red-500/5 via-red-500/2 to-transparent",
    icon: XCircle,
    iconColor: "text-red-500",
  },
};

const SEVERITY_STYLES = {
  critical: {
    bg: "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800",
    icon: "text-red-500",
    badge: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  },
  warning: {
    bg: "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800",
    icon: "text-amber-500",
    badge: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  },
  info: {
    bg: "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800",
    icon: "text-blue-500",
    badge: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
  },
};

export function WorkloadAchievementPanel({ executionId }: { executionId: number }) {
  const [expandDiagnostics, setExpandDiagnostics] = useState(true);
  const [expandTransactions, setExpandTransactions] = useState(false);

  const { data, isLoading, error } = useQuery<AchievementResponse>({
    queryKey: ["workload-achievement", executionId],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", `/api/executions/${executionId}/workload-achievement`);
        return res.json();
      } catch {
        return { available: false };
      }
    },
    staleTime: 5 * 60 * 1000,
    retry: false,
  });

  if (isLoading) {
    return (
      <Card className="card-shadow border-l-4 border-l-primary overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-primary/5 via-primary/2 to-transparent border-b">
          <CardTitle className="flex items-center gap-2 text-base">
            <Target className="w-5 h-5 text-primary" />
            Workload Achievement
            <Loader2 className="w-4 h-4 animate-spin ml-2 text-muted-foreground" />
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="space-y-2">
            <Skeleton className="h-12 w-full rounded-lg" />
            <Skeleton className="h-20 w-full rounded-lg" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error || !data?.available || !data.result) return null;

  const { result, source } = data;
  const config = VERDICT_CONFIG[result.verdict];
  const VerdictIcon = config.icon;

  return (
    <Card className={`card-shadow border-l-4 ${config.border} overflow-hidden`}>
      <CardHeader className={`bg-gradient-to-r ${config.gradient} border-b`}>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <Target className={`w-5 h-5 ${config.iconColor}`} />
            Workload Achievement
          </CardTitle>
          <div className="flex items-center gap-2">
            {source && (
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                {source === "script" ? "Script Targets" : "Execution Targets"}
              </span>
            )}
            <Badge className={config.color}>
              <VerdictIcon className="w-3.5 h-3.5 mr-1" />
              {config.label}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-4 space-y-4">
        {result.comparisons.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Metric</th>
                  <th className="text-right py-2 px-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Target</th>
                  <th className="text-right py-2 px-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Actual</th>
                  <th className="text-right py-2 px-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Deviation</th>
                  <th className="text-center py-2 px-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {result.comparisons.map((c) => (
                  <tr key={c.metric} className="border-b last:border-b-0 hover:bg-muted/30 transition-colors">
                    <td className="py-2.5 px-3 font-medium">{c.label}</td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-muted-foreground">
                      {c.target.toLocaleString()} {c.unit}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-medium">
                      {c.actual.toLocaleString()} {c.unit}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums">
                      <span className={`inline-flex items-center gap-1 ${c.deviationPercent > 0 ? (c.achieved ? "text-emerald-600" : "text-red-600") : (c.achieved ? "text-emerald-600" : "text-red-600")}`}>
                        {c.deviationPercent > 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        {c.deviationPercent > 0 ? "+" : ""}{c.deviationPercent}%
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {c.achieved ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 mx-auto" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-500 mx-auto" />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {result.perTransaction && result.perTransaction.length > 0 && (
          <div>
            <button
              className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors mb-2"
              onClick={() => setExpandTransactions(!expandTransactions)}
            >
              {expandTransactions ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              Per-Transaction Breakdown ({result.perTransaction.length})
            </button>
            {expandTransactions && (
              <div className="overflow-x-auto border rounded-lg">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/30">
                      <th className="text-left py-2 px-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Transaction</th>
                      <th className="text-right py-2 px-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Target TPH</th>
                      <th className="text-right py-2 px-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Actual TPH</th>
                      <th className="text-right py-2 px-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Deviation</th>
                      <th className="text-center py-2 px-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.perTransaction.map((t) => (
                      <tr key={t.name} className="border-b last:border-b-0">
                        <td className="py-2 px-3 font-medium">{t.name}</td>
                        <td className="py-2 px-3 text-right tabular-nums text-muted-foreground">{t.targetTph.toLocaleString()}</td>
                        <td className="py-2 px-3 text-right tabular-nums font-medium">{t.actualTph.toLocaleString()}</td>
                        <td className="py-2 px-3 text-right tabular-nums">
                          <span className={t.achieved ? "text-emerald-600" : "text-red-600"}>
                            {t.deviationPercent > 0 ? "+" : ""}{t.deviationPercent}%
                          </span>
                        </td>
                        <td className="py-2 px-3 text-center">
                          {t.achieved ? <CheckCircle2 className="w-4 h-4 text-emerald-500 mx-auto" /> : <XCircle className="w-4 h-4 text-red-500 mx-auto" />}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {result.findings.length > 0 && (
          <div>
            <button
              className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors mb-2"
              onClick={() => setExpandDiagnostics(!expandDiagnostics)}
            >
              {expandDiagnostics ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              Diagnostics ({result.findings.length})
            </button>
            {expandDiagnostics && (
              <div className="space-y-2">
                {result.findings.map((f, i) => {
                  const style = SEVERITY_STYLES[f.severity];
                  return (
                    <div key={i} className={`rounded-lg border p-3 ${style.bg}`}>
                      <div className="flex items-start gap-2">
                        <AlertTriangle className={`w-4 h-4 mt-0.5 flex-shrink-0 ${style.icon}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-sm font-semibold">{f.title}</span>
                            <span className={`text-[10px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded ${style.badge}`}>
                              {f.severity}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground leading-relaxed">{f.detail}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {result.suggestions.length > 0 && (
          <div className="bg-primary/5 rounded-lg border border-primary/10 p-3">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="w-4 h-4 text-primary" />
              <span className="text-sm font-semibold">Suggestions</span>
            </div>
            <ul className="space-y-1.5">
              {result.suggestions.map((s, i) => (
                <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                  <span className="text-primary mt-0.5 flex-shrink-0">•</span>
                  <span>{s}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
