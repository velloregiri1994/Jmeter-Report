import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { XCircle } from "lucide-react";
import { format } from "date-fns";

export function ErrorDetailsTable({ results }: { results: any }) {
  if (!results?.errorDetails || results.errorDetails.length === 0) return null;

  return (
    <Card className="card-shadow overflow-hidden border-red-200 dark:border-red-800/50">
      <CardHeader className="bg-rose-500/5 border-b border-red-200 dark:border-red-800/50">
        <CardTitle className="flex items-center gap-2 text-base text-red-600 dark:text-red-400">
          <XCircle className="w-5 h-5" />
          Error Details
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto rounded-xl border border-red-200 dark:border-red-800/50 bg-card">
          <table className="w-full text-sm text-left">
            <thead className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 font-bold text-xs uppercase tracking-wider">
              <tr>
                <th className="px-4 py-3">Transaction</th>
                <th className="px-4 py-3">Error Message</th>
                <th className="px-4 py-3">Status Code</th>
                <th className="px-4 py-3">Count</th>
                <th className="px-4 py-3">Error %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-red-100 dark:divide-red-800/30">
              {results.errorDetails.map((error: any, idx: number) => (
                <tr key={idx} className="hover:bg-red-50/50 dark:hover:bg-red-900/10 transition-colors">
                  <td className="px-4 py-3 font-semibold">{error.label || error.transaction || 'Unknown'}</td>
                  <td className="px-4 py-3 text-red-600 dark:text-red-400">{error.response_message || error.message || 'Unknown error'}</td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-1 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 rounded text-xs font-mono">
                      {error.response_code || error.statusCode || 'N/A'}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-medium">{error.count || 1}</td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {error.pct !== undefined ? `${(error.pct * 100).toFixed(1)}%` : (error.timestamp ? format(new Date(error.timestamp), "HH:mm:ss") : 'N/A')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
