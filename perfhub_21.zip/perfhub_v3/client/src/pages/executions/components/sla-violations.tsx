import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";
import { formatSlaMetric, formatComparator, getMetricUnit } from "./results-summary";

export function SlaViolationsCard({ slaViolations }: { slaViolations: { perTransaction?: Array<{ label: string; metric: string; threshold: number; actual: number; comparator: string }> } | null }) {
  if (!slaViolations?.perTransaction || slaViolations.perTransaction.length === 0) return null;

  return (
    <Card className="border-amber-500/50 bg-amber-50 dark:bg-amber-900/10">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-amber-700 dark:text-amber-400">
          <AlertTriangle className="w-5 h-5" />
          SLA Violations Detected ({slaViolations.perTransaction.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {slaViolations.perTransaction.map((violation, idx) => (
            <div key={idx} className="flex items-center justify-between p-3 bg-white dark:bg-background rounded-lg border border-amber-200 dark:border-amber-800">
              <div>
                <div className="text-xs uppercase text-muted-foreground font-bold">{violation.label}</div>
                <div className="text-sm text-muted-foreground mt-1">
                  {formatSlaMetric(violation.metric)} {formatComparator(violation.comparator)} {violation.threshold}{getMetricUnit(violation.metric)}
                </div>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-red-600">{typeof violation.actual === 'number' ? violation.actual.toFixed(2) : violation.actual}{getMetricUnit(violation.metric)}</div>
                <div className="text-xs text-muted-foreground">Actual</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
