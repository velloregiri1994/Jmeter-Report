import React from "react";

interface MetricConfig {
  key: string;
  label: string;
  unit?: string;
  color: string;
  decimals?: number;
}

interface GrafanaTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
  metrics: MetricConfig[];
}

export function GrafanaTooltip({ active, payload, label, metrics }: GrafanaTooltipProps) {
  if (!active || !payload?.length) return null;
  const data = payload[0]?.payload;
  if (!data) return null;

  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-xl text-xs min-w-[180px]">
      <div className="px-3 py-1.5 border-b bg-muted/40 flex items-center justify-between gap-4">
        <span className="font-medium">{data.time}</span>
        {data.absoluteTime && (
          <span className="text-muted-foreground">{data.absoluteTime}</span>
        )}
      </div>
      <div className="px-3 py-1.5 space-y-1">
        {metrics.map((m) => {
          const raw = data[m.key];
          if (raw === undefined || raw === null) return null;
          const val = m.decimals !== undefined ? Number(raw).toFixed(m.decimals) : Math.floor(raw);
          return (
            <div key={m.key} className="flex items-center justify-between gap-6">
              <span className="flex items-center gap-1.5">
                <span className="inline-block w-2.5 h-[3px] rounded-full" style={{ backgroundColor: m.color }} />
                <span className="text-muted-foreground">{m.label}</span>
              </span>
              <span className="font-mono font-medium tabular-nums">
                {val}{m.unit ? ` ${m.unit}` : ''}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
