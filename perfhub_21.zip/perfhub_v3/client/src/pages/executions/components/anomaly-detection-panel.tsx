import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Activity, AlertTriangle, CheckCircle, ChevronDown, ChevronRight, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const CATEGORY_ICONS: Record<string, string> = {
  baseline_deviation: "📊",
  tail_latency_spread: "📈",
  throughput_saturation: "🔥",
  error_step_change: "🔴",
  transaction_regression: "🐌",
  time_window_hotspot: "🎯",
  throughput_drop: "📉",
  gradual_degradation: "📉",
};

const CATEGORY_LABELS: Record<string, string> = {
  baseline_deviation: "Baseline Deviation",
  tail_latency_spread: "Tail Latency",
  throughput_saturation: "Saturation",
  error_step_change: "Error Rate",
  transaction_regression: "Transaction Regression",
  time_window_hotspot: "Response Time Spike",
  throughput_drop: "Throughput Drop",
  gradual_degradation: "Gradual Degradation",
};

export function AnomalyDetectionPanel({ executionId, isLive = false }: { executionId: number; isLive?: boolean }) {
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [filterSeverity, setFilterSeverity] = useState<"all" | "critical" | "warning" | "info">("all");

  const { data: anomalyResult, isLoading, error } = useQuery({
    queryKey: ["anomaly-detection", executionId],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", `/api/executions/${executionId}/anomaly-detection`);
        return res.json();
      } catch (err: any) {
        if (err?.message?.includes("400")) return null;
        throw err;
      }
    },
    staleTime: isLive ? 30 * 1000 : 5 * 60 * 1000,
    refetchInterval: isLive ? 30 * 1000 : false,
    retry: false,
  });

  if (isLoading) {
    return (
      <Card className="card-shadow border-l-4 border-l-violet-500 overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-violet-500/5 via-violet-500/2 to-transparent border-b">
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="w-5 h-5 text-violet-500" />
            Anomaly Detection
            <Loader2 className="w-4 h-4 animate-spin ml-2 text-muted-foreground" />
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="space-y-2">
            <Skeleton className="h-16 w-full rounded-lg" />
            <Skeleton className="h-16 w-full rounded-lg" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error || !anomalyResult) return null;

  const { healthScore, overallVerdict, anomalies, summary, baselineUsed } = anomalyResult;
  if (!anomalies || anomalies.length === 0) {
    return (
      <Card className="card-shadow border-l-4 border-l-emerald-500 overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-emerald-500/5 via-emerald-500/2 to-transparent border-b">
          <CardTitle className="flex items-center gap-2 text-base">
            <CheckCircle className="w-5 h-5 text-emerald-500" />
            Anomaly Detection
            <span className="ml-auto flex items-center gap-2">
              <span className="text-xs font-normal text-muted-foreground">Health Score</span>
              <span className="text-lg font-bold text-emerald-600">{healthScore}</span>
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <p className="text-sm text-muted-foreground">No anomalies detected. All metrics are within normal ranges{baselineUsed ? " and consistent with baseline" : ""}.</p>
        </CardContent>
      </Card>
    );
  }

  const verdictColors = {
    healthy: "border-l-emerald-500",
    degraded: "border-l-amber-500",
    critical: "border-l-red-500",
  };

  const healthColors = healthScore >= 80 ? "text-emerald-600" : healthScore >= 50 ? "text-amber-600" : "text-red-600";

  const filtered = filterSeverity === "all" ? anomalies : anomalies.filter((a: any) => a.severity === filterSeverity);

  const toggleExpanded = (id: string) => {
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <Card className={`card-shadow border-l-4 ${verdictColors[overallVerdict as keyof typeof verdictColors] || verdictColors.degraded} overflow-hidden`}>
      <CardHeader className="bg-gradient-to-r from-violet-500/5 via-violet-500/2 to-transparent border-b pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Activity className="w-5 h-5 text-violet-500" />
          Anomaly Detection
          <div className="flex items-center gap-1.5 ml-2">
            {summary.critical > 0 && <Badge variant="destructive" className="text-[10px] px-1.5 py-0">{summary.critical} critical</Badge>}
            {summary.warning > 0 && <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-amber-400 text-amber-600">{summary.warning} warning</Badge>}
            {summary.info > 0 && <Badge variant="outline" className="text-[10px] px-1.5 py-0">{summary.info} info</Badge>}
          </div>
          <span className="ml-auto flex items-center gap-2">
            {baselineUsed && <Badge variant="outline" className="text-[10px]">vs baseline</Badge>}
            <span className="text-xs font-normal text-muted-foreground">Health</span>
            <span className={`text-lg font-bold ${healthColors}`}>{healthScore}</span>
          </span>
        </CardTitle>
        <div className="flex items-center gap-1.5 mt-2">
          {(["all", "critical", "warning", "info"] as const).map(sev => (
            <button
              key={sev}
              onClick={() => setFilterSeverity(sev)}
              className={`text-[10px] px-2 py-0.5 rounded-full font-medium transition-colors ${
                filterSeverity === sev
                  ? sev === "critical" ? "bg-red-500 text-white"
                    : sev === "warning" ? "bg-amber-500 text-white"
                    : sev === "info" ? "bg-blue-500 text-white"
                    : "bg-primary text-primary-foreground"
                  : "bg-muted/60 text-muted-foreground hover:bg-muted"
              }`}
            >
              {sev === "all" ? `All (${summary.total})` : `${sev} (${summary[sev as keyof typeof summary] || 0})`}
            </button>
          ))}
        </div>
      </CardHeader>
      <CardContent className="pt-3 pb-3">
        <div className="space-y-2">
          {filtered.map((anomaly: any) => {
            const isExpanded = expandedIds.has(anomaly.id);
            const severityStyles = {
              critical: "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800/40",
              warning: "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800/40",
              info: "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800/40",
            };
            const severityText = {
              critical: "text-red-700 dark:text-red-400",
              warning: "text-amber-700 dark:text-amber-400",
              info: "text-blue-700 dark:text-blue-400",
            };
            const severityBadge = {
              critical: "bg-red-200 dark:bg-red-800/50 text-red-700 dark:text-red-300",
              warning: "bg-amber-200 dark:bg-amber-800/50 text-amber-700 dark:text-amber-300",
              info: "bg-blue-200 dark:bg-blue-800/50 text-blue-700 dark:text-blue-300",
            };

            return (
              <div
                key={anomaly.id}
                className={`rounded-lg border transition-all ${severityStyles[anomaly.severity as keyof typeof severityStyles] || severityStyles.info}`}
              >
                <button
                  onClick={() => toggleExpanded(anomaly.id)}
                  className="w-full flex items-start gap-2.5 p-3 text-left"
                >
                  <span className="text-base shrink-0 mt-0.5">{CATEGORY_ICONS[anomaly.category] || "⚠️"}</span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                      <span className={`font-semibold text-sm ${severityText[anomaly.severity as keyof typeof severityText]}`}>
                        {anomaly.title}
                      </span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium uppercase ${severityBadge[anomaly.severity as keyof typeof severityBadge]}`}>
                        {anomaly.severity}
                      </span>
                      <span className="text-[10px] text-muted-foreground bg-muted/60 px-1.5 py-0.5 rounded font-mono">
                        {anomaly.confidence}% confidence
                      </span>
                      <Badge variant="outline" className="text-[10px] px-1 py-0">
                        {CATEGORY_LABELS[anomaly.category] || anomaly.category}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{anomaly.description}</p>
                  </div>
                  {isExpanded ? <ChevronDown className="w-4 h-4 shrink-0 mt-1 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 shrink-0 mt-1 text-muted-foreground" />}
                </button>

                {isExpanded && (
                  <div className="px-3 pb-3 pt-0 border-t border-border/30 mt-0">
                    <div className="mt-2 space-y-2">
                      {anomaly.evidence && anomaly.evidence.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {anomaly.evidence.map((ev: any, ei: number) => (
                            <div key={ei} className="flex items-center gap-1 text-[10px] bg-muted/60 px-2 py-1 rounded-md font-mono">
                              <span className="text-muted-foreground">{ev.metric}:</span>
                              <span className="font-semibold">{ev.current}{ev.unit}</span>
                              {ev.baseline != null && (
                                <span className="text-muted-foreground">(baseline: {ev.baseline}{ev.unit})</span>
                              )}
                              {ev.pctChange != null && (
                                <span className={ev.pctChange > 0 ? "text-red-600" : "text-emerald-600"}>
                                  {ev.pctChange > 0 ? "+" : ""}{ev.pctChange}%
                                </span>
                              )}
                              {ev.zScore != null && (
                                <span className="text-muted-foreground">z={ev.zScore}</span>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                      {anomaly.recommendation && (
                        <div className="flex items-start gap-2 p-2 rounded-md bg-muted/30 border border-border/40">
                          <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-500" />
                          <p className="text-[11px] text-muted-foreground leading-relaxed">{anomaly.recommendation}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
