import { useState, useEffect, useCallback, useRef } from "react";
import { useWebSocket, type LiveMetricsSnapshot } from "@/hooks/use-websocket";

const STALE_THRESHOLD_MS = 10000;
const POLL_INTERVAL_MS = 3000;
const POLL_BACKOFF_MAX_MS = 10000;

interface FetchResult {
  active: boolean;
  snapshot: LiveMetricsSnapshot | null;
  warning: string | null;
}

function fetchSnapshot(executionId: number): Promise<FetchResult> {
  return fetch(`/api/executions/${executionId}/live-metrics`)
    .then((res) => res.json())
    .catch(() => ({ active: false, snapshot: null, warning: null }));
}

export function useLiveSnapshot(executionId: number, enabled: boolean) {
  const [snapshot, setSnapshot] = useState<LiveMetricsSnapshot | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [isStale, setIsStale] = useState(false);
  const wsReceivedRef = useRef(false);
  const pollTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pollAttemptsRef = useRef(0);
  const staleTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const applySnapshot = useCallback((data: FetchResult) => {
    if (data.active && data.snapshot) {
      setSnapshot(data.snapshot);
      setLastUpdate(new Date());
      setIsStale(false);
    }
  }, []);

  const startPolling = useCallback(() => {
    if (pollTimerRef.current) clearTimeout(pollTimerRef.current);
    const poll = () => {
      if (wsReceivedRef.current) return;
      fetchSnapshot(executionId).then((data) => {
        applySnapshot(data);
        if (data.active && data.snapshot) {
          pollAttemptsRef.current = 0;
        } else {
          pollAttemptsRef.current++;
        }
        if (!wsReceivedRef.current) {
          const delay = Math.min(POLL_INTERVAL_MS + pollAttemptsRef.current * 1000, POLL_BACKOFF_MAX_MS);
          pollTimerRef.current = setTimeout(poll, delay);
        }
      });
    };
    pollTimerRef.current = setTimeout(poll, POLL_INTERVAL_MS);
  }, [executionId, applySnapshot]);

  useEffect(() => {
    if (!enabled) return;
    wsReceivedRef.current = false;
    pollAttemptsRef.current = 0;
    fetchSnapshot(executionId).then(applySnapshot);
    startPolling();
    return () => {
      if (pollTimerRef.current) clearTimeout(pollTimerRef.current);
    };
  }, [executionId, enabled, applySnapshot, startPolling]);

  useEffect(() => {
    if (!enabled) return;
    staleTimerRef.current = setInterval(() => {
      if (lastUpdate) {
        const elapsed = Date.now() - lastUpdate.getTime();
        if (elapsed > STALE_THRESHOLD_MS) {
          setIsStale(true);
          if (wsReceivedRef.current) {
            wsReceivedRef.current = false;
            pollAttemptsRef.current = 0;
            startPolling();
          }
        } else {
          setIsStale(false);
        }
      }
    }, 2000);
    return () => {
      if (staleTimerRef.current) clearInterval(staleTimerRef.current);
    };
  }, [enabled, lastUpdate, startPolling]);

  useWebSocket({
    onLiveMetrics: useCallback((data: { executionId: number; snapshot: LiveMetricsSnapshot }) => {
      if (data.executionId === executionId && enabled) {
        wsReceivedRef.current = true;
        setSnapshot(data.snapshot);
        setLastUpdate(new Date());
        setIsStale(false);
      }
    }, [executionId, enabled]),
    enabled,
  });

  return { snapshot, lastUpdate, isStale };
}
