import type { LiveMetricsSnapshot } from "@/hooks/use-websocket";

export interface NormalizedPoint {
  time: string;
  elapsed: number;
  sec: number;
  rps: number;
  avgMs: number;
  p50Ms: number;
  p90Ms: number;
  p95Ms: number;
  p99Ms: number;
  activeThreads: number;
  errors: number;
  errorRate: number;
  errorsPerSec: number;
}

export interface SystemDataPoint {
  time: string;
  elapsed: number;
  cpuPercent: number;
  memPercent: number;
  memUsedMb?: number;
  diskReadMbps: number;
  diskWriteMbps: number;
  jmeterCpu: number;
  jmeterMemMB: number;
}

export interface UnifiedChartsProps {
  results: Record<string, any>;
  systemMetrics: Record<string, any> | null;
  liveSnapshot: LiveMetricsSnapshot | null;
  isLive: boolean;
  executionId: number;
}

export interface ChartSectionProps {
  data: NormalizedPoint[];
  rampUpLabel: string | null;
  showBrush: boolean;
  brushHeight: number;
  collapsedCharts: Record<string, boolean>;
  chartSizes: Record<string, "compact" | "expanded">;
  isCollapsed: (key: string) => boolean;
  toggleChart: (key: string) => void;
  getSize: (key: string) => "compact" | "expanded";
  setChartSize: (key: string, s: "compact" | "expanded") => void;
}
