import { Skeleton } from "@/components/ui/skeleton";

export function filterTimeseriesClientSide(fullResults: any, startMs: number, endMs: number) {
  if (!fullResults?.timeseries?.length) return null;
  const ts = fullResults.timeseries;
  const isRemote = ts[0]?.t !== undefined;

  const getPointMs = (p: any) => isRemote ? (p.t || 0) : (p.sec || 0) * 1000;
  const clampedStart = Math.max(startMs, getPointMs(ts[0]));
  const clampedEnd = Math.min(endMs, getPointMs(ts[ts.length - 1]));

  const filtered = ts.filter((p: any) => {
    const pointMs = getPointMs(p);
    return pointMs >= clampedStart && pointMs <= clampedEnd;
  });

  if (filtered.length === 0) return null;

  const totalBuckets = ts.length;
  const bucketCount = filtered.length;

  let bucketIntervalSec = 5;
  if (filtered.length >= 2) {
    const t0 = getPointMs(filtered[0]);
    const t1 = getPointMs(filtered[1]);
    bucketIntervalSec = Math.max(1, (t1 - t0) / 1000);
  }

  const durationSeconds = Math.max(1, (clampedEnd - clampedStart) / 1000);

  let totalRequests = 0;
  let totalErrors = 0;
  let sumRT = 0;
  let minRT = Infinity;
  let maxRT = -Infinity;

  for (const p of filtered) {
    const rps = isRemote ? (p.throughput || 0) : (p.rps || 0);
    const avgMs = isRemote ? (p.avgRT || 0) : (p.avg_ms || 0);
    const errors = p.errors || 0;
    const bucketRequests = Math.round(rps * bucketIntervalSec);
    totalRequests += bucketRequests;
    totalErrors += errors;
    sumRT += avgMs * bucketRequests;
    if (avgMs > 0 && avgMs < minRT) minRT = avgMs;
    if (avgMs > maxRT) maxRT = avgMs;
  }

  const avgResponseTime = totalRequests > 0 ? sumRT / totalRequests : 0;
  const errorRate = totalRequests > 0 ? Math.round((totalErrors / totalRequests) * 10000) / 100 : 0;
  const ratio = totalBuckets > 0 ? bucketCount / totalBuckets : 1;

  const transactionDetails = fullResults.transactionDetails?.map((tx: any) => {
    const estCount = Math.round((tx.count || 0) * ratio);
    const estErrors = Math.round((tx.errorCount || 0) * ratio);
    return {
      label: tx.label,
      count: estCount,
      avg: tx.avg || 0,
      min: tx.min || 0,
      max: tx.max || 0,
      p50: tx.p50 || 0,
      p90: tx.p90 || 0,
      p95: tx.p95 || 0,
      p99: tx.p99 || 0,
      errorRate: tx.errorRate || 0,
      errorCount: estErrors,
      throughput: estCount / durationSeconds,
    };
  });

  return {
    summary: {
      totalRequests,
      errorCount: totalErrors,
      errorRate,
      avgResponseTime,
      minResponseTime: minRT === Infinity ? 0 : minRT,
      maxResponseTime: maxRT === -Infinity ? 0 : maxRT,
      throughput: totalRequests / durationSeconds,
      p50: 0,
      p90: 0,
      p95: 0,
      p99: 0,
      durationSeconds,
    },
    transactionDetails,
    timeseries: filtered,
    startTime: clampedStart,
    endTime: clampedEnd,
    bucketCount,
    totalBuckets,
  };
}

export function toPercent(rate?: number | null): number {
  const v = rate || 0;
  return v <= 1 ? v * 100 : v;
}

export function parseStartTimeToSec(startTime?: any): number | null {
  if (!startTime) return null;
  if (typeof startTime === 'number') return Math.floor(startTime / 1000);
  if (typeof startTime === 'string') {
    const ms = new Date(startTime).getTime();
    return isNaN(ms) ? null : Math.floor(ms / 1000);
  }
  return null;
}

export function formatElapsedLabel(elapsedSec: number): string {
  const totalSec = Math.max(0, Math.round(elapsedSec));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function formatAbsoluteTime(epochSec: number): string {
  const d = new Date(epochSec * 1000);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
}

export function formatTimeseriesData(timeseries: any[], startTime?: any) {
  if (!timeseries || timeseries.length === 0) return [];
  const isRemoteFormat = timeseries[0]?.t !== undefined && timeseries[0]?.sec === undefined;
  const firstSec = isRemoteFormat
    ? Math.floor((timeseries[0]?.t || 0) / 1000)
    : timeseries[0]?.sec || 0;
  const baseTime = parseStartTimeToSec(startTime) ?? firstSec;
  return timeseries.map((point) => {
    if (isRemoteFormat) {
      const sec = Math.floor((point.t || 0) / 1000);
      const elapsed = sec - baseTime;
      const rps = point.throughput || 0;
      const errorRate = point.errorRate || 0;
      const errors = point.errors != null ? point.errors : (rps > 0 ? Math.round(rps * errorRate / 100) : 0);
      return {
        time: formatElapsedLabel(elapsed),
        absoluteTime: formatAbsoluteTime(sec),
        elapsed,
        sec,
        rps,
        avgMs: point.avgRT || 0,
        p95Ms: point.p95 || 0,
        activeThreads: point.activeThreads || 0,
        errors,
        errorRate,
      };
    }
    const elapsed = point.sec - baseTime;
    return {
      time: formatElapsedLabel(elapsed),
      absoluteTime: formatAbsoluteTime(point.sec),
      elapsed,
      sec: point.sec,
      rps: point.rps || 0,
      avgMs: point.avg_ms || 0,
      p95Ms: point.p95 || 0,
      activeThreads: point.active_threads || 0,
      errors: point.errors || 0,
      errorRate: point.rps > 0 ? Math.round((point.errors / point.rps) * 10000) / 100 : 0,
    };
  });
}

export interface AnomalyMarker {
  time: string;
  value: number;
  severity: "warning" | "critical";
  description: string;
  metricType: string;
}

export function mapAnomaliesForChart(
  anomalies: any[] | undefined,
  timeseries: any[] | undefined,
  startTime?: any
): { responseTime: AnomalyMarker[]; throughput: AnomalyMarker[]; errorRate: AnomalyMarker[] } {
  const result = { responseTime: [] as AnomalyMarker[], throughput: [] as AnomalyMarker[], errorRate: [] as AnomalyMarker[] };
  if (!anomalies?.length || !timeseries?.length) return result;
  const baseTime = parseStartTimeToSec(startTime) ?? (timeseries[0]?.sec || 0);
  const secMap = new Map<number, any>();
  for (const p of timeseries) secMap.set(p.sec, p);
  for (const a of anomalies) {
    const sec = Math.floor(a.timestamp / 1000);
    let point = secMap.get(sec);
    if (!point) {
      point = secMap.get(sec - 1) || secMap.get(sec + 1);
    }
    if (!point) continue;
    const timeLabel = formatElapsedLabel(point.sec - baseTime);
    if (a.metricType === "response_time") {
      result.responseTime.push({ time: timeLabel, value: point.avg_ms || a.value, severity: a.severity, description: a.description, metricType: a.metricType });
    } else if (a.metricType === "throughput") {
      result.throughput.push({ time: timeLabel, value: point.rps || a.value, severity: a.severity, description: a.description, metricType: a.metricType });
    } else if (a.metricType === "error_rate") {
      result.errorRate.push({ time: timeLabel, value: point.error_rate ?? a.value, severity: a.severity, description: a.description, metricType: a.metricType });
    }
  }
  return result;
}

export function formatHMS(totalSeconds: number): string {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function parseHMS(value: string): number | null {
  const trimmed = value.trim();
  if (!trimmed) return null;
  const parts = trimmed.split(':').map(Number);
  if (parts.some(isNaN)) return null;
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 1) return parts[0];
  return null;
}

export function DetailSkeleton() {
   return (
      <div className="space-y-6">
         <Skeleton className="h-12 w-full" />
         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Skeleton className="col-span-2 h-64" />
            <Skeleton className="col-span-1 h-64" />
         </div>
      </div>
   )
}
