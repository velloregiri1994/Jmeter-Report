import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Activity, AlertTriangle, XCircle, BarChart2 } from "lucide-react";
import { Link } from "wouter";

export function DeviationCard({ 
  label, 
  baseline, 
  current, 
  change, 
  unit, 
  higherIsBad,
  thresholds
}: { 
  label: string; 
  baseline: number; 
  current: number; 
  change: number; 
  unit: string;
  higherIsBad: boolean;
  thresholds?: { warning: number; critical: number };
}) {
  const isNegative = higherIsBad ? change > 0 : change < 0;
  const absChange = Math.abs(change);
  const severity = thresholds ? (absChange >= thresholds.critical ? 'critical' : absChange >= thresholds.warning ? 'warning' : 'ok') : (isNegative ? 'warning' : 'ok');
  
  return (
    <div className={`p-3 rounded-xl border ${
      severity === 'critical' ? 'bg-gradient-to-br from-red-500/15 to-red-600/5 border-red-500/20' :
      severity === 'warning' ? 'bg-gradient-to-br from-amber-500/10 to-amber-600/5 border-amber-500/15' :
      isNegative ? 'bg-gradient-to-br from-rose-500/10 to-rose-600/5 border-rose-500/15' :
      'bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border-emerald-500/15'
    }`}>
      <div className="flex items-center justify-between">
        <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground/70">{label}</div>
        {severity !== 'ok' && isNegative && thresholds && (
          <span className={`text-[8px] font-bold uppercase px-1 py-0.5 rounded ${
            severity === 'critical' ? 'bg-red-500/20 text-red-600' : 'bg-amber-500/20 text-amber-600'
          }`}>{severity}</span>
        )}
      </div>
      <div className="flex items-baseline gap-2 mt-1">
        <span className="text-lg font-bold">{current.toFixed(1)}<span className="text-xs font-normal text-muted-foreground">{unit}</span></span>
        <span className={`text-xs font-semibold px-1.5 py-0.5 rounded ${isNegative ? 'text-rose-600 bg-rose-500/10' : 'text-emerald-600 bg-emerald-500/10'}`}>
          {change > 0 ? '+' : ''}{Math.round(change)}%
        </span>
      </div>
      <div className="text-xs text-muted-foreground mt-0.5">
        Baseline: {baseline.toFixed(1)}{unit}
      </div>
    </div>
  );
}

export function BaselineComparisonCard({ baselineDeviation }: { baselineDeviation: any }) {
  if (!baselineDeviation) return null;

  return (
    <Card className={baselineDeviation.overallRegression 
      ? "border-red-500/50 bg-red-50 dark:bg-red-900/10" 
      : "border-emerald-500/50 bg-emerald-50 dark:bg-emerald-900/10"
    }>
      <CardHeader className="pb-2">
        <CardTitle className={`flex items-center gap-2 ${baselineDeviation.overallRegression ? 'text-red-700 dark:text-red-400' : 'text-emerald-700 dark:text-emerald-400'}`}>
          <Activity className="w-5 h-5" />
          Baseline Comparison
          {baselineDeviation.overallRegression && baselineDeviation.regressionSeverity && (
            <span className={`ml-2 text-xs uppercase px-2 py-0.5 rounded font-bold ${
              baselineDeviation.regressionSeverity === 'severe' ? 'bg-red-200 dark:bg-red-800 text-red-800 dark:text-red-200' :
              baselineDeviation.regressionSeverity === 'moderate' ? 'bg-amber-200 dark:bg-amber-800 text-amber-800 dark:text-amber-200' :
              'bg-yellow-200 dark:bg-yellow-800 text-yellow-800 dark:text-yellow-200'
            }`}>
              {baselineDeviation.regressionSeverity} regression
            </span>
          )}
          {!baselineDeviation.overallRegression && (
            <span className="ml-2 text-xs uppercase bg-emerald-200 dark:bg-emerald-800 px-2 py-0.5 rounded font-bold text-emerald-800 dark:text-emerald-200">
              within thresholds
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {baselineDeviation.global?.avgResponseTime && (
            <DeviationCard label="Avg Response" baseline={baselineDeviation.global.avgResponseTime.baseline} current={baselineDeviation.global.avgResponseTime.current} change={baselineDeviation.global.avgResponseTime.changePercent} unit="ms" higherIsBad thresholds={baselineDeviation.thresholds?.avgResponseTime} />
          )}
          {baselineDeviation.global?.throughput && (
            <DeviationCard label="Throughput" baseline={baselineDeviation.global.throughput.baseline} current={baselineDeviation.global.throughput.current} change={baselineDeviation.global.throughput.changePercent} unit="/s" higherIsBad={false} thresholds={baselineDeviation.thresholds?.throughput} />
          )}
          {baselineDeviation.global?.p90 && (
            <DeviationCard label="P90" baseline={baselineDeviation.global.p90.baseline} current={baselineDeviation.global.p90.current} change={baselineDeviation.global.p90.changePercent} unit="ms" higherIsBad thresholds={baselineDeviation.thresholds?.p90} />
          )}
          {baselineDeviation.global?.p95 && (
            <DeviationCard label="P95" baseline={baselineDeviation.global.p95.baseline} current={baselineDeviation.global.p95.current} change={baselineDeviation.global.p95.changePercent} unit="ms" higherIsBad thresholds={baselineDeviation.thresholds?.p95} />
          )}
          {baselineDeviation.global?.p99 && (
            <DeviationCard label="P99" baseline={baselineDeviation.global.p99.baseline} current={baselineDeviation.global.p99.current} change={baselineDeviation.global.p99.changePercent} unit="ms" higherIsBad thresholds={baselineDeviation.thresholds?.p99} />
          )}
          {baselineDeviation.global?.errorRate && (
            <DeviationCard label="Error Rate" baseline={baselineDeviation.global.errorRate.baseline * 100} current={baselineDeviation.global.errorRate.current * 100} change={baselineDeviation.global.errorRate.changePercent} unit="%" higherIsBad thresholds={baselineDeviation.thresholds?.errorRate} />
          )}
        </div>

        {(baselineDeviation.regressionDetails?.length ?? 0) > 0 && (
          <div className="p-3 rounded-lg bg-red-100/50 dark:bg-red-900/20 border border-red-200/50 dark:border-red-800/30">
            <div className="text-xs font-bold text-red-700 dark:text-red-400 mb-2 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              Regression Details
            </div>
            <div className="flex flex-wrap gap-2">
              {(baselineDeviation.regressionDetails ?? []).map((r: any, i: number) => {
                const metricLabels: Record<string, string> = { avgResponseTime: 'Avg RT', throughput: 'Throughput', errorRate: 'Error Rate', p90: 'P90', p95: 'P95', p99: 'P99' };
                return (
                  <span key={i} className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wide ${
                    r.severity === 'critical' ? 'bg-red-500/20 text-red-700 dark:text-red-300' : 'bg-amber-500/20 text-amber-700 dark:text-amber-300'
                  }`}>
                    {r.severity === 'critical' ? <XCircle className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                    {metricLabels[r.metric] || r.metric}: {r.changePercent > 0 ? '+' : ''}{Math.round(r.changePercent)}%
                  </span>
                );
              })}
            </div>
          </div>
        )}

        {baselineDeviation.global && (
          <div className="rounded-lg border bg-background/50 p-4">
            <div className="text-xs font-bold text-muted-foreground mb-3 flex items-center gap-1.5">
              <BarChart2 className="w-3.5 h-3.5" />
              Baseline vs Current
            </div>
            <div className="space-y-3">
              {Object.entries(baselineDeviation.global).map(([key, dev]: [string, any]) => {
                if (!dev) return null;
                const labels: Record<string, string> = { avgResponseTime: 'Avg Response Time', throughput: 'Throughput', errorRate: 'Error Rate', p90: 'P90', p95: 'P95', p99: 'P99' };
                const isHigherBad = key !== 'throughput';
                const baseVal = key === 'errorRate' ? dev.baseline * 100 : dev.baseline;
                const curVal = key === 'errorRate' ? dev.current * 100 : dev.current;
                const maxVal = Math.max(baseVal, curVal) || 1;
                const isRegression = isHigherBad ? dev.changePercent > 0 : dev.changePercent < 0;
                const thresh = baselineDeviation.thresholds?.[key];

                return (
                  <div key={key} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium">{labels[key] || key}</span>
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${isRegression ? 'text-rose-600 bg-rose-500/10' : 'text-emerald-600 bg-emerald-500/10'}`}>
                        {dev.changePercent > 0 ? '+' : ''}{Math.round(dev.changePercent)}%
                      </span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-bold text-blue-500 w-12">Baseline</span>
                        <div className="flex-1 h-3 bg-muted/30 rounded-full overflow-hidden relative">
                          <div className="h-full rounded-full bg-blue-500/60 transition-all duration-500" style={{ width: `${(baseVal / maxVal) * 100}%` }} />
                          {thresh && (
                            <div className="absolute top-0 bottom-0 w-px bg-amber-500/60" style={{ left: `${Math.min(((baseVal * (1 + thresh.warning / 100)) / maxVal) * 100, 100)}%` }} title={`Warning: ${thresh.warning}%`} />
                          )}
                        </div>
                        <span className="text-[10px] font-semibold w-16 text-right tabular-nums">{baseVal.toFixed(1)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-bold text-violet-500 w-12">Current</span>
                        <div className="flex-1 h-3 bg-muted/30 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full transition-all duration-500 ${isRegression ? 'bg-rose-500/60' : 'bg-emerald-500/60'}`} style={{ width: `${(curVal / maxVal) * 100}%` }} />
                        </div>
                        <span className="text-[10px] font-semibold w-16 text-right tabular-nums">{curVal.toFixed(1)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {(baselineDeviation.transactionDeviations?.length ?? 0) > 0 && (
          <div className="rounded-lg border bg-background/50 p-4">
            <div className="text-xs font-bold text-muted-foreground mb-3 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5" />
              Transaction-Level Deviations ({baselineDeviation.transactionDeviations?.length ?? 0})
            </div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {(baselineDeviation.transactionDeviations ?? []).map((td: any) => {
                const avgChange = td.avg?.changePercent || 0;
                const isRegression = avgChange > 0;
                return (
                  <div key={td.label} className={`flex items-center gap-3 p-2 rounded-lg border ${isRegression ? 'border-rose-500/15 bg-rose-500/5' : 'border-emerald-500/15 bg-emerald-500/5'}`}>
                    <div className={`w-1 h-8 rounded-full shrink-0 ${isRegression ? 'bg-rose-500' : 'bg-emerald-500'}`} />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold truncate">{td.label}</div>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className="text-[10px] text-muted-foreground">Avg: {td.avg.baseline.toFixed(0)} → {td.avg.current.toFixed(0)} ms</span>
                        {td.p90 && <span className="text-[10px] text-muted-foreground">P90: {td.p90.baseline.toFixed(0)} → {td.p90.current.toFixed(0)} ms</span>}
                      </div>
                    </div>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${isRegression ? 'text-rose-600 bg-rose-500/10' : 'text-emerald-600 bg-emerald-500/10'}`}>
                      {avgChange > 0 ? '+' : ''}{Math.round(avgChange)}%
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div className="text-xs text-muted-foreground">
          Compared against <Link href={`/executions/${baselineDeviation.baselineExecutionId}`} className="text-primary hover:underline">baseline execution #{baselineDeviation.baselineExecutionId}</Link>
          {baselineDeviation.thresholds && (
            <span className="ml-2 text-muted-foreground/60">
              • Thresholds: warn {baselineDeviation.thresholds.avgResponseTime?.warning || 10}% / critical {baselineDeviation.thresholds.avgResponseTime?.critical || 25}%
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
