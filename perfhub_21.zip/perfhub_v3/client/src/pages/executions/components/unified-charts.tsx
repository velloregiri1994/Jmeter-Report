import React, { useMemo, useState, useCallback } from "react";
import {
  Activity, TrendingUp, Users, AlertTriangle, BarChart3,
  Cpu, MemoryStick, HardDrive, GitCompare, Server,
  Target, Timer, ChevronDown, ChevronRight
} from "lucide-react";
import {
  Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Area, AreaChart, ComposedChart, Bar, BarChart,
  ReferenceLine, Brush, Cell, LineChart
} from "recharts";
import { CollapsibleChart, ChartGrid } from "@/components/collapsible-chart";
import { formatElapsedLabel } from "./detail-utils";
import { DynatraceTooltip } from "./dynatrace-tooltip";
import {
  DT_COLORS, DT_PALETTE, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS,
  DT_TOOLTIP_STYLE, DynatraceGradients, DtLegend, useLegendToggle
} from "@/components/charts/dynatrace-theme";
import { LazyChartSection } from "./lazy-chart-section";
import type { UnifiedChartsProps, NormalizedPoint } from "./chart-types";
import type { LiveMetricsSnapshot } from "@/hooks/use-websocket";

function normalizeData(results: any, liveSnapshot: LiveMetricsSnapshot | null, isLive: boolean): NormalizedPoint[] {
  if (isLive && liveSnapshot?.series?.length) {
    const series = liveSnapshot.series;
    const firstT = series[0]?.t || 0;
    const intervalSec = series.length > 1 ? Math.max(1, (series[1].t - series[0].t) / 1000) : 5;
    return series.map((p) => {
      const sec = Math.floor(p.t / 1000);
      const elapsed = Math.floor((p.t - firstT) / 1000);
      const rps = p.throughput || 0;
      const errorRate = p.errorRate || 0;
      const estimatedErrors = rps > 0 ? Math.round(rps * intervalSec * errorRate / 100) : 0;
      const actualErrors = p.errors ?? estimatedErrors;
      return {
        time: formatElapsedLabel(elapsed),
        elapsed,
        sec,
        rps,
        avgMs: p.avgRT || 0,
        p50Ms: p.p50 || 0,
        p90Ms: p.p90 || 0,
        p95Ms: p.p95 || 0,
        p99Ms: p.p99 || 0,
        activeThreads: p.activeThreads || 0,
        errors: actualErrors,
        errorRate,
        errorsPerSec: intervalSec > 0 ? Math.round((actualErrors / intervalSec) * 100) / 100 : 0,
      };
    });
  }

  if (results?.timeseries?.length) {
    const ts = results.timeseries;
    const isRemote = ts[0]?.t !== undefined && ts[0]?.sec === undefined;
    const firstSec = isRemote ? Math.floor((ts[0]?.t || 0) / 1000) : (ts[0]?.sec || 0);
    const bucketSec = ts.length > 1
      ? Math.max(1, isRemote
          ? Math.floor(((ts[1]?.t || 0) - (ts[0]?.t || 0)) / 1000)
          : ((ts[1]?.sec || 0) - (ts[0]?.sec || 0)))
      : 5;

    return ts.map((point: any) => {
      if (isRemote) {
        const sec = Math.floor((point.t || 0) / 1000);
        const elapsed = sec - firstSec;
        const rps = point.throughput || 0;
        const errorRate = point.errorRate || 0;
        const errors = point.errors ?? (rps > 0 ? Math.round(rps * bucketSec * errorRate / 100) : 0);
        return {
          time: formatElapsedLabel(elapsed),
          elapsed,
          sec,
          rps,
          avgMs: point.avgRT || 0,
          p50Ms: point.p50 || 0,
          p90Ms: point.p90 || 0,
          p95Ms: point.p95 || 0,
          p99Ms: point.p99 || 0,
          activeThreads: point.activeThreads || 0,
          errors,
          errorRate,
          errorsPerSec: bucketSec > 0 ? Math.round((errors / bucketSec) * 100) / 100 : 0,
        };
      }
      const elapsed = point.sec - firstSec;
      const rps = point.rps || 0;
      const errors = point.errors || 0;
      const totalRequests = rps * bucketSec;
      return {
        time: formatElapsedLabel(elapsed),
        elapsed,
        sec: point.sec,
        rps,
        avgMs: point.avg_ms || 0,
        p50Ms: point.p50 || 0,
        p90Ms: point.p90 || 0,
        p95Ms: point.p95 || 0,
        p99Ms: point.p99 || 0,
        activeThreads: point.active_threads || 0,
        errors,
        errorRate: totalRequests > 0 ? Math.round((errors / totalRequests) * 10000) / 100 : 0,
        errorsPerSec: bucketSec > 0 ? Math.round((errors / bucketSec) * 100) / 100 : 0,
      };
    });
  }

  return [];
}

function getSystemData(systemMetrics: any, liveSnapshot: LiveMetricsSnapshot | null, isLive: boolean) {
  if (isLive && liveSnapshot?.systemMetrics?.history?.length) {
    const hist = liveSnapshot.systemMetrics.history;
    const firstTs = hist[0]?.ts || 0;
    const latestMem = liveSnapshot.systemMetrics.latest?.jmeterMemMb;
    return hist.map((h: any) => ({
      time: formatElapsedLabel(Math.floor((h.ts - firstTs) / 1000)),
      elapsed: Math.floor((h.ts - firstTs) / 1000),
      cpuPercent: h.cpuPercent || 0,
      memPercent: h.memPercent || 0,
      diskReadMbps: h.diskReadMbps || 0,
      diskWriteMbps: h.diskWriteMbps || 0,
      jmeterCpu: h.jmeterCpuPercent || 0,
      jmeterMemMB: (h as any).jmeterMemMb || latestMem || 0,
    }));
  }

  const sysTs = (systemMetrics?.host?.timeseries?.length ? systemMetrics.host.timeseries : null) || systemMetrics?.timeseries;
  if (sysTs?.length) {
    const firstTs = sysTs[0]?.ts || 0;
    return sysTs.map((d: any) => ({
      time: formatElapsedLabel(Math.round((d.ts - firstTs) / 1000)),
      elapsed: Math.round((d.ts - firstTs) / 1000),
      cpuPercent: d.cpuPercent || 0,
      memPercent: d.memPercent || 0,
      memUsedMb: d.memUsedMb || 0,
      diskReadMbps: d.diskReadMbps || 0,
      diskWriteMbps: d.diskWriteMbps || 0,
      jmeterCpu: d.jmeterCpuPercent || 0,
      jmeterMemMB: d.jmeterMemMb || 0,
    }));
  }

  const mm = systemMetrics?.machineMetrics;
  if (mm && typeof mm === 'object') {
    const allSamples: any[] = [];
    for (const nodeId of Object.keys(mm)) {
      const nodeTs = mm[nodeId]?.timeseries || mm[nodeId]?.history;
      if (Array.isArray(nodeTs)) {
        for (const s of nodeTs) {
          allSamples.push(s);
        }
      }
    }
    if (allSamples.length > 0) {
      allSamples.sort((a, b) => (a.ts || 0) - (b.ts || 0));
      const bucketMs = 2000;
      const merged: any[] = [];
      let bucket: any[] = [allSamples[0]];
      for (let i = 1; i < allSamples.length; i++) {
        if (allSamples[i].ts - bucket[0].ts < bucketMs) {
          bucket.push(allSamples[i]);
        } else {
          merged.push(bucket);
          bucket = [allSamples[i]];
        }
      }
      merged.push(bucket);
      const firstTs = merged[0][0].ts || 0;
      return merged.map(group => {
        const n = group.length;
        const avg = (key: string) => group.reduce((s: number, g: any) => s + (g[key] || 0), 0) / n;
        return {
          time: formatElapsedLabel(Math.round((group[0].ts - firstTs) / 1000)),
          elapsed: Math.round((group[0].ts - firstTs) / 1000),
          cpuPercent: avg('cpuPercent'),
          memPercent: avg('memPercent'),
          memUsedMb: avg('memUsedMb'),
          diskReadMbps: avg('diskReadMbps'),
          diskWriteMbps: avg('diskWriteMbps'),
          jmeterCpu: avg('jmeterCpuPercent'),
          jmeterMemMB: avg('jmeterMemMb'),
        };
      });
    }
  }

  return [];
}

function detectRampUpEnd(data: NormalizedPoint[]): string | null {
  if (data.length < 10) return null;
  const maxThreads = Math.max(...data.map(d => d.activeThreads));
  if (maxThreads <= 1) return null;
  const threshold = maxThreads * 0.95;
  for (let i = 1; i < data.length; i++) {
    if (data[i].activeThreads >= threshold && data[i - 1].activeThreads < threshold) {
      return data[i].time;
    }
  }
  return null;
}

function buildHistogram(data: NormalizedPoint[]) {
  if (data.length === 0) return [];
  const allValues: number[] = [];
  for (const p of data) {
    if (p.p50Ms > 0) allValues.push(p.p50Ms);
    if (p.p90Ms > 0) allValues.push(p.p90Ms);
    if (p.p95Ms > 0) allValues.push(p.p95Ms);
    if (p.p99Ms > 0) allValues.push(p.p99Ms);
    if (p.avgMs > 0) allValues.push(p.avgMs);
  }
  if (allValues.length === 0) return [];
  allValues.sort((a, b) => a - b);
  const minVal = allValues[0];
  const maxVal = allValues[allValues.length - 1];
  const range = maxVal - minVal;
  const numBuckets = Math.min(12, Math.max(5, Math.ceil(Math.sqrt(allValues.length))));

  if (range < 10) {
    return [{ range: `${Math.round(minVal)}ms`, count: allValues.length, min: minVal, max: maxVal }];
  }

  const step = Math.ceil(range / numBuckets);
  const roundedStep = step <= 5 ? 5 : step <= 10 ? 10 : step <= 25 ? 25 : step <= 50 ? 50 : step <= 100 ? 100 : Math.ceil(step / 50) * 50;
  const bucketStart = Math.floor(minVal / roundedStep) * roundedStep;

  const buckets: Array<{ range: string; min: number; max: number; count: number }> = [];
  for (let i = 0; i < numBuckets + 2; i++) {
    const lo = bucketStart + i * roundedStep;
    const hi = lo + roundedStep;
    if (lo > maxVal) break;
    buckets.push({
      range: hi >= 1000 ? `${(lo / 1000).toFixed(1)}-${(hi / 1000).toFixed(1)}s` : `${lo}-${hi}`,
      min: lo, max: hi, count: 0,
    });
  }
  for (const v of allValues) {
    for (const b of buckets) {
      if (v >= b.min && v < b.max) { b.count++; break; }
    }
    if (allValues.length > 0 && buckets.length > 0) {
      const last = buckets[buckets.length - 1];
      if (v >= last.max) last.count++;
    }
  }
  return buckets.filter(b => b.count > 0);
}

function SectionHeader({ icon, title, collapsed, onToggle, count }: {
  icon: React.ReactNode; title: string; collapsed: boolean; onToggle: () => void; count?: number;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className="flex items-center gap-2 w-full text-left group py-2"
    >
      {collapsed ? <ChevronRight className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      {icon}
      <span className="text-sm font-semibold uppercase tracking-wider text-muted-foreground group-hover:text-foreground transition-colors">
        {title}
      </span>
      {count !== undefined && (
        <span className="text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded-full">{count} charts</span>
      )}
      <div className="flex-1 border-b border-border/40 ml-2" />
    </button>
  );
}

export function UnifiedCharts({ results, systemMetrics, liveSnapshot, isLive, executionId }: UnifiedChartsProps) {
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
  const [collapsedCharts, setCollapsedCharts] = useState<Record<string, boolean>>({});
  const [chartSizes, setChartSizes] = useState<Record<string, "compact" | "expanded">>({});

  const toggleSection = useCallback((key: string) => {
    setCollapsedSections(prev => ({ ...prev, [key]: !prev[key] }));
  }, []);

  const isCollapsed = (key: string) => collapsedCharts[key] ?? false;
  const toggleChart = (key: string) => setCollapsedCharts(prev => ({ ...prev, [key]: !prev[key] }));
  const getSize = (key: string) => chartSizes[key] ?? "compact";
  const setChartSize = (key: string, s: "compact" | "expanded") => setChartSizes(prev => ({ ...prev, [key]: s }));

  const data = useMemo(() => normalizeData(results, liveSnapshot, isLive), [results, liveSnapshot, isLive]);
  const sysData = useMemo(() => getSystemData(systemMetrics, liveSnapshot, isLive), [systemMetrics, liveSnapshot, isLive]);
  const rampUpLabel = useMemo(() => detectRampUpEnd(data), [data]);
  const histogram = useMemo(() => buildHistogram(data), [data]);

  const showBrush = data.length > 30;
  const brushHeight = 25;

  const hasDiskData = sysData.some((d: any) => (d.diskReadMbps || 0) > 0 || (d.diskWriteMbps || 0) > 0);
  const machineMetrics = systemMetrics?.machineMetrics;
  const machineNodeIds = machineMetrics ? Object.keys(machineMetrics) : [];
  const hasMultipleNodes = machineNodeIds.length > 1;
  const legendTraffic = useLegendToggle();
  const legendRtThroughput = useLegendToggle();
  const legendLatency = useLegendToggle();
  const legendRtErrors = useLegendToggle();
  const legendErrors = useLegendToggle();
  const legendErrorThreads = useLegendToggle();
  const legendSys = useLegendToggle();
  const legendCorr1 = useLegendToggle();

  if (data.length === 0) return null;

  return (
    <div className="space-y-2">

      {/* SECTION 2: TRAFFIC / LOAD */}
      <SectionHeader
        icon={<TrendingUp className="w-4 h-4" style={{ color: DT_COLORS.throughput }} />}
        title="Traffic / Load"
        collapsed={!!collapsedSections.traffic}
        onToggle={() => toggleSection('traffic')}
        count={4}
      />
      {!collapsedSections.traffic && (
        <ChartGrid columns={2}>
          <CollapsibleChart
            title="Throughput Over Time"
            icon={<TrendingUp className="w-4 h-4" style={{ color: DT_COLORS.throughput }} />}
            collapsed={isCollapsed("throughput")}
            onToggleCollapse={() => toggleChart("throughput")}
            size={getSize("throughput")}
            onSizeChange={(s) => setChartSize("throughput", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis {...DT_AXIS_PROPS} label={{ value: 'req/s', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip
                  cursor={DT_CURSOR_PROPS}
                  content={<DynatraceTooltip hiddenSeries={new Set()} metrics={[
                    { key: 'rps', label: 'Throughput', unit: 'req/s', color: DT_COLORS.throughput, decimals: 1 },
                  ]} />}
                />
                {rampUpLabel && <ReferenceLine x={rampUpLabel} stroke={DT_COLORS.amber} strokeDasharray="6 3" strokeWidth={1.5} label={{ value: 'Ramp-up end', position: 'top', fontSize: 9, fill: DT_COLORS.amber }} />}
                <Area type="monotone" dataKey="rps" name="Throughput" stroke={DT_COLORS.throughput} strokeWidth={2} fill="url(#dt-grad-green)" dot={false} />
                {showBrush && <Brush dataKey="time" height={brushHeight} stroke={DT_COLORS.primary} fill="hsl(var(--muted))" travellerWidth={8} tickFormatter={() => ''} />}
              </AreaChart>
            </ResponsiveContainer></div>
          </CollapsibleChart>

          <CollapsibleChart
            title="Active Threads / Users"
            icon={<Users className="w-4 h-4" style={{ color: DT_COLORS.threads }} />}
            collapsed={isCollapsed("threads")}
            onToggleCollapse={() => toggleChart("threads")}
            size={getSize("threads")}
            onSizeChange={(s) => setChartSize("threads", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis {...DT_AXIS_PROPS} label={{ value: 'threads', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip
                  cursor={DT_CURSOR_PROPS}
                  content={<DynatraceTooltip hiddenSeries={new Set()} metrics={[
                    { key: 'activeThreads', label: 'Active Threads', color: DT_COLORS.threads },
                  ]} />}
                />
                {rampUpLabel && <ReferenceLine x={rampUpLabel} stroke={DT_COLORS.amber} strokeDasharray="6 3" strokeWidth={1.5} />}
                <Area type="stepAfter" dataKey="activeThreads" name="Active Threads" stroke={DT_COLORS.threads} strokeWidth={2} fill="url(#dt-grad-teal)" dot={false} />
              </AreaChart>
            </ResponsiveContainer></div>
          </CollapsibleChart>

          <CollapsibleChart
            title="Throughput vs Threads"
            icon={<GitCompare className="w-4 h-4" style={{ color: DT_COLORS.primary }} />}
            collapsed={isCollapsed("tpt-vs-threads")}
            onToggleCollapse={() => toggleChart("tpt-vs-threads")}
            size={getSize("tpt-vs-threads")}
            onSizeChange={(s) => setChartSize("tpt-vs-threads", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis yAxisId="left" {...DT_AXIS_PROPS} label={{ value: 'req/s', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} label={{ value: 'threads', angle: 90, position: 'insideRight', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip
                  cursor={DT_CURSOR_PROPS}
                  content={<DynatraceTooltip hiddenSeries={legendTraffic.hiddenSeries} metrics={[
                    { key: 'rps', label: 'Throughput', unit: 'req/s', color: DT_COLORS.throughput, decimals: 1 },
                    { key: 'activeThreads', label: 'Active Threads', color: DT_COLORS.threads },
                  ]} />}
                />
                {rampUpLabel && <ReferenceLine yAxisId="left" x={rampUpLabel} stroke={DT_COLORS.amber} strokeDasharray="6 3" strokeWidth={1.5} />}
                {legendTraffic.isVisible('rps') && <Area yAxisId="left" type="monotone" dataKey="rps" name="Throughput" stroke={DT_COLORS.throughput} strokeWidth={2} fill="url(#dt-grad-green)" dot={false} />}
                {legendTraffic.isVisible('activeThreads') && <Line yAxisId="right" type="stepAfter" dataKey="activeThreads" name="Active Threads" stroke={DT_COLORS.threads} strokeWidth={2} dot={false} />}
              </ComposedChart>
            </ResponsiveContainer></div>
            <DtLegend
              items={[
                { key: 'rps', label: 'Throughput (req/s)', color: DT_COLORS.throughput },
                { key: 'activeThreads', label: 'Active Threads', color: DT_COLORS.threads },
              ]}
              hiddenSeries={legendTraffic.hiddenSeries}
              onToggle={legendTraffic.toggleSeries}
            />
          </CollapsibleChart>

          <CollapsibleChart
            title="Avg Response Time vs Throughput"
            icon={<GitCompare className="w-4 h-4" style={{ color: DT_COLORS.responseTime }} />}
            collapsed={isCollapsed("rt-vs-throughput")}
            onToggleCollapse={() => toggleChart("rt-vs-throughput")}
            size={getSize("rt-vs-throughput")}
            onSizeChange={(s) => setChartSize("rt-vs-throughput", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis yAxisId="left" {...DT_AXIS_PROPS} label={{ value: 'ms', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} label={{ value: 'req/s', angle: 90, position: 'insideRight', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip
                  cursor={DT_CURSOR_PROPS}
                  content={<DynatraceTooltip hiddenSeries={legendRtThroughput.hiddenSeries} metrics={[
                    { key: 'avgMs', label: 'Avg Response', unit: 'ms', color: DT_COLORS.responseTime },
                    { key: 'rps', label: 'Throughput', unit: 'req/s', color: DT_COLORS.throughput, decimals: 1 },
                  ]} />}
                />
                {rampUpLabel && <ReferenceLine yAxisId="left" x={rampUpLabel} stroke={DT_COLORS.amber} strokeDasharray="6 3" strokeWidth={1.5} />}
                {legendRtThroughput.isVisible('avgMs') && <Area yAxisId="left" type="monotone" dataKey="avgMs" name="Avg Response" stroke={DT_COLORS.responseTime} strokeWidth={2} fill="url(#dt-grad-primary)" dot={false} />}
                {legendRtThroughput.isVisible('rps') && <Line yAxisId="right" type="monotone" dataKey="rps" name="Throughput" stroke={DT_COLORS.throughput} strokeWidth={2} dot={false} />}
              </ComposedChart>
            </ResponsiveContainer></div>
            <DtLegend
              items={[
                { key: 'avgMs', label: 'Avg Response (ms)', color: DT_COLORS.responseTime },
                { key: 'rps', label: 'Throughput (req/s)', color: DT_COLORS.throughput },
              ]}
              hiddenSeries={legendRtThroughput.hiddenSeries}
              onToggle={legendRtThroughput.toggleSeries}
            />
          </CollapsibleChart>
        </ChartGrid>
      )}

      {/* SECTION 3: LATENCY / RESPONSE TIME */}
      <LazyChartSection>
      <SectionHeader
        icon={<Timer className="w-4 h-4" style={{ color: DT_COLORS.responseTime }} />}
        title="Latency / Response Time"
        collapsed={!!collapsedSections.latency}
        onToggle={() => toggleSection('latency')}
        count={4}
      />
      {!collapsedSections.latency && (
        <ChartGrid columns={2}>
          <CollapsibleChart
            title="Latency Percentiles Over Time"
            icon={<Activity className="w-4 h-4" style={{ color: DT_COLORS.primary }} />}
            collapsed={isCollapsed("latency-pct")}
            onToggleCollapse={() => toggleChart("latency-pct")}
            size={getSize("latency-pct")}
            onSizeChange={(s) => setChartSize("latency-pct", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis yAxisId="left" {...DT_AXIS_PROPS} label={{ value: 'ms', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip
                  cursor={DT_CURSOR_PROPS}
                  content={<DynatraceTooltip hiddenSeries={legendLatency.hiddenSeries} metrics={[
                    { key: 'p99Ms', label: 'P99', unit: 'ms', color: DT_COLORS.red },
                    { key: 'p95Ms', label: 'P95', unit: 'ms', color: DT_COLORS.purple },
                    { key: 'p90Ms', label: 'P90', unit: 'ms', color: DT_COLORS.amber },
                    { key: 'p50Ms', label: 'P50', unit: 'ms', color: DT_COLORS.cyan },
                    { key: 'avgMs', label: 'Avg', unit: 'ms', color: DT_COLORS.primary },
                  ]} />}
                />
                {legendLatency.isVisible('p99Ms') && <Line yAxisId="left" type="monotone" dataKey="p99Ms" name="P99" stroke={DT_COLORS.red} strokeWidth={1.5} dot={false} strokeDasharray="2 2" />}
                {legendLatency.isVisible('p95Ms') && <Line yAxisId="left" type="monotone" dataKey="p95Ms" name="P95" stroke={DT_COLORS.purple} strokeWidth={1.5} dot={false} strokeDasharray="4 2" />}
                {legendLatency.isVisible('p90Ms') && <Line yAxisId="left" type="monotone" dataKey="p90Ms" name="P90" stroke={DT_COLORS.amber} strokeWidth={1.5} dot={false} strokeDasharray="4 2" />}
                {legendLatency.isVisible('p50Ms') && <Line yAxisId="left" type="monotone" dataKey="p50Ms" name="P50" stroke={DT_COLORS.cyan} strokeWidth={1.5} dot={false} />}
                {legendLatency.isVisible('avgMs') && <Area yAxisId="left" type="monotone" dataKey="avgMs" name="Avg" stroke={DT_COLORS.primary} strokeWidth={2} fill="url(#dt-grad-primary)" dot={false} />}
              </ComposedChart>
            </ResponsiveContainer></div>
            <DtLegend
              items={[
                { key: 'avgMs', label: 'Avg (ms)', color: DT_COLORS.primary },
                { key: 'p50Ms', label: 'P50', color: DT_COLORS.cyan },
                { key: 'p90Ms', label: 'P90', color: DT_COLORS.amber, dashed: true },
                { key: 'p95Ms', label: 'P95', color: DT_COLORS.purple, dashed: true },
                { key: 'p99Ms', label: 'P99', color: DT_COLORS.red, dashed: true },
              ]}
              hiddenSeries={legendLatency.hiddenSeries}
              onToggle={legendLatency.toggleSeries}
            />
          </CollapsibleChart>

          <CollapsibleChart
            title="Latency Distribution"
            icon={<BarChart3 className="w-4 h-4" style={{ color: DT_COLORS.purple }} />}
            collapsed={isCollapsed("lat-dist")}
            onToggleCollapse={() => toggleChart("lat-dist")}
            size={getSize("lat-dist")}
            onSizeChange={(s) => setChartSize("lat-dist", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <BarChart data={histogram}>
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="range" {...DT_AXIS_PROPS} />
                <YAxis {...DT_AXIS_PROPS} label={{ value: 'count', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip cursor={DT_CURSOR_PROPS} contentStyle={DT_TOOLTIP_STYLE} />
                <Bar dataKey="count" name="Samples" fill={DT_COLORS.primary} radius={[4, 4, 0, 0]}>
                  {histogram.map((_, i) => (
                    <Cell key={i} fill={DT_PALETTE[i % DT_PALETTE.length]} fillOpacity={0.8} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer></div>
          </CollapsibleChart>

          <CollapsibleChart
            title="Avg Response Time vs Errors/sec"
            icon={<GitCompare className="w-4 h-4" style={{ color: DT_COLORS.orange }} />}
            collapsed={isCollapsed("rt-vs-errors")}
            onToggleCollapse={() => toggleChart("rt-vs-errors")}
            size={getSize("rt-vs-errors")}
            onSizeChange={(s) => setChartSize("rt-vs-errors", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis yAxisId="left" {...DT_AXIS_PROPS} label={{ value: 'ms', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} label={{ value: 'errors/s', angle: 90, position: 'insideRight', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip
                  cursor={DT_CURSOR_PROPS}
                  content={<DynatraceTooltip hiddenSeries={legendRtErrors.hiddenSeries} metrics={[
                    { key: 'avgMs', label: 'Avg Response', unit: 'ms', color: DT_COLORS.responseTime },
                    { key: 'errorsPerSec', label: 'Errors/sec', color: DT_COLORS.red, decimals: 2 },
                  ]} />}
                />
                {legendRtErrors.isVisible('avgMs') && <Area yAxisId="left" type="monotone" dataKey="avgMs" name="Avg Response" stroke={DT_COLORS.responseTime} strokeWidth={2} fill="url(#dt-grad-primary)" dot={false} />}
                {legendRtErrors.isVisible('errorsPerSec') && <Line yAxisId="right" type="monotone" dataKey="errorsPerSec" name="Errors/sec" stroke={DT_COLORS.red} strokeWidth={2} dot={false} />}
              </ComposedChart>
            </ResponsiveContainer></div>
            <DtLegend
              items={[
                { key: 'avgMs', label: 'Avg Response (ms)', color: DT_COLORS.responseTime },
                { key: 'errorsPerSec', label: 'Errors/sec', color: DT_COLORS.red },
              ]}
              hiddenSeries={legendRtErrors.hiddenSeries}
              onToggle={legendRtErrors.toggleSeries}
            />
          </CollapsibleChart>

          <CollapsibleChart
            title="Latency vs Load"
            icon={<Target className="w-4 h-4" style={{ color: DT_COLORS.purple }} />}
            collapsed={isCollapsed("corr-lat-load")}
            onToggleCollapse={() => toggleChart("corr-lat-load")}
            size={getSize("corr-lat-load")}
            onSizeChange={(s) => setChartSize("corr-lat-load", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis yAxisId="left" {...DT_AXIS_PROPS} label={{ value: 'ms', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} label={{ value: 'threads', angle: 90, position: 'insideRight', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip
                  cursor={DT_CURSOR_PROPS}
                  content={<DynatraceTooltip hiddenSeries={legendCorr1.hiddenSeries} metrics={[
                    { key: 'p95Ms', label: 'P95 Latency', unit: 'ms', color: DT_COLORS.purple },
                    { key: 'avgMs', label: 'Avg Response', unit: 'ms', color: DT_COLORS.responseTime },
                    { key: 'activeThreads', label: 'Active Threads', color: DT_COLORS.threads },
                  ]} />}
                />
                {legendCorr1.isVisible('p95Ms') && <Line yAxisId="left" type="monotone" dataKey="p95Ms" name="P95" stroke={DT_COLORS.purple} strokeWidth={1.5} dot={false} strokeDasharray="4 2" />}
                {legendCorr1.isVisible('avgMs') && <Line yAxisId="left" type="monotone" dataKey="avgMs" name="Avg Response" stroke={DT_COLORS.responseTime} strokeWidth={2} dot={false} />}
                {legendCorr1.isVisible('activeThreads') && <Area yAxisId="right" type="stepAfter" dataKey="activeThreads" name="Active Threads" stroke={DT_COLORS.threads} fill="url(#dt-grad-teal)" strokeWidth={2} dot={false} />}
              </ComposedChart>
            </ResponsiveContainer></div>
            <DtLegend
              items={[
                { key: 'p95Ms', label: 'P95 (ms)', color: DT_COLORS.purple, dashed: true },
                { key: 'avgMs', label: 'Avg Response (ms)', color: DT_COLORS.responseTime },
                { key: 'activeThreads', label: 'Active Threads', color: DT_COLORS.threads },
              ]}
              hiddenSeries={legendCorr1.hiddenSeries}
              onToggle={legendCorr1.toggleSeries}
            />
          </CollapsibleChart>
        </ChartGrid>
      )}
      </LazyChartSection>

      {/* SECTION 4: ERROR ANALYSIS */}
      <LazyChartSection>
      <SectionHeader
        icon={<AlertTriangle className="w-4 h-4" style={{ color: DT_COLORS.red }} />}
        title="Error Analysis"
        collapsed={!!collapsedSections.errors}
        onToggle={() => toggleSection('errors')}
        count={4}
      />
      {!collapsedSections.errors && (
        <ChartGrid columns={2}>
          <CollapsibleChart
            title="Error Rate Over Time"
            icon={<AlertTriangle className="w-4 h-4" style={{ color: DT_COLORS.errorRate }} />}
            collapsed={isCollapsed("error-rate")}
            onToggleCollapse={() => toggleChart("error-rate")}
            size={getSize("error-rate")}
            onSizeChange={(s) => setChartSize("error-rate", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis {...DT_AXIS_PROPS} domain={[0, 'auto']} label={{ value: '%', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip
                  cursor={DT_CURSOR_PROPS}
                  content={<DynatraceTooltip hiddenSeries={new Set()} metrics={[
                    { key: 'errorRate', label: 'Error Rate', unit: '%', color: DT_COLORS.errorRate, decimals: 2 },
                  ]} />}
                />
                <Area type="monotone" dataKey="errorRate" name="Error Rate" stroke={DT_COLORS.errorRate} strokeWidth={2} fill="url(#dt-grad-red)" dot={false} />
              </AreaChart>
            </ResponsiveContainer></div>
          </CollapsibleChart>

          <CollapsibleChart
            title="Error Count Over Time"
            icon={<AlertTriangle className="w-4 h-4" style={{ color: DT_COLORS.red }} />}
            collapsed={isCollapsed("error-count")}
            onToggleCollapse={() => toggleChart("error-count")}
            size={getSize("error-count")}
            onSizeChange={(s) => setChartSize("error-count", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis {...DT_AXIS_PROPS} allowDecimals={false} label={{ value: 'errors', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip cursor={DT_CURSOR_PROPS} contentStyle={DT_TOOLTIP_STYLE} />
                <Bar dataKey="errors" name="Errors" fill={DT_COLORS.red} fillOpacity={0.7} barSize={4} radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer></div>
          </CollapsibleChart>

          <CollapsibleChart
            title="Error Rate vs Throughput"
            icon={<GitCompare className="w-4 h-4" style={{ color: DT_COLORS.red }} />}
            collapsed={isCollapsed("error-vs-tpt")}
            onToggleCollapse={() => toggleChart("error-vs-tpt")}
            size={getSize("error-vs-tpt")}
            onSizeChange={(s) => setChartSize("error-vs-tpt", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis yAxisId="left" {...DT_AXIS_PROPS} label={{ value: '%', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} label={{ value: 'req/s', angle: 90, position: 'insideRight', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip
                  cursor={DT_CURSOR_PROPS}
                  content={<DynatraceTooltip hiddenSeries={legendErrors.hiddenSeries} metrics={[
                    { key: 'errorRate', label: 'Error Rate', unit: '%', color: DT_COLORS.errorRate, decimals: 2 },
                    { key: 'rps', label: 'Throughput', unit: 'req/s', color: DT_COLORS.throughput, decimals: 1 },
                  ]} />}
                />
                {legendErrors.isVisible('errorRate') && <Area yAxisId="left" type="monotone" dataKey="errorRate" name="Error Rate" stroke={DT_COLORS.errorRate} strokeWidth={2} fill="url(#dt-grad-red)" dot={false} />}
                {legendErrors.isVisible('rps') && <Line yAxisId="right" type="monotone" dataKey="rps" name="Throughput" stroke={DT_COLORS.throughput} strokeWidth={2} dot={false} />}
              </ComposedChart>
            </ResponsiveContainer></div>
            <DtLegend
              items={[
                { key: 'errorRate', label: 'Error Rate (%)', color: DT_COLORS.errorRate },
                { key: 'rps', label: 'Throughput (req/s)', color: DT_COLORS.throughput },
              ]}
              hiddenSeries={legendErrors.hiddenSeries}
              onToggle={legendErrors.toggleSeries}
            />
          </CollapsibleChart>

          <CollapsibleChart
            title="Error Rate vs Threads"
            icon={<Users className="w-4 h-4" style={{ color: DT_COLORS.errorRate }} />}
            collapsed={isCollapsed("error-vs-threads")}
            onToggleCollapse={() => toggleChart("error-vs-threads")}
            size={getSize("error-vs-threads")}
            onSizeChange={(s) => setChartSize("error-vs-threads", s)}
          >
            <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} syncId="execution">
                <DynatraceGradients />
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis yAxisId="left" {...DT_AXIS_PROPS} domain={[0, 'auto']} label={{ value: '%', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} label={{ value: 'threads', angle: 90, position: 'insideRight', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                <Tooltip
                  cursor={DT_CURSOR_PROPS}
                  content={<DynatraceTooltip hiddenSeries={legendErrorThreads.hiddenSeries} metrics={[
                    { key: 'errorRate', label: 'Error Rate', unit: '%', color: DT_COLORS.errorRate, decimals: 2 },
                    { key: 'activeThreads', label: 'Active Threads', color: DT_COLORS.threads },
                  ]} />}
                />
                {legendErrorThreads.isVisible('errorRate') && <Area yAxisId="left" type="monotone" dataKey="errorRate" name="Error Rate" stroke={DT_COLORS.errorRate} strokeWidth={2} fill="url(#dt-grad-red)" dot={false} />}
                {legendErrorThreads.isVisible('activeThreads') && <Line yAxisId="right" type="stepAfter" dataKey="activeThreads" name="Active Threads" stroke={DT_COLORS.threads} strokeWidth={2} dot={false} />}
              </ComposedChart>
            </ResponsiveContainer></div>
            <DtLegend
              items={[
                { key: 'errorRate', label: 'Error Rate (%)', color: DT_COLORS.errorRate },
                { key: 'activeThreads', label: 'Active Threads', color: DT_COLORS.threads },
              ]}
              hiddenSeries={legendErrorThreads.hiddenSeries}
              onToggle={legendErrorThreads.toggleSeries}
            />
          </CollapsibleChart>
        </ChartGrid>
      )}
      </LazyChartSection>

      {/* SECTION 6: SYSTEM / RESOURCE METRICS */}
      <LazyChartSection>
      {(() => {
        const hasSysData = sysData.length > 0;
        return (
        <>
          <SectionHeader
            icon={<Cpu className="w-4 h-4" style={{ color: DT_COLORS.cpu }} />}
            title="System / Resource Metrics"
            collapsed={!!collapsedSections.system}
            onToggle={() => toggleSection('system')}
            count={hasSysData ? (hasDiskData ? 4 : 3) : 0}
          />
          {!collapsedSections.system && !hasSysData && (
            <div className="rounded-lg border border-border bg-card p-6 text-center text-sm text-muted-foreground">
              No load generator metrics available. System CPU and memory data is collected when tests run locally on PerfHub's JMeter engine or when remote agents send system metrics via the ingest API.
            </div>
          )}
          {!collapsedSections.system && hasSysData && (
            <ChartGrid columns={2}>
              <CollapsibleChart
                title="CPU Usage Over Time"
                icon={<Cpu className="w-4 h-4" style={{ color: DT_COLORS.cpu }} />}
                collapsed={isCollapsed("sys-cpu")}
                onToggleCollapse={() => toggleChart("sys-cpu")}
                size={getSize("sys-cpu")}
                onSizeChange={(s) => setChartSize("sys-cpu", s)}
              >
                <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={sysData} syncId="execution-sys">
                    <DynatraceGradients />
                    <CartesianGrid {...DT_GRID_PROPS} />
                    <XAxis dataKey="time" {...DT_AXIS_PROPS} />
                    <YAxis {...DT_AXIS_PROPS} domain={[0, 100]} label={{ value: '%', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                    <Tooltip
                      cursor={DT_CURSOR_PROPS}
                      content={<DynatraceTooltip hiddenSeries={legendSys.hiddenSeries} metrics={[
                        { key: 'cpuPercent', label: 'Host CPU', unit: '%', color: DT_COLORS.cpu, decimals: 1 },
                        { key: 'jmeterCpu', label: 'JMeter CPU', unit: '%', color: DT_COLORS.jmeterCpu, decimals: 1 },
                      ]} />}
                    />
                    {legendSys.isVisible('cpuPercent') && <Area type="monotone" dataKey="cpuPercent" name="Host CPU" stroke={DT_COLORS.cpu} fill="url(#dt-grad-orange)" strokeWidth={2} dot={false} />}
                    {legendSys.isVisible('jmeterCpu') && <Area type="monotone" dataKey="jmeterCpu" name="JMeter CPU" stroke={DT_COLORS.jmeterCpu} fill="url(#dt-grad-purple)" strokeWidth={2} dot={false} />}
                  </AreaChart>
                </ResponsiveContainer></div>
                <DtLegend
                  items={[
                    { key: 'cpuPercent', label: 'Host CPU %', color: DT_COLORS.cpu },
                    { key: 'jmeterCpu', label: 'JMeter CPU %', color: DT_COLORS.jmeterCpu },
                  ]}
                  hiddenSeries={legendSys.hiddenSeries}
                  onToggle={legendSys.toggleSeries}
                />
              </CollapsibleChart>

              <CollapsibleChart
                title="Memory Usage Over Time"
                icon={<MemoryStick className="w-4 h-4" style={{ color: DT_COLORS.memory }} />}
                collapsed={isCollapsed("sys-mem")}
                onToggleCollapse={() => toggleChart("sys-mem")}
                size={getSize("sys-mem")}
                onSizeChange={(s) => setChartSize("sys-mem", s)}
              >
                <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={sysData} syncId="execution-sys">
                    <DynatraceGradients />
                    <CartesianGrid {...DT_GRID_PROPS} />
                    <XAxis dataKey="time" {...DT_AXIS_PROPS} />
                    <YAxis yAxisId="left" {...DT_AXIS_PROPS} domain={[0, 100]} label={{ value: '%', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                    <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} label={{ value: 'MB', angle: 90, position: 'insideRight', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                    <Tooltip cursor={DT_CURSOR_PROPS} contentStyle={DT_TOOLTIP_STYLE} />
                    <Area yAxisId="left" type="monotone" dataKey="memPercent" name="Memory %" stroke={DT_COLORS.memory} fill="url(#dt-grad-primary)" strokeWidth={2} dot={false} />
                    <Line yAxisId="right" type="monotone" dataKey="jmeterMemMB" name="JMeter RSS (MB)" stroke={DT_COLORS.jmeterMem} strokeWidth={2} dot={false} />
                  </ComposedChart>
                </ResponsiveContainer></div>
              </CollapsibleChart>

              {hasDiskData && (
                <CollapsibleChart
                  title="Disk I/O"
                  icon={<HardDrive className="w-4 h-4" style={{ color: DT_COLORS.cyan }} />}
                  collapsed={isCollapsed("sys-disk")}
                  onToggleCollapse={() => toggleChart("sys-disk")}
                  size={getSize("sys-disk")}
                  onSizeChange={(s) => setChartSize("sys-disk", s)}
                >
                  <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={sysData} syncId="execution-sys">
                      <DynatraceGradients />
                      <CartesianGrid {...DT_GRID_PROPS} />
                      <XAxis dataKey="time" {...DT_AXIS_PROPS} />
                      <YAxis {...DT_AXIS_PROPS} label={{ value: 'MB/s', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                      <Tooltip cursor={DT_CURSOR_PROPS} contentStyle={DT_TOOLTIP_STYLE} />
                      <Area type="monotone" dataKey="diskReadMbps" name="Disk Read" stroke={DT_COLORS.primary} fill="url(#dt-grad-primary)" strokeWidth={2} dot={false} />
                      <Area type="monotone" dataKey="diskWriteMbps" name="Disk Write" stroke={DT_COLORS.orange} fill="url(#dt-grad-orange)" strokeWidth={2} dot={false} />
                    </AreaChart>
                  </ResponsiveContainer></div>
                </CollapsibleChart>
              )}

              <CollapsibleChart
                title="Concurrency & CPU Correlation"
                icon={<Activity className="w-4 h-4" style={{ color: DT_COLORS.threads }} />}
                collapsed={isCollapsed("sys-threads-cpu")}
                onToggleCollapse={() => toggleChart("sys-threads-cpu")}
                size={getSize("sys-threads-cpu")}
                onSizeChange={(s) => setChartSize("sys-threads-cpu", s)}
              >
                <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={data} syncId="execution">
                    <DynatraceGradients />
                    <CartesianGrid {...DT_GRID_PROPS} />
                    <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                    <YAxis yAxisId="left" {...DT_AXIS_PROPS} label={{ value: 'threads', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                    <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} domain={[0, 100]} label={{ value: 'CPU %', angle: 90, position: 'insideRight', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                    <Tooltip cursor={DT_CURSOR_PROPS} contentStyle={DT_TOOLTIP_STYLE} />
                    <Area yAxisId="left" type="stepAfter" dataKey="activeThreads" name="Active Threads" stroke={DT_COLORS.threads} fill="url(#dt-grad-teal)" strokeWidth={2} dot={false} />
                    {sysData.length > 0 && (() => {
                      const merged = data.map(d => {
                        const closest = sysData.reduce((best: any, s: any) => Math.abs(s.elapsed - d.elapsed) < Math.abs(best.elapsed - d.elapsed) ? s : best, sysData[0]);
                        return { ...d, cpuOverlay: closest?.cpuPercent || 0 };
                      });
                      return <Line yAxisId="right" type="monotone" data={merged} dataKey="cpuOverlay" name="Host CPU %" stroke={DT_COLORS.cpu} strokeWidth={1.5} dot={false} strokeDasharray="4 2" />;
                    })()}
                  </ComposedChart>
                </ResponsiveContainer></div>
              </CollapsibleChart>
            </ChartGrid>
          )}
        </>
        );
      })()}
      </LazyChartSection>

      {/* SECTION 8: DISTRIBUTED NODE METRICS */}
      {hasMultipleNodes && (
      <LazyChartSection>
          <SectionHeader
            icon={<Server className="w-4 h-4" style={{ color: DT_COLORS.indigo }} />}
            title="Distributed Node Metrics"
            collapsed={!!collapsedSections.distributed}
            onToggle={() => toggleSection('distributed')}
            count={2}
          />
          {!collapsedSections.distributed && (() => {
            const nodeDataMap: Record<string, any[]> = {};
            for (const nodeId of machineNodeIds) {
              const ts = machineMetrics[nodeId]?.timeseries || [];
              const firstTs = ts[0]?.ts || 0;
              nodeDataMap[nodeId] = ts.map((d: any) => ({
                time: formatElapsedLabel(Math.round((d.ts - firstTs) / 1000)),
                elapsed: Math.round((d.ts - firstTs) / 1000),
                cpuPercent: d.cpuPercent || 0,
                memPercent: d.memPercent || 0,
              }));
            }

            const maxLen = Math.max(...Object.values(nodeDataMap).map(a => a.length));
            const combinedCpu = [];
            const combinedMem = [];
            for (let i = 0; i < maxLen; i++) {
              const cpuRow: any = { time: '' };
              const memRow: any = { time: '' };
              for (const nodeId of machineNodeIds) {
                const d = nodeDataMap[nodeId]?.[i];
                if (d) {
                  cpuRow.time = d.time;
                  memRow.time = d.time;
                  cpuRow[nodeId] = d.cpuPercent;
                  memRow[nodeId] = d.memPercent;
                }
              }
              if (cpuRow.time) combinedCpu.push(cpuRow);
              if (memRow.time) combinedMem.push(memRow);
            }

            return (
              <ChartGrid columns={2}>
                <CollapsibleChart
                  title="Node CPU Comparison"
                  icon={<Cpu className="w-4 h-4" style={{ color: DT_COLORS.cpu }} />}
                  collapsed={isCollapsed("node-cpu")}
                  onToggleCollapse={() => toggleChart("node-cpu")}
                  size={getSize("node-cpu")}
                  onSizeChange={(s) => setChartSize("node-cpu", s)}
                >
                  <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
                    <LineChart data={combinedCpu} syncId="nodes">
                      <DynatraceGradients />
                      <CartesianGrid {...DT_GRID_PROPS} />
                      <XAxis dataKey="time" {...DT_AXIS_PROPS} />
                      <YAxis {...DT_AXIS_PROPS} domain={[0, 100]} label={{ value: '%', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                      <Tooltip cursor={DT_CURSOR_PROPS} contentStyle={DT_TOOLTIP_STYLE} />
                      {machineNodeIds.map((nodeId, i) => (
                        <Line key={nodeId} type="monotone" dataKey={nodeId} name={nodeId} stroke={DT_PALETTE[i % DT_PALETTE.length]} strokeWidth={2} dot={false} />
                      ))}
                    </LineChart>
                  </ResponsiveContainer></div>
                </CollapsibleChart>

                <CollapsibleChart
                  title="Node Memory Comparison"
                  icon={<MemoryStick className="w-4 h-4" style={{ color: DT_COLORS.memory }} />}
                  collapsed={isCollapsed("node-mem")}
                  onToggleCollapse={() => toggleChart("node-mem")}
                  size={getSize("node-mem")}
                  onSizeChange={(s) => setChartSize("node-mem", s)}
                >
                  <div className="flex-1 min-h-0"><ResponsiveContainer width="100%" height="100%">
                    <LineChart data={combinedMem} syncId="nodes">
                      <DynatraceGradients />
                      <CartesianGrid {...DT_GRID_PROPS} />
                      <XAxis dataKey="time" {...DT_AXIS_PROPS} />
                      <YAxis {...DT_AXIS_PROPS} domain={[0, 100]} label={{ value: '%', angle: -90, position: 'insideLeft', style: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' } }} />
                      <Tooltip cursor={DT_CURSOR_PROPS} contentStyle={DT_TOOLTIP_STYLE} />
                      {machineNodeIds.map((nodeId, i) => (
                        <Line key={nodeId} type="monotone" dataKey={nodeId} name={nodeId} stroke={DT_PALETTE[i % DT_PALETTE.length]} strokeWidth={2} dot={false} />
                      ))}
                    </LineChart>
                  </ResponsiveContainer></div>
                </CollapsibleChart>
              </ChartGrid>
            );
          })()}
      </LazyChartSection>
      )}

    </div>
  );
}
