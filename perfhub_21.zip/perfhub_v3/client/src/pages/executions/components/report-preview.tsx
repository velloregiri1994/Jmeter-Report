import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, EyeOff, Maximize2, Minimize2, ExternalLink } from "lucide-react";

interface ReportPreviewProps {
  reportHtmlPath: string;
  reportPreviewExpanded: boolean;
  setReportPreviewExpanded: (expanded: boolean) => void;
  setShowReportPreview: (show: boolean) => void;
}

export function ReportPreview({ reportHtmlPath, reportPreviewExpanded, setReportPreviewExpanded, setShowReportPreview }: ReportPreviewProps) {
  return (
    <Card className="card-shadow overflow-hidden">
      <CardHeader className="py-3 px-4 bg-gradient-to-r from-indigo-500/10 via-purple-500/5 to-transparent border-b flex flex-row items-center justify-between space-y-0">
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-indigo-500" />
          <CardTitle className="text-sm font-medium">Report Preview</CardTitle>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2"
            onClick={() => setReportPreviewExpanded(!reportPreviewExpanded)}
          >
            {reportPreviewExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2"
            onClick={() => window.open(reportHtmlPath, '_blank')}
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2"
            onClick={() => setShowReportPreview(false)}
          >
            <EyeOff className="w-3.5 h-3.5" />
          </Button>
        </div>
      </CardHeader>
      <div className="relative bg-white">
        <iframe
          src={reportHtmlPath}
          className="w-full border-0"
          style={{ height: reportPreviewExpanded ? '80vh' : '500px' }}
          sandbox="allow-same-origin allow-scripts"
          title="Report Preview"
        />
      </div>
    </Card>
  );
}
