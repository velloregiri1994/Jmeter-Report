import React from "react";

interface MetricConfig {
  key: string;
  label: string;
  unit?: string;
  color: string;
  decimals?: number;
}

interface DynatraceTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
  metrics: MetricConfig[];
  hiddenSeries?: Set<string>;
}

export function DynatraceTooltip({ active, payload, label, metrics, hiddenSeries }: DynatraceTooltipProps) {
  if (!active || !payload?.length) return null;
  const data = payload[0]?.payload;
  if (!data) return null;

  const visibleMetrics = hiddenSeries
    ? metrics.filter(m => !hiddenSeries.has(m.key))
    : metrics;

  return (
    <div className="rounded-md border bg-card text-card-foreground shadow-lg text-xs min-w-[200px] overflow-hidden">
      <div className="px-3 py-1.5 border-b bg-muted/30 flex items-center justify-between gap-4">
        <span className="font-semibold text-foreground">{data.time}</span>
        {data.absoluteTime && (
          <span className="text-[10px] text-muted-foreground font-mono">{data.absoluteTime}</span>
        )}
      </div>
      <div className="py-1">
        {visibleMetrics.map((m) => {
          const raw = data[m.key];
          if (raw === undefined || raw === null) return null;
          const val = m.decimals !== undefined ? Number(raw).toFixed(m.decimals) : Math.floor(raw);
          return (
            <div key={m.key} className="flex items-center justify-between gap-6 px-3 py-[3px] hover:bg-muted/20 transition-colors">
              <span className="flex items-center gap-2">
                <span
                  className="inline-block w-[3px] h-3.5 rounded-sm flex-shrink-0"
                  style={{ backgroundColor: m.color }}
                />
                <span className="text-muted-foreground">{m.label}</span>
              </span>
              <span className="font-mono font-semibold tabular-nums text-foreground">
                {val}{m.unit ? <span className="text-muted-foreground font-normal ml-0.5">{m.unit}</span> : ''}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
