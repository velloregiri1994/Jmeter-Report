import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageSquare, Send, ShieldCheck, CheckCircle } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { format } from "date-fns";

interface CommentsSectionProps {
  execution: any;
  commentText: string;
  setCommentText: (text: string) => void;
  handleCommentSubmit: (type: 'comment' | 'sign-off') => void;
  isPending: boolean;
}

export function CommentsSection({ execution, commentText, setCommentText, handleCommentSubmit, isPending }: CommentsSectionProps) {
  return (
    <Card className="card-shadow overflow-hidden">
      <CardHeader className="bg-muted/30 border-b">
        <CardTitle className="flex items-center gap-2 text-base">
          <MessageSquare className="w-5 h-5 text-primary" />
          Comments & Notes
        </CardTitle>
        <CardDescription>
          Team collaboration and test documentation
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {execution.comments && execution.comments.length > 0 ? (
          <div className="space-y-3">
            {execution.comments.map((comment: any) => (
              <div key={comment.id} className="flex gap-3 p-3 rounded-lg bg-muted/30 border">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="text-xs bg-primary/10 text-primary">
                    {comment.user?.username?.substring(0, 2).toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{comment.user?.username || 'User'}</span>
                    <span className="text-xs text-muted-foreground">
                      {comment.createdAt ? format(new Date(comment.createdAt), "PP p") : ''}
                    </span>
                    {comment.type === 'sign-off' && (
                      <span className="text-xs bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 px-2 py-0.5 rounded">
                        <CheckCircle className="w-3 h-3 inline mr-1" />
                        Sign-off
                      </span>
                    )}
                  </div>
                  <p className="text-sm mt-1">{comment.content}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-muted-foreground">
            <MessageSquare className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p>No comments yet. Be the first to add a note!</p>
          </div>
        )}

        <Separator />

        <div className="space-y-3">
          <Textarea 
            placeholder="Add a comment or note about this test execution..."
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            className="min-h-[80px]"
          />
          <div className="flex gap-2">
            <Button 
              onClick={() => handleCommentSubmit('comment')}
              disabled={isPending || !commentText.trim()}
              size="sm"
            >
              <Send className="w-4 h-4 mr-2" />
              {isPending ? "Posting..." : "Add Comment"}
            </Button>
            <Button 
              variant="outline"
              onClick={() => handleCommentSubmit('sign-off')}
              disabled={isPending || !commentText.trim()}
              size="sm"
            >
              <ShieldCheck className="w-4 h-4 mr-2" />
              Sign-off
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
