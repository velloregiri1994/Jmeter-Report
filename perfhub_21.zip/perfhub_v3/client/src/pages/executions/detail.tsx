import { useExecution, useAddComment } from "@/hooks/use-executions";
import { useAuth } from "@/hooks/use-auth";
import { useRoute, useLocation } from "wouter";
import { queryKeys } from "@/lib/query-keys";
import { StatusBadge } from "@/components/status-badge";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { XCircle, Download, FileText, RotateCw, Loader2, Trash2, Eye, EyeOff, ExternalLink, Target, Tag, Check, X } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { format } from "date-fns";
import { useState, useMemo, useRef } from "react";


import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { BarChart2, Filter, Globe, Zap, GitBranch, Server, Radio, MessageSquare, Layers } from "lucide-react";

import { filterTimeseriesClientSide, toPercent, formatHMS, parseHMS, DetailSkeleton } from "./components/detail-utils";
import { ResultBox } from "./components/results-summary";
import { BaselineComparisonCard } from "./components/baseline-comparison";
import { SlaViolationsCard } from "./components/sla-violations";
import { TransactionDetailsTable } from "./components/transaction-details-table";
import { UnifiedCharts } from "./components/unified-charts";
import { ErrorDetailsTable } from "./components/error-details-table";
import { CommentsSection } from "./components/comments-section";
import { ReportPreview } from "./components/report-preview";
import { AnomalyDetectionPanel } from "./components/anomaly-detection-panel";
import { WorkloadAchievementPanel } from "./components/workload-achievement-panel";
import { ExecutionWorkloadTargetsDialog } from "@/components/execution-workload-targets-dialog";
import { useLiveSnapshot } from "./components/use-live-snapshot";

export default function ExecutionDetail() {
  const { canWrite } = useAuth();
  const [, params] = useRoute("/executions/:id");
  const id = parseInt(params?.id || "0");
  const { data: execution, isLoading, isError, error, refetch } = useExecution(id);
  const { mutate: addComment, isPending } = useAddComment();
  const [commentText, setCommentText] = useState("");
  const [timeFilter, setTimeFilter] = useState<"all" | "1m" | "5m" | "10m" | "15m" | "30m" | "1h" | "first5m" | "first15m" | "first30m" | "custom">("all");
  
  const [customRange, setCustomRange] = useState<{ start: number; end: number } | null>(null);
  const [showReportPreview, setShowReportPreview] = useState(false);
  const [reportPreviewExpanded, setReportPreviewExpanded] = useState(false);
  const [showWorkloadTargetsDialog, setShowWorkloadTargetsDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const rerunMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/executions/${id}/rerun`);
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Test re-queued", description: "A new execution has been created with the same settings." });
      queryClient.invalidateQueries({ queryKey: queryKeys.executions.all });
      if (data.execution?.id) {
        setLocation(`/executions/${data.execution.id}`);
      }
    },
    onError: (error: Error) => {
      toast({ title: "Re-run failed", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/executions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (q) => String(q.queryKey[0]).includes("/api/executions") });
      toast({ title: "Execution deleted" });
      setLocation("/executions");
    },
    onError: (err: Error) => {
      toast({ title: "Delete failed", description: err.message, variant: "destructive" });
    },
  });

  const fullResults = (execution?.resultSummary as any) || {};
  const hasMetrics = !!(fullResults?.totalRequests > 0);

  const filterParams = useMemo(() => {
    if (timeFilter === "all") return null;
    if (timeFilter === "custom" && customRange) {
      return { start: customRange.start, end: customRange.end };
    }
    const parseMs = (v: any) => {
      if (!v) return null;
      if (typeof v === 'number') return v;
      const ms = new Date(v).getTime();
      return isNaN(ms) ? null : ms;
    };
    const testStartMs = parseMs(fullResults?.startTime) || parseMs(execution?.startTime);
    const testEndMs = parseMs(fullResults?.endTime) || parseMs(execution?.endTime);
    if (!testStartMs || !testEndMs) return null;

    const durationMap: Record<string, number> = {
      "1m": 1, "5m": 5, "10m": 10, "15m": 15, "30m": 30, "1h": 60,
      "first5m": 5, "first15m": 15, "first30m": 30,
    };
    const mins = durationMap[timeFilter];
    if (!mins) return null;

    if (timeFilter.startsWith("first")) {
      const endMs = Math.min(testStartMs + mins * 60 * 1000, testEndMs);
      return { start: testStartMs, end: endMs };
    }
    const startMs = Math.max(testEndMs - mins * 60 * 1000, testStartMs);
    return { start: startMs, end: testEndMs };
  }, [timeFilter, customRange, fullResults?.endTime, fullResults?.startTime, execution?.startTime, execution?.endTime]);

  const isTerminalForMetrics = !!execution && ["completed", "failed", "cancelled", "aborted"].includes(execution.status);

  const { data: dbMetrics } = useQuery({
    queryKey: [...queryKeys.executions.filteredMetrics(String(id), "full")],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", `/api/executions/${id}/filtered-metrics`);
        return res.json();
      } catch {
        return null;
      }
    },
    enabled: isTerminalForMetrics && hasMetrics,
    staleTime: Infinity,
  });

  const { data: filteredData, isFetching: isFilterLoading } = useQuery({
    queryKey: [...queryKeys.executions.filteredMetrics(String(id), filterParams ? JSON.stringify(filterParams) : "")],
    queryFn: async () => {
      if (!filterParams) return null;
      const params = new URLSearchParams({
        start: String(filterParams.start),
        end: String(filterParams.end),
      });
      try {
        const res = await apiRequest("GET", `/api/executions/${id}/filtered-metrics?${params}`);
        return res.json();
      } catch {
        return filterTimeseriesClientSide(fullResults, filterParams.start, filterParams.end);
      }
    },
    enabled: filterParams !== null && !!execution && hasMetrics,
    staleTime: Infinity,
  });

  const enrichedFullResults = useMemo(() => {
    if (!dbMetrics?.timeseries?.length) return fullResults;
    return { ...fullResults, timeseries: dbMetrics.timeseries };
  }, [fullResults, dbMetrics]);

  const isRunning = execution?.status === "running";
  const isQueued = execution?.status === "queued";
  const isAborted = execution?.status === "aborted";
  const isTerminal = execution?.status === "completed" || execution?.status === "failed" || execution?.status === "cancelled" || isAborted;
  const { snapshot: liveSnapshot } = useLiveSnapshot(id, isRunning || isQueued);
  const { data: systemMetrics } = useQuery({
    queryKey: [...queryKeys.executions.systemMetrics(String(id))],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/executions/${id}/system-metrics`);
      return res.json();
    },
    enabled: !!execution && (isTerminal || isRunning),
    staleTime: isRunning ? 3000 : Infinity,
    refetchInterval: isRunning ? 5000 : false,
  });

  const cancelMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/executions/${id}/cancel`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Execution cancelled" });
      queryClient.invalidateQueries({ queryKey: queryKeys.executions.detail(id) });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  const [releaseTagOpen, setReleaseTagOpen] = useState(false);
  const [releaseTagInput, setReleaseTagInput] = useState("");
  const releaseTagInputRef = useRef<HTMLInputElement>(null);

  const { data: existingReleaseTags = [] } = useQuery<Array<{ id: number; name: string }>>({
    queryKey: [...queryKeys.releaseTags],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/release-tags");
      return res.json();
    },
    enabled: releaseTagOpen,
  });

  const releaseTagMutation = useMutation({
    mutationFn: async (releaseTag: string | null) => {
      const res = await apiRequest("PATCH", `/api/executions/${id}/release-tag`, { releaseTag });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.executions.detail(id) });
      queryClient.invalidateQueries({ queryKey: queryKeys.releaseTags });
      toast({ title: "Release tag updated" });
      setReleaseTagOpen(false);
    },
    onError: (err: Error) => {
      toast({ title: "Failed to update release tag", description: err.message, variant: "destructive" });
    },
  });

  const generateReportMutation = useMutation({
    mutationFn: async () => {
      const url = buildUrl(api.executions.generateReport.path, { id });
      const res = await apiRequest("POST", url);
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Success", description: "Report generated successfully" });
      queryClient.invalidateQueries({ queryKey: queryKeys.executions.detail(id) });
      window.open(data.url, '_blank');
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });



  const liveResults = useMemo(() => {
    if (!liveSnapshot?.summary) return null;
    const s = liveSnapshot.summary;
    const txs = liveSnapshot.allTransactions || [];
    const minRT = txs.length ? Math.min(...txs.map((t: any) => t.min || 0)) : 0;
    const maxRT = txs.length ? Math.max(...txs.map((t: any) => t.max || 0)) : 0;
    const totalCount = txs.reduce((sum: number, t: any) => sum + (t.count || 0), 0);
    const weightedP50 = totalCount > 0 ? txs.reduce((sum: number, t: any) => sum + (t.p50 || 0) * (t.count || 0), 0) / totalCount : 0;
    const weightedP90 = totalCount > 0 ? txs.reduce((sum: number, t: any) => sum + (t.p90 || 0) * (t.count || 0), 0) / totalCount : 0;
    return {
      totalRequests: s.totalRequests || 0,
      successfulRequests: (s.totalRequests || 0) - (s.totalErrors || 0),
      failedRequests: s.totalErrors || 0,
      errorRate: s.errorRate || 0,
      avgResponseTime: s.avgResponseTime || 0,
      minResponseTime: minRT,
      maxResponseTime: maxRT,
      throughput: s.throughput || 0,
      p50: weightedP50,
      p90: weightedP90,
      p95: s.p95 || 0,
      p99: s.p99 || 0,
      peakRps: (() => {
        const series = liveSnapshot?.series;
        if (series?.length) return Math.max(...series.map((p: any) => p.throughput || 0));
        return 0;
      })(),
      apdex: 0,
      transactionDetails: txs.map((tx: any) => ({
        label: tx.label,
        count: tx.count,
        avg: tx.avg,
        min: tx.min,
        max: tx.max,
        p50: tx.p50,
        p90: tx.p90,
        p95: tx.p95,
        p99: tx.p99,
        errorRate: tx.errorRate,
        errorCount: tx.errors,
        throughput: tx.throughput,
      })),
      timeseries: enrichedFullResults?.timeseries || [],
    };
  }, [liveSnapshot, enrichedFullResults]);

  if (isLoading) return <DetailSkeleton />;
  if (isError) return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load execution" />;
  if (!execution) return <div className="p-8 text-center text-muted-foreground">Execution not found</div>;

  const handleCommentSubmit = (type: 'comment' | 'sign-off') => {
    if (!commentText.trim()) return;
    addComment({
        executionId: id,
        content: commentText,
        type: type
    }, {
        onSuccess: () => {
          setCommentText("");
          toast({ title: "Success", description: type === 'sign-off' ? "Sign-off added" : "Comment added" });
        },
        onError: (error) => {
          toast({ title: "Error", description: error.message || "Failed to add comment", variant: "destructive" });
        }
    });
  };

  const isFiltered = timeFilter !== "all" && filteredData;

  const slaViolations = (execution as any).slaViolations as { perTransaction?: Array<{ label: string; metric: string; threshold: number; actual: number; comparator: string }> } | null;
  const baselineDeviation = (execution as any).baselineDeviation as { baselineExecutionId: number; global: any; overallRegression: boolean; regressionSeverity?: string; regressionDetails?: any[]; transactionDeviations?: any[]; thresholds?: Record<string, { warning: number; critical: number }> } | null;

  const executionId = (execution as any).executionId;

  const results = isFiltered
    ? {
        totalRequests: filteredData.summary.totalRequests,
        successfulRequests: filteredData.summary.totalRequests - filteredData.summary.errorCount,
        failedRequests: filteredData.summary.errorCount,
        errorRate: filteredData.summary.errorRate,
        avgResponseTime: filteredData.summary.avgResponseTime,
        minResponseTime: filteredData.summary.minResponseTime,
        maxResponseTime: filteredData.summary.maxResponseTime,
        throughput: filteredData.summary.throughput,
        p50: filteredData.summary.p50,
        p90: filteredData.summary.p90,
        p95: filteredData.summary.p95,
        p99: filteredData.summary.p99,
        peakRps: 0,
        apdex: 0,
        durationSeconds: filteredData.summary.durationSeconds,
        transactionDetails: filteredData.transactionDetails?.map((tx: any) => ({
          label: tx.label,
          count: tx.count,
          avg: tx.avg,
          min: tx.min,
          max: tx.max,
          p50: tx.p50,
          p90: tx.p90,
          p95: tx.p95,
          p99: tx.p99,
          errorRate: tx.errorRate,
          errorCount: tx.errorCount,
          throughput: tx.throughput,
        })),
        timeseries: filteredData.timeseries,
        startTime: filteredData.startTime,
        endTime: filteredData.endTime,
        errorDetails: [],
        errorSummary: [],
      }
    : (isRunning && liveResults ? liveResults : enrichedFullResults);

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <PageHeader
        title={execution.schedule?.name || (execution as any).testName || (execution.scheduleId ? 'Deleted Schedule' : 'Remote Execution')}
        subtitle={`${executionId || `#${execution.id}`} · Executed on ${execution.startTime ? format(new Date(execution.startTime), "PPpp") : "Pending"}`}
        actionsStacked
        actions={
          <>
            <StatusBadge status={execution.status} />
            {(() => {
              const protocol = (execution.schedule?.script as any)?.protocol || (execution as any).protocol;
              if (!protocol) return null;
              const protocolConfig: Record<string, { icon: typeof Globe; label: string; color: string }> = {
                http: { icon: Globe, label: "HTTP", color: "border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-400" },
                websocket: { icon: Zap, label: "WebSocket", color: "border-yellow-300 dark:border-yellow-700 text-yellow-700 dark:text-yellow-400" },
                graphql: { icon: GitBranch, label: "GraphQL", color: "border-pink-300 dark:border-pink-700 text-pink-700 dark:text-pink-400" },
                grpc: { icon: Server, label: "gRPC", color: "border-green-300 dark:border-green-700 text-green-700 dark:text-green-400" },
                mqtt: { icon: Radio, label: "MQTT", color: "border-purple-300 dark:border-purple-700 text-purple-700 dark:text-purple-400" },
                jms: { icon: MessageSquare, label: "JMS", color: "border-orange-300 dark:border-orange-700 text-orange-700 dark:text-orange-400" },
                mixed: { icon: Layers, label: "Mixed", color: "border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-400" },
              };
              const cfg = protocolConfig[protocol] || protocolConfig.http;
              const Icon = cfg.icon;
              return (
                <Badge variant="outline" className={`gap-1 text-xs px-2 py-1 ${cfg.color}`}>
                  <Icon className="w-3 h-3" />
                  {cfg.label}
                </Badge>
              );
            })()}
            <Popover open={releaseTagOpen} onOpenChange={(open) => {
              setReleaseTagOpen(open);
              if (open) setReleaseTagInput((execution as any).releaseTag || "");
            }}>
              <PopoverTrigger asChild>
                {(execution as any).releaseTag ? (
                  <Badge variant="outline" className="cursor-pointer hover:bg-muted gap-1 text-xs px-2 py-1 border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-400">
                    <Tag className="w-3 h-3" />
                    {(execution as any).releaseTag}
                  </Badge>
                ) : (
                  <Badge variant="outline" className="cursor-pointer hover:bg-muted gap-1 text-xs px-2 py-1 text-muted-foreground">
                    <Tag className="w-3 h-3" />
                    Add Release Tag
                  </Badge>
                )}
              </PopoverTrigger>
              <PopoverContent className="w-64 p-3" align="start">
                <div className="space-y-2">
                  <p className="text-xs font-medium text-muted-foreground">Release / Build Tag</p>
                  <div className="flex gap-1.5">
                    <Input
                      ref={releaseTagInputRef}
                      value={releaseTagInput}
                      onChange={(e) => setReleaseTagInput(e.target.value)}
                      placeholder="e.g. v2.1.0, Sprint 42"
                      className="h-8 text-sm"
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          releaseTagMutation.mutate(releaseTagInput.trim() || null);
                        }
                      }}
                    />
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => releaseTagMutation.mutate(releaseTagInput.trim() || null)} disabled={releaseTagMutation.isPending}>
                      <Check className="w-4 h-4" />
                    </Button>
                  </div>
                  {existingReleaseTags.length > 0 && (
                    <div className="space-y-1 max-h-32 overflow-y-auto">
                      {existingReleaseTags
                        .filter(t => !releaseTagInput || t.name.toLowerCase().includes(releaseTagInput.toLowerCase()))
                        .map(tag => (
                          <button
                            key={tag.id}
                            type="button"
                            className="w-full text-left text-xs px-2 py-1 rounded hover:bg-muted truncate"
                            onClick={() => {
                              setReleaseTagInput(tag.name);
                              releaseTagMutation.mutate(tag.name);
                            }}
                          >
                            {tag.name}
                          </button>
                        ))
                      }
                    </div>
                  )}
                  {(execution as any).releaseTag && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="w-full h-7 text-xs text-muted-foreground hover:text-destructive"
                      onClick={() => releaseTagMutation.mutate(null)}
                      disabled={releaseTagMutation.isPending}
                    >
                      <X className="w-3 h-3 mr-1" /> Remove Tag
                    </Button>
                  )}
                </div>
              </PopoverContent>
            </Popover>
            {(execution.status === 'completed' || execution.status === 'failed' || execution.status === 'cancelled' || execution.status === 'aborted') && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => rerunMutation.mutate()}
                disabled={rerunMutation.isPending}
              >
                {rerunMutation.isPending ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Re-running...</>
                ) : (
                  <><RotateCw className="w-4 h-4 mr-2" /> Re-run</>
                )}
              </Button>
            )}
            {(execution.status === 'running' || execution.status === 'queued') && (
              <Button 
                variant="destructive" 
                size="sm" 
                onClick={() => cancelMutation.mutate()}
                disabled={cancelMutation.isPending}
              >
                <XCircle className="w-4 h-4 mr-2" /> {cancelMutation.isPending ? "Cancelling..." : "Cancel Execution"}
              </Button>
            )}
            {canWrite && (execution.status === 'completed' || execution.status === 'failed' || execution.status === 'cancelled' || execution.status === 'aborted') && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive">
                    <Trash2 className="w-4 h-4 mr-2" /> Delete
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Execution</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently delete this execution and its associated data. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => deleteMutation.mutate()} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowWorkloadTargetsDialog(true)}
              className="text-purple-600 border-purple-200 dark:border-purple-800 hover:bg-purple-50 dark:hover:bg-purple-900/20"
            >
              <Target className="w-4 h-4 mr-2" /> Workload Targets
            </Button>
            {execution.reportHtmlPath ? (
              <>
                <Button
                  variant={showReportPreview ? "default" : "outline"}
                  size="sm"
                  onClick={() => setShowReportPreview(!showReportPreview)}
                >
                  {showReportPreview ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                  {showReportPreview ? "Hide Preview" : "Preview Report"}
                </Button>
                <Button variant="outline" size="sm" onClick={() => window.open(execution.reportHtmlPath!, '_blank')}>
                  <ExternalLink className="w-4 h-4 mr-2" /> Open Report
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={async () => {
                    try {
                      const response = await fetch(execution.reportHtmlPath!);
                      const blob = await response.blob();
                      const url = window.URL.createObjectURL(blob);
                      const link = document.createElement('a');
                      link.href = url;
                      link.download = `report-${executionId || execution.id}.html`;
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                      window.URL.revokeObjectURL(url);
                    } catch (error) {
                      console.error('Download failed:', error);
                    }
                  }}
                >
                  <Download className="w-4 h-4 mr-2" /> Download
                </Button>
              </>
            ) : canWrite ? (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => {
                  generateReportMutation.mutate(undefined, {
                    onSuccess: () => setShowReportPreview(true),
                  });
                }}
                disabled={generateReportMutation.isPending}
              >
                <FileText className="w-4 h-4 mr-2" /> {generateReportMutation.isPending ? "Generating..." : "Generate Report"}
              </Button>
            ) : null}
          </>
        }
      />

      {showReportPreview && execution.reportHtmlPath && (
        <ReportPreview
          reportHtmlPath={execution.reportHtmlPath}
          reportPreviewExpanded={reportPreviewExpanded}
          setReportPreviewExpanded={setReportPreviewExpanded}
          setShowReportPreview={setShowReportPreview}
        />
      )}

      



      {isAborted && (
        <Card className="border-orange-500/50 bg-orange-50 dark:bg-orange-900/10">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-orange-700 dark:text-orange-400">
              <XCircle className="w-5 h-5" />
              Test Auto-Aborted
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {fullResults?.abortReason && (
                <p className="text-sm text-orange-800 dark:text-orange-300">{fullResults.abortReason}</p>
              )}
              {!fullResults?.abortReason && (
                <p className="text-sm text-orange-800 dark:text-orange-300">This execution was automatically stopped due to a threshold breach.</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 gap-6">
         <div className="space-y-6">

            {!isRunning && <SlaViolationsCard slaViolations={slaViolations} />}

            {!isRunning && baselineDeviation && <BaselineComparisonCard baselineDeviation={baselineDeviation} />}

            {!isRunning && hasMetrics && (() => {
              const parseMsUI = (v: any) => { if (!v) return 0; if (typeof v === 'number') return v; const ms = new Date(v).getTime(); return isNaN(ms) ? 0 : ms; };
              const testStartMs = parseMsUI(fullResults?.startTime) || parseMsUI(execution?.startTime);
              const testEndMs = parseMsUI(fullResults?.endTime) || parseMsUI(execution?.endTime);
              const testDurationSec = testStartMs && testEndMs ? Math.round((testEndMs - testStartMs) / 1000) : 0;
              const testDurationMin = testDurationSec / 60;
              if (!testStartMs || !testEndMs) return null;

              const lastPresets = [
                { key: "1m" as const, label: "Last 1m", mins: 1 },
                { key: "5m" as const, label: "Last 5m", mins: 5 },
                { key: "15m" as const, label: "Last 15m", mins: 15 },
                { key: "30m" as const, label: "Last 30m", mins: 30 },
                { key: "1h" as const, label: "Last 1h", mins: 60 },
              ].filter(p => p.mins <= testDurationMin);

              const firstPresets = [
                { key: "first5m" as const, label: "First 5m", mins: 5 },
                { key: "first15m" as const, label: "First 15m", mins: 15 },
                { key: "first30m" as const, label: "First 30m", mins: 30 },
              ].filter(p => p.mins <= testDurationMin);

              return (
                <Card className="card-shadow overflow-hidden">
                  <CardHeader className="pb-3 bg-gradient-to-r from-primary/5 via-primary/2 to-transparent border-b">
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2 text-base">
                        <Filter className="w-4 h-4 text-primary" />
                        Time Range Filter
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        {isFilterLoading && (
                          <span className="flex items-center gap-1.5 text-xs text-primary animate-pulse">
                            <Loader2 className="w-3 h-3 animate-spin" />
                            Recalculating...
                          </span>
                        )}
                        {isFiltered && !isFilterLoading && (
                          <span className="text-xs font-medium text-primary bg-primary/10 px-2.5 py-1 rounded-full">
                            {filteredData.bucketCount}/{filteredData.totalBuckets} buckets · {formatHMS(Math.round(filteredData.summary.durationSeconds))} window
                          </span>
                        )}
                        <span className="text-xs text-muted-foreground">
                          Total: {formatHMS(testDurationSec)}
                        </span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="space-y-3">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <Button
                          size="sm"
                          variant={timeFilter === "all" ? "default" : "outline"}
                          onClick={() => setTimeFilter("all")}
                          className="text-xs h-8"
                        >
                          Entire Test
                        </Button>
                        {lastPresets.length > 0 && (
                          <>
                            <span className="text-xs text-muted-foreground px-1">|</span>
                            {lastPresets.map((p) => (
                              <Button
                                key={p.key}
                                size="sm"
                                variant={timeFilter === p.key ? "default" : "outline"}
                                onClick={() => setTimeFilter(p.key)}
                                className="text-xs h-8"
                              >
                                {p.label}
                              </Button>
                            ))}
                          </>
                        )}
                        {firstPresets.length > 0 && (
                          <>
                            <span className="text-xs text-muted-foreground px-1">|</span>
                            {firstPresets.map((p) => (
                              <Button
                                key={p.key}
                                size="sm"
                                variant={timeFilter === p.key ? "default" : "outline"}
                                onClick={() => setTimeFilter(p.key)}
                                className="text-xs h-8"
                              >
                                {p.label}
                              </Button>
                            ))}
                          </>
                        )}
                      </div>
                      <div className="flex items-center gap-2 pt-1 border-t border-border/40">
                        <span className="text-xs font-medium text-muted-foreground">Custom:</span>
                        <div className="flex items-center gap-1.5">
                          <label className="text-xs text-muted-foreground">From</label>
                          <input
                            type="text"
                            className="w-20 h-7 text-xs px-2 rounded-md border bg-background font-mono focus:ring-1 focus:ring-primary/50 focus:border-primary/50 outline-none"
                            placeholder="00:00:00"
                            onChange={(e) => {
                              const sec = parseHMS(e.target.value);
                              if (sec === null) return;
                              const s = Math.max(testStartMs, Math.min(testStartMs + sec * 1000, testEndMs));
                              const end = customRange?.end || testEndMs;
                              setCustomRange({ start: Math.min(s, end), end: Math.max(s, end) });
                              setTimeFilter("custom");
                            }}
                          />
                          <label className="text-xs text-muted-foreground">To</label>
                          <input
                            type="text"
                            className="w-20 h-7 text-xs px-2 rounded-md border bg-background font-mono focus:ring-1 focus:ring-primary/50 focus:border-primary/50 outline-none"
                            placeholder={formatHMS(testDurationSec)}
                            onChange={(e) => {
                              const sec = parseHMS(e.target.value);
                              if (sec === null) return;
                              const end = Math.max(testStartMs, Math.min(testStartMs + sec * 1000, testEndMs));
                              const start = customRange?.start || testStartMs;
                              setCustomRange({ start: Math.min(start, end), end: Math.max(start, end) });
                              setTimeFilter("custom");
                            }}
                          />
                        </div>
                        {timeFilter !== "all" && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => { setTimeFilter("all"); setCustomRange(null); }}
                            className="text-xs h-7 text-muted-foreground hover:text-foreground"
                          >
                            <RotateCw className="w-3 h-3 mr-1" /> Reset
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })()}

            {(results?.totalRequests > 0 || (isRunning && liveSnapshot?.summary)) && (
            <Card className="card-shadow overflow-hidden">
               <CardHeader className="bg-muted/30 border-b">
                  <CardTitle className="flex items-center justify-between text-base">
                    <span className="flex items-center gap-2">
                      <BarChart2 className="w-5 h-5 text-primary" />
                      Results Summary
                      {isRunning && <span className="text-xs font-normal text-primary bg-primary/10 px-2 py-1 rounded animate-pulse">Live</span>}
                    </span>
                    {isFiltered && (
                      <span className="text-xs font-normal text-amber-500 bg-amber-500/10 px-2 py-1 rounded">Filtered View</span>
                    )}
                  </CardTitle>
               </CardHeader>
               <CardContent className="pt-5">
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 2xl:grid-cols-6 gap-3 sm:gap-4">
                    <ResultBox 
                      label="Total Requests" 
                      value={(results?.totalRequests || 0).toLocaleString()} 
                      gradient="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-500/15"
                    />
                    <ResultBox 
                      label="Successful" 
                      value={(results?.successfulRequests || 0).toLocaleString()} 
                      color="text-emerald-500" 
                      gradient="bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border-emerald-500/15"
                    />
                    <ResultBox 
                      label="Failed" 
                      value={(results?.failedRequests || 0).toLocaleString()} 
                      color="text-rose-500" 
                      gradient="bg-gradient-to-br from-rose-500/10 to-rose-600/5 border-rose-500/15"
                    />
                    <ResultBox 
                      label="Error Rate" 
                      value={`${toPercent(results?.errorRate).toFixed(2)}%`} 
                      color={toPercent(results?.errorRate) > 5 ? "text-rose-500" : "text-emerald-500"}
                      gradient={toPercent(results?.errorRate) > 5 ? "bg-gradient-to-br from-rose-500/10 to-rose-600/5 border-rose-500/15" : "bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border-emerald-500/15"}
                    />
                    <ResultBox 
                      label="Avg Response" 
                      value={`${Math.floor(results?.avgResponseTime || 0)}ms`} 
                      gradient="bg-gradient-to-br from-amber-500/10 to-amber-600/5 border-amber-500/15"
                    />
                    <ResultBox 
                      label="Throughput" 
                      value={`${(results?.throughput || 0).toFixed(2)}/sec`} 
                      gradient="bg-gradient-to-br from-cyan-500/10 to-cyan-600/5 border-cyan-500/15"
                    />
                    <ResultBox 
                      label="Peak RPS" 
                      value={(results?.peakRps || 0).toLocaleString()} 
                      color="text-blue-500" 
                      gradient="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-500/15"
                    />
                    <ResultBox 
                      label="Min Response" 
                      value={`${Math.floor(results?.minResponseTime || 0)}ms`} 
                    />
                    <ResultBox 
                      label="Max Response" 
                      value={`${Math.floor(results?.maxResponseTime || 0)}ms`} 
                    />
                    <ResultBox 
                      label="P50 (Median)" 
                      value={`${Math.floor(results?.p50 || 0)}ms`} 
                      gradient="bg-gradient-to-br from-cyan-500/10 to-cyan-600/5 border-cyan-500/15"
                    />
                    <ResultBox 
                      label="P90" 
                      value={`${Math.floor(results?.p90 || 0)}ms`} 
                      gradient="bg-gradient-to-br from-violet-500/10 to-violet-600/5 border-violet-500/15"
                    />
                    <ResultBox 
                      label="P95" 
                      value={`${Math.floor(results?.p95 || 0)}ms`} 
                      gradient="bg-gradient-to-br from-violet-500/10 to-violet-600/5 border-violet-500/15"
                    />
                    <ResultBox 
                      label="APDEX" 
                      value={(results?.apdex || 0).toFixed(3)} 
                      color={(results?.apdex || 0) >= 0.9 ? "text-emerald-500" : (results?.apdex || 0) >= 0.7 ? "text-amber-500" : "text-rose-500"}
                    />
                  </div>
               </CardContent>
            </Card>
            )}

            {(hasMetrics || (isRunning && liveSnapshot?.allTransactions?.length)) && <TransactionDetailsTable results={results} />}

            {(hasMetrics || isRunning || isQueued) && (results?.timeseries?.length > 0 || liveSnapshot?.series?.length) && (
              <UnifiedCharts
                results={results}
                systemMetrics={systemMetrics}
                liveSnapshot={liveSnapshot}
                isLive={isRunning || isQueued}
                executionId={id}
              />
            )}

            {!isRunning && hasMetrics && <WorkloadAchievementPanel executionId={id} />}

            {hasMetrics && <AnomalyDetectionPanel executionId={id} isLive={isRunning} />}

            {!isRunning && hasMetrics && <ErrorDetailsTable results={results} />}

            <CommentsSection
              execution={execution}
              commentText={commentText}
              setCommentText={setCommentText}
              handleCommentSubmit={handleCommentSubmit}
              isPending={isPending}
            />
         </div>
      </div>

      {execution && (
        <ExecutionWorkloadTargetsDialog
          executionId={id}
          executionName={execution.schedule?.name || (execution as any).testName || `Execution #${id}`}
          open={showWorkloadTargetsDialog}
          onOpenChange={setShowWorkloadTargetsDialog}
        />
      )}
    </div>
  );
}
