import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { LayoutTemplate, Plus, MoreVertical, Copy, Trash2, Star, StarOff, Pencil, Layers, ClipboardCheck } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";

type TemplateSection = {
  id: string;
  type: 'builtin' | 'custom';
  key?: string;
  title: string;
  defaultContent?: string;
  enabled: boolean;
};

type ReportTemplate = {
  id: number;
  name: string;
  description: string | null;
  sections: TemplateSection[];
  isDefault: boolean;
  createdBy: number;
  createdAt: string;
  updatedAt: string;
};

export default function ReportTemplatesPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const { data: templates, isLoading } = useQuery<ReportTemplate[]>({
    queryKey: ["/api/report-templates"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/report-templates");
      return res.json();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/report-templates/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/report-templates"] });
      toast({ title: "Template deleted" });
      setDeleteId(null);
    },
  });

  const duplicateMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/report-templates/${id}/duplicate`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/report-templates"] });
      toast({ title: "Template duplicated" });
    },
  });

  const setDefaultMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("PATCH", `/api/report-templates/${id}/default`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/report-templates"] });
      toast({ title: "Default template updated" });
    },
  });

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <PageHeader
        title="Report Templates"
        subtitle="Design reusable report layouts with configurable sections for sign-off reports"
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2" onClick={() => navigate("/completion-reports")}>
              <Layers className="h-4 w-4" />
              Sign-Off Reports
            </Button>
            <Button className="gap-2" onClick={() => navigate("/report-templates/new")}>
              <Plus className="h-4 w-4" />
              Create Template
            </Button>
          </div>
        }
      />

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-48 rounded-xl" />
          ))}
        </div>
      ) : !templates || templates.length === 0 ? (
        <EmptyState
          icon={LayoutTemplate}
          title="No Report Templates"
          description="Create a template to standardize your sign-off report layouts. Templates define which sections appear and in what order."
          action={
            <Button className="gap-2" onClick={() => navigate("/report-templates/new")}>
              <Plus className="h-4 w-4" />
              Create Your First Template
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {templates.map(template => {
            const enabledSections = template.sections.filter(s => s.enabled);
            const builtinCount = enabledSections.filter(s => s.type === 'builtin').length;
            const customCount = enabledSections.filter(s => s.type === 'custom').length;

            return (
              <Card key={template.id} className="group hover:shadow-lg transition-all duration-200 hover:border-primary/30">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-base flex items-center gap-2">
                        <LayoutTemplate className="h-4 w-4 text-primary shrink-0" />
                        <span className="truncate">{template.name}</span>
                        {template.isDefault && (
                          <Badge className="bg-amber-500 text-white text-[10px] shrink-0">Default</Badge>
                        )}
                      </CardTitle>
                      {template.description && (
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{template.description}</p>
                      )}
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => navigate(`/report-templates/${template.id}`)}>
                          <Pencil className="h-4 w-4 mr-2" /> Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => duplicateMutation.mutate(template.id)}>
                          <Copy className="h-4 w-4 mr-2" /> Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setDefaultMutation.mutate(template.id)}>
                          {template.isDefault ? <StarOff className="h-4 w-4 mr-2" /> : <Star className="h-4 w-4 mr-2" />}
                          {template.isDefault ? "Remove Default" : "Set as Default"}
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive" onClick={() => setDeleteId(template.id)}>
                          <Trash2 className="h-4 w-4 mr-2" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-1.5">
                      {enabledSections.slice(0, 5).map(s => (
                        <Badge key={s.id} variant="outline" className="text-[10px]">
                          {s.title}
                        </Badge>
                      ))}
                      {enabledSections.length > 5 && (
                        <Badge variant="outline" className="text-[10px]">+{enabledSections.length - 5} more</Badge>
                      )}
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1">
                          <Layers className="h-3 w-3" />
                          {enabledSections.length} sections
                        </span>
                        {customCount > 0 && (
                          <span>{customCount} custom</span>
                        )}
                      </div>
                      <span>{format(new Date(template.createdAt), 'MMM d, yyyy')}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <AlertDialog open={deleteId !== null} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Template</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this report template. Existing reports created from this template will not be affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleteId && deleteMutation.mutate(deleteId)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
