import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLocation, useParams } from "wouter";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { PageHeader } from "@/components/page-header";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, type DragEndEvent, DragOverlay
} from "@dnd-kit/core";
import {
  arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy, useSortable
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  GripVertical, Plus, Trash2, Save, ArrowLeft, Eye, EyeOff, LayoutTemplate, FileText, BarChart3,
  ShieldCheck, GitCompare, List, AlignLeft, Target, Settings, Pencil, X, Check, Info,
  CheckCircle2, Sparkles, BookOpen, type LucideIcon
} from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter
} from "@/components/ui/dialog";

type TemplateSection = {
  id: string;
  type: 'builtin' | 'custom';
  key?: string;
  title: string;
  defaultContent?: string;
  enabled: boolean;
};

const BUILTIN_SECTIONS: TemplateSection[] = [
  { id: 'builtin_executive_summary', type: 'builtin', key: 'executive_summary', title: 'Executive Summary', enabled: true },
  { id: 'builtin_objective', type: 'builtin', key: 'objective', title: 'Objective', enabled: true },
  { id: 'builtin_scope', type: 'builtin', key: 'scope', title: 'Scope', enabled: true },
  { id: 'builtin_environment_notes', type: 'builtin', key: 'environment_notes', title: 'Environment Notes', enabled: true },
  { id: 'builtin_test_results', type: 'builtin', key: 'test_results', title: 'Test Results', enabled: true },
  { id: 'builtin_sla_compliance', type: 'builtin', key: 'sla_compliance', title: 'SLA Compliance', enabled: true },
  { id: 'builtin_transactions', type: 'builtin', key: 'transactions', title: 'Transaction Breakdown', enabled: true },
  { id: 'builtin_run_comparison', type: 'builtin', key: 'run_comparison', title: 'Run Comparison', enabled: true },
  { id: 'builtin_recommendations', type: 'builtin', key: 'recommendations', title: 'Recommendations', enabled: true },
];

const SECTION_META: Record<string, { icon: LucideIcon; description: string; color: string }> = {
  executive_summary: { icon: FileText, description: "High-level overview of test results, key findings, and go/no-go recommendation", color: "text-blue-600 dark:text-blue-400" },
  objective: { icon: Target, description: "Purpose and goals of the performance test execution", color: "text-violet-600 dark:text-violet-400" },
  scope: { icon: BookOpen, description: "Test scenarios, transaction mix, and workload model coverage", color: "text-indigo-600 dark:text-indigo-400" },
  environment_notes: { icon: Settings, description: "Infrastructure details, configuration, and environment specifications", color: "text-slate-600 dark:text-slate-400" },
  test_results: { icon: BarChart3, description: "Aggregated metrics — throughput, response times, error rates, and percentiles", color: "text-emerald-600 dark:text-emerald-400" },
  sla_compliance: { icon: ShieldCheck, description: "Service level agreement validation with pass/fail status per rule", color: "text-amber-600 dark:text-amber-400" },
  transactions: { icon: List, description: "Per-transaction breakdown with individual metrics and status", color: "text-cyan-600 dark:text-cyan-400" },
  run_comparison: { icon: GitCompare, description: "Side-by-side comparison with baseline run showing deltas", color: "text-orange-600 dark:text-orange-400" },
  recommendations: { icon: AlignLeft, description: "Action items, tuning suggestions, and next steps", color: "text-rose-600 dark:text-rose-400" },
};

function SortableSectionCard({
  section,
  index,
  onToggle,
  onRemove,
  onEdit,
}: {
  section: TemplateSection;
  index: number;
  onToggle: () => void;
  onRemove?: () => void;
  onEdit?: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: section.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
    zIndex: isDragging ? 50 : undefined,
  };

  const meta = section.key ? SECTION_META[section.key] : null;
  const IconComponent = meta?.icon || Sparkles;
  const iconColor = meta?.color || "text-primary";

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`group relative flex items-start gap-3 p-3.5 rounded-xl border-2 transition-all duration-200 ${
        section.enabled
          ? 'bg-card border-border hover:border-primary/30 hover:shadow-sm'
          : 'bg-muted/20 border-dashed border-muted-foreground/15'
      } ${isDragging ? 'shadow-xl ring-2 ring-primary/20' : ''}`}
    >
      <div className="flex items-center gap-2 pt-0.5">
        <span className={`text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
          section.enabled
            ? 'bg-primary/10 text-primary'
            : 'bg-muted text-muted-foreground'
        }`}>
          {index + 1}
        </span>
        <div
          {...attributes}
          {...listeners}
          className="flex items-center justify-center cursor-grab active:cursor-grabbing p-1 rounded-md hover:bg-muted/80 transition-colors shrink-0"
        >
          <GripVertical className="h-4 w-4 text-muted-foreground/60" />
        </div>
      </div>

      <div className={`flex items-center justify-center h-8 w-8 rounded-lg shrink-0 ${
        section.enabled ? 'bg-primary/8' : 'bg-muted'
      }`}>
        <IconComponent className={`h-4 w-4 ${section.enabled ? iconColor : 'text-muted-foreground/50'}`} />
      </div>

      <div className="flex-1 min-w-0 pt-0.5">
        <div className="flex items-center gap-2">
          <span className={`text-sm font-semibold ${!section.enabled ? 'text-muted-foreground line-through' : ''}`}>
            {section.title}
          </span>
          <Badge variant={section.type === 'builtin' ? 'secondary' : 'outline'} className="text-[9px] px-1.5 py-0 h-4 font-medium">
            {section.type === 'builtin' ? 'Auto-generated' : 'Custom'}
          </Badge>
        </div>
        {meta && section.enabled && (
          <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{meta.description}</p>
        )}
        {!meta && section.defaultContent && section.enabled && (
          <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed line-clamp-1">{section.defaultContent}</p>
        )}
      </div>

      <div className="flex items-center gap-1.5 shrink-0 pt-0.5">
        {section.type === 'custom' && onEdit && (
          <TooltipProvider delayDuration={300}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" onClick={onEdit}>
                  <Pencil className="h-3.5 w-3.5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top"><p>Edit section</p></TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
        <Switch checked={section.enabled} onCheckedChange={onToggle} className="scale-[0.85]" />
        {section.type === 'custom' && onRemove && (
          <TooltipProvider delayDuration={300}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive" onClick={onRemove}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top"><p>Remove section</p></TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>
    </div>
  );
}

export default function ReportTemplateBuilder() {
  const params = useParams<{ id: string }>();
  const isEditing = params.id && params.id !== 'new';
  const templateId = isEditing ? parseInt(params.id!) : null;

  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [sections, setSections] = useState<TemplateSection[]>([...BUILTIN_SECTIONS]);
  const [isDefault, setIsDefault] = useState(false);
  const [initialized, setInitialized] = useState(false);

  const [customDialogOpen, setCustomDialogOpen] = useState(false);
  const [editingSection, setEditingSection] = useState<TemplateSection | null>(null);
  const [customTitle, setCustomTitle] = useState("");
  const [customContent, setCustomContent] = useState("");

  const [showPreview, setShowPreview] = useState(true);

  const { data: templateData, isLoading } = useQuery({
    queryKey: ["/api/report-templates", templateId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/report-templates/${templateId}`);
      return res.json();
    },
    enabled: !!templateId,
  });

  useEffect(() => {
    if (templateData && !initialized) {
      setName(templateData.name);
      setDescription(templateData.description || "");
      setSections(templateData.sections);
      setIsDefault(templateData.isDefault);
      setInitialized(true);
    }
  }, [templateData, initialized]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload = { name, description: description || undefined, sections, isDefault };
      if (templateId) {
        const res = await apiRequest("PATCH", `/api/report-templates/${templateId}`, payload);
        return res.json();
      } else {
        const res = await apiRequest("POST", "/api/report-templates", payload);
        return res.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/report-templates"] });
      toast({ title: templateId ? "Template updated" : "Template created" });
      navigate("/completion-reports");
    },
    onError: (err: any) => {
      toast({ title: "Error saving template", description: err.message, variant: "destructive" });
    },
  });

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    setSections(prev => {
      const oldIndex = prev.findIndex(s => s.id === active.id);
      const newIndex = prev.findIndex(s => s.id === over.id);
      return arrayMove(prev, oldIndex, newIndex);
    });
  }

  function toggleSection(id: string) {
    setSections(prev => prev.map(s => s.id === id ? { ...s, enabled: !s.enabled } : s));
  }

  function removeSection(id: string) {
    setSections(prev => prev.filter(s => s.id !== id));
  }

  function openAddCustom() {
    setEditingSection(null);
    setCustomTitle("");
    setCustomContent("");
    setCustomDialogOpen(true);
  }

  function openEditCustom(section: TemplateSection) {
    setEditingSection(section);
    setCustomTitle(section.title);
    setCustomContent(section.defaultContent || "");
    setCustomDialogOpen(true);
  }

  function saveCustomSection() {
    if (!customTitle.trim()) return;

    if (editingSection) {
      setSections(prev => prev.map(s =>
        s.id === editingSection.id
          ? { ...s, title: customTitle.trim(), defaultContent: customContent.trim() || undefined }
          : s
      ));
    } else {
      const newSection: TemplateSection = {
        id: `custom_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        type: 'custom',
        title: customTitle.trim(),
        defaultContent: customContent.trim() || undefined,
        enabled: true,
      };
      setSections(prev => [...prev, newSection]);
    }
    setCustomDialogOpen(false);
  }

  function enableAll() {
    setSections(prev => prev.map(s => ({ ...s, enabled: true })));
  }

  function disableAll() {
    setSections(prev => prev.map(s => ({ ...s, enabled: false })));
  }

  const enabledSections = sections.filter(s => s.enabled);
  const disabledSections = sections.filter(s => !s.enabled);
  const builtinCount = enabledSections.filter(s => s.type === 'builtin').length;
  const customCount = enabledSections.filter(s => s.type === 'custom').length;
  const canSave = name.trim().length > 0 && sections.length > 0;

  if (isEditing && isLoading) {
    return (
      <div className="space-y-6 max-w-6xl mx-auto">
        <Skeleton className="h-10 w-64" />
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <div className="lg:col-span-3 space-y-4">
            <Skeleton className="h-44 rounded-xl" />
            <Skeleton className="h-96 rounded-xl" />
          </div>
          <div className="lg:col-span-2">
            <Skeleton className="h-[500px] rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <PageHeader
        title={isEditing ? "Edit Template" : "Create Report Template"}
        subtitle="Design a reusable layout for your sign-off reports"
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2" onClick={() => navigate("/completion-reports")}>
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
            <Button variant="outline" className="gap-2" onClick={() => setShowPreview(!showPreview)}>
              {showPreview ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              {showPreview ? "Hide Preview" : "Preview"}
            </Button>
            <Button className="gap-2" disabled={!canSave || saveMutation.isPending} onClick={() => saveMutation.mutate()}>
              <Save className="h-4 w-4" />
              {saveMutation.isPending ? "Saving..." : "Save Template"}
            </Button>
          </div>
        }
      />

      <div className={`grid ${showPreview ? 'grid-cols-1 lg:grid-cols-5' : 'grid-cols-1 max-w-3xl'} gap-6`}>
        <div className={`space-y-6 ${showPreview ? 'lg:col-span-3' : ''}`}>
          <Card className="shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-base flex items-center gap-2">
                <div className="h-6 w-6 rounded-md bg-primary/10 flex items-center justify-center">
                  <LayoutTemplate className="h-3.5 w-3.5 text-primary" />
                </div>
                Template Details
              </CardTitle>
              <CardDescription>Set the name and description for this template</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Template Name <span className="text-destructive">*</span></Label>
                <Input id="name" placeholder="e.g., Standard Load Test Report" value={name} onChange={e => setName(e.target.value)} className="text-base" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Description</Label>
                <Textarea id="description" placeholder="Describe when to use this template and what type of tests it covers..." value={description} onChange={e => setDescription(e.target.value)} rows={2} />
              </div>
              <Separator />
              <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/50">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-amber-100 dark:bg-amber-900/40 flex items-center justify-center">
                    <Sparkles className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Default Template</p>
                    <p className="text-[11px] text-muted-foreground">Auto-apply this template when creating new reports</p>
                  </div>
                </div>
                <Switch id="default" checked={isDefault} onCheckedChange={setIsDefault} />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    <div className="h-6 w-6 rounded-md bg-primary/10 flex items-center justify-center">
                      <List className="h-3.5 w-3.5 text-primary" />
                    </div>
                    Report Sections
                  </CardTitle>
                  <CardDescription className="mt-1">Drag to reorder, toggle to enable or disable. Sections appear in the order shown.</CardDescription>
                </div>
                <Button variant="outline" size="sm" className="gap-1.5 shrink-0" onClick={openAddCustom}>
                  <Plus className="h-3.5 w-3.5" />
                  Add Custom Section
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center gap-4 flex-1">
                  <div className="flex items-center gap-1.5 text-xs">
                    <div className="h-2 w-2 rounded-full bg-emerald-500"></div>
                    <span className="text-muted-foreground">{enabledSections.length} active</span>
                  </div>
                  {disabledSections.length > 0 && (
                    <div className="flex items-center gap-1.5 text-xs">
                      <div className="h-2 w-2 rounded-full bg-muted-foreground/30"></div>
                      <span className="text-muted-foreground">{disabledSections.length} disabled</span>
                    </div>
                  )}
                  <Separator orientation="vertical" className="h-3" />
                  <div className="flex items-center gap-1.5 text-xs">
                    <span className="text-muted-foreground">{builtinCount} built-in</span>
                  </div>
                  {customCount > 0 && (
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="text-muted-foreground">{customCount} custom</span>
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={enableAll}>Enable All</Button>
                  <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={disableAll}>Disable All</Button>
                </div>
              </div>

              <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                <SortableContext items={sections.map(s => s.id)} strategy={verticalListSortingStrategy}>
                  <div className="space-y-2">
                    {sections.map((section, idx) => (
                      <SortableSectionCard
                        key={section.id}
                        section={section}
                        index={idx}
                        onToggle={() => toggleSection(section.id)}
                        onRemove={section.type === 'custom' ? () => removeSection(section.id) : undefined}
                        onEdit={section.type === 'custom' ? () => openEditCustom(section) : undefined}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>

              {sections.length === 0 && (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground border-2 border-dashed rounded-xl">
                  <LayoutTemplate className="h-10 w-10 mb-3 opacity-30" />
                  <p className="text-sm font-medium">No sections added yet</p>
                  <p className="text-xs mt-1">Add built-in or custom sections to build your template</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {showPreview && (
          <div className="lg:col-span-2">
            <div className="sticky top-4 space-y-4">
              <Card className="shadow-sm border-primary/20">
                <CardHeader className="pb-3 bg-gradient-to-r from-primary/5 to-transparent rounded-t-lg">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Eye className="h-4 w-4 text-primary" />
                    Document Preview
                  </CardTitle>
                  <CardDescription>How the report layout will appear</CardDescription>
                </CardHeader>
                <CardContent>
                  {enabledSections.length === 0 ? (
                    <div className="flex flex-col items-center py-8 text-muted-foreground">
                      <EyeOff className="h-8 w-8 mb-2 opacity-30" />
                      <p className="text-sm">Enable sections to see the preview</p>
                    </div>
                  ) : (
                    <div className="space-y-0">
                      <div className="border rounded-lg overflow-hidden">
                        <div className="bg-gradient-to-r from-primary/10 to-primary/5 p-4 border-b">
                          <div className="h-3 w-48 bg-primary/20 rounded mb-2"></div>
                          <div className="h-2 w-32 bg-primary/10 rounded"></div>
                        </div>

                        <div className="divide-y">
                          {enabledSections.map((section, idx) => {
                            const meta = section.key ? SECTION_META[section.key] : null;
                            const IconComponent = meta?.icon || Sparkles;
                            const iconColor = meta?.color || "text-primary";
                            return (
                              <div key={section.id} className="px-4 py-3 hover:bg-muted/30 transition-colors">
                                <div className="flex items-center gap-2.5">
                                  <span className="text-[10px] font-bold text-muted-foreground/60 w-4 text-right">{idx + 1}.</span>
                                  <IconComponent className={`h-3.5 w-3.5 shrink-0 ${iconColor}`} />
                                  <span className="text-sm font-medium">{section.title}</span>
                                </div>
                                {section.type === 'builtin' && (
                                  <div className="ml-[34px] mt-1.5 space-y-1">
                                    <div className="h-1.5 w-full bg-muted rounded-full"></div>
                                    <div className="h-1.5 w-4/5 bg-muted rounded-full"></div>
                                    <div className="h-1.5 w-3/5 bg-muted rounded-full"></div>
                                  </div>
                                )}
                                {section.type === 'custom' && section.defaultContent && (
                                  <p className="ml-[34px] mt-1 text-[11px] text-muted-foreground italic line-clamp-2">{section.defaultContent}</p>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="shadow-sm">
                <CardContent className="p-4">
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div>
                      <div className="text-2xl font-bold text-primary">{enabledSections.length}</div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">Sections</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{builtinCount}</div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">Built-in</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{customCount}</div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">Custom</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>

      <Dialog open={customDialogOpen} onOpenChange={setCustomDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="h-7 w-7 rounded-md bg-primary/10 flex items-center justify-center">
                <Sparkles className="h-4 w-4 text-primary" />
              </div>
              {editingSection ? "Edit Custom Section" : "Add Custom Section"}
            </DialogTitle>
            <DialogDescription>
              Custom sections let you add free-text areas to your report template. You can optionally set default content that will be pre-filled when the template is used.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Section Title <span className="text-destructive">*</span></Label>
              <Input placeholder="e.g., Database Performance Findings" value={customTitle} onChange={e => setCustomTitle(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Default Content</Label>
              <Textarea
                placeholder="Pre-fill this section with default text that can be edited when creating a report..."
                value={customContent}
                onChange={e => setCustomContent(e.target.value)}
                rows={5}
                className="text-sm"
              />
              <div className="flex items-start gap-2 p-2.5 rounded-md bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800/40">
                <Info className="h-3.5 w-3.5 text-blue-500 mt-0.5 shrink-0" />
                <p className="text-[11px] text-blue-700 dark:text-blue-300 leading-relaxed">
                  Default content will be pre-filled when this template is applied. Report authors can edit or replace it.
                </p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCustomDialogOpen(false)}>Cancel</Button>
            <Button onClick={saveCustomSection} disabled={!customTitle.trim()} className="gap-1.5">
              {editingSection ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
              {editingSection ? "Update Section" : "Add Section"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
