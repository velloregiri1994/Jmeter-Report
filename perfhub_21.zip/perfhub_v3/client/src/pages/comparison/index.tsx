import { useState, useMemo } from "react";
import { useExecutions, useExecution } from "@/hooks/use-executions";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  ArrowRight, ArrowDown, ArrowUp, Minus,
  Scale, ArrowLeftRight, Activity, Clock,
  AlertTriangle, Zap, BarChart3, Layers, Users,
  ChevronDown, ChevronUp, RefreshCw, TrendingUp, Tag
} from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Skeleton } from "@/components/ui/skeleton";
import { QueryErrorFallback } from "@/components/error-boundary";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip,
  ResponsiveContainer, Legend, BarChart, Bar, RadarChart, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis, Radar, AreaChart, Area, ScatterChart,
  Scatter, ZAxis, Cell, ReferenceLine
} from "recharts";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS, DT_PALETTE, DT_TOOLTIP_STYLE, DynatraceGradients } from "@/components/charts/dynatrace-theme";

function formatNum(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(1) + "K";
  return n.toLocaleString();
}

function VarianceChip({ diff, percent, inverted = false }: { diff: number; percent: string; inverted?: boolean }) {
  const isBetter = inverted ? diff < 0 : diff > 0;
  const isNeutral = diff === 0;

  if (isNeutral) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-muted text-muted-foreground">
        <Minus className="w-3 h-3" /> 0%
      </span>
    );
  }

  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
      isBetter
        ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
        : 'bg-rose-500/15 text-rose-600 dark:text-rose-400'
    }`}>
      {diff > 0 ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
      {diff > 0 ? '+' : ''}{percent}%
    </span>
  );
}

function MetricCard({ label, icon: Icon, valA, valB, unit, higherIsBetter, color, delay }: {
  label: string;
  icon: any;
  valA: number;
  valB: number;
  unit: string;
  higherIsBetter: boolean;
  color: string;
  delay: number;
}) {
  const diff = valB - valA;
  const percent = valA !== 0 ? ((diff / valA) * 100).toFixed(1) : "0";
  const isBetter = higherIsBetter ? diff > 0 : diff < 0;
  const isNeutral = diff === 0;

  const barMaxVal = Math.max(valA, valB) || 1;
  const barA = (valA / barMaxVal) * 100;
  const barB = (valB / barMaxVal) * 100;

  const colorMap: Record<string, string> = {
    blue: 'from-blue-500/20 to-blue-600/5 border-blue-500/20',
    amber: 'from-amber-500/20 to-amber-600/5 border-amber-500/20',
    rose: 'from-rose-500/20 to-rose-600/5 border-rose-500/20',
    emerald: 'from-emerald-500/20 to-emerald-600/5 border-emerald-500/20',
  };
  const iconColorMap: Record<string, string> = {
    blue: 'text-blue-500',
    amber: 'text-amber-500',
    rose: 'text-rose-500',
    emerald: 'text-emerald-500',
  };

  return (
    <div
      className={`relative rounded-xl border bg-gradient-to-br ${colorMap[color]} p-5 transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5`}
      style={{ animationName: 'fadeSlideIn', animationDuration: '0.4s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: `${delay}ms` }}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className={`p-1.5 rounded-lg bg-background/80 ${iconColorMap[color]}`}>
            <Icon className="w-4 h-4" />
          </div>
          <span className="text-sm font-semibold text-muted-foreground">{label}</span>
        </div>
        <VarianceChip diff={diff} percent={percent} inverted={!higherIsBetter} />
      </div>

      <div className="space-y-3">
        <div className="flex items-end justify-between">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground/70 font-bold mb-0.5">Baseline</div>
            <div className="text-xl font-bold tabular-nums">{formatNum(Math.round(valA))}<span className="text-xs font-normal text-muted-foreground ml-1">{unit}</span></div>
          </div>
          <div className="text-right">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground/70 font-bold mb-0.5">Compare</div>
            <div className="text-xl font-bold tabular-nums">{formatNum(Math.round(valB))}<span className="text-xs font-normal text-muted-foreground ml-1">{unit}</span></div>
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-blue-500 w-3">A</span>
            <div className="flex-1 h-2 bg-background/60 rounded-full overflow-hidden">
              <div className="h-full rounded-full bg-blue-500/70 transition-all duration-700" style={{ width: `${barA}%` }} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-violet-500 w-3">B</span>
            <div className="flex-1 h-2 bg-background/60 rounded-full overflow-hidden">
              <div className={`h-full rounded-full transition-all duration-700 ${
                isNeutral ? 'bg-muted-foreground/40' : isBetter ? 'bg-emerald-500/70' : 'bg-rose-500/70'
              }`} style={{ width: `${barB}%` }} />
            </div>
          </div>
        </div>
      </div>

      <div className={`absolute bottom-0 left-0 right-0 h-1 rounded-b-xl ${
        isNeutral ? 'bg-muted-foreground/20' : isBetter ? 'bg-emerald-500/40' : 'bg-rose-500/40'
      }`} />
    </div>
  );
}

function TransactionRow({ txA, txB, index, presence }: { txA: any; txB: any; index: number; presence: 'both' | 'only-a' | 'only-b' }) {
  const [expanded, setExpanded] = useState(false);
  const isOnlyA = presence === 'only-a';
  const isOnlyB = presence === 'only-b';
  const isUnmatched = isOnlyA || isOnlyB;

  const label = txA?.label || txB?.label;
  const avgA = txA?.avg || 0;
  const avgB = txB?.avg || 0;
  const avgVariance = presence === 'both' ? avgB - avgA : 0;
  const p90Variance = presence === 'both' ? (txB?.p90 || 0) - (txA?.p90 || 0) : 0;
  const p95Variance = presence === 'both' ? (txB?.p95 || 0) - (txA?.p95 || 0) : 0;
  const errDiff = presence === 'both' ? (txB?.errorRate || 0) - (txA?.errorRate || 0) : 0;

  const avgPercent = avgA !== 0 ? ((avgVariance / avgA) * 100).toFixed(1) : "0";
  const isRegression = avgVariance > 0 || p90Variance > 0 || p95Variance > 0;

  const barColor = isUnmatched ? 'bg-sky-500' : isRegression ? 'bg-rose-500' : 'bg-emerald-500';

  return (
    <div
      className={`border rounded-lg overflow-hidden transition-all duration-200 hover:shadow-md ${isUnmatched ? 'border-sky-500/30' : ''}`}
      style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: `${index * 60}ms` }}
    >
      <button
        className={`w-full flex items-center gap-3 p-4 text-left transition-colors ${
          expanded ? 'bg-muted/40' : 'hover:bg-muted/20'
        } ${isUnmatched ? 'bg-sky-500/5' : ''}`}
        onClick={() => setExpanded(!expanded)}
      >
        <div className={`w-1 h-10 rounded-full flex-shrink-0 ${barColor}`} />

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-sm truncate">{label}</span>
            {isOnlyA && <span className="flex-shrink-0 text-[9px] font-semibold px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-600 dark:text-blue-400">Only in A</span>}
            {isOnlyB && <span className="flex-shrink-0 text-[9px] font-semibold px-1.5 py-0.5 rounded bg-violet-500/15 text-violet-600 dark:text-violet-400">Only in B</span>}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            {isOnlyB ? `${avgB}ms avg` : `${avgA}ms avg`}
            {presence === 'both' && <span className="mx-1.5 text-muted-foreground/40">vs</span>}
            {presence === 'both' && <span>{avgB}ms avg</span>}
          </div>
        </div>

        <div className="flex items-center gap-3 flex-shrink-0">
          {presence === 'both' && (
            <VarianceChip diff={avgVariance} percent={avgPercent} inverted={true} />
          )}
          {isUnmatched && (
            <Badge variant="outline" className="text-xs border-sky-500/30 text-sky-600 dark:text-sky-400">Unmatched</Badge>
          )}
          {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
        </div>
      </button>

      {expanded && (
        <div className="border-t bg-muted/10 p-4">
          {isUnmatched ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="space-y-1">
                <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground/70">Avg Response</div>
                <div className="text-lg font-bold tabular-nums">{Math.round(isOnlyA ? avgA : avgB)}<span className="text-xs text-muted-foreground ml-1">ms</span></div>
              </div>
              <div className="space-y-1">
                <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground/70">P90 Latency</div>
                <div className="text-lg font-bold tabular-nums">{Math.round(isOnlyA ? (txA?.p90 || 0) : (txB?.p90 || 0))}<span className="text-xs text-muted-foreground ml-1">ms</span></div>
              </div>
              <div className="space-y-1">
                <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground/70">P95 Latency</div>
                <div className="text-lg font-bold tabular-nums">{Math.round(isOnlyA ? (txA?.p95 || 0) : (txB?.p95 || 0))}<span className="text-xs text-muted-foreground ml-1">ms</span></div>
              </div>
              <div className="space-y-1">
                <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground/70">Error Rate</div>
                <div className={`text-lg font-bold tabular-nums ${((isOnlyA ? txA?.errorRate : txB?.errorRate) || 0) * 100 > 0 ? 'text-rose-500' : 'text-emerald-600'}`}>
                  {(((isOnlyA ? txA?.errorRate : txB?.errorRate) || 0) * 100).toFixed(2)}%
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <MetricDetail label="Avg Response" valA={txA.avg} valB={txB.avg} unit="ms" inverted />
              <MetricDetail label="P90 Latency" valA={txA.p90} valB={txB.p90} unit="ms" inverted />
              <MetricDetail label="P95 Latency" valA={txA.p95} valB={txB.p95} unit="ms" inverted />
              <div className="space-y-1">
                <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground/70">Error Rate</div>
                <div className="flex items-baseline gap-2">
                  <span className={`text-lg font-bold tabular-nums ${(txA.errorRate || 0) * 100 > 0 ? 'text-rose-500' : 'text-emerald-600'}`}>
                    {((txA.errorRate || 0) * 100).toFixed(2)}%
                  </span>
                  <ArrowRight className="w-3 h-3 text-muted-foreground/40" />
                  <span className={`text-lg font-bold tabular-nums ${(txB.errorRate || 0) * 100 > 0 ? 'text-rose-500' : 'text-emerald-600'}`}>
                    {((txB.errorRate || 0) * 100).toFixed(2)}%
                  </span>
                </div>
                {errDiff !== 0 && (
                  <div className={`text-xs font-semibold ${errDiff > 0 ? 'text-rose-500' : 'text-emerald-600'}`}>
                    {errDiff > 0 ? '+' : ''}{errDiff.toFixed(2)}pp
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function MetricDetail({ label, valA, valB, unit, inverted }: { label: string; valA: number; valB: number; unit: string; inverted?: boolean }) {
  const diff = valB - valA;
  const percent = valA !== 0 ? ((diff / valA) * 100).toFixed(1) : "0";

  return (
    <div className="space-y-1">
      <div className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground/70">{label}</div>
      <div className="flex items-baseline gap-2">
        <span className="text-lg font-bold tabular-nums">{Math.round(valA)}</span>
        <ArrowRight className="w-3 h-3 text-muted-foreground/40" />
        <span className="text-lg font-bold tabular-nums">{Math.round(valB)}</span>
        <span className="text-xs text-muted-foreground">{unit}</span>
      </div>
      <VarianceChip diff={diff} percent={percent} inverted={inverted} />
    </div>
  );
}

const CHART_TOOLTIP_STYLE = DT_TOOLTIP_STYLE;
const CHART_LABEL_STYLE = { fontWeight: 600, marginBottom: 4, color: "hsl(var(--foreground))" };

function ChartCard({ icon: Icon, iconColor, title, gradientFrom, gradientTo, children, className }: {
  icon: any; iconColor: string; title: string; gradientFrom: string; gradientTo: string; children: React.ReactNode; className?: string;
}) {
  return (
    <Card className={`overflow-hidden border border-border/40 shadow-lg ${className || ''}`}>
      <CardHeader className={`bg-gradient-to-r ${gradientFrom} ${gradientTo} border-b pb-3 pt-4 px-5`}>
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <div className={`p-1.5 rounded-md ${iconColor.replace('text-', 'bg-').replace('500', '500/10')}`}>
            <Icon className={`w-4 h-4 ${iconColor}`} />
          </div>
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">{children}</CardContent>
    </Card>
  );
}

function RegressionHeatmap({ testA, testB }: { testA: any; testB: any }) {
  const [sortBy, setSortBy] = useState<string>("avgDelta");
  const [sortAsc, setSortAsc] = useState(false);

  const txData = useMemo(() => {
    const txAList = testA.resultSummary?.transactionDetails || [];
    const txBList = testB.resultSummary?.transactionDetails || [];
    if (txAList.length === 0 && txBList.length === 0) return [];

    const aLabels = new Set(txAList.map((t: any) => t.label));
    const bLabels = new Set(txBList.map((t: any) => t.label));

    const buildRow = (a: any, b: any, presence: 'both' | 'only-a' | 'only-b') => {
      const avgA = a?.avg || 0;
      const avgB = b?.avg || 0;
      const avgDelta = avgB - avgA;
      const p90A = a?.p90 || 0;
      const p90B = b?.p90 || 0;
      const p90Delta = p90B - p90A;
      const p95A = a?.p95 || 0;
      const p95B = b?.p95 || 0;
      const p95Delta = p95B - p95A;
      const p99A = a?.p99 || 0;
      const p99B = b?.p99 || 0;
      const p99Delta = p99B - p99A;
      const tpsA = a?.throughput || a?.hitsPerSec || 0;
      const tpsB = b?.throughput || b?.hitsPerSec || 0;
      const tpsDelta = tpsB - tpsA;
      const errA = (a?.errorRate || 0) * 100;
      const errB = (b?.errorRate || 0) * 100;
      const errDelta = errB - errA;
      const avgPct = avgA ? ((avgDelta / avgA) * 100) : 0;
      const p95Pct = p95A ? ((p95Delta / p95A) * 100) : 0;
      return {
        label: a?.label || b?.label,
        avgA, avgB, avgDelta, avgPct,
        p90A, p90B, p90Delta,
        p95A, p95B, p95Delta, p95Pct,
        p99A, p99B, p99Delta,
        tpsA, tpsB, tpsDelta,
        errA, errB, errDelta,
        severity: presence !== 'both' ? 'unmatched' as const :
          Math.abs(avgPct) > 20 || Math.abs(p95Pct) > 30 ? 'critical' as const :
          Math.abs(avgPct) > 10 || Math.abs(p95Pct) > 15 ? 'warning' as const : 'ok' as const,
        matched: presence === 'both',
        presence,
      };
    };

    const rows: ReturnType<typeof buildRow>[] = [];

    for (const a of txAList) {
      const b = txBList.find((t: any) => t.label === a.label);
      rows.push(buildRow(a, b || null, b ? 'both' : 'only-a'));
    }

    for (const b of txBList) {
      if (!aLabels.has(b.label)) {
        rows.push(buildRow(null, b, 'only-b'));
      }
    }

    return rows;
  }, [testA, testB]);

  const sorted = useMemo(() => {
    if (!txData.length) return [];
    return [...txData].sort((a, b) => {
      const aVal = (a as any)[sortBy] ?? 0;
      const bVal = (b as any)[sortBy] ?? 0;
      if (sortBy === 'label') return sortAsc ? a.label.localeCompare(b.label) : b.label.localeCompare(a.label);
      return sortAsc ? aVal - bVal : bVal - aVal;
    });
  }, [txData, sortBy, sortAsc]);

  const handleSort = (col: string) => {
    if (sortBy === col) setSortAsc(!sortAsc);
    else { setSortBy(col); setSortAsc(false); }
  };

  const cellColor = (val: number, inverted = false) => {
    const v = inverted ? -val : val;
    if (Math.abs(v) < 0.01) return 'bg-muted/30 text-muted-foreground';
    if (v > 20) return 'bg-rose-500/20 text-rose-600 dark:text-rose-400 font-bold';
    if (v > 10) return 'bg-rose-500/10 text-rose-500';
    if (v > 0) return 'bg-amber-500/10 text-amber-600 dark:text-amber-400';
    if (v < -10) return 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold';
    return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400';
  };

  const SortHeader = ({ col, label, className }: { col: string; label: string; className?: string }) => (
    <th
      className={`px-3 py-2.5 text-right font-semibold cursor-pointer hover:bg-muted/60 transition-colors select-none ${className || ''}`}
      onClick={() => handleSort(col)}
    >
      <span className="inline-flex items-center gap-1">
        {label}
        {sortBy === col && (sortAsc ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
      </span>
    </th>
  );

  if (sorted.length === 0) return null;

  return (
    <ChartCard icon={Activity} iconColor="text-rose-500" title="Transaction Regression Heatmap" gradientFrom="from-rose-500/5" gradientTo="to-amber-500/5">
      <div className="text-xs text-muted-foreground mb-3">
        Color intensity indicates regression severity. Sort by any column to find bottlenecks.
      </div>
      <div className="overflow-x-auto rounded-lg border border-border/60">
        <table className="w-full text-xs">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th rowSpan={2} className="px-3 py-2.5 text-left font-semibold cursor-pointer hover:bg-muted/60 border-b border-border/40 align-bottom" onClick={() => handleSort('label')}>
                Transaction {sortBy === 'label' && (sortAsc ? <ChevronUp className="w-3 h-3 inline" /> : <ChevronDown className="w-3 h-3 inline" />)}
              </th>
              <th colSpan={3} className="px-3 py-1.5 text-center font-semibold border-b border-border/40 border-l border-border/20">Avg Response</th>
              <th colSpan={3} className="px-3 py-1.5 text-center font-semibold border-b border-border/40 border-l border-border/20">P90</th>
              <th colSpan={3} className="px-3 py-1.5 text-center font-semibold border-b border-border/40 border-l border-border/20">P95</th>
              <th colSpan={3} className="px-3 py-1.5 text-center font-semibold border-b border-border/40 border-l border-border/20">P99</th>
              <th colSpan={3} className="px-3 py-1.5 text-center font-semibold border-b border-border/40 border-l border-border/20">TPS</th>
              <th colSpan={3} className="px-3 py-1.5 text-center font-semibold border-b border-border/40 border-l border-border/20">Error %</th>
            </tr>
            <tr>
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-blue-600 dark:text-blue-400 border-l border-border/20">A</th>
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-violet-600 dark:text-violet-400">B</th>
              <SortHeader col="avgDelta" label="Δ" />
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-blue-600 dark:text-blue-400 border-l border-border/20">A</th>
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-violet-600 dark:text-violet-400">B</th>
              <SortHeader col="p90Delta" label="Δ" />
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-blue-600 dark:text-blue-400 border-l border-border/20">A</th>
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-violet-600 dark:text-violet-400">B</th>
              <SortHeader col="p95Delta" label="Δ" />
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-blue-600 dark:text-blue-400 border-l border-border/20">A</th>
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-violet-600 dark:text-violet-400">B</th>
              <SortHeader col="p99Delta" label="Δ" />
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-blue-600 dark:text-blue-400 border-l border-border/20">A</th>
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-violet-600 dark:text-violet-400">B</th>
              <SortHeader col="tpsDelta" label="Δ" />
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-blue-600 dark:text-blue-400 border-l border-border/20">A</th>
              <th className="px-2 py-1.5 text-right text-[10px] font-medium text-violet-600 dark:text-violet-400">B</th>
              <SortHeader col="errDelta" label="Δ" />
            </tr>
          </thead>
          <tbody>
            {sorted.map((tx, i) => {
              const isOnlyA = tx.presence === 'only-a';
              const isOnlyB = tx.presence === 'only-b';
              const isUnmatched = isOnlyA || isOnlyB;
              const dimA = isOnlyB ? 'text-muted-foreground/40' : 'text-muted-foreground';
              const dimB = isOnlyA ? 'text-muted-foreground/40' : 'text-muted-foreground';
              const severityDot = tx.severity === 'unmatched' ? 'bg-sky-500' : tx.severity === 'critical' ? 'bg-rose-500' : tx.severity === 'warning' ? 'bg-amber-500' : 'bg-emerald-500';
              return (
              <tr key={tx.label} className={`border-t border-border/30 ${i % 2 === 0 ? '' : 'bg-muted/10'} hover:bg-muted/20 transition-colors ${isUnmatched ? 'bg-sky-500/5' : ''}`}>
                <td className="px-3 py-2 font-medium text-foreground max-w-[220px]">
                  <div className="flex items-center gap-2">
                    <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${severityDot}`} />
                    <span className="truncate">{tx.label}</span>
                    {isOnlyA && <span className="flex-shrink-0 text-[9px] font-semibold px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-600 dark:text-blue-400">Only in A</span>}
                    {isOnlyB && <span className="flex-shrink-0 text-[9px] font-semibold px-1.5 py-0.5 rounded bg-violet-500/15 text-violet-600 dark:text-violet-400">Only in B</span>}
                  </div>
                </td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimA} border-l border-border/20`}>{isOnlyB ? '—' : `${Math.round(tx.avgA)}ms`}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimB}`}>{isOnlyA ? '—' : `${Math.round(tx.avgB)}ms`}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${isUnmatched ? 'text-muted-foreground/40' : cellColor(tx.avgDelta)}`}>
                  {isUnmatched ? '—' : `${tx.avgDelta > 0 ? '+' : ''}${Math.round(tx.avgDelta)}ms`}
                </td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimA} border-l border-border/20`}>{isOnlyB ? '—' : `${Math.round(tx.p90A || 0)}ms`}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimB}`}>{isOnlyA ? '—' : `${Math.round(tx.p90B || 0)}ms`}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${isUnmatched ? 'text-muted-foreground/40' : cellColor(tx.p90Delta)}`}>
                  {isUnmatched ? '—' : `${tx.p90Delta > 0 ? '+' : ''}${Math.round(tx.p90Delta)}ms`}
                </td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimA} border-l border-border/20`}>{isOnlyB ? '—' : `${Math.round(tx.p95A || 0)}ms`}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimB}`}>{isOnlyA ? '—' : `${Math.round(tx.p95B || 0)}ms`}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${isUnmatched ? 'text-muted-foreground/40' : cellColor(tx.p95Delta)}`}>
                  {isUnmatched ? '—' : `${tx.p95Delta > 0 ? '+' : ''}${Math.round(tx.p95Delta)}ms`}
                </td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimA} border-l border-border/20`}>{isOnlyB ? '—' : `${Math.round(tx.p99A || 0)}ms`}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimB}`}>{isOnlyA ? '—' : `${Math.round(tx.p99B || 0)}ms`}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${isUnmatched ? 'text-muted-foreground/40' : cellColor(tx.p99Delta)}`}>
                  {isUnmatched ? '—' : `${tx.p99Delta > 0 ? '+' : ''}${Math.round(tx.p99Delta)}ms`}
                </td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimA} border-l border-border/20`}>{isOnlyB ? '—' : tx.tpsA.toFixed(1)}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimB}`}>{isOnlyA ? '—' : tx.tpsB.toFixed(1)}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${isUnmatched ? 'text-muted-foreground/40' : cellColor(tx.tpsDelta, true)}`}>
                  {isUnmatched ? '—' : `${tx.tpsDelta > 0 ? '+' : ''}${tx.tpsDelta.toFixed(2)}`}
                </td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimA} border-l border-border/20`}>{isOnlyB ? '—' : `${tx.errA.toFixed(2)}%`}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${dimB}`}>{isOnlyA ? '—' : `${tx.errB.toFixed(2)}%`}</td>
                <td className={`px-2 py-2 text-right tabular-nums ${isUnmatched ? 'text-muted-foreground/40' : cellColor(tx.errDelta)}`}>
                  {isUnmatched ? '—' : `${tx.errDelta > 0 ? '+' : ''}${tx.errDelta.toFixed(2)}%`}
                </td>
              </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </ChartCard>
  );
}

function formatElapsed(sec: number): string {
  if (sec < 60) return `${Math.round(sec)}s`;
  if (sec < 3600) {
    const m = Math.floor(sec / 60);
    const s = Math.round(sec % 60);
    return s > 0 ? `${m}m${s}s` : `${m}m`;
  }
  const h = Math.floor(sec / 3600);
  const m = Math.round((sec % 3600) / 60);
  return m > 0 ? `${h}h${m}m` : `${h}h`;
}

function VisualDiffCharts({ testA, testB }: { testA: any; testB: any }) {
  const timeseriesData = useMemo(() => {
    const tsA = testA.resultSummary?.timeseries || [];
    const tsB = testB.resultSummary?.timeseries || [];
    if (tsA.length === 0 && tsB.length === 0) return null;

    const maxLen = Math.max(tsA.length, tsB.length);
    const durationA = tsA.length > 0 ? (tsA[tsA.length - 1]?.sec ?? 0) - (tsA[0]?.sec ?? 0) : 0;
    const durationB = tsB.length > 0 ? (tsB[tsB.length - 1]?.sec ?? 0) - (tsB[0]?.sec ?? 0) : 0;
    const maxDuration = Math.max(durationA, durationB);
    const startA = tsA.length > 0 ? (tsA[0]?.sec ?? 0) : 0;
    const startB = tsB.length > 0 ? (tsB[0]?.sec ?? 0) : 0;

    const merged: any[] = [];
    for (let i = 0; i < maxLen; i++) {
      const pctA = tsA.length > 0 ? Math.round((i / maxLen) * tsA.length) : 0;
      const pctB = tsB.length > 0 ? Math.round((i / maxLen) * tsB.length) : 0;
      const a = tsA[Math.min(pctA, tsA.length - 1)];
      const b = tsB[Math.min(pctB, tsB.length - 1)];
      const avgA = a?.avg_ms ?? a?.avgRT ?? a?.avg ?? a?.avgResponseTime ?? null;
      const avgB = b?.avg_ms ?? b?.avgRT ?? b?.avg ?? b?.avgResponseTime ?? null;
      const tpsA = a?.rps ?? a?.throughput ?? a?.tps ?? null;
      const tpsB = b?.rps ?? b?.throughput ?? b?.tps ?? null;
      const rawErrA = a?.errorRate ?? a?.errorPercent ?? null;
      const rawErrB = b?.errorRate ?? b?.errorPercent ?? null;
      const errA = rawErrA != null ? (rawErrA <= 1 && rawErrA > 0 ? rawErrA * 100 : rawErrA) : null;
      const errB = rawErrB != null ? (rawErrB <= 1 && rawErrB > 0 ? rawErrB * 100 : rawErrB) : null;
      const p95A = a?.p95 ?? null;
      const p95B = b?.p95 ?? null;
      const threadsA = a?.activeThreads ?? a?.threads ?? null;
      const threadsB = b?.activeThreads ?? b?.threads ?? null;
      const rtDelta = avgA != null && avgB != null ? avgB - avgA : null;

      const elapsedSec = maxDuration > 0
        ? (i / (maxLen - 1 || 1)) * maxDuration
        : a?.sec != null ? (a.sec - startA) : (b?.sec != null ? (b.sec - startB) : i);

      merged.push({
        index: i,
        time: formatElapsed(elapsedSec),
        elapsedSec,
        avgA, avgB, tpsA, tpsB, errA, errB, p95A, p95B, threadsA, threadsB,
        rtDelta,
        rtDeltaPos: rtDelta != null && rtDelta > 0 ? rtDelta : 0,
        rtDeltaNeg: rtDelta != null && rtDelta < 0 ? rtDelta : 0,
      });
    }
    return merged;
  }, [testA, testB]);

  const percentileData = useMemo(() => {
    const sA = testA.resultSummary;
    const sB = testB.resultSummary;
    if (!sA || !sB) return null;
    const hasData = (sA.p90 || sA.p95 || sB.p90 || sB.p95);
    if (!hasData) return null;
    const data: { name: string; baseline: number; compare: number }[] = [];
    if (sA.p50 != null || sB.p50 != null) data.push({ name: 'P50', baseline: sA.p50 || 0, compare: sB.p50 || 0 });
    data.push({ name: 'P90', baseline: sA.p90 || 0, compare: sB.p90 || 0 });
    data.push({ name: 'P95', baseline: sA.p95 || 0, compare: sB.p95 || 0 });
    if (sA.p99 != null || sB.p99 != null) data.push({ name: 'P99', baseline: sA.p99 || 0, compare: sB.p99 || 0 });
    return data;
  }, [testA, testB]);

  const concurrencyData = useMemo(() => {
    if (!timeseriesData) return null;
    const scatterA: any[] = [];
    const scatterB: any[] = [];
    timeseriesData.forEach(d => {
      if (d.threadsA != null && d.avgA != null) scatterA.push({ threads: d.threadsA, rt: d.avgA, tps: d.tpsA || 1 });
      if (d.threadsB != null && d.avgB != null) scatterB.push({ threads: d.threadsB, rt: d.avgB, tps: d.tpsB || 1 });
    });
    if (scatterA.length === 0 && scatterB.length === 0) return null;
    return { scatterA, scatterB };
  }, [timeseriesData]);

  const transactionBarData = useMemo(() => {
    const txA = testA.resultSummary?.transactionDetails || [];
    const txB = testB.resultSummary?.transactionDetails || [];
    if (txA.length === 0) return null;
    return txA.map((a: any) => {
      const b = txB.find((t: any) => t.label === a.label);
      const shortLabel = a.label.length > 20 ? a.label.substring(0, 18) + '...' : a.label;
      return {
        label: shortLabel,
        fullLabel: a.label,
        avgA: a.avg || 0, avgB: b?.avg || 0,
        p95A: a.p95 || 0, p95B: b?.p95 || 0,
      };
    });
  }, [testA, testB]);

  const radarData = useMemo(() => {
    const sA = testA.resultSummary;
    const sB = testB.resultSummary;
    if (!sA || !sB) return null;
    const normalize = (val: number, max: number) => max > 0 ? Math.min((val / max) * 100, 100) : 0;
    const maxAvg = Math.max(sA.avgResponseTime || 0, sB.avgResponseTime || 0) || 1;
    const maxP90 = Math.max(sA.p90 || 0, sB.p90 || 0) || 1;
    const maxP95 = Math.max(sA.p95 || 0, sB.p95 || 0) || 1;
    const maxTps = Math.max(sA.throughput || 0, sB.throughput || 0) || 1;
    const maxErr = Math.max(sA.failedRequests || 0, sB.failedRequests || 0) || 1;
    const maxReq = Math.max(sA.totalRequests || 0, sB.totalRequests || 0) || 1;
    return [
      { metric: 'Avg RT', A: normalize(sA.avgResponseTime || 0, maxAvg), B: normalize(sB.avgResponseTime || 0, maxAvg) },
      { metric: 'P90', A: normalize(sA.p90 || 0, maxP90), B: normalize(sB.p90 || 0, maxP90) },
      { metric: 'P95', A: normalize(sA.p95 || 0, maxP95), B: normalize(sB.p95 || 0, maxP95) },
      { metric: 'Throughput', A: normalize(sA.throughput || 0, maxTps), B: normalize(sB.throughput || 0, maxTps) },
      { metric: 'Errors', A: normalize(sA.failedRequests || 0, maxErr), B: normalize(sB.failedRequests || 0, maxErr) },
      { metric: 'Requests', A: normalize(sA.totalRequests || 0, maxReq), B: normalize(sB.totalRequests || 0, maxReq) },
    ];
  }, [testA, testB]);

  return (
    <div className="space-y-4" style={{ animationName: 'fadeSlideIn', animationDuration: '0.4s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: '300ms' }}>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {timeseriesData && (
          <ChartCard icon={TrendingUp} iconColor="text-blue-500" title="Response Time Overlay" gradientFrom="from-blue-500/5" gradientTo="to-violet-500/5">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={timeseriesData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="cmpGradA" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={DT_COLORS.primary} stopOpacity={0.15} />
                    <stop offset="100%" stopColor={DT_COLORS.primary} stopOpacity={0.02} />
                  </linearGradient>
                  <linearGradient id="cmpGradB" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={DT_COLORS.purple} stopOpacity={0.15} />
                    <stop offset="100%" stopColor={DT_COLORS.purple} stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid {...DT_GRID_PROPS} vertical={false} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis {...DT_AXIS_PROPS} axisLine={false} width={48} label={{ value: "ms", angle: -90, position: "insideLeft", fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                <RechartsTooltip contentStyle={CHART_TOOLTIP_STYLE} labelStyle={CHART_LABEL_STYLE} cursor={DT_CURSOR_PROPS} formatter={(value: any, name: string) => [`${Math.round(value)} ms`, name === 'avgA' ? 'Baseline (A)' : name === 'avgB' ? 'Compare (B)' : 'P95 (A)']} />
                <Legend verticalAlign="top" align="right" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }} formatter={(v) => v === 'avgA' ? 'Baseline Avg' : v === 'avgB' ? 'Compare Avg' : 'Baseline P95'} />
                <Area type="monotone" dataKey="avgA" stroke={DT_COLORS.primary} strokeWidth={2} fill="url(#cmpGradA)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} name="avgA" />
                <Area type="monotone" dataKey="avgB" stroke={DT_COLORS.purple} strokeWidth={2} fill="url(#cmpGradB)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} name="avgB" strokeDasharray="6 3" />
                <Line type="monotone" dataKey="p95A" stroke={DT_COLORS.primary} strokeWidth={1} strokeDasharray="3 3" dot={false} name="p95A" strokeOpacity={0.5} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        )}

        {timeseriesData && (
          <ChartCard icon={Zap} iconColor="text-emerald-500" title="Throughput Overlay" gradientFrom="from-emerald-500/5" gradientTo="to-blue-500/5">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={timeseriesData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="cmpTpsA" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={DT_COLORS.green} stopOpacity={0.15} />
                    <stop offset="100%" stopColor={DT_COLORS.green} stopOpacity={0.02} />
                  </linearGradient>
                  <linearGradient id="cmpTpsB" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={DT_COLORS.purple} stopOpacity={0.15} />
                    <stop offset="100%" stopColor={DT_COLORS.purple} stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid {...DT_GRID_PROPS} vertical={false} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis {...DT_AXIS_PROPS} axisLine={false} width={48} label={{ value: "req/s", angle: -90, position: "insideLeft", fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                <RechartsTooltip contentStyle={CHART_TOOLTIP_STYLE} labelStyle={CHART_LABEL_STYLE} cursor={DT_CURSOR_PROPS} formatter={(value: any, name: string) => [`${Number(value).toFixed(1)} /s`, name === 'tpsA' ? 'Baseline' : 'Compare']} />
                <Legend verticalAlign="top" align="right" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }} formatter={(v) => v === 'tpsA' ? 'Baseline (A)' : 'Compare (B)'} />
                <Area type="monotone" dataKey="tpsA" stroke={DT_COLORS.green} strokeWidth={2} fill="url(#cmpTpsA)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} name="tpsA" />
                <Area type="monotone" dataKey="tpsB" stroke={DT_COLORS.purple} strokeWidth={2} fill="url(#cmpTpsB)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} name="tpsB" strokeDasharray="6 3" />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {timeseriesData && (
          <ChartCard icon={AlertTriangle} iconColor="text-rose-500" title="Error Rate Comparison" gradientFrom="from-rose-500/5" gradientTo="to-pink-500/5">
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={timeseriesData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="cmpErrA" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={DT_COLORS.red} stopOpacity={0.2} />
                    <stop offset="100%" stopColor={DT_COLORS.red} stopOpacity={0.02} />
                  </linearGradient>
                  <linearGradient id="cmpErrB" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={DT_COLORS.amber} stopOpacity={0.2} />
                    <stop offset="100%" stopColor={DT_COLORS.amber} stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid {...DT_GRID_PROPS} vertical={false} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis {...DT_AXIS_PROPS} axisLine={false} width={42} domain={[0, (max: number) => Math.max(max, 5)]} label={{ value: "error %", angle: -90, position: "insideLeft", fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                <RechartsTooltip contentStyle={CHART_TOOLTIP_STYLE} labelStyle={CHART_LABEL_STYLE} cursor={DT_CURSOR_PROPS} formatter={(value: any, name: string) => [`${Number(value).toFixed(2)}%`, name === 'errA' ? 'Baseline' : 'Compare']} />
                <Legend verticalAlign="top" align="right" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }} formatter={(v) => v === 'errA' ? 'Baseline (A)' : 'Compare (B)'} />
                <Area type="monotone" dataKey="errA" stroke={DT_COLORS.red} strokeWidth={2} fill="url(#cmpErrA)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} name="errA" />
                <Area type="monotone" dataKey="errB" stroke={DT_COLORS.amber} strokeWidth={2} fill="url(#cmpErrB)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} name="errB" strokeDasharray="6 3" />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        )}

        {timeseriesData && (
          <ChartCard icon={TrendingUp} iconColor="text-amber-500" title="Response Time Delta (B \u2212 A)" gradientFrom="from-amber-500/5" gradientTo="to-rose-500/5">
            <div className="text-xs text-muted-foreground mb-2">
              <span className="text-rose-500 font-semibold">Above zero</span> = regression (slower), <span className="text-emerald-500 font-semibold">below zero</span> = improvement (faster).
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={timeseriesData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="cmpDeltaPos" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={DT_COLORS.red} stopOpacity={0.3} />
                    <stop offset="100%" stopColor={DT_COLORS.red} stopOpacity={0.02} />
                  </linearGradient>
                  <linearGradient id="cmpDeltaNeg" x1="0" y1="1" x2="0" y2="0">
                    <stop offset="0%" stopColor={DT_COLORS.green} stopOpacity={0.3} />
                    <stop offset="100%" stopColor={DT_COLORS.green} stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid {...DT_GRID_PROPS} vertical={false} />
                <XAxis dataKey="time" {...DT_AXIS_PROPS} interval="preserveStartEnd" />
                <YAxis {...DT_AXIS_PROPS} axisLine={false} width={48} label={{ value: "ms Δ", angle: -90, position: "insideLeft", fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                <ReferenceLine y={0} stroke="hsl(var(--foreground))" strokeWidth={1.5} strokeOpacity={0.3} label={{ value: "Baseline", position: "right", fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                <RechartsTooltip contentStyle={CHART_TOOLTIP_STYLE} labelStyle={CHART_LABEL_STYLE} cursor={DT_CURSOR_PROPS} formatter={(value: any) => {
                  const v = Math.round(value);
                  const label = v > 0 ? `+${v} ms (regression)` : v < 0 ? `${v} ms (improvement)` : '0 ms (no change)';
                  return [label, 'RT Delta'];
                }} />
                <Legend verticalAlign="top" align="right" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }} formatter={(v) => v === 'rtDeltaPos' ? 'Regression' : 'Improvement'} />
                <Area type="monotone" dataKey="rtDeltaPos" stroke={DT_COLORS.red} strokeWidth={1.5} fill="url(#cmpDeltaPos)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} name="rtDeltaPos" />
                <Area type="monotone" dataKey="rtDeltaNeg" stroke={DT_COLORS.green} strokeWidth={1.5} fill="url(#cmpDeltaNeg)" dot={false} activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }} name="rtDeltaNeg" />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {percentileData && (
          <ChartCard icon={BarChart3} iconColor="text-violet-500" title="Percentile Distribution" gradientFrom="from-violet-500/5" gradientTo="to-blue-500/5">
            <div className="text-xs text-muted-foreground mb-2">Side-by-side latency at each percentile. Large gaps at P99 reveal tail latency problems.</div>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={percentileData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid {...DT_GRID_PROPS} vertical={false} />
                <XAxis dataKey="name" {...DT_AXIS_PROPS} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))", fontWeight: 600 }} axisLine={false} />
                <YAxis {...DT_AXIS_PROPS} axisLine={false} width={48} label={{ value: "ms", angle: -90, position: "insideLeft", fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                <RechartsTooltip contentStyle={CHART_TOOLTIP_STYLE} labelStyle={CHART_LABEL_STYLE} cursor={DT_CURSOR_PROPS} formatter={(value: any, name: string) => [`${Math.round(value)} ms`, name === 'baseline' ? 'Baseline (A)' : 'Compare (B)']} />
                <Legend verticalAlign="top" align="right" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }} formatter={(v) => v === 'baseline' ? 'Baseline (A)' : 'Compare (B)'} />
                <Bar dataKey="baseline" fill={DT_COLORS.primary} radius={[4, 4, 0, 0]} barSize={28} name="baseline" />
                <Bar dataKey="compare" fill={DT_COLORS.purple} radius={[4, 4, 0, 0]} barSize={28} name="compare" />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        )}

        {concurrencyData && (
          <ChartCard icon={Users} iconColor="text-purple-500" title="Concurrency vs Response Time" gradientFrom="from-purple-500/5" gradientTo="to-pink-500/5">
            <div className="text-xs text-muted-foreground mb-2">Detects scalability regression: if Run B's curve shifts upward under equal load, the system degrades faster.</div>
            <ResponsiveContainer width="100%" height={240}>
              <ScatterChart margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid {...DT_GRID_PROPS} />
                <XAxis type="number" dataKey="threads" {...DT_AXIS_PROPS} name="Threads" label={{ value: "Virtual Users", position: "insideBottom", offset: -2, fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis type="number" dataKey="rt" {...DT_AXIS_PROPS} axisLine={false} width={48} name="RT" label={{ value: "ms", angle: -90, position: "insideLeft", fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                <ZAxis type="number" dataKey="tps" range={[30, 120]} name="TPS" />
                <RechartsTooltip contentStyle={CHART_TOOLTIP_STYLE} labelStyle={CHART_LABEL_STYLE} cursor={DT_CURSOR_PROPS} formatter={(value: any, name: string) => [name === 'RT' ? `${Math.round(value)} ms` : name === 'TPS' ? `${Number(value).toFixed(1)} /s` : value, name]} />
                <Legend verticalAlign="top" align="right" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }} />
                <Scatter name="Baseline (A)" data={concurrencyData.scatterA} fill={DT_COLORS.primary} fillOpacity={0.7} strokeWidth={0} />
                <Scatter name="Compare (B)" data={concurrencyData.scatterB} fill={DT_COLORS.purple} fillOpacity={0.7} strokeWidth={0} />
              </ScatterChart>
            </ResponsiveContainer>
          </ChartCard>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {transactionBarData && transactionBarData.length > 0 && (
          <ChartCard icon={BarChart3} iconColor="text-amber-500" title="Transaction Avg & P95 Comparison" gradientFrom="from-amber-500/5" gradientTo="to-rose-500/5">
            <ResponsiveContainer width="100%" height={Math.max(220, transactionBarData.length * 40 + 60)}>
              <BarChart data={transactionBarData} layout="vertical" margin={{ left: 10, right: 20 }}>
                <CartesianGrid {...DT_GRID_PROPS} horizontal={false} />
                <XAxis type="number" {...DT_AXIS_PROPS} label={{ value: "ms", position: "insideBottomRight", fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis dataKey="label" type="category" {...DT_AXIS_PROPS} width={120} axisLine={false} />
                <RechartsTooltip contentStyle={CHART_TOOLTIP_STYLE} labelStyle={CHART_LABEL_STYLE} cursor={DT_CURSOR_PROPS} formatter={(value: any, name: string) => {
                  const labels: Record<string, string> = { avgA: 'Baseline Avg', avgB: 'Compare Avg', p95A: 'Baseline P95', p95B: 'Compare P95' };
                  return [`${Math.round(value)} ms`, labels[name] || name];
                }} />
                <Legend verticalAlign="top" align="right" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px", paddingBottom: "8px" }} formatter={(v) => {
                  const labels: Record<string, string> = { avgA: 'Baseline Avg', avgB: 'Compare Avg', p95A: 'Baseline P95', p95B: 'Compare P95' };
                  return labels[v] || v;
                }} />
                <Bar dataKey="avgA" fill={DT_COLORS.primary} radius={[0, 4, 4, 0]} barSize={10} name="avgA" />
                <Bar dataKey="avgB" fill={DT_COLORS.purple} radius={[0, 4, 4, 0]} barSize={10} name="avgB" />
                <Bar dataKey="p95A" fill={DT_COLORS.primary} radius={[0, 4, 4, 0]} barSize={6} name="p95A" fillOpacity={0.4} />
                <Bar dataKey="p95B" fill={DT_COLORS.purple} radius={[0, 4, 4, 0]} barSize={6} name="p95B" fillOpacity={0.4} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        )}

        {radarData && (
          <ChartCard icon={Scale} iconColor="text-violet-500" title="Performance Radar" gradientFrom="from-violet-500/5" gradientTo="to-pink-500/5">
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="hsl(var(--border))" strokeOpacity={0.5} />
                <PolarAngleAxis dataKey="metric" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))', fontWeight: 500 }} />
                <PolarRadiusAxis tick={{ fontSize: 9 }} domain={[0, 100]} />
                <Radar name="Baseline (A)" dataKey="A" stroke={DT_COLORS.primary} fill={DT_COLORS.primary} fillOpacity={0.15} strokeWidth={2} />
                <Radar name="Compare (B)" dataKey="B" stroke={DT_COLORS.purple} fill={DT_COLORS.purple} fillOpacity={0.15} strokeWidth={2} />
                <Legend verticalAlign="bottom" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: "11px" }} />
              </RadarChart>
            </ResponsiveContainer>
          </ChartCard>
        )}
      </div>

      <RegressionHeatmap testA={testA} testB={testB} />
    </div>
  );
}

export default function ComparisonPage() {
  const [testAId, setTestAId] = useState<string>("");
  const [testBId, setTestBId] = useState<string>("");

  const { data: executionsResponse, isLoading: loadingExecutions, isError, error, refetch } = useExecutions({ limit: 50 });
  const { data: testA, isLoading: loadingA } = useExecution(testAId ? parseInt(testAId) : 0);
  const { data: testB, isLoading: loadingB } = useExecution(testBId ? parseInt(testBId) : 0);

  const executions = executionsResponse?.data || [];
  const completedExecutions = executions.filter(e => e.status === 'completed' || e.status === 'failed' || e.status === 'running');

  const swapSelections = () => {
    const tmp = testAId;
    setTestAId(testBId);
    setTestBId(tmp);
  };

  const summary = testA && testB ? (() => {
    const s = testA.resultSummary;
    const s2 = testB.resultSummary;
    if (!s || !s2) return null;

    const metrics = [
      { key: 'avgResp', a: s.avgResponseTime || 0, b: s2.avgResponseTime || 0, better: false },
      { key: 'throughput', a: s.throughput || 0, b: s2.throughput || 0, better: true },
      { key: 'errors', a: s.failedRequests || 0, b: s2.failedRequests || 0, better: false },
    ];

    let improvements = 0;
    let regressions = 0;
    metrics.forEach(m => {
      const diff = m.b - m.a;
      if (diff === 0) return;
      const isBetter = m.better ? diff > 0 : diff < 0;
      if (isBetter) improvements++;
      else regressions++;
    });

    return { improvements, regressions, neutral: metrics.length - improvements - regressions };
  })() : null;

  if (isError) return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load executions" />;

  if (loadingExecutions) {
    return (
      <div className="space-y-6 max-w-7xl mx-auto">
        <PageHeader title="Comparison" subtitle="Compare performance between two test executions" />
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto_1fr] gap-4">
          <Skeleton className="h-48 w-full rounded-xl" />
          <div className="flex items-center justify-center"><Skeleton className="h-10 w-10 rounded-full" /></div>
          <Skeleton className="h-48 w-full rounded-xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulse-soft {
          0%, 100% { opacity: 0.6; }
          50% { opacity: 1; }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-8px) rotate(2deg); }
        }
      `}</style>

      <PageHeader title="Comparison" subtitle="Compare performance between two test executions" />

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto_1fr] gap-4 items-stretch">
        <Card className="border-2 border-blue-500/20 bg-gradient-to-br from-blue-500/5 to-transparent hover:border-blue-500/30 transition-colors">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-500 text-xs font-bold">A</div>
              <span className="text-sm font-bold uppercase tracking-wider text-blue-500">Baseline</span>
            </div>
            <Select onValueChange={setTestAId} value={testAId}>
              <SelectTrigger className="w-full h-11 rounded-lg border-blue-500/20 focus:ring-blue-500/30">
                <SelectValue placeholder="Select baseline execution..." />
              </SelectTrigger>
              <SelectContent>
                {completedExecutions.map(exec => (
                  <SelectItem key={exec.id} value={exec.id.toString()}>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-muted-foreground">#{exec.id}</span>
                      <span>{exec.schedule?.name || (exec as any).testName || exec.executionId}</span>
                      {(exec as any).releaseTag && (
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 gap-0.5">
                          <Tag className="h-2.5 w-2.5" />
                          {(exec as any).releaseTag}
                        </Badge>
                      )}
                      <span className="text-xs text-muted-foreground">({new Date(exec.startTime!).toLocaleDateString()})</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {testA && (
              <div className="mt-3 p-3 rounded-lg bg-blue-500/5 border border-blue-500/15 space-y-2">
                <div className="flex items-center justify-between">
                  <Badge variant={testA.status === 'completed' ? 'default' : 'destructive'} className="text-[10px]">{testA.status}</Badge>
                  <span className="text-xs text-muted-foreground">{testA.schedule?.configuration?.environment || (testA as any).environment || ''}</span>
                </div>
                <div className="text-xs text-muted-foreground">{testA.schedule?.script?.name || (testA as any).testName || testA.schedule?.script?.toolType || 'Unknown'}</div>
                {testA.resultSummary && (
                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-blue-500/10">
                    <div>
                      <div className="text-[10px] text-muted-foreground/70">Requests</div>
                      <div className="text-sm font-bold tabular-nums">{formatNum(testA.resultSummary.totalRequests || 0)}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground/70">Avg</div>
                      <div className="text-sm font-bold tabular-nums">{Math.round(testA.resultSummary.avgResponseTime || 0)}ms</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground/70">Errors</div>
                      <div className="text-sm font-bold tabular-nums">{formatNum(testA.resultSummary.failedRequests || 0)}</div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex lg:flex-col items-center justify-center gap-2 py-2">
          <Button
            variant="outline"
            size="icon"
            className="rounded-full h-10 w-10 border-2 hover:bg-primary/10 hover:border-primary/40 transition-all"
            onClick={swapSelections}
            title="Swap selections"
            disabled={!testAId && !testBId}
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
          <ArrowLeftRight className="w-4 h-4 text-muted-foreground/40 hidden lg:block" />
        </div>

        <Card className="border-2 border-violet-500/20 bg-gradient-to-br from-violet-500/5 to-transparent hover:border-violet-500/30 transition-colors">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded-full bg-violet-500/20 flex items-center justify-center text-violet-500 text-xs font-bold">B</div>
              <span className="text-sm font-bold uppercase tracking-wider text-violet-500">Compare</span>
            </div>
            <Select onValueChange={setTestBId} value={testBId}>
              <SelectTrigger className="w-full h-11 rounded-lg border-violet-500/20 focus:ring-violet-500/30">
                <SelectValue placeholder="Select comparison execution..." />
              </SelectTrigger>
              <SelectContent>
                {completedExecutions.map(exec => (
                  <SelectItem key={exec.id} value={exec.id.toString()}>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-muted-foreground">#{exec.id}</span>
                      <span>{exec.schedule?.name || (exec as any).testName || exec.executionId}</span>
                      {(exec as any).releaseTag && (
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 gap-0.5">
                          <Tag className="h-2.5 w-2.5" />
                          {(exec as any).releaseTag}
                        </Badge>
                      )}
                      <span className="text-xs text-muted-foreground">({new Date(exec.startTime!).toLocaleDateString()})</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {testB && (
              <div className="mt-3 p-3 rounded-lg bg-violet-500/5 border border-violet-500/15 space-y-2">
                <div className="flex items-center justify-between">
                  <Badge variant={testB.status === 'completed' ? 'default' : 'destructive'} className="text-[10px]">{testB.status}</Badge>
                  <span className="text-xs text-muted-foreground">{testB.schedule?.configuration?.environment || (testB as any).environment || ''}</span>
                </div>
                <div className="text-xs text-muted-foreground">{testB.schedule?.script?.name || (testB as any).testName || testB.schedule?.script?.toolType || 'Unknown'}</div>
                {testB.resultSummary && (
                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-violet-500/10">
                    <div>
                      <div className="text-[10px] text-muted-foreground/70">Requests</div>
                      <div className="text-sm font-bold tabular-nums">{formatNum(testB.resultSummary.totalRequests || 0)}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground/70">Avg</div>
                      <div className="text-sm font-bold tabular-nums">{Math.round(testB.resultSummary.avgResponseTime || 0)}ms</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground/70">Errors</div>
                      <div className="text-sm font-bold tabular-nums">{formatNum(testB.resultSummary.failedRequests || 0)}</div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {(loadingA || loadingB) && (testAId || testBId) ? (
        <div className="space-y-6">
          <div className="flex items-center justify-center gap-6 p-4 rounded-xl bg-muted/30 border">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-5 w-24" />
            ))}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-40 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      ) : testA && testB ? (
        <div className="space-y-6">
          {summary && (
            <div
              className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 p-4 rounded-xl bg-muted/30 border"
              style={{ animationName: 'fadeSlideIn', animationDuration: '0.4s', animationTimingFunction: 'ease-out', animationFillMode: 'both' }}
            >
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-sm font-semibold">{summary.improvements} Improved</span>
              </div>
              <div className="w-px h-5 bg-border" />
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-rose-500" />
                <span className="text-sm font-semibold">{summary.regressions} Regressed</span>
              </div>
              <div className="w-px h-5 bg-border" />
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-muted-foreground/40" />
                <span className="text-sm font-semibold">{summary.neutral} Unchanged</span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricCard
              label="Total Requests"
              icon={Layers}
              valA={testA.resultSummary?.totalRequests || 0}
              valB={testB.resultSummary?.totalRequests || 0}
              unit=""
              higherIsBetter={true}
              color="blue"
              delay={0}
            />
            <MetricCard
              label="Avg Response"
              icon={Clock}
              valA={testA.resultSummary?.avgResponseTime || 0}
              valB={testB.resultSummary?.avgResponseTime || 0}
              unit="ms"
              higherIsBetter={false}
              color="amber"
              delay={80}
            />
            <MetricCard
              label="Failed Requests"
              icon={AlertTriangle}
              valA={testA.resultSummary?.failedRequests || 0}
              valB={testB.resultSummary?.failedRequests || 0}
              unit=""
              higherIsBetter={false}
              color="rose"
              delay={160}
            />
            <MetricCard
              label="Throughput"
              icon={Zap}
              valA={testA.resultSummary?.throughput || 0}
              valB={testB.resultSummary?.throughput || 0}
              unit="/s"
              higherIsBetter={true}
              color="emerald"
              delay={240}
            />
          </div>

          <VisualDiffCharts testA={testA} testB={testB} />

          {(testA.resultSummary?.transactionDetails || testB.resultSummary?.transactionDetails) && (
            <Card className="overflow-hidden border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-muted/50 to-muted/20 border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Activity className="w-5 h-5 text-primary" />
                    Transaction Breakdown
                  </CardTitle>
                  <Badge variant="outline" className="text-xs font-mono">
                    {(() => {
                      const aLabels = new Set((testA.resultSummary?.transactionDetails || []).map((t: any) => t.label));
                      const bLabels = new Set((testB.resultSummary?.transactionDetails || []).map((t: any) => t.label));
                      const allLabels = new Set([...aLabels, ...bLabels]);
                      return `${allLabels.size} transactions`;
                    })()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-2">
                  {(() => {
                    const txAList = testA.resultSummary?.transactionDetails || [];
                    const txBList = testB.resultSummary?.transactionDetails || [];
                    const aLabels = new Set(txAList.map((t: any) => t.label));
                    const rows: { txA: any; txB: any; presence: 'both' | 'only-a' | 'only-b' }[] = [];

                    for (const a of txAList) {
                      const b = txBList.find((t: any) => t.label === a.label);
                      rows.push({ txA: a, txB: b || null, presence: b ? 'both' : 'only-a' });
                    }
                    for (const b of txBList) {
                      if (!aLabels.has(b.label)) {
                        rows.push({ txA: null, txB: b, presence: 'only-b' });
                      }
                    }

                    return rows.map((row, index) => (
                      <TransactionRow
                        key={row.txA?.label || row.txB?.label}
                        txA={row.txA}
                        txB={row.txB}
                        index={index}
                        presence={row.presence}
                      />
                    ));
                  })()}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      ) : (
        <div
          className="flex flex-col items-center justify-center py-20 bg-gradient-to-b from-muted/20 to-transparent rounded-2xl border-2 border-dashed border-border/50 text-center px-6"
          style={{ animationName: 'fadeSlideIn', animationDuration: '0.5s', animationTimingFunction: 'ease-out', animationFillMode: 'both' }}
        >
          <div className="relative mb-6">
            <Scale className="w-16 h-16 text-muted-foreground/30" style={{ animation: 'float 4s ease-in-out infinite' }} />
            <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-primary/20" style={{ animation: 'pulse-soft 2s ease-in-out infinite' }} />
          </div>
          <h3 className="text-xl font-bold">Select Two Executions</h3>
          <p className="text-muted-foreground mt-2 max-w-sm text-sm leading-relaxed">
            Pick a baseline and comparison execution above to see a detailed performance breakdown with variance analysis.
          </p>
          <div className="flex items-center gap-4 mt-6 text-xs text-muted-foreground/60">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-blue-500/30" />
              <span>Baseline (A)</span>
            </div>
            <ArrowLeftRight className="w-3 h-3" />
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-violet-500/30" />
              <span>Compare (B)</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
