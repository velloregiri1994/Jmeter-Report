import { useDashboardStats, useExecutions } from "@/hooks/use-executions";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Activity, CheckCircle, FileCode, Play, XCircle, Zap, Server, Shield, Star, ArrowRight, Clock, BarChart3, Eye, TrendingUp, TrendingDown, Minus, Sparkles, Timer, Gauge, AlertTriangle, CalendarDays, Upload, Calendar, Settings, Rocket } from "lucide-react";
import { StatusBadge } from "@/components/status-badge";
import { Link } from "wouter";
import { format, formatDistanceToNow } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { queryKeys } from "@/lib/query-keys";

interface Script {
  id: number;
  name: string;
  toolType: string;
  description?: string;
}

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

export default function Dashboard() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { data: stats, isLoading, isError: statsIsError, error: statsError, refetch: refetchStats } = useDashboardStats();
  const { data: executionsResponse, isError: execError, refetch: refetchExec } = useExecutions({ limit: 100 });
  
  const { data: favorites = [] } = useQuery<number[]>({
    queryKey: [...queryKeys.dashboard.favorites],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/favorites");
        return res.json();
      } catch {
        return [];
      }
    }
  });

  const { data: scripts = [] } = useQuery<Script[]>({
    queryKey: [...queryKeys.scripts.all],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/scripts");
      return res.json();
    }
  });

  const toggleFavorite = useMutation({
    mutationFn: async (scriptId: number) => {
      if (favorites.includes(scriptId)) {
        await apiRequest("DELETE", `/api/favorites/${scriptId}`);
      } else {
        await apiRequest("POST", "/api/favorites", { scriptId });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.favorites });
    }
  });

  if (statsIsError) {
    return <QueryErrorFallback error={statsError as Error} onRetry={() => { refetchStats(); refetchExec(); }} title="Failed to load dashboard stats" />;
  }

  if (isLoading) {
    return <DashboardSkeleton />;
  }
  
  const allExecutions = executionsResponse?.data || [];

  if (!stats) {
    return (
      <div className="section-gap">
        <div className="text-center py-20 text-muted-foreground">
          <p className="text-lg font-semibold">No data available</p>
          <p className="text-sm mt-2">Dashboard data is loading or unavailable</p>
        </div>
      </div>
    );
  }

  const isEmptyWorkspace = stats.totalScripts === 0 && stats.totalExecutions === 0;

  if (isEmptyWorkspace) {
    return (
      <div className="section-gap">
        <div className="mb-6 sm:mb-8">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="text-sm font-medium text-muted-foreground">{getGreeting()}</span>
          </div>
          <h1 className="page-title">
            {user?.username ? `Welcome, ${user.username}` : "Welcome to PerfHub"}
          </h1>
          <p className="page-subtitle mt-1">Your performance engineering workspace is ready. Let's get started!</p>
        </div>

        <Card className="card-shadow border-primary/20 overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/3 pointer-events-none" />
          <CardContent className="relative py-10 px-6 sm:px-10">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
                <Rocket className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-xl font-bold mb-2">Get started in 3 steps</h2>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                Upload a JMeter test script, schedule a test run, and view the results — all from one place.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 max-w-3xl mx-auto">
              <Link href="/scripts">
                <div className="group p-6 rounded-xl border border-border/50 hover:border-primary/40 bg-card/80 hover:bg-card transition-all cursor-pointer text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/10 mb-3 group-hover:scale-110 transition-transform">
                    <Upload className="w-6 h-6 text-indigo-500" />
                  </div>
                  <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold mb-2">1</div>
                  <h3 className="font-semibold text-sm mb-1">Upload Script</h3>
                  <p className="text-xs text-muted-foreground">Upload your JMeter .jmx test file and any dependencies</p>
                </div>
              </Link>

              <Link href="/schedule">
                <div className="group p-6 rounded-xl border border-border/50 hover:border-primary/40 bg-card/80 hover:bg-card transition-all cursor-pointer text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-emerald-500/10 mb-3 group-hover:scale-110 transition-transform">
                    <Calendar className="w-6 h-6 text-emerald-500" />
                  </div>
                  <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold mb-2">2</div>
                  <h3 className="font-semibold text-sm mb-1">Schedule Test</h3>
                  <p className="text-xs text-muted-foreground">Set up a one-time or recurring test run with your parameters</p>
                </div>
              </Link>

              <Link href="/executions">
                <div className="group p-6 rounded-xl border border-border/50 hover:border-primary/40 bg-card/80 hover:bg-card transition-all cursor-pointer text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-amber-500/10 mb-3 group-hover:scale-110 transition-transform">
                    <BarChart3 className="w-6 h-6 text-amber-500" />
                  </div>
                  <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold mb-2">3</div>
                  <h3 className="font-semibold text-sm mb-1">View Results</h3>
                  <p className="text-xs text-muted-foreground">Monitor live metrics and analyze performance after completion</p>
                </div>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-5">
          <GlowMetricCard 
            title="Active Tests" value={0} icon={Zap} 
            gradient="from-amber-500 to-orange-500" bgGlow="bg-amber-500/5" description="Running now"
          />
          <GlowMetricCard 
            title="Test Scripts" value={0} icon={FileCode} 
            gradient="from-indigo-500 to-violet-500" bgGlow="bg-indigo-500/5" description="In repository"
          />
          <GlowMetricCard 
            title="Total Runs" value={0} icon={Server} 
            gradient="from-blue-500 to-cyan-500" bgGlow="bg-blue-500/5" description="All time"
          />
          <GlowMetricCard 
            title="Pass Rate" value="--" icon={Shield} 
            gradient="from-slate-500 to-slate-600" bgGlow="bg-slate-500/5" description="No tests yet"
          />
        </div>

        <Card className="card-shadow">
          <CardHeader>
            <CardTitle>Recent Tests</CardTitle>
            <CardDescription>Latest test executions with performance metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-10 text-muted-foreground">
              <Activity className="w-10 h-10 mx-auto mb-3 text-muted-foreground/40" />
              <p className="font-medium">No tests run yet</p>
              <p className="text-sm mt-1">Upload a script and schedule your first test to see results here</p>
              <Link href="/scripts">
                <Button className="mt-4" size="sm">
                  <Upload className="w-4 h-4 mr-2" /> Upload Your First Script
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const favoriteScripts = scripts.filter((s: Script) => favorites.includes(s.id));
  const runningExecutions = allExecutions?.filter(e => e.status === 'running') || [];
  const allFailed = allExecutions?.filter(e => e.status === 'failed') || [];
  const failedCount = allFailed.length;
  const passedCount = allExecutions?.filter(e => e.status === 'completed').length || 0;
  const totalDone = passedCount + failedCount;
  const trendIcon = stats.passRate >= 80 ? TrendingUp : stats.passRate >= 50 ? Minus : TrendingDown;
  const trendColor = stats.passRate >= 80 ? "text-emerald-400" : stats.passRate >= 50 ? "text-amber-400" : "text-rose-400";
  const perf = stats.performanceMetrics;
  const today = stats.todayStats;

  return (
    <div className="section-gap">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes barGrowH {
          from { transform: scaleX(0); transform-origin: left; }
          to { transform: scaleX(1); transform-origin: left; }
        }
      `}</style>

      <div className="mb-6 sm:mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium text-muted-foreground">{getGreeting()}</span>
            </div>
            <h1 className="page-title">
              {user?.username ? `Welcome, ${user.username}` : "Dashboard"}
            </h1>
            <p className="page-subtitle mt-1">Performance monitoring & test management</p>
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <Link href="/scripts">
              <Button size="lg" className="btn-primary-glow">
                <Play className="w-4 h-4 mr-2" /> New Test
                <kbd className="hidden sm:inline-flex ml-2 h-5 items-center rounded border border-white/20 bg-white/10 px-1.5 font-mono text-[10px] font-medium text-white/60">
                  N
                </kbd>
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-5" role="region" aria-label="Key metrics">
        <Link href="/executions?status=running">
          <GlowMetricCard 
            title="Active Tests" 
            value={stats.activeTests} 
            icon={Zap} 
            gradient="from-amber-500 to-orange-500"
            bgGlow="bg-amber-500/5"
            description="Running now"
            pulse={stats.activeTests > 0}
          />
        </Link>
        <Link href="/scripts">
          <GlowMetricCard 
            title="Test Scripts" 
            value={stats.totalScripts} 
            icon={FileCode} 
            gradient="from-indigo-500 to-violet-500"
            bgGlow="bg-indigo-500/5"
            description="In repository"
          />
        </Link>
        <Link href="/executions">
          <GlowMetricCard 
            title="Total Runs" 
            value={stats.totalExecutions} 
            icon={Server} 
            gradient="from-blue-500 to-cyan-500"
            bgGlow="bg-blue-500/5"
            description="All time"
          />
        </Link>
        <GlowMetricCard 
          title="Pass Rate" 
          value={`${stats.passRate.toFixed(1)}%`} 
          icon={Shield} 
          gradient={stats.passRate >= 80 ? "from-emerald-500 to-teal-500" : stats.passRate >= 50 ? "from-amber-500 to-yellow-500" : "from-rose-500 to-red-500"}
          bgGlow={stats.passRate >= 80 ? "bg-emerald-500/5" : stats.passRate >= 50 ? "bg-amber-500/5" : "bg-rose-500/5"}
          description={stats.passRate >= 80 ? "Healthy" : stats.passRate >= 50 ? "Needs attention" : "Critical"}
          trend={trendIcon}
          trendColor={trendColor}
        />
      </div>


      {today && (today.completed > 0 || today.failed > 0 || today.running > 0) && (
        <div className="rounded-xl border border-border/40 bg-card/50 p-4" role="region" aria-label="Today's activity" style={{ animationName: 'fadeSlideIn', animationDuration: '0.4s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: '150ms' }}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-primary" />
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Today's Activity</p>
            </div>
            <span className="text-xs text-muted-foreground">{format(new Date(), "EEEE, MMMM d")}</span>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="flex items-center gap-3 p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/15">
              <CheckCircle className="w-5 h-5 text-emerald-500" />
              <div>
                <p className="text-lg font-bold text-emerald-500">{today.completed}</p>
                <p className="text-[10px] uppercase font-bold text-muted-foreground">Completed</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg bg-rose-500/5 border border-rose-500/15">
              <XCircle className="w-5 h-5 text-rose-500" />
              <div>
                <p className="text-lg font-bold text-rose-500">{today.failed}</p>
                <p className="text-[10px] uppercase font-bold text-muted-foreground">Failed</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg bg-amber-500/5 border border-amber-500/15">
              <Zap className="w-5 h-5 text-amber-500" />
              <div>
                <p className="text-lg font-bold text-amber-500">{today.running}</p>
                <p className="text-[10px] uppercase font-bold text-muted-foreground">Running</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {totalDone > 0 && (
        <div className="rounded-xl border border-border/40 bg-card/50 p-4 sm:p-5" role="region" aria-label="Execution results">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Execution Results</p>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500/70" /> Passed
              </span>
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className="w-2.5 h-2.5 rounded-sm bg-rose-500/70" /> Failed
              </span>
            </div>
          </div>
          <ExecutionMiniChart passed={passedCount} failed={failedCount} total={totalDone} />
        </div>
      )}

      {runningExecutions.length > 0 && (
        <Card className="card-shadow border-l-4 border-l-amber-500 overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-r from-amber-500/5 to-transparent pointer-events-none" />
          <CardHeader className="pb-2 relative">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Zap className="w-5 h-5 text-amber-500 animate-pulse" />
              Live Tests Running
              <span className="ml-auto text-xs font-mono text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{runningExecutions.length} active</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="relative">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {runningExecutions.slice(0, 6).map((exec) => (
                <Link key={exec.id} href={`/executions/${exec.id}`}>
                  <div className="p-3 rounded-xl border border-amber-200 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-900/20 hover:bg-amber-100/50 dark:hover:bg-amber-900/30 transition-all cursor-pointer group">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                        <span className="font-medium text-sm truncate">{exec.schedule?.name || (exec as any).testName || exec.executionId}</span>
                      </div>
                      <Eye className="w-4 h-4 text-muted-foreground group-hover:text-amber-600" />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Started {exec.startTime ? format(new Date(exec.startTime), "HH:mm") : "-"}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-5" role="region" aria-label="Quick actions">
        <QuickActionCard
          icon={Clock}
          iconColor="text-indigo-500"
          iconBg="bg-indigo-500/10"
          label="Scheduled"
          value={allExecutions?.filter(e => e.status === 'scheduled').length || 0}
          href="/schedule"
          action="View"
        />
        <QuickActionCard
          icon={XCircle}
          iconColor="text-rose-500"
          iconBg="bg-rose-500/10"
          label="Failed"
          value={failedCount}
          href="/executions?status=failed"
          action="Review"
        />
        <QuickActionCard
          icon={BarChart3}
          iconColor="text-emerald-500"
          iconBg="bg-emerald-500/10"
          label="Reports"
          value={stats.totalExecutions}
          href="/reports"
          action="Open"
        />
      </div>

      {favoriteScripts.length > 0 && (
        <Card className="card-shadow">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                Favorite Scripts
              </CardTitle>
              <CardDescription>Quick access to your pinned scripts</CardDescription>
            </div>
            <Link href="/scripts">
              <span className="text-sm font-semibold text-primary hover:underline cursor-pointer flex items-center gap-1">
                View All <ArrowRight className="w-4 h-4" />
              </span>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {favoriteScripts.map((script: Script) => (
                <Link key={script.id} href={`/scripts/${script.id}`}>
                  <div className="p-4 rounded-xl border border-border/40 hover:border-primary/30 hover:bg-muted/30 transition-all cursor-pointer group">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-primary/10">
                          <FileCode className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold group-hover:text-primary transition-colors">{script.name}</h4>
                          <p className="text-xs text-muted-foreground">{script.toolType}</p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={(e) => {
                          e.preventDefault();
                          toggleFavorite.mutate(script.id);
                        }}
                      >
                        <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                      </Button>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="card-shadow">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Recent Tests</CardTitle>
            <CardDescription>Latest test executions with performance metrics</CardDescription>
          </div>
          <Link href="/executions">
            <span className="text-sm font-semibold text-primary hover:underline cursor-pointer flex items-center gap-1">
              View All <ArrowRight className="w-4 h-4" />
            </span>
          </Link>
        </CardHeader>
        <CardContent>
          {!stats.recentExecutions || stats.recentExecutions.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Activity className="w-10 h-10 mx-auto mb-3 text-muted-foreground/40" />
              <p className="font-medium">No recent activity</p>
              <p className="text-sm mt-1">Run a test to see results here</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-lg border border-border/40">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-muted-foreground">
                  <tr>
                    <th className="text-left px-4 py-2.5 font-semibold text-xs uppercase tracking-wider">Test Name</th>
                    <th className="text-left px-4 py-2.5 font-semibold text-xs uppercase tracking-wider">Status</th>
                    <th className="text-right px-4 py-2.5 font-semibold text-xs uppercase tracking-wider hidden sm:table-cell">Avg RT</th>
                    <th className="text-right px-4 py-2.5 font-semibold text-xs uppercase tracking-wider hidden md:table-cell">Throughput</th>
                    <th className="text-right px-4 py-2.5 font-semibold text-xs uppercase tracking-wider hidden lg:table-cell">Error Rate</th>
                    <th className="text-right px-4 py-2.5 font-semibold text-xs uppercase tracking-wider">When</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/30">
                  {stats.recentExecutions
                    .filter(exec => exec != null)
                    .map((exec, idx) => {
                      const rs = exec.resultSummary as any;
                      return (
                        <tr
                          key={exec.id}
                          className="hover:bg-muted/20 transition-colors cursor-pointer group"
                          style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: `${idx * 40}ms` }}
                        >
                          <td className="px-4 py-3">
                            <Link href={`/executions/${exec.id}`}>
                              <div className="flex items-center gap-3">
                                <div className={`p-2 rounded-lg shrink-0 ${exec.status === 'failed' ? 'bg-rose-500/10' : exec.status === 'completed' ? 'bg-emerald-500/10' : exec.status === 'running' ? 'bg-amber-500/10' : 'bg-muted'}`}>
                                  {exec.status === 'failed' ? <XCircle className="w-4 h-4 text-rose-500" /> : exec.status === 'completed' ? <CheckCircle className="w-4 h-4 text-emerald-500" /> : exec.status === 'running' ? <Zap className="w-4 h-4 text-amber-500 animate-pulse" /> : <Clock className="w-4 h-4 text-muted-foreground" />}
                                </div>
                                <div className="min-w-0">
                                  <p className="font-semibold truncate group-hover:text-primary transition-colors">{exec.schedule?.name || (exec as any).testName || exec.executionId}</p>
                                  <p className="text-xs text-muted-foreground">{exec.schedule?.script?.name || ''}</p>
                                </div>
                              </div>
                            </Link>
                          </td>
                          <td className="px-4 py-3">
                            <StatusBadge status={exec.status} />
                          </td>
                          <td className="px-4 py-3 text-right hidden sm:table-cell">
                            {rs?.avgResponseTime ? (
                              <span className="font-mono font-semibold">{Math.round(rs.avgResponseTime)} ms</span>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-right hidden md:table-cell">
                            {rs?.throughput ? (
                              <span className="font-mono font-semibold">{rs.throughput.toFixed(1)} /s</span>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-right hidden lg:table-cell">
                            {rs?.errorRate !== undefined ? (
                              <span className={`font-mono font-semibold ${rs.errorRate * 100 > 5 ? 'text-rose-500' : rs.errorRate * 100 > 1 ? 'text-amber-500' : 'text-emerald-500'}`}>
                                {(rs.errorRate * 100).toFixed(2)}%
                              </span>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <span className="text-xs text-muted-foreground whitespace-nowrap">
                              {exec.startTime ? formatDistanceToNow(new Date(exec.startTime), { addSuffix: true }) : "-"}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function GlowMetricCard({ title, value, icon: Icon, gradient, bgGlow, description, pulse, trend: TrendIcon, trendColor }: { 
  title: string; value: number | string; icon: any; gradient: string; bgGlow: string; description: string; pulse?: boolean; trend?: any; trendColor?: string;
}) {
  return (
    <Card className={`card-shadow group cursor-pointer hover:scale-[1.03] transition-all duration-200 overflow-hidden relative`}>
      <div className={`absolute inset-0 ${bgGlow} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
      <CardContent className="p-4 sm:p-5 relative">
        <div className="flex items-center justify-between gap-3">
          <div className={`p-3 rounded-xl bg-gradient-to-br ${gradient} shadow-lg shrink-0`}>
            <Icon className={`h-5 w-5 text-white ${pulse ? 'animate-pulse' : ''}`} />
          </div>
          <div className="text-right min-w-0">
            <p className="text-[10px] sm:text-xs font-bold text-muted-foreground uppercase tracking-wider truncate">{title}</p>
            <div className="flex items-center justify-end gap-1.5 mt-0.5">
              <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">{value}</h3>
              {TrendIcon && (
                <TrendIcon className={`w-4 h-4 ${trendColor} hidden sm:block`} />
              )}
            </div>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-2">
          <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
            <div className={`h-full bg-gradient-to-r ${gradient} opacity-60 w-3/4 transition-all duration-500 group-hover:w-full`} />
          </div>
          <span className="text-[9px] sm:text-[10px] font-semibold text-muted-foreground/60 uppercase whitespace-nowrap hidden sm:inline">{description}</span>
        </div>
      </CardContent>
    </Card>
  );
}

function ExecutionMiniChart({ passed, failed, total }: { passed: number; failed: number; total: number }) {
  const passedPct = total > 0 ? (passed / total) * 100 : 0;
  const failedPct = total > 0 ? (failed / total) * 100 : 0;
  
  return (
    <div>
      <div className="flex items-center gap-1 h-6 rounded-lg overflow-hidden">
        {passedPct > 0 && (
          <div 
            className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400 rounded-l-lg transition-all duration-700 flex items-center justify-center"
            style={{ width: `${passedPct}%`, animationName: 'barGrowH', animationDuration: '0.8s', animationTimingFunction: 'ease-out', animationFillMode: 'both' }}
          >
            {passedPct > 15 && <span className="text-[10px] font-bold text-white">{passed}</span>}
          </div>
        )}
        {failedPct > 0 && (
          <div 
            className="h-full bg-gradient-to-r from-rose-500 to-rose-400 rounded-r-lg transition-all duration-700 flex items-center justify-center"
            style={{ width: `${failedPct}%`, animationName: 'barGrowH', animationDuration: '0.8s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: '0.2s' }}
          >
            {failedPct > 15 && <span className="text-[10px] font-bold text-white">{failed}</span>}
          </div>
        )}
      </div>
      <div className="flex items-center justify-between mt-2">
        <span className="text-xs text-muted-foreground">{passed} passed</span>
        <span className="text-xs text-muted-foreground">{failed} failed of {total} total</span>
      </div>
    </div>
  );
}

function QuickActionCard({ icon: Icon, iconColor, iconBg, label, value, href, action }: {
  icon: any; iconColor: string; iconBg: string; label: string; value: number; href: string; action: string;
}) {
  return (
    <Card className="card-shadow hover:border-primary/30 transition-all group">
      <CardContent className="p-5 sm:p-6">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-xl ${iconBg} group-hover:scale-110 transition-transform`}>
            <Icon className={`w-6 h-6 ${iconColor}`} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-muted-foreground font-medium">{label}</p>
            <p className="text-2xl font-bold mt-0.5">{value}</p>
          </div>
          <Link href={href}>
            <Button variant="ghost" size="sm" className="text-primary font-semibold">{action}</Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Skeleton className="h-5 w-32" />
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-4 w-80" />
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-32 w-full rounded-2xl" />
        ))}
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-20 w-full rounded-xl" />
        ))}
      </div>
      <Skeleton className="h-20 rounded-xl" />
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        {[...Array(3)].map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-xl" />
        ))}
      </div>
      <Skeleton className="h-64 rounded-2xl" />
    </div>
  );
}
