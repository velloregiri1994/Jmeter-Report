import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/page-header";
import { StatusBadge } from "@/components/status-badge";
import { Link } from "wouter";
import { ChevronLeft, ChevronRight, CalendarDays, Clock, Play, FileCode } from "lucide-react";
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, addMonths, subMonths, isSameMonth, isSameDay, isToday } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { queryKeys } from "@/lib/query-keys";

interface Schedule {
  id: number;
  name: string;
  scriptId: number;
  scheduledTime: string;
  status: string;
  recurrence: string | null;
  configuration: any;
  script?: { name: string };
}

interface Execution {
  id: number;
  executionId: string;
  scheduleId: number;
  startTime: string | null;
  endTime: string | null;
  status: string;
  schedule?: { name: string; scriptId: number };
}

export default function TestCalendar() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const { data: schedules = [] } = useQuery<Schedule[]>({
    queryKey: [...queryKeys.schedules.all],
    queryFn: () => apiRequest("GET", "/api/schedules").then(r => r.json()),
  });

  const { data: executions = [] } = useQuery<Execution[]>({
    queryKey: [...queryKeys.executions.all, "calendar"],
    queryFn: () => apiRequest("GET", "/api/executions?limit=100").then(r => r.json()).then(res => res.data || res),
  });

  const calendarDays = useMemo(() => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(currentMonth);
    const calStart = startOfWeek(monthStart, { weekStartsOn: 0 });
    const calEnd = endOfWeek(monthEnd, { weekStartsOn: 0 });
    
    const days: Date[] = [];
    let day = calStart;
    while (day <= calEnd) {
      days.push(day);
      day = addDays(day, 1);
    }
    return days;
  }, [currentMonth]);

  const getEventsForDate = (date: Date) => {
    const events: { type: 'schedule' | 'execution'; name: string; status: string; id: number; time: string }[] = [];
    
    for (const s of schedules) {
      if (s.scheduledTime && isSameDay(new Date(s.scheduledTime), date)) {
        events.push({
          type: 'schedule',
          name: s.name,
          status: s.status,
          id: s.id,
          time: format(new Date(s.scheduledTime), "HH:mm"),
        });
      }
    }
    
    for (const e of executions) {
      const execDate = e.startTime || e.endTime;
      if (execDate && isSameDay(new Date(execDate), date)) {
        const alreadyHasSchedule = events.some(ev => ev.type === 'schedule' && ev.id === e.scheduleId);
        if (!alreadyHasSchedule) {
          events.push({
            type: 'execution',
            name: e.schedule?.name || `Execution #${e.id}`,
            status: e.status,
            id: e.id,
            time: format(new Date(execDate), "HH:mm"),
          });
        }
      }
    }
    
    return events.sort((a, b) => a.time.localeCompare(b.time));
  };

  const statusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-emerald-500';
      case 'running': return 'bg-amber-500';
      case 'queued': case 'pending': return 'bg-blue-500';
      case 'failed': return 'bg-red-500';
      case 'cancelled': return 'bg-slate-400';
      default: return 'bg-slate-400';
    }
  };

  const selectedEvents = selectedDate ? getEventsForDate(selectedDate) : [];

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div className="grid lg:grid-cols-[1fr,320px] gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <CalendarDays className="w-5 h-5 text-primary" />
              {format(currentMonth, "MMMM yyyy")}
            </CardTitle>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => { setCurrentMonth(new Date()); setSelectedDate(new Date()); }}>
                Today
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-px bg-border rounded-lg overflow-hidden">
              {weekDays.map(day => (
                <div key={day} className="bg-muted/50 px-2 py-2 text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  {day}
                </div>
              ))}
              {calendarDays.map((day, i) => {
                const events = getEventsForDate(day);
                const inMonth = isSameMonth(day, currentMonth);
                const today = isToday(day);
                const selected = selectedDate && isSameDay(day, selectedDate);
                
                return (
                  <div
                    key={i}
                    className={`bg-card min-h-[80px] p-1.5 cursor-pointer transition-colors hover:bg-muted/30 ${!inMonth ? 'opacity-30' : ''} ${selected ? 'ring-2 ring-primary ring-inset' : ''}`}
                    onClick={() => setSelectedDate(day)}
                  >
                    <div className={`text-xs font-medium mb-1 w-6 h-6 flex items-center justify-center rounded-full ${today ? 'bg-primary text-primary-foreground' : 'text-foreground'}`}>
                      {format(day, "d")}
                    </div>
                    <div className="space-y-0.5">
                      {events.slice(0, 3).map((event, j) => (
                        <div key={j} className="flex items-center gap-1">
                          <span className={`w-1.5 h-1.5 rounded-full ${statusColor(event.status)} shrink-0`} />
                          <span className="text-[10px] truncate leading-tight">{event.name}</span>
                        </div>
                      ))}
                      {events.length > 3 && (
                        <span className="text-[10px] text-muted-foreground font-medium">+{events.length - 3} more</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex items-center gap-4 mt-4 pt-3 border-t text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-500" /> Completed</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-blue-500" /> Pending</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-amber-500" /> Running</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-red-500" /> Failed</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-slate-400" /> Cancelled</span>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">
                {selectedDate ? format(selectedDate, "EEEE, MMMM d, yyyy") : "Select a date"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!selectedDate ? (
                <p className="text-sm text-muted-foreground py-4 text-center">Click a date on the calendar to see tests</p>
              ) : selectedEvents.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">No tests on this date</p>
              ) : (
                <div className="space-y-2">
                  {selectedEvents.map((event, i) => (
                    <Link key={i} href={event.type === 'execution' ? `/executions/${event.id}` : `/schedule`}>
                      <div className="p-3 rounded-lg border hover:bg-muted/30 transition-colors cursor-pointer">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium truncate">{event.name}</span>
                          <StatusBadge status={event.status} />
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          <span>{event.time}</span>
                          <span className="capitalize">{event.type}</span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Month Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <MonthSummary schedules={schedules} executions={executions} currentMonth={currentMonth} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function MonthSummary({ schedules, executions, currentMonth }: { schedules: Schedule[]; executions: Execution[]; currentMonth: Date }) {
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);

  const monthSchedules = schedules.filter(s => {
    const d = new Date(s.scheduledTime);
    return d >= monthStart && d <= monthEnd;
  });

  const monthExecutions = executions.filter(e => {
    const d = new Date(e.startTime || e.endTime || "");
    return d >= monthStart && d <= monthEnd;
  });

  const completed = monthExecutions.filter(e => e.status === 'completed').length;
  const failed = monthExecutions.filter(e => e.status === 'failed').length;
  const pending = monthSchedules.filter(s => s.status === 'pending').length;

  return (
    <div className="grid grid-cols-3 gap-2 text-center">
      <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
        <p className="text-lg font-bold text-emerald-500">{completed}</p>
        <p className="text-[10px] text-muted-foreground uppercase">Completed</p>
      </div>
      <div className="p-2 rounded-lg bg-red-500/10 border border-red-500/20">
        <p className="text-lg font-bold text-red-500">{failed}</p>
        <p className="text-[10px] text-muted-foreground uppercase">Failed</p>
      </div>
      <div className="p-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
        <p className="text-lg font-bold text-blue-500">{pending}</p>
        <p className="text-[10px] text-muted-foreground uppercase">Pending</p>
      </div>
    </div>
  );
}
