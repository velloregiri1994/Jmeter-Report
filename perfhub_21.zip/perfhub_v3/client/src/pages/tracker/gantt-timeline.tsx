import { useState, useMemo } from "react";
import { format } from "date-fns";
import type { TrackerRecord } from "./types";
import { formatDuration, getBarColor } from "./utils";

export function GanttTimeline({ records }: { records: TrackerRecord[] }) {
  const [hoveredRecord, setHoveredRecord] = useState<TrackerRecord | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const ganttData = useMemo(() => {
    if (!records.length) return null;

    const timestamps = records
      .filter(r => r.executionTimestamp)
      .map(r => new Date(r.executionTimestamp).getTime());

    if (!timestamps.length) return null;

    const minTime = Math.min(...timestamps);
    const maxDuration = Math.max(...records.map(r => (r.durationSeconds || 0) * 1000));
    const maxTime = Math.max(...timestamps) + Math.max(maxDuration, 3600000);
    const timeRange = maxTime - minTime || 3600000;

    const groups: Record<string, TrackerRecord[]> = {};
    records.forEach(r => {
      const key = r.projectName || r.featureName || "Ungrouped";
      if (!groups[key]) groups[key] = [];
      groups[key].push(r);
    });

    const tickCount = Math.min(7, Math.max(3, 5));
    const ticks: { label: string; pct: number }[] = [];
    for (let i = 0; i < tickCount; i++) {
      const pct = i / (tickCount - 1);
      const time = minTime + pct * timeRange;
      const d = new Date(time);
      ticks.push({
        label: format(d, "MMM d HH:mm"),
        pct: pct * 100,
      });
    }

    return { groups, minTime, timeRange, ticks };
  }, [records]);

  if (!records.length || !ganttData) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        No data available for timeline view.
      </div>
    );
  }

  const { groups, minTime, timeRange, ticks } = ganttData;

  return (
    <div className="relative" role="img" aria-label="Test execution Gantt timeline">
      <div className="flex border-b border-border">
        <div className="w-[200px] shrink-0 px-3 py-2 text-xs font-medium text-muted-foreground border-r border-border">
          Project
        </div>
        <div className="flex-1 relative h-8">
          {ticks.map((tick, i) => (
            <div
              key={i}
              className="absolute top-0 h-full flex items-center"
              style={{ left: `${tick.pct}%`, transform: i === ticks.length - 1 ? 'translateX(-100%)' : i > 0 ? 'translateX(-50%)' : undefined }}
            >
              <span className="text-[10px] text-muted-foreground whitespace-nowrap">{tick.label}</span>
            </div>
          ))}
        </div>
      </div>

      {Object.entries(groups).map(([groupName, groupRecords]) => (
        <div key={groupName} className="flex border-b border-border hover:bg-muted/30 transition-colors" role="row">
          <div className="w-[200px] shrink-0 px-3 py-3 text-sm font-medium truncate border-r border-border flex items-center" title={groupName}>
            {groupName}
          </div>
          <div className="flex-1 relative py-2 min-h-[40px]">
            {ticks.map((tick, i) => (
              <div
                key={i}
                className="absolute top-0 bottom-0 border-l border-border/30"
                style={{ left: `${tick.pct}%` }}
              />
            ))}
            {groupRecords.map((r) => {
              if (!r.executionTimestamp) return null;
              const startMs = new Date(r.executionTimestamp).getTime();
              const leftPct = ((startMs - minTime) / timeRange) * 100;
              const durationMs = (r.durationSeconds || 0) * 1000;
              const widthPct = Math.max((durationMs / timeRange) * 100, 0.3);

              return (
                <div
                  key={r.id}
                  className={`absolute top-1/2 -translate-y-1/2 h-6 rounded ${getBarColor(r.status)} opacity-85 hover:opacity-100 transition-opacity ${r.executionId ? 'cursor-pointer' : ''}`}
                  style={{
                    left: `${leftPct}%`,
                    width: `max(${widthPct}%, 8px)`,
                  }}
                  role="button"
                  tabIndex={0}
                  aria-label={`${r.featureName || r.projectName || 'Unknown'}, Status: ${r.status || 'Unknown'}, Duration: ${formatDuration(r.durationSeconds)}`}
                  onClick={() => r.executionId && (window.location.href = `/executions/${r.executionId}`)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && r.executionId) {
                      window.location.href = `/executions/${r.executionId}`;
                    }
                  }}
                  onMouseEnter={(e) => {
                    setHoveredRecord(r);
                    setTooltipPos({ x: e.clientX, y: e.clientY });
                  }}
                  onMouseMove={(e) => {
                    setTooltipPos({ x: e.clientX, y: e.clientY });
                  }}
                  onMouseLeave={() => setHoveredRecord(null)}
                />
              );
            })}
          </div>
        </div>
      ))}

      {hoveredRecord && (
        <div
          role="tooltip"
          className="fixed z-50 bg-popover border border-border rounded-lg shadow-lg p-3 pointer-events-none max-w-xs"
          style={{
            left: tooltipPos.x + 12,
            top: tooltipPos.y - 10,
          }}
        >
          <div className="text-sm font-medium mb-1">{hoveredRecord.featureName || hoveredRecord.projectName || "Unknown"}</div>
          <div className="text-xs text-muted-foreground space-y-0.5">
            <div>Status: <span className="font-medium text-foreground">{hoveredRecord.status || "Unknown"}</span></div>
            <div>Duration: <span className="font-medium text-foreground">{formatDuration(hoveredRecord.durationSeconds)}</span></div>
            <div>Avg RT: <span className="font-medium text-foreground">{hoveredRecord.avgResponseTime?.toFixed(0) || "-"} ms</span></div>
            <div>Error Rate: <span className="font-medium text-foreground">{hoveredRecord.errorRate != null ? `${hoveredRecord.errorRate.toFixed(2)}%` : "-"}</span></div>
          </div>
        </div>
      )}
    </div>
  );
}
