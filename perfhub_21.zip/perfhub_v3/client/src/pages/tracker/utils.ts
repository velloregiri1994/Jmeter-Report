import { subDays, startOfDay, endOfDay } from "date-fns";
import type { TimePreset } from "./types";

export function formatDuration(seconds: number | null): string {
  if (!seconds) return "-";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

export function getPresetDates(preset: TimePreset): { startDate: string | null; endDate: string | null } {
  const now = new Date();
  switch (preset) {
    case "today":
      return { startDate: startOfDay(now).toISOString(), endDate: endOfDay(now).toISOString() };
    case "7d":
      return { startDate: startOfDay(subDays(now, 7)).toISOString(), endDate: endOfDay(now).toISOString() };
    case "30d":
      return { startDate: startOfDay(subDays(now, 30)).toISOString(), endDate: endOfDay(now).toISOString() };
    case "90d":
      return { startDate: startOfDay(subDays(now, 90)).toISOString(), endDate: endOfDay(now).toISOString() };
    case "all":
    default:
      return { startDate: null, endDate: null };
  }
}

export function getBarColor(status: string | null): string {
  if (!status) return "bg-gray-400";
  switch (status.toLowerCase()) {
    case "completed": return "bg-emerald-500";
    case "failed": return "bg-rose-500";
    case "running": return "bg-blue-500";
    default: return "bg-gray-400";
  }
}
