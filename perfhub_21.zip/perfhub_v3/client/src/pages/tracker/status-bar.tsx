export function StatusBar({ completed, failed, running, total }: { completed: number; failed: number; running: number; total: number }) {
  if (total === 0) return null;
  const pCompleted = (completed / total) * 100;
  const pFailed = (failed / total) * 100;
  const pRunning = (running / total) * 100;
  const other = total - completed - failed - running;
  const pOther = (other / total) * 100;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>Status Distribution</span>
        <span>{total} total</span>
      </div>
      <div className="h-3 rounded-full overflow-hidden flex bg-muted">
        {pCompleted > 0 && <div className="bg-emerald-500 transition-all" style={{ width: `${pCompleted}%` }} title={`Completed: ${completed}`} />}
        {pFailed > 0 && <div className="bg-rose-500 transition-all" style={{ width: `${pFailed}%` }} title={`Failed: ${failed}`} />}
        {pRunning > 0 && <div className="bg-blue-500 transition-all" style={{ width: `${pRunning}%` }} title={`Running: ${running}`} />}
        {pOther > 0 && <div className="bg-gray-400 transition-all" style={{ width: `${pOther}%` }} title={`Other: ${other}`} />}
      </div>
      <div className="flex flex-wrap gap-3 text-xs">
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" /> Completed ({completed})</span>
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-rose-500" /> Failed ({failed})</span>
        {running > 0 && <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-blue-500" /> Running ({running})</span>}
        {other > 0 && <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-gray-400" /> Other ({other})</span>}
      </div>
    </div>
  );
}
