import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, endOfDay } from "date-fns";
import { queryKeys } from "@/lib/query-keys";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, RefreshCw, ChevronLeft, ChevronRight, Calendar, X, BarChart3, Activity, CheckCircle2, XCircle, Zap, Layers, List, Trash2, GripVertical, GanttChart, ArrowUpDown, ArrowUp, ArrowDown, Bookmark, Save, Star, ClipboardList, Tag } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useState, useMemo, useCallback } from "react";
import { QueryErrorFallback } from "@/components/error-boundary";
import { EmptyState, emptyStates } from "@/components/empty-state";
import { PageHeader } from "@/components/page-header";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import type { TrackerRecord, TrackerStats, TimePreset, GroupBy, ViewMode } from "./types";
import { formatDuration, getPresetDates } from "./utils";
import { MiniSparkline } from "./mini-sparkline";
import { StatusBar } from "./status-bar";
import { InlineComment } from "./inline-comment";
import { GanttTimeline } from "./gantt-timeline";
import { SortableTableRow } from "./sortable-table-row";

export default function TrackerPage() {
  const { canWrite } = useAuth();
  const [page, setPage] = useState(1);
  const pageSize = 25;
  const [timePreset, setTimePreset] = useState<TimePreset>("all");
  const [customStart, setCustomStart] = useState("");
  const [customEnd, setCustomEnd] = useState("");
  const [filterProject, setFilterProject] = useState<string>("all");
  const [filterEnv, setFilterEnv] = useState<string>("all");
  const [filterReleaseTag, setFilterReleaseTag] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [groupBy, setGroupBy] = useState<GroupBy>("none");
  const [viewMode, setViewMode] = useState<ViewMode>("table");
  const [localRecords, setLocalRecords] = useState<TrackerRecord[] | null>(null);
  const [sortBy, setSortBy] = useState<string>("");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [saveViewOpen, setSaveViewOpen] = useState(false);
  const [saveViewName, setSaveViewName] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  type SavedView = { id: number; name: string; page: string; filters: Record<string, string>; isDefault: boolean };

  const { data: savedViews = [] } = useQuery<SavedView[]>({
    queryKey: queryKeys.savedViews.list("tracker"),
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/saved-views?page=tracker");
      return res.json();
    },
  });

  const saveViewMutation = useMutation({
    mutationFn: async (data: { name: string; filters: Record<string, string> }) => {
      const res = await apiRequest("POST", "/api/saved-views", { name: data.name, page: "tracker", filters: data.filters });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.savedViews.list("tracker") });
      toast({ title: "Filter view saved" });
      setSaveViewOpen(false);
      setSaveViewName("");
    },
  });

  const deleteViewMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/saved-views/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.savedViews.list("tracker") });
      toast({ title: "Filter view deleted" });
    },
  });

  const handleSaveCurrentView = () => {
    const filters: Record<string, string> = {};
    if (timePreset !== "all") filters.timePreset = timePreset;
    if (customStart) filters.customStart = customStart;
    if (customEnd) filters.customEnd = customEnd;
    if (filterProject !== "all") filters.filterProject = filterProject;
    if (filterEnv !== "all") filters.filterEnv = filterEnv;
    if (filterReleaseTag !== "all") filters.filterReleaseTag = filterReleaseTag;
    if (filterStatus !== "all") filters.filterStatus = filterStatus;
    if (sortBy) { filters.sortBy = sortBy; filters.sortDir = sortDir; }
    if (groupBy !== "none") filters.groupBy = groupBy;
    saveViewMutation.mutate({ name: saveViewName, filters });
  };

  const handleLoadView = (view: SavedView) => {
    const f = view.filters;
    setTimePreset((f.timePreset as TimePreset) || "all");
    setCustomStart(f.customStart || "");
    setCustomEnd(f.customEnd || "");
    setFilterProject(f.filterProject || "all");
    setFilterEnv(f.filterEnv || "all");
    setFilterReleaseTag(f.filterReleaseTag || "all");
    setFilterStatus(f.filterStatus || "all");
    setSortBy(f.sortBy || "");
    setSortDir((f.sortDir as "asc" | "desc") || "desc");
    setGroupBy((f.groupBy as GroupBy) || "none");
    setPage(1);
    setLocalRecords(null);
  };

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const deleteTrackerMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/test-tracker/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (q) => String(q.queryKey[0]).includes("/api/test-tracker") });
      toast({ title: "Tracker record deleted" });
    },
    onError: (err: Error) => {
      toast({ title: "Delete failed", description: err.message, variant: "destructive" });
    },
  });

  const reorderMutation = useMutation({
    mutationFn: async (orderedIds: number[]) => {
      await apiRequest("PATCH", "/api/test-tracker/reorder", { orderedIds });
    },
    onSuccess: () => {
      toast({ title: "Order updated" });
    },
    onError: (err: Error) => {
      setLocalRecords(null);
      toast({ title: "Reorder failed", description: err.message, variant: "destructive" });
    },
  });

  const dateFilter = useMemo(() => {
    if (timePreset === "custom") {
      return {
        startDate: customStart ? new Date(customStart).toISOString() : null,
        endDate: customEnd ? endOfDay(new Date(customEnd)).toISOString() : null,
      };
    }
    return getPresetDates(timePreset);
  }, [timePreset, customStart, customEnd]);

  const buildParams = useCallback(() => {
    const params = new URLSearchParams();
    if (dateFilter.startDate) params.set("startDate", dateFilter.startDate);
    if (dateFilter.endDate) params.set("endDate", dateFilter.endDate);
    if (filterProject !== "all") params.set("projectName", filterProject);
    if (filterEnv !== "all") params.set("environment", filterEnv);
    if (filterReleaseTag !== "all") params.set("releaseTag", filterReleaseTag);
    if (filterStatus !== "all") params.set("status", filterStatus);
    if (sortBy) {
      params.set("sortBy", sortBy);
      params.set("sortDir", sortDir);
    }
    return params;
  }, [dateFilter, filterProject, filterEnv, filterReleaseTag, filterStatus, sortBy, sortDir]);

  const { data: stats } = useQuery<TrackerStats>({
    queryKey: [...queryKeys.tracker.stats([dateFilter.startDate, dateFilter.endDate, filterProject, filterEnv, filterReleaseTag, filterStatus])],
    queryFn: async () => {
      const params = buildParams();
      const res = await apiRequest("GET", `/api/test-tracker/stats?${params.toString()}`);
      return res.json();
    },
  });

  const { data: trackerData, isLoading, isError, error, refetch } = useQuery<{ data: TrackerRecord[]; total: number; }>({
    queryKey: [...queryKeys.tracker.list([page, dateFilter.startDate, dateFilter.endDate, filterProject, filterEnv, filterReleaseTag, filterStatus, sortBy, sortDir])],
    queryFn: async () => {
      const params = buildParams();
      params.set("page", String(page));
      params.set("limit", String(pageSize));
      const res = await apiRequest("GET", `/api/test-tracker?${params.toString()}`);
      setLocalRecords(null);
      return res.json();
    },
    refetchInterval: 10000,
  });

  const { data: releaseTags = [] } = useQuery<{ id: number; name: string }[]>({
    queryKey: queryKeys.releaseTags,
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/release-tags");
      return res.json();
    },
  });

  const commentMutation = useMutation({
    mutationFn: async ({ id, comments }: { id: number; comments: string }) => {
      await apiRequest("PATCH", `/api/test-tracker/${id}/comment`, { comments });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (query) => {
        const key = query.queryKey[0];
        return typeof key === "string" && key.startsWith("/api/test-tracker");
      }});
      toast({ title: "Note saved" });
    },
    onError: () => {
      toast({ title: "Failed to save note", variant: "destructive" });
    },
  });

  if (isError) {
    return <QueryErrorFallback error={error} onRetry={() => refetch()} title="Failed to load tracker" />;
  }

  const records = localRecords || trackerData?.data || [];
  const total = trackerData?.total || 0;
  const totalPages = Math.ceil(total / pageSize);

  const handleExportCSV = () => {
    const params = buildParams();
    const qs = params.toString();
    window.open(`/api/test-tracker/export${qs ? '?' + qs : ''}`, "_blank");
  };

  const handlePresetChange = (preset: TimePreset) => {
    setTimePreset(preset);
    setPage(1);
    if (preset !== "custom") {
      setCustomStart("");
      setCustomEnd("");
    }
  };

  const handleFilterChange = (setter: (v: string) => void) => (value: string) => {
    setter(value);
    setPage(1);
  };

  const clearAllFilters = () => {
    setTimePreset("all");
    setCustomStart("");
    setCustomEnd("");
    setFilterProject("all");
    setFilterEnv("all");
    setFilterReleaseTag("all");
    setFilterStatus("all");
    setPage(1);
  };

  const hasActiveFilter = timePreset !== "all" || filterProject !== "all" || filterEnv !== "all" || filterReleaseTag !== "all" || filterStatus !== "all";

  const handleSort = useCallback((column: string) => {
    if (sortBy === column) {
      setSortDir(prev => prev === "asc" ? "desc" : "asc");
    } else {
      setSortBy(column);
      setSortDir("desc");
    }
    setPage(1);
    setLocalRecords(null);
  }, [sortBy]);

  const SortIcon = ({ column }: { column: string }) => {
    if (sortBy !== column) return <ArrowUpDown className="h-3 w-3 ml-1 opacity-30" />;
    return sortDir === "asc"
      ? <ArrowUp className="h-3 w-3 ml-1 text-primary" />
      : <ArrowDown className="h-3 w-3 ml-1 text-primary" />;
  };

  const getStatusBadge = (status: string | null) => {
    if (!status) return <Badge variant="outline">Unknown</Badge>;
    switch (status.toLowerCase()) {
      case "completed":
        return <Badge className="bg-green-500/10 text-green-700 border-green-200">Completed</Badge>;
      case "failed":
        return <Badge className="bg-red-500/10 text-red-700 border-red-200">Failed</Badge>;
      case "running":
        return <Badge className="bg-blue-500/10 text-blue-700 border-blue-200">Running</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const presets: { key: TimePreset; label: string }[] = [
    { key: "today", label: "Today" },
    { key: "7d", label: "7 Days" },
    { key: "30d", label: "30 Days" },
    { key: "90d", label: "90 Days" },
    { key: "all", label: "All Time" },
  ];

  const groupedRecords = useMemo(() => {
    if (groupBy === "none") return null;
    const groups: Record<string, TrackerRecord[]> = {};
    records.forEach(r => {
      let key = "Ungrouped";
      if (groupBy === "project") key = r.projectName || "No Project";
      else if (groupBy === "environment") key = r.environment || "No Environment";
      else if (groupBy === "testType") key = r.testTypeName || "No Test Type";
      if (!groups[key]) groups[key] = [];
      groups[key].push(r);
    });
    return groups;
  }, [records, groupBy]);

  const projectSparklines = useMemo(() => {
    if (!records.length) return {};
    const map: Record<string, number[]> = {};
    records.forEach(r => {
      const key = r.projectName || r.featureName || "Other";
      if (!map[key]) map[key] = [];
      if (r.avgResponseTime != null) map[key].push(r.avgResponseTime);
    });
    return map;
  }, [records]);

  const isDragEnabled = groupBy === "none" && viewMode === "table";

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const oldIndex = records.findIndex(r => r.id === active.id);
    const newIndex = records.findIndex(r => r.id === over.id);
    if (oldIndex === -1 || newIndex === -1) return;

    const reordered = arrayMove([...records], oldIndex, newIndex);
    setLocalRecords(reordered);
    reorderMutation.mutate(reordered.map(r => r.id));
  };

  const renderTableRows = (rows: TrackerRecord[]) => (
    rows.map((r, index) => (
      <TableRow key={r.id} className={`cursor-pointer hover:bg-primary/[0.04] transition-colors duration-150 ${index % 2 === 1 ? 'bg-muted/20' : ''}`} style={{ animation: `fadeSlideIn 0.3s ease-out ${Math.min(index, 10) * 0.03}s both` }} onClick={() => r.executionId && (window.location.href = `/executions/${r.executionId}`)}>
        <TableCell className="w-8 px-1">
          <div className="flex items-center justify-center p-1">
            <GripVertical className="h-4 w-4 text-muted-foreground/30" />
          </div>
        </TableCell>
        <TableCell className="whitespace-nowrap text-sm">
          {r.executionTimestamp ? format(new Date(r.executionTimestamp), "MMM d, yyyy HH:mm") : "-"}
        </TableCell>
        <TableCell className="text-sm">{r.projectName || "-"}</TableCell>
        <TableCell className="font-medium text-sm">{r.featureName || "-"}</TableCell>
        <TableCell className="text-sm">{r.testTypeName || "-"}</TableCell>
        <TableCell className="text-sm">{r.volume || "-"}</TableCell>
        <TableCell className="text-sm">{r.environment || "-"}</TableCell>
        <TableCell className="text-sm">
          {r.releaseTag ? (
            <Badge variant="outline" className="text-xs font-medium bg-violet-500/10 text-violet-700 dark:text-violet-400 border-violet-200 dark:border-violet-500/30">
              {r.releaseTag}
            </Badge>
          ) : "-"}
        </TableCell>
        <TableCell>{getStatusBadge(r.status)}</TableCell>
        <TableCell className="text-right text-sm">{formatDuration(r.durationSeconds)}</TableCell>
        <TableCell className="text-right text-sm">{r.avgResponseTime?.toFixed(0) || "-"}</TableCell>
        <TableCell className="text-right text-sm">{r.p95?.toFixed(0) || "-"}</TableCell>
        <TableCell className="text-right text-sm">{r.throughput?.toFixed(2) || "-"}</TableCell>
        <TableCell className="text-right">
          {r.errorRate != null ? (
            <span className={`font-medium text-sm ${r.errorRate < 1 ? 'text-emerald-600 dark:text-emerald-400' : r.errorRate <= 5 ? 'text-amber-600 dark:text-amber-400' : 'text-red-600 dark:text-red-400'}`}>
              {r.errorRate.toFixed(2)}%
            </span>
          ) : "-"}
        </TableCell>
        <TableCell>
          <MiniSparkline values={projectSparklines[r.projectName || r.featureName || "Other"] || []} color="#1496ff" />
        </TableCell>
        <TableCell>
          <InlineComment record={r} onSave={(id, c) => commentMutation.mutate({ id, comments: c })} />
        </TableCell>
        {canWrite && <TableCell>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" aria-label="Delete tracker record">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Tracker Record</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete this tracker record. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={() => deleteTrackerMutation.mutate(r.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </TableCell>}
      </TableRow>
    ))
  );

  const sortableHeaderClass = "cursor-pointer select-none hover:text-foreground transition-colors";

  const tableHeaders = (
    <TableHeader>
      <TableRow>
        <TableHead className="w-8 px-1"></TableHead>
        <TableHead className={sortableHeaderClass} onClick={() => handleSort("executionTimestamp")}>
          <span className="inline-flex items-center">Date <SortIcon column="executionTimestamp" /></span>
        </TableHead>
        <TableHead className={sortableHeaderClass} onClick={() => handleSort("projectName")}>
          <span className="inline-flex items-center">Project <SortIcon column="projectName" /></span>
        </TableHead>
        <TableHead className={sortableHeaderClass} onClick={() => handleSort("featureName")}>
          <span className="inline-flex items-center">Feature <SortIcon column="featureName" /></span>
        </TableHead>
        <TableHead>Test Type</TableHead>
        <TableHead>Volume</TableHead>
        <TableHead>Environment</TableHead>
        <TableHead>Release</TableHead>
        <TableHead className={sortableHeaderClass} onClick={() => handleSort("status")}>
          <span className="inline-flex items-center">Status <SortIcon column="status" /></span>
        </TableHead>
        <TableHead className={`text-right ${sortableHeaderClass}`} onClick={() => handleSort("durationSeconds")}>
          <span className="inline-flex items-center justify-end">Duration <SortIcon column="durationSeconds" /></span>
        </TableHead>
        <TableHead className={`text-right ${sortableHeaderClass}`} onClick={() => handleSort("avgResponseTime")}>
          <span className="inline-flex items-center justify-end">Avg RT <SortIcon column="avgResponseTime" /></span>
        </TableHead>
        <TableHead className={`text-right ${sortableHeaderClass}`} onClick={() => handleSort("p95")}>
          <span className="inline-flex items-center justify-end">P95 <SortIcon column="p95" /></span>
        </TableHead>
        <TableHead className={`text-right ${sortableHeaderClass}`} onClick={() => handleSort("throughput")}>
          <span className="inline-flex items-center justify-end">Throughput <SortIcon column="throughput" /></span>
        </TableHead>
        <TableHead className={`text-right ${sortableHeaderClass}`} onClick={() => handleSort("errorRate")}>
          <span className="inline-flex items-center justify-end">Error % <SortIcon column="errorRate" /></span>
        </TableHead>
        <TableHead>Trend</TableHead>
        <TableHead>Notes</TableHead>
        <TableHead className="w-10"></TableHead>
      </TableRow>
    </TableHeader>
  );

  return (
    <div className="section-gap">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
      <PageHeader
        title="Test Execution Tracker"
        subtitle="All completed test executions are displayed here automatically"
        actions={
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => refetch()}>
              <RefreshCw className="h-4 w-4 mr-2" /> Refresh
            </Button>
            <Button onClick={handleExportCSV}>
              <Download className="h-4 w-4 mr-2" /> Export CSV
            </Button>
          </div>
        }
      />

      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3" style={{ animation: 'fadeSlideIn 0.4s ease-out' }}>
          <Card className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-blue-600/5" />
            <CardContent className="p-4 relative">
              <div className="flex items-center gap-2 mb-1">
                <BarChart3 className="h-4 w-4 text-blue-500" />
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Total Tests</span>
              </div>
              <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{stats.total}</p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-emerald-600/5" />
            <CardContent className="p-4 relative">
              <div className="flex items-center gap-2 mb-1">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Completed</span>
              </div>
              <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{stats.completed}</p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-rose-500/10 to-rose-600/5" />
            <CardContent className="p-4 relative">
              <div className="flex items-center gap-2 mb-1">
                <XCircle className="h-4 w-4 text-rose-500" />
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Failed</span>
              </div>
              <p className="text-2xl font-bold text-rose-600 dark:text-rose-400">{stats.failed}</p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-amber-600/5" />
            <CardContent className="p-4 relative">
              <div className="flex items-center gap-2 mb-1">
                <Activity className="h-4 w-4 text-amber-500" />
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Running</span>
              </div>
              <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">{stats.running}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {stats && stats.total > 0 && (
        <Card style={{ animation: 'fadeSlideIn 0.5s ease-out 0.1s both' }}>
          <CardContent className="p-4">
            <StatusBar completed={stats.completed} failed={stats.failed} running={stats.running} total={stats.total} />
          </CardContent>
        </Card>
      )}

      <Card style={{ animation: 'fadeSlideIn 0.5s ease-out 0.2s both' }}>
        <CardHeader className="pb-3">
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <CardTitle className="text-lg">
                Execution History
                {total > 0 && <span className="text-sm font-normal text-muted-foreground ml-2">({total} records)</span>}
              </CardTitle>

              <div className="flex flex-wrap items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground shrink-0" />
                <div className="flex items-center rounded-lg border border-border overflow-hidden">
                  {presets.map((p) => (
                    <button
                      key={p.key}
                      onClick={() => handlePresetChange(p.key)}
                      className={`px-3 py-1.5 text-xs font-medium transition-colors border-r border-border last:border-r-0 ${
                        timePreset === p.key
                          ? "bg-primary text-primary-foreground"
                          : "bg-transparent hover:bg-muted text-muted-foreground"
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                  <button
                    onClick={() => handlePresetChange("custom")}
                    className={`px-3 py-1.5 text-xs font-medium transition-colors ${
                      timePreset === "custom"
                        ? "bg-primary text-primary-foreground"
                        : "bg-transparent hover:bg-muted text-muted-foreground"
                    }`}
                  >
                    Custom
                  </button>
                </div>
              </div>
            </div>

            {timePreset === "custom" && (
              <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-border">
                <div className="flex items-center gap-2">
                  <label className="text-xs text-muted-foreground whitespace-nowrap">From</label>
                  <input
                    type="date"
                    value={customStart}
                    onChange={(e) => { setCustomStart(e.target.value); setPage(1); }}
                    className="h-8 px-2 text-sm rounded-md border border-border bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-xs text-muted-foreground whitespace-nowrap">To</label>
                  <input
                    type="date"
                    value={customEnd}
                    onChange={(e) => { setCustomEnd(e.target.value); setPage(1); }}
                    className="h-8 px-2 text-sm rounded-md border border-border bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                </div>
                {(customStart || customEnd) && (
                  <button
                    onClick={() => { setCustomStart(""); setCustomEnd(""); setPage(1); }}
                    className="text-xs text-muted-foreground hover:text-foreground underline"
                  >
                    Clear dates
                  </button>
                )}
              </div>
            )}

            <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-border">
              {stats && stats.projects.length > 0 && (
                <Select value={filterProject} onValueChange={handleFilterChange(setFilterProject)}>
                  <SelectTrigger className="h-8 w-[150px] text-xs" aria-label="Filter by project">
                    <SelectValue placeholder="All Projects" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Projects</SelectItem>
                    {stats.projects.map(p => (
                      <SelectItem key={p} value={p}>{p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              {stats && stats.environments.length > 0 && (
                <Select value={filterEnv} onValueChange={handleFilterChange(setFilterEnv)}>
                  <SelectTrigger className="h-8 w-[150px] text-xs" aria-label="Filter by environment">
                    <SelectValue placeholder="All Environments" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Environments</SelectItem>
                    {stats.environments.map(e => (
                      <SelectItem key={e} value={e}>{e}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              {releaseTags.length > 0 && (
                <Select value={filterReleaseTag} onValueChange={handleFilterChange(setFilterReleaseTag)}>
                  <SelectTrigger className="h-8 w-[150px] text-xs" aria-label="Filter by release tag">
                    <SelectValue placeholder="All Releases" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Releases</SelectItem>
                    {releaseTags.map(t => (
                      <SelectItem key={t.id} value={t.name}>{t.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              <Select value={filterStatus} onValueChange={handleFilterChange(setFilterStatus)}>
                <SelectTrigger className="h-8 w-[130px] text-xs" aria-label="Filter by status">
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                  <SelectItem value="running">Running</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex items-center rounded-lg border border-border overflow-hidden ml-auto shrink-0">
                <button
                  onClick={() => setViewMode("table")}
                  className={`px-2.5 py-1.5 text-xs font-medium transition-colors border-r border-border ${viewMode === "table" ? "bg-primary text-primary-foreground" : "bg-transparent hover:bg-muted text-muted-foreground"}`}
                  title="Table view"
                  aria-label="Table view"
                >
                  <List className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => setViewMode("gantt")}
                  className={`px-2.5 py-1.5 text-xs font-medium transition-colors ${viewMode === "gantt" ? "bg-primary text-primary-foreground" : "bg-transparent hover:bg-muted text-muted-foreground"}`}
                  title="Gantt timeline view"
                  aria-label="Gantt timeline view"
                >
                  <GanttChart className="h-3.5 w-3.5" />
                </button>
              </div>

              {viewMode === "table" && (
                <div className="flex items-center rounded-lg border border-border overflow-hidden">
                  <button
                    onClick={() => setGroupBy("none")}
                    className={`px-2.5 py-1.5 text-xs font-medium transition-colors border-r border-border ${groupBy === "none" ? "bg-primary text-primary-foreground" : "bg-transparent hover:bg-muted text-muted-foreground"}`}
                    title="Flat list"
                  >
                    <List className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => setGroupBy("project")}
                    className={`px-2.5 py-1.5 text-xs font-medium transition-colors border-r border-border ${groupBy === "project" ? "bg-primary text-primary-foreground" : "bg-transparent hover:bg-muted text-muted-foreground"}`}
                    title="Group by Project"
                  >
                    <Layers className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => setGroupBy("environment")}
                    className={`px-2.5 py-1.5 text-xs font-medium transition-colors border-r border-border ${groupBy === "environment" ? "bg-primary text-primary-foreground" : "bg-transparent hover:bg-muted text-muted-foreground"}`}
                    title="Group by Environment"
                  >
                    <Zap className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => setGroupBy("testType")}
                    className={`px-2.5 py-1.5 text-xs font-medium transition-colors ${groupBy === "testType" ? "bg-primary text-primary-foreground" : "bg-transparent hover:bg-muted text-muted-foreground"}`}
                    title="Group by Test Type"
                  >
                    <BarChart3 className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}

              {hasActiveFilter && (
                <>
                  <button
                    onClick={clearAllFilters}
                    className="flex items-center gap-1 px-2 py-1 rounded text-xs text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                    title="Clear all filters"
                  >
                    <X className="h-3.5 w-3.5" /> Clear all
                  </button>
                  {canWrite && <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => setSaveViewOpen(true)}>
                    <Save className="h-3 w-3" /> Save View
                  </Button>}
                </>
              )}

              {savedViews.length > 0 && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="h-7 text-xs gap-1">
                      <Bookmark className="h-3 w-3" /> Views ({savedViews.length})
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    {savedViews.map(v => (
                      <DropdownMenuItem key={v.id} className="flex items-center justify-between group">
                        <button className="flex-1 text-left text-sm" onClick={() => handleLoadView(v)}>
                          <span className="flex items-center gap-1.5">
                            {v.isDefault && <Star className="h-3 w-3 text-amber-500 fill-amber-500" />}
                            {v.name}
                          </span>
                        </button>
                        {canWrite && <button
                          onClick={(e) => { e.stopPropagation(); deleteViewMutation.mutate(v.id); }}
                          className="opacity-0 group-hover:opacity-100 p-0.5 hover:text-destructive transition-opacity"
                          title="Delete view"
                        >
                          <X className="h-3 w-3" />
                        </button>}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : records.length === 0 ? (
            hasActiveFilter ? (
              <div className="text-center py-12 text-muted-foreground">
                No executions found for the selected filters.
              </div>
            ) : (
              <EmptyState {...emptyStates.tracker} />
            )
          ) : viewMode === "gantt" ? (
            <div className="overflow-x-auto">
              <div className="min-w-[600px]">
                <GanttTimeline records={records} />
              </div>
            </div>
          ) : groupBy !== "none" && groupedRecords ? (
            <div className="space-y-6">
              {Object.entries(groupedRecords).map(([group, rows]) => {
                const groupCompleted = rows.filter(r => r.status === "completed").length;
                const groupFailed = rows.filter(r => r.status === "failed").length;
                const groupAvgRT = rows.filter(r => r.avgResponseTime != null).length > 0
                  ? (rows.filter(r => r.avgResponseTime != null).reduce((s, r) => s + (r.avgResponseTime || 0), 0) / rows.filter(r => r.avgResponseTime != null).length).toFixed(0)
                  : "-";

                return (
                  <div key={group}>
                    <div className="flex items-center gap-3 mb-2 px-1">
                      <h3 className="text-sm font-semibold">{group}</h3>
                      <Badge variant="outline" className="text-xs">{rows.length} tests</Badge>
                      <span className="text-xs text-emerald-600 dark:text-emerald-400">{groupCompleted} passed</span>
                      {groupFailed > 0 && <span className="text-xs text-rose-600 dark:text-rose-400">{groupFailed} failed</span>}
                      <span className="text-xs text-muted-foreground">Avg RT: {groupAvgRT}ms</span>
                    </div>
                    <div className="rounded-md border overflow-x-auto">
                      <Table aria-label="Test tracker data">
                        {tableHeaders}
                        <TableBody>{renderTableRows(rows)}</TableBody>
                      </Table>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <>
              <div className="rounded-md border overflow-x-auto">
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext
                    items={records.map(r => r.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    <Table aria-label="Test tracker data">
                      {tableHeaders}
                      <TableBody>
                        {records.map((r, index) => (
                          <SortableTableRow
                            key={r.id}
                            record={r}
                            index={index}
                            isDragEnabled={isDragEnabled}
                            getStatusBadge={getStatusBadge}
                            projectSparklines={projectSparklines}
                            commentMutation={commentMutation}
                            deleteTrackerMutation={deleteTrackerMutation}
                          />
                        ))}
                      </TableBody>
                    </Table>
                  </SortableContext>
                </DndContext>
              </div>

              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    Page {page} of {totalPages}
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)} className="rounded-l-lg rounded-r-none border-r-0">
                      <ChevronLeft className="h-4 w-4" /> Previous
                    </Button>
                    <div className="px-3 py-1.5 text-sm font-medium bg-primary/5 border border-border">
                      {page} / {totalPages}
                    </div>
                    <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="rounded-r-lg rounded-l-none border-l-0">
                      Next <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      <Dialog open={saveViewOpen} onOpenChange={setSaveViewOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>Save Current Filters</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="view-name">View Name</Label>
              <Input
                id="view-name"
                placeholder="e.g., Production Load Tests"
                value={saveViewName}
                onChange={(e) => setSaveViewName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && saveViewName.trim() && handleSaveCurrentView()}
              />
            </div>
            <div className="text-xs text-muted-foreground space-y-1">
              <p className="font-medium">Saving filters:</p>
              {timePreset !== "all" && <p>Time: {timePreset}</p>}
              {filterProject !== "all" && <p>Project: {filterProject}</p>}
              {filterEnv !== "all" && <p>Environment: {filterEnv}</p>}
              {filterReleaseTag !== "all" && <p>Release: {filterReleaseTag}</p>}
              {filterStatus !== "all" && <p>Status: {filterStatus}</p>}
              {sortBy && <p>Sort: {sortBy} ({sortDir})</p>}
              {groupBy !== "none" && <p>Group by: {groupBy}</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSaveViewOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveCurrentView} disabled={!saveViewName.trim() || saveViewMutation.isPending}>
              {saveViewMutation.isPending ? "Saving..." : "Save View"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
