import { useState } from "react";
import { MessageSquare } from "lucide-react";
import type { TrackerRecord } from "./types";

export function InlineComment({ record, onSave }: { record: TrackerRecord; onSave: (id: number, comment: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(record.comments || "");

  const handleSave = () => {
    onSave(record.id, text);
    setEditing(false);
  };

  const handleCancel = () => {
    setText(record.comments || "");
    setEditing(false);
  };

  if (editing) {
    return (
      <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="h-7 px-2 text-xs rounded border border-border bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-ring w-32"
          autoFocus
          onKeyDown={(e) => { if (e.key === "Enter") handleSave(); if (e.key === "Escape") handleCancel(); }}
        />
        <button onClick={handleSave} className="text-xs text-primary hover:underline">Save</button>
        <button onClick={handleCancel} className="text-xs text-muted-foreground hover:underline">Cancel</button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1 group cursor-pointer" onClick={(e) => { e.stopPropagation(); setEditing(true); }}>
      {record.comments ? (
        <span className="text-xs truncate max-w-[120px]" title={record.comments}>{record.comments}</span>
      ) : (
        <span className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">Add note...</span>
      )}
      <MessageSquare className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
    </div>
  );
}
