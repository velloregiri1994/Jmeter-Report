export type TrackerRecord = {
  id: number;
  runId: string;
  executionTimestamp: string;
  projectId: number | null;
  projectName: string | null;
  featureName: string | null;
  testTypeId: number | null;
  testTypeName: string | null;
  volume: string | null;
  environment: string | null;
  comments: string | null;
  status: string | null;
  durationSeconds: number | null;
  avgResponseTime: number | null;
  p95: number | null;
  p99: number | null;
  throughput: number | null;
  errorRate: number | null;
  executionId: number | null;
  sortOrder: number | null;
  releaseTag: string | null;
};

export type TrackerStats = {
  total: number;
  completed: number;
  failed: number;
  running: number;
  passRate: number;
  avgResponseTime: number;
  totalDurationHours: number;
  avgThroughput: number;
  avgErrorRate: number;
  projects: string[];
  environments: string[];
  testTypes: string[];
};

export type TimePreset = "today" | "7d" | "30d" | "90d" | "custom" | "all";
export type GroupBy = "none" | "project" | "environment" | "testType";
export type ViewMode = "table" | "gantt";
