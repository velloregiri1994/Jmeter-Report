import { format } from "date-fns";
import { TableRow, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, Trash2 } from "lucide-react";
import type { TrackerRecord } from "./types";
import { formatDuration } from "./utils";
import { InlineComment } from "./inline-comment";
import { MiniSparkline } from "./mini-sparkline";

export function SortableTableRow({
  record,
  index,
  isDragEnabled,
  getStatusBadge,
  projectSparklines,
  commentMutation,
  deleteTrackerMutation,
}: {
  record: TrackerRecord;
  index: number;
  isDragEnabled: boolean;
  getStatusBadge: (status: string | null) => JSX.Element;
  projectSparklines: Record<string, number[]>;
  commentMutation: any;
  deleteTrackerMutation: any;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: record.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    animation: `fadeSlideIn 0.3s ease-out ${Math.min(index, 10) * 0.03}s both`,
  };

  return (
    <TableRow
      ref={setNodeRef}
      style={style}
      className={`cursor-pointer hover:bg-primary/[0.04] transition-colors duration-150 ${index % 2 === 1 ? 'bg-muted/20' : ''}`}
      onClick={() => record.executionId && (window.location.href = `/executions/${record.executionId}`)}
      role="row"
      aria-rowindex={index + 1}
      aria-roledescription="sortable"
    >
      <TableCell className="w-8 px-1">
        {isDragEnabled ? (
          <div
            {...attributes}
            {...listeners}
            className="flex items-center justify-center cursor-grab active:cursor-grabbing p-1 rounded hover:bg-muted transition-colors"
            onClick={(e) => e.stopPropagation()}
            aria-label="Drag to reorder"
          >
            <GripVertical className="h-4 w-4 text-muted-foreground" />
          </div>
        ) : (
          <div className="flex items-center justify-center p-1">
            <GripVertical className="h-4 w-4 text-muted-foreground/30" />
          </div>
        )}
      </TableCell>
      <TableCell className="whitespace-nowrap text-sm">
        {record.executionTimestamp ? format(new Date(record.executionTimestamp), "MMM d, yyyy HH:mm") : "-"}
      </TableCell>
      <TableCell className="text-sm">{record.projectName || "-"}</TableCell>
      <TableCell className="font-medium text-sm">{record.featureName || "-"}</TableCell>
      <TableCell className="text-sm">{record.testTypeName || "-"}</TableCell>
      <TableCell className="text-sm">{record.volume || "-"}</TableCell>
      <TableCell className="text-sm">{record.environment || "-"}</TableCell>
      <TableCell className="text-sm">
        {record.releaseTag ? (
          <Badge variant="outline" className="text-xs font-medium bg-violet-500/10 text-violet-700 dark:text-violet-400 border-violet-200 dark:border-violet-500/30">
            {record.releaseTag}
          </Badge>
        ) : "-"}
      </TableCell>
      <TableCell>{getStatusBadge(record.status)}</TableCell>
      <TableCell className="text-right text-sm">{formatDuration(record.durationSeconds)}</TableCell>
      <TableCell className="text-right text-sm">{record.avgResponseTime?.toFixed(0) || "-"}</TableCell>
      <TableCell className="text-right text-sm">{record.p95?.toFixed(0) || "-"}</TableCell>
      <TableCell className="text-right text-sm">{record.throughput?.toFixed(2) || "-"}</TableCell>
      <TableCell className="text-right">
        {record.errorRate != null ? (
          <span className={`font-medium text-sm ${record.errorRate < 1 ? 'text-emerald-600 dark:text-emerald-400' : record.errorRate <= 5 ? 'text-amber-600 dark:text-amber-400' : 'text-red-600 dark:text-red-400'}`}>
            {record.errorRate.toFixed(2)}%
          </span>
        ) : "-"}
      </TableCell>
      <TableCell>
        <MiniSparkline values={projectSparklines[record.projectName || record.featureName || "Other"] || []} color="#1496ff" />
      </TableCell>
      <TableCell>
        <InlineComment record={record} onSave={(id, c) => commentMutation.mutate({ id, comments: c })} />
      </TableCell>
      <TableCell>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={(e) => e.stopPropagation()} aria-label="Delete tracker record">
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Tracker Record</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete this tracker record. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={() => deleteTrackerMutation.mutate(record.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </TableCell>
    </TableRow>
  );
}
