import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import {
  Zap, Shield, CheckCircle, ArrowRight, ArrowLeft, Loader2,
  Server, Database, FileCode, Lock, Monitor, Settings,
  UserPlus, FileText, Rocket, Globe, Eye, EyeOff,
  AlertCircle, ChevronRight, Box, Cpu, HardDrive
} from "lucide-react";

type SetupStep = "welcome" | "requirements" | "license" | "admin" | "configuration" | "complete";

const STEPS: { key: SetupStep; label: string; icon: any }[] = [
  { key: "welcome", label: "Welcome", icon: Rocket },
  { key: "requirements", label: "System Check", icon: Monitor },
  { key: "license", label: "License Agreement", icon: FileText },
  { key: "admin", label: "Admin Account", icon: UserPlus },
  { key: "configuration", label: "Configuration", icon: Settings },
  { key: "complete", label: "Complete", icon: CheckCircle },
];

interface RequirementCheck {
  name: string;
  status: "pass" | "fail" | "warn" | "checking";
  detail: string;
  icon: any;
}

export default function SetupWizard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentStep, setCurrentStep] = useState<SetupStep>("welcome");
  const [licenseAccepted, setLicenseAccepted] = useState(false);
  const [licenseScrolled, setLicenseScrolled] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [adminForm, setAdminForm] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    organization: "",
  });
  const [configForm, setConfigForm] = useState({
    instanceName: "PerfHub",
    jmeterPath: "",
    dataRetentionDays: "90",
  });
  const [requirements, setRequirements] = useState<RequirementCheck[]>([
    { name: "PostgreSQL Database", status: "checking", detail: "Checking connection...", icon: Database },
    { name: "Node.js Runtime", status: "checking", detail: "Verifying version...", icon: Server },
    { name: "Disk Space", status: "checking", detail: "Checking available space...", icon: HardDrive },
    { name: "Network Connectivity", status: "checking", detail: "Testing connectivity...", icon: Globe },
  ]);

  const { data: setupStatus, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/setup/status"],
    queryFn: async () => {
      const res = await fetch("/api/setup/status");
      return res.json();
    },
  });

  useEffect(() => {
    if (setupStatus && !setupStatus.needsSetup) {
      setLocation("/");
    }
  }, [setupStatus, setLocation]);

  useEffect(() => {
    if (currentStep === "requirements") {
      runRequirementChecks();
    }
  }, [currentStep]);

  const runRequirementChecks = async () => {
    setRequirements(prev => prev.map(r => ({ ...r, status: "checking" as const, detail: "Checking..." })));

    try {
      const res = await fetch("/api/setup/check-requirements");
      const data = await res.json();

      setRequirements([
        {
          name: "PostgreSQL Database",
          status: data.database ? "pass" : "fail",
          detail: data.database ? "Connected successfully" : "Database connection failed",
          icon: Database,
        },
        {
          name: "Node.js Runtime",
          status: "pass",
          detail: `Version ${data.nodeVersion || process.env.NODE_VERSION || "20.x"}`,
          icon: Server,
        },
        {
          name: "Disk Space",
          status: data.diskSpace === "sufficient" ? "pass" : data.diskSpace === "low" ? "warn" : "fail",
          detail: data.diskSpaceDetail || "Available",
          icon: HardDrive,
        },
        {
          name: "Network Connectivity",
          status: "pass",
          detail: "Server accessible",
          icon: Globe,
        },
      ]);
    } catch {
      setRequirements(prev => prev.map(r => ({
        ...r,
        status: r.name === "Network Connectivity" ? "fail" as const : "checking" as const,
        detail: r.name === "Network Connectivity" ? "Cannot reach server" : "Check failed",
      })));
    }
  };

  const signupMutation = useMutation({
    mutationFn: async (data: { username: string; email: string; password: string }) => {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message);
      return json;
    },
    onSuccess: () => {
      setCurrentStep("configuration");
    },
    onError: (error: Error) => {
      toast({ title: "Account creation failed", description: error.message, variant: "destructive" });
    },
  });

  const completeMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" },
        body: JSON.stringify({ username: adminForm.username, password: adminForm.password }),
        credentials: "include",
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message);
      return json;
    },
    onError: (error: Error) => {
      toast({ title: "Setup error", description: error.message, variant: "destructive" });
    },
  });

  const handleAdminSubmit = () => {
    if (!adminForm.username.trim()) {
      toast({ title: "Username required", description: "Please enter a username for the admin account.", variant: "destructive" });
      return;
    }
    if (adminForm.password.length < 8) {
      toast({ title: "Password too short", description: "Password must be at least 8 characters.", variant: "destructive" });
      return;
    }
    if (adminForm.password !== adminForm.confirmPassword) {
      toast({ title: "Passwords don't match", description: "Please make sure both passwords are identical.", variant: "destructive" });
      return;
    }
    signupMutation.mutate({
      username: adminForm.username,
      email: adminForm.email,
      password: adminForm.password,
    });
  };

  const handleFinish = () => {
    completeMutation.mutate(undefined, {
      onSuccess: async (data) => {
        queryClient.setQueryData(["/api/auth/session"], { user: data.user, isAuthenticated: true });
        queryClient.invalidateQueries({ queryKey: ["/api/setup/status"] });

        if (configForm.jmeterPath.trim()) {
          try {
            await fetch("/api/config/jmeter", {
              method: "POST",
              headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" },
              body: JSON.stringify({ jmeterHome: configForm.jmeterPath.trim() }),
              credentials: "include",
            });
          } catch {}
        }

        toast({ title: "Setup complete!", description: "Welcome to PerfHub." });
        setLocation("/");
      },
    });
  };

  const handleLicenseScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    if (scrollHeight - scrollTop - clientHeight < 40) {
      setLicenseScrolled(true);
    }
  };

  const stepIndex = STEPS.findIndex(s => s.key === currentStep);

  const canProceed = () => {
    switch (currentStep) {
      case "requirements":
        return requirements.every(r => r.status === "pass" || r.status === "warn");
      case "license":
        return licenseAccepted;
      case "admin":
        return adminForm.username.length >= 3 &&
          adminForm.password.length >= 8 &&
          adminForm.password === adminForm.confirmPassword;
      default:
        return true;
    }
  };

  const goNext = () => {
    const idx = stepIndex;
    if (idx < STEPS.length - 1) {
      if (currentStep === "admin") {
        handleAdminSubmit();
        return;
      }
      setCurrentStep(STEPS[idx + 1].key);
    }
  };

  const goBack = () => {
    if (stepIndex > 0) {
      setCurrentStep(STEPS[stepIndex - 1].key);
    }
  };

  if (statusLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="text-center">
          <Loader2 className="h-10 w-10 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground text-sm">Checking installation status...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background flex">
      <aside className="hidden lg:flex w-80 bg-card border-r flex-col">
        <div className="p-6 border-b">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight">PerfHub</h1>
              <p className="text-[11px] text-muted-foreground font-medium uppercase tracking-wider">Installation Wizard</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4">
          <div className="space-y-1">
            {STEPS.map((step, idx) => {
              const isActive = step.key === currentStep;
              const isCompleted = idx < stepIndex;
              const isDisabled = idx > stepIndex;
              const Icon = step.icon;

              return (
                <div
                  key={step.key}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    isActive
                      ? "bg-primary/10 text-primary border border-primary/20"
                      : isCompleted
                      ? "text-foreground/70"
                      : "text-muted-foreground/50"
                  }`}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                    isCompleted
                      ? "bg-green-500/15 text-green-600"
                      : isActive
                      ? "bg-primary/15 text-primary"
                      : "bg-muted/50 text-muted-foreground/40"
                  }`}>
                    {isCompleted ? (
                      <CheckCircle className="w-4 h-4" />
                    ) : (
                      <Icon className="w-4 h-4" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-[13px] font-semibold ${isDisabled ? "text-muted-foreground/40" : ""}`}>
                      {step.label}
                    </p>
                    <p className="text-[10px] text-muted-foreground truncate">
                      {isCompleted ? "Completed" : isActive ? "In progress" : "Pending"}
                    </p>
                  </div>
                  {isActive && <ChevronRight className="w-4 h-4 text-primary/50" />}
                </div>
              );
            })}
          </div>
        </nav>

        <div className="p-4 border-t">
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-2">
              <span>Installation Progress</span>
              <span className="font-semibold">{Math.round(((stepIndex) / (STEPS.length - 1)) * 100)}%</span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full transition-all duration-500"
                style={{ width: `${((stepIndex) / (STEPS.length - 1)) * 100}%` }}
              />
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground mt-3 text-center">PerfHub v3.0.0 Enterprise</p>
        </div>
      </aside>

      <main className="flex-1 flex flex-col">
        <div className="lg:hidden border-b bg-card p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-bold">PerfHub Setup</span>
          </div>
          <div className="flex gap-1.5">
            {STEPS.map((_, idx) => (
              <div
                key={idx}
                className={`h-1 flex-1 rounded-full ${
                  idx <= stepIndex ? "bg-primary" : "bg-muted"
                }`}
              />
            ))}
          </div>
        </div>

        <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
          <div className="w-full max-w-2xl">
            {currentStep === "welcome" && <WelcomeStep />}
            {currentStep === "requirements" && (
              <RequirementsStep requirements={requirements} onRetry={runRequirementChecks} />
            )}
            {currentStep === "license" && (
              <LicenseStep
                accepted={licenseAccepted}
                scrolled={licenseScrolled}
                onAcceptChange={setLicenseAccepted}
                onScroll={handleLicenseScroll}
              />
            )}
            {currentStep === "admin" && (
              <AdminStep
                form={adminForm}
                onChange={setAdminForm}
                showPassword={showPassword}
                showConfirmPassword={showConfirmPassword}
                onTogglePassword={() => setShowPassword(!showPassword)}
                onToggleConfirmPassword={() => setShowConfirmPassword(!showConfirmPassword)}
                isPending={signupMutation.isPending}
              />
            )}
            {currentStep === "configuration" && (
              <ConfigurationStep form={configForm} onChange={setConfigForm} />
            )}
            {currentStep === "complete" && (
              <CompleteStep
                username={adminForm.username}
                onFinish={handleFinish}
                isPending={completeMutation.isPending}
              />
            )}
          </div>
        </div>

        {currentStep !== "complete" && (
          <div className="border-t bg-card p-4 lg:p-6">
            <div className="max-w-2xl mx-auto flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={goBack}
                disabled={stepIndex === 0}
                className="gap-2 text-[13px]"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </Button>
              <div className="text-[11px] text-muted-foreground">
                Step {stepIndex + 1} of {STEPS.length}
              </div>
              <Button
                onClick={goNext}
                disabled={!canProceed() || signupMutation.isPending}
                className="gap-2 text-[13px] shadow-md shadow-primary/20"
              >
                {signupMutation.isPending ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Setting up...</>
                ) : currentStep === "admin" ? (
                  <>Create Admin <ArrowRight className="w-4 h-4" /></>
                ) : (
                  <>Continue <ArrowRight className="w-4 h-4" /></>
                )}
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function WelcomeStep() {
  return (
    <div className="text-center">
      <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-primary/15 shadow-lg shadow-primary/5">
        <Rocket className="w-10 h-10 text-primary" />
      </div>
      <h2 className="text-3xl font-extrabold tracking-tight mb-3">Welcome to PerfHub</h2>
      <p className="text-base text-muted-foreground mb-8 max-w-lg mx-auto leading-relaxed">
        Enterprise Performance Engineering Platform. This wizard will guide you through the
        initial setup of your PerfHub instance in just a few steps.
      </p>

      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <SetupFeatureCard
          icon={Shield}
          title="Secure by Default"
          desc="Role-based access, encrypted passwords, and audit logging"
        />
        <SetupFeatureCard
          icon={Server}
          title="Self-Hosted"
          desc="Your data stays on your infrastructure, fully under your control"
        />
        <SetupFeatureCard
          icon={Box}
          title="All-in-One"
          desc="Test orchestration, live metrics, SLA monitoring, and reporting"
        />
      </div>

      <div className="bg-muted/30 rounded-xl p-4 border max-w-md mx-auto">
        <p className="text-[12px] text-muted-foreground leading-relaxed">
          <strong className="text-foreground">Estimated setup time:</strong> 2-3 minutes. You'll configure your
          admin account, review system requirements, and accept the license agreement.
        </p>
      </div>
    </div>
  );
}

function SetupFeatureCard({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <div className="bg-card border rounded-xl p-4 text-left">
      <div className="w-9 h-9 bg-primary/8 rounded-lg flex items-center justify-center mb-3">
        <Icon className="w-4.5 h-4.5 text-primary" />
      </div>
      <h3 className="text-[13px] font-bold mb-1">{title}</h3>
      <p className="text-[11px] text-muted-foreground leading-relaxed">{desc}</p>
    </div>
  );
}

function RequirementsStep({
  requirements,
  onRetry,
}: {
  requirements: RequirementCheck[];
  onRetry: () => void;
}) {
  const allPassed = requirements.every(r => r.status === "pass" || r.status === "warn");
  const anyFailed = requirements.some(r => r.status === "fail");
  const isChecking = requirements.some(r => r.status === "checking");

  return (
    <div>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
          <Monitor className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight">System Requirements</h2>
          <p className="text-sm text-muted-foreground">Verifying your environment meets all prerequisites</p>
        </div>
      </div>

      <div className="mt-6 space-y-3">
        {requirements.map((req, idx) => {
          const Icon = req.icon;
          return (
            <div
              key={idx}
              className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${
                req.status === "pass"
                  ? "bg-green-50/50 dark:bg-green-900/10 border-green-200/50 dark:border-green-800/30"
                  : req.status === "warn"
                  ? "bg-amber-50/50 dark:bg-amber-900/10 border-amber-200/50 dark:border-amber-800/30"
                  : req.status === "fail"
                  ? "bg-red-50/50 dark:bg-red-900/10 border-red-200/50 dark:border-red-800/30"
                  : "bg-muted/20 border-border/50"
              }`}
            >
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                req.status === "pass" ? "bg-green-100 dark:bg-green-900/30" :
                req.status === "warn" ? "bg-amber-100 dark:bg-amber-900/30" :
                req.status === "fail" ? "bg-red-100 dark:bg-red-900/30" :
                "bg-muted/50"
              }`}>
                <Icon className={`w-5 h-5 ${
                  req.status === "pass" ? "text-green-600 dark:text-green-400" :
                  req.status === "warn" ? "text-amber-600 dark:text-amber-400" :
                  req.status === "fail" ? "text-red-600 dark:text-red-400" :
                  "text-muted-foreground"
                }`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">{req.name}</p>
                <p className="text-xs text-muted-foreground">{req.detail}</p>
              </div>
              <div className="flex-shrink-0">
                {req.status === "checking" && <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />}
                {req.status === "pass" && <CheckCircle className="w-5 h-5 text-green-500" />}
                {req.status === "warn" && <AlertCircle className="w-5 h-5 text-amber-500" />}
                {req.status === "fail" && <AlertCircle className="w-5 h-5 text-red-500" />}
              </div>
            </div>
          );
        })}
      </div>

      {allPassed && !isChecking && (
        <div className="mt-6 bg-green-50/80 dark:bg-green-900/15 border border-green-200/50 dark:border-green-800/30 rounded-xl p-4 flex items-center gap-3">
          <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
          <p className="text-sm text-green-700 dark:text-green-400 font-medium">
            All system requirements are met. You can proceed with the installation.
          </p>
        </div>
      )}

      {anyFailed && !isChecking && (
        <div className="mt-6 flex items-center justify-between bg-red-50/80 dark:bg-red-900/15 border border-red-200/50 dark:border-red-800/30 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
            <p className="text-sm text-red-700 dark:text-red-400 font-medium">
              Some requirements are not met. Please resolve the issues and retry.
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={onRetry} className="text-xs">
            Retry Check
          </Button>
        </div>
      )}
    </div>
  );
}

function LicenseStep({
  accepted,
  scrolled,
  onAcceptChange,
  onScroll,
}: {
  accepted: boolean;
  scrolled: boolean;
  onAcceptChange: (v: boolean) => void;
  onScroll: (e: React.UIEvent<HTMLDivElement>) => void;
}) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
          <FileText className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight">License Agreement</h2>
          <p className="text-sm text-muted-foreground">Please read and accept the terms and conditions</p>
        </div>
      </div>

      <div
        className="mt-6 bg-card border rounded-xl p-6 h-[380px] overflow-y-auto text-[13px] text-muted-foreground leading-relaxed space-y-5 scroll-smooth"
        onScroll={onScroll}
      >
        <div className="flex items-center gap-2 pb-3 border-b mb-4">
          <Shield className="w-4 h-4 text-primary" />
          <span className="text-foreground font-bold text-sm">PerfHub Enterprise - Terms of Service & End User License Agreement</span>
        </div>
        <p className="text-[11px] text-muted-foreground">Effective Date: February 2026 | Version 3.0</p>

        <section>
          <h3 className="text-foreground font-semibold mb-2">1. Acceptance of Terms</h3>
          <p>By installing, accessing, or using PerfHub Enterprise ("the Platform"), you acknowledge that you have read, understood, and agree to be bound by these Terms of Service and End User License Agreement (collectively, "the Agreement"). If you are accepting these terms on behalf of an organization, you represent and warrant that you have the authority to bind that organization to this Agreement. If you do not agree to these terms, you must not install or use the Platform.</p>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">2. Description of Service</h3>
          <p>PerfHub is a self-hosted performance testing management platform that provides tools for orchestrating Apache JMeter load tests, streaming real-time metrics via WebSocket, analyzing test results with automated anomaly detection, managing SLA compliance, generating stakeholder sign-off reports, and integrating with CI/CD pipelines. The Platform is designed for enterprise performance engineering teams requiring comprehensive load testing infrastructure.</p>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">3. License Grant</h3>
          <p>Subject to the terms of this Agreement, PerfHub grants you a non-exclusive, non-transferable, revocable license to install and use the Platform within your organization. This license permits you to:</p>
          <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
            <li>Install and operate the Platform on your infrastructure</li>
            <li>Create user accounts for members of your organization</li>
            <li>Execute performance tests and generate reports using the Platform's features</li>
            <li>Integrate the Platform with your existing CI/CD tools and monitoring systems</li>
            <li>Access and use all bundled features including anomaly detection, SLA monitoring, and report generation</li>
          </ul>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">4. User Accounts & Access Control</h3>
          <p>The Platform implements role-based access control with five roles: Administrator, Lead, Engineer, Manager, and Viewer. You are responsible for:</p>
          <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
            <li>Maintaining the confidentiality of all user account credentials</li>
            <li>Ensuring appropriate role assignments for all users</li>
            <li>Promptly revoking access for users who leave the organization</li>
            <li>Reviewing audit logs regularly for unauthorized access attempts</li>
            <li>Notifying the administrator immediately of any security breach</li>
          </ul>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">5. Acceptable Use Policy</h3>
          <p>You agree to use the Platform only for lawful performance testing purposes. You shall not:</p>
          <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
            <li>Conduct load tests against systems without proper authorization from the system owner</li>
            <li>Upload malicious test scripts, files, or dependencies</li>
            <li>Attempt to gain unauthorized access to other user accounts or system resources</li>
            <li>Use the Platform as a tool for denial-of-service attacks or to disrupt third-party services</li>
            <li>Share API tokens, access credentials, or ingest tokens with unauthorized individuals</li>
            <li>Reverse engineer, decompile, or disassemble the Platform software</li>
            <li>Remove or modify any proprietary notices or labels on the Platform</li>
          </ul>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">6. Data & Privacy</h3>
          <p>The Platform stores test scripts, execution results, user data, audit logs, and configuration data in your self-hosted PostgreSQL database. As a self-hosted solution:</p>
          <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
            <li>All data remains entirely within your infrastructure and under your control</li>
            <li>No telemetry, usage data, or test results are transmitted externally</li>
            <li>You are responsible for implementing appropriate backup procedures</li>
            <li>You are responsible for compliance with applicable data protection regulations (GDPR, CCPA, etc.)</li>
            <li>Data retention policies are configurable through the Platform's administration panel</li>
          </ul>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">7. Intellectual Property</h3>
          <p>Test scripts, configurations, and results you create or upload remain your intellectual property. The Platform's software, design, documentation, anomaly detection algorithms, and all associated intellectual property are owned by PerfHub and are protected by applicable intellectual property laws. You may not distribute, sublicense, or create derivative works from the Platform software.</p>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">8. Service Availability & Support</h3>
          <p>As a self-hosted platform, service availability depends on your infrastructure. The Platform is provided "as-is" without warranties of any kind, either express or implied. We do not guarantee uninterrupted operation and are not responsible for downtime caused by hardware failures, network issues, or misconfiguration.</p>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">9. Resource Usage & Limitations</h3>
          <p>Test executions consume system resources including CPU, memory, disk I/O, and network bandwidth. Administrators may configure limits on concurrent test executions, data retention periods, storage quotas, and API rate limits. The Platform includes built-in safeguards for memory management during long-running tests, but resource planning is the responsibility of the deploying organization.</p>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">10. Limitation of Liability</h3>
          <p>TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL PERFHUB, ITS AFFILIATES, OR THEIR RESPECTIVE DIRECTORS, OFFICERS, EMPLOYEES, OR AGENTS BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES (INCLUDING BUT NOT LIMITED TO LOSS OF PROFITS, DATA, BUSINESS OPPORTUNITIES, OR GOODWILL) ARISING OUT OF OR IN CONNECTION WITH YOUR USE OF OR INABILITY TO USE THE PLATFORM, REGARDLESS OF THE CAUSE OF ACTION OR THE THEORY OF LIABILITY.</p>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">11. Indemnification</h3>
          <p>You agree to indemnify, defend, and hold harmless PerfHub and its affiliates from and against any claims, liabilities, damages, losses, and expenses arising out of or in any way connected with your access to or use of the Platform, your violation of this Agreement, or your infringement of any third-party rights.</p>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">12. Termination</h3>
          <p>This Agreement is effective until terminated. We may terminate this Agreement at any time if you breach any of its terms. Upon termination, you must cease all use of the Platform and destroy all copies of the software. Sections relating to intellectual property, limitation of liability, and indemnification shall survive termination.</p>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">13. Modifications to Terms</h3>
          <p>We reserve the right to modify these terms at any time. Material changes will be communicated through the Platform's notification system. Continued use of the Platform after changes constitutes acceptance of the updated terms. It is your responsibility to review these terms periodically.</p>
        </section>

        <section>
          <h3 className="text-foreground font-semibold mb-2">14. Governing Law</h3>
          <p>This Agreement shall be governed by and construed in accordance with applicable laws, without regard to conflict of law principles. Any disputes arising under this Agreement shall be subject to the exclusive jurisdiction of the competent courts.</p>
        </section>

        <section className="pb-4">
          <h3 className="text-foreground font-semibold mb-2">15. Contact</h3>
          <p>For questions about these terms, please contact your organization's PerfHub administrator or refer to the Platform's documentation.</p>
        </section>
      </div>

      {!scrolled && (
        <p className="mt-3 text-[11px] text-muted-foreground text-center flex items-center justify-center gap-1.5">
          <ArrowRight className="w-3 h-3 rotate-90" /> Scroll to the bottom to enable acceptance
        </p>
      )}

      <div className={`mt-5 flex items-start gap-3 p-4 rounded-xl border transition-all ${
        scrolled ? "bg-card border-primary/20" : "bg-muted/20 border-border/50 opacity-60"
      }`}>
        <Checkbox
          id="accept-terms"
          checked={accepted}
          onCheckedChange={(checked) => onAcceptChange(checked === true)}
          disabled={!scrolled}
          className="mt-0.5"
        />
        <label htmlFor="accept-terms" className={`text-[13px] leading-relaxed cursor-pointer select-none ${
          scrolled ? "text-foreground" : "text-muted-foreground"
        }`}>
          I have read and agree to the <strong>PerfHub Enterprise Terms of Service</strong> and{" "}
          <strong>End User License Agreement</strong>. I understand that by proceeding with the
          installation, I am accepting all terms and conditions outlined above.
        </label>
      </div>
    </div>
  );
}

function AdminStep({
  form,
  onChange,
  showPassword,
  showConfirmPassword,
  onTogglePassword,
  onToggleConfirmPassword,
  isPending,
}: {
  form: { username: string; email: string; password: string; confirmPassword: string; organization: string };
  onChange: (f: typeof form) => void;
  showPassword: boolean;
  showConfirmPassword: boolean;
  onTogglePassword: () => void;
  onToggleConfirmPassword: () => void;
  isPending: boolean;
}) {
  const passwordStrength = getPasswordStrength(form.password);

  return (
    <div>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
          <UserPlus className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight">Administrator Account</h2>
          <p className="text-sm text-muted-foreground">Create the primary admin account for your PerfHub instance</p>
        </div>
      </div>

      <div className="bg-primary/5 border border-primary/15 rounded-xl p-4 mt-4 mb-6 flex items-start gap-3">
        <Lock className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
        <p className="text-[12px] text-muted-foreground leading-relaxed">
          This account will have full administrative privileges including user management,
          system configuration, and audit log access. The first account is automatically approved
          and granted admin rights.
        </p>
      </div>

      <div className="space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="setup-username" className="text-[13px] font-semibold">
              Username <span className="text-red-500">*</span>
            </Label>
            <Input
              id="setup-username"
              placeholder="admin"
              value={form.username}
              onChange={(e) => onChange({ ...form, username: e.target.value })}
              className="h-10 text-[13px]"
              autoComplete="username"
              required
              minLength={3}
              disabled={isPending}
            />
            <p className="text-[10px] text-muted-foreground">Minimum 3 characters</p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="setup-org" className="text-[13px] font-semibold">Organization</Label>
            <Input
              id="setup-org"
              placeholder="Your Company Name"
              value={form.organization}
              onChange={(e) => onChange({ ...form, organization: e.target.value })}
              className="h-10 text-[13px]"
              disabled={isPending}
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="setup-email" className="text-[13px] font-semibold">Email Address</Label>
          <Input
            id="setup-email"
            type="email"
            placeholder="admin@company.com"
            value={form.email}
            onChange={(e) => onChange({ ...form, email: e.target.value })}
            className="h-10 text-[13px]"
            autoComplete="email"
            disabled={isPending}
          />
          <p className="text-[10px] text-muted-foreground">Used for password recovery and notifications</p>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="setup-password" className="text-[13px] font-semibold">
              Password <span className="text-red-500">*</span>
            </Label>
            <div className="relative">
              <Input
                id="setup-password"
                type={showPassword ? "text" : "password"}
                placeholder="Create a strong password"
                value={form.password}
                onChange={(e) => onChange({ ...form, password: e.target.value })}
                className="h-10 text-[13px] pr-10"
                autoComplete="new-password"
                required
                minLength={8}
                disabled={isPending}
              />
              <button
                type="button"
                onClick={onTogglePassword}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {form.password && (
              <div className="space-y-1">
                <div className="flex gap-1">
                  {[1, 2, 3, 4].map(level => (
                    <div
                      key={level}
                      className={`h-1 flex-1 rounded-full transition-colors ${
                        passwordStrength.level >= level
                          ? level <= 1 ? "bg-red-500" : level <= 2 ? "bg-orange-500" : level <= 3 ? "bg-yellow-500" : "bg-green-500"
                          : "bg-muted"
                      }`}
                    />
                  ))}
                </div>
                <p className={`text-[10px] font-medium ${
                  passwordStrength.level <= 1 ? "text-red-500" : passwordStrength.level <= 2 ? "text-orange-500" : passwordStrength.level <= 3 ? "text-yellow-600" : "text-green-500"
                }`}>{passwordStrength.label}</p>
              </div>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="setup-confirm" className="text-[13px] font-semibold">
              Confirm Password <span className="text-red-500">*</span>
            </Label>
            <div className="relative">
              <Input
                id="setup-confirm"
                type={showConfirmPassword ? "text" : "password"}
                placeholder="Confirm password"
                value={form.confirmPassword}
                onChange={(e) => onChange({ ...form, confirmPassword: e.target.value })}
                className="h-10 text-[13px] pr-10"
                autoComplete="new-password"
                required
                disabled={isPending}
              />
              <button
                type="button"
                onClick={onToggleConfirmPassword}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              >
                {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {form.confirmPassword && form.password !== form.confirmPassword && (
              <p className="text-[10px] text-red-500 font-medium">Passwords do not match</p>
            )}
            {form.confirmPassword && form.password === form.confirmPassword && form.password.length >= 8 && (
              <p className="text-[10px] text-green-500 font-medium flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Passwords match
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function ConfigurationStep({
  form,
  onChange,
}: {
  form: { instanceName: string; jmeterPath: string; dataRetentionDays: string };
  onChange: (f: typeof form) => void;
}) {
  const [detecting, setDetecting] = useState(false);
  const [detectResult, setDetectResult] = useState<{ detected: string | null; version: string | null; candidates: string[] } | null>(null);

  useEffect(() => {
    setDetecting(true);
    fetch("/api/detect-jmeter")
      .then(res => res.json())
      .then(data => {
        setDetectResult(data);
        if (data.detected && !form.jmeterPath) {
          onChange({ ...form, jmeterPath: data.detected });
        }
      })
      .catch(() => {})
      .finally(() => setDetecting(false));
  }, []);

  return (
    <div>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
          <Settings className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight">Configuration</h2>
          <p className="text-sm text-muted-foreground">Optional settings - these can be changed later in the admin panel</p>
        </div>
      </div>

      <div className="mt-6 space-y-5">
        <div className="space-y-1.5">
          <Label htmlFor="instance-name" className="text-[13px] font-semibold">Instance Name</Label>
          <Input
            id="instance-name"
            placeholder="PerfHub"
            value={form.instanceName}
            onChange={(e) => onChange({ ...form, instanceName: e.target.value })}
            className="h-10 text-[13px]"
          />
          <p className="text-[10px] text-muted-foreground">A friendly name for your PerfHub installation</p>
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="jmeter-path" className="text-[13px] font-semibold">JMeter Installation Path</Label>
            {detecting && (
              <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" /> Detecting...
              </span>
            )}
            {!detecting && detectResult?.detected && (
              <span className="text-[11px] text-green-600 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Auto-detected{detectResult.version ? ` (v${detectResult.version})` : ""}
              </span>
            )}
            {!detecting && !detectResult?.detected && (
              <span className="text-[11px] text-amber-600 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> Not found on system
              </span>
            )}
          </div>
          <Input
            id="jmeter-path"
            placeholder="/opt/apache-jmeter-5.6.3"
            value={form.jmeterPath}
            onChange={(e) => onChange({ ...form, jmeterPath: e.target.value })}
            className="h-10 text-[13px] font-mono"
          />
          {detectResult && detectResult.candidates.length > 1 && (
            <div className="text-[10px] text-muted-foreground">
              Found {detectResult.candidates.length} installations:{" "}
              {detectResult.candidates.map((c, i) => (
                <button
                  key={c}
                  type="button"
                  className="text-primary hover:underline"
                  onClick={() => onChange({ ...form, jmeterPath: c })}
                >
                  {c}{i < detectResult.candidates.length - 1 ? ", " : ""}
                </button>
              ))}
            </div>
          )}
          <p className="text-[10px] text-muted-foreground">
            {form.jmeterPath ? "JMeter home directory (containing bin/jmeter)" : "Auto-detected from system PATH, JMETER_HOME, and common install locations"}
          </p>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="retention" className="text-[13px] font-semibold">Data Retention Period</Label>
          <div className="flex items-center gap-2">
            <Input
              id="retention"
              type="number"
              min="7"
              max="365"
              value={form.dataRetentionDays}
              onChange={(e) => onChange({ ...form, dataRetentionDays: e.target.value })}
              className="h-10 text-[13px] w-28"
            />
            <span className="text-sm text-muted-foreground">days</span>
          </div>
          <p className="text-[10px] text-muted-foreground">How long test results and execution data are retained (can be configured per-category later)</p>
        </div>

        <div className="bg-muted/30 rounded-xl p-4 border">
          <h4 className="text-[13px] font-semibold mb-2 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-primary" /> Default Configuration
          </h4>
          <div className="grid sm:grid-cols-2 gap-y-2 gap-x-6 text-[12px]">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Database</span>
              <span className="font-medium text-green-600 dark:text-green-400">PostgreSQL (Connected)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">WebSocket</span>
              <span className="font-medium text-green-600 dark:text-green-400">Enabled</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Session Store</span>
              <span className="font-medium">PostgreSQL</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Password Hashing</span>
              <span className="font-medium">bcrypt (12 rounds)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Rate Limiting</span>
              <span className="font-medium text-green-600 dark:text-green-400">Enabled</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Audit Logging</span>
              <span className="font-medium text-green-600 dark:text-green-400">Enabled</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CompleteStep({
  username,
  onFinish,
  isPending,
}: {
  username: string;
  onFinish: () => void;
  isPending: boolean;
}) {
  return (
    <div className="text-center">
      <div className="w-20 h-20 bg-green-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-green-500/15">
        <CheckCircle className="w-10 h-10 text-green-500" />
      </div>
      <h2 className="text-3xl font-extrabold tracking-tight mb-3">Installation Complete</h2>
      <p className="text-base text-muted-foreground mb-8 max-w-lg mx-auto leading-relaxed">
        PerfHub has been successfully configured and is ready to use.
        Your admin account <strong className="text-foreground">{username}</strong> has been created.
      </p>

      <div className="bg-card border rounded-xl p-5 max-w-md mx-auto mb-8 text-left space-y-3">
        <h4 className="text-sm font-bold flex items-center gap-2">
          <Rocket className="w-4 h-4 text-primary" /> Quick Start Guide
        </h4>
        <div className="space-y-2.5 text-[12px]">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-[10px] font-bold text-primary">1</span>
            </div>
            <p className="text-muted-foreground"><strong className="text-foreground">Upload JMX Scripts</strong> - Import your JMeter test plans from the Scripts page</p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-[10px] font-bold text-primary">2</span>
            </div>
            <p className="text-muted-foreground"><strong className="text-foreground">Create a Schedule</strong> - Set up test configurations with VUsers, ramp-up, and duration</p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-[10px] font-bold text-primary">3</span>
            </div>
            <p className="text-muted-foreground"><strong className="text-foreground">Run & Monitor</strong> - Execute tests and view real-time metrics on the live dashboard</p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-[10px] font-bold text-primary">4</span>
            </div>
            <p className="text-muted-foreground"><strong className="text-foreground">Invite Team</strong> - Add engineers and managers from the Platform Users page</p>
          </div>
        </div>
      </div>

      <Button
        size="lg"
        onClick={onFinish}
        disabled={isPending}
        className="h-12 px-8 text-[14px] font-semibold shadow-lg shadow-primary/25 gap-2"
      >
        {isPending ? (
          <><Loader2 className="w-4 h-4 animate-spin" /> Launching PerfHub...</>
        ) : (
          <>Launch PerfHub <ArrowRight className="w-4 h-4" /></>
        )}
      </Button>
    </div>
  );
}

function getPasswordStrength(password: string): { level: number; label: string } {
  if (!password) return { level: 0, label: "" };
  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
  if (/\d/.test(password)) score++;
  if (/[^a-zA-Z0-9]/.test(password)) score++;

  if (score <= 1) return { level: 1, label: "Weak" };
  if (score <= 2) return { level: 2, label: "Fair" };
  if (score <= 3) return { level: 3, label: "Good" };
  return { level: 4, label: "Strong" };
}
