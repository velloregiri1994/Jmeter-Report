import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Bell,
  Check,
  CheckCheck,
  AlertTriangle,
  Info,
  X,
  ExternalLink,
  Trash2,
  XCircle,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  Settings2,
  Mail,
  Moon,
  Shield,
  TrendingDown,
  Activity,
  FileCheck,
  Save,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { formatDistanceToNow, format } from "date-fns";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { QueryErrorFallback } from "@/components/error-boundary";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { queryKeys } from "@/lib/query-keys";

type NotificationType = "info" | "warning" | "error" | "sla_violation" | "success";

const typeConfig: Record<NotificationType, { icon: typeof Bell; color: string; bgColor: string; label: string }> = {
  sla_violation: { icon: AlertTriangle, color: "text-amber-500", bgColor: "bg-amber-500/10", label: "SLA Violation" },
  error: { icon: XCircle, color: "text-red-500", bgColor: "bg-red-500/10", label: "Error" },
  warning: { icon: AlertTriangle, color: "text-orange-500", bgColor: "bg-orange-500/10", label: "Warning" },
  success: { icon: CheckCircle2, color: "text-emerald-500", bgColor: "bg-emerald-500/10", label: "Success" },
  info: { icon: Info, color: "text-blue-500", bgColor: "bg-blue-500/10", label: "Info" },
};

function getTypeConfig(type: string) {
  return typeConfig[type as NotificationType] || typeConfig.info;
}

type NotificationPrefs = {
  testCompleted: boolean;
  testFailed: boolean;
  slaViolation: boolean;
  regressionDetected: boolean;
  approvalRequested: boolean;
  systemAlerts: boolean;
  emailEnabled: boolean;
  emailDigestFrequency: string;
  emailDigestTime: string;
  emailDigestDay: string;
  quietHoursEnabled: boolean;
  quietHoursStart: string;
  quietHoursEnd: string;
};

export default function NotificationsPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [view, setView] = useState<"notifications" | "preferences">("notifications");
  const [tab, setTab] = useState<"all" | "unread" | "read">("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const PAGE_SIZE = 50;

  const readParam = tab === "unread" ? "false" : tab === "read" ? "true" : undefined;
  const typeParam = typeFilter !== "all" ? typeFilter : undefined;

  const { data: paginatedResult, isLoading: notificationsLoading, isError: notificationsError, error: notificationsErrorData, refetch: refetchNotifications } = useQuery({
    queryKey: [...queryKeys.notifications.all, "paginated", currentPage, tab, typeFilter],
    queryFn: async () => {
      const qp = new URLSearchParams();
      qp.set("page", String(currentPage));
      qp.set("pageSize", String(PAGE_SIZE));
      if (readParam) qp.set("read", readParam);
      if (typeParam) qp.set("type", typeParam);
      const res = await apiRequest("GET", `/api/notifications?${qp.toString()}`);
      return res.json();
    },
  });

  const notifications = paginatedResult?.data || [];
  const totalNotifications = paginatedResult?.total || 0;
  const totalPages = Math.ceil(totalNotifications / PAGE_SIZE);

  useEffect(() => { setCurrentPage(1); }, [tab, typeFilter]);

  const { data: unreadData } = useQuery({
    queryKey: [...queryKeys.notifications.unreadCount],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/notifications/unread-count");
      return res.json();
    },
  });

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.notifications.all });
    queryClient.invalidateQueries({ queryKey: queryKeys.notifications.unreadCount });
  };

  const markReadMutation = useMutation({
    mutationFn: async (id: number) => { await apiRequest("POST", `/api/notifications/${id}/read`); },
    onSuccess: invalidateAll,
  });

  const markAllReadMutation = useMutation({
    mutationFn: async () => { await apiRequest("POST", "/api/notifications/mark-all-read"); },
    onSuccess: invalidateAll,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => { await apiRequest("DELETE", `/api/notifications/${id}`); },
    onSuccess: invalidateAll,
  });

  const clearAllMutation = useMutation({
    mutationFn: async () => { await apiRequest("DELETE", "/api/notifications"); },
    onSuccess: invalidateAll,
  });

  const unreadCount = unreadData?.count || 0;

  const filteredNotifications = notifications.filter((n: any) => {
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return n.title?.toLowerCase().includes(q) || n.message?.toLowerCase().includes(q);
    }
    return true;
  });

  const typeCounts = notifications.reduce((acc: Record<string, number>, n: any) => {
    acc[n.type] = (acc[n.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Bell className="h-6 w-6" />
            Notifications
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {notifications.length} total, {unreadCount} unread
          </p>
        </div>
        <div className="flex gap-2">
          <Tabs value={view} onValueChange={(v) => setView(v as any)}>
            <TabsList className="h-9">
              <TabsTrigger value="notifications" className="text-xs gap-1.5">
                <Bell className="h-3.5 w-3.5" />
                Inbox
                {unreadCount > 0 && (
                  <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4 ml-1">{unreadCount}</Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="preferences" className="text-xs gap-1.5">
                <Settings2 className="h-3.5 w-3.5" />
                Preferences
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {view === "notifications" && notificationsError && (
        <QueryErrorFallback error={notificationsErrorData as Error} onRetry={refetchNotifications} title="Failed to load notifications" />
      )}

      {view === "notifications" && !notificationsError && (
        <>
          <div className="flex gap-2 justify-end">
            {unreadCount > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => markAllReadMutation.mutate()}
                disabled={markAllReadMutation.isPending}
              >
                <CheckCheck className="h-4 w-4 mr-1.5" />
                Mark all read
              </Button>
            )}
            {notifications.length > 0 && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:bg-destructive/10"
                    disabled={clearAllMutation.isPending}
                  >
                    <Trash2 className="h-4 w-4 mr-1.5" />
                    Clear all
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to clear all notifications?
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => clearAllMutation.mutate()}>
                      Clear All
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {(["sla_violation", "error", "warning", "info"] as NotificationType[]).map((type) => {
              const config = typeConfig[type];
              const Icon = config.icon;
              const count = typeCounts[type] || 0;
              return (
                <Card
                  key={type}
                  className={cn(
                    "cursor-pointer transition-all hover:shadow-md",
                    typeFilter === type && "ring-2 ring-primary"
                  )}
                  onClick={() => setTypeFilter(typeFilter === type ? "all" : type)}
                >
                  <CardContent className="p-4 flex items-center gap-3">
                    <div className={cn("h-9 w-9 rounded-full flex items-center justify-center flex-shrink-0", config.bgColor)}>
                      <Icon className={cn("h-4 w-4", config.color)} />
                    </div>
                    <div>
                      <p className="text-lg font-bold leading-none">{count}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{config.label}</p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                <Tabs value={tab} onValueChange={(v) => setTab(v as any)} className="flex-shrink-0">
                  <TabsList className="h-9">
                    <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
                    <TabsTrigger value="unread" className="text-xs">
                      Unread
                      {unreadCount > 0 && (
                        <Badge variant="secondary" className="ml-1.5 text-[10px] px-1 py-0 h-4">{unreadCount}</Badge>
                      )}
                    </TabsTrigger>
                    <TabsTrigger value="read" className="text-xs">Read</TabsTrigger>
                  </TabsList>
                </Tabs>
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                  <Input
                    placeholder="Search notifications..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-8 h-9 text-sm"
                  />
                </div>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-[140px] h-9 text-xs">
                    <Filter className="h-3 w-3 mr-1.5" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="sla_violation">SLA Violation</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="success">Success</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {notificationsLoading ? (
                <div className="divide-y">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="px-6 py-4 flex gap-4">
                      <Skeleton className="h-10 w-10 rounded-full flex-shrink-0" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-4 w-48" />
                        <Skeleton className="h-3 w-full max-w-md" />
                        <div className="flex items-center gap-3">
                          <Skeleton className="h-3 w-32" />
                          <Skeleton className="h-4 w-16 rounded-full" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredNotifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 px-8 text-center">
                  <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
                    {tab === "unread" ? (
                      <CheckCheck className="h-8 w-8 text-muted-foreground/40" />
                    ) : searchQuery ? (
                      <Search className="h-8 w-8 text-muted-foreground/40" />
                    ) : (
                      <Bell className="h-8 w-8 text-muted-foreground/40" />
                    )}
                  </div>
                  <p className="text-base font-medium text-muted-foreground">
                    {tab === "unread" ? "All caught up!" : searchQuery ? "No matching notifications" : "No notifications yet"}
                  </p>
                  <p className="text-sm text-muted-foreground/70 mt-1 max-w-xs">
                    {tab === "unread"
                      ? "You have no unread notifications. Great job staying on top of things!"
                      : searchQuery
                      ? "Try adjusting your search or filters"
                      : "Notifications about test executions, SLA violations, and team activity will appear here"}
                  </p>
                </div>
              ) : (
                <div className="divide-y">
                  {filteredNotifications.map((notif: any) => {
                    const config = getTypeConfig(notif.type);
                    const Icon = config.icon;
                    return (
                      <div
                        key={notif.id}
                        className={cn(
                          "group relative px-6 py-4 transition-all duration-150 hover:bg-muted/40",
                          !notif.read && "bg-primary/[0.03]"
                        )}
                      >
                        {!notif.read && (
                          <div className="absolute left-2 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-primary" />
                        )}
                        <div className="flex gap-4">
                          <div className={cn("mt-0.5 flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center", config.bgColor)}>
                            <Icon className={cn("h-5 w-5", config.color)} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-start gap-3">
                              <div className="flex-1 min-w-0">
                                <p className={cn(
                                  "text-sm",
                                  !notif.read ? "font-semibold text-foreground" : "font-medium text-muted-foreground"
                                )}>
                                  {notif.title}
                                </p>
                                <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                                  {notif.message}
                                </p>
                              </div>
                              <div className="flex items-center gap-1 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                                {!notif.read && (
                                  <TooltipProvider delayDuration={200}>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-7 w-7 hover:bg-primary/10 hover:text-primary"
                                          onClick={() => markReadMutation.mutate(notif.id)}
                                        >
                                          <Check className="h-3.5 w-3.5" />
                                        </Button>
                                      </TooltipTrigger>
                                      <TooltipContent><p>Mark as read</p></TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>
                                )}
                                <AlertDialog>
                                  <TooltipProvider delayDuration={200}>
                                    <Tooltip>
                                      <AlertDialogTrigger asChild>
                                        <TooltipTrigger asChild>
                                          <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-7 w-7 hover:bg-destructive/10 hover:text-destructive"
                                          >
                                            <Trash2 className="h-3.5 w-3.5" />
                                          </Button>
                                        </TooltipTrigger>
                                      </AlertDialogTrigger>
                                      <TooltipContent><p>Delete notification</p></TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will permanently delete this notification.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction onClick={() => deleteMutation.mutate(notif.id)}>
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            </div>
                            <div className="flex items-center gap-3 mt-2">
                              <div className="flex items-center gap-1 text-xs text-muted-foreground/70">
                                <Clock className="h-3 w-3" />
                                {format(new Date(notif.createdAt), "MMM d, yyyy 'at' h:mm a")}
                              </div>
                              <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-[18px] border-muted-foreground/20">
                                {config.label}
                              </Badge>
                              {notif.link && (
                                <Link href={notif.link}>
                                  <span className="inline-flex items-center gap-1 text-xs text-primary font-semibold hover:underline cursor-pointer">
                                    View details <ExternalLink className="h-3 w-3" />
                                  </span>
                                </Link>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              {totalPages > 1 && (
                <div className="flex items-center justify-between px-6 py-4 border-t border-border/50">
                  <p className="text-sm text-muted-foreground">
                    Showing {((currentPage - 1) * PAGE_SIZE) + 1}-{Math.min(currentPage * PAGE_SIZE, totalNotifications)} of {totalNotifications}
                  </p>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      Previous
                    </Button>
                    <span className="text-sm text-muted-foreground">
                      Page {currentPage} of {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}

      {view === "preferences" && <NotificationPreferencesPanel />}
    </div>
  );
}

function NotificationPreferencesPanel() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: prefs, isLoading } = useQuery<NotificationPrefs>({
    queryKey: [...queryKeys.notifications.preferences],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/notification-preferences");
      return res.json();
    },
  });

  const [localPrefs, setLocalPrefs] = useState<NotificationPrefs | null>(null);
  const currentPrefs = localPrefs || prefs;

  const updateLocal = (key: keyof NotificationPrefs, value: any) => {
    setLocalPrefs(prev => ({
      ...(prev || prefs || getDefaults()),
      [key]: value,
    }));
  };

  const saveMutation = useMutation({
    mutationFn: async (data: NotificationPrefs) => {
      const res = await apiRequest("PUT", "/api/notification-preferences", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.notifications.preferences });
      setLocalPrefs(null);
      toast({ title: "Preferences saved", description: "Your notification preferences have been updated." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to save preferences. Please try again.", variant: "destructive" });
    },
  });

  const hasChanges = localPrefs !== null;

  if (isLoading || !currentPrefs) {
    return (
      <div className="space-y-6">
        {[...Array(2)].map((_, i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-5 w-40" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[...Array(3)].map((_, j) => (
                  <div key={j} className="flex items-center justify-between p-3">
                    <div className="flex items-center gap-3">
                      <Skeleton className="h-9 w-9 rounded-full" />
                      <div className="space-y-1">
                        <Skeleton className="h-4 w-28" />
                        <Skeleton className="h-3 w-48" />
                      </div>
                    </div>
                    <Skeleton className="h-5 w-10 rounded-full" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const categories = [
    {
      key: "testCompleted" as const,
      label: "Test Completed",
      description: "Get notified when a test execution completes successfully",
      icon: CheckCircle2,
      color: "text-emerald-500",
      bgColor: "bg-emerald-500/10",
    },
    {
      key: "testFailed" as const,
      label: "Test Failed",
      description: "Get notified when a test execution fails or encounters errors",
      icon: XCircle,
      color: "text-red-500",
      bgColor: "bg-red-500/10",
    },
    {
      key: "slaViolation" as const,
      label: "SLA Violations",
      description: "Get notified when SLA thresholds are breached during or after tests",
      icon: AlertTriangle,
      color: "text-amber-500",
      bgColor: "bg-amber-500/10",
    },
    {
      key: "regressionDetected" as const,
      label: "Performance Regressions",
      description: "Get notified when baseline comparison detects a regression",
      icon: TrendingDown,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
    },
    {
      key: "approvalRequested" as const,
      label: "Approval Requests",
      description: "Get notified when you are assigned as a reviewer on a report",
      icon: FileCheck,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
    },
    {
      key: "systemAlerts" as const,
      label: "System Alerts",
      description: "Get notified about system-level events and announcements",
      icon: Activity,
      color: "text-violet-500",
      bgColor: "bg-violet-500/10",
    },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Bell className="h-5 w-5" />
            Notification Categories
          </CardTitle>
          <CardDescription>
            Choose which types of notifications you want to receive in your inbox.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-1">
            {categories.map((cat) => {
              const Icon = cat.icon;
              return (
                <div
                  key={cat.key}
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/40 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={cn("h-9 w-9 rounded-full flex items-center justify-center flex-shrink-0", cat.bgColor)}>
                      <Icon className={cn("h-4.5 w-4.5", cat.color)} />
                    </div>
                    <div>
                      <Label className="text-sm font-medium cursor-pointer">{cat.label}</Label>
                      <p className="text-xs text-muted-foreground mt-0.5">{cat.description}</p>
                    </div>
                  </div>
                  <Switch
                    checked={currentPrefs[cat.key]}
                    onCheckedChange={(checked) => updateLocal(cat.key, checked)}
                  />
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Mail className="h-5 w-5" />
            Email Digest
          </CardTitle>
          <CardDescription>
            Configure email notifications for test results and alerts. Requires email settings to be configured by an admin.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-full bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                <Mail className="h-4.5 w-4.5 text-blue-500" />
              </div>
              <div>
                <Label className="text-sm font-medium">Enable Email Notifications</Label>
                <p className="text-xs text-muted-foreground mt-0.5">Receive notification summaries via email</p>
              </div>
            </div>
            <Switch
              checked={currentPrefs.emailEnabled}
              onCheckedChange={(checked) => updateLocal("emailEnabled", checked)}
            />
          </div>

          {currentPrefs.emailEnabled && (
            <div className="space-y-4 pl-3 border-l-2 border-blue-500/20 ml-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Delivery Frequency</Label>
                <Select
                  value={currentPrefs.emailDigestFrequency}
                  onValueChange={(val) => updateLocal("emailDigestFrequency", val)}
                >
                  <SelectTrigger className="w-full sm:w-[280px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="instant">Instant (every notification)</SelectItem>
                    <SelectItem value="hourly">Hourly digest</SelectItem>
                    <SelectItem value="daily">Daily digest</SelectItem>
                    <SelectItem value="weekly">Weekly digest</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {currentPrefs.emailDigestFrequency === "instant"
                    ? "You will receive an email for each notification as it happens."
                    : currentPrefs.emailDigestFrequency === "hourly"
                    ? "Notifications will be bundled and sent every hour."
                    : currentPrefs.emailDigestFrequency === "daily"
                    ? "You will receive a daily summary of all notifications."
                    : "You will receive a weekly summary of all notifications."}
                </p>
              </div>

              {(currentPrefs.emailDigestFrequency === "daily" || currentPrefs.emailDigestFrequency === "weekly") && (
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Delivery Time</Label>
                  <Select
                    value={currentPrefs.emailDigestTime}
                    onValueChange={(val) => updateLocal("emailDigestTime", val)}
                  >
                    <SelectTrigger className="w-full sm:w-[280px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {["06:00", "07:00", "08:00", "09:00", "10:00", "11:00", "12:00",
                        "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"].map(time => (
                        <SelectItem key={time} value={time}>
                          {time.replace(/^0/, '')} {parseInt(time) < 12 ? 'AM' : parseInt(time) === 12 ? 'PM' : 'PM'}
                          {parseInt(time) > 12 ? ` (${parseInt(time) - 12}:00 PM)` : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {currentPrefs.emailDigestFrequency === "weekly" && (
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Delivery Day</Label>
                  <Select
                    value={currentPrefs.emailDigestDay}
                    onValueChange={(val) => updateLocal("emailDigestDay", val)}
                  >
                    <SelectTrigger className="w-full sm:w-[280px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"].map(day => (
                        <SelectItem key={day} value={day}>
                          {day.charAt(0).toUpperCase() + day.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Moon className="h-5 w-5" />
            Quiet Hours
          </CardTitle>
          <CardDescription>
            Suppress non-critical notifications during off-hours. Critical alerts (test failures, SLA breaches) will still come through.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-full bg-indigo-500/10 flex items-center justify-center flex-shrink-0">
                <Moon className="h-4.5 w-4.5 text-indigo-500" />
              </div>
              <div>
                <Label className="text-sm font-medium">Enable Quiet Hours</Label>
                <p className="text-xs text-muted-foreground mt-0.5">Mute non-critical notifications during specified hours</p>
              </div>
            </div>
            <Switch
              checked={currentPrefs.quietHoursEnabled}
              onCheckedChange={(checked) => updateLocal("quietHoursEnabled", checked)}
            />
          </div>

          {currentPrefs.quietHoursEnabled && (
            <div className="flex items-center gap-3 pl-3 border-l-2 border-indigo-500/20 ml-4">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">From</Label>
                <Select
                  value={currentPrefs.quietHoursStart}
                  onValueChange={(val) => updateLocal("quietHoursStart", val)}
                >
                  <SelectTrigger className="w-[120px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 24 }, (_, i) => {
                      const h = i.toString().padStart(2, '0');
                      return <SelectItem key={h} value={`${h}:00`}>{`${h}:00`}</SelectItem>;
                    })}
                  </SelectContent>
                </Select>
              </div>
              <span className="text-muted-foreground mt-5">to</span>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Until</Label>
                <Select
                  value={currentPrefs.quietHoursEnd}
                  onValueChange={(val) => updateLocal("quietHoursEnd", val)}
                >
                  <SelectTrigger className="w-[120px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 24 }, (_, i) => {
                      const h = i.toString().padStart(2, '0');
                      return <SelectItem key={h} value={`${h}:00`}>{`${h}:00`}</SelectItem>;
                    })}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {hasChanges && (
        <div className="sticky bottom-4 flex justify-end">
          <div className="flex items-center gap-3 bg-card border rounded-xl px-5 py-3 shadow-lg">
            <span className="text-sm text-muted-foreground">You have unsaved changes</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setLocalPrefs(null)}
            >
              Discard
            </Button>
            <Button
              size="sm"
              className="gap-1.5"
              onClick={() => currentPrefs && saveMutation.mutate(currentPrefs)}
              disabled={saveMutation.isPending}
            >
              <Save className="h-3.5 w-3.5" />
              {saveMutation.isPending ? "Saving..." : "Save Preferences"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function getDefaults(): NotificationPrefs {
  return {
    testCompleted: true,
    testFailed: true,
    slaViolation: true,
    regressionDetected: true,
    approvalRequested: true,
    systemAlerts: true,
    emailEnabled: false,
    emailDigestFrequency: 'instant',
    emailDigestTime: '09:00',
    emailDigestDay: 'monday',
    quietHoursEnabled: false,
    quietHoursStart: '22:00',
    quietHoursEnd: '07:00',
  };
}
