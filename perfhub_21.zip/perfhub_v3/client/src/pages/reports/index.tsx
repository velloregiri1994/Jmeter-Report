import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { FileText, Download, ExternalLink, MessageSquare, Save, CheckCircle, BarChart2, Clock, Trash2, Eye, EyeOff, Maximize2, Minimize2, Plus, Mail, Calendar, Edit2, Power, Globe, Send, Filter, X } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useExecutions } from "@/hooks/use-executions";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { PageHeader } from "@/components/page-header";
import { Skeleton } from "@/components/ui/skeleton";
import { queryKeys } from "@/lib/query-keys";
import { QueryErrorFallback } from "@/components/error-boundary";

const DAYS_OF_WEEK = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const COMMON_TIMEZONES = [
  "UTC", "America/New_York", "America/Chicago", "America/Denver", "America/Los_Angeles",
  "Europe/London", "Europe/Paris", "Europe/Berlin", "Asia/Tokyo", "Asia/Shanghai",
  "Asia/Kolkata", "Asia/Singapore", "Australia/Sydney", "Pacific/Auckland",
];

export default function ReportsPage() {
  const { toast } = useToast();
  const { data: executionsResponse, isLoading, isError, error, refetch } = useExecutions({ limit: 100 });
  const executions = executionsResponse?.data || [];
  const [activeTab, setActiveTab] = useState<"reports" | "deliveries">("reports");
  const [editingComments, setEditingComments] = useState<Record<number, string>>({});
  const [previewId, setPreviewId] = useState<number | null>(null);
  const [previewExpanded, setPreviewExpanded] = useState(false);
  const [showDeliveryDialog, setShowDeliveryDialog] = useState(false);
  const [editingDelivery, setEditingDelivery] = useState<any>(null);
  const [timeFilter, setTimeFilter] = useState<string>("all");

  const { data: deliverySchedules = [], isLoading: deliveriesLoading } = useQuery({
    queryKey: [...queryKeys.reportDelivery],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/report-delivery-schedules");
      return res.json();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/executions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (q) => String(q.queryKey[0]).includes("/api/executions") });
      toast({ title: "Artifact deleted" });
    },
    onError: (err: Error) => {
      toast({ title: "Delete failed", description: err.message, variant: "destructive" });
    },
  });

  const commentMutation = useMutation({
    mutationFn: async ({ id, comments }: { id: number; comments: string }) => {
      const res = await apiRequest("POST", `/api/executions/${id}/report-comments`, { comments });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.executions.all });
      toast({ title: "Success", description: "Report comments saved" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteDeliveryMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/report-delivery-schedules/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.reportDelivery });
      toast({ title: "Delivery schedule deleted" });
    },
  });

  const toggleDeliveryMutation = useMutation({
    mutationFn: async ({ id, enabled }: { id: number; enabled: boolean }) => {
      const res = await apiRequest("PATCH", `/api/report-delivery-schedules/${id}`, { enabled });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.reportDelivery });
    },
  });

  const completedExecutions = executions.filter(e => {
    if (e.status !== "completed") return false;
    if (timeFilter === "all") return true;
    const endTime = e.endTime ? new Date(e.endTime).getTime() : 0;
    const now = Date.now();
    const day = 24 * 60 * 60 * 1000;
    if (timeFilter === "today") return endTime >= now - day;
    if (timeFilter === "7d") return endTime >= now - 7 * day;
    if (timeFilter === "30d") return endTime >= now - 30 * day;
    if (timeFilter === "90d") return endTime >= now - 90 * day;
    return true;
  });

  if (isError) {
    return <QueryErrorFallback error={error as Error} onRetry={refetch} title="Failed to load reports" />;
  }

  return (
    <div className="section-gap">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
      <PageHeader
        title="HTML Reports"
        subtitle="View reports, preview results inline, and schedule automated report delivery."
        actions={
          <Button
            size="sm"
            onClick={() => { setEditingDelivery(null); setShowDeliveryDialog(true); }}
            className="gap-2"
          >
            <Mail className="w-4 h-4" />
            Schedule Delivery
          </Button>
        }
      />

      <div className="flex items-center gap-1 p-1 bg-muted/50 rounded-lg w-fit mb-4">
        <button
          onClick={() => setActiveTab("reports")}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === "reports" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
        >
          <FileText className="w-4 h-4 inline mr-2" />
          Reports ({completedExecutions.length})
        </button>
        <button
          onClick={() => setActiveTab("deliveries")}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === "deliveries" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
        >
          <Mail className="w-4 h-4 inline mr-2" />
          Scheduled Deliveries ({deliverySchedules.length})
        </button>
      </div>

      {activeTab === "reports" && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <Filter className="w-3.5 h-3.5" />
              <span className="font-medium">Time:</span>
            </div>
            {[
              { value: "all", label: "All Time" },
              { value: "today", label: "Today" },
              { value: "7d", label: "Last 7 Days" },
              { value: "30d", label: "Last 30 Days" },
              { value: "90d", label: "Last 90 Days" },
            ].map(opt => (
              <button
                key={opt.value}
                onClick={() => setTimeFilter(opt.value)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  timeFilter === opt.value
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                {opt.label}
              </button>
            ))}
            {timeFilter !== "all" && (
              <button
                onClick={() => setTimeFilter("all")}
                className="p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                title="Clear filter"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="grid gap-4">
          {isLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Card key={i}>
                <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 space-y-0 pb-3 p-4 sm:p-6 border-b">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Skeleton className="h-5 w-5 rounded" />
                      <Skeleton className="h-5 w-48" />
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Skeleton className="h-3.5 w-3.5 rounded" />
                      <Skeleton className="h-4 w-36" />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Skeleton className="h-6 w-16 rounded-md" />
                    <Skeleton className="h-6 w-20 rounded-full" />
                  </div>
                </CardHeader>
                <CardContent className="p-4 sm:p-6 space-y-3">
                  <Skeleton className="h-20 w-full rounded-md" />
                  <div className="flex gap-2">
                    <Skeleton className="h-8 w-24 rounded-md" />
                    <Skeleton className="h-8 w-28 rounded-md" />
                    <Skeleton className="h-8 w-24 rounded-md" />
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            completedExecutions.map((execution, index) => {
              const resultSummary = (execution as any).resultSummary;
              return (
              <Card key={execution.id} className="overflow-hidden hover:shadow-md transition-all duration-200" style={{ animation: `fadeSlideIn 0.3s ease-out ${index * 0.05}s both` }}>
                <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 space-y-0 pb-3 p-4 sm:p-6 bg-gradient-to-r from-emerald-500/5 via-transparent to-transparent border-b">
                  <div className="space-y-1">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <BarChart2 className="w-5 h-5 text-emerald-500" />
                      {execution.schedule?.name || (execution as any).testName || execution.executionId}
                    </CardTitle>
                    <CardDescription className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      {execution.endTime ? format(new Date(execution.endTime), "PPP p") : "Unknown"}
                      {(execution as any).executionId && (
                        <span className="text-xs text-muted-foreground/70 ml-1">({(execution as any).executionId})</span>
                      )}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    {resultSummary && (
                      <div className="flex items-center gap-3 text-xs">
                        <span className="px-2 py-1 rounded-md bg-blue-500/10 text-blue-600 font-medium">{(resultSummary.totalRequests || 0).toLocaleString()} req</span>
                        <span className={`px-2 py-1 rounded-md font-medium ${(resultSummary.errorRate || 0) * 100 > 5 ? 'bg-rose-500/10 text-rose-600' : 'bg-emerald-500/10 text-emerald-600'}`}>{((resultSummary.errorRate || 0) * 100).toFixed(1)}% err</span>
                      </div>
                    )}
                    <Badge variant="outline" className="capitalize">
                      {execution.schedule?.script?.toolType || (!(execution as any).scheduleId ? "remote" : "unknown")}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4 p-4 sm:p-6">
                  {(execution as any).comments && (execution as any).comments.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                        <MessageSquare className="h-4 w-4" />
                        Test Comments ({(execution as any).comments.length})
                      </div>
                      <div className="space-y-2 max-h-[200px] overflow-y-auto pr-2">
                        {(execution as any).comments.map((comment: any) => (
                          <div key={comment.id} className="flex gap-2 p-2 rounded-lg bg-muted/30 border text-sm">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback className="text-xs bg-primary/10 text-primary">
                                {comment.user?.username?.substring(0, 2).toUpperCase() || 'U'}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-medium text-xs">{comment.user?.username || 'User'}</span>
                                <span className="text-xs text-muted-foreground">
                                  {comment.createdAt ? format(new Date(comment.createdAt), "PP p") : ''}
                                </span>
                                {comment.type === 'sign-off' && (
                                  <span className="text-xs bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 px-1.5 py-0.5 rounded">
                                    <CheckCircle className="w-3 h-3 inline mr-0.5" />
                                    Sign-off
                                  </span>
                                )}
                              </div>
                              <p className="text-xs mt-0.5 text-muted-foreground">{comment.content}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                      <MessageSquare className="h-4 w-4" />
                      Custom Comments
                    </div>
                    <div className="flex gap-2">
                      <Textarea
                        placeholder="Add custom notes or observations for this test..."
                        className="min-h-[80px] resize-none"
                        value={editingComments[execution.id] ?? (execution as any).reportComments ?? ""}
                        onChange={(e) => setEditingComments({ ...editingComments, [execution.id]: e.target.value })}
                      />
                      <Button 
                        size="icon" 
                        className="shrink-0"
                        disabled={commentMutation.isPending}
                        onClick={() => commentMutation.mutate({ 
                          id: execution.id, 
                          comments: editingComments[execution.id] ?? (execution as any).reportComments ?? "" 
                        })}
                      >
                        <Save className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {previewId === execution.id && execution.reportHtmlPath && (
                    <div className="rounded-lg border overflow-hidden bg-white">
                      <div className="flex items-center justify-between px-3 py-2 bg-gradient-to-r from-indigo-500/10 via-purple-500/5 to-transparent border-b">
                        <div className="flex items-center gap-2">
                          <Eye className="w-3.5 h-3.5 text-indigo-500" />
                          <span className="text-xs font-medium">Report Preview</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="sm" className="h-6 px-1.5" onClick={() => setPreviewExpanded(!previewExpanded)}>
                            {previewExpanded ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
                          </Button>
                          <Button variant="ghost" size="sm" className="h-6 px-1.5" onClick={() => window.open(execution.reportHtmlPath!, '_blank')}>
                            <ExternalLink className="w-3 h-3" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-6 px-1.5" onClick={() => { setPreviewId(null); setPreviewExpanded(false); }}>
                            <EyeOff className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      <iframe
                        src={execution.reportHtmlPath}
                        className="w-full border-0"
                        style={{ height: previewExpanded ? '70vh' : '400px' }}
                        sandbox="allow-same-origin allow-scripts"
                        title="Report Preview"
                      />
                    </div>
                  )}

                  <div className="flex flex-wrap gap-2">
                    {execution.reportHtmlPath ? (
                      <>
                        <Button
                          variant={previewId === execution.id ? "default" : "outline"}
                          size="sm"
                          onClick={() => { setPreviewId(previewId === execution.id ? null : execution.id); setPreviewExpanded(false); }}
                        >
                          {previewId === execution.id ? <EyeOff className="mr-2 h-4 w-4" /> : <Eye className="mr-2 h-4 w-4" />}
                          {previewId === execution.id ? "Hide Preview" : "Preview"}
                        </Button>
                        <Button variant="outline" size="sm" asChild>
                          <a href={execution.reportHtmlPath} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="mr-2 h-4 w-4" />
                            Open Report
                          </a>
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={async () => {
                            try {
                              const response = await fetch(execution.reportHtmlPath!);
                              const blob = await response.blob();
                              const url = window.URL.createObjectURL(blob);
                              const link = document.createElement('a');
                              link.href = url;
                              link.download = `report-${(execution as any).executionId || execution.id}.html`;
                              document.body.appendChild(link);
                              link.click();
                              document.body.removeChild(link);
                              window.URL.revokeObjectURL(url);
                            } catch (error) {
                              console.error('Download failed:', error);
                            }
                          }}
                        >
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      </>
                    ) : (
                      <Button variant="outline" size="sm" onClick={async () => {
                        await apiRequest("POST", `/api/executions/${execution.id}/generate-report`);
                        queryClient.invalidateQueries({ queryKey: queryKeys.executions.all });
                        setPreviewId(execution.id);
                      }}>
                        <FileText className="mr-2 h-4 w-4" />
                        Generate Report
                      </Button>
                    )}
                    <Button variant="outline" size="sm" asChild className="text-primary border-primary/30 hover:bg-primary/5">
                      <a href={`/executions/${execution.id}`}>
                        <FileText className="mr-2 h-4 w-4" />
                        View Details
                      </a>
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive">
                          <Trash2 className="w-4 h-4 mr-2" /> Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Artifact</AlertDialogTitle>
                          <AlertDialogDescription>
                            This will permanently delete this test execution and its report. This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteMutation.mutate(execution.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </CardContent>
              </Card>
              );
            })
          )}

          {!isLoading && completedExecutions.length === 0 && (
            <div className="flex flex-col items-center justify-center p-16 border border-dashed rounded-xl bg-muted/20" style={{ animation: 'fadeSlideIn 0.4s ease-out both' }}>
              <div className="mb-4 rounded-full p-4" style={{ background: 'linear-gradient(135deg, hsl(var(--primary) / 0.12), hsl(var(--primary) / 0.04))' }}>
                <FileText className="h-12 w-12 text-primary/60" />
              </div>
              <h3 className="text-lg font-semibold">{timeFilter !== "all" ? "No reports in this time range" : "No reports yet"}</h3>
              <p className="text-muted-foreground text-sm mt-1 text-center max-w-md">
                {timeFilter !== "all"
                  ? "Try selecting a different time range or clear the filter to see all reports."
                  : "Reports are generated automatically when test executions complete. Schedule and run a test to see reports here."}
              </p>
              {timeFilter !== "all" && (
                <Button variant="outline" size="sm" className="mt-3" onClick={() => setTimeFilter("all")}>
                  Clear Filter
                </Button>
              )}
            </div>
          )}
          </div>
        </div>
      )}

      {activeTab === "deliveries" && (
        <div className="space-y-4">
          {deliveriesLoading ? (
            Array.from({ length: 2 }).map((_, i) => (
              <Card key={i}>
                <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 space-y-0 pb-3 p-4 sm:p-6 border-b">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Skeleton className="h-5 w-5 rounded" />
                      <Skeleton className="h-5 w-40" />
                      <Skeleton className="h-5 w-14 rounded-full" />
                    </div>
                    <Skeleton className="h-4 w-56" />
                  </div>
                  <Skeleton className="h-5 w-10 rounded-full" />
                </CardHeader>
                <CardContent className="p-4 sm:p-6">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-2"><Skeleton className="h-3 w-16" /><Skeleton className="h-5 w-32" /></div>
                    <div className="space-y-2"><Skeleton className="h-3 w-16" /><Skeleton className="h-5 w-24" /></div>
                    <div className="space-y-2"><Skeleton className="h-3 w-16" /><Skeleton className="h-5 w-20" /></div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : deliverySchedules.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-16 border border-dashed rounded-xl bg-muted/20" style={{ animation: 'fadeSlideIn 0.4s ease-out both' }}>
              <div className="mb-4 rounded-full p-4" style={{ background: 'linear-gradient(135deg, hsl(var(--primary) / 0.12), hsl(var(--primary) / 0.04))' }}>
                <Mail className="h-12 w-12 text-primary/60" />
              </div>
              <h3 className="text-lg font-semibold">No scheduled deliveries</h3>
              <p className="text-muted-foreground text-sm mt-1 text-center max-w-md">
                Set up automated report delivery to receive performance test digests via email on a daily, weekly, or monthly basis.
              </p>
              <Button className="mt-4" onClick={() => { setEditingDelivery(null); setShowDeliveryDialog(true); }}>
                <Plus className="w-4 h-4 mr-2" /> Create Delivery Schedule
              </Button>
            </div>
          ) : (
            deliverySchedules.map((ds: any, index: number) => (
              <Card key={ds.id} className="overflow-hidden hover:shadow-md transition-all duration-200" style={{ animation: `fadeSlideIn 0.3s ease-out ${index * 0.05}s both` }}>
                <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 space-y-0 pb-3 p-4 sm:p-6 bg-gradient-to-r from-indigo-500/5 via-purple-500/3 to-transparent border-b">
                  <div className="space-y-1">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Mail className="w-5 h-5 text-indigo-500" />
                      {ds.name}
                      <Badge variant={ds.enabled ? "default" : "secondary"} className="text-xs">
                        {ds.enabled ? "Active" : "Paused"}
                      </Badge>
                    </CardTitle>
                    <CardDescription className="flex items-center gap-3 flex-wrap">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {ds.frequency === "daily" ? "Daily" : ds.frequency === "weekly" ? `Weekly (${DAYS_OF_WEEK[ds.dayOfWeek || 0]})` : `Monthly (Day ${ds.dayOfMonth || 1})`} at {ds.timeOfDay}
                      </span>
                      <span className="flex items-center gap-1">
                        <Globe className="w-3.5 h-3.5" />
                        {ds.timezone}
                      </span>
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={ds.enabled}
                      onCheckedChange={(checked) => toggleDeliveryMutation.mutate({ id: ds.id, enabled: checked })}
                    />
                  </div>
                </CardHeader>
                <CardContent className="p-4 sm:p-6">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Recipients</span>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {(ds.recipients || []).map((r: string, i: number) => (
                          <Badge key={i} variant="outline" className="text-xs">{r}</Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <span className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Last Sent</span>
                      <p className="mt-1">{ds.lastSentAt ? format(new Date(ds.lastSentAt), "PP p") : "Never"}</p>
                    </div>
                    <div>
                      <span className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Next Delivery</span>
                      <p className="mt-1">{ds.nextRunAt ? format(new Date(ds.nextRunAt), "PP p") : "Not scheduled"}</p>
                    </div>
                  </div>
                  {ds.filters && Object.keys(ds.filters).some((k: string) => (ds.filters as any)[k]) && (
                    <div className="mt-3 pt-3 border-t">
                      <span className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Filters</span>
                      <div className="mt-1 flex gap-2 flex-wrap">
                        {ds.filters.environment && <Badge variant="outline" className="text-xs">Env: {ds.filters.environment}</Badge>}
                        {ds.filters.status && <Badge variant="outline" className="text-xs">Status: {ds.filters.status}</Badge>}
                      </div>
                    </div>
                  )}
                  <div className="mt-3 pt-3 border-t flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => { setEditingDelivery(ds); setShowDeliveryDialog(true); }}>
                      <Edit2 className="w-3.5 h-3.5 mr-1.5" /> Edit
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive">
                          <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Delivery Schedule</AlertDialogTitle>
                          <AlertDialogDescription>
                            This will permanently remove this automated delivery schedule. You will no longer receive digest emails from this schedule.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteDeliveryMutation.mutate(ds.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      <DeliveryScheduleDialog
        open={showDeliveryDialog}
        onOpenChange={setShowDeliveryDialog}
        editingSchedule={editingDelivery}
      />
    </div>
  );
}

function DeliveryScheduleDialog({ open, onOpenChange, editingSchedule }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingSchedule: any | null;
}) {
  const { toast } = useToast();
  const isEditing = !!editingSchedule;

  const [name, setName] = useState("");
  const [recipientsInput, setRecipientsInput] = useState("");
  const [frequency, setFrequency] = useState("weekly");
  const [dayOfWeek, setDayOfWeek] = useState(1);
  const [dayOfMonth, setDayOfMonth] = useState(1);
  const [timeOfDay, setTimeOfDay] = useState("09:00");
  const [timezone, setTimezone] = useState("UTC");
  const [environment, setEnvironment] = useState("");
  const [includeAttachments, setIncludeAttachments] = useState(false);
  const [enabled, setEnabled] = useState(true);

  const resetForm = () => {
    if (editingSchedule) {
      setName(editingSchedule.name || "");
      setRecipientsInput((editingSchedule.recipients || []).join(", "));
      setFrequency(editingSchedule.frequency || "weekly");
      setDayOfWeek(editingSchedule.dayOfWeek ?? 1);
      setDayOfMonth(editingSchedule.dayOfMonth ?? 1);
      setTimeOfDay(editingSchedule.timeOfDay || "09:00");
      setTimezone(editingSchedule.timezone || "UTC");
      setEnvironment(editingSchedule.filters?.environment || "");
      setIncludeAttachments(editingSchedule.includeAttachments || false);
      setEnabled(editingSchedule.enabled !== false);
    } else {
      setName("");
      setRecipientsInput("");
      setFrequency("weekly");
      setDayOfWeek(1);
      setDayOfMonth(1);
      setTimeOfDay("09:00");
      setTimezone(Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC");
      setEnvironment("");
      setIncludeAttachments(false);
      setEnabled(true);
    }
  };

  const saveMutation = useMutation({
    mutationFn: async () => {
      const recipients = recipientsInput.split(/[,;\n]+/).map(e => e.trim()).filter(Boolean);
      if (!name.trim()) throw new Error("Name is required");
      if (recipients.length === 0) throw new Error("At least one recipient email is required");

      const body: any = {
        name: name.trim(),
        recipients,
        frequency,
        dayOfWeek: frequency === "weekly" ? dayOfWeek : null,
        dayOfMonth: frequency === "monthly" ? dayOfMonth : null,
        timeOfDay,
        timezone,
        filters: environment ? { environment } : null,
        includeAttachments,
        enabled,
      };

      const url = isEditing ? `/api/report-delivery-schedules/${editingSchedule.id}` : "/api/report-delivery-schedules";
      const method = isEditing ? "PATCH" : "POST";

      const res = await apiRequest(method, url, body);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.reportDelivery });
      toast({ title: isEditing ? "Schedule updated" : "Delivery schedule created" });
      onOpenChange(false);
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  return (
    <Dialog open={open} onOpenChange={(o) => { if (o) resetForm(); onOpenChange(o); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-indigo-500" />
            {isEditing ? "Edit Delivery Schedule" : "Create Delivery Schedule"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Modify the automated report delivery settings."
              : "Set up automated delivery of test report digests via email."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label>Schedule Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g., Weekly Performance Digest" />
          </div>

          <div className="space-y-2">
            <Label>Recipients (comma-separated emails)</Label>
            <Textarea
              value={recipientsInput}
              onChange={(e) => setRecipientsInput(e.target.value)}
              placeholder="team@company.com, manager@company.com"
              className="min-h-[60px] resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Frequency</Label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value)}
                className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
              </select>
            </div>
            {frequency === "weekly" && (
              <div className="space-y-2">
                <Label>Day of Week</Label>
                <select
                  value={dayOfWeek}
                  onChange={(e) => setDayOfWeek(Number(e.target.value))}
                  className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
                >
                  {DAYS_OF_WEEK.map((day, i) => (
                    <option key={i} value={i}>{day}</option>
                  ))}
                </select>
              </div>
            )}
            {frequency === "monthly" && (
              <div className="space-y-2">
                <Label>Day of Month</Label>
                <select
                  value={dayOfMonth}
                  onChange={(e) => setDayOfMonth(Number(e.target.value))}
                  className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
                >
                  {Array.from({ length: 28 }, (_, i) => (
                    <option key={i + 1} value={i + 1}>{i + 1}</option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Delivery Time</Label>
              <Input type="time" value={timeOfDay} onChange={(e) => setTimeOfDay(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Timezone</Label>
              <select
                value={timezone}
                onChange={(e) => setTimezone(e.target.value)}
                className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
              >
                {COMMON_TIMEZONES.map(tz => (
                  <option key={tz} value={tz}>{tz.replace(/_/g, " ")}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Filter by Environment (optional)</Label>
            <Input value={environment} onChange={(e) => setEnvironment(e.target.value)} placeholder="e.g., Production, Staging" />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div>
              <Label>Include Report Attachments</Label>
              <p className="text-xs text-muted-foreground mt-0.5">Attach HTML reports for up to 5 most recent tests</p>
            </div>
            <Switch checked={includeAttachments} onCheckedChange={setIncludeAttachments} />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Enabled</Label>
              <p className="text-xs text-muted-foreground mt-0.5">Start delivering reports immediately</p>
            </div>
            <Switch checked={enabled} onCheckedChange={setEnabled} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending}
            className="gap-2"
          >
            {saveMutation.isPending ? "Saving..." : (
              <>
                <Send className="w-4 h-4" />
                {isEditing ? "Update Schedule" : "Create Schedule"}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
