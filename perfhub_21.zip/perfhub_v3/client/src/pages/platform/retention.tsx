import { PageHeader } from "@/components/page-header";
import AdminRetention from "../admin/retention";

export default function PlatformRetentionPage() {
  return (
    <div className="section-gap">
      <PageHeader
        title="Data Retention"
        subtitle="Configure cleanup policies and storage management"
      />
      <AdminRetention />
    </div>
  );
}
