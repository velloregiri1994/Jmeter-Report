import { PageHeader } from "@/components/page-header";
import AdminUsersPage from "../admin/users";

export default function PlatformUsersPage() {
  return (
    <div className="section-gap">
      <PageHeader
        title="User Management"
        subtitle="Manage user accounts, roles, and access permissions"
      />
      <AdminUsersPage />
    </div>
  );
}
