import { PageHeader } from "@/components/page-header";
import IngestTokensPage from "../admin/ingest-tokens";

export default function PlatformDistributedPage() {
  return (
    <div className="section-gap">
      <PageHeader
        title="Distributed Testing"
        subtitle="Manage ingest tokens and remote agent connections"
      />
      <IngestTokensPage />
    </div>
  );
}
