import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { PageHeader } from "@/components/page-header";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { EmptyState } from "@/components/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Plus, Trash2, Loader2, Edit, Send, ChevronDown, ChevronRight, CheckCircle, XCircle, Clock, Globe, MessageSquare, Bell } from "lucide-react";

interface WebhookData {
  id: number;
  name: string;
  url: string;
  secret: string | null;
  type: "slack" | "teams" | "pagerduty" | "generic";
  events: string[];
  enabled: boolean;
  headers: Record<string, string> | null;
  createdBy: number | null;
  lastDeliveryAt: string | null;
  lastDeliveryStatus: string | null;
  createdAt: string;
  updatedAt: string;
}

interface DeliveryData {
  id: number;
  webhookId: number;
  event: string;
  payload: unknown;
  responseStatus: number | null;
  responseBody: string | null;
  error: string | null;
  attempts: number;
  deliveredAt: string;
}

type WebhookType = "slack" | "teams" | "pagerduty" | "generic";

const TYPE_CONFIG: Record<WebhookType, { label: string; color: string; icon: React.ReactNode }> = {
  slack: { label: "Slack", color: "bg-purple-100 text-purple-700 dark:bg-purple-500/15 dark:text-purple-400 border-purple-200 dark:border-purple-500/20", icon: <MessageSquare className="h-3 w-3" /> },
  teams: { label: "Microsoft Teams", color: "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-400 border-blue-200 dark:border-blue-500/20", icon: <MessageSquare className="h-3 w-3" /> },
  pagerduty: { label: "PagerDuty", color: "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-400 border-green-200 dark:border-green-500/20", icon: <Bell className="h-3 w-3" /> },
  generic: { label: "Generic", color: "bg-gray-100 text-gray-700 dark:bg-gray-500/15 dark:text-gray-400 border-gray-200 dark:border-gray-500/20", icon: <Globe className="h-3 w-3" /> },
};

interface WebhookFormState {
  name: string;
  url: string;
  type: WebhookType;
  events: string[];
  enabled: boolean;
  secret: string;
}

const defaultForm: WebhookFormState = {
  name: "",
  url: "",
  type: "slack",
  events: [],
  enabled: true,
  secret: "",
};

function WebhookForm({
  form,
  setForm,
  availableEvents,
  onSubmit,
  onCancel,
  isPending,
  submitLabel,
}: {
  form: WebhookFormState;
  setForm: React.Dispatch<React.SetStateAction<WebhookFormState>>;
  availableEvents: string[];
  onSubmit: () => void;
  onCancel: () => void;
  isPending: boolean;
  submitLabel: string;
}) {
  return (
    <div className="space-y-4 p-5 rounded-xl border border-blue-200 dark:border-blue-500/20 bg-blue-50/50 dark:bg-blue-500/5">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Name *</Label>
          <Input
            placeholder="e.g. Slack Alerts"
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
          />
        </div>
        <div className="space-y-2">
          <Label>URL *</Label>
          <Input
            placeholder="https://hooks.slack.com/services/..."
            value={form.url}
            onChange={(e) => setForm((f) => ({ ...f, url: e.target.value }))}
          />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Type</Label>
          <Select value={form.type} onValueChange={(v) => setForm((f) => ({ ...f, type: v as WebhookType }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="slack">Slack</SelectItem>
              <SelectItem value="teams">Microsoft Teams</SelectItem>
              <SelectItem value="pagerduty">PagerDuty</SelectItem>
              <SelectItem value="generic">Generic</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {form.type === "generic" && (
          <div className="space-y-2">
            <Label>Secret (optional)</Label>
            <Input
              placeholder="Signing secret for HMAC verification"
              value={form.secret}
              onChange={(e) => setForm((f) => ({ ...f, secret: e.target.value }))}
            />
          </div>
        )}
      </div>
      <div className="space-y-2">
        <Label>Events</Label>
        <div className="flex flex-wrap gap-3">
          {availableEvents.map((event) => (
            <div key={event} className="flex items-center gap-2">
              <Checkbox
                id={`event-${event}`}
                checked={form.events.includes(event)}
                onCheckedChange={(checked) => {
                  setForm((f) => ({
                    ...f,
                    events: checked
                      ? [...f.events, event]
                      : f.events.filter((e) => e !== event),
                  }));
                }}
              />
              <label htmlFor={`event-${event}`} className="text-sm text-muted-foreground cursor-pointer">
                {event}
              </label>
            </div>
          ))}
        </div>
      </div>
      <div className="flex items-center gap-3">
        <Switch
          checked={form.enabled}
          onCheckedChange={(checked) => setForm((f) => ({ ...f, enabled: checked }))}
        />
        <Label>Enabled</Label>
      </div>
      <div className="flex gap-2 pt-1">
        <Button
          onClick={onSubmit}
          disabled={!form.name.trim() || !form.url.trim() || isPending}
        >
          {isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
          {submitLabel}
        </Button>
        <Button variant="ghost" onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}

function DeliveryHistory({ webhookId }: { webhookId: number }) {
  const { data: deliveries = [], isLoading } = useQuery<DeliveryData[]>({
    queryKey: [...queryKeys.webhooks.deliveries(webhookId)],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/webhooks/${webhookId}/deliveries`);
      return res.json();
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-2 p-4">
        {[...Array(3)].map((_, i) => (
          <Skeleton key={i} className="h-10 w-full" />
        ))}
      </div>
    );
  }

  if (deliveries.length === 0) {
    return (
      <div className="text-center py-6 text-sm text-muted-foreground">
        No deliveries yet
      </div>
    );
  }

  return (
    <div className="divide-y border-t">
      {deliveries.slice(0, 10).map((d) => (
        <div key={d.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
          <div className="flex items-center gap-3">
            {d.responseStatus && d.responseStatus >= 200 && d.responseStatus < 300 ? (
              <CheckCircle className="h-4 w-4 text-green-500" />
            ) : (
              <XCircle className="h-4 w-4 text-red-500" />
            )}
            <span className="text-muted-foreground">{new Date(d.deliveredAt).toLocaleString()}</span>
            <Badge variant="outline" className="text-xs">{d.event}</Badge>
            {d.responseStatus && (
              <span className={`text-xs font-mono ${d.responseStatus >= 200 && d.responseStatus < 300 ? "text-green-600" : "text-red-600"}`}>
                {d.responseStatus}
              </span>
            )}
          </div>
          {d.error && (
            <span className="text-xs text-red-500 truncate max-w-[200px]" title={d.error}>
              {d.error}
            </span>
          )}
        </div>
      ))}
    </div>
  );
}

function WebhookCard({
  webhook,
  availableEvents,
}: {
  webhook: WebhookData;
  availableEvents: string[];
}) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [expanded, setExpanded] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState<WebhookFormState>({
    name: webhook.name,
    url: webhook.url,
    type: webhook.type,
    events: webhook.events || [],
    enabled: webhook.enabled,
    secret: webhook.secret || "",
  });

  const updateMutation = useMutation({
    mutationFn: async () => {
      const body: Record<string, unknown> = {
        name: editForm.name,
        url: editForm.url,
        type: editForm.type,
        events: editForm.events,
        enabled: editForm.enabled,
      };
      if (editForm.type === "generic" && editForm.secret) {
        body.secret = editForm.secret;
      }
      const res = await apiRequest("PATCH", `/api/webhooks/${webhook.id}`, body);
      return res.json();
    },
    onSuccess: () => {
      setEditing(false);
      queryClient.invalidateQueries({ queryKey: queryKeys.webhooks.all });
      toast({ title: "Webhook Updated" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/webhooks/${webhook.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.webhooks.all });
      toast({ title: "Webhook Deleted" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const testMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/webhooks/${webhook.id}/test`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.webhooks.deliveries(webhook.id) });
      toast({ title: "Test Sent", description: "Test webhook delivery was sent successfully." });
    },
    onError: (err: any) => {
      toast({ title: "Test Failed", description: err.message, variant: "destructive" });
    },
  });

  const typeConfig = TYPE_CONFIG[webhook.type] || TYPE_CONFIG.generic;

  if (editing) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Edit Webhook</CardTitle>
        </CardHeader>
        <CardContent>
          <WebhookForm
            form={editForm}
            setForm={setEditForm}
            availableEvents={availableEvents}
            onSubmit={() => updateMutation.mutate()}
            onCancel={() => {
              setEditing(false);
              setEditForm({
                name: webhook.name,
                url: webhook.url,
                type: webhook.type,
                events: webhook.events || [],
                enabled: webhook.enabled,
                secret: webhook.secret || "",
              });
            }}
            isPending={updateMutation.isPending}
            submitLabel="Save Changes"
          />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="group">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0 space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-foreground">{webhook.name}</span>
              <Badge className={`text-xs border ${typeConfig.color}`}>
                <span className="flex items-center gap-1">{typeConfig.icon} {typeConfig.label}</span>
              </Badge>
              {webhook.enabled ? (
                <Badge className="bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20 text-[10px] px-1.5 py-0 h-5">ENABLED</Badge>
              ) : (
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-5">DISABLED</Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground truncate max-w-md" title={webhook.url}>
              {webhook.url}
            </p>
            <div className="flex flex-wrap gap-1.5">
              {(webhook.events || []).map((event) => (
                <Badge key={event} variant="outline" className="text-[10px] px-1.5 py-0 h-5 font-mono">
                  {event}
                </Badge>
              ))}
            </div>
            {webhook.lastDeliveryAt && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                <span>Last delivery: {new Date(webhook.lastDeliveryAt).toLocaleString()}</span>
                {webhook.lastDeliveryStatus === "success" ? (
                  <span className="flex items-center gap-1 text-green-600"><CheckCircle className="h-3 w-3" /> Success</span>
                ) : webhook.lastDeliveryStatus === "failed" ? (
                  <span className="flex items-center gap-1 text-red-600"><XCircle className="h-3 w-3" /> Failed</span>
                ) : null}
              </div>
            )}
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setEditing(true)}
              className="text-muted-foreground hover:text-foreground"
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => testMutation.mutate()}
              disabled={testMutation.isPending}
              className="text-muted-foreground hover:text-foreground"
            >
              {testMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Webhook</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete "{webhook.name}"? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => deleteMutation.mutate()}>Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
        <div className="mt-3 border-t pt-2">
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            {expanded ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
            Delivery History
          </button>
          {expanded && <DeliveryHistory webhookId={webhook.id} />}
        </div>
      </CardContent>
    </Card>
  );
}

export default function WebhooksPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [createForm, setCreateForm] = useState<WebhookFormState>({ ...defaultForm });

  const { data: webhooks = [], isLoading, isError, error, refetch } = useQuery<WebhookData[]>({
    queryKey: [...queryKeys.webhooks.all],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/webhooks");
      return res.json();
    },
  });

  const { data: availableEvents = [] } = useQuery<string[]>({
    queryKey: [...queryKeys.webhooks.events],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/webhook-events");
      return res.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const body: Record<string, unknown> = {
        name: createForm.name,
        url: createForm.url,
        type: createForm.type,
        events: createForm.events,
        enabled: createForm.enabled,
      };
      if (createForm.type === "generic" && createForm.secret) {
        body.secret = createForm.secret;
      }
      const res = await apiRequest("POST", "/api/webhooks", body);
      return res.json();
    },
    onSuccess: () => {
      setCreateForm({ ...defaultForm });
      setShowCreate(false);
      queryClient.invalidateQueries({ queryKey: queryKeys.webhooks.all });
      toast({ title: "Webhook Created", description: "New webhook has been configured successfully." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  if (isError) return (
    <div className="space-y-6">
      <PageHeader title="Webhooks" subtitle="Send notifications to Slack, Teams, PagerDuty, or custom endpoints" />
      <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load webhooks" />
    </div>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="Webhooks"
        subtitle="Send notifications to Slack, Teams, PagerDuty, or custom endpoints"
        actions={
          <Button onClick={() => setShowCreate(!showCreate)}>
            <Plus className="h-4 w-4 mr-2" /> Add Webhook
          </Button>
        }
      />

      {showCreate && (
        <WebhookForm
          form={createForm}
          setForm={setCreateForm}
          availableEvents={availableEvents}
          onSubmit={() => createMutation.mutate()}
          onCancel={() => {
            setShowCreate(false);
            setCreateForm({ ...defaultForm });
          }}
          isPending={createMutation.isPending}
          submitLabel="Create Webhook"
        />
      )}

      {isLoading ? (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-5">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Skeleton className="h-5 w-40" />
                    <Skeleton className="h-5 w-20 rounded-full" />
                    <Skeleton className="h-5 w-16 rounded-full" />
                  </div>
                  <Skeleton className="h-4 w-64" />
                  <div className="flex gap-2">
                    <Skeleton className="h-4 w-24 rounded-full" />
                    <Skeleton className="h-4 w-20 rounded-full" />
                    <Skeleton className="h-4 w-28 rounded-full" />
                  </div>
                  <Skeleton className="h-3 w-48" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : webhooks.length === 0 && !showCreate ? (
        <EmptyState
          icon={Bell}
          title="No webhooks configured"
          description="Create a webhook to send automated notifications when test executions complete, SLAs are breached, or anomalies are detected."
          actionLabel="Add Your First Webhook"
          actionIcon={Plus}
          onAction={() => setShowCreate(true)}
        />
      ) : (
        <div className="space-y-4">
          {webhooks.map((webhook) => (
            <WebhookCard
              key={webhook.id}
              webhook={webhook}
              availableEvents={availableEvents}
            />
          ))}
        </div>
      )}
    </div>
  );
}
