import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/page-header";
import { EmailSettingsCard, EmailLogsCard } from "../admin/settings";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, CheckCircle2, AlertTriangle, Search, Save, Terminal } from "lucide-react";

function JMeterConfigCard() {
  const { toast } = useToast();
  const [jmeterHome, setJmeterHome] = useState("");
  const [detecting, setDetecting] = useState(false);
  const [detectResult, setDetectResult] = useState<{
    detected: string | null;
    version: string | null;
    candidates: string[];
    configured: string | null;
    platform: string;
  } | null>(null);

  const { data: config, isLoading } = useQuery({
    queryKey: ["jmeter-config"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/config/jmeter");
      return res.json();
    },
  });

  useEffect(() => {
    if (config?.jmeterHome) {
      setJmeterHome(config.jmeterHome);
    }
  }, [config]);

  const detectJmeter = async () => {
    setDetecting(true);
    try {
      const res = await fetch("/api/detect-jmeter");
      const data = await res.json();
      setDetectResult(data);
      if (data.detected && !jmeterHome) {
        setJmeterHome(data.detected);
      }
    } catch {
      toast({ title: "Detection failed", description: "Could not scan for JMeter installations", variant: "destructive" });
    } finally {
      setDetecting(false);
    }
  };

  useEffect(() => {
    detectJmeter();
  }, []);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/config/jmeter", { jmeterHome: jmeterHome.trim() });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      return data;
    },
    onSuccess: () => {
      toast({ title: "Saved", description: "JMeter configuration updated" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  return (
    <Card className="transition-all duration-200 hover:shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 shadow">
            <Terminal className="h-4 w-4 text-white" />
          </div>
          JMeter Configuration
        </CardTitle>
        <CardDescription>
          Configure the path to your Apache JMeter installation for test execution
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">JMeter Home Directory</Label>
            {detectResult?.detected && (
              <Badge variant="outline" className="text-[10px] gap-1 text-green-600 border-green-200 bg-green-50">
                <CheckCircle2 className="w-3 h-3" />
                {detectResult.version ? `v${detectResult.version} detected` : "Detected"}
              </Badge>
            )}
            {detectResult && !detectResult.detected && (
              <Badge variant="outline" className="text-[10px] gap-1 text-amber-600 border-amber-200 bg-amber-50">
                <AlertTriangle className="w-3 h-3" />
                Not found on system
              </Badge>
            )}
          </div>
          <div className="flex gap-2">
            <Input
              value={jmeterHome}
              onChange={(e) => setJmeterHome(e.target.value)}
              placeholder="/opt/apache-jmeter-5.6.3"
              className="font-mono text-sm"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={detectJmeter}
              disabled={detecting}
              title="Auto-detect JMeter"
            >
              {detecting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            The directory containing bin/jmeter (e.g., /opt/apache-jmeter-5.6.3)
          </p>
        </div>

        {detectResult && detectResult.candidates.length > 0 && (
          <div className="bg-muted/30 rounded-lg p-3 border">
            <p className="text-xs font-medium mb-2">Found installations:</p>
            <div className="space-y-1">
              {detectResult.candidates.map((candidate) => (
                <button
                  key={candidate}
                  type="button"
                  className="block w-full text-left text-xs font-mono px-2 py-1.5 rounded hover:bg-primary/10 hover:text-primary transition-colors"
                  onClick={() => setJmeterHome(candidate)}
                >
                  {candidate}
                  {candidate === jmeterHome && (
                    <CheckCircle2 className="w-3 h-3 inline ml-2 text-green-500" />
                  )}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="flex gap-2 pt-2 border-t">
          <Button
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending || isLoading}
          >
            {saveMutation.isPending ? (
              <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Saving...</>
            ) : (
              <><Save className="w-4 h-4 mr-2" /> Save Configuration</>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function PlatformGeneralPage() {
  return (
    <div className="section-gap">
      <PageHeader
        title="General Settings"
        subtitle="JMeter, email, and platform configuration"
      />
      <div className="space-y-6">
        <JMeterConfigCard />
        <EmailSettingsCard />
        <EmailLogsCard />
      </div>
    </div>
  );
}
