import { useState, useRef, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { PageHeader } from "@/components/page-header";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { EmptyState } from "@/components/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { copyToClipboard } from "@/lib/clipboard";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Key, Plus, Copy, Trash2, Loader2, Code, BookOpen, Shield, Clock, CheckCircle, XCircle, Terminal, Check, AlertTriangle, ShieldCheck } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface CiToken {
  id: number;
  name: string;
  description: string | null;
  tokenPrefix: string;
  scopes: string[];
  createdBy: number | null;
  lastUsedAt: string | null;
  expiresAt: string | null;
  revokedAt: string | null;
  createdAt: string;
}

function getTokenStatus(token: CiToken): { label: string; variant: "active" | "revoked" | "expired" } {
  if (token.revokedAt) return { label: "Revoked", variant: "revoked" };
  if (token.expiresAt && new Date(token.expiresAt) < new Date()) return { label: "Expired", variant: "expired" };
  return { label: "Active", variant: "active" };
}

function timeAgo(dateStr: string | null): string {
  if (!dateStr) return "Never";
  const ms = Date.now() - new Date(dateStr).getTime();
  if (ms < 60000) return "Just now";
  if (ms < 3600000) return `${Math.floor(ms / 60000)}m ago`;
  if (ms < 86400000) return `${Math.floor(ms / 3600000)}h ago`;
  return `${Math.floor(ms / 86400000)}d ago`;
}

function CodeBlock({ children, title }: { children: string; title?: string }) {
  const { toast } = useToast();
  return (
    <div className="relative group">
      {title && (
        <div className="flex items-center gap-2 px-4 py-2 bg-slate-800 border-b border-slate-700 rounded-t-lg">
          <Terminal className="h-3.5 w-3.5 text-slate-400" />
          <span className="text-xs font-medium text-slate-300">{title}</span>
        </div>
      )}
      <pre className={`bg-slate-900 text-slate-200 p-4 text-sm font-mono overflow-x-auto ${title ? "rounded-b-lg" : "rounded-lg"}`}>
        <code>{children}</code>
      </pre>
      <Button
        variant="ghost"
        size="sm"
        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-slate-400 hover:text-white hover:bg-slate-700"
        onClick={async () => {
          const ok = await copyToClipboard(children);
          if (ok) {
            toast({ title: "Copied to clipboard" });
          } else {
            toast({ title: "Select the text and copy manually", variant: "destructive" });
          }
        }}
      >
        <Copy className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}

const AVAILABLE_SCOPES = [
  { id: "trigger", label: "Trigger Tests", description: "Start test executions via API" },
  { id: "status", label: "Check Status", description: "Query execution status and results" },
  { id: "results", label: "Read Results", description: "Access detailed test metrics and reports" },
];

const EXPIRATION_OPTIONS = [
  { value: "never", label: "Never" },
  { value: "30", label: "30 days" },
  { value: "90", label: "90 days" },
  { value: "365", label: "1 year" },
];

export default function CicdPage() {
  const { canWrite } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [selectedScopes, setSelectedScopes] = useState<string[]>([]);
  const [expiration, setExpiration] = useState("never");
  const [revealedToken, setRevealedToken] = useState<string | null>(null);
  const [tokenCopied, setTokenCopied] = useState(false);
  const tokenInputRef = useRef<HTMLInputElement>(null);

  const handleCopyToken = useCallback(async () => {
    if (!revealedToken) return;
    const ok = await copyToClipboard(revealedToken);
    if (ok) {
      setTokenCopied(true);
      toast({ title: "Copied to clipboard" });
      setTimeout(() => setTokenCopied(false), 3000);
    } else {
      tokenInputRef.current?.select();
      toast({ title: "Please press Ctrl+C / Cmd+C to copy the selected text" });
    }
  }, [revealedToken, toast]);

  const { data: tokens = [], isLoading, isError, error, refetch } = useQuery<CiToken[]>({
    queryKey: [...queryKeys.cicd.tokens],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/ci/tokens");
      return res.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const body: Record<string, unknown> = {
        name: newName,
        description: newDescription || undefined,
        scopes: selectedScopes,
      };
      if (expiration !== "never") {
        const days = parseInt(expiration);
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + days);
        body.expiresAt = expiresAt.toISOString();
      }
      const res = await apiRequest("POST", "/api/ci/tokens", body);
      return res.json();
    },
    onSuccess: (data) => {
      setRevealedToken(data.token);
      setNewName("");
      setNewDescription("");
      setSelectedScopes([]);
      setExpiration("never");
      setShowCreate(false);
      queryClient.invalidateQueries({ queryKey: queryKeys.cicd.tokens });
      toast({ title: "Token Created", description: "Copy the token now — it won't be shown again." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const revokeMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/ci/tokens/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.cicd.tokens });
      toast({ title: "Token Revoked" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/ci/tokens/${id}?force=true`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.cicd.tokens });
      toast({ title: "Token Deleted" });
    },
  });

  const toggleScope = (scope: string) => {
    setSelectedScopes((prev) =>
      prev.includes(scope) ? prev.filter((s) => s !== scope) : [...prev, scope]
    );
  };

  const statusBadgeClasses: Record<string, string> = {
    active: "bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20",
    revoked: "bg-red-50 dark:bg-red-500/15 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-500/20",
    expired: "bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-500/20",
  };

  if (isError) return (
    <div className="section-gap">
      <PageHeader title="CI/CD Integration" subtitle="Manage API tokens and integrate performance testing into your CI/CD pipelines" />
      <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load CI/CD tokens" />
    </div>
  );

  return (
    <div className="section-gap">
      <PageHeader
        title="CI/CD Integration"
        subtitle="Manage API tokens and integrate performance testing into your CI/CD pipelines"
      />

      <Dialog open={!!revealedToken} onOpenChange={(open) => { if (!open) { setRevealedToken(null); setTokenCopied(false); } }}>
        <DialogContent className="sm:max-w-lg" onInteractOutside={(e) => e.preventDefault()}>
          <DialogHeader>
            <div className="mx-auto mb-2 p-3 rounded-full bg-amber-100 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 w-fit">
              <Key className="h-6 w-6 text-amber-600 dark:text-amber-400" />
            </div>
            <DialogTitle className="text-center">API Token Created Successfully</DialogTitle>
            <DialogDescription className="text-center">
              Copy this token now. For security reasons, it will not be shown again.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="flex items-center gap-2">
              <Input
                ref={tokenInputRef}
                readOnly
                value={revealedToken || ""}
                className="font-mono text-sm bg-slate-900 text-emerald-400 border-slate-700 h-12"
                onFocus={(e) => e.target.select()}
                onClick={(e) => (e.target as HTMLInputElement).select()}
              />
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 h-12 w-12"
                onClick={handleCopyToken}
              >
                {tokenCopied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
            <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50 dark:bg-amber-500/5 border border-amber-200 dark:border-amber-500/20">
              <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
              <p className="text-xs text-amber-700 dark:text-amber-300/80">
                Store this token in a secure location. You will need it to authenticate CI/CD pipeline requests. If lost, revoke and create a new one.
              </p>
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => { tokenInputRef.current?.select(); }}>
              Select All
            </Button>
            <Button onClick={handleCopyToken}>
              {tokenCopied ? <><Check className="h-4 w-4 mr-2" /> Copied</> : <><Copy className="h-4 w-4 mr-2" /> Copy Token</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Tabs defaultValue="tokens" className="space-y-6">
        <TabsList className="bg-muted/50 border border-border/50 p-1">
          <TabsTrigger value="tokens" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground gap-2">
            <Key className="h-4 w-4" />
            API Tokens
          </TabsTrigger>
          <TabsTrigger value="docs" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground gap-2">
            <BookOpen className="h-4 w-4" />
            API Documentation
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tokens" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between border-b pb-4">
              <div>
                <CardTitle className="text-lg">API Tokens</CardTitle>
                <CardDescription className="mt-1">Create and manage tokens for CI/CD pipeline authentication</CardDescription>
              </div>
              {canWrite && <Button
                onClick={() => setShowCreate(!showCreate)}
                className="bg-primary hover:bg-primary/90 shadow-sm"
              >
                <Plus className="h-4 w-4 mr-2" /> Create Token
              </Button>}
            </CardHeader>
            <CardContent className="pt-5">
              {showCreate && (
                <div className="mb-6 p-5 rounded-xl border border-blue-200 dark:border-blue-500/20 bg-blue-50/50 dark:bg-blue-500/5 space-y-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Key className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                    <h4 className="text-sm font-semibold text-foreground">New API Token</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Name <span className="text-red-500">*</span></Label>
                      <Input
                        placeholder="e.g. Jenkins CI Pipeline"
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Input
                        placeholder="e.g. Main build pipeline token"
                        value={newDescription}
                        onChange={(e) => setNewDescription(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Scopes</Label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {AVAILABLE_SCOPES.map((scope) => (
                        <label
                          key={scope.id}
                          className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                            selectedScopes.includes(scope.id)
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/40"
                          }`}
                        >
                          <Checkbox
                            checked={selectedScopes.includes(scope.id)}
                            onCheckedChange={() => toggleScope(scope.id)}
                          />
                          <div>
                            <p className="text-sm font-medium">{scope.label}</p>
                            <p className="text-xs text-muted-foreground">{scope.description}</p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2 max-w-xs">
                    <Label>Expiration</Label>
                    <Select value={expiration} onValueChange={setExpiration}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {EXPIRATION_OPTIONS.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value}>
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <Button
                      onClick={() => createMutation.mutate()}
                      disabled={!newName.trim() || selectedScopes.length === 0 || createMutation.isPending}
                    >
                      {createMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Key className="h-4 w-4 mr-2" />}
                      Create Token
                    </Button>
                    <Button variant="ghost" onClick={() => setShowCreate(false)}>Cancel</Button>
                  </div>
                </div>
              )}

              {isLoading ? (
                <div className="space-y-3">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="flex items-center gap-4 p-4 rounded-xl border">
                      <Skeleton className="h-10 w-10 rounded-xl" />
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2.5">
                          <Skeleton className="h-4 w-36" />
                          <Skeleton className="h-5 w-20 rounded-md" />
                          <Skeleton className="h-5 w-14 rounded-full" />
                        </div>
                        <div className="flex items-center gap-4">
                          <Skeleton className="h-3 w-24" />
                          <Skeleton className="h-3 w-20" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : tokens.length === 0 ? (
                <EmptyState
                  icon={Key}
                  title="No API tokens created"
                  description="Create an API token to integrate performance testing into your CI/CD pipelines"
                  actionLabel="Create Token"
                  onAction={() => setShowCreate(true)}
                />
              ) : (
                <div className="space-y-2">
                  {tokens.map((token) => {
                    const status = getTokenStatus(token);
                    return (
                      <div
                        key={token.id}
                        className={`group flex items-center justify-between p-4 rounded-xl border transition-all duration-200 ${
                          status.variant === "revoked"
                            ? "border-red-200 dark:border-red-500/15 bg-red-50/50 dark:bg-red-500/3 opacity-60"
                            : status.variant === "expired"
                            ? "border-amber-200 dark:border-amber-500/15 bg-amber-50/50 dark:bg-amber-500/3 opacity-70"
                            : "border-border/50 hover:border-primary/40 hover:bg-muted/30"
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <div className={`p-2.5 rounded-xl transition-colors ${
                            status.variant === "revoked"
                              ? "bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20"
                              : status.variant === "expired"
                              ? "bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20"
                              : "bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-500/15"
                          }`}>
                            {status.variant === "revoked" ? (
                              <XCircle className="h-4 w-4 text-red-500" />
                            ) : status.variant === "expired" ? (
                              <Clock className="h-4 w-4 text-amber-500" />
                            ) : (
                              <CheckCircle className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2.5 flex-wrap">
                              <span className="font-medium text-foreground">{token.name}</span>
                              <code className="text-xs bg-muted px-2 py-0.5 rounded-md text-muted-foreground border border-border/50 font-mono">
                                {token.tokenPrefix}...
                              </code>
                              <Badge className={`text-[10px] px-1.5 py-0 h-5 ${statusBadgeClasses[status.variant]}`}>
                                {status.label.toUpperCase()}
                              </Badge>
                              {token.scopes?.map((scope) => (
                                <Badge key={scope} variant="outline" className="text-[10px] px-1.5 py-0 h-5">
                                  {scope}
                                </Badge>
                              ))}
                            </div>
                            <div className="flex items-center gap-4 mt-1.5 text-xs text-muted-foreground">
                              {token.description && <span>{token.description}</span>}
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                Created {new Date(token.createdAt).toLocaleDateString()}
                              </span>
                              <span className="flex items-center gap-1">
                                Last used: {timeAgo(token.lastUsedAt)}
                              </span>
                              {token.expiresAt && (
                                <span className="flex items-center gap-1">
                                  Expires: {new Date(token.expiresAt).toLocaleDateString()}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        {canWrite && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10"
                              >
                                <Trash2 className="h-4 w-4 mr-1.5" />
                                <span className="text-xs">{status.variant === "revoked" ? "Delete" : "Revoke"}</span>
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>{status.variant === "revoked" ? "Delete Token" : "Revoke Token"}</AlertDialogTitle>
                                <AlertDialogDescription>
                                  {status.variant === "revoked"
                                    ? `Are you sure you want to permanently delete "${token.name}"? This action cannot be undone.`
                                    : `Are you sure you want to revoke "${token.name}"? Any CI/CD pipelines using this token will lose access immediately.`}
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => status.variant === "revoked" ? deleteMutation.mutate(token.id) : revokeMutation.mutate(token.id)}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  {status.variant === "revoked" ? "Delete Permanently" : "Revoke Token"}
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="docs" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                Authentication
              </CardTitle>
              <CardDescription>All API calls require a Bearer token in the Authorization header</CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock title="HTTP Header">{`Authorization: Bearer phub_your_token_here`}</CodeBlock>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                Trigger a Test
              </CardTitle>
              <CardDescription>Start a performance test execution via the API</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <CodeBlock title="Request">{`POST /api/ci/trigger
Content-Type: application/json
Authorization: Bearer phub_your_token_here

{
  "scriptId": 1,
  "releaseTag": "v2.1.0",
  "config": {
    "vusers": 50,
    "duration": 300
  }
}`}</CodeBlock>
              <CodeBlock title="Response">{`{
  "executionId": 1,
  "runId": "RUN-20260218-143000-AB12",
  "status": "queued",
  "statusUrl": "/api/ci/status/1"
}`}</CodeBlock>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                Check Status
              </CardTitle>
              <CardDescription>Poll the execution status until completion</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <CodeBlock title="Request">{`GET /api/ci/status/:executionId
Authorization: Bearer phub_your_token_here`}</CodeBlock>
              <CodeBlock title="Response">{`{
  "executionId": 1,
  "status": "completed",
  "metrics": {
    "avgResponseTime": 245,
    "p95": 890,
    "errorRate": 0.02,
    "throughput": 150.5
  },
  "sla": {
    "passed": true,
    "rules": [
      { "metric": "p95", "comparator": "lt", "threshold": 1000, "actual": 890, "transactionLabel": "Global", "passed": true },
      { "metric": "errorRate", "comparator": "lt", "threshold": 0.05, "actual": 0.02, "transactionLabel": "Global", "passed": true }
    ]
  },
  "gate": {
    "verdict": "pass",
    "exitCode": 0,
    "reason": "All 2 SLA rule(s) passed",
    "evaluatedAt": "2026-02-18T14:35:00.000Z",
    "failedRules": []
  }
}`}</CodeBlock>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                Performance Gates
              </CardTitle>
              <CardDescription>Automated pass/fail decisions for your CI/CD pipelines based on SLA rules</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  The <code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">gate</code> object in the status response provides a clear, actionable verdict for your CI/CD pipeline. Instead of manually parsing SLA rules, use the gate verdict to determine if your build should pass or fail.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="p-3 rounded-lg border border-emerald-200 dark:border-emerald-500/20 bg-emerald-50/50 dark:bg-emerald-500/5">
                    <div className="flex items-center gap-2 mb-1">
                      <CheckCircle className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                      <span className="text-sm font-semibold text-emerald-700 dark:text-emerald-400">pass</span>
                      <code className="text-[10px] bg-emerald-100 dark:bg-emerald-500/10 px-1.5 py-0.5 rounded font-mono text-emerald-600 dark:text-emerald-300">exitCode: 0</code>
                    </div>
                    <p className="text-xs text-muted-foreground">Test completed and all SLA rules passed (or no SLA rules defined)</p>
                  </div>
                  <div className="p-3 rounded-lg border border-red-200 dark:border-red-500/20 bg-red-50/50 dark:bg-red-500/5">
                    <div className="flex items-center gap-2 mb-1">
                      <XCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
                      <span className="text-sm font-semibold text-red-700 dark:text-red-400">fail</span>
                      <code className="text-[10px] bg-red-100 dark:bg-red-500/10 px-1.5 py-0.5 rounded font-mono text-red-600 dark:text-red-300">exitCode: 1</code>
                    </div>
                    <p className="text-xs text-muted-foreground">Test failed/aborted, or completed with SLA violations</p>
                  </div>
                  <div className="p-3 rounded-lg border border-amber-200 dark:border-amber-500/20 bg-amber-50/50 dark:bg-amber-500/5">
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                      <span className="text-sm font-semibold text-amber-700 dark:text-amber-400">pending</span>
                      <code className="text-[10px] bg-amber-100 dark:bg-amber-500/10 px-1.5 py-0.5 rounded font-mono text-amber-600 dark:text-amber-300">exitCode: -1</code>
                    </div>
                    <p className="text-xs text-muted-foreground">Test is still queued, running, or being parsed</p>
                  </div>
                </div>
                <div className="mt-2">
                  <h4 className="text-sm font-semibold mb-2">Gate Object Fields</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-2 pr-4 font-medium">Field</th>
                          <th className="text-left py-2 pr-4 font-medium">Type</th>
                          <th className="text-left py-2 font-medium">Description</th>
                        </tr>
                      </thead>
                      <tbody className="text-muted-foreground">
                        <tr className="border-b border-border/50">
                          <td className="py-2 pr-4"><code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">verdict</code></td>
                          <td className="py-2 pr-4"><code className="text-xs">"pass" | "fail" | "pending"</code></td>
                          <td className="py-2">The overall gate decision</td>
                        </tr>
                        <tr className="border-b border-border/50">
                          <td className="py-2 pr-4"><code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">exitCode</code></td>
                          <td className="py-2 pr-4"><code className="text-xs">0 | 1 | -1</code></td>
                          <td className="py-2">Shell-friendly exit code (0=pass, 1=fail, -1=pending)</td>
                        </tr>
                        <tr className="border-b border-border/50">
                          <td className="py-2 pr-4"><code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">reason</code></td>
                          <td className="py-2 pr-4"><code className="text-xs">string</code></td>
                          <td className="py-2">Human-readable explanation of the verdict</td>
                        </tr>
                        <tr className="border-b border-border/50">
                          <td className="py-2 pr-4"><code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">evaluatedAt</code></td>
                          <td className="py-2 pr-4"><code className="text-xs">string | null</code></td>
                          <td className="py-2">ISO timestamp when the gate was evaluated</td>
                        </tr>
                        <tr>
                          <td className="py-2 pr-4"><code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">failedRules</code></td>
                          <td className="py-2 pr-4"><code className="text-xs">string[]</code></td>
                          <td className="py-2">Human-readable descriptions of failed SLA rules</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <CodeBlock title="Quick Shell Check">{`# Use exitCode for simple shell scripting
RESPONSE=$(curl -s "/api/ci/status/$EXEC_ID" -H "Authorization: Bearer $TOKEN")
EXIT_CODE=$(echo $RESPONSE | jq -r '.gate.exitCode')
VERDICT=$(echo $RESPONSE | jq -r '.gate.verdict')
REASON=$(echo $RESPONSE | jq -r '.gate.reason')

echo "Gate verdict: $VERDICT ($REASON)"
exit $EXIT_CODE`}</CodeBlock>
              <CodeBlock title="Failed Gate Response Example">{`{
  "gate": {
    "verdict": "fail",
    "exitCode": 1,
    "reason": "2 SLA rule(s) violated",
    "evaluatedAt": "2026-02-18T14:35:00.000Z",
    "failedRules": [
      "Global p95 lt 500 (actual: 890)",
      "Login avg lt 200 (actual: 345)"
    ]
  }
}`}</CodeBlock>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="h-5 w-5 text-orange-600 dark:text-orange-400" />
                CI/CD Pipeline Examples
              </CardTitle>
              <CardDescription>Copy-paste examples for popular CI/CD platforms</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">Jenkins</Badge>
                  Jenkinsfile (Groovy)
                </h3>
                <CodeBlock title="Jenkinsfile">{`pipeline {
    agent any
    environment {
        PERFHUB_TOKEN = credentials('perfhub-api-token')
        PERFHUB_URL   = 'https://your-perfhub-instance.com'
    }
    stages {
        stage('Performance Test') {
            steps {
                script {
                    // Trigger test
                    def triggerResponse = httpRequest(
                        url: "\${PERFHUB_URL}/api/ci/trigger",
                        httpMode: 'POST',
                        contentType: 'APPLICATION_JSON',
                        customHeaders: [[name: 'Authorization', value: "Bearer \${PERFHUB_TOKEN}"]],
                        requestBody: '''{
                            "scriptId": 1,
                            "releaseTag": "\${env.BUILD_TAG ?: 'v1.0.0'}",
                            "config": { "vusers": 50, "duration": 300 }
                        }'''
                    )
                    def trigger = readJSON text: triggerResponse.content
                    echo "Execution started: \${trigger.executionId}"

                    // Poll for completion
                    def status = 'queued'
                    while (status == 'queued' || status == 'running') {
                        sleep(time: 30, unit: 'SECONDS')
                        def statusResponse = httpRequest(
                            url: "\${PERFHUB_URL}/api/ci/status/\${trigger.executionId}",
                            customHeaders: [[name: 'Authorization', value: "Bearer \${PERFHUB_TOKEN}"]]
                        )
                        def result = readJSON text: statusResponse.content
                        status = result.status
                        echo "Status: \${status}"
                    }

                    // Check performance gate verdict
                    def finalResponse = httpRequest(
                        url: "\${PERFHUB_URL}/api/ci/status/\${trigger.executionId}",
                        customHeaders: [[name: 'Authorization', value: "Bearer \${PERFHUB_TOKEN}"]]
                    )
                    def finalResult = readJSON text: finalResponse.content
                    echo "Gate verdict: \${finalResult.gate.verdict} - \${finalResult.gate.reason}"
                    if (finalResult.gate.verdict != 'pass') {
                        finalResult.gate.failedRules.each { rule -> echo "  FAILED: \${rule}" }
                        error "Performance gate failed: \${finalResult.gate.reason}"
                    }
                }
            }
        }
    }
}`}</CodeBlock>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">GitHub Actions</Badge>
                  workflow.yml
                </h3>
                <CodeBlock title=".github/workflows/perf-test.yml">{`name: Performance Test
on:
  push:
    branches: [main]

jobs:
  performance-test:
    runs-on: ubuntu-latest
    steps:
      - name: Trigger Performance Test
        id: trigger
        run: |
          RESPONSE=$(curl -s -X POST \\
            "\${{ vars.PERFHUB_URL }}/api/ci/trigger" \\
            -H "Authorization: Bearer \${{ secrets.PERFHUB_TOKEN }}" \\
            -H "Content-Type: application/json" \\
            -d '{"scriptId": 1, "releaseTag": "\${{ github.ref_name }}", "config": {"vusers": 50, "duration": 300}}')
          EXEC_ID=$(echo $RESPONSE | jq -r '.executionId')
          echo "execution_id=$EXEC_ID" >> $GITHUB_OUTPUT
          echo "Triggered execution: $EXEC_ID"

      - name: Wait for Completion
        run: |
          STATUS="queued"
          while [ "$STATUS" = "queued" ] || [ "$STATUS" = "running" ]; do
            sleep 30
            RESPONSE=$(curl -s \\
              "\${{ vars.PERFHUB_URL }}/api/ci/status/\${{ steps.trigger.outputs.execution_id }}" \\
              -H "Authorization: Bearer \${{ secrets.PERFHUB_TOKEN }}")
            STATUS=$(echo $RESPONSE | jq -r '.status')
            echo "Status: $STATUS"
          done

      - name: Check Performance Gate
        run: |
          RESPONSE=$(curl -s \\
            "\${{ vars.PERFHUB_URL }}/api/ci/status/\${{ steps.trigger.outputs.execution_id }}" \\
            -H "Authorization: Bearer \${{ secrets.PERFHUB_TOKEN }}")
          VERDICT=$(echo $RESPONSE | jq -r '.gate.verdict')
          REASON=$(echo $RESPONSE | jq -r '.gate.reason')
          EXIT_CODE=$(echo $RESPONSE | jq -r '.gate.exitCode')
          echo "Gate verdict: $VERDICT - $REASON"
          if [ "$VERDICT" != "pass" ]; then
            echo "::error::Performance gate failed: $REASON"
            echo $RESPONSE | jq '.gate.failedRules[]'
            exit $EXIT_CODE
          fi
          echo "Performance gate passed!"
          echo $RESPONSE | jq '.metrics'`}</CodeBlock>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">GitLab CI</Badge>
                  .gitlab-ci.yml
                </h3>
                <CodeBlock title=".gitlab-ci.yml">{`stages:
  - performance

performance_test:
  stage: performance
  image: curlimages/curl:latest
  variables:
    PERFHUB_URL: "https://your-perfhub-instance.com"
  script:
    # Trigger the test
    - |
      RESPONSE=$(curl -s -X POST \\
        "$PERFHUB_URL/api/ci/trigger" \\
        -H "Authorization: Bearer $PERFHUB_TOKEN" \\
        -H "Content-Type: application/json" \\
        -d '{"scriptId": 1, "releaseTag": "'$CI_COMMIT_TAG'", "config": {"vusers": 50, "duration": 300}}')
      EXEC_ID=$(echo $RESPONSE | jq -r '.executionId')
      echo "Triggered execution: $EXEC_ID"

    # Poll for completion
    - |
      STATUS="queued"
      while [ "$STATUS" = "queued" ] || [ "$STATUS" = "running" ]; do
        sleep 30
        RESPONSE=$(curl -s \\
          "$PERFHUB_URL/api/ci/status/$EXEC_ID" \\
          -H "Authorization: Bearer $PERFHUB_TOKEN")
        STATUS=$(echo $RESPONSE | jq -r '.status')
        echo "Status: $STATUS"
      done

    # Check performance gate
    - |
      RESPONSE=$(curl -s \\
        "$PERFHUB_URL/api/ci/status/$EXEC_ID" \\
        -H "Authorization: Bearer $PERFHUB_TOKEN")
      VERDICT=$(echo $RESPONSE | jq -r '.gate.verdict')
      REASON=$(echo $RESPONSE | jq -r '.gate.reason')
      EXIT_CODE=$(echo $RESPONSE | jq -r '.gate.exitCode')
      echo "Gate verdict: $VERDICT - $REASON"
      if [ "$VERDICT" != "pass" ]; then
        echo "Performance gate failed!"
        echo $RESPONSE | jq '.gate.failedRules[]'
        exit $EXIT_CODE
      fi
      echo "Performance gate passed!"
  rules:
    - if: $CI_COMMIT_BRANCH == "main"`}</CodeBlock>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
