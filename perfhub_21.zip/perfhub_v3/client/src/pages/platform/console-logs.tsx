import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import {
  Terminal, Search, RefreshCw, AlertTriangle, AlertCircle,
  Info, Bug, Flame, Filter, X, Download, ChevronDown, ChevronRight,
  FileText, Clock, Activity
} from "lucide-react";

type LogLevel = "debug" | "info" | "warn" | "error" | "fatal";

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  source: string;
  message: string;
  meta?: Record<string, any>;
}

interface LogStats {
  total: number;
  byLevel: Record<LogLevel, number>;
  bySource: Record<string, number>;
  sources: string[];
}

interface LogFile {
  name: string;
  size: number;
  modified: string;
}

const LEVEL_CONFIG: Record<LogLevel, { label: string; icon: typeof Info; color: string; bgColor: string; badgeClass: string }> = {
  debug: {
    label: "DEBUG",
    icon: Bug,
    color: "text-slate-500",
    bgColor: "bg-slate-50 dark:bg-slate-900/30",
    badgeClass: "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700",
  },
  info: {
    label: "INFO",
    icon: Info,
    color: "text-blue-500",
    bgColor: "bg-blue-50/30 dark:bg-blue-950/10",
    badgeClass: "bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-500/20",
  },
  warn: {
    label: "WARN",
    icon: AlertTriangle,
    color: "text-amber-500",
    bgColor: "bg-amber-50/30 dark:bg-amber-950/10",
    badgeClass: "bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-500/20",
  },
  error: {
    label: "ERROR",
    icon: AlertCircle,
    color: "text-red-500",
    bgColor: "bg-red-50/40 dark:bg-red-950/15",
    badgeClass: "bg-red-50 dark:bg-red-500/10 text-red-700 dark:text-red-400 border-red-200 dark:border-red-500/20",
  },
  fatal: {
    label: "FATAL",
    icon: Flame,
    color: "text-red-600",
    bgColor: "bg-red-100/50 dark:bg-red-950/25",
    badgeClass: "bg-red-100 dark:bg-red-500/15 text-red-800 dark:text-red-300 border-red-300 dark:border-red-500/30",
  },
};

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatTimestamp(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", second: "2-digit", hour12: true });
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

export default function ConsoleLogsPage() {
  const [levelFilter, setLevelFilter] = useState<string>("all");
  const [sourceFilter, setSourceFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [expandedEntries, setExpandedEntries] = useState<Set<number>>(new Set());
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [showFiles, setShowFiles] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(searchTerm), 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const { data: stats } = useQuery<LogStats>({
    queryKey: ["/api/logs/stats"],
    queryFn: async () => {
      const res = await fetch("/api/logs/stats", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch stats");
      return res.json();
    },
    refetchInterval: autoRefresh ? 5000 : false,
  });

  const { data: logsData, isLoading, refetch } = useQuery<{ entries: LogEntry[]; total: number }>({
    queryKey: ["/api/logs", levelFilter, sourceFilter, debouncedSearch],
    queryFn: async () => {
      const params = new URLSearchParams({ limit: "200" });
      if (levelFilter !== "all") params.set("level", levelFilter);
      if (sourceFilter !== "all") params.set("source", sourceFilter);
      if (debouncedSearch) params.set("search", debouncedSearch);
      const res = await fetch(`/api/logs?${params}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch logs");
      return res.json();
    },
    refetchInterval: autoRefresh ? 3000 : false,
  });

  const { data: logFiles } = useQuery<{ files: LogFile[] }>({
    queryKey: ["/api/logs/files"],
    queryFn: async () => {
      const res = await fetch("/api/logs/files", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch log files");
      return res.json();
    },
    enabled: showFiles,
  });

  const entries = logsData?.entries || [];
  const hasFilters = levelFilter !== "all" || sourceFilter !== "all" || debouncedSearch;

  const toggleExpand = (idx: number) => {
    setExpandedEntries(prev => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const clearFilters = () => {
    setLevelFilter("all");
    setSourceFilter("all");
    setSearchTerm("");
    setDebouncedSearch("");
  };

  const handleDownloadFile = async (fileName: string) => {
    const res = await fetch(`/api/logs/files/${fileName}`, { credentials: "include" });
    if (!res.ok) return;
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="Console Logs"
        subtitle="Real-time application logs with file persistence"
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant={showFiles ? "default" : "outline"}
              size="sm"
              onClick={() => setShowFiles(!showFiles)}
            >
              <FileText className="h-4 w-4 mr-1" />Log Files
            </Button>
            <Button
              variant={autoRefresh ? "default" : "outline"}
              size="sm"
              onClick={() => setAutoRefresh(!autoRefresh)}
            >
              <RefreshCw className={`h-4 w-4 mr-1 ${autoRefresh ? "animate-spin" : ""}`} style={autoRefresh ? { animationDuration: "3s" } : {}} />
              {autoRefresh ? "Live" : "Paused"}
            </Button>
            <Button variant="outline" size="sm" onClick={() => refetch()}>
              <RefreshCw className="h-4 w-4 mr-1" />Refresh
            </Button>
          </div>
        }
      />

      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <Card className="col-span-1">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-2 mb-1">
                <Activity className="h-3.5 w-3.5 text-primary" />
                <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">Total</span>
              </div>
              <div className="text-lg font-bold">{stats.total.toLocaleString()}</div>
            </CardContent>
          </Card>
          {(["info", "warn", "error", "fatal"] as LogLevel[]).map(level => {
            const config = LEVEL_CONFIG[level];
            const LevelIcon = config.icon;
            const count = stats.byLevel[level] || 0;
            return (
              <Card
                key={level}
                className={`col-span-1 cursor-pointer transition-colors hover:border-primary/30 ${levelFilter === level ? "border-primary ring-1 ring-primary/20" : ""}`}
                onClick={() => setLevelFilter(levelFilter === level ? "all" : level)}
              >
                <CardContent className="pt-4 pb-3 px-4">
                  <div className="flex items-center gap-2 mb-1">
                    <LevelIcon className={`h-3.5 w-3.5 ${config.color}`} />
                    <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">{config.label}</span>
                  </div>
                  <div className={`text-lg font-bold ${count > 0 && (level === "error" || level === "fatal") ? config.color : ""}`}>
                    {count.toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            );
          })}
          <Card className="col-span-1">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-2 mb-1">
                <Terminal className="h-3.5 w-3.5 text-primary" />
                <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">Sources</span>
              </div>
              <div className="text-lg font-bold">{stats.sources?.length || 0}</div>
            </CardContent>
          </Card>
        </div>
      )}

      {showFiles && logFiles && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <FileText className="h-4 w-4 text-primary" />
              Persisted Log Files
            </CardTitle>
          </CardHeader>
          <CardContent>
            {logFiles.files.length === 0 ? (
              <p className="text-sm text-muted-foreground">No log files found yet.</p>
            ) : (
              <div className="space-y-1.5">
                {logFiles.files.map(file => (
                  <div key={file.name} className="flex items-center justify-between p-2.5 rounded-lg bg-muted/30 border">
                    <div className="flex items-center gap-3">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <div className="text-sm font-medium font-mono">{file.name}</div>
                        <div className="text-[10px] text-muted-foreground">
                          {formatBytes(file.size)} &middot; Modified {formatDate(file.modified)}
                        </div>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => handleDownloadFile(file.name)}>
                      <Download className="h-3.5 w-3.5 mr-1" />Download
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Terminal className="h-4 w-4 text-primary" />
              Log Stream
              {logsData && (
                <Badge variant="secondary" className="text-[10px]">
                  {logsData.total.toLocaleString()} entries
                </Badge>
              )}
            </CardTitle>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  placeholder="Search logs..."
                  className="h-8 w-48 pl-8 text-xs"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
              </div>
              <Select value={levelFilter} onValueChange={setLevelFilter}>
                <SelectTrigger className="h-8 w-28 text-xs">
                  <Filter className="h-3 w-3 mr-1" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="debug">Debug+</SelectItem>
                  <SelectItem value="info">Info+</SelectItem>
                  <SelectItem value="warn">Warn+</SelectItem>
                  <SelectItem value="error">Error+</SelectItem>
                  <SelectItem value="fatal">Fatal</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sourceFilter} onValueChange={setSourceFilter}>
                <SelectTrigger className="h-8 w-32 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sources</SelectItem>
                  {stats?.sources?.map(s => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {hasFilters && (
                <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={clearFilters}>
                  <X className="h-3.5 w-3.5 mr-1" />Clear
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-8 rounded bg-muted/50 animate-pulse" />
              ))}
            </div>
          ) : entries.length === 0 ? (
            <EmptyState
              icon={Terminal}
              title="No logs found"
              description={hasFilters ? "Try adjusting your filters or search term" : "Application logs will appear here as the server runs"}
            />
          ) : (
            <div className="rounded-lg border overflow-hidden">
              <div className="max-h-[600px] overflow-y-auto">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 z-10 bg-muted/80 backdrop-blur-sm border-b">
                    <tr>
                      <th className="text-left py-2 px-3 font-medium text-muted-foreground w-20">Time</th>
                      <th className="text-left py-2 px-3 font-medium text-muted-foreground w-16">Level</th>
                      <th className="text-left py-2 px-3 font-medium text-muted-foreground w-28">Source</th>
                      <th className="text-left py-2 px-3 font-medium text-muted-foreground">Message</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    {entries.map((entry, idx) => {
                      const config = LEVEL_CONFIG[entry.level];
                      const LevelIcon = config.icon;
                      const isExpanded = expandedEntries.has(idx);
                      const hasMeta = entry.meta && Object.keys(entry.meta).length > 0;

                      return (
                        <tr
                          key={idx}
                          className={`${config.bgColor} hover:bg-muted/40 transition-colors ${hasMeta ? "cursor-pointer" : ""}`}
                          onClick={() => hasMeta && toggleExpand(idx)}
                        >
                          <td className="py-1.5 px-3 font-mono text-muted-foreground whitespace-nowrap align-top">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3 shrink-0" />
                              {formatTimestamp(entry.timestamp)}
                            </div>
                          </td>
                          <td className="py-1.5 px-3 align-top">
                            <Badge variant="outline" className={`text-[9px] px-1.5 py-0 font-mono ${config.badgeClass}`}>
                              <LevelIcon className="h-2.5 w-2.5 mr-0.5" />
                              {config.label}
                            </Badge>
                          </td>
                          <td className="py-1.5 px-3 align-top">
                            <span className="font-mono text-muted-foreground">{entry.source}</span>
                          </td>
                          <td className="py-1.5 px-3 align-top">
                            <div>
                              <div className="flex items-start gap-1">
                                {hasMeta && (
                                  isExpanded
                                    ? <ChevronDown className="h-3 w-3 shrink-0 mt-0.5 text-muted-foreground" />
                                    : <ChevronRight className="h-3 w-3 shrink-0 mt-0.5 text-muted-foreground" />
                                )}
                                <span className={`break-all ${entry.level === "error" || entry.level === "fatal" ? "font-medium " + config.color : ""}`}>
                                  {entry.message}
                                </span>
                              </div>
                              {isExpanded && hasMeta && (
                                <div className="mt-2 mb-1 ml-4">
                                  <pre className="bg-slate-900 text-emerald-400 p-3 rounded-md text-[10px] overflow-x-auto whitespace-pre-wrap font-mono leading-relaxed border border-slate-700">
                                    {JSON.stringify(entry.meta, null, 2)}
                                  </pre>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          <div ref={logEndRef} />
        </CardContent>
      </Card>
    </div>
  );
}
