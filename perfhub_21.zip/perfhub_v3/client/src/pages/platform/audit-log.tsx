import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/page-header";
import { useToast } from "@/hooks/use-toast";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { EmptyState } from "@/components/empty-state";
import { Shield, ScrollText, ChevronDown, ChevronRight, Clock, User, Filter, X, Trash2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface AuditLog {
  id: number;
  userId: number;
  action: string;
  resourceType: string;
  resourceId: string | number | null;
  details: {
    metadata?: Record<string, unknown>;
    ipAddress?: string;
    userAgent?: string;
  };
  timestamp: string;
  username: string;
}

interface AuditLogsResponse {
  logs: AuditLog[];
  total: number;
  limit: number;
  offset: number;
}

interface Filters {
  action: string;
  resourceType: string;
  startDate: string;
  endDate: string;
}

const PAGE_SIZE = 50;

function getActionBadgeClasses(action: string): string {
  const a = action.toLowerCase();
  if (a === "login" || a === "logout" || a === "signup")
    return "bg-blue-50 dark:bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-500/20";
  if (a.startsWith("create"))
    return "bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-500/20";
  if (a.startsWith("update"))
    return "bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-500/20";
  if (a.startsWith("delete"))
    return "bg-red-50 dark:bg-red-500/15 text-red-700 dark:text-red-400 border-red-200 dark:border-red-500/20";
  if (a.startsWith("execution"))
    return "bg-purple-50 dark:bg-purple-500/15 text-purple-700 dark:text-purple-400 border-purple-200 dark:border-purple-500/20";
  if (a === "approve" || a === "reject")
    return "bg-indigo-50 dark:bg-indigo-500/15 text-indigo-700 dark:text-indigo-400 border-indigo-200 dark:border-indigo-500/20";
  return "bg-muted text-muted-foreground border-border/50";
}

export default function AuditLogPage() {
  const { canWrite } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [page, setPage] = useState(0);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [filters, setFilters] = useState<Filters>({
    action: "",
    resourceType: "",
    startDate: "",
    endDate: "",
  });

  const hasFilters = filters.action || filters.resourceType || filters.startDate || filters.endDate;

  const deleteMutation = useMutation({
    mutationFn: async (ids: number[]) => {
      const res = await apiRequest("DELETE", "/api/audit-logs", { ids });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.auditLogs });
      setSelectedIds(new Set());
      toast({ title: `Deleted ${data.deleted} log${data.deleted !== 1 ? "s" : ""}` });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const clearAllMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", "/api/audit-logs/all");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.auditLogs });
      setSelectedIds(new Set());
      setPage(0);
      toast({ title: `Cleared ${data.deleted} audit log${data.deleted !== 1 ? "s" : ""}` });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const toggleSelect = (id: number) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === logs.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(logs.map(l => l.id)));
    }
  };

  const { data: actions = [] } = useQuery<string[]>({
    queryKey: [...queryKeys.auditLogs, "actions"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/audit-logs/actions");
      return res.json();
    },
  });

  const { data: resourceTypes = [] } = useQuery<string[]>({
    queryKey: [...queryKeys.auditLogs, "resource-types"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/audit-logs/resource-types");
      return res.json();
    },
  });

  const queryFilters = { ...filters, page };

  const { data, isLoading, isError, error, refetch } = useQuery<AuditLogsResponse>({
    queryKey: [...queryKeys.auditLogs, queryFilters],
    queryFn: async () => {
      const params = new URLSearchParams();
      params.set("limit", String(PAGE_SIZE));
      params.set("offset", String(page * PAGE_SIZE));
      if (filters.action) params.set("action", filters.action);
      if (filters.resourceType) params.set("resourceType", filters.resourceType);
      if (filters.startDate) params.set("startDate", filters.startDate);
      if (filters.endDate) params.set("endDate", filters.endDate);
      const res = await apiRequest("GET", `/api/audit-logs?${params.toString()}`);
      return res.json();
    },
  });

  const logs = data?.logs ?? [];
  const total = data?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  function clearFilters() {
    setFilters({ action: "", resourceType: "", startDate: "", endDate: "" });
    setPage(0);
  }

  function updateFilter(key: keyof Filters, value: string) {
    setFilters((prev) => ({ ...prev, [key]: value }));
    setPage(0);
  }

  if (isError) return (
    <div className="section-gap">
      <PageHeader title="Audit Trail" subtitle="Activity log for compliance and security monitoring" />
      <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load audit logs" />
    </div>
  );

  return (
    <div className="section-gap">
      <PageHeader
        title="Audit Trail"
        subtitle="Activity log for compliance and security monitoring"
      />

      <Card>
        <CardHeader className="border-b pb-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-muted-foreground" />
              <CardTitle className="text-lg">Activity Log</CardTitle>
              {total > 0 && (
                <Badge variant="secondary" className="text-xs">{total} entries</Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              {canWrite && selectedIds.size > 0 && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm" disabled={deleteMutation.isPending}>
                      <Trash2 className="h-4 w-4 mr-1.5" />
                      Delete {selectedIds.size} Selected
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Selected Logs</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently delete {selectedIds.size} audit log{selectedIds.size !== 1 ? "s" : ""}. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => deleteMutation.mutate(Array.from(selectedIds))}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
              {canWrite && total > 0 && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" size="sm" disabled={clearAllMutation.isPending} className="text-destructive hover:text-destructive">
                      <Trash2 className="h-4 w-4 mr-1.5" />
                      Clear All
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Clear All Audit Logs</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently delete all {total} audit log entries. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => clearAllMutation.mutate()}
                      >
                        Delete All
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
              {hasFilters && (
                <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground hover:text-foreground">
                  <X className="h-4 w-4 mr-1" />
                  Clear Filters
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="flex flex-wrap items-end gap-3 mb-6 p-4 rounded-lg border border-border/50 bg-muted/30">
            <div className="flex items-center gap-2 text-xs text-muted-foreground font-medium uppercase tracking-wider">
              <Filter className="h-3.5 w-3.5" />
              Filters
            </div>
            <div className="flex flex-wrap items-end gap-3 flex-1">
              <div className="w-48">
                <label className="text-xs text-muted-foreground mb-1 block">Action</label>
                <Select value={filters.action} onValueChange={(v) => updateFilter("action", v === "all" ? "" : v)}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="All actions" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All actions</SelectItem>
                    {actions.map((a) => (
                      <SelectItem key={a} value={a}>{a}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-48">
                <label className="text-xs text-muted-foreground mb-1 block">Resource Type</label>
                <Select value={filters.resourceType} onValueChange={(v) => updateFilter("resourceType", v === "all" ? "" : v)}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="All types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All types</SelectItem>
                    {resourceTypes.map((rt) => (
                      <SelectItem key={rt} value={rt}>{rt}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-44">
                <label className="text-xs text-muted-foreground mb-1 block">Start Date</label>
                <Input
                  type="date"
                  className="h-9"
                  value={filters.startDate}
                  onChange={(e) => updateFilter("startDate", e.target.value)}
                />
              </div>
              <div className="w-44">
                <label className="text-xs text-muted-foreground mb-1 block">End Date</label>
                <Input
                  type="date"
                  className="h-9"
                  value={filters.endDate}
                  onChange={(e) => updateFilter("endDate", e.target.value)}
                />
              </div>
            </div>
          </div>

          {isLoading ? (
            <div className="space-y-2">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="flex items-center gap-4 p-4 rounded-lg border border-border/50">
                  <Skeleton className="h-4 w-4 rounded" />
                  <Skeleton className="h-4 w-36" />
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-5 w-20 rounded-full" />
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-4 w-28" />
                </div>
              ))}
            </div>
          ) : logs.length === 0 ? (
            <EmptyState
              icon={ScrollText}
              title="No audit logs found"
              description={hasFilters
                ? "No activity matches your current filters. Try adjusting or clearing them."
                : "Activity will appear here as users interact with the platform."}
            />
          ) : (
            <>
              <div className="rounded-lg border border-border/50 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-muted/40">
                        <th className="w-10 px-3 py-3">
                          <Checkbox
                            checked={logs.length > 0 && selectedIds.size === logs.length}
                            onCheckedChange={toggleSelectAll}
                          />
                        </th>
                        <th className="w-8 px-3 py-3"></th>
                        <th className="px-4 py-3 text-left font-medium text-muted-foreground">Timestamp</th>
                        <th className="px-4 py-3 text-left font-medium text-muted-foreground">User</th>
                        <th className="px-4 py-3 text-left font-medium text-muted-foreground">Action</th>
                        <th className="px-4 py-3 text-left font-medium text-muted-foreground">Resource Type</th>
                        <th className="px-4 py-3 text-left font-medium text-muted-foreground">Resource ID</th>
                        <th className="px-4 py-3 text-left font-medium text-muted-foreground">IP Address</th>
                      </tr>
                    </thead>
                    <tbody>
                      {logs.map((log) => {
                        const isExpanded = expandedId === log.id;
                        const isSelected = selectedIds.has(log.id);
                        return (
                          <tr key={log.id} className="group">
                            <td colSpan={8} className="p-0">
                              <div
                                className={`flex items-center cursor-pointer transition-colors hover:bg-muted/30 ${isExpanded ? "bg-muted/20" : ""} ${isSelected ? "bg-destructive/5" : ""}`}
                                onClick={() => setExpandedId(isExpanded ? null : log.id)}
                              >
                                <div className="w-10 px-3 py-3 flex items-center justify-center" onClick={(e) => e.stopPropagation()}>
                                  <Checkbox
                                    checked={isSelected}
                                    onCheckedChange={() => toggleSelect(log.id)}
                                  />
                                </div>
                                <div className="w-8 px-3 py-3 flex items-center justify-center text-muted-foreground">
                                  {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                                </div>
                                <div className="px-4 py-3 whitespace-nowrap text-muted-foreground flex items-center gap-1.5 min-w-[180px]">
                                  <Clock className="h-3.5 w-3.5 shrink-0" />
                                  {new Date(log.timestamp).toLocaleString()}
                                </div>
                                <div className="px-4 py-3 whitespace-nowrap min-w-[120px]">
                                  <span className="flex items-center gap-1.5">
                                    <User className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                                    <span className="font-medium text-foreground">{log.username}</span>
                                  </span>
                                </div>
                                <div className="px-4 py-3 whitespace-nowrap min-w-[140px]">
                                  <Badge variant="outline" className={`text-[11px] font-medium border ${getActionBadgeClasses(log.action)}`}>
                                    {log.action}
                                  </Badge>
                                </div>
                                <div className="px-4 py-3 whitespace-nowrap text-muted-foreground min-w-[120px]">
                                  {log.resourceType}
                                </div>
                                <div className="px-4 py-3 whitespace-nowrap min-w-[100px]">
                                  {log.resourceId ? (
                                    <code className="text-xs bg-muted px-2 py-0.5 rounded-md text-muted-foreground border border-border/50 font-mono">
                                      {log.resourceId}
                                    </code>
                                  ) : (
                                    <span className="text-muted-foreground/50">—</span>
                                  )}
                                </div>
                                <div className="px-4 py-3 whitespace-nowrap text-xs text-muted-foreground font-mono min-w-[120px]">
                                  {log.details?.ipAddress || "—"}
                                </div>
                              </div>
                              {isExpanded && (
                                <div className="border-t border-border/30 bg-muted/10 px-12 py-4">
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {log.details?.userAgent && (
                                      <div>
                                        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">User Agent</p>
                                        <p className="text-xs text-muted-foreground break-all">{log.details.userAgent}</p>
                                      </div>
                                    )}
                                    {log.details?.ipAddress && (
                                      <div>
                                        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">IP Address</p>
                                        <p className="text-xs text-foreground font-mono">{log.details.ipAddress}</p>
                                      </div>
                                    )}
                                  </div>
                                  {log.details?.metadata && Object.keys(log.details.metadata).length > 0 && (
                                    <div className="mt-4">
                                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Metadata</p>
                                      <pre className="text-xs bg-slate-900 text-emerald-400 p-4 rounded-lg overflow-x-auto font-mono border border-slate-700">
                                        {JSON.stringify(log.details.metadata, null, 2)}
                                      </pre>
                                    </div>
                                  )}
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="flex items-center justify-between mt-4 px-1">
                <p className="text-sm text-muted-foreground">
                  Page {page + 1} of {totalPages}
                  <span className="ml-2 text-xs">({total} total entries)</span>
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage((p) => Math.max(0, p - 1))}
                    disabled={page === 0}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                    disabled={page >= totalPages - 1}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
