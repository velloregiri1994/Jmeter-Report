import { useState, useRef, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Key, Plus, Copy, Trash2, Loader2, XCircle,
  Shield, Clock, Radio, AlertTriangle, Terminal,
  Download, Network, Server, Globe, Lock,
  Zap, ArrowRight, CheckCircle, BookOpen,
  HardDrive, Cpu, Activity, FileCode, Check
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { copyToClipboard } from "@/lib/clipboard";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { EmptyState } from "@/components/empty-state";

interface IngestToken {
  id: number;
  name: string;
  description: string | null;
  tokenPrefix: string;
  createdBy: number | null;
  createdAt: string;
  revokedAt: string | null;
  lastUsedAt: string | null;
  allowedExecutionIds: number[] | null;
  lastHeartbeatAt: string | null;
  activeExecutionCount: number | null;
  completedExecutionCount: number | null;
  totalSamplesIngested: number | null;
  lastNodeId: string | null;
}

function getAgentStatus(token: IngestToken): { label: string; color: string; dotColor: string } {
  if (token.revokedAt) return { label: "Revoked", color: "text-red-600 dark:text-red-400", dotColor: "bg-red-500" };
  if (!token.lastHeartbeatAt) return { label: "Never Connected", color: "text-muted-foreground", dotColor: "bg-gray-400" };
  const lastSeen = Date.now() - new Date(token.lastHeartbeatAt).getTime();
  if ((token.activeExecutionCount ?? 0) > 0 && lastSeen < 5 * 60 * 1000) return { label: "Running", color: "text-emerald-600 dark:text-emerald-400", dotColor: "bg-emerald-500 animate-pulse" };
  if (lastSeen < 5 * 60 * 1000) return { label: "Online", color: "text-blue-600 dark:text-blue-400", dotColor: "bg-blue-500" };
  if (lastSeen < 30 * 60 * 1000) return { label: "Idle", color: "text-amber-600 dark:text-amber-400", dotColor: "bg-amber-500" };
  return { label: "Offline", color: "text-muted-foreground", dotColor: "bg-gray-400" };
}

function timeAgo(dateStr: string | null): string {
  if (!dateStr) return "Never";
  const ms = Date.now() - new Date(dateStr).getTime();
  if (ms < 60000) return "Just now";
  if (ms < 3600000) return `${Math.floor(ms / 60000)}m ago`;
  if (ms < 86400000) return `${Math.floor(ms / 3600000)}h ago`;
  return `${Math.floor(ms / 86400000)}d ago`;
}

export default function IngestTokensPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [revealedToken, setRevealedToken] = useState<string | null>(null);
  const [tokenCopied, setTokenCopied] = useState(false);
  const [activeTab, setActiveTab] = useState("tokens");
  const tokenInputRef = useRef<HTMLInputElement>(null);

  const handleCopyToken = useCallback(async () => {
    if (!revealedToken) return;
    const ok = await copyToClipboard(revealedToken);
    if (ok) {
      setTokenCopied(true);
      toast({ title: "Copied to clipboard" });
      setTimeout(() => setTokenCopied(false), 3000);
    } else {
      tokenInputRef.current?.select();
      toast({ title: "Please press Ctrl+C / Cmd+C to copy the selected text" });
    }
  }, [revealedToken, toast]);

  const { data: tokens = [], isLoading, isError, error, refetch } = useQuery<IngestToken[]>({
    queryKey: [...queryKeys.admin.ingestTokens],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/admin/ingest-tokens");
      return res.json();
    },
    refetchInterval: activeTab === "agents" ? 30000 : false,
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/ingest-tokens", { name: newName, description: newDescription || null });
      return res.json();
    },
    onSuccess: (data) => {
      setRevealedToken(data.rawToken);
      setNewName("");
      setNewDescription("");
      setShowCreate(false);
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.ingestTokens });
      toast({ title: "Token Created", description: "Copy the token now — it won't be shown again." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const revokeMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/ingest-tokens/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.ingestTokens });
      toast({ title: "Token Revoked" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/ingest-tokens/${id}?force=true`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.ingestTokens });
      toast({ title: "Token Deleted" });
    },
  });

  const activeTokens = tokens.filter((t) => !t.revokedAt);
  const revokedTokens = tokens.filter((t) => t.revokedAt);

  if (isError) return (
    <div className="space-y-6">
      <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load ingest tokens" />
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-xl border bg-card p-6 sm:p-8">
        <div className="absolute top-4 right-4 opacity-[0.06]">
          <Network className="h-40 w-40 text-foreground" />
        </div>
        <div className="relative">
          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20">
              <Network className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
              <span className="text-xs font-medium text-blue-700 dark:text-blue-300 tracking-wide uppercase">Distributed Testing</span>
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
            Distributed Test Execution
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base max-w-2xl">
            Connect remote JMeter nodes across your infrastructure to stream live results into PerfHub.
            Manage authentication tokens, download the agent plugin, and monitor distributed test runs.
          </p>
          <div className="flex flex-wrap gap-3 mt-5">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted/50 border">
              <Lock className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
              <span className="text-xs text-muted-foreground">Token Auth</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted/50 border">
              <Zap className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
              <span className="text-xs text-muted-foreground">Gzip Compression</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted/50 border">
              <Activity className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
              <span className="text-xs text-muted-foreground">Real-time Streaming</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted/50 border">
              <Shield className="h-3.5 w-3.5 text-purple-600 dark:text-purple-400" />
              <span className="text-xs text-muted-foreground">SHA-256 Hashing</span>
            </div>
          </div>
        </div>
      </div>

      <Dialog open={!!revealedToken} onOpenChange={(open) => { if (!open) { setRevealedToken(null); setTokenCopied(false); } }}>
        <DialogContent className="sm:max-w-lg" onInteractOutside={(e) => e.preventDefault()}>
          <DialogHeader>
            <div className="mx-auto mb-2 p-3 rounded-full bg-amber-100 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 w-fit">
              <Key className="h-6 w-6 text-amber-600 dark:text-amber-400" />
            </div>
            <DialogTitle className="text-center">Token Created Successfully</DialogTitle>
            <DialogDescription className="text-center">
              Copy this token now. For security reasons, it will not be shown again.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="flex items-center gap-2">
              <Input
                ref={tokenInputRef}
                readOnly
                value={revealedToken || ""}
                className="font-mono text-sm bg-slate-900 text-emerald-400 border-slate-700 h-12"
                onFocus={(e) => e.target.select()}
                onClick={(e) => (e.target as HTMLInputElement).select()}
              />
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 h-12 w-12"
                onClick={handleCopyToken}
              >
                {tokenCopied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
            <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50 dark:bg-amber-500/5 border border-amber-200 dark:border-amber-500/20">
              <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
              <p className="text-xs text-amber-700 dark:text-amber-300/80">
                Store this token in a secure location. You will need it to authenticate remote JMeter agents. If lost, revoke and create a new one.
              </p>
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => { tokenInputRef.current?.select(); }}>
              Select All
            </Button>
            <Button onClick={handleCopyToken}>
              {tokenCopied ? <><Check className="h-4 w-4 mr-2" /> Copied</> : <><Copy className="h-4 w-4 mr-2" /> Copy Token</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="rounded-xl border border-border/50 bg-card p-5 shadow-sm hover:border-emerald-300 dark:hover:border-emerald-500/30 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Active Tokens</p>
              <p className="text-3xl font-bold text-foreground mt-1">{activeTokens.length}</p>
            </div>
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20">
              <Key className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-border/50 bg-card p-5 shadow-sm hover:border-red-300 dark:hover:border-red-500/30 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Revoked</p>
              <p className="text-3xl font-bold text-foreground mt-1">{revokedTokens.length}</p>
            </div>
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20">
              <XCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-border/50 bg-card p-5 shadow-sm hover:border-cyan-300 dark:hover:border-cyan-500/30 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Encryption</p>
              <p className="text-3xl font-bold text-foreground mt-1">SHA-256</p>
            </div>
            <div className="p-3 rounded-xl bg-cyan-50 dark:bg-cyan-500/10 border border-cyan-200 dark:border-cyan-500/20">
              <Shield className="h-5 w-5 text-cyan-600 dark:text-cyan-400" />
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-border/50 bg-card p-5 shadow-sm hover:border-blue-300 dark:hover:border-blue-500/30 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Protocol</p>
              <p className="text-3xl font-bold text-foreground mt-1">HTTPS</p>
            </div>
            <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20">
              <Globe className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            </div>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-muted/50 border border-border/50 p-1">
          <TabsTrigger value="tokens" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground gap-2">
            <Key className="h-4 w-4" />
            Access Tokens
          </TabsTrigger>
          <TabsTrigger value="agents" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground gap-2">
            <Server className="h-4 w-4" />
            Remote Agents
          </TabsTrigger>
          <TabsTrigger value="setup" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground gap-2">
            <BookOpen className="h-4 w-4" />
            Setup Guide
          </TabsTrigger>
          <TabsTrigger value="api" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground gap-2">
            <FileCode className="h-4 w-4" />
            API Reference
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tokens" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between border-b pb-4">
              <div>
                <CardTitle className="text-lg">Authentication Tokens</CardTitle>
                <CardDescription className="mt-1">Issue and manage Bearer tokens for remote JMeter node authentication</CardDescription>
              </div>
              <Button
                onClick={() => setShowCreate(!showCreate)}
                className="bg-primary hover:bg-primary/90 shadow-sm"
              >
                <Plus className="h-4 w-4 mr-2" /> New Token
              </Button>
            </CardHeader>
            <CardContent className="pt-5">
              {showCreate && (
                <div className="mb-6 p-5 rounded-xl border border-blue-200 dark:border-blue-500/20 bg-blue-50/50 dark:bg-blue-500/5 space-y-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Key className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                    <h4 className="text-sm font-semibold text-foreground">Generate New Token</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Token Name</Label>
                      <Input
                        placeholder="e.g. AWS us-east-1 Load Generator"
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Description (optional)</Label>
                      <Input
                        placeholder="e.g. c5.4xlarge instance, 16 vCPU"
                        value={newDescription}
                        onChange={(e) => setNewDescription(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <Button
                      onClick={() => createMutation.mutate()}
                      disabled={!newName.trim() || createMutation.isPending}
                    >
                      {createMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Key className="h-4 w-4 mr-2" />}
                      Generate Token
                    </Button>
                    <Button variant="ghost" onClick={() => setShowCreate(false)}>Cancel</Button>
                  </div>
                </div>
              )}

              {isLoading ? (
                <div className="space-y-2">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="flex items-center justify-between p-4 rounded-xl border">
                      <div className="flex items-center gap-4">
                        <Skeleton className="h-10 w-10 rounded-xl" />
                        <div className="space-y-2">
                          <div className="flex items-center gap-2.5">
                            <Skeleton className="h-4 w-36" />
                            <Skeleton className="h-5 w-20 rounded-md" />
                            <Skeleton className="h-5 w-14 rounded-full" />
                          </div>
                          <div className="flex items-center gap-4">
                            <Skeleton className="h-3 w-24" />
                            <Skeleton className="h-3 w-20" />
                          </div>
                        </div>
                      </div>
                      <Skeleton className="h-8 w-8 rounded-md" />
                    </div>
                  ))}
                </div>
              ) : tokens.length === 0 ? (
                <EmptyState
                  icon={Shield}
                  title="No tokens configured"
                  description="Create an authentication token to enable remote JMeter nodes to stream test results"
                  actionLabel="New Token"
                  onAction={() => setShowCreate(true)}
                />
              ) : (
                <div className="space-y-2">
                  {tokens.map((token) => (
                    <div
                      key={token.id}
                      className={`group flex items-center justify-between p-4 rounded-xl border transition-all duration-200 ${
                        token.revokedAt
                          ? "border-red-200 dark:border-red-500/15 bg-red-50/50 dark:bg-red-500/3 opacity-60"
                          : "border-border/50 hover:border-primary/40 hover:bg-muted/30"
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`p-2.5 rounded-xl transition-colors ${
                          token.revokedAt
                            ? "bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20"
                            : "bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-500/15"
                        }`}>
                          {token.revokedAt ? (
                            <XCircle className="h-4 w-4 text-red-500" />
                          ) : (
                            <Key className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2.5">
                            <span className="font-medium text-foreground">{token.name}</span>
                            <code className="text-xs bg-muted px-2 py-0.5 rounded-md text-muted-foreground border border-border/50 font-mono">
                              {token.tokenPrefix}...
                            </code>
                            {token.revokedAt ? (
                              <Badge variant="destructive" className="text-[10px] px-1.5 py-0 h-5">REVOKED</Badge>
                            ) : (
                              <Badge className="bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20 text-[10px] px-1.5 py-0 h-5">ACTIVE</Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-4 mt-1.5 text-xs text-muted-foreground">
                            {token.description && <span>{token.description}</span>}
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {new Date(token.createdAt).toLocaleDateString()}
                            </span>
                            {token.lastUsedAt && (
                              <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400/70">
                                <Radio className="h-3 w-3" />
                                Last active {new Date(token.lastUsedAt).toLocaleString()}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10"
                          >
                            <Trash2 className="h-4 w-4 mr-1.5" />
                            <span className="text-xs">{token.revokedAt ? "Delete" : "Revoke"}</span>
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>{token.revokedAt ? "Delete Token" : "Revoke Token"}</AlertDialogTitle>
                            <AlertDialogDescription>
                              {token.revokedAt
                                ? `Are you sure you want to permanently delete "${token.name}"? This action cannot be undone.`
                                : `Are you sure you want to revoke "${token.name}"? Any systems using it will lose access immediately.`}
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => token.revokedAt ? deleteMutation.mutate(token.id) : revokeMutation.mutate(token.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              {token.revokedAt ? "Delete Permanently" : "Revoke"}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="agents" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between border-b pb-4">
              <div>
                <CardTitle className="text-lg">Remote Agent Status</CardTitle>
                <CardDescription className="mt-1">Monitor the health and activity of your distributed JMeter agents</CardDescription>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Activity className="h-3.5 w-3.5" />
                Auto-refreshes every 30s
              </div>
            </CardHeader>
            <CardContent className="pt-5">
              {isLoading ? (
                <div className="space-y-3">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-24 w-full rounded-xl" />
                  ))}
                </div>
              ) : activeTokens.length === 0 ? (
                <div className="text-center py-16">
                  <div className="p-4 rounded-2xl bg-muted/50 border w-fit mx-auto mb-4">
                    <Server className="h-10 w-10 text-muted-foreground" />
                  </div>
                  <p className="text-lg font-medium text-foreground mb-1">No active agents</p>
                  <p className="text-sm text-muted-foreground max-w-sm mx-auto">
                    Create an access token and configure a remote JMeter node to get started
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {activeTokens.map((token) => {
                    const status = getAgentStatus(token);
                    return (
                      <div key={token.id} className="rounded-xl border p-5 hover:border-primary/30 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="relative">
                              <div className="p-2.5 rounded-xl bg-muted/50 border">
                                <Server className="h-5 w-5 text-foreground/70" />
                              </div>
                              <div className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-background ${status.dotColor}`} />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-foreground">{token.name}</span>
                                <span className={`text-xs font-medium ${status.color}`}>{status.label}</span>
                              </div>
                              {token.description && (
                                <p className="text-xs text-muted-foreground mt-0.5">{token.description}</p>
                              )}
                              {token.lastNodeId && (
                                <div className="flex items-center gap-1 mt-1">
                                  <Cpu className="h-3 w-3 text-muted-foreground" />
                                  <span className="text-xs text-muted-foreground font-mono">{token.lastNodeId}</span>
                                </div>
                              )}
                            </div>
                          </div>
                          <code className="text-xs bg-muted px-2 py-0.5 rounded-md text-muted-foreground border font-mono">
                            {token.tokenPrefix}...
                          </code>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4 pt-4 border-t border-border/50">
                          <div>
                            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Active Tests</p>
                            <p className="text-lg font-bold text-foreground mt-0.5">{token.activeExecutionCount ?? 0}</p>
                          </div>
                          <div>
                            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Completed</p>
                            <p className="text-lg font-bold text-foreground mt-0.5">{token.completedExecutionCount ?? 0}</p>
                          </div>
                          <div>
                            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Samples Ingested</p>
                            <p className="text-lg font-bold text-foreground mt-0.5">{((token.totalSamplesIngested ?? 0) / 1000).toFixed(1)}k</p>
                          </div>
                          <div>
                            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Last Heartbeat</p>
                            <p className="text-sm font-medium text-foreground mt-1">{timeAgo(token.lastHeartbeatAt)}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="setup" className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Download className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                Agent Plugin
              </CardTitle>
              <CardDescription>JMeter BackendListener JAR for remote result streaming</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-4 rounded-xl bg-blue-50/50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-500/15">
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-xl bg-blue-100 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20">
                    <HardDrive className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">perfhub-backend-listener-1.4.0.jar</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Java 11+ compatible | JMeter 5.x+ | System metrics | Auto-abort support</p>
                  </div>
                </div>
                <Button
                  onClick={() => window.open("/api/admin/download-backend-listener", "_blank")}
                  className="shadow-sm"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download JAR
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StepCard
              step={1}
              icon={<Download className="h-5 w-5" />}
              title="Install Plugin"
              description="Copy the downloaded JAR into your JMeter installation's lib/ext directory and restart JMeter."
              code={`cp perfhub-backend-listener-1.4.0.jar \\
  $JMETER_HOME/lib/ext/`}
            />
            <StepCard
              step={2}
              icon={<Cpu className="h-5 w-5" />}
              title="Configure BackendListener"
              description="Add a Backend Listener in your JMX test plan. PerfHub auto-creates the execution when results arrive — no pre-setup needed."
              code={`perfhub.url=https://<your-perfhub>/api/ingest/samples
perfhub.token=phi_<your-token>
perfhub.testName=My Load Test
perfhub.runId=<unique-run-id>
perfhub.nodeId=node-1
perfhub.batchSize=500
perfhub.flushIntervalMs=5000
perfhub.gzipEnabled=true
perfhub.collectSystemMetrics=true`}
            />
            <StepCard
              step={3}
              icon={<Activity className="h-5 w-5" />}
              title="Run & Monitor"
              description="Start JMeter on the remote machine. Results stream to PerfHub in real-time with live metrics, SLA checks, and full analysis."
              code={`jmeter -n -t test-plan.jmx \\
  -l results.jtl`}
            />
          </div>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Network className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                Multi-Node Distributed Testing
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 p-4 rounded-xl bg-muted/30 border border-border/50">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-4 w-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-foreground">Same Execution ID</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Configure all JMeter nodes with the same execution ID to merge results into a single unified view.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex-1 p-4 rounded-xl bg-muted/30 border border-border/50">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-4 w-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-foreground">Unique Node IDs</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Assign each machine a distinct nodeId (e.g. node-1, node-2) for identification in logs.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex-1 p-4 rounded-xl bg-muted/30 border border-border/50">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-4 w-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-foreground">Unified Metrics</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Throughput, percentiles (t-digest), and error rates aggregate across all nodes automatically.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-amber-200 dark:border-amber-500/20">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Zap className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                Performance Tuning
              </CardTitle>
              <CardDescription>
                The Backend Listener adds CPU and memory overhead to JMeter. Tune these settings to minimize impact on your load test accuracy.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="rounded-xl border bg-muted/20 overflow-hidden">
                <div className="bg-muted/40 px-4 py-2.5 border-b">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Recommended Settings by Load Level</p>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-muted/10">
                        <th className="text-left py-2.5 px-4 font-semibold text-xs uppercase tracking-wider">Setting</th>
                        <th className="text-center py-2.5 px-4 font-semibold text-xs uppercase tracking-wider text-emerald-600">Light (&lt;100 TPS)</th>
                        <th className="text-center py-2.5 px-4 font-semibold text-xs uppercase tracking-wider text-blue-600">Medium (100-1K TPS)</th>
                        <th className="text-center py-2.5 px-4 font-semibold text-xs uppercase tracking-wider text-amber-600">Heavy (1K-5K TPS)</th>
                        <th className="text-center py-2.5 px-4 font-semibold text-xs uppercase tracking-wider text-red-600">Extreme (&gt;5K TPS)</th>
                      </tr>
                    </thead>
                    <tbody className="font-mono text-xs">
                      <tr className="border-b">
                        <td className="py-2 px-4 font-medium font-sans">batchSize</td>
                        <td className="py-2 px-4 text-center">100</td>
                        <td className="py-2 px-4 text-center">500</td>
                        <td className="py-2 px-4 text-center">2,000</td>
                        <td className="py-2 px-4 text-center">5,000</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 px-4 font-medium font-sans">flushIntervalMs</td>
                        <td className="py-2 px-4 text-center">3,000</td>
                        <td className="py-2 px-4 text-center">5,000</td>
                        <td className="py-2 px-4 text-center">10,000</td>
                        <td className="py-2 px-4 text-center">15,000</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 px-4 font-medium font-sans">gzipEnabled</td>
                        <td className="py-2 px-4 text-center">optional</td>
                        <td className="py-2 px-4 text-center">true</td>
                        <td className="py-2 px-4 text-center">true</td>
                        <td className="py-2 px-4 text-center">true</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 px-4 font-medium font-sans">collectSystemMetrics</td>
                        <td className="py-2 px-4 text-center">true</td>
                        <td className="py-2 px-4 text-center">true</td>
                        <td className="py-2 px-4 text-center">optional</td>
                        <td className="py-2 px-4 text-center">false</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-4 font-medium font-sans">HTTP calls / min</td>
                        <td className="py-2 px-4 text-center text-emerald-600 font-sans">~20</td>
                        <td className="py-2 px-4 text-center text-blue-600 font-sans">~12</td>
                        <td className="py-2 px-4 text-center text-amber-600 font-sans">~6</td>
                        <td className="py-2 px-4 text-center text-red-600 font-sans">~4</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-muted/30 border border-border/50 space-y-2">
                  <h4 className="text-sm font-semibold flex items-center gap-2">
                    <Cpu className="h-4 w-4 text-blue-500" />
                    Reducing CPU Overhead
                  </h4>
                  <ul className="text-xs text-muted-foreground space-y-1.5 leading-relaxed">
                    <li className="flex items-start gap-2"><ArrowRight className="h-3 w-3 mt-0.5 shrink-0 text-blue-400" />Increase <code className="px-1 bg-muted rounded text-[11px]">batchSize</code> to reduce HTTP call frequency</li>
                    <li className="flex items-start gap-2"><ArrowRight className="h-3 w-3 mt-0.5 shrink-0 text-blue-400" />Increase <code className="px-1 bg-muted rounded text-[11px]">flushIntervalMs</code> to buffer more samples between sends</li>
                    <li className="flex items-start gap-2"><ArrowRight className="h-3 w-3 mt-0.5 shrink-0 text-blue-400" />Enable <code className="px-1 bg-muted rounded text-[11px]">gzipEnabled=true</code> — compresses payloads 80-90%, reducing network I/O</li>
                    <li className="flex items-start gap-2"><ArrowRight className="h-3 w-3 mt-0.5 shrink-0 text-blue-400" />Disable <code className="px-1 bg-muted rounded text-[11px]">collectSystemMetrics</code> if CPU/memory charts aren't needed</li>
                  </ul>
                </div>
                <div className="p-4 rounded-xl bg-muted/30 border border-border/50 space-y-2">
                  <h4 className="text-sm font-semibold flex items-center gap-2">
                    <HardDrive className="h-4 w-4 text-purple-500" />
                    Reducing Memory Usage
                  </h4>
                  <ul className="text-xs text-muted-foreground space-y-1.5 leading-relaxed">
                    <li className="flex items-start gap-2"><ArrowRight className="h-3 w-3 mt-0.5 shrink-0 text-purple-400" />Larger batch sizes use more buffer memory — find a balance for your heap</li>
                    <li className="flex items-start gap-2"><ArrowRight className="h-3 w-3 mt-0.5 shrink-0 text-purple-400" />Increase JMeter heap: <code className="px-1 bg-muted rounded text-[11px]">JVM_ARGS="-Xms2g -Xmx4g"</code></li>
                    <li className="flex items-start gap-2"><ArrowRight className="h-3 w-3 mt-0.5 shrink-0 text-purple-400" />For extreme loads, use multiple JMeter nodes with same <code className="px-1 bg-muted rounded text-[11px]">runId</code></li>
                    <li className="flex items-start gap-2"><ArrowRight className="h-3 w-3 mt-0.5 shrink-0 text-purple-400" />Ensure JMeter runs in non-GUI mode: <code className="px-1 bg-muted rounded text-[11px]">jmeter -n -t test.jmx</code></li>
                  </ul>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-500/15 space-y-2">
                <h4 className="text-sm font-semibold flex items-center gap-2">
                  <Terminal className="h-4 w-4 text-blue-500" />
                  High-Performance Example (1,000+ TPS)
                </h4>
                <pre className="bg-slate-900 p-3 rounded-lg text-xs text-emerald-400 overflow-x-auto border border-slate-700 font-mono">{`perfhub.url=https://<your-perfhub>/api/ingest/samples
perfhub.token=phi_<your-token>
perfhub.batchSize=2000
perfhub.flushIntervalMs=10000
perfhub.gzipEnabled=true
perfhub.collectSystemMetrics=false
perfhub.connectionTimeoutMs=10000
perfhub.socketTimeoutMs=30000

# JMeter JVM tuning
JVM_ARGS="-Xms2g -Xmx4g -XX:+UseG1GC"
jmeter -n -t test.jmx -l results.jtl`}</pre>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  With batchSize=2000 and flushIntervalMs=10000, the plugin sends ~6 HTTP requests per minute instead of ~30.
                  Gzip compression reduces payload size by 80-90%. Live metrics update every 10 seconds on the dashboard.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api" className="space-y-4">
          <Card>
            <CardHeader className="border-b pb-4">
              <CardTitle className="text-lg">Ingestion API</CardTitle>
              <CardDescription>REST endpoints for streaming JMeter results into PerfHub</CardDescription>
            </CardHeader>
            <CardContent className="pt-5 space-y-6">
              <ApiEndpoint
                method="POST"
                path="/api/ingest/samples"
                description="Stream a batch of JMeter sample results. Supports gzip Content-Encoding for efficient transport."
                headers={[
                  { key: "Authorization", value: "Bearer phi_<token>" },
                  { key: "Content-Type", value: "application/json" },
                  { key: "Content-Encoding", value: "gzip (optional)" },
                ]}
                body={`{
  "runId": "run_abc123",
  "testName": "My Load Test",
  "nodeId": "node-1",
  "samples": [
    {
      "timestamp": 1707849600000,
      "elapsed": 245,
      "label": "HTTP Request",
      "responseCode": "200",
      "success": true,
      "allThreads": 50,
      "responseMessage": "OK"
    }
  ]
}`}
                responses={[
                  { code: 202, description: "Samples accepted, returns executionId" },
                  { code: 401, description: "Invalid or revoked token" },
                  { code: 413, description: "Payload exceeds 5MB limit" },
                  { code: 409, description: "Execution not accepting samples" },
                ]}
              />

              <ApiEndpoint
                method="POST"
                path="/api/ingest/complete"
                description="Signal that a remote test run has completed. Stops the live metrics stream and finalizes the execution."
                headers={[
                  { key: "Authorization", value: "Bearer phi_<token>" },
                  { key: "Content-Type", value: "application/json" },
                ]}
                body={`{
  "runId": "run_abc123"
}`}
                responses={[
                  { code: 200, description: "Completion acknowledged, returns executionId" },
                  { code: 401, description: "Invalid or revoked token" },
                  { code: 404, description: "No execution found for runId" },
                ]}
              />

              <ApiEndpoint
                method="POST"
                path="/api/admin/remote-execution"
                description="Optionally pre-create an execution entry. Not required — the ingest API auto-creates executions from the runId if none exists."
                headers={[
                  { key: "Cookie", value: "<session cookie>" },
                  { key: "Content-Type", value: "application/json" },
                ]}
                body={`{
  "name": "Remote Load Test",
  "scheduleId": 1
}`}
                responses={[
                  { code: 200, description: "Execution created with ID" },
                  { code: 400, description: "Missing required fields" },
                ]}
                requiresAdmin
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function StepCard({
  step,
  icon,
  title,
  description,
  code,
}: {
  step: number;
  icon: React.ReactNode;
  title: string;
  description: string;
  code: string;
}) {
  return (
    <Card className="hover:border-primary/40 transition-colors">
      <CardContent className="pt-5 pb-5 space-y-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-7 h-7 rounded-lg bg-primary/10 border border-primary/20 text-xs font-bold text-primary">
            {step}
          </div>
          <div className="p-1.5 rounded-lg text-blue-600 dark:text-blue-400">
            {icon}
          </div>
          <h4 className="text-sm font-semibold text-foreground">{title}</h4>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
        <pre className="bg-slate-900 p-3 rounded-lg text-xs text-emerald-400 overflow-x-auto border border-slate-700 font-mono">
          {code}
        </pre>
      </CardContent>
    </Card>
  );
}

function ApiEndpoint({
  method,
  path,
  description,
  headers,
  body,
  responses,
  requiresAdmin,
}: {
  method: string;
  path: string;
  description: string;
  headers: { key: string; value: string }[];
  body: string;
  responses: { code: number; description: string }[];
  requiresAdmin?: boolean;
}) {
  return (
    <div className="p-5 rounded-xl border border-border/50 bg-muted/20 space-y-4">
      <div className="flex items-center gap-3 flex-wrap">
        <span className="px-2.5 py-1 rounded-md bg-primary/10 border border-primary/20 text-xs font-bold text-primary tracking-wide">
          {method}
        </span>
        <code className="text-sm font-mono text-foreground">{path}</code>
        {requiresAdmin && (
          <Badge className="bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-500/20 text-[10px]">
            ADMIN
          </Badge>
        )}
      </div>
      <p className="text-sm text-muted-foreground">{description}</p>

      <div className="space-y-1">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Headers</p>
        <div className="bg-muted/40 rounded-lg border border-border/50 divide-y divide-border/50">
          {headers.map((h) => (
            <div key={h.key} className="flex items-center px-3 py-2 text-xs font-mono">
              <span className="text-primary w-40 flex-shrink-0">{h.key}</span>
              <span className="text-muted-foreground">{h.value}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-1">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Request Body</p>
        <pre className="bg-slate-900 p-3 rounded-lg text-xs text-emerald-400 overflow-x-auto border border-slate-700 font-mono">
          {body}
        </pre>
      </div>

      <div className="space-y-1">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Responses</p>
        <div className="flex flex-wrap gap-2">
          {responses.map((r) => (
            <div
              key={r.code}
              className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border text-xs ${
                r.code >= 200 && r.code < 300
                  ? "bg-emerald-50 dark:bg-emerald-500/5 border-emerald-200 dark:border-emerald-500/20 text-emerald-700 dark:text-emerald-400"
                  : "bg-red-50 dark:bg-red-500/5 border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400"
              }`}
            >
              <span className="font-bold font-mono">{r.code}</span>
              <span className="text-muted-foreground">{r.description}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
