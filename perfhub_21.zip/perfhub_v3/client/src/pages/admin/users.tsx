import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { EmptyState } from "@/components/empty-state";

import { format } from "date-fns";
import { Check, X, UserCog, Clock, Users, Shield, Loader2, Trash2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { queryKeys } from "@/lib/query-keys";

interface User {
  id: number;
  username: string;
  email: string | null;
  role: string;
  isApproved: boolean;
  createdAt: string;
}

export default function AdminUsersPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser } = useAuth();
  const [pendingApproveIds, setPendingApproveIds] = useState<Set<number>>(new Set());
  const [pendingDeleteIds, setPendingDeleteIds] = useState<Set<number>>(new Set());

  const { data: allUsers = [], isLoading: loadingAll, isError: isErrorAll, error: errorAll, refetch: refetchAll } = useQuery<User[]>({
    queryKey: [...queryKeys.admin.users],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/admin/users");
      return res.json();
    },
  });

  const { data: pendingUsers = [], isLoading: loadingPending, isError: isErrorPending, error: errorPending, refetch: refetchPending } = useQuery<User[]>({
    queryKey: [...queryKeys.admin.pendingUsers],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/admin/pending-users");
      return res.json();
    },
  });

  const approveMutation = useMutation({
    mutationFn: async (userId: number) => {
      setPendingApproveIds(prev => new Set(prev).add(userId));
      const res = await apiRequest("POST", `/api/admin/users/${userId}/approve`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "User approved", description: "The user can now access the application." });
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.users });
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.pendingUsers });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to approve user", variant: "destructive" });
    },
    onSettled: (_data, _error, userId) => {
      setPendingApproveIds(prev => { const next = new Set(prev); next.delete(userId); return next; });
    },
  });

  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: number; role: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/role`, { role });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Role updated", description: "User role has been updated successfully." });
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.users });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (userId: number) => {
      setPendingDeleteIds(prev => new Set(prev).add(userId));
      const res = await apiRequest("DELETE", `/api/admin/users/${userId}`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "User deleted", description: "The user has been removed from the system." });
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.users });
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.pendingUsers });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
    onSettled: (_data, _error, userId) => {
      setPendingDeleteIds(prev => { const next = new Set(prev); next.delete(userId); return next; });
    },
  });

  if (isErrorAll) return <QueryErrorFallback error={errorAll} onRetry={refetchAll} title="Failed to load users" />;
  if (isErrorPending) return <QueryErrorFallback error={errorPending} onRetry={refetchPending} title="Failed to load pending users" />;

  const approvedUsers = allUsers.filter(u => u.isApproved);

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case "admin": return "default";
      case "lead": return "default";
      case "manager": return "secondary";
      case "viewer": return "outline";
      default: return "outline";
    }
  };

  const getRoleBorderColor = (role: string) => {
    switch (role) {
      case "admin": return "border-l-purple-500";
      case "lead": return "border-l-indigo-500";
      case "manager": return "border-l-green-500";
      case "viewer": return "border-l-gray-400";
      default: return "border-l-blue-500";
    }
  };

  const isSelf = (userId: number) => currentUser?.id === userId;

  const UserCard = ({ user, showApproveButton = false, index = 0 }: { user: User; showApproveButton?: boolean; index?: number }) => (
    <Card
      className={`mb-4 border-l-4 ${getRoleBorderColor(user.role)} transition-all duration-200 hover:shadow-md`}
      style={{ animation: `fadeSlideIn 0.3s ease-out ${index * 0.05}s both` }}
    >
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
              {user.username.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-lg">{user.username}</h3>
                <Badge variant={getRoleBadgeVariant(user.role)}>{user.role}</Badge>
                {!user.isApproved && <Badge variant="outline" className="text-orange-500 border-orange-500">Pending</Badge>}
                {isSelf(user.id) && <Badge variant="outline" className="text-blue-500 border-blue-500">You</Badge>}
              </div>
              <p className="text-sm text-muted-foreground">
                {user.email || "No email provided"}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Joined {format(new Date(user.createdAt), "MMM d, yyyy 'at' h:mm a")}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {showApproveButton ? (
              <>
                <Button 
                  onClick={() => approveMutation.mutate(user.id)}
                  disabled={pendingApproveIds.has(user.id)}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {pendingApproveIds.has(user.id) ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Approve
                    </>
                  )}
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="icon">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Reject User Request</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently delete the signup request for "{user.username}". This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => deleteMutation.mutate(user.id)}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        {pendingDeleteIds.has(user.id) ? <Loader2 className="h-4 w-4 animate-spin" /> : "Delete"}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </>
            ) : isSelf(user.id) ? (
              <Badge variant="outline" className="text-muted-foreground">Current session</Badge>
            ) : (
              <>
                <Select
                  defaultValue={user.role}
                  onValueChange={(role) => updateRoleMutation.mutate({ userId: user.id, role })}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="viewer">Viewer</SelectItem>
                    <SelectItem value="engineer">Engineer</SelectItem>
                    <SelectItem value="lead">Lead</SelectItem>
                    <SelectItem value="manager">Manager</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete User</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently delete the user "{user.username}" and all their associated data. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => deleteMutation.mutate(user.id)}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        {pendingDeleteIds.has(user.id) ? <Loader2 className="h-4 w-4 animate-spin" /> : "Delete"}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="transition-all duration-200 hover:shadow-lg hover:shadow-blue-500/5">
          <CardHeader className="pb-2">
            <CardDescription>Total Users</CardDescription>
            <CardTitle className="text-3xl flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 shadow-lg">
                <Users className="h-5 w-5 text-white" />
              </div>
              {allUsers.length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card className="transition-all duration-200 hover:shadow-lg hover:shadow-orange-500/5">
          <CardHeader className="pb-2">
            <CardDescription>Pending Approval</CardDescription>
            <CardTitle className="text-3xl flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 shadow-lg">
                <Clock className="h-5 w-5 text-white" />
              </div>
              {pendingUsers.length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card className="transition-all duration-200 hover:shadow-lg hover:shadow-purple-500/5">
          <CardHeader className="pb-2">
            <CardDescription>Administrators</CardDescription>
            <CardTitle className="text-3xl flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-purple-500 to-violet-500 shadow-lg">
                <Shield className="h-5 w-5 text-white" />
              </div>
              {allUsers.filter(u => u.role === "admin").length}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="pending" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Pending Requests
            {pendingUsers.length > 0 && (
              <Badge variant="destructive" className="ml-1">{pendingUsers.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="all" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            All Users
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending">
          {loadingPending ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="mb-4 border-l-4 border-l-muted">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Skeleton className="w-12 h-12 rounded-full" />
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Skeleton className="h-5 w-32" />
                            <Skeleton className="h-5 w-16 rounded-full" />
                          </div>
                          <Skeleton className="h-4 w-40" />
                          <Skeleton className="h-3 w-36" />
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Skeleton className="h-9 w-24 rounded-md" />
                        <Skeleton className="h-9 w-9 rounded-md" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : pendingUsers.length === 0 ? (
            <EmptyState
              icon={Clock}
              title="No pending requests"
              description="All user access requests have been processed."
            />
          ) : (
            pendingUsers.map((user, index) => (
              <UserCard key={user.id} user={user} showApproveButton index={index} />
            ))
          )}
        </TabsContent>

        <TabsContent value="all">
          {loadingAll ? (
            <div className="space-y-4">
              {[...Array(4)].map((_, i) => (
                <Card key={i} className="mb-4 border-l-4 border-l-muted">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Skeleton className="w-12 h-12 rounded-full" />
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Skeleton className="h-5 w-32" />
                            <Skeleton className="h-5 w-16 rounded-full" />
                          </div>
                          <Skeleton className="h-4 w-40" />
                          <Skeleton className="h-3 w-36" />
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Skeleton className="h-9 w-32 rounded-md" />
                        <Skeleton className="h-9 w-9 rounded-md" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : approvedUsers.length === 0 ? (
            <EmptyState
              icon={Users}
              title="No users yet"
              description="Users will appear here once they sign up and are approved."
            />
          ) : (
            approvedUsers.map((user, index) => (
              <UserCard key={user.id} user={user} index={index} />
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
