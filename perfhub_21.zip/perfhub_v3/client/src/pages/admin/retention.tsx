import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "@/lib/query-keys";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { Skeleton } from "@/components/ui/skeleton";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Database, Trash2, Shield, Clock, AlertTriangle, CheckCircle2,
  Loader2, History, Eye, Settings2, Archive, FileText, Bell, ScrollText,
  HardDrive, RefreshCw, Pin
} from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";

interface CategoryOverview {
  category: string;
  label: string;
  description: string;
  totalCount: number;
  oldestRecordDate: string | null;
  beyondRetentionCount: number;
  pinnedCount?: number;
  retentionDays: number;
}

interface PreviewResult {
  category: string;
  thresholdDays: number;
  recordsToDelete: number;
  pinnedExcluded: number;
  sampleIds: number[];
  cutoffDate: string;
}

interface CleanupRecord {
  id: number;
  category: string;
  thresholdDays: number;
  deletedCount: number | null;
  status: string;
  initiatedBy: number;
  startedAt: string;
  completedAt: string | null;
  notes: string | null;
}

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  executions: <Archive className="h-5 w-5" />,
  notifications: <Bell className="h-5 w-5" />,
  auditLogs: <ScrollText className="h-5 w-5" />,
  reports: <FileText className="h-5 w-5" />,
  dumpFiles: <HardDrive className="h-5 w-5" />,
};

const CATEGORY_COLORS: Record<string, string> = {
  executions: "from-blue-500/20 to-blue-600/10 border-blue-500/30",
  notifications: "from-amber-500/20 to-amber-600/10 border-amber-500/30",
  auditLogs: "from-green-500/20 to-green-600/10 border-green-500/30",
  reports: "from-purple-500/20 to-purple-600/10 border-purple-500/30",
  dumpFiles: "from-red-500/20 to-red-600/10 border-red-500/30",
};

const CATEGORY_ICON_COLORS: Record<string, string> = {
  executions: "text-blue-500",
  notifications: "text-amber-500",
  auditLogs: "text-green-500",
  reports: "text-purple-500",
  dumpFiles: "text-red-500",
};

export default function AdminRetention() {
  return (
    <div className="space-y-6">
      <RetentionOverviewSection />
      <RetentionSettingsSection />
      <CleanupHistorySection />
    </div>
  );
}

function RetentionOverviewSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [previewData, setPreviewData] = useState<PreviewResult | null>(null);
  const [cleanupCategory, setCleanupCategory] = useState<string | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);

  const { data: overview, isLoading, isError, error, refetch } = useQuery<CategoryOverview[]>({
    queryKey: [...queryKeys.admin.retentionOverview],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/retention/overview");
      return res.json();
    },
  });

  const previewMutation = useMutation({
    mutationFn: async (category: string) => {
      const res = await apiRequest("POST", `/api/retention/${category}/preview`);
      return res.json();
    },
    onSuccess: (data: PreviewResult) => {
      setPreviewData(data);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to generate cleanup preview", variant: "destructive" });
    },
  });

  const cleanupMutation = useMutation({
    mutationFn: async (category: string) => {
      const res = await apiRequest("POST", `/api/retention/${category}/cleanup`);
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Cleanup Complete", description: `Deleted ${data.deletedCount} ${data.category} records` });
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.retentionOverview });
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.retentionHistory });
      setPreviewData(null);
      setShowConfirmDialog(false);
      setCleanupCategory(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Cleanup operation failed", variant: "destructive" });
      setShowConfirmDialog(false);
    },
  });

  const handlePreview = (category: string) => {
    previewMutation.mutate(category);
  };

  const handleCleanup = (category: string) => {
    setCleanupCategory(category);
    setShowConfirmDialog(true);
  };

  const confirmCleanup = () => {
    if (cleanupCategory) {
      cleanupMutation.mutate(cleanupCategory);
    }
  };

  if (isError) {
    return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load retention overview" />;
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <Skeleton className="h-6 w-40" />
              <Skeleton className="h-4 w-72 mt-2" />
            </div>
            <Skeleton className="h-9 w-24" />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="rounded-lg border p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <Skeleton className="h-5 w-5 mt-0.5" />
                  <div>
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-48 mt-1" />
                    <div className="flex items-center gap-4 mt-2">
                      <Skeleton className="h-3 w-24" />
                      <Skeleton className="h-3 w-20" />
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Skeleton className="h-8 w-20" />
                  <Skeleton className="h-8 w-24" />
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-primary" />
                Storage Overview
              </CardTitle>
              <CardDescription>Review data categories and clean up old records</CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => queryClient.invalidateQueries({ queryKey: queryKeys.admin.retentionOverview })}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {overview?.map((cat) => (
            <div
              key={cat.category}
              className={`rounded-lg border bg-gradient-to-r p-4 ${CATEGORY_COLORS[cat.category] || ""}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className={`mt-0.5 ${CATEGORY_ICON_COLORS[cat.category] || "text-muted-foreground"}`}>
                    {CATEGORY_ICONS[cat.category]}
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm">{cat.label}</h4>
                    <p className="text-xs text-muted-foreground mt-0.5">{cat.description}</p>
                    <div className="flex items-center gap-4 mt-2 flex-wrap">
                      <div className="flex items-center gap-1.5 text-xs">
                        <Archive className="h-3 w-3" />
                        <span className="font-medium">{cat.totalCount.toLocaleString()}</span>
                        <span className="text-muted-foreground">total records</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs">
                        <Clock className="h-3 w-3" />
                        <span className="font-medium">{cat.retentionDays}d</span>
                        <span className="text-muted-foreground">retention</span>
                      </div>
                      {cat.oldestRecordDate && (
                        <div className="flex items-center gap-1.5 text-xs">
                          <History className="h-3 w-3" />
                          <span className="text-muted-foreground">Oldest:</span>
                          <span className="font-medium">
                            {formatDistanceToNow(new Date(cat.oldestRecordDate), { addSuffix: true })}
                          </span>
                        </div>
                      )}
                      {(cat.pinnedCount ?? 0) > 0 && (
                        <div className="flex items-center gap-1.5 text-xs">
                          <Pin className="h-3 w-3" />
                          <span className="font-medium">{cat.pinnedCount}</span>
                          <span className="text-muted-foreground">pinned</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {cat.beyondRetentionCount > 0 && (
                    <Badge variant="destructive" className="text-xs">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      {cat.beyondRetentionCount} eligible
                    </Badge>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePreview(cat.category)}
                    disabled={previewMutation.isPending}
                  >
                    {previewMutation.isPending && previewMutation.variables === cat.category ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" />
                    ) : (
                      <Eye className="h-3.5 w-3.5 mr-1" />
                    )}
                    Preview
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleCleanup(cat.category)}
                    disabled={cat.beyondRetentionCount === 0 || cleanupMutation.isPending}
                  >
                    <Trash2 className="h-3.5 w-3.5 mr-1" />
                    Clean Up
                  </Button>
                </div>
              </div>

              {previewData && previewData.category === cat.category && (
                <>
                  <Separator className="my-3" />
                  <div className="bg-background/60 rounded-md p-3 space-y-2">
                    <h5 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      Cleanup Preview
                    </h5>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div>
                        <p className="text-xs text-muted-foreground">Records to Delete</p>
                        <p className="text-lg font-bold text-destructive">{previewData.recordsToDelete}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Retention Threshold</p>
                        <p className="text-lg font-bold">{previewData.thresholdDays} days</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Cutoff Date</p>
                        <p className="text-sm font-medium">{format(new Date(previewData.cutoffDate), "MMM d, yyyy")}</p>
                      </div>
                      {previewData.pinnedExcluded > 0 && (
                        <div>
                          <p className="text-xs text-muted-foreground">Pinned (Excluded)</p>
                          <p className="text-lg font-bold text-amber-500">{previewData.pinnedExcluded}</p>
                        </div>
                      )}
                    </div>
                    {previewData.sampleIds.length > 0 && (
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Sample IDs to be deleted:</p>
                        <div className="flex flex-wrap gap-1">
                          {previewData.sampleIds.map((id) => (
                            <Badge key={id} variant="secondary" className="text-xs font-mono">
                              #{id}
                            </Badge>
                          ))}
                          {previewData.recordsToDelete > previewData.sampleIds.length && (
                            <Badge variant="secondary" className="text-xs">
                              +{previewData.recordsToDelete - previewData.sampleIds.length} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          ))}

          {(!overview || overview.length === 0) && (
            <div className="text-center py-8 text-muted-foreground">
              <Database className="h-10 w-10 mx-auto mb-2 opacity-40" />
              <p>No data categories found</p>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Confirm Data Cleanup
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete records older than the retention threshold
              for <strong>{cleanupCategory}</strong>. Pinned records will be excluded.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmCleanup}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={cleanupMutation.isPending}
            >
              {cleanupMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Trash2 className="h-4 w-4 mr-2" />
              )}
              Delete Records
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function RetentionSettingsSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");

  const { data: settings, isLoading, isError, error, refetch } = useQuery<Array<{ settingKey: string; settingValue: number }>>({
    queryKey: [...queryKeys.admin.retentionSettings],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/settings/retention");
      return res.json();
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ key, value }: { key: string; value: number }) => {
      const res = await apiRequest("PUT", `/api/settings/retention/${key}`, { value });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Updated", description: "Retention setting saved" });
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.retentionSettings });
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.retentionOverview });
      setEditingKey(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update setting", variant: "destructive" });
    },
  });

  const defaults: Record<string, { label: string; defaultDays: number }> = {
    executions: { label: "Test Executions", defaultDays: 90 },
    notifications: { label: "Notifications", defaultDays: 30 },
    auditLogs: { label: "Audit Logs", defaultDays: 365 },
    reports: { label: "Completion Reports", defaultDays: 180 },
    dumpFiles: { label: "Dump Files", defaultDays: 60 },
  };

  const settingsMap: Record<string, number> = {};
  settings?.forEach((s) => { settingsMap[s.settingKey] = s.settingValue; });

  const startEdit = (key: string) => {
    setEditingKey(key);
    setEditValue(String(settingsMap[key] || defaults[key]?.defaultDays || 90));
  };

  const saveEdit = () => {
    if (editingKey) {
      const val = parseInt(editValue, 10);
      if (isNaN(val) || val < 1) {
        toast({ title: "Invalid", description: "Value must be a positive number", variant: "destructive" });
        return;
      }
      updateMutation.mutate({ key: editingKey, value: val });
    }
  };

  if (isError) {
    return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load retention settings" />;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings2 className="h-5 w-5 text-primary" />
          Retention Thresholds
        </CardTitle>
        <CardDescription>
          Configure how long data is kept before becoming eligible for cleanup
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-5 w-5" />
                  <div>
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-24 mt-1" />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Skeleton className="h-6 w-14 rounded-full" />
                  <Skeleton className="h-8 w-12" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {Object.entries(defaults).map(([key, { label, defaultDays }]) => {
              const currentDays = settingsMap[key] || defaultDays;
              const isEditing = editingKey === key;

              return (
                <div
                  key={key}
                  className="flex items-center justify-between p-3 rounded-lg border bg-muted/30 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={CATEGORY_ICON_COLORS[key]}>
                      {CATEGORY_ICONS[key]}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{label}</p>
                      <p className="text-xs text-muted-foreground">
                        Default: {defaultDays} days
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {isEditing ? (
                      <>
                        <Input
                          type="number"
                          min={1}
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          className="w-24 h-8 text-sm"
                          onKeyDown={(e) => {
                            if (e.key === "Enter") saveEdit();
                            if (e.key === "Escape") setEditingKey(null);
                          }}
                          autoFocus
                        />
                        <span className="text-xs text-muted-foreground">days</span>
                        <Button
                          size="sm"
                          variant="default"
                          onClick={saveEdit}
                          disabled={updateMutation.isPending}
                          className="h-8"
                        >
                          {updateMutation.isPending ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <CheckCircle2 className="h-3.5 w-3.5" />
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setEditingKey(null)}
                          className="h-8"
                        >
                          Cancel
                        </Button>
                      </>
                    ) : (
                      <>
                        <Badge variant="secondary" className="text-sm font-mono px-3">
                          {currentDays}d
                        </Badge>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => startEdit(key)}
                          className="h-8"
                        >
                          Edit
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function CleanupHistorySection() {
  const { data, isLoading, isError, error, refetch } = useQuery<{ records: CleanupRecord[]; total: number }>({
    queryKey: [...queryKeys.admin.retentionHistory],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/retention/history?limit=20");
      return res.json();
    },
  });

  const statusConfig: Record<string, { icon: React.ReactNode; color: string }> = {
    completed: { icon: <CheckCircle2 className="h-3.5 w-3.5" />, color: "text-green-500" },
    running: { icon: <Loader2 className="h-3.5 w-3.5 animate-spin" />, color: "text-blue-500" },
    failed: { icon: <AlertTriangle className="h-3.5 w-3.5" />, color: "text-red-500" },
  };

  const categoryLabels: Record<string, string> = {
    executions: "Test Executions",
    notifications: "Notifications",
    auditLogs: "Audit Logs",
    reports: "Completion Reports",
    dumpFiles: "Dump Files",
  };

  if (isError) {
    return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load cleanup history" />;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <History className="h-5 w-5 text-primary" />
          Cleanup History
        </CardTitle>
        <CardDescription>Past data cleanup operations and their results</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-4 w-4 rounded-full" />
                  <div>
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-40 mt-1" />
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Skeleton className="h-5 w-20 rounded-full" />
                  <Skeleton className="h-5 w-20 rounded-full" />
                </div>
              </div>
            ))}
          </div>
        ) : data?.records && data.records.length > 0 ? (
          <div className="space-y-2">
            {data.records.map((record) => {
              const sc = statusConfig[record.status] || statusConfig.failed;
              return (
                <div
                  key={record.id}
                  className="flex items-center justify-between p-3 rounded-lg border bg-muted/20"
                >
                  <div className="flex items-center gap-3">
                    <div className={sc.color}>{sc.icon}</div>
                    <div>
                      <p className="text-sm font-medium">
                        {categoryLabels[record.category] || record.category}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {record.startedAt
                          ? formatDistanceToNow(new Date(record.startedAt), { addSuffix: true })
                          : "Unknown"}
                        {" · "}Threshold: {record.thresholdDays}d
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {record.deletedCount !== null && (
                      <Badge variant={record.deletedCount > 0 ? "destructive" : "secondary"} className="text-xs">
                        {record.deletedCount} deleted
                      </Badge>
                    )}
                    <Badge
                      variant="outline"
                      className={`text-xs capitalize ${sc.color}`}
                    >
                      {record.status}
                    </Badge>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <Shield className="h-10 w-10 mx-auto mb-2 opacity-40" />
            <p className="text-sm">No cleanup operations have been performed yet</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
