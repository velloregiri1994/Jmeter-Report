import { useState, useEffect, lazy, Suspense } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "@/lib/query-keys";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Settings, Mail, XCircle, Send, Loader2, CheckCircle2, AlertTriangle,
  Clock, RefreshCw, Users, Network, Database, ChevronRight
} from "lucide-react";
import { useLocation } from "wouter";
import AdminUsersPage from "./users";
import IngestTokensPage from "./ingest-tokens";
import AdminRetention from "./retention";
import { cn } from "@/lib/utils";

const sections = [
  { id: "general", label: "General", icon: Mail, description: "Email & SMTP configuration" },
  { id: "users", label: "Users", icon: Users, description: "Manage user accounts & roles" },
  { id: "distributed", label: "Distributed Testing", icon: Network, description: "Ingest tokens & remote agents" },
  { id: "retention", label: "Data Retention", icon: Database, description: "Cleanup & storage policies" },
] as const;

type SectionId = typeof sections[number]["id"];

function getSectionFromHash(): SectionId {
  if (typeof window !== "undefined") {
    const hash = window.location.hash.replace("#", "");
    if (sections.some(s => s.id === hash)) return hash as SectionId;
  }
  return "general";
}

export { EmailSettingsCard, EmailLogsCard };

export default function AdminSettings({ embedded, section }: { embedded?: boolean; section?: SectionId } = {}) {
  const [activeSection, setActiveSection] = useState<SectionId>(embedded ? "general" : getSectionFromHash());

  const handleSectionChange = (id: SectionId) => {
    setActiveSection(id);
    if (!embedded && typeof window !== "undefined") {
      window.history.replaceState(null, "", `#${id}`);
    }
  };

  useEffect(() => {
    if (embedded) return;
    const onHashChange = () => setActiveSection(getSectionFromHash());
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, [embedded]);

  const active = sections.find(s => s.id === activeSection)!;

  const navContent = (
    <div className={cn("flex gap-1.5 overflow-x-auto pb-2", embedded ? "flex-row" : "lg:flex-col lg:overflow-visible lg:pb-0")}>
      {sections.map((section) => {
        const Icon = section.icon;
        const isActive = activeSection === section.id;
        return (
          <button
            key={section.id}
            onClick={() => handleSectionChange(section.id)}
            className={cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-200 whitespace-nowrap w-full min-w-fit",
              !embedded && "lg:whitespace-normal",
              isActive
                ? "bg-primary text-primary-foreground shadow-sm"
                : "hover:bg-muted/60 text-muted-foreground hover:text-foreground"
            )}
          >
            <div className={cn(
              "p-1.5 rounded-md shrink-0",
              isActive ? "bg-primary-foreground/20" : "bg-muted"
            )}>
              <Icon className="w-4 h-4" />
            </div>
            {!embedded && (
              <div className="hidden lg:block min-w-0">
                <div className="text-sm font-medium">{section.label}</div>
                <div className={cn(
                  "text-[11px] truncate",
                  isActive ? "text-primary-foreground/70" : "text-muted-foreground"
                )}>
                  {section.description}
                </div>
              </div>
            )}
            <span className={cn(embedded ? "text-sm font-medium" : "lg:hidden text-sm font-medium")}>{section.label}</span>
            {!embedded && (
              <ChevronRight className={cn(
                "w-4 h-4 ml-auto hidden lg:block shrink-0",
                isActive ? "text-primary-foreground/70" : "text-muted-foreground/40"
              )} />
            )}
          </button>
        );
      })}
    </div>
  );

  const contentPanel = (
    <div
      key={activeSection}
      className="animate-in fade-in slide-in-from-right-4 duration-300"
    >
      {activeSection === "general" && (
        <div className="space-y-6">
          <EmailSettingsCard />
          <EmailLogsCard />
        </div>
      )}
      {activeSection === "users" && <AdminUsersPage />}
      {activeSection === "distributed" && <IngestTokensPage />}
      {activeSection === "retention" && <AdminRetention />}
    </div>
  );

  if (embedded) {
    return (
      <div className="space-y-4">
        <nav>{navContent}</nav>
        {contentPanel}
      </div>
    );
  }

  return (
    <div className="section-gap">
      <PageHeader
        title="Settings"
        subtitle="Manage system configuration, users, and data policies"
      />

      <div className="flex flex-col lg:flex-row gap-6">
        <nav className="lg:w-64 shrink-0">
          {navContent}
        </nav>

        <div className="flex-1 min-w-0">
          {contentPanel}
        </div>
      </div>
    </div>
  );
}

function EmailSettingsCard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings, isLoading, isError, error, refetch } = useQuery({
    queryKey: [...queryKeys.admin.emailSettings],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/email-settings");
      return res.json();
    },
  });

  const [smtpHost, setSmtpHost] = useState("");
  const [smtpPort, setSmtpPort] = useState("587");
  const [senderEmail, setSenderEmail] = useState("");
  const [senderPassword, setSenderPassword] = useState("");
  const [enabled, setEnabled] = useState(false);
  const [defaultRecipients, setDefaultRecipients] = useState<string[]>([]);
  const [recipientInput, setRecipientInput] = useState("");
  const [testRecipient, setTestRecipient] = useState("");

  useEffect(() => {
    if (settings) {
      setSmtpHost(settings.smtpHost || "smtp.office365.com");
      setSmtpPort(String(settings.smtpPort || 587));
      setSenderEmail(settings.senderEmail || "");
      setSenderPassword(settings.senderPassword || "");
      setEnabled(settings.enabled ?? false);
      setDefaultRecipients(settings.defaultRecipients || []);
    }
  }, [settings]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/email-settings", {
        smtpHost,
        smtpPort: parseInt(smtpPort),
        senderEmail,
        senderPassword,
        defaultRecipients,
        enabled,
      });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(queryKeys.admin.emailSettings, data);
      setSenderPassword(data.senderPassword || "");
      toast({ title: "Saved", description: "Email settings updated successfully" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const testConnectionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/email-settings/test-connection");
      const data = await res.json();
      if (!data.success) throw new Error(data.error || "Connection failed");
      return data;
    },
    onSuccess: () => {
      toast({ title: "Connection Successful", description: "SMTP server is reachable" });
    },
    onError: (err: any) => {
      toast({ title: "Connection Failed", description: err.message, variant: "destructive" });
    },
  });

  const sendTestMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/email-settings/send-test", { recipientEmail: testRecipient });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || "Failed to send test email");
      return data;
    },
    onSuccess: () => {
      toast({ title: "Test Email Sent", description: `Check inbox for ${testRecipient}` });
      queryClient.invalidateQueries({ queryKey: queryKeys.admin.emailLogs });
    },
    onError: (err: any) => {
      toast({ title: "Send Failed", description: err.message, variant: "destructive" });
    },
  });

  const addRecipient = () => {
    const email = recipientInput.trim();
    if (email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && !defaultRecipients.includes(email)) {
      setDefaultRecipients([...defaultRecipients, email]);
      setRecipientInput("");
    }
  };

  const removeRecipient = (email: string) => {
    setDefaultRecipients(defaultRecipients.filter(r => r !== email));
  };

  if (isError) {
    return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load email settings" />;
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-64" />
          <Skeleton className="h-4 w-96 mt-2" />
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-3">
            <Skeleton className="h-6 w-10 rounded-full" />
            <Skeleton className="h-4 w-48" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-10 w-full" />
            </div>
            <div className="space-y-2">
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-10 w-full" />
            </div>
            <div className="space-y-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
          <div className="flex gap-2 pt-2">
            <Skeleton className="h-10 w-32" />
            <Skeleton className="h-10 w-40" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="transition-all duration-200 hover:shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 shadow">
            <Mail className="h-4 w-4 text-white" />
          </div>
          Email Notifications (SMTP)
        </CardTitle>
        <CardDescription>
          Configure Outlook / Microsoft 365 SMTP to send email alerts when tests complete
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center gap-3">
          <Switch checked={enabled} onCheckedChange={setEnabled} />
          <Label className="text-sm font-medium">Enable email notifications</Label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label className="text-sm">SMTP Host</Label>
            <Input
              value={smtpHost}
              onChange={(e) => setSmtpHost(e.target.value)}
              placeholder="smtp.office365.com"
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-sm">SMTP Port</Label>
            <Input
              type="number"
              value={smtpPort}
              onChange={(e) => setSmtpPort(e.target.value)}
              placeholder="587"
              className="mt-1"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label className="text-sm">Sender Email</Label>
            <Input
              type="email"
              value={senderEmail}
              onChange={(e) => setSenderEmail(e.target.value)}
              placeholder="perfhub@company.com"
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-sm">App Password</Label>
            <Input
              type="password"
              value={senderPassword}
              onChange={(e) => setSenderPassword(e.target.value)}
              placeholder="Enter app password"
              className="mt-1"
            />
          </div>
        </div>

        <div>
          <Label className="text-sm">Default Recipients</Label>
          <p className="text-xs text-muted-foreground mt-0.5 mb-1.5">These recipients get notified for all tests unless overridden per-test</p>
          <div className="flex gap-2">
            <Input
              placeholder="email@example.com"
              value={recipientInput}
              onChange={(e) => setRecipientInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addRecipient(); } }}
            />
            <Button type="button" variant="outline" size="sm" onClick={addRecipient} disabled={!recipientInput.trim()}>Add</Button>
          </div>
          {defaultRecipients.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-2">
              {defaultRecipients.map((email) => (
                <Badge key={email} variant="secondary" className="text-xs gap-1 pr-1">
                  {email}
                  <button type="button" onClick={() => removeRecipient(email)} className="ml-1 hover:text-destructive">
                    <XCircle className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-2 pt-2 border-t">
          <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending || !senderEmail}>
            {saveMutation.isPending ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Saving...</> : "Save Settings"}
          </Button>
          <Button variant="outline" onClick={() => testConnectionMutation.mutate()} disabled={testConnectionMutation.isPending || !settings}>
            {testConnectionMutation.isPending ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Testing...</> : <><RefreshCw className="w-4 h-4 mr-2" /> Test Connection</>}
          </Button>
        </div>

        {settings && (
          <div className="border rounded-lg p-4 space-y-3 bg-muted/20">
            <h4 className="font-medium text-sm flex items-center gap-2">
              <Send className="w-4 h-4" /> Send Test Email
            </h4>
            <div className="flex gap-2">
              <Input
                type="email"
                value={testRecipient}
                onChange={(e) => setTestRecipient(e.target.value)}
                placeholder="recipient@example.com"
              />
              <Button
                variant="outline"
                onClick={() => sendTestMutation.mutate()}
                disabled={sendTestMutation.isPending || !testRecipient.trim()}
              >
                {sendTestMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Send"}
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function EmailLogsCard() {
  const { data: logs = [], isLoading, isError, error, refetch } = useQuery({
    queryKey: [...queryKeys.admin.emailLogs],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/email-logs?limit=25");
      return res.json();
    },
  });

  if (isError) {
    return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load email logs" />;
  }

  return (
    <Card className="transition-all duration-200 hover:shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-gradient-to-br from-slate-500 to-slate-600 shadow">
            <Clock className="h-4 w-4 text-white" />
          </div>
          Email Log
        </CardTitle>
        <CardDescription>Recent email delivery history</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center justify-between gap-3 py-2 px-3 rounded-lg border">
                <div className="flex items-center gap-2">
                  <Skeleton className="w-4 h-4 rounded-full" />
                  <Skeleton className="h-4 w-48" />
                </div>
                <div className="flex items-center gap-2">
                  <Skeleton className="h-5 w-20 rounded-full" />
                  <Skeleton className="h-3 w-32" />
                </div>
              </div>
            ))}
          </div>
        ) : logs.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-6">No emails sent yet</p>
        ) : (
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {logs.map((log: any) => (
              <div key={log.id} className="flex items-center justify-between gap-3 text-sm py-2 px-3 rounded-lg border bg-card">
                <div className="flex items-center gap-2 min-w-0">
                  {log.status === "sent" ? (
                    <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                  )}
                  <span className="truncate">{Array.isArray(log.recipients) ? log.recipients.join(", ") : log.recipientEmail || "—"}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Badge variant={log.status === "sent" ? "default" : "destructive"} className="text-[10px]">
                    {log.eventType}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {log.sentAt ? new Date(log.sentAt).toLocaleString() : "—"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
