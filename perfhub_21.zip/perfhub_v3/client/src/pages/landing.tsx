import { useState, useEffect, useCallback, useRef } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Zap, Shield, BarChart3, Users, Loader2,
  Activity, GitBranch, FileCode, CheckCircle, TrendingUp,
  Server, Bug, Sparkles, ArrowRight, ChevronLeft, ChevronRight,
  Lock, Gauge, KeyRound, Mail, FileText,
  LogIn, UserPlus, Play, Target, LineChart,
  AlertTriangle, Webhook, ClipboardCheck, BrainCircuit,
  Bell, ScrollText, Globe, Rocket,
  ShieldAlert, Upload, Network, Calculator,
  Wand2, Database, Scale, CalendarDays
} from "lucide-react";

interface AuthResponse {
  user?: any;
  message: string;
  resetToken?: string;
}

type AuthView = "none" | "login" | "signup";

function useInView() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } }, { threshold: 0.15 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

function AnimateIn({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const { ref, visible } = useInView();
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(18px)',
        transition: `opacity 0.55s ease ${delay}ms, transform 0.55s ease ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

export default function LandingPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [authView, setAuthView] = useState<AuthView>("none");
  const [loginForm, setLoginForm] = useState({ username: "", password: "" });
  const [signupForm, setSignupForm] = useState({ username: "", email: "", password: "", confirmPassword: "" });
  const [forgotPasswordOpen, setForgotPasswordOpen] = useState(false);
  const [forgotStep, setForgotStep] = useState<'request' | 'reset' | 'done'>('request');
  const [forgotIdentifier, setForgotIdentifier] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [tosOpen, setTosOpen] = useState(false);

  const loginMutation = useMutation({
    mutationFn: async (data: { username: string; password: string }) => {
      const res = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" }, body: JSON.stringify(data), credentials: "include" });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message);
      return json as AuthResponse;
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/auth/session"], { user: data.user, isAuthenticated: true });
      toast({ title: "Welcome back!", description: "You have been logged in successfully." });
      setLocation("/");
    },
    onError: (error: Error) => { toast({ title: "Login failed", description: error.message, variant: "destructive" }); },
  });

  const signupMutation = useMutation({
    mutationFn: async (data: { username: string; email: string; password: string }) => {
      const res = await fetch("/api/auth/signup", { method: "POST", headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" }, body: JSON.stringify(data), credentials: "include" });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message);
      return json as AuthResponse;
    },
    onSuccess: (data) => { toast({ title: "Account created!", description: data.message }); setSignupForm({ username: "", email: "", password: "", confirmPassword: "" }); setAuthView("none"); },
    onError: (error: Error) => { toast({ title: "Signup failed", description: error.message, variant: "destructive" }); },
  });

  const handleLogin = (e: React.FormEvent) => { e.preventDefault(); loginMutation.mutate(loginForm); };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (signupForm.password !== signupForm.confirmPassword) { toast({ title: "Error", description: "Passwords do not match", variant: "destructive" }); return; }
    signupMutation.mutate({ username: signupForm.username, email: signupForm.email, password: signupForm.password });
  };

  const forgotPasswordMutation = useMutation({
    mutationFn: async (identifier: string) => {
      const res = await fetch("/api/auth/forgot-password", { method: "POST", headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" }, body: JSON.stringify({ identifier }) });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message);
      return json as AuthResponse;
    },
    onSuccess: (data) => {
      if (data.resetToken) { setResetToken(data.resetToken); setForgotStep('reset'); toast({ title: "Reset token generated", description: "You can now set your new password." }); }
      else { toast({ title: "Check your email", description: data.message }); }
    },
    onError: (error: Error) => { toast({ title: "Error", description: error.message, variant: "destructive" }); },
  });

  const resetPasswordMutation = useMutation({
    mutationFn: async (data: { token: string; newPassword: string }) => {
      const res = await fetch("/api/auth/reset-password", { method: "POST", headers: { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" }, body: JSON.stringify(data) });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message);
      return json;
    },
    onSuccess: (data) => { setForgotStep('done'); toast({ title: "Password reset", description: data.message }); },
    onError: (error: Error) => { toast({ title: "Reset failed", description: error.message, variant: "destructive" }); },
  });

  const handleForgotSubmit = (e: React.FormEvent) => { e.preventDefault(); forgotPasswordMutation.mutate(forgotIdentifier); };
  const handleResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) { toast({ title: "Error", description: "Passwords do not match", variant: "destructive" }); return; }
    resetPasswordMutation.mutate({ token: resetToken, newPassword });
  };

  const openForgotPassword = () => {
    setAuthView("none");
    setForgotStep('request'); setForgotIdentifier(""); setResetToken(""); setNewPassword(""); setConfirmNewPassword("");
    setForgotPasswordOpen(true);
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <nav className="border-b bg-card/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center shadow-md shadow-primary/20">
              <Zap className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="text-lg font-bold tracking-tight">PerfHub</span>
            <span className="text-[9px] font-bold uppercase tracking-widest text-primary bg-primary/10 px-2 py-0.5 rounded-full border border-primary/20 ml-1">v3</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden lg:flex items-center gap-5 text-[13px] text-muted-foreground mr-4">
              <a href="#features" className="hover:text-foreground transition-colors">Features</a>
              <a href="#platform" className="hover:text-foreground transition-colors">Platform</a>
            </div>
            <Button variant="outline" size="sm" className="h-8 text-[13px] font-medium gap-1.5" onClick={() => setAuthView("login")}>
              <LogIn className="w-3.5 h-3.5" /> Sign In
            </Button>
            <Button size="sm" className="h-8 text-[13px] font-medium gap-1.5 shadow-md shadow-primary/20" onClick={() => setAuthView("signup")}>
              <Rocket className="w-3.5 h-3.5" /> Get Started
            </Button>
          </div>
        </div>
      </nav>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
          <div className="absolute top-[-120px] right-[-80px] w-[400px] h-[400px] rounded-full bg-primary/[0.04] blur-3xl" />
          <div className="absolute bottom-[-80px] left-[-60px] w-[350px] h-[350px] rounded-full bg-primary/[0.03] blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-6 pt-12 pb-14 relative">
          <div className="grid lg:grid-cols-[1fr,1.15fr] gap-10 lg:gap-14 items-center">
            <div>
              <AnimateIn>
                <div className="inline-flex items-center gap-2 text-xs font-semibold text-primary bg-primary/8 border border-primary/15 rounded-full px-3.5 py-1 mb-5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Performance Engineering Platform
                </div>
              </AnimateIn>

              <AnimateIn delay={80}>
                <h1 className="text-[2rem] sm:text-[2.5rem] font-extrabold leading-[1.1] tracking-tight mb-4">
                  Test, Analyze &
                  <br />
                  <span className="bg-gradient-to-r from-primary via-primary/75 to-primary/40 bg-clip-text text-transparent">Ship With Confidence</span>
                </h1>
              </AnimateIn>

              <AnimateIn delay={160}>
                <p className="text-[14px] text-foreground/55 leading-relaxed max-w-md mb-5">
                  The complete JMeter platform. Execute tests, stream live metrics,
                  detect anomalies, enforce SLA compliance, convert HAR recordings to scripts,
                  and generate stakeholder sign-off reports.
                </p>
              </AnimateIn>

              <AnimateIn delay={220}>
                <div className="flex flex-wrap gap-3 mb-5">
                  <Button size="lg" className="h-10 text-[13px] font-semibold gap-2 shadow-lg shadow-primary/25" onClick={() => setAuthView("signup")}>
                    <Rocket className="w-4 h-4" /> Start Free <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                  <Button variant="outline" size="lg" className="h-10 text-[13px] font-semibold gap-2" onClick={() => setAuthView("login")}>
                    <Play className="w-4 h-4" /> Sign In
                  </Button>
                </div>
              </AnimateIn>

              <AnimateIn delay={280}>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-[11px] text-foreground/40">
                  <MiniFeature icon={Shield} label="Role-Based Access" />
                  <MiniFeature icon={Lock} label="Audit Trails" />
                  <MiniFeature icon={GitBranch} label="CI/CD Ready" />
                  <MiniFeature icon={Network} label="Distributed" />
                  <MiniFeature icon={Globe} label="Self-Hosted" />
                </div>
              </AnimateIn>
            </div>

            <AnimateIn delay={200} className="lg:pl-2">
              <FeatureCarousel />
            </AnimateIn>
          </div>
        </div>
      </section>

      <section id="features" className="border-t border-b bg-muted/20">
        <div className="max-w-7xl mx-auto px-6 py-14">
          <AnimateIn>
            <div className="text-center mb-10">
              <p className="text-xs font-bold uppercase tracking-widest text-primary mb-2">Core Capabilities</p>
              <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight mb-2">Full Performance Testing Lifecycle</h2>
              <p className="text-[13px] text-foreground/50 max-w-lg mx-auto">From script creation to stakeholder sign-off, everything in one platform.</p>
            </div>
          </AnimateIn>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <AnimateIn delay={0}><FeatureCard icon={FileCode} title="Script Management" desc="Upload JMeter scripts, organize with folders, manage CSV/JAR dependencies, and configure thread groups." /></AnimateIn>
            <AnimateIn delay={50}><FeatureCard icon={Wand2} title="Script Converter" desc="Convert browser HAR recordings to JMeter scripts with auto-correlation, parameterization, and domain filtering." /></AnimateIn>
            <AnimateIn delay={100}><FeatureCard icon={Activity} title="Live Metrics" desc="Real-time WebSocket dashboard with streaming throughput, response times, percentiles, and error rates." /></AnimateIn>
            <AnimateIn delay={150}><FeatureCard icon={BrainCircuit} title="Anomaly Detection" desc="7 algorithms detect regressions, tail latency, throughput saturation, error spikes, and gradual degradation." /></AnimateIn>
            <AnimateIn delay={200}><FeatureCard icon={ShieldAlert} title="Auto-Abort & SLA" desc="Per-script and per-execution rules that auto-terminate tests on sustained threshold breaches." /></AnimateIn>
            <AnimateIn delay={250}><FeatureCard icon={Scale} title="Comparison & Trends" desc="Side-by-side execution diffs with regression heatmaps, and cross-run trend analysis with forecasting." /></AnimateIn>
            <AnimateIn delay={300}><FeatureCard icon={ClipboardCheck} title="Sign-Off Reports" desc="Consolidated reports with approval workflows, custom sections, and Word document export." /></AnimateIn>
            <AnimateIn delay={350}><FeatureCard icon={Calculator} title="Workload Calculator" desc="Model arrival rates, weighted mixes, pacing, and distributed infrastructure sizing from business requirements." /></AnimateIn>
          </div>
        </div>
      </section>

      <section id="platform" className="border-b">
        <div className="max-w-7xl mx-auto px-6 py-14">
          <AnimateIn>
            <div className="text-center mb-10">
              <p className="text-xs font-bold uppercase tracking-widest text-primary mb-2">Platform</p>
              <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight mb-2">Built for Enterprise Teams</h2>
              <p className="text-[13px] text-foreground/50 max-w-lg mx-auto">Integrations, compliance, and collaboration for performance engineering at scale.</p>
            </div>
          </AnimateIn>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <AnimateIn delay={0}>
              <PlatformCard
                icon={Network}
                title="Distributed Testing"
                features={["Backend Listener JAR (Java 11+)", "Remote agent monitoring", "System metrics collection", "Abort signal propagation"]}
              />
            </AnimateIn>
            <AnimateIn delay={60}>
              <PlatformCard
                icon={GitBranch}
                title="CI/CD Integration"
                features={["Jenkins, GitHub Actions, GitLab CI", "Scoped API tokens", "SLA pass/fail gates", "Pipeline code snippets"]}
              />
            </AnimateIn>
            <AnimateIn delay={120}>
              <PlatformCard
                icon={Bell}
                title="Webhook Notifications"
                features={["Slack, MS Teams, PagerDuty", "HMAC-SHA256 signing", "5 event types", "Delivery tracking & retry"]}
              />
            </AnimateIn>
            <AnimateIn delay={180}>
              <PlatformCard
                icon={Database}
                title="Dump Analyzer"
                features={["Java thread dump analysis", "Heap histogram parsing", "GC log analysis", "Dump comparison mode"]}
              />
            </AnimateIn>
            <AnimateIn delay={240}>
              <PlatformCard
                icon={Upload}
                title="CSV/JTL Import"
                features={["Import legacy result files", "Full analytics pipeline", "Anomaly detection on import", "Transaction breakdown"]}
              />
            </AnimateIn>
            <AnimateIn delay={300}>
              <PlatformCard
                icon={ScrollText}
                title="Audit & Compliance"
                features={["Full audit trail logging", "Admin/Manager/Engineer roles", "Data retention policies", "User approval workflow"]}
              />
            </AnimateIn>
          </div>
        </div>
      </section>

      <section className="border-b bg-muted/20">
        <div className="max-w-7xl mx-auto px-6 py-14">
          <AnimateIn>
            <div className="text-center mb-10">
              <p className="text-xs font-bold uppercase tracking-widest text-primary mb-2">Workflow</p>
              <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight mb-2">From Test to Sign-Off in 4 Steps</h2>
            </div>
          </AnimateIn>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <AnimateIn delay={0}><StepCard step={1} icon={Rocket} title="Execute" desc="Upload scripts, configure VUs, schedule or trigger from CI/CD pipelines." /></AnimateIn>
            <AnimateIn delay={80}><StepCard step={2} icon={Activity} title="Monitor" desc="Stream live metrics via WebSocket. Track throughput, latency, errors, and percentiles in real-time." /></AnimateIn>
            <AnimateIn delay={160}><StepCard step={3} icon={BrainCircuit} title="Analyze" desc="7 anomaly algorithms, regression comparison, trend forecasting, and bottleneck detection." /></AnimateIn>
            <AnimateIn delay={240}><StepCard step={4} icon={ClipboardCheck} title="Sign Off" desc="Generate reports, route through approvals, and export Word documents for stakeholders." /></AnimateIn>
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-br from-primary/5 via-background to-primary/[0.03]">
        <div className="max-w-3xl mx-auto px-6 py-14 text-center">
          <AnimateIn>
            <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center mx-auto mb-5 shadow-xl shadow-primary/20">
              <Zap className="w-6 h-6 text-primary-foreground" />
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight mb-3">Ready to Ship with Confidence?</h2>
            <p className="text-[13px] text-foreground/50 max-w-md mx-auto mb-6">
              Join performance engineering teams using PerfHub for load testing, anomaly detection, and compliance sign-off.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Button size="lg" className="h-10 text-[13px] font-semibold gap-2 px-6 shadow-lg shadow-primary/25" onClick={() => setAuthView("signup")}>
                <Rocket className="w-4 h-4" /> Create Free Account <ArrowRight className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="lg" className="h-10 text-[13px] font-semibold gap-2 px-6" onClick={() => setAuthView("login")}>
                <LogIn className="w-4 h-4" /> Sign In
              </Button>
            </div>
          </AnimateIn>
        </div>
      </section>

      <footer className="border-t py-6 px-6 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center">
                <Zap className="w-3 h-3 text-primary-foreground" />
              </div>
              <span className="text-[13px] font-bold">PerfHub</span>
              <span className="text-[9px] font-bold uppercase tracking-widest text-primary bg-primary/10 px-1.5 py-0.5 rounded-full border border-primary/20">v3</span>
            </div>
            <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
              <button onClick={() => setTosOpen(true)} className="hover:text-foreground transition-colors hover:underline">Terms of Service</button>
              <span className="w-1 h-1 rounded-full bg-border" />
              <span>Privacy Policy</span>
              <span className="w-1 h-1 rounded-full bg-border" />
              <span>v3.2.0</span>
            </div>
          </div>
        </div>
      </footer>

      <Dialog open={authView === "login"} onOpenChange={(open) => !open && setAuthView("none")}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><LogIn className="w-5 h-5 text-primary" /> Sign In</DialogTitle>
            <DialogDescription>Access your performance engineering workspace</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleLogin} className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label htmlFor="login-username" className="text-[13px]">Username</Label>
              <Input id="login-username" placeholder="Enter your username" value={loginForm.username} onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })} className="h-10 text-[13px]" autoComplete="username" required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="login-password" className="text-[13px]">Password</Label>
              <Input id="login-password" type="password" placeholder="Enter your password" value={loginForm.password} onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })} className="h-10 text-[13px]" autoComplete="current-password" required />
            </div>
            <Button type="submit" className="w-full font-medium h-10 text-[13px]" disabled={loginMutation.isPending}>
              {loginMutation.isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Signing in...</> : <>Sign In <ArrowRight className="ml-2 h-4 w-4" /></>}
            </Button>
            <div className="flex items-center justify-between text-[12px]">
              <button type="button" onClick={openForgotPassword} className="text-primary hover:text-primary/80 transition-colors hover:underline">Forgot your password?</button>
              <button type="button" onClick={() => setAuthView("signup")} className="text-muted-foreground hover:text-foreground transition-colors hover:underline">Create an account</button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={authView === "signup"} onOpenChange={(open) => !open && setAuthView("none")}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><UserPlus className="w-5 h-5 text-primary" /> Create Account</DialogTitle>
            <DialogDescription>Sign up for a new performance engineering account</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSignup} className="space-y-3 mt-2">
            <div className="space-y-1.5">
              <Label htmlFor="signup-username" className="text-[13px]">Username</Label>
              <Input id="signup-username" placeholder="Choose a username" value={signupForm.username} onChange={(e) => setSignupForm({ ...signupForm, username: e.target.value })} className="h-10 text-[13px]" autoComplete="username" required minLength={3} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="signup-email" className="text-[13px]">Email (optional)</Label>
              <Input id="signup-email" type="email" placeholder="your@email.com" value={signupForm.email} onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })} className="h-10 text-[13px]" autoComplete="email" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="signup-password" className="text-[13px]">Password</Label>
              <Input id="signup-password" type="password" placeholder="Create a password" value={signupForm.password} onChange={(e) => setSignupForm({ ...signupForm, password: e.target.value })} className="h-10 text-[13px]" autoComplete="new-password" required minLength={8} />
              <p className="text-[10px] text-muted-foreground">Min 8 chars, uppercase, lowercase, number, special character</p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="signup-confirm" className="text-[13px]">Confirm Password</Label>
              <Input id="signup-confirm" type="password" placeholder="Confirm your password" value={signupForm.confirmPassword} onChange={(e) => setSignupForm({ ...signupForm, confirmPassword: e.target.value })} className="h-10 text-[13px]" autoComplete="new-password" required />
            </div>
            <Button type="submit" className="w-full font-medium h-10 text-[13px]" disabled={signupMutation.isPending}>
              {signupMutation.isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating account...</> : <>Create Account <ArrowRight className="ml-2 h-4 w-4" /></>}
            </Button>
            <div className="space-y-2 pt-2 border-t">
              <p className="text-[11px] text-muted-foreground text-center leading-relaxed">After signing up, an administrator will review and approve your account.</p>
              <p className="text-[11px] text-muted-foreground text-center">By creating an account, you agree to our <button type="button" onClick={() => setTosOpen(true)} className="text-primary hover:underline">Terms of Service</button>.</p>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={forgotPasswordOpen} onOpenChange={setForgotPasswordOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><KeyRound className="w-5 h-5 text-primary" /> Reset Password</DialogTitle>
            <DialogDescription>{forgotStep === 'request' ? 'Enter your username or email to reset your password' : forgotStep === 'reset' ? 'Set your new password' : 'Password has been reset'}</DialogDescription>
          </DialogHeader>
          {forgotStep === 'request' && (
            <form onSubmit={handleForgotSubmit} className="space-y-4 mt-2">
              <div className="space-y-1.5">
                <Label htmlFor="forgot-id" className="text-[13px]">Username or Email</Label>
                <Input id="forgot-id" placeholder="Enter your username or email" value={forgotIdentifier} onChange={(e) => setForgotIdentifier(e.target.value)} className="h-10 text-[13px]" required />
              </div>
              <Button type="submit" className="w-full h-10 text-[13px]" disabled={forgotPasswordMutation.isPending}>
                {forgotPasswordMutation.isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...</> : <>Request Reset <Mail className="ml-2 h-4 w-4" /></>}
              </Button>
            </form>
          )}
          {forgotStep === 'reset' && (
            <form onSubmit={handleResetSubmit} className="space-y-4 mt-2">
              <div className="space-y-1.5">
                <Label className="text-[13px]">Reset Token</Label>
                <Input value={resetToken} readOnly className="h-10 text-[13px] font-mono bg-muted/50" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="new-pw" className="text-[13px]">New Password</Label>
                <Input id="new-pw" type="password" placeholder="Enter new password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="h-10 text-[13px]" required minLength={8} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="confirm-new-pw" className="text-[13px]">Confirm Password</Label>
                <Input id="confirm-new-pw" type="password" placeholder="Confirm new password" value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} className="h-10 text-[13px]" required />
              </div>
              <Button type="submit" className="w-full h-10 text-[13px]" disabled={resetPasswordMutation.isPending}>
                {resetPasswordMutation.isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Resetting...</> : "Reset Password"}
              </Button>
            </form>
          )}
          {forgotStep === 'done' && (
            <div className="text-center py-4">
              <CheckCircle className="w-10 h-10 text-green-500 mx-auto mb-3" />
              <p className="text-[13px] text-foreground mb-3">Your password has been reset successfully.</p>
              <Button className="h-10 text-[13px]" onClick={() => { setForgotPasswordOpen(false); setAuthView("login"); }}>
                Sign In Now <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={tosOpen} onOpenChange={setTosOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Terms of Service</DialogTitle>
            <DialogDescription>PerfHub Performance Testing Platform</DialogDescription>
          </DialogHeader>
          <div className="prose prose-sm max-w-none text-[13px] text-foreground/70 space-y-4">
            <h3 className="text-[14px] font-bold text-foreground">1. Acceptance</h3>
            <p>By creating an account and using PerfHub, you agree to be bound by these Terms of Service. If you do not agree, do not use the platform.</p>
            <h3 className="text-[14px] font-bold text-foreground">2. Usage</h3>
            <p>PerfHub is a performance testing platform designed for use by authorized personnel. You agree to use the platform only for lawful purposes and in accordance with your organization's policies.</p>
            <h3 className="text-[14px] font-bold text-foreground">3. Accounts</h3>
            <p>New accounts require administrator approval. You are responsible for maintaining the confidentiality of your credentials and for all activities under your account.</p>
            <h3 className="text-[14px] font-bold text-foreground">4. Data</h3>
            <p>Performance test data, scripts, and results are stored on your self-hosted instance. You are responsible for backups and data retention.</p>
            <h3 className="text-[14px] font-bold text-foreground">5. Intellectual Property</h3>
            <p>PerfHub and its components are proprietary software. Your test scripts, data, and results remain your intellectual property.</p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

const slides = [
  { id: "dashboard", title: "Live Test Dashboard", subtitle: "Real-time metrics via WebSocket streaming", content: <DashboardSlide /> },
  { id: "metrics", title: "Transaction Breakdown", subtitle: "Per-transaction response times & throughput", content: <MetricsSlide /> },
  { id: "anomaly", title: "Anomaly Detection", subtitle: "7 algorithms with confidence scoring", content: <AnomalySlide /> },
  { id: "sla", title: "SLA Compliance", subtitle: "Automated threshold tracking & auto-abort", content: <SlaSlide /> },
];

function FeatureCarousel() {
  const [current, setCurrent] = useState(0);
  const next = useCallback(() => { setCurrent((c) => (c + 1) % slides.length); }, []);
  const prev = useCallback(() => { setCurrent((c) => (c - 1 + slides.length) % slides.length); }, []);

  useEffect(() => {
    const timer = setInterval(next, 5000);
    return () => clearInterval(timer);
  }, [next]);

  return (
    <div className="relative">
      <div className="rounded-xl border bg-card overflow-hidden shadow-2xl shadow-primary/[0.06]">
        <div className="flex items-center justify-between px-4 py-2 border-b bg-muted/30">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-400/60" />
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-400/60" />
            <div className="w-2.5 h-2.5 rounded-full bg-green-400/60" />
            <span className="text-[11px] text-muted-foreground ml-3 font-mono">{slides[current].title}</span>
          </div>
          <div className="flex items-center gap-0.5">
            <button onClick={prev} className="w-6 h-6 rounded-md flex items-center justify-center hover:bg-muted transition-colors">
              <ChevronLeft className="w-3.5 h-3.5 text-muted-foreground" />
            </button>
            <button onClick={next} className="w-6 h-6 rounded-md flex items-center justify-center hover:bg-muted transition-colors">
              <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />
            </button>
          </div>
        </div>
        <div className="relative overflow-hidden" style={{ minHeight: 280 }}>
          {slides.map((slide, i) => (
            <div key={slide.id} className="absolute inset-0 p-4 transition-all duration-500 ease-in-out"
              style={{ transform: i === current ? 'translateX(0)' : i < current ? 'translateX(-100%)' : 'translateX(100%)', opacity: i === current ? 1 : 0, pointerEvents: i === current ? 'auto' : 'none' }}>
              {slide.content}
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between px-4 py-2.5 border-t bg-muted/20">
          <div>
            <p className="text-[11px] font-semibold">{slides[current].title}</p>
            <p className="text-[10px] text-muted-foreground">{slides[current].subtitle}</p>
          </div>
          <div className="flex items-center gap-1.5">
            {slides.map((_, i) => (
              <button key={i} onClick={() => setCurrent(i)}
                className={`transition-all duration-300 rounded-full ${i === current ? 'w-5 h-1.5 bg-primary' : 'w-1.5 h-1.5 bg-muted-foreground/25 hover:bg-muted-foreground/40'}`} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function DashboardSlide() {
  const bars = [32, 48, 42, 65, 55, 78, 46, 60, 72, 50, 82, 66, 58, 40, 70, 64, 74, 52, 80, 45, 68, 56, 62, 76];
  return (
    <div>
      <div className="grid grid-cols-4 gap-2 mb-3">
        <SlideMetric label="Throughput" value="12.2 rps" color="text-primary" />
        <SlideMetric label="Avg Response" value="408 ms" color="text-green-500" />
        <SlideMetric label="Error Rate" value="0.9%" color="text-destructive" />
        <SlideMetric label="P95 Latency" value="445 ms" color="text-amber-500" />
      </div>
      <div className="flex items-end gap-[2px] h-[140px] px-0.5">
        {bars.map((h, i) => (
          <div key={i} className="flex-1 rounded-t-[2px]" style={{
            height: `${h}%`,
            background: h > 75 ? 'linear-gradient(to top, hsl(var(--destructive) / 0.5), hsl(var(--destructive) / 0.15))' : 'linear-gradient(to top, hsl(var(--primary) / 0.45), hsl(var(--primary) / 0.1))',
            animationName: 'barReveal', animationDuration: '0.4s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: `${i * 20}ms`,
          }} />
        ))}
      </div>
      <div className="flex items-center justify-between mt-2 text-[9px] text-muted-foreground font-mono px-0.5">
        <span>0s</span>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-sm bg-primary/50" /> Normal</span>
          <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-sm bg-destructive/50" /> SLA Breach</span>
        </div>
        <span>120s</span>
      </div>
      <style>{`@keyframes barReveal { from { transform: scaleY(0); transform-origin: bottom; } to { transform: scaleY(1); transform-origin: bottom; } }`}</style>
    </div>
  );
}

function MetricsSlide() {
  const transactions = [
    { name: "Login API", avg: 245, p95: 412, rps: 8.2, err: "0.1%" },
    { name: "Search Query", avg: 180, p95: 350, rps: 15.4, err: "0.0%" },
    { name: "Checkout Flow", avg: 520, p95: 890, rps: 3.1, err: "2.3%" },
    { name: "Dashboard Load", avg: 310, p95: 580, rps: 6.8, err: "0.0%" },
    { name: "File Upload", avg: 890, p95: 1450, rps: 1.2, err: "1.1%" },
  ];
  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <LineChart className="w-4 h-4 text-primary" />
        <span className="text-[12px] font-semibold">Transaction Summary</span>
        <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-green-500/10 text-green-600 border border-green-500/20 font-medium">5 passed</span>
      </div>
      <div className="rounded-lg border overflow-hidden">
        <table className="w-full text-[11px]">
          <thead><tr className="bg-muted/40 text-muted-foreground">
            <th className="text-left px-3 py-1.5 font-medium">Transaction</th>
            <th className="text-right px-2 py-1.5 font-medium">Avg</th>
            <th className="text-right px-2 py-1.5 font-medium">P95</th>
            <th className="text-right px-2 py-1.5 font-medium">RPS</th>
            <th className="text-right px-3 py-1.5 font-medium">Err%</th>
          </tr></thead>
          <tbody className="divide-y">
            {transactions.map((t, i) => (
              <tr key={i} className="hover:bg-muted/20 transition-colors">
                <td className="px-3 py-1.5 font-medium">{t.name}</td>
                <td className="text-right px-2 py-1.5 font-mono text-muted-foreground">{t.avg}ms</td>
                <td className="text-right px-2 py-1.5 font-mono text-muted-foreground">{t.p95}ms</td>
                <td className="text-right px-2 py-1.5 font-mono text-primary">{t.rps}</td>
                <td className={`text-right px-3 py-1.5 font-mono ${parseFloat(t.err) > 1 ? 'text-destructive' : 'text-green-500'}`}>{t.err}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex items-center gap-4 mt-2 text-[10px] text-muted-foreground">
        <span className="flex items-center gap-1"><Target className="w-3 h-3 text-primary" /> 34.7 total rps</span>
        <span className="flex items-center gap-1"><Activity className="w-3 h-3 text-amber-500" /> 250 VUs</span>
      </div>
    </div>
  );
}

function AnomalySlide() {
  const anomalies = [
    { title: "Tail Latency Spread", severity: "critical", desc: "P99/P50 ratio is 4.8x (threshold: 3.0x) on Checkout Flow", confidence: 94, icon: AlertTriangle },
    { title: "Throughput Saturation", severity: "warning", desc: "Throughput plateaued at 34.7 rps despite 40% VU increase", confidence: 87, icon: TrendingUp },
    { title: "Gradual Degradation", severity: "warning", desc: "Login API avg response time increased 23% over test duration", confidence: 82, icon: Activity },
    { title: "Error Step Change", severity: "info", desc: "File Upload error rate jumped from 0.2% to 1.1% at 10:42", confidence: 76, icon: Bug },
  ];
  const severityColors: Record<string, string> = {
    critical: "bg-red-500/10 text-red-600 border-red-500/20",
    warning: "bg-amber-500/10 text-amber-600 border-amber-500/20",
    info: "bg-blue-500/10 text-blue-600 border-blue-500/20",
  };
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <BrainCircuit className="w-4 h-4 text-primary" />
          <span className="text-[12px] font-semibold">Anomaly Detection</span>
        </div>
        <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20 font-medium">Health: 72/100</span>
      </div>
      <div className="space-y-1.5">
        {anomalies.map((a, i) => (
          <div key={i} className="rounded-lg border p-2.5 flex items-start gap-2.5 hover:bg-muted/20 transition-colors">
            <div className={`w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0 ${a.severity === 'critical' ? 'bg-red-500/10' : a.severity === 'warning' ? 'bg-amber-500/10' : 'bg-blue-500/10'}`}>
              <a.icon className={`w-3 h-3 ${a.severity === 'critical' ? 'text-red-500' : a.severity === 'warning' ? 'text-amber-500' : 'text-blue-500'}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-[11px] font-semibold">{a.title}</span>
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full border font-medium ${severityColors[a.severity]}`}>{a.severity}</span>
              </div>
              <p className="text-[10px] text-muted-foreground leading-snug">{a.desc}</p>
            </div>
            <span className="text-[10px] font-mono text-muted-foreground flex-shrink-0">{a.confidence}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function SlaSlide() {
  const rules = [
    { name: "Response Time < 500ms", threshold: "500 ms", actual: "412 ms", status: "pass" },
    { name: "Error Rate < 1%", threshold: "1.0%", actual: "0.9%", status: "pass" },
    { name: "Throughput > 10 rps", threshold: "10 rps", actual: "12.2 rps", status: "pass" },
    { name: "P99 < 2000ms", threshold: "2000 ms", actual: "2100 ms", status: "fail" },
  ];
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Target className="w-4 h-4 text-primary" />
          <span className="text-[12px] font-semibold">SLA Compliance</span>
        </div>
        <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 border border-amber-500/20 font-medium">3/4 Passed</span>
      </div>
      <div className="space-y-2">
        {rules.map((r, i) => (
          <div key={i} className={`rounded-lg border p-3 flex items-center justify-between ${r.status === 'fail' ? 'border-destructive/30 bg-destructive/5' : 'bg-muted/20'}`}>
            <div>
              <p className="text-[12px] font-medium mb-0.5">{r.name}</p>
              <p className="text-[10px] text-muted-foreground">Actual: <span className="font-mono font-medium">{r.actual}</span> / Limit: <span className="font-mono">{r.threshold}</span></p>
            </div>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${r.status === 'pass' ? 'bg-green-500/10' : 'bg-destructive/10'}`}>
              {r.status === 'pass' ? <CheckCircle className="w-3.5 h-3.5 text-green-500" /> : <AlertTriangle className="w-3.5 h-3.5 text-destructive" />}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SlideMetric({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="bg-muted/30 rounded-md px-2 py-1.5 border">
      <p className="text-[9px] text-muted-foreground uppercase tracking-wider font-medium">{label}</p>
      <p className={`text-[13px] font-bold ${color} mt-0.5`}>{value}</p>
    </div>
  );
}

function MiniFeature({ icon: Icon, label }: { icon: any; label: string }) {
  return (
    <div className="flex items-center gap-1.5 text-[11px] text-foreground/40">
      <Icon className="w-3.5 h-3.5 text-primary/60" />
      <span className="font-semibold">{label}</span>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <div className="group bg-card border rounded-xl p-4 hover:border-primary/25 hover:shadow-lg hover:shadow-primary/[0.04] hover:-translate-y-0.5 transition-all duration-300">
      <div className="w-9 h-9 rounded-lg bg-primary/8 flex items-center justify-center mb-2.5 group-hover:bg-primary/12 transition-colors">
        <Icon className="w-4.5 h-4.5 text-primary" />
      </div>
      <h3 className="text-[13px] font-bold mb-1">{title}</h3>
      <p className="text-[12px] text-foreground/50 leading-relaxed">{desc}</p>
    </div>
  );
}

function PlatformCard({ icon: Icon, title, features }: {
  icon: any; title: string; features: string[];
}) {
  return (
    <div className="bg-card border rounded-xl p-4 hover:border-primary/20 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-9 h-9 bg-primary/8 rounded-lg flex items-center justify-center flex-shrink-0">
          <Icon className="w-4.5 h-4.5 text-primary" />
        </div>
        <h3 className="text-[13px] font-bold">{title}</h3>
      </div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
        {features.map((f, i) => (
          <div key={i} className="flex items-center gap-1.5 text-[11px] text-foreground/50">
            <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0" />
            <span>{f}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function StepCard({ step, icon: Icon, title, desc }: { step: number; icon: any; title: string; desc: string }) {
  return (
    <div className="relative bg-card border rounded-xl p-4 text-center hover:border-primary/25 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300">
      <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-primary text-primary-foreground text-[11px] font-bold flex items-center justify-center shadow-md shadow-primary/20">{step}</div>
      <div className="w-9 h-9 rounded-lg bg-primary/8 flex items-center justify-center mx-auto mb-2.5 mt-2">
        <Icon className="w-4.5 h-4.5 text-primary" />
      </div>
      <h3 className="text-[13px] font-bold mb-1">{title}</h3>
      <p className="text-[11px] text-foreground/50 leading-relaxed">{desc}</p>
    </div>
  );
}
