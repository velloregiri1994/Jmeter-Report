import { useState, useMemo } from "react";
import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Calculator, Users, Clock, Zap, Plus, Trash2, BarChart3,
  ArrowRight, Info, Copy, Check, AlertTriangle, Layers,
  Timer, Activity, Target, TrendingUp, Hash, Settings2,
  ChevronRight, Download, GitBranch, Workflow, Save, Loader2,
  Server
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { copyToClipboard } from "@/lib/clipboard";

import { DistributedLoadCalculator } from "./distributed-load-calculator";

type TestType = "load" | "stress" | "spike" | "endurance" | "scalability" | "breakpoint";
type CalcMode = "single" | "weighted" | "distributed";
type InputMode = "threads" | "tph";

interface SingleFlowInputs {
  inputMode: InputMode;
  threads: string;
  tph: string;
  transactionsPerIteration: string;
  e2eResponseTime: string;
  thinkTime: string;
  testDuration: string;
  testType: TestType;
}

interface WeightedTransaction {
  id: string;
  name: string;
  weight: string;
  responseTime: string;
  thinkTime: string;
}

interface WeightedInputs {
  inputMode: InputMode;
  threads: string;
  tph: string;
  transactions: WeightedTransaction[];
  testDuration: string;
  testType: TestType;
}

interface CalculationResult {
  threads: number;
  tph: number;
  tps: number;
  pacing: number;
  iterationsPerHour: number;
  totalIterations: number;
  totalTransactions: number;
  durationSeconds: number;
  threadGroupRecommendation: ThreadGroupRec;
  perTransaction?: { name: string; tph: number; tps: number; weight: number }[];
  weightedResponseTime?: number;
  weightedThinkTime?: number;
  transactionsPerIteration?: number;
}

interface ThreadGroupRec {
  name: string;
  description: string;
  config: string;
  reason: string;
  jmeterSetup: string[];
  pluginRequired: boolean;
  pluginName?: string;
  pluginUrl?: string;
}

const TEST_TYPES: { value: TestType; label: string; description: string }[] = [
  { value: "load", label: "Load Test", description: "Steady state, validate expected load" },
  { value: "stress", label: "Stress Test", description: "Find the breaking point" },
  { value: "spike", label: "Spike Test", description: "Sudden burst of users" },
  { value: "endurance", label: "Endurance / Soak Test", description: "Long duration stability" },
  { value: "scalability", label: "Scalability Test", description: "Incremental load increase" },
  { value: "breakpoint", label: "Breakpoint Test", description: "Maximum capacity discovery" },
];

function getThreadGroupRecommendation(testType: TestType, threads: number, duration: number): ThreadGroupRec {
  const rampUp = Math.max(Math.round(duration * 0.1), 60);

  switch (testType) {
    case "load":
      return {
        name: "Thread Group",
        description: "Fixed concurrency with gradual ramp-up, steady hold, and ramp-down. The default JMeter thread group — no plugins needed.",
        reason: "Load tests need a stable user count to validate steady-state performance. A flat load profile ensures consistent measurement conditions.",
        pluginRequired: false,
        jmeterSetup: [
          "Right-click Test Plan → Add → Threads → Thread Group",
          `Set Number of Threads to ${threads}`,
          `Set Ramp-up Period to ${rampUp} seconds`,
          "Check 'Specify Thread Lifetime' and set Duration",
          `Set Duration to ${duration} seconds`,
          "Set Loop Count to Forever (-1)",
          "Add a Constant Timer with your Think Time value under samplers",
        ],
        config: `Thread Group:
  Threads: ${threads}
  Ramp-up: ${rampUp} seconds
  Duration: ${duration} seconds
  Loop: Forever (controlled by duration)`,
      };
    case "stress": {
      const stepSize = Math.max(Math.round(threads / 10), 5);
      return {
        name: "Stepping Thread Group",
        description: "Adds users in controlled steps to identify the stress threshold. Each step holds for a period before adding more users, creating a staircase pattern.",
        reason: "Stress tests need gradual load increase to pinpoint where degradation begins. Each step gives the system time to stabilize, making it easy to correlate performance changes with specific user counts.",
        pluginRequired: true,
        pluginName: "Custom Thread Groups (jpgc-casutg)",
        pluginUrl: "https://jmeter-plugins.org/wiki/SteppingThreadGroup/",
        jmeterSetup: [
          "Install JMeter Plugins Manager (if not installed)",
          "Install 'Custom Thread Groups' plugin via Plugins Manager",
          "Right-click Test Plan → Add → Threads → jp@gc - Stepping Thread Group",
          `Set 'This group will start' to ${stepSize} threads`,
          `Set 'Then start' to ${stepSize} threads every ${Math.round(duration / 10)} seconds`,
          `Set 'Using ramp-up' to ${Math.round(rampUp / 10)} seconds`,
          `Set max threads to ${threads}`,
          `Set 'Then hold load for' to ${Math.round(duration * 0.25)} seconds`,
        ],
        config: `Stepping Thread Group:
  Start threads: ${stepSize}
  Step size: ${stepSize} users
  Step interval: ${Math.round(duration / 10)} seconds
  Target threads: ${threads}
  Hold at peak: ${Math.round(duration * 0.25)} seconds`,
      };
    }
    case "spike":
      return {
        name: "Ultimate Thread Group",
        description: "Models sudden jump from baseline to peak and back. Each row defines a thread schedule with independent start time, ramp-up, hold, and shutdown.",
        reason: "Spike tests simulate sudden traffic bursts like flash sales or viral events. The sharp ramp-up reveals how the system handles sudden load, and the recovery phase shows resilience.",
        pluginRequired: true,
        pluginName: "Custom Thread Groups (jpgc-casutg)",
        pluginUrl: "https://jmeter-plugins.org/wiki/UltimateThreadGroup/",
        jmeterSetup: [
          "Install JMeter Plugins Manager (if not installed)",
          "Install 'Custom Thread Groups' plugin via Plugins Manager",
          "Right-click Test Plan → Add → Threads → jp@gc - Ultimate Thread Group",
          "Add Row 1 (Baseline):",
          `  Threads: ${Math.round(threads * 0.2)}, Start: 0s, Hold: ${Math.round(duration * 0.3)}s`,
          "Add Row 2 (Spike):",
          `  Threads: ${threads - Math.round(threads * 0.2)}, Start: ${Math.round(duration * 0.3)}s, Ramp-up: ${Math.round(rampUp * 0.1)}s, Hold: ${Math.round(duration * 0.3)}s`,
          "Add Row 3 (Recovery):",
          `  Reduce back to ${Math.round(threads * 0.2)} threads for ${Math.round(duration * 0.3)}s`,
        ],
        config: `Ultimate Thread Group:
  Phase 1 — Baseline:
    Threads: ${Math.round(threads * 0.2)}
    Duration: ${Math.round(duration * 0.3)} seconds
  Phase 2 — Spike:
    Threads: ${threads}
    Ramp-up: ${Math.round(rampUp * 0.1)} seconds
    Duration: ${Math.round(duration * 0.3)} seconds
  Phase 3 — Recovery:
    Threads: ${Math.round(threads * 0.2)}
    Duration: ${Math.round(duration * 0.3)} seconds`,
      };
    case "endurance":
      return {
        name: "Thread Group",
        description: "Fixed concurrency over extended duration to detect memory leaks, connection pool exhaustion, and gradual degradation. Uses the default JMeter thread group.",
        reason: "Endurance tests hold constant load for hours to surface time-based issues like memory leaks, GC pressure, and log file growth that only appear under sustained load.",
        pluginRequired: false,
        jmeterSetup: [
          "Right-click Test Plan → Add → Threads → Thread Group",
          `Set Number of Threads to ${threads}`,
          `Set Ramp-up Period to ${rampUp} seconds`,
          "Check 'Specify Thread Lifetime' and set Duration",
          `Set Duration to ${duration} seconds (${(duration / 3600).toFixed(1)} hours)`,
          "Set Loop Count to Forever (-1)",
          "Add a Constant Timer with your Think Time value under samplers",
          "Tip: Use a Backend Listener to stream results to PerfHub for live monitoring",
        ],
        config: `Thread Group:
  Threads: ${threads}
  Ramp-up: ${rampUp} seconds
  Duration: ${duration} seconds (${(duration / 3600).toFixed(1)} hours)
  Loop: Forever (controlled by duration)`,
      };
    case "scalability":
      return {
        name: "Concurrency Thread Group",
        description: "Auto-adjusts threads to hit target concurrency with optional Throughput Shaping Timer for precise TPS control at each scaling level.",
        reason: "Scalability tests need controlled throughput ramp to measure system elasticity. Each plateau gives time to observe whether response times stay within SLA at each load level.",
        pluginRequired: true,
        pluginName: "Custom Thread Groups (jpgc-casutg)",
        pluginUrl: "https://jmeter-plugins.org/wiki/ConcurrencyThreadGroup/",
        jmeterSetup: [
          "Install JMeter Plugins Manager (if not installed)",
          "Install 'Custom Thread Groups' plugin via Plugins Manager",
          "Right-click Test Plan → Add → Threads → jp@gc - Concurrency Thread Group",
          `Set Target Concurrency to ${threads}`,
          `Set Ramp Up Time to ${rampUp} seconds`,
          `Set Hold Target Rate Time to ${duration - rampUp} seconds`,
          "Optional: Add Throughput Shaping Timer for TPS-based phases:",
          `  Phase 1: ${Math.round(threads * 0.25)} threads for ${Math.round(duration * 0.25)}s`,
          `  Phase 2: ${Math.round(threads * 0.50)} threads for ${Math.round(duration * 0.25)}s`,
          `  Phase 3: ${Math.round(threads * 0.75)} threads for ${Math.round(duration * 0.25)}s`,
          `  Phase 4: ${threads} threads for ${Math.round(duration * 0.25)}s`,
        ],
        config: `Concurrency Thread Group:
  Target concurrency: ${threads}
  Ramp-up: ${rampUp} seconds
  Hold: ${duration - rampUp} seconds

Throughput Shaping Timer:
  Phase 1: ${Math.round(threads * 0.25)} threads for ${Math.round(duration * 0.25)}s
  Phase 2: ${Math.round(threads * 0.50)} threads for ${Math.round(duration * 0.25)}s
  Phase 3: ${Math.round(threads * 0.75)} threads for ${Math.round(duration * 0.25)}s
  Phase 4: ${threads} threads for ${Math.round(duration * 0.25)}s`,
      };
    case "breakpoint": {
      const bpStep = Math.max(Math.round(threads / 20), 5);
      return {
        name: "Stepping Thread Group",
        description: "Continuously adds users with no ceiling until failure or SLA breach. The step-and-hold pattern lets you identify the exact concurrency level where the system breaks.",
        reason: "Breakpoint tests push load beyond expected capacity to find absolute limits. By stepping past the target, you discover the real ceiling — not just the expected one.",
        pluginRequired: true,
        pluginName: "Custom Thread Groups (jpgc-casutg)",
        pluginUrl: "https://jmeter-plugins.org/wiki/SteppingThreadGroup/",
        jmeterSetup: [
          "Install JMeter Plugins Manager (if not installed)",
          "Install 'Custom Thread Groups' plugin via Plugins Manager",
          "Right-click Test Plan → Add → Threads → jp@gc - Stepping Thread Group",
          `Set 'This group will start' to ${bpStep} threads`,
          `Set 'Then start' to ${bpStep} threads every ${Math.round(duration / 20)} seconds`,
          `Set max threads to ${Math.round(threads * 1.5)} (overshoot target to find break)`,
          `Set 'Then hold load for' to ${Math.round(duration * 0.1)} seconds`,
          "Monitor error rate and response time — stop when SLA breach is sustained",
        ],
        config: `Stepping Thread Group:
  Start threads: ${bpStep}
  Step size: ${bpStep} users
  Step interval: ${Math.round(duration / 20)} seconds
  Target threads: ${Math.round(threads * 1.5)} (overshoot to find break)
  Hold at peak: ${Math.round(duration * 0.1)} seconds`,
      };
    }
  }
}

function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

const DEFAULT_SINGLE: SingleFlowInputs = {
  inputMode: "threads",
  threads: "",
  tph: "",
  transactionsPerIteration: "",
  e2eResponseTime: "",
  thinkTime: "",
  testDuration: "",
  testType: "load",
};

const DEFAULT_WEIGHTED_TX: WeightedTransaction = {
  id: generateId(),
  name: "",
  weight: "",
  responseTime: "",
  thinkTime: "",
};

const DEFAULT_WEIGHTED: WeightedInputs = {
  inputMode: "threads",
  threads: "",
  tph: "",
  transactions: [
    { ...DEFAULT_WEIGHTED_TX, id: generateId() },
    { ...DEFAULT_WEIGHTED_TX, id: generateId() },
  ],
  testDuration: "",
  testType: "load",
};

export default function WorkloadModelPage() {
  const { canWrite } = useAuth();
  const { toast } = useToast();
  const [calcMode, setCalcMode] = useState<CalcMode>("single");
  const [single, setSingle] = useState<SingleFlowInputs>(DEFAULT_SINGLE);
  const [weighted, setWeighted] = useState<WeightedInputs>(DEFAULT_WEIGHTED);
  const [copied, setCopied] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [selectedScriptId, setSelectedScriptId] = useState<string>("");

  const singleResult = useMemo((): CalculationResult | null => {
    const txns = parseFloat(single.transactionsPerIteration);
    const e2e = parseFloat(single.e2eResponseTime);
    const think = parseFloat(single.thinkTime);
    const dur = parseFloat(single.testDuration) * 60;

    if (!txns || txns <= 0 || !e2e || e2e < 0 || think < 0 || isNaN(think) || !dur || dur <= 0) return null;

    const pacing = e2e + (think * txns);
    if (pacing <= 0) return null;

    const iterationsPerHour = 3600 / pacing;

    if (single.inputMode === "threads") {
      const threads = parseFloat(single.threads);
      if (!threads || threads <= 0) return null;

      const tph = threads * iterationsPerHour * txns;
      const tps = tph / 3600;
      const totalIterations = threads * (dur / pacing);
      const totalTransactions = totalIterations * txns;

      return {
        threads: Math.ceil(threads),
        tph: Math.round(tph),
        tps: parseFloat(tps.toFixed(2)),
        pacing: parseFloat(pacing.toFixed(2)),
        iterationsPerHour: parseFloat(iterationsPerHour.toFixed(2)),
        totalIterations: Math.round(totalIterations),
        totalTransactions: Math.round(totalTransactions),
        durationSeconds: dur,
        threadGroupRecommendation: getThreadGroupRecommendation(single.testType, Math.ceil(threads), dur),
        transactionsPerIteration: txns,
      };
    } else {
      const tph = parseFloat(single.tph);
      if (!tph || tph <= 0) return null;

      const threads = (tph * pacing) / (3600 * txns);
      const tps = tph / 3600;
      const totalIterations = Math.ceil(threads) * (dur / pacing);
      const totalTransactions = totalIterations * txns;

      return {
        threads: Math.ceil(threads),
        tph: Math.round(tph),
        tps: parseFloat(tps.toFixed(2)),
        pacing: parseFloat(pacing.toFixed(2)),
        iterationsPerHour: parseFloat(iterationsPerHour.toFixed(2)),
        totalIterations: Math.round(totalIterations),
        totalTransactions: Math.round(totalTransactions),
        durationSeconds: dur,
        threadGroupRecommendation: getThreadGroupRecommendation(single.testType, Math.ceil(threads), dur),
        transactionsPerIteration: txns,
      };
    }
  }, [single]);

  const weightedResult = useMemo((): CalculationResult | null => {
    const txns = weighted.transactions.filter(t => t.name.trim() && parseFloat(t.weight) > 0);
    if (txns.length === 0) return null;

    const totalWeight = txns.reduce((s, t) => s + parseFloat(t.weight || "0"), 0);
    if (Math.abs(totalWeight - 100) > 0.5) return null;

    const dur = parseFloat(weighted.testDuration) * 60;
    if (!dur || dur <= 0) return null;

    let weightedRT = 0;
    let weightedTT = 0;
    for (const t of txns) {
      const w = parseFloat(t.weight) / 100;
      const rt = parseFloat(t.responseTime);
      const tt = parseFloat(t.thinkTime);
      if (isNaN(rt) || rt < 0 || isNaN(tt) || tt < 0) return null;
      weightedRT += w * rt;
      weightedTT += w * tt;
    }

    const pacing = weightedRT + weightedTT;
    if (pacing <= 0) return null;

    const perTransaction: { name: string; tph: number; tps: number; weight: number }[] = [];

    if (weighted.inputMode === "threads") {
      const threads = parseFloat(weighted.threads);
      if (!threads || threads <= 0) return null;

      const iterationsPerHour = 3600 / pacing;
      const tph = threads * iterationsPerHour;
      const tps = tph / 3600;
      const totalIterations = threads * (dur / pacing);

      for (const t of txns) {
        const w = parseFloat(t.weight) / 100;
        perTransaction.push({
          name: t.name,
          tph: Math.round(tph * w),
          tps: parseFloat((tps * w).toFixed(2)),
          weight: parseFloat(t.weight),
        });
      }

      return {
        threads: Math.ceil(threads),
        tph: Math.round(tph),
        tps: parseFloat(tps.toFixed(2)),
        pacing: parseFloat(pacing.toFixed(2)),
        iterationsPerHour: parseFloat(iterationsPerHour.toFixed(2)),
        totalIterations: Math.round(totalIterations),
        totalTransactions: Math.round(totalIterations),
        durationSeconds: dur,
        threadGroupRecommendation: getThreadGroupRecommendation(weighted.testType, Math.ceil(threads), dur),
        perTransaction,
        weightedResponseTime: parseFloat(weightedRT.toFixed(3)),
        weightedThinkTime: parseFloat(weightedTT.toFixed(3)),
      };
    } else {
      const tph = parseFloat(weighted.tph);
      if (!tph || tph <= 0) return null;

      const threads = (tph * pacing) / 3600;
      const tps = tph / 3600;
      const iterationsPerHour = 3600 / pacing;
      const totalIterations = Math.ceil(threads) * (dur / pacing);

      for (const t of txns) {
        const w = parseFloat(t.weight) / 100;
        perTransaction.push({
          name: t.name,
          tph: Math.round(tph * w),
          tps: parseFloat((tps * w).toFixed(2)),
          weight: parseFloat(t.weight),
        });
      }

      return {
        threads: Math.ceil(threads),
        tph: Math.round(tph),
        tps: parseFloat(tps.toFixed(2)),
        pacing: parseFloat(pacing.toFixed(2)),
        iterationsPerHour: parseFloat(iterationsPerHour.toFixed(2)),
        totalIterations: Math.round(totalIterations),
        totalTransactions: Math.round(totalIterations),
        durationSeconds: dur,
        threadGroupRecommendation: getThreadGroupRecommendation(weighted.testType, Math.ceil(threads), dur),
        perTransaction,
        weightedResponseTime: parseFloat(weightedRT.toFixed(3)),
        weightedThinkTime: parseFloat(weightedTT.toFixed(3)),
      };
    }
  }, [weighted]);

  const result = calcMode === "single" ? singleResult : (calcMode === "weighted" ? weightedResult : null);

  const lastCalculatedThreads = singleResult?.threads ?? weightedResult?.threads ?? null;

  const addTransaction = () => {
    setWeighted(prev => ({
      ...prev,
      transactions: [...prev.transactions, { ...DEFAULT_WEIGHTED_TX, id: generateId() }],
    }));
  };

  const removeTransaction = (id: string) => {
    setWeighted(prev => ({
      ...prev,
      transactions: prev.transactions.filter(t => t.id !== id),
    }));
  };

  const updateTransaction = (id: string, field: keyof WeightedTransaction, value: string) => {
    setWeighted(prev => ({
      ...prev,
      transactions: prev.transactions.map(t => t.id === id ? { ...t, [field]: value } : t),
    }));
  };

  const weightTotal = weighted.transactions.reduce((s, t) => s + (parseFloat(t.weight) || 0), 0);

  const { data: scripts = [] } = useQuery<Array<{ id: number; name: string }>>({
    queryKey: ["/api/scripts"],
    queryFn: async () => {
      const res = await fetch("/api/scripts", { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: showSaveDialog,
  });

  const saveToScriptMutation = useMutation({
    mutationFn: async ({ scriptId, targets }: { scriptId: number; targets: Record<string, any> }) => {
      const res = await apiRequest("PATCH", `/api/scripts/${scriptId}`, { workloadTargets: targets });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Workload targets saved to script" });
      setShowSaveDialog(false);
      setSelectedScriptId("");
    },
    onError: (err: Error) => {
      toast({ title: "Failed to save", description: err.message, variant: "destructive" });
    },
  });

  const handleSaveToScript = () => {
    if (!result || !selectedScriptId) return;
    const targets: Record<string, any> = {
      threads: result.threads,
      tph: result.tph,
      tps: result.tps,
      pacing: result.pacing,
      testType: calcMode === "single" ? single.testType : weighted.testType,
    };
    if (calcMode === "single") {
      targets.transactionsPerIteration = parseInt(single.transactionsPerIteration) || 1;
      targets.e2eResponseTime = parseFloat(single.e2eResponseTime) || 0;
      targets.thinkTime = parseFloat(single.thinkTime) || 0;
    } else {
      targets.e2eResponseTime = result.weightedResponseTime || 0;
      targets.thinkTime = result.weightedThinkTime || 0;
    }
    if (result.perTransaction) {
      targets.perTransaction = result.perTransaction;
    }
    saveToScriptMutation.mutate({ scriptId: parseInt(selectedScriptId), targets });
  };

  const handleCopyResult = async () => {
    if (!result) return;
    const lines = [
      "=== Workload Model Calculator — PerfHub ===",
      `Mode: ${calcMode === "single" ? "Single Flow" : "Weighted Mix"}`,
      `Test Type: ${TEST_TYPES.find(t => t.value === (calcMode === "single" ? single.testType : weighted.testType))?.label}`,
      "",
      "--- Calculated Values ---",
      `Concurrent Threads: ${result.threads}`,
      `Transactions Per Hour (TPH): ${result.tph.toLocaleString()}`,
      `Transactions Per Second (TPS): ${result.tps}`,
      `Pacing: ${result.pacing}s`,
      `Iterations Per User Per Hour: ${result.iterationsPerHour}`,
      `Total Iterations: ${result.totalIterations.toLocaleString()}`,
      `Total Transactions: ${result.totalTransactions.toLocaleString()}`,
    ];

    if (result.weightedResponseTime !== undefined) {
      lines.push("", "--- Weighted Averages ---");
      lines.push(`Weighted Response Time: ${result.weightedResponseTime}s`);
      lines.push(`Weighted Think Time: ${result.weightedThinkTime}s`);
    }

    if (result.perTransaction && result.perTransaction.length > 0) {
      lines.push("", "--- Per Transaction ---");
      for (const t of result.perTransaction) {
        lines.push(`  ${t.name}: ${t.weight}% — ${t.tph.toLocaleString()} TPH (${t.tps} TPS)`);
      }
    }

    lines.push("", "--- Thread Group Recommendation ---");
    lines.push(`Model: ${result.threadGroupRecommendation.name}`);
    lines.push(`Reason: ${result.threadGroupRecommendation.reason}`);
    lines.push("", result.threadGroupRecommendation.config);

    const ok = await copyToClipboard(lines.join("\n"));
    if (ok) {
      setCopied(true);
      toast({ title: "Copied to clipboard" });
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const handleReset = () => {
    if (calcMode === "single") {
      setSingle(DEFAULT_SINGLE);
    } else {
      setWeighted({
        ...DEFAULT_WEIGHTED,
        transactions: [
          { ...DEFAULT_WEIGHTED_TX, id: generateId() },
          { ...DEFAULT_WEIGHTED_TX, id: generateId() },
        ],
      });
    }
  };

  return (
    <div className="section-gap">
      <PageHeader
        title="Workload Model Calculator"
        subtitle="Calculate thread counts, throughput, pacing, and get thread group recommendations"
        actions={
          <div className="flex items-center gap-2">
            {calcMode !== "distributed" && (
              <Button variant="outline" size="sm" onClick={handleReset}>
                <Settings2 className="h-4 w-4 mr-1" />Reset
              </Button>
            )}
            {result && calcMode !== "distributed" && (
              <>
                {canWrite && <Button variant="outline" size="sm" onClick={() => setShowSaveDialog(true)}>
                  <Save className="h-4 w-4 mr-1" />Save to Script
                </Button>}
                <Button size="sm" onClick={handleCopyResult}>
                  {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                  {copied ? "Copied" : "Copy Results"}
                </Button>
              </>
            )}
          </div>
        }
      />

      <Tabs value={calcMode} onValueChange={(v) => setCalcMode(v as CalcMode)}>
        <TabsList>
          <TabsTrigger value="single" className="gap-1.5">
            <Target className="h-3.5 w-3.5" />
            Single Flow
          </TabsTrigger>
          <TabsTrigger value="weighted" className="gap-1.5">
            <Layers className="h-3.5 w-3.5" />
            Weighted Mix
          </TabsTrigger>
          <TabsTrigger value="distributed" className="gap-1.5">
            <Server className="h-3.5 w-3.5" />
            Distributed Load
          </TabsTrigger>
        </TabsList>

        <TabsContent value="single" className="mt-4 space-y-4">
          <SingleFlowForm inputs={single} onChange={setSingle} result={singleResult} />
        </TabsContent>

        <TabsContent value="weighted" className="mt-4 space-y-4">
          <WeightedMixForm
            inputs={weighted}
            onChange={setWeighted}
            weightTotal={weightTotal}
            onAddTransaction={addTransaction}
            onRemoveTransaction={removeTransaction}
            onUpdateTransaction={updateTransaction}
          />
        </TabsContent>

        <TabsContent value="distributed" className="mt-4 space-y-4">
          <DistributedLoadCalculator
            totalThreadsFromModel={lastCalculatedThreads}
            pacingFromModel={result?.pacing ?? null}
          />
        </TabsContent>
      </Tabs>

      {result && calcMode !== "distributed" && <ResultsPanel result={result} calcMode={calcMode} testType={calcMode === "single" ? single.testType : weighted.testType} />}

      {calcMode !== "distributed" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card>
            <CardContent className="pt-5">
              <CalculationFlowDiagram mode={calcMode} />
            </CardContent>
          </Card>
          <FormulasReference />
        </div>
      )}

      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Save className="w-5 h-5 text-primary" />
              Save Workload Targets to Script
            </DialogTitle>
            <DialogDescription>
              Select a script to save the calculated workload model targets. These targets will be used for post-test achievement analysis on all executions of this script.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium">Select Script</Label>
              <Select value={selectedScriptId} onValueChange={setSelectedScriptId}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Choose a script..." />
                </SelectTrigger>
                <SelectContent>
                  {scripts.map((s) => (
                    <SelectItem key={s.id} value={String(s.id)}>
                      {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {result && (
              <div className="bg-muted/30 rounded-lg border p-3 text-xs space-y-1">
                <div className="font-medium text-sm mb-1.5">Targets to save:</div>
                <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 text-muted-foreground">
                  <span>Threads: <strong className="text-foreground">{result.threads}</strong></span>
                  <span>TPH: <strong className="text-foreground">{result.tph.toLocaleString()}</strong></span>
                  <span>TPS: <strong className="text-foreground">{result.tps}</strong></span>
                  <span>Pacing: <strong className="text-foreground">{result.pacing}s</strong></span>
                </div>
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowSaveDialog(false)}>Cancel</Button>
              <Button onClick={handleSaveToScript} disabled={!selectedScriptId || saveToScriptMutation.isPending}>
                {saveToScriptMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Save className="w-4 h-4 mr-1" />}
                Save
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function SingleFlowForm({ inputs, onChange, result }: { inputs: SingleFlowInputs; onChange: (v: SingleFlowInputs) => void; result: CalculationResult | null }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-4">
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-base flex items-center gap-2">
            <Calculator className="h-4 w-4 text-primary" />
            Input Parameters
          </CardTitle>
          <CardDescription>
            All values from the tester — no assumptions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div>
            <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 block">
              What do you know?
            </Label>
            <div className="flex gap-2">
              <Button
                variant={inputs.inputMode === "threads" ? "default" : "outline"}
                size="sm"
                onClick={() => onChange({ ...inputs, inputMode: "threads", tph: "" })}
                className="gap-1.5"
              >
                <Users className="h-3.5 w-3.5" />Number of Threads
              </Button>
              <Button
                variant={inputs.inputMode === "tph" ? "default" : "outline"}
                size="sm"
                onClick={() => onChange({ ...inputs, inputMode: "tph", threads: "" })}
                className="gap-1.5"
              >
                <TrendingUp className="h-3.5 w-3.5" />Transactions Per Hour (TPH)
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {inputs.inputMode === "threads" ? (
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <Users className="h-3.5 w-3.5 text-blue-500" />
                  Concurrent Threads
                </Label>
                <Input
                  type="number"
                  min="1"
                  placeholder="e.g., 200"
                  value={inputs.threads}
                  onChange={(e) => onChange({ ...inputs, threads: e.target.value })}
                />
              </div>
            ) : (
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <TrendingUp className="h-3.5 w-3.5 text-blue-500" />
                  Target TPH
                </Label>
                <Input
                  type="number"
                  min="1"
                  placeholder="e.g., 50000"
                  value={inputs.tph}
                  onChange={(e) => onChange({ ...inputs, tph: e.target.value })}
                />
              </div>
            )}

            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <Hash className="h-3.5 w-3.5 text-purple-500" />
                Transactions Per Iteration
              </Label>
              <Input
                type="number"
                min="1"
                placeholder="e.g., 6"
                value={inputs.transactionsPerIteration}
                onChange={(e) => onChange({ ...inputs, transactionsPerIteration: e.target.value })}
              />
            </div>

            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <Zap className="h-3.5 w-3.5 text-amber-500" />
                E2E Response Time (seconds)
              </Label>
              <Input
                type="number"
                min="0"
                step="0.1"
                placeholder="e.g., 3"
                value={inputs.e2eResponseTime}
                onChange={(e) => onChange({ ...inputs, e2eResponseTime: e.target.value })}
              />
              <p className="text-[10px] text-muted-foreground">Sum of all response times across all transactions in one iteration (excludes think time)</p>
            </div>

            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5 text-teal-500" />
                Think Time Per Transaction (seconds)
              </Label>
              <Input
                type="number"
                min="0"
                step="0.1"
                placeholder="e.g., 5"
                value={inputs.thinkTime}
                onChange={(e) => onChange({ ...inputs, thinkTime: e.target.value })}
              />
              <p className="text-[10px] text-muted-foreground">User pause after each transaction (applied N times, once per transaction in the iteration)</p>
            </div>

            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <Timer className="h-3.5 w-3.5 text-orange-500" />
                Test Duration (minutes)
              </Label>
              <Input
                type="number"
                min="1"
                placeholder="e.g., 60"
                value={inputs.testDuration}
                onChange={(e) => onChange({ ...inputs, testDuration: e.target.value })}
              />
            </div>

            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <Activity className="h-3.5 w-3.5 text-red-500" />
                Test Type
              </Label>
              <Select value={inputs.testType} onValueChange={(v) => onChange({ ...inputs, testType: v as TestType })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TEST_TYPES.map(t => (
                    <SelectItem key={t.value} value={t.value}>
                      <div className="flex flex-col">
                        <span>{t.label}</span>
                        <span className="text-[10px] text-muted-foreground">{t.description}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <LivePreview result={result} inputs={inputs} mode="single" />
    </div>
  );
}

function WeightedMixForm({
  inputs, onChange, weightTotal, onAddTransaction, onRemoveTransaction, onUpdateTransaction,
}: {
  inputs: WeightedInputs;
  onChange: (v: WeightedInputs) => void;
  weightTotal: number;
  onAddTransaction: () => void;
  onRemoveTransaction: (id: string) => void;
  onUpdateTransaction: (id: string, field: keyof WeightedTransaction, value: string) => void;
}) {
  const weightValid = Math.abs(weightTotal - 100) <= 0.5;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-base flex items-center gap-2">
            <Calculator className="h-4 w-4 text-primary" />
            Global Parameters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 block">
                What do you know?
              </Label>
              <div className="flex gap-2">
                <Button
                  variant={inputs.inputMode === "threads" ? "default" : "outline"}
                  size="sm"
                  onClick={() => onChange({ ...inputs, inputMode: "threads", tph: "" })}
                  className="gap-1.5"
                >
                  <Users className="h-3.5 w-3.5" />Number of Threads
                </Button>
                <Button
                  variant={inputs.inputMode === "tph" ? "default" : "outline"}
                  size="sm"
                  onClick={() => onChange({ ...inputs, inputMode: "tph", threads: "" })}
                  className="gap-1.5"
                >
                  <TrendingUp className="h-3.5 w-3.5" />Transactions Per Hour (TPH)
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {inputs.inputMode === "threads" ? (
                <div className="space-y-1.5">
                  <Label className="flex items-center gap-1.5">
                    <Users className="h-3.5 w-3.5 text-blue-500" />
                    Concurrent Threads
                  </Label>
                  <Input
                    type="number"
                    min="1"
                    placeholder="e.g., 200"
                    value={inputs.threads}
                    onChange={(e) => onChange({ ...inputs, threads: e.target.value })}
                  />
                </div>
              ) : (
                <div className="space-y-1.5">
                  <Label className="flex items-center gap-1.5">
                    <TrendingUp className="h-3.5 w-3.5 text-blue-500" />
                    Total Target TPH
                  </Label>
                  <Input
                    type="number"
                    min="1"
                    placeholder="e.g., 50000"
                    value={inputs.tph}
                    onChange={(e) => onChange({ ...inputs, tph: e.target.value })}
                  />
                </div>
              )}

              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <Timer className="h-3.5 w-3.5 text-orange-500" />
                  Test Duration (minutes)
                </Label>
                <Input
                  type="number"
                  min="1"
                  placeholder="e.g., 60"
                  value={inputs.testDuration}
                  onChange={(e) => onChange({ ...inputs, testDuration: e.target.value })}
                />
              </div>

              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <Activity className="h-3.5 w-3.5 text-red-500" />
                  Test Type
                </Label>
                <Select value={inputs.testType} onValueChange={(v) => onChange({ ...inputs, testType: v as TestType })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TEST_TYPES.map(t => (
                      <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Layers className="h-4 w-4 text-primary" />
                Transaction Mix
              </CardTitle>
              <CardDescription className="mt-1">
                Define each transaction with its weight, response time, and think time
              </CardDescription>
            </div>
            <div className="flex items-center gap-3">
              <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium ${weightValid ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20' : 'bg-red-50 dark:bg-red-500/10 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-500/20'}`}>
                {weightValid ? <Check className="h-3 w-3" /> : <AlertTriangle className="h-3 w-3" />}
                Total: {weightTotal.toFixed(1)}%
              </div>
              <Button variant="outline" size="sm" onClick={onAddTransaction} className="gap-1.5">
                <Plus className="h-3.5 w-3.5" />Add
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-500/15 text-[11px] text-muted-foreground leading-relaxed">
              <Info className="h-3.5 w-3.5 text-blue-500 mt-0.5 shrink-0" />
              <span>
                <strong className="text-foreground">Pacing model:</strong> each row is one discrete transaction choice per iteration. Think time is the pause <em>after that transaction</em>, not multiplied by a transaction count. This differs from Single Flow, where think time is applied after each individual step within a multi-step iteration.
              </span>
            </div>
            <div className="grid grid-cols-[1fr_80px_100px_100px_36px] gap-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-1">
              <span>Transaction Name</span>
              <span>Weight %</span>
              <span>Response Time (s)</span>
              <span>Think Time (s)</span>
              <span></span>
            </div>
            {inputs.transactions.map((t) => (
              <div key={t.id} className="grid grid-cols-[1fr_80px_100px_100px_36px] gap-2 items-center">
                <Input
                  placeholder="e.g., Browse Products"
                  value={t.name}
                  onChange={(e) => onUpdateTransaction(t.id, "name", e.target.value)}
                  className="h-9"
                />
                <Input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  placeholder="%"
                  value={t.weight}
                  onChange={(e) => onUpdateTransaction(t.id, "weight", e.target.value)}
                  className="h-9"
                />
                <Input
                  type="number"
                  min="0"
                  step="0.1"
                  placeholder="sec"
                  value={t.responseTime}
                  onChange={(e) => onUpdateTransaction(t.id, "responseTime", e.target.value)}
                  className="h-9"
                />
                <Input
                  type="number"
                  min="0"
                  step="0.1"
                  placeholder="sec"
                  value={t.thinkTime}
                  onChange={(e) => onUpdateTransaction(t.id, "thinkTime", e.target.value)}
                  className="h-9"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-9 w-9 p-0 text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10"
                  onClick={() => onRemoveTransaction(t.id)}
                  disabled={inputs.transactions.length <= 1}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
          </div>
          {!weightValid && weightTotal > 0 && (
            <div className="mt-3 flex items-center gap-2 text-xs text-red-600 dark:text-red-400">
              <AlertTriangle className="h-3.5 w-3.5" />
              Weights must total 100%. Currently: {weightTotal.toFixed(1)}%
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function LivePreview({ result, inputs, mode }: { result: CalculationResult | null; inputs: SingleFlowInputs; mode: string }) {
  if (mode !== "single") return null;

  const txns = parseFloat(inputs.transactionsPerIteration) || 0;
  const e2e = parseFloat(inputs.e2eResponseTime) || 0;
  const think = parseFloat(inputs.thinkTime) || 0;

  const pacing = result ? result.pacing : (txns > 0 ? parseFloat((e2e + (think * txns)).toFixed(2)) : 0);

  return (
    <Card className="h-fit">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Info className="h-4 w-4 text-blue-500" />
          How Pacing is Calculated
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="p-3 rounded-lg bg-muted/50 border space-y-2">
          <p className="text-[11px] text-muted-foreground font-medium">Formula:</p>
          <p className="text-xs font-mono">
            Pacing = E2E RT + (Think Time × Transactions/Iter)
          </p>
          {pacing > 0 && (
            <>
              <Separator />
              <p className="text-xs font-mono text-primary">
                = {e2e}s + ({think}s × {txns})
              </p>
              <p className="text-xs font-mono text-primary font-bold">
                = {pacing}s per iteration
              </p>
            </>
          )}
        </div>
        <div className="p-3 rounded-lg bg-muted/50 border space-y-2">
          <p className="text-[11px] text-muted-foreground font-medium">
            {inputs.inputMode === "threads" ? "TPH Formula:" : "Threads Formula:"}
          </p>
          <p className="text-xs font-mono">
            {inputs.inputMode === "threads"
              ? "TPH = Threads × (3600 / Pacing) × Txns/Iter"
              : "Threads = (TPH × Pacing) / (3600 × Txns/Iter)"
            }
          </p>
        </div>
        <div className="p-3 rounded-lg bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-500/15 space-y-1.5">
          <p className="text-[11px] font-medium text-blue-700 dark:text-blue-400">Verification:</p>
          <p className="text-[11px] text-muted-foreground">
            Results are always cross-verified. If you provide Threads, the calculated TPH is verified back to Threads. If you provide TPH, the calculated Threads are verified back to TPH.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

function ResultsPanel({ result, calcMode, testType }: { result: CalculationResult; calcMode: CalcMode; testType: TestType }) {
  return (
    <div className="space-y-4" style={{ animation: 'fadeSlideIn 0.3s ease-out both' }}>
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <Separator />

      <div className="flex items-center gap-2">
        <BarChart3 className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold">Calculated Workload Model</h2>
      </div>

      <div className={`grid grid-cols-2 gap-3 ${calcMode === "weighted" ? "sm:grid-cols-3 lg:grid-cols-6" : "sm:grid-cols-4 lg:grid-cols-7"}`}>
        {[
          { label: "Threads", value: result.threads.toLocaleString(), icon: Users, color: "text-blue-600 dark:text-blue-400" },
          { label: "TPH", value: result.tph.toLocaleString(), icon: TrendingUp, color: "text-emerald-600 dark:text-emerald-400" },
          { label: "TPS", value: result.tps.toString(), icon: Zap, color: "text-amber-600 dark:text-amber-400" },
          { label: "Pacing", value: `${result.pacing}s`, icon: Clock, color: "text-teal-600 dark:text-teal-400" },
          { label: "Iter/User/Hr", value: result.iterationsPerHour.toString(), icon: ArrowRight, color: "text-purple-600 dark:text-purple-400" },
          { label: "Total Iterations", value: result.totalIterations.toLocaleString(), icon: Hash, color: "text-orange-600 dark:text-orange-400" },
          ...(calcMode === "single" ? [{ label: "Total Transactions", value: result.totalTransactions.toLocaleString(), icon: Activity, color: "text-red-600 dark:text-red-400" }] : []),
        ].map((kpi, i) => {
          const KpiIcon = kpi.icon;
          return (
            <div key={i} className="rounded-lg border bg-card p-3">
              <div className="flex items-center gap-1.5 mb-1.5">
                <KpiIcon className={`h-3.5 w-3.5 ${kpi.color}`} />
                <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">{kpi.label}</span>
              </div>
              <div className={`text-lg font-bold ${kpi.color}`}>{kpi.value}</div>
            </div>
          );
        })}
      </div>

      {result.weightedResponseTime !== undefined && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Layers className="h-4 w-4 text-primary" />
              Weighted Averages & Per-Transaction Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="p-3 rounded-lg bg-muted/30 border text-center">
                <div className="text-lg font-bold text-primary">{result.weightedResponseTime}s</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Weighted Response Time</div>
              </div>
              <div className="p-3 rounded-lg bg-muted/30 border text-center">
                <div className="text-lg font-bold text-primary">{result.weightedThinkTime}s</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Weighted Think Time</div>
              </div>
            </div>

            {result.perTransaction && result.perTransaction.length > 0 && (
              <div className="overflow-x-auto rounded-lg border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/30 border-b">
                      <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Transaction</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Weight</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">TPH</th>
                      <th className="text-right py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">TPS</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.perTransaction.map((t, i) => (
                      <tr key={i} className="border-b hover:bg-muted/20 transition-colors">
                        <td className="py-2.5 px-3 font-medium">{t.name}</td>
                        <td className="py-2.5 px-3 text-right font-mono">{t.weight}%</td>
                        <td className="py-2.5 px-3 text-right font-mono">{t.tph.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right font-mono">{t.tps}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <ThreadGroupRecommendationCard rec={result.threadGroupRecommendation} testType={testType} threads={result.threads} tps={result.tps} pacing={result.pacing} durationSeconds={result.durationSeconds} transactionsPerIteration={result.transactionsPerIteration ?? 1} perTransaction={result.perTransaction} calcMode={calcMode} />

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Check className="h-4 w-4 text-emerald-500" />
            Cross-Verification
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-3 rounded-lg bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-500/15">
            <p className="text-xs font-mono leading-relaxed">
              {calcMode === "single" ? (
                <>
                  Verify: Threads × (3600 / Pacing) × Txns/Iter = TPH{"\n"}
                  <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                    {result.threads} × (3600 / {result.pacing}) × {result.transactionsPerIteration ?? 1} = {result.tph.toLocaleString()} TPH ✓
                  </span>
                </>
              ) : (
                <>
                  Verify: (TPH × Pacing) / 3600 = Threads{"\n"}
                  <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                    ({result.tph.toLocaleString()} × {result.pacing}) / 3600 = {result.threads} threads ✓
                  </span>
                </>
              )}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

interface PhaseInfo {
  startPct: number;
  endPct: number;
  label: string;
  threads: number;
  startSec: number;
  endSec: number;
}

function buildPhases(testType: TestType, threads: number, duration: number): {
  points: [number, number][];
  phases: PhaseInfo[];
  maxY: number;
} {
  const rawRampUp = Math.max(Math.round(duration * 0.1), 60);
  const rampUp = Math.min(rawRampUp, Math.round(duration * 0.3));
  const rampPct = rampUp / duration;
  const downDur = Math.min(Math.round(rampUp * 0.5), Math.round(duration * 0.05));
  const downPct = downDur / duration;

  switch (testType) {
    case "load":
    case "endurance": {
      return {
        points: [[0, 0], [rampPct, threads], [1 - downPct, threads], [1, 0]],
        phases: [
          { startPct: 0, endPct: rampPct, label: "Ramp-up", threads: 0, startSec: 0, endSec: rampUp },
          { startPct: rampPct, endPct: 1 - downPct, label: "Steady State", threads, startSec: rampUp, endSec: duration - downDur },
          { startPct: 1 - downPct, endPct: 1, label: "Ramp-down", threads: 0, startSec: duration - downDur, endSec: duration },
        ],
        maxY: threads,
      };
    }
    case "stress": {
      const steps = 10;
      const stepSize = Math.max(Math.round(threads / steps), 5);
      const stepDur = duration / steps;
      const pts: [number, number][] = [];
      const phases: PhaseInfo[] = [];
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const level = Math.min(stepSize * i, threads);
        const prevLevel = i > 0 ? Math.min(stepSize * (i - 1), threads) : 0;
        if (i > 0) {
          pts.push([t - 0.005, prevLevel]);
          phases.push({
            startPct: (i - 1) / steps,
            endPct: t,
            label: `Step ${i}`,
            threads: prevLevel,
            startSec: Math.round((i - 1) * stepDur),
            endSec: Math.round(i * stepDur),
          });
        }
        pts.push([t, level]);
      }
      const holdPct = 0.25;
      pts.push([1, threads]);
      phases.push({
        startPct: 1 - holdPct,
        endPct: 1,
        label: "Peak Hold",
        threads,
        startSec: Math.round(duration * (1 - holdPct)),
        endSec: duration,
      });
      return { points: pts, phases, maxY: threads };
    }
    case "spike": {
      const baseline = Math.round(threads * 0.2);
      const baseEnd = 0.3;
      const spikeStart = 0.33;
      const spikeEnd = 0.6;
      const recStart = 0.63;
      const recEnd = 0.9;
      return {
        points: [
          [0, 0], [0.05, baseline], [baseEnd, baseline],
          [spikeStart, threads], [spikeEnd, threads],
          [recStart, baseline], [recEnd, baseline], [1, 0],
        ],
        phases: [
          { startPct: 0, endPct: baseEnd, label: "Baseline", threads: baseline, startSec: 0, endSec: Math.round(baseEnd * duration) },
          { startPct: spikeStart, endPct: spikeEnd, label: "Spike", threads, startSec: Math.round(spikeStart * duration), endSec: Math.round(spikeEnd * duration) },
          { startPct: recStart, endPct: recEnd, label: "Recovery", threads: baseline, startSec: Math.round(recStart * duration), endSec: Math.round(recEnd * duration) },
        ],
        maxY: threads,
      };
    }
    case "scalability": {
      const levels = [0.25, 0.5, 0.75, 1.0];
      const pts: [number, number][] = [[0, 0]];
      const phases: PhaseInfo[] = [];
      levels.forEach((lvl, i) => {
        const startPct = i * 0.25 + (i === 0 ? 0.02 : 0);
        const endPct = (i + 1) * 0.25 - (i < 3 ? 0.02 : 0.05);
        const t = Math.round(threads * lvl);
        if (i > 0) pts.push([startPct - 0.01, Math.round(threads * levels[i - 1])]);
        pts.push([startPct, t]);
        pts.push([endPct, t]);
        phases.push({
          startPct, endPct, label: `${Math.round(lvl * 100)}%`, threads: t,
          startSec: Math.round(startPct * duration), endSec: Math.round(endPct * duration),
        });
      });
      pts.push([1, 0]);
      return { points: pts, phases, maxY: threads };
    }
    case "breakpoint": {
      const peak = Math.round(threads * 1.5);
      const steps = 15;
      const stepDur = duration / steps;
      const pts: [number, number][] = [];
      const phases: PhaseInfo[] = [];
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const level = Math.round((i / steps) * peak);
        const prevLevel = i > 0 ? Math.round(((i - 1) / steps) * peak) : 0;
        if (i > 0) pts.push([t - 0.005, prevLevel]);
        pts.push([t, level]);
        if (i > 0 && i <= 5) {
          phases.push({ startPct: (i - 1) / steps, endPct: t, label: `Step ${i}`, threads: prevLevel, startSec: Math.round((i - 1) * stepDur), endSec: Math.round(i * stepDur) });
        }
      }
      phases.push({ startPct: 5 / steps, endPct: 10 / steps, label: "Target Zone", threads, startSec: Math.round(5 * stepDur), endSec: Math.round(10 * stepDur) });
      phases.push({ startPct: 10 / steps, endPct: 1, label: "Beyond Target", threads: peak, startSec: Math.round(10 * stepDur), endSec: duration });
      return { points: pts, phases, maxY: peak };
    }
  }
}

function formatDuration(sec: number): string {
  if (sec >= 3600) return `${(sec / 3600).toFixed(1)}h`;
  if (sec >= 60) return `${Math.round(sec / 60)}m`;
  return `${sec}s`;
}

interface LoadProfileProps {
  testType: TestType;
  threads: number;
  tps: number;
  pacing: number;
  durationSeconds: number;
  transactionsPerIteration: number;
  perTransaction?: { name: string; tph: number; tps: number; weight: number }[];
  calcMode: string;
}

function LoadProfileSVG({ testType, threads, tps, pacing, durationSeconds, transactionsPerIteration, perTransaction, calcMode }: LoadProfileProps) {
  const [hoveredPhase, setHoveredPhase] = useState<number | null>(null);
  const [showThroughput, setShowThroughput] = useState(true);

  const txnsPerIter = transactionsPerIteration > 0 ? transactionsPerIteration : 1;
  const duration = durationSeconds > 0 ? durationSeconds : 3600;

  const { points, phases, maxY } = buildPhases(testType, threads, duration);

  const W = 560;
  const H = 220;
  const pad = { top: 25, right: 60, bottom: 40, left: 55 };
  const cw = W - pad.left - pad.right;
  const ch = H - pad.top - pad.bottom;

  const yScale = (v: number) => pad.top + ch - (v / (maxY || 1)) * ch;
  const xScale = (pct: number) => pad.left + Math.max(0, Math.min(1, pct)) * cw;

  const tpsAtPhase = (threadCount: number) => {
    if (pacing <= 0) return 0;
    return (threadCount * txnsPerIter) / pacing;
  };
  const maxTps = tpsAtPhase(maxY);

  const yScaleTps = (v: number) => pad.top + ch - (v / (maxTps || 1)) * ch;

  const linePath = points
    .map(([x, y], i) => `${i === 0 ? "M" : "L"}${xScale(x).toFixed(1)},${yScale(y).toFixed(1)}`)
    .join(" ");

  const areaPoints = [...points, [1, 0], [0, 0]] as [number, number][];
  const areaPath = areaPoints
    .map(([x, y], i) => `${i === 0 ? "M" : "L"}${xScale(x).toFixed(1)},${yScale(y).toFixed(1)}`)
    .join(" ") + " Z";

  const tpsLinePath = showThroughput ? points
    .map(([x, y], i) => `${i === 0 ? "M" : "L"}${xScale(x).toFixed(1)},${yScaleTps(tpsAtPhase(y)).toFixed(1)}`)
    .join(" ") : "";

  const yTicks = [0, Math.round(maxY * 0.5), maxY];
  const tpsTicks = [0, parseFloat((maxTps * 0.5).toFixed(1)), parseFloat(maxTps.toFixed(1))];

  const timeMarks = [0, 0.25, 0.5, 0.75, 1.0];

  const txColors = ["hsl(217,91%,60%)", "hsl(142,71%,45%)", "hsl(38,92%,50%)", "hsl(0,72%,51%)", "hsl(262,83%,58%)", "hsl(190,90%,50%)", "hsl(330,80%,55%)", "hsl(45,93%,47%)"];

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-0.5 bg-blue-500 rounded" />
            <span className="text-[10px] text-muted-foreground">Threads</span>
          </div>
          {showThroughput && (
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-0.5 rounded" style={{ background: "hsl(142, 71%, 45%)" }} />
              <span className="text-[10px] text-muted-foreground">TPS</span>
            </div>
          )}
        </div>
        <button
          onClick={() => setShowThroughput(!showThroughput)}
          className="text-[10px] text-muted-foreground hover:text-foreground transition-colors px-1.5 py-0.5 rounded border border-transparent hover:border-border"
        >
          {showThroughput ? "Hide TPS" : "Show TPS"}
        </button>
      </div>

      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ maxHeight: 260 }}>
        <defs>
          <linearGradient id={`fill-${testType}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="hsl(217, 91%, 60%)" stopOpacity="0.2" />
            <stop offset="100%" stopColor="hsl(217, 91%, 60%)" stopOpacity="0.02" />
          </linearGradient>
        </defs>

        {yTicks.map((v) => (
          <g key={`yt-${v}`}>
            <line x1={pad.left} y1={yScale(v)} x2={W - pad.right} y2={yScale(v)} stroke="hsl(215, 15%, 85%)" strokeWidth="0.5" strokeDasharray="3,3" />
            <text x={pad.left - 6} y={yScale(v) + 3} textAnchor="end" fontSize="8" fill="hsl(217, 91%, 60%)" fontFamily="monospace">{v}</text>
          </g>
        ))}

        {showThroughput && tpsTicks.map((v) => (
          <g key={`tps-${v}`}>
            <text x={W - pad.right + 6} y={yScaleTps(v) + 3} textAnchor="start" fontSize="8" fill="hsl(142, 71%, 45%)" fontFamily="monospace">{v}</text>
          </g>
        ))}

        <line x1={pad.left} y1={H - pad.bottom} x2={W - pad.right} y2={H - pad.bottom} stroke="hsl(215, 15%, 80%)" strokeWidth="1" />
        <line x1={pad.left} y1={pad.top} x2={pad.left} y2={H - pad.bottom} stroke="hsl(215, 15%, 80%)" strokeWidth="1" />
        {showThroughput && <line x1={W - pad.right} y1={pad.top} x2={W - pad.right} y2={H - pad.bottom} stroke="hsl(142, 71%, 45%)" strokeWidth="0.5" strokeDasharray="2,4" />}

        {timeMarks.map((pct) => (
          <text key={`tm-${pct}`} x={xScale(pct)} y={H - pad.bottom + 14} textAnchor="middle" fontSize="8" fill="hsl(215, 15%, 55%)" fontFamily="monospace">
            {formatDuration(Math.round(pct * duration))}
          </text>
        ))}

        <path d={areaPath} fill={`url(#fill-${testType})`} />
        <path d={linePath} fill="none" stroke="hsl(217, 91%, 60%)" strokeWidth="2" strokeLinejoin="round" />

        {showThroughput && tpsLinePath && (
          <path d={tpsLinePath} fill="none" stroke="hsl(142, 71%, 45%)" strokeWidth="1.5" strokeLinejoin="round" strokeDasharray="4,3" />
        )}

        {phases.map((phase, i) => {
          const x1 = xScale(phase.startPct);
          const x2 = xScale(phase.endPct);
          const isHovered = hoveredPhase === i;
          return (
            <g key={`phase-${i}`}>
              <rect
                x={x1} y={pad.top} width={Math.max(0, x2 - x1)} height={ch}
                fill={isHovered ? "hsl(217, 91%, 60%)" : "transparent"}
                fillOpacity={isHovered ? 0.08 : 0}
                onMouseEnter={() => setHoveredPhase(i)}
                onMouseLeave={() => setHoveredPhase(null)}
                style={{ cursor: "default" }}
              />
              {(testType === "load" || testType === "endurance" || testType === "spike" || testType === "scalability") && (
                <text
                  x={(x1 + x2) / 2} y={H - pad.bottom + 28}
                  textAnchor="middle" fontSize="8" fill="hsl(217, 91%, 60%)" fontWeight="600" fontFamily="system-ui"
                >
                  {phase.label}
                </text>
              )}
            </g>
          );
        })}

        {hoveredPhase !== null && phases[hoveredPhase] && (() => {
          const phase = phases[hoveredPhase];
          const cx = xScale((phase.startPct + phase.endPct) / 2);
          const tooltipW = 160;
          const tooltipH = 46;
          const tx = Math.min(Math.max(cx - tooltipW / 2, pad.left), W - pad.right - tooltipW);
          const ty = pad.top + 4;
          const isRamp = phase.label === "Ramp-up" || phase.label === "Ramp-down";
          const displayThreads = isRamp ? Math.round(threads / 2) : phase.threads;
          const phaseTps = tpsAtPhase(displayThreads);
          const phaseDurSec = phase.endSec - phase.startSec;
          const threadLabel = isRamp
            ? (phase.label === "Ramp-up" ? `0 → ${threads}` : `${threads} → 0`)
            : `${phase.threads}`;
          return (
            <g>
              <rect x={tx} y={ty} width={tooltipW} height={tooltipH} rx="4" fill="hsl(222, 47%, 11%)" fillOpacity="0.95" />
              <text x={tx + 8} y={ty + 14} fontSize="9" fill="white" fontWeight="600" fontFamily="system-ui">{phase.label}</text>
              <text x={tx + 8} y={ty + 26} fontSize="8" fill="hsl(215, 20%, 75%)" fontFamily="monospace">
                {threadLabel} threads · {formatDuration(phaseDurSec)}
              </text>
              <text x={tx + 8} y={ty + 38} fontSize="8" fill="hsl(142, 71%, 65%)" fontFamily="monospace">
                {isRamp ? "avg " : ""}~{phaseTps.toFixed(1)} TPS · ~{Math.round(phaseTps * 3600).toLocaleString()} TPH
              </text>
            </g>
          );
        })()}

        <text x={pad.left - 6} y={pad.top - 8} textAnchor="end" fontSize="7" fill="hsl(217, 91%, 60%)" fontFamily="monospace">Threads</text>
        {showThroughput && <text x={W - pad.right + 6} y={pad.top - 8} textAnchor="start" fontSize="7" fill="hsl(142, 71%, 45%)" fontFamily="monospace">TPS</text>}
        <text x={W / 2} y={H - 2} textAnchor="middle" fontSize="8" fill="hsl(215, 15%, 55%)" fontFamily="monospace">Duration</text>
      </svg>

      {calcMode === "weighted" && perTransaction && perTransaction.length > 0 && (
        <WeightedMixBreakdown perTransaction={perTransaction} threads={threads} colors={txColors} />
      )}
    </div>
  );
}

function WeightedMixBreakdown({ perTransaction, threads, colors }: {
  perTransaction: { name: string; tph: number; tps: number; weight: number }[];
  threads: number;
  colors: string[];
}) {
  const W = 560;
  const H = 100;
  const pad = { top: 12, right: 10, bottom: 24, left: 10 };
  const cw = W - pad.left - pad.right;
  const barH = H - pad.top - pad.bottom;

  const sorted = [...perTransaction].sort((a, b) => b.weight - a.weight);
  let cumPct = 0;

  return (
    <div className="space-y-1.5">
      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Transaction Mix</p>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ maxHeight: 100 }}>
        {sorted.map((tx, i) => {
          const x = pad.left + (cumPct / 100) * cw;
          const w = (tx.weight / 100) * cw;
          cumPct += tx.weight;
          const color = colors[i % colors.length];
          return (
            <g key={tx.name}>
              <rect x={x} y={pad.top} width={Math.max(0, w - 1)} height={barH} rx="3" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="1" />
              {w > 40 && (
                <>
                  <text x={x + w / 2} y={pad.top + barH / 2 - 4} textAnchor="middle" fontSize="8" fill={color} fontWeight="600" fontFamily="system-ui">
                    {tx.name.length > 12 ? tx.name.slice(0, 11) + "…" : tx.name}
                  </text>
                  <text x={x + w / 2} y={pad.top + barH / 2 + 8} textAnchor="middle" fontSize="8" fill={color} fontFamily="monospace" fillOpacity="0.8">
                    {tx.weight}% · {Math.round(threads * tx.weight / 100)} threads
                  </text>
                </>
              )}
              <text x={x + w / 2} y={H - pad.bottom + 14} textAnchor="middle" fontSize="7" fill={color} fontFamily="monospace">
                {tx.tps} TPS
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function ThreadGroupRecommendationCard({ rec, testType, threads, tps, pacing, durationSeconds, transactionsPerIteration, perTransaction, calcMode }: {
  rec: ThreadGroupRec;
  testType: TestType;
  threads: number;
  tps: number;
  pacing: number;
  durationSeconds: number;
  transactionsPerIteration: number;
  perTransaction?: { name: string; tph: number; tps: number; weight: number }[];
  calcMode: string;
}) {
  const testTypeInfo = TEST_TYPES.find(t => t.value === testType);

  return (
    <Card className="border-2 border-blue-200 dark:border-blue-500/30 shadow-sm">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-blue-100 dark:bg-blue-500/15 flex items-center justify-center">
              <Settings2 className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            </div>
            Recommended Thread Group Model
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">
              {testTypeInfo?.label}
            </Badge>
            {rec.pluginRequired ? (
              <Badge className="bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-500/20 text-[10px]">
                Plugin Required
              </Badge>
            ) : (
              <Badge className="bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20 text-[10px]">
                Built-in
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="p-4 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/20 border border-blue-100 dark:border-blue-500/15">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <span className="font-semibold text-blue-900 dark:text-blue-300 text-lg">{rec.name}</span>
          </div>
          <p className="text-sm text-slate-600 dark:text-slate-400">{rec.description}</p>
        </div>

        <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/30 border">
          <Info className="h-4 w-4 text-blue-500 mt-0.5 shrink-0" />
          <p className="text-xs text-muted-foreground leading-relaxed">{rec.reason}</p>
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Load Profile &amp; Throughput</p>
          <div className="rounded-lg border bg-white dark:bg-slate-900/50 p-3">
            <LoadProfileSVG testType={testType} threads={threads} tps={tps} pacing={pacing} durationSeconds={durationSeconds} transactionsPerIteration={transactionsPerIteration} perTransaction={perTransaction} calcMode={calcMode} />
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Configuration</p>
          <pre className="bg-slate-900 p-4 rounded-lg text-xs text-emerald-400 overflow-x-auto border border-slate-700 font-mono leading-relaxed min-h-[120px]">
            {rec.config}
          </pre>
        </div>

        {rec.pluginRequired && rec.pluginName && (
          <div className="p-3 rounded-lg bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-500/15">
            <div className="flex items-center gap-2 mb-1">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
              <span className="text-xs font-semibold text-amber-700 dark:text-amber-400">Plugin Required: {rec.pluginName}</span>
            </div>
            {rec.pluginUrl && (
              <p className="text-[11px] text-amber-600 dark:text-amber-400/80 ml-5">
                Install via JMeter Plugins Manager or download from{" "}
                <a href={rec.pluginUrl} target="_blank" rel="noopener noreferrer" className="underline hover:no-underline">
                  jmeter-plugins.org
                </a>
              </p>
            )}
          </div>
        )}

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-1.5">
            <GitBranch className="h-3.5 w-3.5" />
            JMeter Setup Steps
          </p>
          <div className="space-y-0">
            {rec.jmeterSetup.map((step, i) => {
              const isSubStep = step.startsWith("  ");
              return (
                <div key={i} className={`flex items-start gap-2.5 py-1.5 ${isSubStep ? "ml-6" : ""}`}>
                  {!isSubStep && (
                    <div className="h-5 w-5 rounded-full bg-blue-100 dark:bg-blue-500/15 flex items-center justify-center text-[10px] font-bold text-blue-600 dark:text-blue-400 shrink-0 mt-0.5">
                      {i + 1 - rec.jmeterSetup.slice(0, i).filter(s => s.startsWith("  ")).length}
                    </div>
                  )}
                  {isSubStep && (
                    <ChevronRight className="h-3 w-3 text-muted-foreground shrink-0 mt-1" />
                  )}
                  <span className={`text-xs leading-relaxed ${isSubStep ? "text-muted-foreground" : ""}`}>{isSubStep ? step.trim() : step}</span>
                </div>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function CalculationFlowDiagram({ mode }: { mode: CalcMode }) {
  if (mode === "single") {
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Workflow className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold">Calculation Flow</span>
        </div>
        <div className="flex flex-col items-center gap-0">
          <FlowNode color="blue" label="Inputs" detail="Threads or TPH, E2E RT, Think Time, Txns/Iteration, Duration, Test Type" />
          <FlowArrow />
          <FlowNode color="purple" label="Step 1: Pacing" detail="Pacing = E2E RT + (Think Time × Txns Per Iteration)" />
          <FlowArrow />
          <FlowNode color="teal" label="Step 2: Iterations/Hour" detail="Iterations/Hour = 3600 / Pacing" />
          <FlowArrow />
          <div className="grid grid-cols-2 gap-3 w-full">
            <div className="flex flex-col items-center gap-0">
              <FlowNode color="emerald" label="If Threads given" detail="TPH = Threads × Iter/Hr × Txns" />
            </div>
            <div className="flex flex-col items-center gap-0">
              <FlowNode color="amber" label="If TPH given" detail="Threads = (TPH × Pacing) / (3600 × Txns)" />
            </div>
          </div>
          <FlowArrow />
          <FlowNode color="orange" label="Step 3: TPS" detail="TPS = TPH / 3600" />
          <FlowArrow />
          <FlowNode color="rose" label="Step 4: Totals" detail="Total Iterations = Threads × (Duration / Pacing), Total Txns = Iterations × Txns/Iter" />
          <FlowArrow />
          <FlowNode color="indigo" label="Output" detail="Thread Group Recommendation based on Test Type + Load Profile Diagram" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Workflow className="h-4 w-4 text-primary" />
        <span className="text-sm font-semibold">Calculation Flow — Weighted Mix</span>
      </div>
      <div className="flex flex-col items-center gap-0">
        <FlowNode color="blue" label="Inputs" detail="Threads or TPH, Duration, Test Type + Transaction table (Name, Weight%, RT, TT)" />
        <FlowArrow />
        <FlowNode color="purple" label="Step 1: Validate Weights" detail="All weights must sum to 100%" />
        <FlowArrow />
        <FlowNode color="teal" label="Step 2: Weighted Averages" detail="Weighted RT = Σ(weight% × RT), Weighted TT = Σ(weight% × TT)" />
        <FlowArrow />
        <FlowNode color="emerald" label="Step 3: Pacing" detail="Pacing = Weighted RT + Weighted TT" />
        <FlowArrow />
        <div className="grid grid-cols-2 gap-3 w-full">
          <FlowNode color="amber" label="If Threads given" detail="TPH = Threads × (3600 / Pacing)" />
          <FlowNode color="amber" label="If TPH given" detail="Threads = (TPH × Pacing) / 3600" />
        </div>
        <FlowArrow />
        <FlowNode color="orange" label="Step 4: Per-Transaction" detail="Per-Txn TPH = Total TPH × weight%, Per-Txn TPS = Per-Txn TPH / 3600" />
        <FlowArrow />
        <FlowNode color="indigo" label="Output" detail="Thread Group Recommendation + Load Profile + Per-Transaction Breakdown" />
      </div>
    </div>
  );
}

function FlowNode({ color, label, detail }: { color: string; label: string; detail: string }) {
  const colorMap: Record<string, string> = {
    blue: "bg-blue-50 dark:bg-blue-500/10 border-blue-200 dark:border-blue-500/20",
    purple: "bg-purple-50 dark:bg-purple-500/10 border-purple-200 dark:border-purple-500/20",
    teal: "bg-teal-50 dark:bg-teal-500/10 border-teal-200 dark:border-teal-500/20",
    emerald: "bg-emerald-50 dark:bg-emerald-500/10 border-emerald-200 dark:border-emerald-500/20",
    amber: "bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/20",
    orange: "bg-orange-50 dark:bg-orange-500/10 border-orange-200 dark:border-orange-500/20",
    rose: "bg-rose-50 dark:bg-rose-500/10 border-rose-200 dark:border-rose-500/20",
    indigo: "bg-indigo-50 dark:bg-indigo-500/10 border-indigo-200 dark:border-indigo-500/20",
  };

  return (
    <div className={`w-full rounded-lg border p-2.5 text-center ${colorMap[color] || colorMap.blue}`}>
      <div className="text-xs font-semibold mb-0.5">{label}</div>
      <div className="text-[10px] text-muted-foreground leading-snug">{detail}</div>
    </div>
  );
}

function FlowArrow() {
  return (
    <div className="py-1 flex items-center justify-center text-muted-foreground">
      <svg width="12" height="16" viewBox="0 0 12 16" fill="none">
        <path d="M6 0 L6 12 M2 8 L6 14 L10 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}

function FormulasReference() {
  return (
    <Card className="border-dashed">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Download className="h-4 w-4 text-muted-foreground" />
          Formulas Reference
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Single Flow</p>
            <div className="space-y-1.5">
              {[
                "Pacing = E2E RT + (Think Time × Transactions Per Iteration)",
                "Iterations/Hour = 3600 / Pacing",
                "TPH = Threads × Iterations/Hour × Transactions Per Iteration",
                "TPS = TPH / 3600",
                "Threads = (TPH × Pacing) / (3600 × Transactions Per Iteration)",
              ].map((f, i) => (
                <div key={i} className="flex items-start gap-2">
                  <ChevronRight className="h-3 w-3 mt-0.5 text-muted-foreground shrink-0" />
                  <code className="text-[11px] font-mono text-muted-foreground">{f}</code>
                </div>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Weighted Mix</p>
            <div className="space-y-1.5">
              {[
                "Weighted RT = Σ (weight% × response time per transaction)",
                "Weighted TT = Σ (weight% × think time per transaction)",
                "Pacing = Weighted RT + Weighted TT",
                "TPH = Threads × (3600 / Pacing)",
                "Threads = (TPH × Pacing) / 3600",
                "Per-Txn TPH = Total TPH × weight%",
              ].map((f, i) => (
                <div key={i} className="flex items-start gap-2">
                  <ChevronRight className="h-3 w-3 mt-0.5 text-muted-foreground shrink-0" />
                  <code className="text-[11px] font-mono text-muted-foreground">{f}</code>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
