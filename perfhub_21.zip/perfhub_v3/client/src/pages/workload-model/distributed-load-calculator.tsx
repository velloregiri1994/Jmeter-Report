import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Server, Users, Cpu, HardDrive, Network, Info, AlertTriangle,
  Check, Copy, ChevronRight, Monitor, Settings2, Zap, BarChart3,
  ArrowRight, Loader2, Database, Activity
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { copyToClipboard } from "@/lib/clipboard";

type EstimationMode = "preset" | "calibration";
type HardwarePreset = "small" | "medium" | "large" | "xl" | "custom";
type ScriptComplexity = "lightweight" | "moderate" | "heavy" | "very_heavy";

interface HardwareProfile {
  label: string;
  vcpu: number;
  ramGb: number;
  networkGbps: number;
  baseThreads: number;
  description: string;
}

const HARDWARE_PRESETS: Record<Exclude<HardwarePreset, "custom">, HardwareProfile> = {
  small: {
    label: "Small",
    vcpu: 2,
    ramGb: 4,
    networkGbps: 1,
    baseThreads: 350,
    description: "Dev/staging — basic HTTP scripts",
  },
  medium: {
    label: "Medium",
    vcpu: 4,
    ramGb: 8,
    networkGbps: 5,
    baseThreads: 750,
    description: "Standard load testing workloads",
  },
  large: {
    label: "Large",
    vcpu: 8,
    ramGb: 16,
    networkGbps: 10,
    baseThreads: 1750,
    description: "High-throughput production tests",
  },
  xl: {
    label: "Extra Large",
    vcpu: 16,
    ramGb: 32,
    networkGbps: 25,
    baseThreads: 3500,
    description: "Enterprise-scale load generation",
  },
};

const COMPLEXITY_MULTIPLIERS: Record<ScriptComplexity, { factor: number; label: string; description: string }> = {
  lightweight: {
    factor: 1.0,
    label: "Lightweight",
    description: "Simple HTTP requests, minimal assertions, no file uploads",
  },
  moderate: {
    factor: 0.7,
    label: "Moderate",
    description: "JSON/XML extraction, correlation, moderate assertions",
  },
  heavy: {
    factor: 0.45,
    label: "Heavy",
    description: "Complex scripting, large payloads, many regex extractors, JSR223 processors",
  },
  very_heavy: {
    factor: 0.25,
    label: "Very Heavy",
    description: "File uploads/downloads, heavy JSR223 logic, database calls, embedded resources",
  },
};

interface CalibrationData {
  executionName: string;
  maxThreads: number;
  avgResponseTime: number;
  throughput: number;
  errorRate: number;
  totalRequests: number;
  failedRequests: number;
  durationSeconds: number;
}

interface DistributedResult {
  totalThreads: number;
  threadsPerMachine: number;
  machineCount: number;
  heapPerMachineGb: number;
  networkPerMachineMbps: number;
  totalNetworkMbps: number;
  overheadPercent: number;
  estimatedCapacityPerMachine: number;
  source: "preset" | "calibration";
}

function estimateHeapGb(threadsPerMachine: number): number {
  const baseMb = 512;
  const perThreadMb = 1.2;
  const totalMb = baseMb + (threadsPerMachine * perThreadMb);
  return parseFloat((totalMb / 1024).toFixed(1));
}

function estimateNetworkMbps(threadsPerMachine: number, avgResponseSizeKb: number, pacing: number | null): number {
  const requestsPerSecPerThread = 1 / (pacing && pacing > 0 ? pacing : 3);
  const rps = threadsPerMachine * requestsPerSecPerThread;
  const mbps = (rps * avgResponseSizeKb * 8) / 1024;
  return parseFloat(mbps.toFixed(1));
}

interface DistributedLoadCalculatorProps {
  totalThreadsFromModel: number | null;
  pacingFromModel: number | null;
}

export function DistributedLoadCalculator({ totalThreadsFromModel, pacingFromModel }: DistributedLoadCalculatorProps) {
  const { toast } = useToast();
  const [totalThreads, setTotalThreads] = useState<string>(
    totalThreadsFromModel ? String(totalThreadsFromModel) : ""
  );
  const [estimationMode, setEstimationMode] = useState<EstimationMode>("preset");
  const [preset, setPreset] = useState<HardwarePreset>("medium");
  const [complexity, setComplexity] = useState<ScriptComplexity>("moderate");
  const [customVcpu, setCustomVcpu] = useState<string>("4");
  const [customRam, setCustomRam] = useState<string>("8");
  const overheadPct = 10;
  const avgResponseSizeKb = "10";
  const [selectedExecutionId, setSelectedExecutionId] = useState<string>("");
  const [copied, setCopied] = useState(false);

  const { data: executions = [], isLoading: executionsLoading } = useQuery<Array<{
    id: number;
    executionId: string;
    testName: string;
    status: string;
    startTime: string;
    resultSummary: any;
    liveMetrics: any;
  }>>({
    queryKey: ["/api/executions", "calibration"],
    queryFn: async () => {
      const res = await fetch("/api/executions?status=completed&limit=50", { credentials: "include" });
      if (!res.ok) return [];
      const data = await res.json();
      return (data.data || []).filter((e: any) => e.status === "completed" && e.resultSummary);
    },
    enabled: estimationMode === "calibration",
  });

  const calibrationData = useMemo((): CalibrationData | null => {
    if (!selectedExecutionId) return null;
    const exec = executions.find(e => String(e.id) === selectedExecutionId);
    if (!exec || !exec.resultSummary) return null;

    const summary = exec.resultSummary;
    const live = exec.liveMetrics;

    let maxThreads = 0;
    if (live?.activeThreads && Array.isArray(live.activeThreads)) {
      maxThreads = Math.max(...live.activeThreads.filter((v: any) => typeof v === "number" && !isNaN(v)), 0);
    }
    if (maxThreads === 0 && summary.maxActiveThreads) {
      maxThreads = summary.maxActiveThreads;
    }

    let durationSeconds = summary.durationSeconds || 0;
    if (durationSeconds === 0 && live?.timestamps && Array.isArray(live.timestamps) && live.timestamps.length >= 2) {
      const first = new Date(live.timestamps[0]).getTime();
      const last = new Date(live.timestamps[live.timestamps.length - 1]).getTime();
      durationSeconds = Math.round((last - first) / 1000);
    }

    const totalRequests = summary.totalRequests || 0;
    const failedRequests = summary.failedRequests || 0;

    return {
      executionName: exec.testName || exec.executionId,
      maxThreads,
      avgResponseTime: summary.avgResponseTime || 0,
      throughput: summary.throughput || 0,
      errorRate: totalRequests > 0 ? (failedRequests / totalRequests) * 100 : 0,
      totalRequests,
      failedRequests,
      durationSeconds,
    };
  }, [selectedExecutionId, executions]);

  const capacityPerMachine = useMemo((): number => {
    if (estimationMode === "calibration" && calibrationData) {
      const { maxThreads, errorRate, avgResponseTime } = calibrationData;
      if (maxThreads <= 0) return 0;

      let capacity = maxThreads;

      if (errorRate > 5) {
        capacity = Math.round(capacity * 0.7);
      } else if (errorRate > 2) {
        capacity = Math.round(capacity * 0.85);
      }

      if (avgResponseTime > 5000) {
        capacity = Math.round(capacity * 0.8);
      }

      capacity = Math.round(capacity * 0.9);
      return capacity;
    }

    if (preset === "custom") {
      const vcpu = Math.max(1, parseFloat(customVcpu) || 4);
      const ram = Math.max(2, parseFloat(customRam) || 8);
      const baseFromCpu = vcpu * 200;
      const baseFromRam = ((ram - 2) * 1024) / 1.2;
      const base = Math.min(baseFromCpu, baseFromRam);
      return Math.max(1, Math.round(base * COMPLEXITY_MULTIPLIERS[complexity].factor));
    }

    const profile = HARDWARE_PRESETS[preset];
    return Math.round(profile.baseThreads * COMPLEXITY_MULTIPLIERS[complexity].factor);
  }, [estimationMode, preset, complexity, customVcpu, customRam, calibrationData]);

  const distributedResult = useMemo((): DistributedResult | null => {
    const total = parseInt(totalThreads);
    if (!total || total <= 0 || capacityPerMachine <= 0) return null;

    const effectiveCapacity = Math.round(capacityPerMachine * (1 - overheadPct / 100));
    if (effectiveCapacity <= 0) return null;

    const machineCount = Math.ceil(total / effectiveCapacity);
    const threadsPerMachine = Math.ceil(total / machineCount);
    const heapPerMachineGb = estimateHeapGb(threadsPerMachine);
    const respSize = parseFloat(avgResponseSizeKb) || 10;
    const networkPerMachineMbps = estimateNetworkMbps(threadsPerMachine, respSize, pacingFromModel);

    return {
      totalThreads: total,
      threadsPerMachine,
      machineCount,
      heapPerMachineGb,
      networkPerMachineMbps,
      totalNetworkMbps: parseFloat((networkPerMachineMbps * machineCount).toFixed(1)),
      overheadPercent: overheadPct,
      estimatedCapacityPerMachine: effectiveCapacity,
      source: estimationMode,
    };
  }, [totalThreads, capacityPerMachine, overheadPct, avgResponseSizeKb, estimationMode, pacingFromModel]);

  const handleCopyResult = async () => {
    if (!distributedResult) return;
    const lines = [
      "=== Distributed Load Plan — PerfHub ===",
      "",
      "--- Requirements ---",
      `Total Threads: ${distributedResult.totalThreads.toLocaleString()}`,
      `Estimation Method: ${distributedResult.source === "preset" ? "Hardware Preset" : "Calibration from Execution"}`,
      `Capacity per Machine: ${distributedResult.estimatedCapacityPerMachine.toLocaleString()} threads`,
      `Distributed Overhead: ${distributedResult.overheadPercent}%`,
      "",
      "--- Distribution Plan ---",
      `Load Generators Required: ${distributedResult.machineCount}`,
      `Threads per Machine: ${distributedResult.threadsPerMachine.toLocaleString()}`,
      `Heap Memory per Machine: ${distributedResult.heapPerMachineGb} GB`,
      `Network per Machine: ~${distributedResult.networkPerMachineMbps} Mbps`,
      `Total Network: ~${distributedResult.totalNetworkMbps} Mbps`,
      "",
      "--- JMeter Configuration ---",
      `Controller: 1 machine (does not generate load)`,
      `Workers: ${distributedResult.machineCount} machines`,
      `JMeter Heap: -Xms${Math.ceil(distributedResult.heapPerMachineGb * 0.5)}g -Xmx${Math.ceil(distributedResult.heapPerMachineGb)}g`,
      "",
      "--- remote_hosts property ---",
      `remote_hosts=worker1:1099,worker2:1099${distributedResult.machineCount > 2 ? ",...worker" + distributedResult.machineCount + ":1099" : ""}`,
    ];

    const ok = await copyToClipboard(lines.join("\n"));
    if (ok) {
      setCopied(true);
      toast({ title: "Copied to clipboard" });
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const handleUseFromCalculator = () => {
    if (totalThreadsFromModel) {
      setTotalThreads(String(totalThreadsFromModel));
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr] gap-4">
        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              Thread Requirement
            </CardTitle>
            <CardDescription>
              Total concurrent threads your test needs
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <Users className="h-3.5 w-3.5 text-blue-500" />
                Total Threads
              </Label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  min="1"
                  placeholder="e.g., 5000"
                  value={totalThreads}
                  onChange={(e) => setTotalThreads(e.target.value)}
                />
                {totalThreadsFromModel && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="shrink-0 text-xs"
                    onClick={handleUseFromCalculator}
                  >
                    <ArrowRight className="h-3.5 w-3.5 mr-1" />
                    Use {totalThreadsFromModel} from model
                  </Button>
                )}
              </div>
              <p className="text-[10px] text-muted-foreground">
                Enter the total number of concurrent virtual users your test requires, or pull it from the Single Flow / Weighted Mix calculator
              </p>
            </div>

            <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 border">
              <Info className="h-3.5 w-3.5 text-blue-500 mt-0.5 shrink-0" />
              <p className="text-[11px] text-muted-foreground leading-relaxed">
                A <strong className="text-foreground">10% overhead</strong> is automatically applied to account for distributed coordination costs (RMI, network serialization). Bandwidth estimates use a typical 10 KB average response size.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <Cpu className="h-4 w-4 text-primary" />
              Estimation Method
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Button
                variant={estimationMode === "preset" ? "default" : "outline"}
                size="sm"
                onClick={() => setEstimationMode("preset")}
                className="gap-1.5"
              >
                <Monitor className="h-3.5 w-3.5" />Hardware Presets
              </Button>
              <Button
                variant={estimationMode === "calibration" ? "default" : "outline"}
                size="sm"
                onClick={() => setEstimationMode("calibration")}
                className="gap-1.5"
              >
                <BarChart3 className="h-3.5 w-3.5" />Calibration from Execution
              </Button>
            </div>

            {estimationMode === "preset" && (
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label>Machine Profile</Label>
                  <Select value={preset} onValueChange={(v) => setPreset(v as HardwarePreset)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {(Object.entries(HARDWARE_PRESETS) as [Exclude<HardwarePreset, "custom">, HardwareProfile][]).map(([key, p]) => (
                        <SelectItem key={key} value={key}>
                          <div className="flex flex-col">
                            <span>{p.label} — {p.vcpu} vCPU / {p.ramGb} GB RAM</span>
                            <span className="text-[10px] text-muted-foreground">{p.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                      <SelectItem value="custom">
                        <div className="flex flex-col">
                          <span>Custom</span>
                          <span className="text-[10px] text-muted-foreground">Define your own hardware specs</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {preset === "custom" && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs">vCPU</Label>
                      <Input type="number" min="1" value={customVcpu} onChange={(e) => setCustomVcpu(e.target.value)} className="h-8" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">RAM (GB)</Label>
                      <Input type="number" min="2" value={customRam} onChange={(e) => setCustomRam(e.target.value)} className="h-8" />
                    </div>
                  </div>
                )}

                {preset !== "custom" && (
                  <div className="grid grid-cols-3 gap-2 text-center">
                    {[
                      { label: "vCPU", value: HARDWARE_PRESETS[preset].vcpu, icon: Cpu },
                      { label: "RAM", value: `${HARDWARE_PRESETS[preset].ramGb} GB`, icon: HardDrive },
                      { label: "Network", value: `${HARDWARE_PRESETS[preset].networkGbps} Gbps`, icon: Network },
                    ].map((spec) => {
                      const SpecIcon = spec.icon;
                      return (
                        <div key={spec.label} className="p-2 rounded-lg bg-muted/30 border">
                          <SpecIcon className="h-3.5 w-3.5 mx-auto mb-1 text-muted-foreground" />
                          <div className="text-sm font-bold">{spec.value}</div>
                          <div className="text-[10px] text-muted-foreground">{spec.label}</div>
                        </div>
                      );
                    })}
                  </div>
                )}

                <div className="space-y-1.5">
                  <Label>Script Complexity</Label>
                  <Select value={complexity} onValueChange={(v) => setComplexity(v as ScriptComplexity)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {(Object.entries(COMPLEXITY_MULTIPLIERS) as [ScriptComplexity, typeof COMPLEXITY_MULTIPLIERS[ScriptComplexity]][]).map(([key, c]) => (
                        <SelectItem key={key} value={key}>
                          <div className="flex flex-col">
                            <span>{c.label} (×{c.factor})</span>
                            <span className="text-[10px] text-muted-foreground">{c.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="p-3 rounded-lg bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-500/15">
                  <div className="flex items-center gap-2 mb-1">
                    <Server className="h-3.5 w-3.5 text-blue-500" />
                    <span className="text-xs font-semibold text-blue-700 dark:text-blue-400">
                      Estimated capacity: {capacityPerMachine.toLocaleString()} threads/machine
                    </span>
                  </div>
                  <p className="text-[10px] text-muted-foreground ml-5">
                    Based on {preset === "custom" ? "custom specs" : `${HARDWARE_PRESETS[preset].label} profile`} with {COMPLEXITY_MULTIPLIERS[complexity].label.toLowerCase()} script complexity
                  </p>
                </div>
              </div>
            )}

            {estimationMode === "calibration" && (
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label>Select a Completed Execution</Label>
                  {executionsLoading ? (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
                      <Loader2 className="h-4 w-4 animate-spin" /> Loading executions...
                    </div>
                  ) : (
                    <Select value={selectedExecutionId} onValueChange={setSelectedExecutionId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose an execution..." />
                      </SelectTrigger>
                      <SelectContent>
                        {executions.map((e) => (
                          <SelectItem key={e.id} value={String(e.id)}>
                            <div className="flex flex-col">
                              <span>{e.testName || e.executionId}</span>
                              <span className="text-[10px] text-muted-foreground">
                                {new Date(e.startTime).toLocaleDateString()} — {e.resultSummary?.totalRequests?.toLocaleString() || 0} requests
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                        {executions.length === 0 && (
                          <div className="px-3 py-2 text-xs text-muted-foreground">No completed executions found</div>
                        )}
                      </SelectContent>
                    </Select>
                  )}
                </div>

                {calibrationData && (
                  <>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { label: "Max Threads", value: calibrationData.maxThreads.toLocaleString(), color: "text-blue-600 dark:text-blue-400" },
                        { label: "Throughput", value: `${calibrationData.throughput.toFixed(1)} rps`, color: "text-emerald-600 dark:text-emerald-400" },
                        { label: "Avg RT", value: `${calibrationData.avgResponseTime.toFixed(0)} ms`, color: "text-amber-600 dark:text-amber-400" },
                        { label: "Error Rate", value: `${calibrationData.errorRate.toFixed(1)}%`, color: calibrationData.errorRate > 5 ? "text-red-600 dark:text-red-400" : "text-emerald-600 dark:text-emerald-400" },
                      ].map((m) => (
                        <div key={m.label} className="p-2 rounded-lg bg-muted/30 border text-center">
                          <div className={`text-sm font-bold ${m.color}`}>{m.value}</div>
                          <div className="text-[10px] text-muted-foreground">{m.label}</div>
                        </div>
                      ))}
                    </div>

                    <div className="p-3 rounded-lg bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-500/15">
                      <div className="flex items-center gap-2 mb-1">
                        <Server className="h-3.5 w-3.5 text-blue-500" />
                        <span className="text-xs font-semibold text-blue-700 dark:text-blue-400">
                          Derived capacity: {capacityPerMachine.toLocaleString()} threads/machine
                        </span>
                      </div>
                      <p className="text-[10px] text-muted-foreground ml-5">
                        Based on {calibrationData.executionName} — adjusted for error rate
                        {calibrationData.errorRate > 2 ? ` (${calibrationData.errorRate.toFixed(1)}%)` : ""} and 10% safety margin
                      </p>
                    </div>

                    {calibrationData.errorRate > 5 && (
                      <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-500/15">
                        <AlertTriangle className="h-3.5 w-3.5 text-amber-500 mt-0.5 shrink-0" />
                        <p className="text-[11px] text-amber-700 dark:text-amber-400">
                          This execution had a {calibrationData.errorRate.toFixed(1)}% error rate. The calibration run may have been overloaded — the derived capacity has been reduced by 30% to account for this. For more accurate results, use a calibration run where the load generator was not saturated (error rate &lt; 2%).
                        </p>
                      </div>
                    )}
                  </>
                )}

                {!calibrationData && selectedExecutionId && (
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-500/15">
                    <AlertTriangle className="h-3.5 w-3.5 text-amber-500 mt-0.5 shrink-0" />
                    <p className="text-[11px] text-amber-700 dark:text-amber-400">
                      Could not extract calibration data from this execution. The execution may be missing result summary data.
                    </p>
                  </div>
                )}

                <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 border">
                  <Info className="h-3.5 w-3.5 text-blue-500 mt-0.5 shrink-0" />
                  <p className="text-[11px] text-muted-foreground leading-relaxed">
                    <strong className="text-foreground">How calibration works:</strong> we take the peak thread count from the selected execution, then apply safety adjustments for error rate and a 10% margin. This gives the safe maximum threads for one machine running this specific script.
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {distributedResult && (
        <DistributedResultsPanel
          result={distributedResult}
          capacityPerMachine={capacityPerMachine}
          onCopy={handleCopyResult}
          copied={copied}
        />
      )}
    </div>
  );
}

function DistributedResultsPanel({
  result, capacityPerMachine, onCopy, copied,
}: {
  result: DistributedResult;
  capacityPerMachine: number;
  onCopy: () => void;
  copied: boolean;
}) {
  return (
    <div className="space-y-4" style={{ animation: 'fadeSlideIn 0.3s ease-out both' }}>
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <Separator />

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Server className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Distribution Plan</h2>
          <Badge variant="secondary" className="text-[10px]">
            {result.source === "preset" ? "Hardware Preset" : "Calibration-Based"}
          </Badge>
        </div>
        <Button size="sm" variant="outline" onClick={onCopy}>
          {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
          {copied ? "Copied" : "Copy Plan"}
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: "Load Generators", value: result.machineCount.toString(), icon: Server, color: "text-blue-600 dark:text-blue-400" },
          { label: "Threads / Machine", value: result.threadsPerMachine.toLocaleString(), icon: Users, color: "text-emerald-600 dark:text-emerald-400" },
          { label: "Total Threads", value: result.totalThreads.toLocaleString(), icon: Activity, color: "text-purple-600 dark:text-purple-400" },
          { label: "Heap / Machine", value: `${result.heapPerMachineGb} GB`, icon: HardDrive, color: "text-amber-600 dark:text-amber-400" },
          { label: "Net / Machine", value: `${result.networkPerMachineMbps} Mbps`, icon: Network, color: "text-teal-600 dark:text-teal-400" },
          { label: "Total Network", value: `${result.totalNetworkMbps} Mbps`, icon: Zap, color: "text-red-600 dark:text-red-400" },
        ].map((kpi, i) => {
          const KpiIcon = kpi.icon;
          return (
            <div key={i} className="rounded-lg border bg-card p-3">
              <div className="flex items-center gap-1.5 mb-1.5">
                <KpiIcon className={`h-3.5 w-3.5 ${kpi.color}`} />
                <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">{kpi.label}</span>
              </div>
              <div className={`text-lg font-bold ${kpi.color}`}>{kpi.value}</div>
            </div>
          );
        })}
      </div>

      <DistributionVisual machineCount={result.machineCount} threadsPerMachine={result.threadsPerMachine} />

      <Card className="border-2 border-blue-200 dark:border-blue-500/30 shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle className="text-base flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-blue-100 dark:bg-blue-500/15 flex items-center justify-center">
                <Settings2 className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              </div>
              JMeter Distributed Setup
            </CardTitle>
            <Badge className="bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20 text-[10px]">
              Controller + {result.machineCount} Workers
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">JVM Heap Settings (per worker)</p>
              <pre className="bg-slate-900 p-4 rounded-lg text-xs text-emerald-400 overflow-x-auto border border-slate-700 font-mono leading-relaxed">
{`# jmeter (or jmeter.bat) — set HEAP
HEAP="-Xms${Math.ceil(result.heapPerMachineGb * 0.5)}g -Xmx${Math.ceil(result.heapPerMachineGb)}g"

# GC tuning (recommended)
GC="-XX:+UseG1GC -XX:MaxGCPauseMillis=100"

# Full JVM_ARGS
JVM_ARGS="$HEAP $GC"`}
              </pre>
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">remote_hosts property</p>
              <pre className="bg-slate-900 p-4 rounded-lg text-xs text-emerald-400 overflow-x-auto border border-slate-700 font-mono leading-relaxed">
{`# jmeter.properties or user.properties
remote_hosts=${Array.from({ length: Math.min(result.machineCount, 5) }, (_, i) => `worker${i + 1}:1099`).join(",")}${result.machineCount > 5 ? `\n# ... add all ${result.machineCount} worker IPs` : ""}

# Mode setting for distributed execution
mode=Statistical
server.rmi.ssl.disable=true`}
              </pre>
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-1.5">
              <ChevronRight className="h-3.5 w-3.5" />
              Setup Steps
            </p>
            <div className="space-y-0">
              {[
                `Provision ${result.machineCount} worker machines and 1 controller machine (controller does not generate load)`,
                "Install identical JMeter version and plugins on all machines",
                `Set JVM heap to -Xms${Math.ceil(result.heapPerMachineGb * 0.5)}g -Xmx${Math.ceil(result.heapPerMachineGb)}g on each worker`,
                "Start JMeter Server on each worker: jmeter-server -Djava.rmi.server.hostname=<worker-ip>",
                `Configure remote_hosts in jmeter.properties on the controller with all ${result.machineCount} worker IPs`,
                "Ensure port 1099 (RMI) and 4000-4002 (data) are open between controller and workers",
                "Place test data files (CSVs, JARs) on all workers at the same path",
                `Run distributed test: jmeter -n -t test.jmx -r -l results.jtl (threads in JMX should be ${result.threadsPerMachine})`,
                "Each worker runs the full thread count from the JMX — threads are NOT automatically split across workers",
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-2.5 py-1.5">
                  <div className="h-5 w-5 rounded-full bg-blue-100 dark:bg-blue-500/15 flex items-center justify-center text-[10px] font-bold text-blue-600 dark:text-blue-400 shrink-0 mt-0.5">
                    {i + 1}
                  </div>
                  <span className="text-xs leading-relaxed">{step}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-500/15">
            <AlertTriangle className="h-3.5 w-3.5 text-amber-500 mt-0.5 shrink-0" />
            <div className="space-y-1">
              <p className="text-xs font-semibold text-amber-700 dark:text-amber-400">Important: JMeter does NOT auto-split threads</p>
              <p className="text-[11px] text-amber-600 dark:text-amber-400/80">
                In distributed mode, each worker runs the full thread count defined in the JMX file. Set the JMX thread count to {result.threadsPerMachine} (threads per machine), not {result.totalThreads.toLocaleString()} (total). The controller coordinates {result.machineCount} workers, each running {result.threadsPerMachine.toLocaleString()} threads, giving you {(result.threadsPerMachine * result.machineCount).toLocaleString()} total threads.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 border">
            <Info className="h-3.5 w-3.5 text-blue-500 mt-0.5 shrink-0" />
            <div className="space-y-1">
              <p className="text-xs font-semibold">Performance Tips</p>
              <ul className="text-[11px] text-muted-foreground space-y-0.5">
                <li>• Use CLI mode only (-n flag) — never run the GUI on workers</li>
                <li>• Disable all listeners (View Results Tree, etc.) during distributed runs</li>
                <li>• Use a Backend Listener to stream results to PerfHub instead of writing large JTL files</li>
                <li>• Monitor worker CPU — if any worker exceeds 80% CPU, reduce its thread count or add more workers</li>
                <li>• Set <code className="bg-muted px-1 rounded">mode=Statistical</code> to reduce data transfer between workers and controller</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DistributionVisual({ machineCount, threadsPerMachine }: { machineCount: number; threadsPerMachine: number }) {
  const displayCount = Math.min(machineCount, 8);
  const hasMore = machineCount > 8;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Database className="h-4 w-4 text-primary" />
          Architecture Diagram
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center gap-4">
          <div className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/20 border-2 border-amber-300 dark:border-amber-500/30">
            <Monitor className="h-4 w-4 text-amber-600 dark:text-amber-400" />
            <div>
              <div className="text-xs font-bold text-amber-700 dark:text-amber-400">Controller</div>
              <div className="text-[10px] text-amber-600 dark:text-amber-400/70">Coordinates only — no load</div>
            </div>
          </div>

          <div className="flex items-center gap-1 text-muted-foreground">
            <div className="w-px h-6 bg-border"></div>
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            {Array.from({ length: displayCount }).map((_, i) => (
              <div
                key={i}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-500/20"
              >
                <Server className="h-3.5 w-3.5 text-blue-500" />
                <div>
                  <div className="text-[10px] font-bold text-blue-700 dark:text-blue-400">Worker {i + 1}</div>
                  <div className="text-[9px] text-blue-500 dark:text-blue-400/70">{threadsPerMachine.toLocaleString()} threads</div>
                </div>
              </div>
            ))}
            {hasMore && (
              <div className="flex items-center px-3 py-2 rounded-lg bg-muted/50 border border-dashed">
                <span className="text-xs text-muted-foreground font-medium">+{machineCount - 8} more</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
