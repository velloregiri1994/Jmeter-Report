import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/lib/query-keys";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { TrendingUp, TrendingDown, Minus, BarChart3, Clock, Activity, Zap, Calendar, AlertTriangle, Layers, GitCompare, CalendarRange, Lightbulb, ChevronDown, ChevronUp, Target, Crosshair, ArrowUpDown, Tag } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { EmptyState } from "@/components/empty-state";
import { useState, useMemo, useCallback } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  BarChart, Bar, ReferenceDot, ReferenceLine, ScatterChart, Scatter, ZAxis, Cell
} from "recharts";
import { format, subDays, subMonths, startOfDay, endOfDay } from "date-fns";
import { QueryErrorFallback } from "@/components/error-boundary";
import { PageHeader } from "@/components/page-header";
import { DT_COLORS, DT_GRID_PROPS, DT_AXIS_PROPS, DT_CURSOR_PROPS, DT_PALETTE, DynatraceGradients, DT_TOOLTIP_STYLE } from "@/components/charts/dynatrace-theme";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import type { DateRange } from "react-day-picker";

type TransactionData = {
  label: string;
  avg: number;
  p95: number;
  throughput: number;
  errorRate: number;
};

type TrendDataPoint = {
  id: number;
  executionId: string;
  startTime: string;
  scheduleName: string;
  scriptId: string;
  scriptName: string;
  environment: string;
  avgResponseTime: number;
  p50: number;
  p90: number;
  p95: number;
  p99: number;
  throughput: number;
  errorRate: number;
  totalRequests: number;
  failedRequests: number;
  isRegression: boolean;
  regressionConfidence: 'none' | 'low' | 'medium' | 'high';
  transactions: TransactionData[];
  achievementVerdict: 'achieved' | 'partially_achieved' | 'not_achieved' | null;
};

type TrendResponse = {
  data: TrendDataPoint[];
  scripts: { id: string; name: string }[];
  environments: string[];
  total: number;
};

type ChartDataPoint = {
  date: string;
  name: string;
  avgResponse: number;
  p50: number;
  p90: number;
  p95: number;
  p99: number;
  throughput: number;
  errorRate: number;
  environment: string;
  scriptName: string;
  scriptId: string;
  isRegression: boolean;
  regressionConfidence: string;
  timestamp: number;
  index: number;
  transactions: TransactionData[];
  achievementVerdict: string | null;
};

type DatePreset = "7d" | "14d" | "30d" | "90d" | "all" | "custom";

function linearRegression(data: { x: number; y: number }[]): { slope: number; intercept: number; r2: number } {
  const n = data.length;
  if (n < 2) return { slope: 0, intercept: data[0]?.y || 0, r2: 0 };

  const sumX = data.reduce((s, d) => s + d.x, 0);
  const sumY = data.reduce((s, d) => s + d.y, 0);
  const sumXY = data.reduce((s, d) => s + d.x * d.y, 0);
  const sumX2 = data.reduce((s, d) => s + d.x * d.x, 0);

  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;

  const meanY = sumY / n;
  const ssTotal = data.reduce((s, d) => s + (d.y - meanY) ** 2, 0);
  const ssResidual = data.reduce((s, d) => s + (d.y - (slope * d.x + intercept)) ** 2, 0);
  const r2 = ssTotal > 0 ? 1 - ssResidual / ssTotal : 0;

  return { slope, intercept, r2 };
}

function computeTrendAndForecast(
  chartData: ChartDataPoint[],
  metric: keyof ChartDataPoint,
  forecastCount: number = 3
): { trendLine: { index: number; value: number; date: string }[]; forecast: { index: number; value: number; date: string }[]; slope: number; r2: number } {
  if (chartData.length < 2) return { trendLine: [], forecast: [], slope: 0, r2: 0 };

  const points = chartData.map((d, i) => ({ x: d.timestamp, y: Number(d[metric]) || 0 }));
  const { slope, intercept, r2 } = linearRegression(points);

  const trendLine = chartData.map((d) => ({
    index: d.index,
    value: Math.max(0, Math.round((slope * d.timestamp + intercept) * 100) / 100),
    date: d.date,
  }));

  const forecast: { index: number; value: number; date: string }[] = [];
  const lastTimestamp = chartData.length > 0 ? chartData[chartData.length - 1].timestamp : Date.now();
  const avgInterval = chartData.length > 1
    ? (chartData[chartData.length - 1].timestamp - chartData[0].timestamp) / (chartData.length - 1)
    : 86400000;

  for (let i = 1; i <= forecastCount; i++) {
    const forecastTs = lastTimestamp + avgInterval * i;
    const forecastDate = new Date(forecastTs);
    forecast.push({
      index: chartData.length - 1 + i,
      value: Math.max(0, Math.round((slope * forecastTs + intercept) * 100) / 100),
      date: format(forecastDate, 'MM/dd HH:mm') + ' (est)',
    });
  }

  const slopePerRun = chartData.length > 1
    ? (slope * (chartData[chartData.length - 1].timestamp - chartData[0].timestamp)) / (chartData.length - 1)
    : 0;

  return { trendLine, forecast, slope: slopePerRun, r2 };
}

function generateInsights(chartData: ChartDataPoint[], filteredData: TrendDataPoint[], regressionCount: number): string[] {
  const insights: string[] = [];
  if (chartData.length < 2) return insights;

  const recent = chartData.slice(-5);
  const older = chartData.slice(0, Math.min(5, chartData.length - 5));

  if (older.length > 0) {
    const avgRecentRT = recent.reduce((s, d) => s + d.avgResponse, 0) / recent.length;
    const avgOlderRT = older.reduce((s, d) => s + d.avgResponse, 0) / older.length;
    if (avgOlderRT > 0) {
      const rtChange = ((avgRecentRT - avgOlderRT) / avgOlderRT) * 100;
      if (Math.abs(rtChange) > 5) {
        insights.push(
          rtChange > 0
            ? `Response time increased ${Math.abs(rtChange).toFixed(1)}% — recent average is ${Math.round(avgRecentRT)}ms vs ${Math.round(avgOlderRT)}ms earlier.`
            : `Response time improved ${Math.abs(rtChange).toFixed(1)}% — recent average is ${Math.round(avgRecentRT)}ms, down from ${Math.round(avgOlderRT)}ms.`
        );
      } else {
        insights.push(`Response time is stable around ${Math.round(avgRecentRT)}ms across recent runs.`);
      }
    }

    const avgRecentTPS = recent.reduce((s, d) => s + d.throughput, 0) / recent.length;
    const avgOlderTPS = older.reduce((s, d) => s + d.throughput, 0) / older.length;
    if (avgOlderTPS > 0) {
      const tpsChange = ((avgRecentTPS - avgOlderTPS) / avgOlderTPS) * 100;
      if (Math.abs(tpsChange) > 5) {
        insights.push(
          tpsChange > 0
            ? `Throughput grew ${Math.abs(tpsChange).toFixed(1)}% — now averaging ${avgRecentTPS.toFixed(1)}/s.`
            : `Throughput dropped ${Math.abs(tpsChange).toFixed(1)}% — now averaging ${avgRecentTPS.toFixed(1)}/s, down from ${avgOlderTPS.toFixed(1)}/s.`
        );
      }
    }
  }

  const allTransactions = new Map<string, { totalAvg: number; count: number }>();
  chartData.forEach(d => {
    d.transactions?.forEach(t => {
      const existing = allTransactions.get(t.label) || { totalAvg: 0, count: 0 };
      existing.totalAvg += t.avg;
      existing.count++;
      allTransactions.set(t.label, existing);
    });
  });
  if (allTransactions.size > 0) {
    let worst = { label: '', avg: 0 };
    allTransactions.forEach((val, label) => {
      const avg = val.totalAvg / val.count;
      if (avg > worst.avg) worst = { label, avg };
    });
    if (worst.label) {
      insights.push(`Slowest transaction: "${worst.label}" averaging ${Math.round(worst.avg)}ms across all runs.`);
    }
  }

  const avgErrorRate = chartData.reduce((s, d) => s + d.errorRate, 0) / chartData.length;
  const errorStdDev = Math.sqrt(chartData.reduce((s, d) => s + (d.errorRate - avgErrorRate) ** 2, 0) / chartData.length);
  if (avgErrorRate > 5) {
    insights.push(`Average error rate is ${avgErrorRate.toFixed(1)}% — investigate failing transactions.`);
  } else if (errorStdDev > 2) {
    insights.push(`Error rate is unstable (stddev ${errorStdDev.toFixed(1)}%) — intermittent failures detected.`);
  }

  if (regressionCount > 0) {
    insights.push(`${regressionCount} performance regression${regressionCount > 1 ? 's' : ''} detected via Z-score analysis.`);
  }

  const achievedCount = filteredData.filter(d => d.achievementVerdict === 'achieved').length;
  const totalWithTargets = filteredData.filter(d => d.achievementVerdict !== null).length;
  if (totalWithTargets > 0) {
    const rate = Math.round((achievedCount / totalWithTargets) * 100);
    insights.push(`Workload achievement: ${rate}% of targeted executions (${achievedCount}/${totalWithTargets}) met their targets.`);
  }

  return insights;
}

const SCATTER_COLORS = DT_PALETTE;

export default function TrendsPage() {
  const [selectedScript, setSelectedScript] = useState<string>("all");
  const [selectedEnv, setSelectedEnv] = useState<string>("all");
  const [selectedReleaseTag, setSelectedReleaseTag] = useState<string>("all");
  const [activeSection, setActiveSection] = useState<string>("latency");
  const [datePreset, setDatePreset] = useState<DatePreset>("all");
  const [customDateRange, setCustomDateRange] = useState<DateRange | undefined>(undefined);
  const [showPredictions, setShowPredictions] = useState(true);
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<string>("__all__");
  const [insightsExpanded, setInsightsExpanded] = useState(true);

  const { data: releaseTags } = useQuery<{ id: number; name: string; color: string | null }[]>({
    queryKey: queryKeys.releaseTags,
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/release-tags");
      return res.json();
    },
    staleTime: 60000,
  });

  const dateRange = useMemo(() => {
    const now = new Date();
    switch (datePreset) {
      case "7d": return { from: subDays(now, 7), to: now };
      case "14d": return { from: subDays(now, 14), to: now };
      case "30d": return { from: subDays(now, 30), to: now };
      case "90d": return { from: subMonths(now, 3), to: now };
      case "custom":
        if (customDateRange?.from) {
          return {
            from: startOfDay(customDateRange.from),
            to: customDateRange.to ? endOfDay(customDateRange.to) : endOfDay(now),
          };
        }
        return null;
      case "all":
      default:
        return null;
    }
  }, [datePreset, customDateRange]);

  const queryParams = useMemo(() => {
    const params: Record<string, string> = {};
    if (dateRange) {
      params.startDate = dateRange.from.toISOString();
      params.endDate = dateRange.to.toISOString();
    }
    if (selectedScript !== "all" && !selectedScript.startsWith("remote-")) {
      params.scriptId = selectedScript;
    }
    if (selectedEnv !== "all") {
      params.environment = selectedEnv;
    }
    if (selectedReleaseTag !== "all") {
      params.releaseTag = selectedReleaseTag;
    }
    return params;
  }, [dateRange, selectedScript, selectedEnv, selectedReleaseTag]);

  const { data: trendResponse, isLoading, isError, error, refetch } = useQuery<TrendResponse>({
    queryKey: queryKeys.trends.aggregated([queryParams]),
    queryFn: async () => {
      const searchParams = new URLSearchParams(queryParams);
      const res = await apiRequest("GET", `/api/trends/aggregated?${searchParams.toString()}`);
      return res.json();
    },
    staleTime: 30000,
  });

  if (isError) {
    return <QueryErrorFallback error={error as Error} onRetry={() => refetch()} title="Failed to load trends" />;
  }

  const trendData = trendResponse?.data || [];
  const availableScripts = trendResponse?.scripts || [];
  const availableEnvironments = trendResponse?.environments || [];

  const filteredData = useMemo(() => {
    let filtered = trendData;
    if (selectedScript !== "all") {
      filtered = filtered.filter(d => d.scriptId === selectedScript);
    }
    return filtered;
  }, [trendData, selectedScript]);

  const chartData = useMemo(() => {
    return filteredData.map((d, idx) => ({
      date: format(new Date(d.startTime), 'MM/dd HH:mm'),
      name: d.scheduleName,
      avgResponse: d.avgResponseTime,
      p50: d.p50 || 0,
      p90: d.p90 || 0,
      p95: d.p95,
      p99: d.p99,
      throughput: d.throughput,
      errorRate: d.errorRate,
      environment: d.environment,
      scriptName: d.scriptName,
      scriptId: d.scriptId,
      isRegression: d.isRegression,
      regressionConfidence: d.regressionConfidence,
      timestamp: new Date(d.startTime).getTime(),
      index: idx,
      transactions: d.transactions || [],
      achievementVerdict: d.achievementVerdict,
    }));
  }, [filteredData]);

  const latencyTrend = useMemo(() => computeTrendAndForecast(chartData, 'avgResponse'), [chartData]);
  const throughputTrend = useMemo(() => computeTrendAndForecast(chartData, 'throughput'), [chartData]);
  const errorTrend = useMemo(() => computeTrendAndForecast(chartData, 'errorRate'), [chartData]);
  const p95Trend = useMemo(() => computeTrendAndForecast(chartData, 'p95'), [chartData]);
  const p99Trend = useMemo(() => computeTrendAndForecast(chartData, 'p99'), [chartData]);

  const chartDataWithTrend = useMemo(() => {
    if (!showPredictions || chartData.length < 2) return chartData;

    return chartData.map((d, i) => ({
      ...d,
      avgResponseTrend: latencyTrend.trendLine[i]?.value,
      throughputTrend: throughputTrend.trendLine[i]?.value,
      errorRateTrend: errorTrend.trendLine[i]?.value,
    }));
  }, [chartData, latencyTrend, throughputTrend, errorTrend, showPredictions]);

  const forecastData = useMemo(() => {
    if (!showPredictions || chartData.length < 2) return [];
    const lastPoint = chartData[chartData.length - 1];
    if (!lastPoint) return [];

    const bridgePoint = {
      date: lastPoint.date,
      avgResponseForecast: lastPoint.avgResponse,
      throughputForecast: lastPoint.throughput,
      errorRateForecast: lastPoint.errorRate,
      avgResponseTrend: latencyTrend.trendLine[latencyTrend.trendLine.length - 1]?.value,
      throughputTrend: throughputTrend.trendLine[throughputTrend.trendLine.length - 1]?.value,
      errorRateTrend: errorTrend.trendLine[errorTrend.trendLine.length - 1]?.value,
      isForecast: false,
    };

    const forecasts = latencyTrend.forecast.map((f, i) => ({
      date: f.date,
      avgResponseForecast: f.value,
      throughputForecast: throughputTrend.forecast[i]?.value || 0,
      errorRateForecast: errorTrend.forecast[i]?.value || 0,
      isForecast: true,
    }));

    return [bridgePoint, ...forecasts];
  }, [chartData, latencyTrend, throughputTrend, errorTrend, showPredictions]);

  const passFailData = useMemo(() => {
    const dayMap = new Map<string, { date: string; passed: number; failed: number }>();
    filteredData.forEach(d => {
      const day = format(new Date(d.startTime), 'yyyy-MM-dd');
      const existing = dayMap.get(day) || { date: day, passed: 0, failed: 0 };
      existing.passed++;
      dayMap.set(day, existing);
    });
    return Array.from(dayMap.values()).sort((a, b) => a.date.localeCompare(b.date));
  }, [filteredData]);

  const envComparisonData = useMemo(() => {
    if (availableEnvironments.length < 2) return null;
    const envMap = new Map<string, { env: string; avgRT: number; p95: number; throughput: number; totalRequests: number; failedRequests: number; count: number }>();
    filteredData.forEach(d => {
      if (!d.environment || d.environment === 'unknown') return;
      const existing = envMap.get(d.environment) || { env: d.environment, avgRT: 0, p95: 0, throughput: 0, totalRequests: 0, failedRequests: 0, count: 0 };
      existing.avgRT += d.avgResponseTime;
      existing.p95 += d.p95;
      existing.throughput += d.throughput;
      existing.totalRequests += d.totalRequests;
      existing.failedRequests += d.failedRequests;
      existing.count++;
      envMap.set(d.environment, existing);
    });
    return Array.from(envMap.values()).map(e => ({
      env: e.env,
      avgRT: Math.round(e.avgRT / e.count),
      p95: Math.round(e.p95 / e.count),
      throughput: Math.round((e.throughput / e.count) * 10) / 10,
      errorRate: e.totalRequests > 0 ? Math.round((e.failedRequests / e.totalRequests) * 10000) / 100 : 0,
      count: e.count,
    }));
  }, [filteredData, availableEnvironments]);

  const scriptBreakdown = useMemo(() => {
    const scriptMap = new Map<string, { name: string; runs: { date: string; avgRT: number; p95: number; throughput: number; errorRate: number }[] }>();
    chartData.forEach(d => {
      const existing = scriptMap.get(d.scriptId) || { name: d.scriptName, runs: [] };
      existing.runs.push({
        date: d.date,
        avgRT: d.avgResponse,
        p95: d.p95,
        throughput: d.throughput,
        errorRate: d.errorRate,
      });
      scriptMap.set(d.scriptId, existing);
    });
    return Array.from(scriptMap.entries()).map(([id, data]) => {
      const runs = data.runs;
      const latestRT = Math.round(runs[runs.length - 1]?.avgRT || 0);
      const previousRT = runs.length > 1 ? runs[runs.length - 2]?.avgRT : latestRT;
      const change = previousRT > 0 ? ((latestRT - previousRT) / previousRT) * 100 : 0;
      const avgRT = runs.reduce((s, r) => s + r.avgRT, 0) / runs.length;
      const avgP95 = runs.reduce((s, r) => s + r.p95, 0) / runs.length;
      const avgThroughput = runs.reduce((s, r) => s + r.throughput, 0) / runs.length;
      const avgErrorRate = runs.reduce((s, r) => s + r.errorRate, 0) / runs.length;
      return {
        id,
        name: data.name,
        runs: runs.length,
        latestRT,
        avgRT: Math.round(avgRT),
        avgP95: Math.round(avgP95),
        avgThroughput: Math.round(avgThroughput * 10) / 10,
        avgErrorRate: Math.round(avgErrorRate * 100) / 100,
        change: Math.round(change * 10) / 10,
        trend: runs.map(r => r.avgRT),
      };
    }).sort((a, b) => b.change - a.change);
  }, [chartData]);

  const regressionPoints = useMemo(() => {
    return chartData.filter(d => d.isRegression);
  }, [chartData]);

  const stats = useMemo(() => {
    if (chartData.length < 2) return null;
    const recent = chartData.slice(-5);
    const older = chartData.slice(0, Math.min(5, chartData.length - 5));
    if (older.length === 0) return null;
    const avgRecent = recent.reduce((s, d) => s + d.avgResponse, 0) / recent.length;
    const avgOlder = older.reduce((s, d) => s + d.avgResponse, 0) / older.length;
    const tpsRecent = recent.reduce((s, d) => s + d.throughput, 0) / recent.length;
    const tpsOlder = older.reduce((s, d) => s + d.throughput, 0) / older.length;
    return {
      responseChange: ((avgRecent - avgOlder) / avgOlder) * 100,
      throughputChange: ((tpsRecent - tpsOlder) / tpsOlder) * 100,
      avgResponse: Math.round(avgRecent),
      avgThroughput: Math.round(tpsRecent * 10) / 10,
    };
  }, [chartData]);

  const allTransactionLabels = useMemo(() => {
    const labels = new Set<string>();
    filteredData.forEach(d => {
      d.transactions?.forEach(t => labels.add(t.label));
    });
    return Array.from(labels).sort();
  }, [filteredData]);

  const transactionChartData = useMemo(() => {
    if (selectedTransaction === "__all__" || !selectedTransaction) return [];
    return chartData.map(d => {
      const tx = d.transactions?.find(t => t.label === selectedTransaction);
      if (!tx) return null;
      return {
        date: d.date,
        avg: tx.avg,
        p95: tx.p95,
        throughput: tx.throughput,
        errorRate: tx.errorRate,
        scriptName: d.scriptName,
        timestamp: d.timestamp,
      };
    }).filter(Boolean);
  }, [chartData, selectedTransaction]);

  const scatterData = useMemo(() => {
    const scriptColorMap = new Map<string, string>();
    const scriptIds = Array.from(new Set(chartData.map(d => d.scriptId)));
    scriptIds.forEach((id, i) => {
      scriptColorMap.set(id, SCATTER_COLORS[i % SCATTER_COLORS.length]);
    });
    return chartData.map(d => ({
      throughput: d.throughput,
      avgResponse: d.avgResponse,
      scriptName: d.scriptName,
      scriptId: d.scriptId,
      date: d.date,
      name: d.name,
      color: scriptColorMap.get(d.scriptId) || DT_COLORS.primary,
      size: Math.max(40, Math.min(200, d.avgResponse / 5)),
    }));
  }, [chartData]);

  const achievementChartData = useMemo(() => {
    return chartData
      .filter(d => d.achievementVerdict !== null)
      .map(d => ({
        date: d.date,
        name: d.name,
        scriptName: d.scriptName,
        verdict: d.achievementVerdict!,
        value: d.achievementVerdict === 'achieved' ? 3 : d.achievementVerdict === 'partially_achieved' ? 2 : 1,
        fill: d.achievementVerdict === 'achieved' ? DT_COLORS.green : d.achievementVerdict === 'partially_achieved' ? DT_COLORS.amber : DT_COLORS.red,
      }));
  }, [chartData]);

  const insights = useMemo(() => {
    return generateInsights(chartData, filteredData, regressionPoints.length);
  }, [chartData, filteredData, regressionPoints]);

  const tooltipStyle = DT_TOOLTIP_STYLE;

  const dateRangeLabel = useMemo(() => {
    switch (datePreset) {
      case "7d": return "Last 7 days";
      case "14d": return "Last 14 days";
      case "30d": return "Last 30 days";
      case "90d": return "Last 90 days";
      case "custom":
        if (customDateRange?.from) {
          const from = format(customDateRange.from, 'MMM d');
          const to = customDateRange.to ? format(customDateRange.to, 'MMM d') : 'now';
          return `${from} - ${to}`;
        }
        return "Pick dates";
      default: return "All time";
    }
  }, [datePreset, customDateRange]);

  const handlePresetClick = useCallback((preset: DatePreset) => {
    setDatePreset(preset);
    if (preset !== "custom") {
      setCustomDateRange(undefined);
      setCalendarOpen(false);
    }
  }, []);

  const getTrendDescription = useCallback((slope: number, metric: string, unit: string) => {
    if (Math.abs(slope) < 0.01) return `${metric} is stable`;
    const dir = slope > 0 ? 'increasing' : 'decreasing';
    const perRun = Math.abs(Math.round(slope * 100) / 100);
    return `${metric} ${dir} ~${perRun}${unit}/run`;
  }, []);

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulseGlow {
          0%, 100% { opacity: 0.4; transform: scale(1); }
          50% { opacity: 0.7; transform: scale(1.05); }
        }
      `}</style>

      <PageHeader
        title="Performance Trends"
        subtitle={`Analyze performance changes over time across test executions${trendResponse ? ` (${trendResponse.total} executions)` : ''}`}
        actions={
          <div className="flex flex-wrap gap-2 items-center">
            <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="gap-2 min-w-[160px]">
                  <CalendarRange className="h-4 w-4" />
                  {dateRangeLabel}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <div className="p-3 border-b space-y-2">
                  <div className="text-sm font-medium text-muted-foreground mb-2">Quick Ranges</div>
                  <div className="flex flex-wrap gap-1.5">
                    {([
                      ["all", "All Time"],
                      ["7d", "7 Days"],
                      ["14d", "14 Days"],
                      ["30d", "30 Days"],
                      ["90d", "90 Days"],
                    ] as [DatePreset, string][]).map(([key, label]) => (
                      <Button
                        key={key}
                        variant={datePreset === key ? "default" : "outline"}
                        size="sm"
                        className="text-xs h-7"
                        onClick={() => handlePresetClick(key)}
                      >
                        {label}
                      </Button>
                    ))}
                  </div>
                </div>
                <div className="p-1">
                  <div className="text-xs text-muted-foreground px-3 pt-2 pb-1 font-medium">Custom Range</div>
                  <CalendarComponent
                    mode="range"
                    selected={customDateRange}
                    onSelect={(range) => {
                      setCustomDateRange(range);
                      setDatePreset("custom");
                      if (range?.from && range?.to) {
                        setCalendarOpen(false);
                      }
                    }}
                    numberOfMonths={2}
                    disabled={{ after: new Date() }}
                    initialFocus
                  />
                </div>
              </PopoverContent>
            </Popover>

            <Select value={selectedScript} onValueChange={setSelectedScript}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Filter by script" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Scripts</SelectItem>
                {availableScripts.map(s => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedEnv} onValueChange={setSelectedEnv}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Filter by environment" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Environments</SelectItem>
                {availableEnvironments.map(env => (
                  <SelectItem key={env} value={env}>{env}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {releaseTags && releaseTags.length > 0 && (
              <Select value={selectedReleaseTag} onValueChange={setSelectedReleaseTag}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <div className="flex items-center gap-2">
                    <Tag className="h-3.5 w-3.5 text-muted-foreground" />
                    <SelectValue placeholder="Filter by release" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Releases</SelectItem>
                  {releaseTags.map(tag => (
                    <SelectItem key={tag.id} value={tag.name}>{tag.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
        }
      />

      {datePreset !== "all" && (
        <div className="flex items-center gap-2 text-sm">
          <Badge variant="outline" className="gap-1.5 px-3 py-1">
            <Calendar className="h-3.5 w-3.5" />
            {dateRangeLabel}
          </Badge>
          <span className="text-muted-foreground">
            {filteredData.length} execution{filteredData.length !== 1 ? 's' : ''} in range
          </span>
          <Button variant="ghost" size="sm" className="text-xs h-6 px-2" onClick={() => handlePresetClick("all")}>
            Clear
          </Button>
        </div>
      )}

      {stats && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            label="Avg Response Time"
            value={`${stats.avgResponse}ms`}
            change={stats.responseChange}
            higherIsBad={true}
            icon={<Clock className="w-5 h-5 text-white" />}
            gradient="from-blue-500 to-cyan-500"
          />
          <StatCard
            label="Avg Throughput"
            value={`${stats.avgThroughput}/s`}
            change={stats.throughputChange}
            higherIsBad={false}
            icon={<Zap className="w-5 h-5 text-white" />}
            gradient="from-emerald-500 to-green-500"
          />
          <StatCard
            label="Total Executions"
            value={`${filteredData.length}`}
            icon={<Activity className="w-5 h-5 text-white" />}
            gradient="from-violet-500 to-purple-500"
          />
          <StatCard
            label="Regressions Detected"
            value={`${regressionPoints.length}`}
            icon={<AlertTriangle className="w-5 h-5 text-white" />}
            gradient={regressionPoints.length > 0 ? "from-rose-500 to-red-500" : "from-emerald-500 to-green-500"}
          />
        </div>
      )}

      {!isLoading && insights.length > 0 && (
        <Card className="overflow-hidden border-l-4 border-l-amber-500/60">
          <CardHeader className="py-3 cursor-pointer" onClick={() => setInsightsExpanded(!insightsExpanded)}>
            <CardTitle className="flex items-center gap-2 text-base">
              <Lightbulb className="h-4 w-4 text-amber-500" />
              Automated Insights
              <Badge variant="outline" className="text-xs ml-1">{insights.length}</Badge>
              <span className="ml-auto">
                {insightsExpanded ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
              </span>
            </CardTitle>
          </CardHeader>
          {insightsExpanded && (
            <CardContent className="pt-0 pb-4">
              <ul className="space-y-2">
                {insights.map((insight, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <span className="mt-1 h-1.5 w-1.5 rounded-full bg-amber-500 shrink-0" />
                    {insight}
                  </li>
                ))}
              </ul>
            </CardContent>
          )}
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-28 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-10 w-full max-w-md rounded-lg" />
          <Skeleton className="h-80 w-full rounded-xl" />
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      ) : chartData.length === 0 ? (
        <EmptyState
          icon={TrendingUp}
          title="No Trend Data Available"
          description={datePreset !== "all"
            ? "No completed executions in this date range. Try expanding the range."
            : "Complete some test executions to see performance trends."}
        />
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <Tabs value={activeSection} onValueChange={setActiveSection}>
              <TabsList className="flex flex-wrap h-auto gap-1 p-1">
                <TabsTrigger value="latency" className="text-xs sm:text-sm">Latency</TabsTrigger>
                <TabsTrigger value="percentiles" className="text-xs sm:text-sm">Percentiles</TabsTrigger>
                <TabsTrigger value="throughput" className="text-xs sm:text-sm">Throughput</TabsTrigger>
                <TabsTrigger value="errors" className="text-xs sm:text-sm">Errors</TabsTrigger>
                <TabsTrigger value="correlation" className="text-xs sm:text-sm">Correlation</TabsTrigger>
                <TabsTrigger value="transactions" className="text-xs sm:text-sm">Transactions</TabsTrigger>
                <TabsTrigger value="achievement" className="text-xs sm:text-sm">Achievement</TabsTrigger>
                <TabsTrigger value="passfail" className="text-xs sm:text-sm">Pass/Fail</TabsTrigger>
                <TabsTrigger value="envcompare" className="text-xs sm:text-sm">Environments</TabsTrigger>
              </TabsList>
            </Tabs>
            {chartData.length >= 2 && (
              <Button
                variant={showPredictions ? "default" : "outline"}
                size="sm"
                className="gap-1.5 ml-3 shrink-0"
                onClick={() => setShowPredictions(!showPredictions)}
              >
                <TrendingUp className="h-3.5 w-3.5" />
                Predictions
              </Button>
            )}
          </div>

          {activeSection === "latency" && (
            <Card className="overflow-hidden" style={{ borderTop: '3px solid transparent', borderImage: 'linear-gradient(to right, hsl(var(--primary)), hsl(var(--primary)/0.3)) 1' }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 flex-wrap">
                  Response Time Trend
                  <span className="text-xs font-normal text-muted-foreground">(Avg, Weighted P95, Weighted P99)</span>
                  {regressionPoints.length > 0 && (
                    <span className="ml-auto flex items-center gap-1 text-xs text-rose-500 font-medium">
                      <AlertTriangle className="h-3.5 w-3.5" />
                      {regressionPoints.length} regression{regressionPoints.length > 1 ? 's' : ''} detected
                      {regressionPoints.filter(r => r.regressionConfidence === 'high').length > 0 && (
                        <Badge variant="destructive" className="text-[10px] ml-1">
                          {regressionPoints.filter(r => r.regressionConfidence === 'high').length} high confidence
                        </Badge>
                      )}
                    </span>
                  )}
                </CardTitle>
                {showPredictions && chartData.length >= 2 && (
                  <TrendBadge slope={latencyTrend.slope} r2={latencyTrend.r2} description={getTrendDescription(latencyTrend.slope, 'Response time', 'ms')} higherIsBad />
                )}
              </CardHeader>
              <CardContent>
                <div className="h-[250px] sm:h-[300px] lg:h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={[...chartDataWithTrend, ...forecastData]}>
                      <CartesianGrid {...DT_GRID_PROPS} />
                      <DynatraceGradients />
                      <XAxis dataKey="date" {...DT_AXIS_PROPS} />
                      <YAxis {...DT_AXIS_PROPS} unit="ms" />
                      <Tooltip contentStyle={tooltipStyle} cursor={DT_CURSOR_PROPS} />
                      <Legend />
                      <Line type="monotone" dataKey="avgResponse" name="Avg (ms)" stroke={DT_COLORS.primary} strokeWidth={2} dot={false} connectNulls={false} />
                      <Line type="monotone" dataKey="p95" name="P95 (ms)" stroke={DT_COLORS.amber} strokeWidth={2} strokeDasharray="5 3" dot={false} connectNulls={false} />
                      <Line type="monotone" dataKey="p99" name="P99 (ms)" stroke={DT_COLORS.red} strokeWidth={2} strokeDasharray="2 2" dot={false} connectNulls={false} />
                      {showPredictions && chartData.length >= 2 && (
                        <>
                          <Line type="monotone" dataKey="avgResponseTrend" name="Trend" stroke={DT_COLORS.primary} strokeWidth={1.5} strokeDasharray="8 4" dot={false} connectNulls={false} />
                          <Line type="monotone" dataKey="avgResponseForecast" name="Forecast" stroke={DT_COLORS.primary} strokeWidth={2} strokeDasharray="3 3" dot={{ fill: DT_COLORS.primary, r: 4, strokeWidth: 2, stroke: '#fff' }} connectNulls />
                        </>
                      )}
                      {regressionPoints.map((point, i) => (
                        <ReferenceDot
                          key={i}
                          x={point.date}
                          y={point.avgResponse}
                          r={point.regressionConfidence === 'high' ? 10 : point.regressionConfidence === 'medium' ? 8 : 6}
                          fill={DT_COLORS.red}
                          stroke="#fff"
                          strokeWidth={2}
                        />
                      ))}
                      {forecastData.length > 0 && (
                        <ReferenceLine x={chartData[chartData.length - 1]?.date} stroke="hsl(var(--muted-foreground))" strokeDasharray="4 4" label={{ value: "Now", position: "top", fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                      )}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          {activeSection === "percentiles" && (
            <Card className="overflow-hidden" style={{ borderTop: `3px solid transparent`, borderImage: `linear-gradient(to right, ${DT_COLORS.purple}, ${DT_COLORS.purple}40) 1` }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 flex-wrap">
                  <BarChart3 className="h-5 w-5" />
                  Percentile Trend Comparison
                  <span className="text-xs font-normal text-muted-foreground">(P50, P90, P95, P99 overlay)</span>
                </CardTitle>
                {showPredictions && chartData.length >= 2 && (
                  <div className="flex flex-wrap gap-2">
                    <TrendBadge slope={p95Trend.slope} r2={p95Trend.r2} description={getTrendDescription(p95Trend.slope, 'P95', 'ms')} higherIsBad />
                    <TrendBadge slope={p99Trend.slope} r2={p99Trend.r2} description={getTrendDescription(p99Trend.slope, 'P99', 'ms')} higherIsBad />
                  </div>
                )}
              </CardHeader>
              <CardContent>
                <div className="h-[250px] sm:h-[300px] lg:h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                      <CartesianGrid {...DT_GRID_PROPS} />
                      <XAxis dataKey="date" {...DT_AXIS_PROPS} />
                      <YAxis {...DT_AXIS_PROPS} unit="ms" />
                      <Tooltip contentStyle={tooltipStyle} cursor={DT_CURSOR_PROPS} />
                      <Legend />
                      <Line type="monotone" dataKey="p50" name="P50 (ms)" stroke={DT_COLORS.primary} strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="p90" name="P90 (ms)" stroke={DT_COLORS.teal} strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="p95" name="P95 (ms)" stroke={DT_COLORS.amber} strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="p99" name="P99 (ms)" stroke={DT_COLORS.red} strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          {activeSection === "throughput" && (
            <Card className="overflow-hidden" style={{ borderTop: `3px solid transparent`, borderImage: `linear-gradient(to right, ${DT_COLORS.green}, ${DT_COLORS.green}40) 1` }}>
              <CardHeader>
                <CardTitle>Throughput Trend</CardTitle>
                {showPredictions && chartData.length >= 2 && (
                  <TrendBadge slope={throughputTrend.slope} r2={throughputTrend.r2} description={getTrendDescription(throughputTrend.slope, 'Throughput', '/s')} higherIsBad={false} />
                )}
              </CardHeader>
              <CardContent>
                <div className="h-[250px] sm:h-[300px] lg:h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={[...chartDataWithTrend, ...forecastData]}>
                      <CartesianGrid {...DT_GRID_PROPS} />
                      <XAxis dataKey="date" {...DT_AXIS_PROPS} />
                      <YAxis {...DT_AXIS_PROPS} />
                      <Tooltip contentStyle={tooltipStyle} cursor={DT_CURSOR_PROPS} />
                      <Legend />
                      <Line type="monotone" dataKey="throughput" name="Throughput (/s)" stroke={DT_COLORS.green} strokeWidth={2} dot={false} connectNulls={false} />
                      {showPredictions && chartData.length >= 2 && (
                        <>
                          <Line type="monotone" dataKey="throughputTrend" name="Trend" stroke={DT_COLORS.green} strokeWidth={1.5} strokeDasharray="8 4" dot={false} connectNulls={false} />
                          <Line type="monotone" dataKey="throughputForecast" name="Forecast" stroke={DT_COLORS.green} strokeWidth={2} strokeDasharray="3 3" dot={{ fill: DT_COLORS.green, r: 4, strokeWidth: 2, stroke: '#fff' }} connectNulls />
                        </>
                      )}
                      {forecastData.length > 0 && (
                        <ReferenceLine x={chartData[chartData.length - 1]?.date} stroke="hsl(var(--muted-foreground))" strokeDasharray="4 4" label={{ value: "Now", position: "top", fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                      )}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          {activeSection === "errors" && (
            <Card className="overflow-hidden" style={{ borderTop: `3px solid transparent`, borderImage: `linear-gradient(to right, ${DT_COLORS.red}, ${DT_COLORS.red}40) 1` }}>
              <CardHeader>
                <CardTitle>Error Rate Trend</CardTitle>
                {showPredictions && chartData.length >= 2 && (
                  <TrendBadge slope={errorTrend.slope} r2={errorTrend.r2} description={getTrendDescription(errorTrend.slope, 'Error rate', '%')} higherIsBad />
                )}
              </CardHeader>
              <CardContent>
                <div className="h-[250px] sm:h-[300px] lg:h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={[...chartDataWithTrend, ...forecastData]}>
                      <CartesianGrid {...DT_GRID_PROPS} />
                      <XAxis dataKey="date" {...DT_AXIS_PROPS} />
                      <YAxis {...DT_AXIS_PROPS} unit="%" />
                      <Tooltip contentStyle={tooltipStyle} cursor={DT_CURSOR_PROPS} />
                      <Legend />
                      <Line type="monotone" dataKey="errorRate" name="Error Rate (%)" stroke={DT_COLORS.red} strokeWidth={2} dot={false} connectNulls={false} />
                      {showPredictions && chartData.length >= 2 && (
                        <>
                          <Line type="monotone" dataKey="errorRateTrend" name="Trend" stroke={DT_COLORS.red} strokeWidth={1.5} strokeDasharray="8 4" dot={false} connectNulls={false} />
                          <Line type="monotone" dataKey="errorRateForecast" name="Forecast" stroke={DT_COLORS.red} strokeWidth={2} strokeDasharray="3 3" dot={{ fill: DT_COLORS.red, r: 4, strokeWidth: 2, stroke: '#fff' }} connectNulls />
                        </>
                      )}
                      {forecastData.length > 0 && (
                        <ReferenceLine x={chartData[chartData.length - 1]?.date} stroke="hsl(var(--muted-foreground))" strokeDasharray="4 4" label={{ value: "Now", position: "top", fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                      )}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          {activeSection === "correlation" && (
            <Card className="overflow-hidden" style={{ borderTop: `3px solid transparent`, borderImage: `linear-gradient(to right, ${DT_COLORS.primary}, ${DT_COLORS.primary}40) 1` }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowUpDown className="h-5 w-5" />
                  Throughput vs Response Time Correlation
                  <span className="text-xs font-normal text-muted-foreground">(Each dot = one execution)</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] sm:h-[350px] lg:h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart>
                      <CartesianGrid {...DT_GRID_PROPS} />
                      <XAxis
                        type="number"
                        dataKey="throughput"
                        name="Throughput"
                        unit="/s"
                        {...DT_AXIS_PROPS}
                        label={{ value: 'Throughput (/s)', position: 'insideBottom', offset: -5, fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      />
                      <YAxis
                        type="number"
                        dataKey="avgResponse"
                        name="Avg RT"
                        unit="ms"
                        {...DT_AXIS_PROPS}
                        label={{ value: 'Avg Response Time (ms)', angle: -90, position: 'insideLeft', offset: 10, fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      />
                      <ZAxis range={[60, 200]} />
                      <Tooltip
                        contentStyle={tooltipStyle}
                        content={({ active, payload }) => {
                          if (!active || !payload || payload.length === 0) return null;
                          const d = payload[0]?.payload;
                          return (
                            <div className="bg-card border border-border rounded-lg p-3 shadow-lg text-sm space-y-1">
                              <div className="font-medium">{d?.name || d?.scriptName}</div>
                              <div className="text-muted-foreground">{d?.date}</div>
                              <div>Throughput: <span className="font-medium">{d?.throughput}/s</span></div>
                              <div>Avg RT: <span className="font-medium">{d?.avgResponse}ms</span></div>
                              <div>Script: <span className="font-medium">{d?.scriptName}</span></div>
                            </div>
                          );
                        }}
                      />
                      <Scatter data={scatterData} name="Executions">
                        {scatterData.map((entry, idx) => (
                          <Cell key={idx} fill={entry.color} />
                        ))}
                      </Scatter>
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex flex-wrap gap-3 mt-3 justify-center">
                  {Array.from(new Set(scatterData.map(d => d.scriptId))).map((scriptId, i) => {
                    const scriptName = scatterData.find(d => d.scriptId === scriptId)?.scriptName || scriptId;
                    return (
                      <div key={scriptId} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: SCATTER_COLORS[i % SCATTER_COLORS.length] }} />
                        {scriptName}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {activeSection === "transactions" && (
            <Card className="overflow-hidden" style={{ borderTop: `3px solid transparent`, borderImage: `linear-gradient(to right, ${DT_COLORS.teal}, ${DT_COLORS.teal}40) 1` }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 flex-wrap">
                  <Crosshair className="h-5 w-5" />
                  Transaction-Level Trend Drilldown
                </CardTitle>
                <div className="mt-2">
                  <Select value={selectedTransaction} onValueChange={setSelectedTransaction}>
                    <SelectTrigger className="w-full sm:w-[300px]">
                      <SelectValue placeholder="Select a transaction" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__all__">-- Select a transaction --</SelectItem>
                      {allTransactionLabels.map(label => (
                        <SelectItem key={label} value={label}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                {selectedTransaction === "__all__" || allTransactionLabels.length === 0 ? (
                  <div className="flex items-center justify-center h-[250px] text-muted-foreground">
                    {allTransactionLabels.length === 0
                      ? "No transaction-level data available in the selected executions."
                      : "Select a transaction from the dropdown above to see its trend."}
                  </div>
                ) : transactionChartData.length === 0 ? (
                  <div className="flex items-center justify-center h-[250px] text-muted-foreground">
                    No data found for "{selectedTransaction}" in the selected executions.
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="h-[250px] sm:h-[300px] lg:h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={transactionChartData}>
                          <CartesianGrid {...DT_GRID_PROPS} />
                          <XAxis dataKey="date" {...DT_AXIS_PROPS} />
                          <YAxis yAxisId="left" {...DT_AXIS_PROPS} unit="ms" />
                          <YAxis yAxisId="right" orientation="right" {...DT_AXIS_PROPS} unit="/s" />
                          <Tooltip contentStyle={tooltipStyle} cursor={DT_CURSOR_PROPS} />
                          <Legend />
                          <Line yAxisId="left" type="monotone" dataKey="avg" name="Avg RT (ms)" stroke={DT_COLORS.primary} strokeWidth={2} dot={false} />
                          <Line yAxisId="left" type="monotone" dataKey="p95" name="P95 (ms)" stroke={DT_COLORS.amber} strokeWidth={2} dot={false} />
                          <Line yAxisId="right" type="monotone" dataKey="throughput" name="Throughput (/s)" stroke={DT_COLORS.green} strokeWidth={2} dot={false} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {activeSection === "achievement" && (
            <Card className="overflow-hidden" style={{ borderTop: `3px solid transparent`, borderImage: `linear-gradient(to right, ${DT_COLORS.green}, ${DT_COLORS.green}40) 1` }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Workload Achievement Trend
                  <span className="text-xs font-normal text-muted-foreground">(Only executions with workload targets)</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {achievementChartData.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-[250px] text-muted-foreground gap-2">
                    <Target className="h-8 w-8 opacity-40" />
                    <span>No executions with workload targets found.</span>
                    <span className="text-xs">Set targets via the Workload Model Calculator or on individual executions.</span>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="h-[250px] sm:h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={achievementChartData}>
                          <CartesianGrid {...DT_GRID_PROPS} />
                          <XAxis dataKey="date" {...DT_AXIS_PROPS} />
                          <YAxis
                            {...DT_AXIS_PROPS}
                            domain={[0, 3.5]}
                            ticks={[1, 2, 3]}
                            tickFormatter={(v: number) => v === 3 ? 'Achieved' : v === 2 ? 'Partial' : v === 1 ? 'Not Met' : ''}
                          />
                          <Tooltip
                            contentStyle={tooltipStyle}
                            cursor={DT_CURSOR_PROPS}
                            content={({ active, payload }) => {
                              if (!active || !payload || payload.length === 0) return null;
                              const d = payload[0]?.payload;
                              const verdictLabel = d?.verdict === 'achieved' ? 'Achieved' : d?.verdict === 'partially_achieved' ? 'Partially Achieved' : 'Not Achieved';
                              return (
                                <div className="bg-card border border-border rounded-lg p-3 shadow-lg text-sm space-y-1">
                                  <div className="font-medium">{d?.name}</div>
                                  <div className="text-muted-foreground">{d?.date}</div>
                                  <div className="flex items-center gap-2">
                                    Verdict: <Badge className={`text-xs ${d?.verdict === 'achieved' ? 'bg-emerald-500' : d?.verdict === 'partially_achieved' ? 'bg-amber-500' : 'bg-red-500'}`}>{verdictLabel}</Badge>
                                  </div>
                                  <div className="text-muted-foreground">{d?.scriptName}</div>
                                </div>
                              );
                            }}
                          />
                          <Bar dataKey="value" name="Achievement" radius={[4, 4, 0, 0]}>
                            {achievementChartData.map((entry, idx) => (
                              <Cell key={idx} fill={entry.fill} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm bg-emerald-500" /> Achieved</div>
                      <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm bg-amber-500" /> Partially Achieved</div>
                      <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm bg-red-500" /> Not Achieved</div>
                    </div>
                    <div className="grid grid-cols-3 gap-3 text-center">
                      <Card className="p-3 border-emerald-500/20">
                        <div className="text-2xl font-bold text-emerald-500">{achievementChartData.filter(d => d.verdict === 'achieved').length}</div>
                        <div className="text-xs text-muted-foreground">Achieved</div>
                      </Card>
                      <Card className="p-3 border-amber-500/20">
                        <div className="text-2xl font-bold text-amber-500">{achievementChartData.filter(d => d.verdict === 'partially_achieved').length}</div>
                        <div className="text-xs text-muted-foreground">Partial</div>
                      </Card>
                      <Card className="p-3 border-red-500/20">
                        <div className="text-2xl font-bold text-red-500">{achievementChartData.filter(d => d.verdict === 'not_achieved').length}</div>
                        <div className="text-xs text-muted-foreground">Not Met</div>
                      </Card>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {activeSection === "passfail" && (
            <Card className="overflow-hidden" style={{ borderTop: `3px solid transparent`, borderImage: `linear-gradient(to right, ${DT_COLORS.purple}, ${DT_COLORS.purple}40) 1` }}>
              <CardHeader>
                <CardTitle>Pass / Fail Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                {passFailData.length === 0 ? (
                  <div className="flex items-center justify-center h-[250px] text-muted-foreground">No pass/fail data available</div>
                ) : (
                  <div className="h-[250px] sm:h-[300px] lg:h-[350px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={passFailData}>
                        <CartesianGrid {...DT_GRID_PROPS} />
                        <XAxis dataKey="date" {...DT_AXIS_PROPS} />
                        <YAxis {...DT_AXIS_PROPS} allowDecimals={false} />
                        <Tooltip contentStyle={tooltipStyle} cursor={DT_CURSOR_PROPS} />
                        <Legend />
                        <Bar dataKey="passed" name="Passed" stackId="a" fill={DT_COLORS.green} radius={[0, 0, 0, 0]} />
                        <Bar dataKey="failed" name="Failed" stackId="a" fill={DT_COLORS.red} radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {activeSection === "envcompare" && (
            <Card className="overflow-hidden" style={{ borderTop: `3px solid transparent`, borderImage: `linear-gradient(to right, ${DT_COLORS.purple}, ${DT_COLORS.purple}40) 1` }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <GitCompare className="h-5 w-5" />
                  Environment Comparison
                </CardTitle>
              </CardHeader>
              <CardContent>
                {!envComparisonData || envComparisonData.length < 2 ? (
                  <div className="flex items-center justify-center h-[200px] text-muted-foreground">
                    Run tests in at least 2 different environments to see comparisons.
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="h-[250px] sm:h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={envComparisonData}>
                          <CartesianGrid {...DT_GRID_PROPS} />
                          <XAxis dataKey="env" {...DT_AXIS_PROPS} />
                          <YAxis {...DT_AXIS_PROPS} />
                          <Tooltip contentStyle={tooltipStyle} cursor={DT_CURSOR_PROPS} />
                          <Legend />
                          <Bar dataKey="avgRT" name="Avg RT (ms)" fill={DT_COLORS.primary} radius={[4, 4, 0, 0]} />
                          <Bar dataKey="p95" name="P95 (ms)" fill={DT_COLORS.amber} radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {envComparisonData.map(env => (
                        <Card key={env.env} className="p-3 border">
                          <div className="text-xs uppercase text-muted-foreground font-bold tracking-wider mb-2">{env.env}</div>
                          <div className="space-y-1 text-sm">
                            <div className="flex justify-between"><span className="text-muted-foreground">Tests:</span> <span className="font-medium">{env.count}</span></div>
                            <div className="flex justify-between"><span className="text-muted-foreground">Avg RT:</span> <span className="font-medium">{env.avgRT}ms</span></div>
                            <div className="flex justify-between"><span className="text-muted-foreground">P95:</span> <span className="font-medium">{env.p95}ms</span></div>
                            <div className="flex justify-between"><span className="text-muted-foreground">TPS:</span> <span className="font-medium">{env.throughput}/s</span></div>
                            <div className="flex justify-between"><span className="text-muted-foreground">Errors:</span> <span className={`font-medium ${env.errorRate > 5 ? 'text-rose-500' : 'text-emerald-500'}`}>{env.errorRate}%</span></div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {scriptBreakdown.length > 1 && (
            <Card className="overflow-hidden" style={{ borderTop: `3px solid transparent`, borderImage: `linear-gradient(to right, ${DT_COLORS.primary}, ${DT_COLORS.primary}40) 1` }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="h-5 w-5" />
                  Script Performance Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2 font-medium text-muted-foreground">Script</th>
                        <th className="text-right p-2 font-medium text-muted-foreground">Runs</th>
                        <th className="text-right p-2 font-medium text-muted-foreground">Latest RT</th>
                        <th className="text-right p-2 font-medium text-muted-foreground">Avg RT</th>
                        <th className="text-right p-2 font-medium text-muted-foreground">Avg P95</th>
                        <th className="text-right p-2 font-medium text-muted-foreground">TPS</th>
                        <th className="text-right p-2 font-medium text-muted-foreground">Error %</th>
                        <th className="text-right p-2 font-medium text-muted-foreground">Change</th>
                        <th className="text-center p-2 font-medium text-muted-foreground">Trend</th>
                      </tr>
                    </thead>
                    <tbody>
                      {scriptBreakdown.map(script => {
                        const maxRT = Math.max(...script.trend);
                        const minRT = Math.min(...script.trend);
                        const range = maxRT - minRT || 1;
                        const points = script.trend.map((val, i) => {
                          const x = (i / Math.max(script.trend.length - 1, 1)) * 80;
                          const y = 20 - ((val - minRT) / range) * 16;
                          return `${x},${y}`;
                        }).join(' ');
                        const trendColor = script.change > 10 ? DT_COLORS.red : script.change < -10 ? DT_COLORS.green : DT_COLORS.primary;

                        return (
                          <tr key={script.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                            <td className="p-2 font-medium truncate max-w-[200px]">{script.name}</td>
                            <td className="p-2 text-right">{script.runs}</td>
                            <td className="p-2 text-right">{script.latestRT}ms</td>
                            <td className="p-2 text-right">{script.avgRT}ms</td>
                            <td className="p-2 text-right">{script.avgP95}ms</td>
                            <td className="p-2 text-right">{script.avgThroughput}/s</td>
                            <td className={`p-2 text-right ${script.avgErrorRate > 5 ? 'text-rose-500' : 'text-emerald-500'}`}>
                              {script.avgErrorRate}%
                            </td>
                            <td className={`p-2 text-right font-medium ${script.change > 10 ? 'text-rose-500' : script.change < -10 ? 'text-emerald-500' : 'text-muted-foreground'}`}>
                              {script.change > 0 ? '+' : ''}{script.change}%
                            </td>
                            <td className="p-2 text-center">
                              {script.trend.length > 1 ? (
                                <svg width="80" height="24" viewBox="0 0 80 24" className="inline-block">
                                  <polyline fill="none" stroke={trendColor} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" points={points} />
                                </svg>
                              ) : (
                                <span className="text-muted-foreground text-xs">-</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, change, higherIsBad, icon, gradient, smallValue }: { label: string; value: string; change?: number; higherIsBad?: boolean; icon: React.ReactNode; gradient: string; smallValue?: boolean }) {
  const isImproving = change !== undefined ? (higherIsBad ? change < 0 : change > 0) : false;
  const isNeutral = change !== undefined ? Math.abs(change) < 1 : true;

  return (
    <Card className="p-4 transition-all duration-200 hover:shadow-lg hover:shadow-primary/5">
      <div className="flex items-start gap-3">
        <div className={`p-2.5 rounded-xl bg-gradient-to-br ${gradient} shadow-lg`}>
          {icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-xs uppercase text-muted-foreground font-bold tracking-wider">{label}</div>
          <div className={`${smallValue ? 'text-sm' : 'text-2xl'} font-bold mt-1 truncate`}>{value}</div>
          {change !== undefined && (
            <div className={`flex items-center gap-1 mt-2 text-sm font-medium ${isNeutral ? 'text-muted-foreground' : isImproving ? 'text-emerald-500' : 'text-rose-500'}`}>
              {isNeutral ? <Minus className="w-4 h-4" /> : isImproving ? <TrendingDown className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
              {Math.abs(change).toFixed(1)}% vs previous
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}

function TrendBadge({ slope, r2, description, higherIsBad }: { slope: number; r2: number; description: string; higherIsBad: boolean }) {
  const isStable = Math.abs(slope) < 0.01;
  const isGood = isStable || (higherIsBad ? slope < 0 : slope > 0);
  const confidence = r2 >= 0.7 ? 'high' : r2 >= 0.4 ? 'moderate' : 'low';

  return (
    <div className="flex items-center gap-2 flex-wrap mt-1">
      <Badge
        variant="outline"
        className={`gap-1 text-xs ${isStable ? 'border-muted-foreground/30 text-muted-foreground' : isGood ? 'border-emerald-500/30 text-emerald-500' : 'border-rose-500/30 text-rose-500'}`}
      >
        {isStable ? <Minus className="h-3 w-3" /> : isGood ? <TrendingDown className="h-3 w-3" /> : <TrendingUp className="h-3 w-3" />}
        {description}
      </Badge>
      <Badge variant="outline" className="gap-1 text-xs text-muted-foreground">
        R² = {r2.toFixed(2)} ({confidence} fit)
      </Badge>
    </div>
  );
}
