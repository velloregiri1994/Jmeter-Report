export interface FieldTemplate {
  name: string;
  type: string;
  enumValues?: string;
  pattern?: string;
  min?: number;
  max?: number;
}

export interface DataTemplate {
  label: string;
  description: string;
  icon: string;
  fields: FieldTemplate[];
}

export const TEMPLATES: DataTemplate[] = [
  {
    label: "User Profile",
    description: "Names, emails, phones, and demographics",
    icon: "user",
    fields: [
      { name: "id", type: "sequential_id" },
      { name: "first_name", type: "first_name" },
      { name: "last_name", type: "last_name" },
      { name: "email", type: "email" },
      { name: "phone", type: "phone" },
      { name: "username", type: "username" },
      { name: "gender", type: "gender" },
      { name: "age", type: "age" },
      { name: "city", type: "city" },
      { name: "country", type: "country" },
    ],
  },
  {
    label: "E-commerce Order",
    description: "Orders with products, amounts, and status",
    icon: "shopping-cart",
    fields: [
      { name: "order_id", type: "pattern", pattern: "ORD-######" },
      { name: "customer_name", type: "full_name" },
      { name: "email", type: "email" },
      { name: "product_id", type: "pattern", pattern: "SKU-????-####" },
      { name: "quantity", type: "integer_range", min: 1, max: 10 },
      { name: "amount", type: "currency_amount" },
      { name: "currency", type: "currency_code" },
      { name: "status", type: "weighted_enum", enumValues: "Completed:50,Processing:25,Shipped:15,Cancelled:5,Refunded:5" },
      { name: "order_date", type: "past_date" },
      { name: "shipping_address", type: "full_address" },
    ],
  },
  {
    label: "API Request Log",
    description: "HTTP methods, URLs, status codes, and latency",
    icon: "globe",
    fields: [
      { name: "request_id", type: "uuid" },
      { name: "timestamp", type: "timestamp" },
      { name: "method", type: "http_method" },
      { name: "url", type: "url" },
      { name: "status_code", type: "http_status" },
      { name: "response_time_ms", type: "duration_ms", min: 5, max: 5000 },
      { name: "ip_address", type: "ip_address" },
      { name: "user_agent", type: "user_agent" },
      { name: "user_id", type: "pattern", pattern: "USR-######" },
    ],
  },
  {
    label: "Employee Directory",
    description: "HR records with roles, departments, and salaries",
    icon: "briefcase",
    fields: [
      { name: "employee_id", type: "employee_id" },
      { name: "first_name", type: "first_name" },
      { name: "last_name", type: "last_name" },
      { name: "email", type: "email" },
      { name: "phone", type: "phone" },
      { name: "department", type: "department" },
      { name: "job_title", type: "job_title" },
      { name: "salary", type: "salary" },
      { name: "hire_date", type: "past_date" },
      { name: "company", type: "company_name" },
    ],
  },
  {
    label: "Financial Transaction",
    description: "Banking transactions with accounts and amounts",
    icon: "credit-card",
    fields: [
      { name: "transaction_id", type: "uuid" },
      { name: "account_holder", type: "full_name" },
      { name: "account_number", type: "bank_account" },
      { name: "iban", type: "iban" },
      { name: "amount", type: "currency_amount" },
      { name: "currency", type: "currency_code" },
      { name: "type", type: "weighted_enum", enumValues: "Debit:45,Credit:45,Transfer:10" },
      { name: "status", type: "weighted_enum", enumValues: "Completed:80,Pending:15,Failed:5" },
      { name: "timestamp", type: "timestamp" },
    ],
  },
  {
    label: "IoT Sensor Data",
    description: "Device readings with timestamps and values",
    icon: "cpu",
    fields: [
      { name: "device_id", type: "pattern", pattern: "DEV-????-####" },
      { name: "timestamp", type: "timestamp" },
      { name: "temperature", type: "decimal_range", min: -20, max: 50 },
      { name: "humidity", type: "decimal_range", min: 0, max: 100 },
      { name: "pressure", type: "decimal_range", min: 980, max: 1040 },
      { name: "battery_pct", type: "percentage" },
      { name: "status", type: "weighted_enum", enumValues: "Online:85,Offline:10,Maintenance:5" },
      { name: "ip_address", type: "ip_address" },
      { name: "location", type: "city" },
    ],
  },
];
