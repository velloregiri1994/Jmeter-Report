const FIRST_NAMES_MALE = [
  "James","John","Robert","Michael","David","William","Richard","Joseph","Thomas","Charles",
  "Christopher","Daniel","Matthew","Anthony","Mark","Donald","Steven","Paul","Andrew","Joshua",
  "Kenneth","Kevin","Brian","George","Timothy","Ronald","Edward","Jason","Jeffrey","Ryan",
  "Jacob","Gary","Nicholas","Eric","Jonathan","Stephen","Larry","Justin","Scott","Brandon",
  "Benjamin","Samuel","Raymond","Gregory","Frank","Alexander","Patrick","Jack","Dennis","Jerry",
  "Tyler","Aaron","Jose","Nathan","Henry","Peter","Douglas","Adam","Zachary","Walter",
  "Kyle","Harold","Carl","Arthur","Dylan","Jesse","Jordan","Bryan","Billy","Bruce",
  "Gabriel","Logan","Albert","Willie","Alan","Eugene","Russell","Vincent","Elijah","Philip",
  "Harry","Evan","Mason","Ethan","Aiden","Noah","Liam","Oliver","Lucas","Sebastian",
  "Mateo","Leo","Adrian","Kai","Ezra","Miles","Caleb","Omar","Rahul","Arjun",
  "Wei","Hiroshi","Yuki","Carlos","Diego","Luis","Marco","Ahmed","Ali","Hassan",
  "Dmitri","Ivan","Andrei","Sven","Lars","Henrik","Finn","Oscar","Hugo","Felix",
];
const FIRST_NAMES_FEMALE = [
  "Mary","Patricia","Jennifer","Linda","Barbara","Elizabeth","Susan","Jessica","Sarah","Karen",
  "Lisa","Nancy","Betty","Margaret","Sandra","Ashley","Dorothy","Kimberly","Emily","Donna",
  "Michelle","Carol","Amanda","Melissa","Deborah","Stephanie","Rebecca","Sharon","Laura","Cynthia",
  "Kathleen","Amy","Angela","Shirley","Anna","Brenda","Pamela","Emma","Nicole","Helen",
  "Samantha","Katherine","Christine","Debra","Rachel","Carolyn","Janet","Catherine","Maria","Heather",
  "Diane","Ruth","Julie","Olivia","Joyce","Virginia","Victoria","Kelly","Lauren","Christina",
  "Joan","Evelyn","Judith","Megan","Andrea","Cheryl","Hannah","Jacqueline","Martha","Gloria",
  "Teresa","Ann","Sara","Madison","Frances","Kathryn","Janice","Jean","Abigail","Alice",
  "Julia","Judy","Sophia","Isabella","Mia","Charlotte","Amelia","Harper","Ella","Avery",
  "Sofia","Luna","Aria","Layla","Zoe","Nora","Priya","Aisha","Yuki","Mei",
  "Fatima","Aaliyah","Valentina","Camila","Gabriela","Natalia","Ingrid","Astrid","Freya","Clara",
];
const FIRST_NAMES = [...FIRST_NAMES_MALE, ...FIRST_NAMES_FEMALE];

const LAST_NAMES = [
  "Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis","Rodriguez","Martinez",
  "Hernandez","Lopez","Gonzalez","Wilson","Anderson","Thomas","Taylor","Moore","Jackson","Martin",
  "Lee","Perez","Thompson","White","Harris","Sanchez","Clark","Ramirez","Lewis","Robinson",
  "Walker","Young","Allen","King","Wright","Scott","Torres","Nguyen","Hill","Flores",
  "Green","Adams","Nelson","Baker","Hall","Rivera","Campbell","Mitchell","Carter","Roberts",
  "Gomez","Phillips","Evans","Turner","Diaz","Parker","Cruz","Edwards","Collins","Reyes",
  "Stewart","Morris","Morales","Murphy","Cook","Rogers","Gutierrez","Ortiz","Morgan","Cooper",
  "Peterson","Bailey","Reed","Kelly","Howard","Ramos","Kim","Cox","Ward","Richardson",
  "Watson","Brooks","Chavez","Wood","James","Bennett","Gray","Mendoza","Ruiz","Hughes",
  "Price","Alvarez","Castillo","Sanders","Patel","Myers","Long","Ross","Foster","Jimenez",
  "Powell","Jenkins","Perry","Russell","Sullivan","Bell","Coleman","Butler","Henderson","Barnes",
  "Gonzales","Fisher","Vasquez","Simmons","Graham","Murray","Ford","O'Brien","McCarthy","Chen",
  "Wang","Li","Zhang","Liu","Singh","Kumar","Sharma","Das","Tanaka","Yamamoto",
  "Sato","Suzuki","Mueller","Schmidt","Schneider","Fischer","Weber","Meyer","Wagner","Becker",
  "Johansson","Eriksson","Larsson","Nilsson","Petrov","Ivanov","Smirnov","Popov","Sokolov","Volkov",
];

const CITIES_WITH_STATE_ZIP: [string, string, string][] = [
  ["New York","New York","10001"],["Los Angeles","California","90001"],["Chicago","Illinois","60601"],
  ["Houston","Texas","77001"],["Phoenix","Arizona","85001"],["Philadelphia","Pennsylvania","19101"],
  ["San Antonio","Texas","78201"],["San Diego","California","92101"],["Dallas","Texas","75201"],
  ["San Jose","California","95101"],["Austin","Texas","73301"],["Jacksonville","Florida","32099"],
  ["Fort Worth","Texas","76101"],["Columbus","Ohio","43085"],["Charlotte","North Carolina","28201"],
  ["Indianapolis","Indiana","46201"],["San Francisco","California","94101"],["Seattle","Washington","98101"],
  ["Denver","Colorado","80201"],["Washington","District of Columbia","20001"],
  ["Nashville","Tennessee","37201"],["Oklahoma City","Oklahoma","73101"],["El Paso","Texas","79901"],
  ["Boston","Massachusetts","02101"],["Portland","Oregon","97201"],["Las Vegas","Nevada","89101"],
  ["Memphis","Tennessee","38101"],["Louisville","Kentucky","40201"],["Baltimore","Maryland","21201"],
  ["Milwaukee","Wisconsin","53201"],["Albuquerque","New Mexico","87101"],["Tucson","Arizona","85701"],
  ["Fresno","California","93701"],["Sacramento","California","95801"],["Mesa","Arizona","85201"],
  ["Kansas City","Missouri","64101"],["Atlanta","Georgia","30301"],["Omaha","Nebraska","68101"],
  ["Colorado Springs","Colorado","80901"],["Raleigh","North Carolina","27601"],
  ["Long Beach","California","90801"],["Virginia Beach","Virginia","23451"],
  ["Miami","Florida","33101"],["Oakland","California","94601"],["Minneapolis","Minnesota","55401"],
  ["Tampa","Florida","33601"],["Tulsa","Oklahoma","74101"],["Arlington","Texas","76001"],
  ["New Orleans","Louisiana","70112"],["Honolulu","Hawaii","96801"],["Anchorage","Alaska","99501"],
  ["Pittsburgh","Pennsylvania","15201"],["Cincinnati","Ohio","45201"],["St. Louis","Missouri","63101"],
  ["Cleveland","Ohio","44101"],["Detroit","Michigan","48201"],["Salt Lake City","Utah","84101"],
  ["Richmond","Virginia","23219"],["Boise","Idaho","83701"],["Des Moines","Iowa","50301"],
];

const COUNTRIES = [
  "United States","Canada","United Kingdom","Germany","France","Australia","Japan","Brazil",
  "India","Mexico","Italy","Spain","Netherlands","Sweden","Norway","Denmark","Finland",
  "Switzerland","South Korea","Singapore","New Zealand","Ireland","Belgium","Austria",
  "Portugal","Poland","Czech Republic","Argentina","Chile","Colombia","Peru","Israel",
  "South Africa","Thailand","Malaysia","Indonesia","Philippines","Vietnam","Taiwan","Egypt",
  "Nigeria","Kenya","Turkey","Greece","Romania","Hungary","Croatia","Iceland","Luxembourg",
];

const STREET_TYPES = ["St","Ave","Blvd","Dr","Ln","Rd","Way","Ct","Pl","Cir","Ter","Loop","Trail","Pike","Pkwy"];
const STREET_NAMES = [
  "Main","Oak","Maple","Cedar","Pine","Elm","Washington","Park","Lake","Hill",
  "River","Spring","Market","Church","High","Mill","Prospect","Center","School","Union",
  "Liberty","Franklin","Madison","Jefferson","Lincoln","Adams","Monroe","Jackson","Grant","Sherman",
  "Sunset","Forest","Meadow","Valley","Ridge","Mountain","Harbor","Bay","Ocean","Summit",
  "Willow","Birch","Hickory","Walnut","Cherry","Poplar","Magnolia","Aspen","Cypress","Laurel",
  "Woodland","Lakeview","Fairview","Highland","Greenwood","Brookside","Northview","Southgate","Eastwood","Westfield",
];

const COMPANY_PREFIXES = [
  "Apex","Global","Prime","Nova","Vertex","Nexus","Zenith","Pinnacle","Quantum","Vanguard",
  "Stellar","Atlas","Titan","Phoenix","Meridian","Catalyst","Summit","Horizon","Synergy","Matrix",
  "Pulse","Forge","Crest","Edge","Core","Orbit","Vector","Helix","Prism","Spectrum",
  "Dynamic","Insight","Pioneer","Ascend","Unity","Evoke","Kinetic","Lumina","Radiant","Swift",
];
const COMPANY_SUFFIXES = [
  "Technologies","Solutions","Systems","Industries","Enterprises","Group","Corp","Inc","Labs","Digital",
  "Analytics","Dynamics","Partners","Consulting","Software","Networks","Services","Innovations","Holdings","Ventures",
];
const COMPANY_PATTERNS = [
  (p: string, s: string) => `${p} ${s}`,
  (p: string, s: string) => `${p}${s.substring(0,4)}`,
  (p: string, _s: string) => `${p}io`,
  (p: string, _s: string) => `${p}ly`,
  (p: string, _s: string) => `${p} AI`,
  (p: string, s: string) => `${p} & ${pick(COMPANY_PREFIXES)} ${s}`,
];

const JOB_TITLES = [
  "Software Engineer","Senior Software Engineer","Staff Software Engineer","Principal Engineer",
  "Product Manager","Senior Product Manager","Director of Product","VP of Product",
  "Data Analyst","Senior Data Analyst","Data Scientist","Machine Learning Engineer",
  "UX Designer","Senior UX Designer","UI/UX Lead","Design Director",
  "DevOps Engineer","Site Reliability Engineer","Platform Engineer","Infrastructure Engineer",
  "QA Engineer","Senior QA Engineer","Test Automation Lead","Quality Director",
  "System Architect","Solutions Architect","Enterprise Architect","Cloud Architect",
  "Project Manager","Program Manager","Delivery Manager","Engineering Manager",
  "Business Analyst","Business Intelligence Analyst","Strategy Analyst","Operations Analyst",
  "Frontend Developer","Backend Developer","Full Stack Developer","Mobile Developer",
  "Database Administrator","Data Engineer","ETL Developer","BI Developer",
  "Network Engineer","Security Engineer","Cybersecurity Analyst","Penetration Tester",
  "Scrum Master","Agile Coach","Technical Product Owner","Release Manager",
  "Technical Writer","Documentation Engineer","Content Strategist","Knowledge Manager",
  "CTO","CIO","VP of Engineering","Director of Engineering",
  "Sales Engineer","Customer Success Manager","Support Engineer","Account Manager",
  "Marketing Manager","Growth Engineer","SEO Specialist","Content Marketing Manager",
  "Research Scientist","R&D Engineer","Innovation Lead","AI Research Engineer",
  "Compliance Officer","Risk Analyst","Audit Manager","Legal Counsel",
];

const DEPARTMENTS = [
  "Engineering","Product","Design","Marketing","Sales","Finance","Human Resources",
  "Operations","Customer Support","Legal","IT","Research & Development","Quality Assurance",
  "Business Development","Data Science","Security","Compliance","Strategy","Procurement",
  "Facilities","Communications","Training","Analytics","Infrastructure","Platform",
];

const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
  "Mozilla/5.0 (iPad; CPU OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
  "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.64 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.64 Mobile Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.2365.52",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 OPR/108.0.0.0",
];

const EMAIL_DOMAINS_PERSONAL = [
  "gmail.com","yahoo.com","outlook.com","hotmail.com","icloud.com","protonmail.com",
  "mail.com","aol.com","zoho.com","yandex.com","fastmail.com","tutanota.com",
  "gmx.com","inbox.com","live.com","msn.com",
];
const EMAIL_DOMAINS_BUSINESS = [
  "company.com","enterprise.io","corp.net","business.org","acme.com","techfirm.io",
  "globalops.com","innovate.co","solutions.net","services.org","consulting.com","agency.io",
];

const PARAGRAPHS = [
  "The system performance metrics indicate consistent throughput under nominal load conditions. Response times remain within acceptable thresholds across all monitored endpoints.",
  "Load testing revealed bottlenecks in the authentication service during peak concurrent user scenarios. Connection pool exhaustion occurred at approximately 2,500 simultaneous sessions.",
  "Database query optimization reduced average response time by 43% across the top 20 most frequently executed queries. Index restructuring contributed to the majority of improvements.",
  "The caching layer intercepts approximately 78% of read requests, significantly reducing database load. Cache invalidation strategies ensure data consistency within a 30-second window.",
  "API gateway rate limiting is configured at 1,000 requests per minute per client. Burst allowance permits temporary spikes of up to 1,500 requests without throttling.",
  "Horizontal scaling tests confirmed linear throughput increase up to 12 application nodes. Beyond this threshold, database connection saturation becomes the primary constraint.",
  "Memory profiling identified a gradual leak in the session management module, accumulating approximately 2MB per hour under sustained load. Garbage collection pauses averaged 45ms.",
  "Network latency between data centers averages 28ms with 99th percentile at 62ms. Cross-region replication maintains eventual consistency with a typical lag of under 500ms.",
  "SSL/TLS handshake overhead contributes approximately 120ms to initial connection time. HTTP/2 multiplexing reduces subsequent request latency by an average of 35%.",
  "Container orchestration handles automatic scaling based on CPU utilization thresholds. Scale-up triggers at 70% and scale-down initiates after 5 minutes below 30%.",
];

const SENTENCES = [
  "Performance testing completed successfully with all SLAs met.",
  "The application handled peak load without any service degradation.",
  "Response times remained stable throughout the entire test duration.",
  "No memory leaks were detected during the extended soak test.",
  "Database connection pooling is operating within expected parameters.",
  "The load balancer distributed traffic evenly across all available nodes.",
  "Error rates stayed below the 0.1% threshold during stress testing.",
  "Cache hit ratio exceeded 85% under typical production workload patterns.",
  "API throughput averaged 3,200 requests per second at steady state.",
  "Failover recovery completed within the 30-second SLA window.",
  "Thread pool utilization peaked at 73% during maximum concurrency.",
  "Garbage collection pauses did not exceed the 100ms budget.",
  "Network bandwidth utilization remained below 60% of available capacity.",
  "All health check endpoints responded within the 5-second timeout.",
  "The circuit breaker tripped after 5 consecutive failures as configured.",
];

const LOREM_WORDS = [
  "lorem","ipsum","dolor","sit","amet","consectetur","adipiscing","elit","sed","do",
  "eiusmod","tempor","incididunt","ut","labore","et","dolore","magna","aliqua","enim",
  "ad","minim","veniam","quis","nostrud","exercitation","ullamco","laboris","nisi",
  "aliquip","ex","ea","commodo","consequat","duis","aute","irure","in","reprehenderit",
  "voluptate","velit","esse","cillum","fugiat","nulla","pariatur","excepteur","sint","occaecat",
];

const TLD_LIST = ["com","net","org","io","co","dev","app","tech","cloud","digital"];
const URL_PATHS = [
  "api/v1","api/v2","users","products","orders","dashboard","settings","reports",
  "analytics","admin","auth","search","catalog","inventory","payments","notifications",
  "health","metrics","docs","webhooks","integrations","workflows","tasks","projects",
];

export type RngFn = () => number;

let _rng: RngFn = Math.random;

export function setRng(fn: RngFn) { _rng = fn; }
export function resetRng() { _rng = Math.random; }
export function rng(): number { return _rng(); }

export function createSeededRng(seed: number): RngFn {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function rand(min: number, max: number): number {
  return Math.floor(_rng() * (max - min + 1)) + min;
}

function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(_rng() * arr.length)];
}

function pickWeighted<T>(arr: readonly T[], bias: number = 0.3): T {
  if (_rng() < bias) {
    return arr[Math.floor(_rng() * Math.min(20, arr.length))];
  }
  return arr[Math.floor(_rng() * arr.length)];
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(_rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function uuid(): string {
  const hex = "0123456789abcdef";
  const parts = [8, 4, 4, 4, 12];
  return parts.map(len => {
    let s = "";
    for (let i = 0; i < len; i++) s += hex[rand(0, 15)];
    return s;
  }).join("-");
}

function ipv4(): string {
  return `${rand(1, 223)}.${rand(0, 255)}.${rand(0, 255)}.${rand(1, 254)}`;
}

function ipv6(): string {
  const parts: string[] = [];
  for (let i = 0; i < 8; i++) parts.push(rand(0, 0xffff).toString(16));
  return parts.join(":");
}

function macAddress(): string {
  const h = () => rand(0, 255).toString(16).padStart(2, "0").toUpperCase();
  return Array.from({ length: 6 }, h).join(":");
}

function creditCard(): string {
  const prefixes = ["4","51","52","53","54","55","34","37","6011","65"];
  const prefix = pick(prefixes);
  let num = prefix;
  const targetLen = prefix.startsWith("3") ? 15 : 16;
  while (num.length < targetLen - 1) num += rand(0, 9);
  let sum = 0;
  let alt = true;
  for (let i = num.length - 1; i >= 0; i--) {
    let n = parseInt(num[i]);
    if (alt) { n *= 2; if (n > 9) n -= 9; }
    sum += n;
    alt = !alt;
  }
  const check = (10 - (sum % 10)) % 10;
  return num + check;
}

function pad(n: number, len: number = 2): string {
  return n.toString().padStart(len, "0");
}

function randomDate(startYear: number, endYear: number): string {
  const y = rand(startYear, endYear);
  const m = rand(1, 12);
  const daysInMonth = new Date(y, m, 0).getDate();
  const d = rand(1, daysInMonth);
  return `${y}-${pad(m)}-${pad(d)}`;
}

function generatePassword(): string {
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const lower = "abcdefghjkmnpqrstuvwxyz";
  const digits = "23456789";
  const special = "!@#$%&*?";
  const len = rand(10, 16);
  let pw = "";
  pw += upper[rand(0, upper.length - 1)];
  pw += lower[rand(0, lower.length - 1)];
  pw += digits[rand(0, digits.length - 1)];
  pw += special[rand(0, special.length - 1)];
  const all = upper + lower + digits + special;
  while (pw.length < len) pw += all[rand(0, all.length - 1)];
  return shuffle(pw.split("")).join("");
}

function generateSSN(): string {
  return `${rand(100, 899)}-${pad(rand(1, 99))}-${pad(rand(1, 9999), 4)}`;
}

function generateIBAN(): string {
  const countries = [
    { code: "DE", len: 18 }, { code: "FR", len: 23 }, { code: "GB", len: 18 },
    { code: "ES", len: 20 }, { code: "IT", len: 23 }, { code: "NL", len: 14 },
  ];
  const c = pick(countries);
  let num = "";
  for (let i = 0; i < c.len; i++) num += rand(0, 9);
  return `${c.code}${pad(rand(10, 99))}${num}`;
}

function generateCurrency(): string {
  const amounts = [
    () => (rand(1, 999) + _rng()).toFixed(2),
    () => (rand(1000, 9999) + _rng()).toFixed(2),
    () => (rand(10000, 99999) + _rng()).toFixed(2),
    () => (rand(100, 9999) / 100).toFixed(2),
  ];
  return pick(amounts)();
}

function generateLoremSentence(): string {
  const len = rand(6, 15);
  const words: string[] = [];
  for (let i = 0; i < len; i++) words.push(pick(LOREM_WORDS));
  words[0] = words[0][0].toUpperCase() + words[0].slice(1);
  return words.join(" ") + ".";
}

function generateLoremParagraph(): string {
  const count = rand(2, 5);
  const sentences: string[] = [];
  for (let i = 0; i < count; i++) sentences.push(generateLoremSentence());
  return sentences.join(" ");
}

export interface RowContext {
  firstName: string;
  lastName: string;
  gender: "male" | "female";
  cityIdx: number;
  companyName: string;
  domainName: string;
  streetNum: number;
  streetName: string;
  streetType: string;
  streetExtra: string;
}

export function createRowContext(): RowContext {
  const gender: "male" | "female" = _rng() < 0.5 ? "male" : "female";
  const firstName = gender === "male" ? pick(FIRST_NAMES_MALE) : pick(FIRST_NAMES_FEMALE);
  const lastName = pickWeighted(LAST_NAMES);
  const cityIdx = rand(0, CITIES_WITH_STATE_ZIP.length - 1);
  const cp = pick(COMPANY_PREFIXES);
  const cs = pick(COMPANY_SUFFIXES);
  const companyName = pick(COMPANY_PATTERNS)(cp, cs);
  const domainName = `${cp.toLowerCase()}${pick(["tech", "corp", "hq", "io", "sys", "app"])}.${pick(TLD_LIST)}`;
  const streetNum = rand(1, 9999);
  const streetName = pick(STREET_NAMES);
  const streetType = pick(STREET_TYPES);
  const extraRoll = _rng();
  const streetExtra = extraRoll < 0.15 ? `, Apt ${rand(1, 999)}` : extraRoll < 0.25 ? `, Suite ${rand(100, 999)}` : extraRoll < 0.3 ? ` #${rand(1, 50)}` : "";
  return { firstName, lastName, gender, cityIdx, companyName, domainName, streetNum, streetName, streetType, streetExtra };
}

export function generateValue(
  type: string,
  rowIndex: number,
  ctx: RowContext,
  enumValues?: string,
  patternStr?: string,
  minVal?: number,
  maxVal?: number,
): string {
  switch (type) {
    case "first_name":
      return ctx.firstName;
    case "last_name":
      return ctx.lastName;
    case "full_name":
      return `${ctx.firstName} ${ctx.lastName}`;
    case "email": {
      const fn = ctx.firstName.toLowerCase().replace(/[^a-z]/g, "");
      const ln = ctx.lastName.toLowerCase().replace(/[^a-z]/g, "");
      const patterns = [
        () => `${fn}.${ln}@${pick(EMAIL_DOMAINS_PERSONAL)}`,
        () => `${fn}${ln}@${pick(EMAIL_DOMAINS_PERSONAL)}`,
        () => `${fn}.${ln}@${ctx.domainName}`,
        () => `${fn[0]}${ln}@${pick(EMAIL_DOMAINS_BUSINESS)}`,
        () => `${fn}_${ln}${rand(1, 99)}@${pick(EMAIL_DOMAINS_PERSONAL)}`,
        () => `${fn}${rand(10, 999)}@${pick(EMAIL_DOMAINS_PERSONAL)}`,
        () => `${fn}.${ln[0]}@${ctx.domainName}`,
        () => `${ln}.${fn}@${pick(EMAIL_DOMAINS_BUSINESS)}`,
      ];
      return pick(patterns)();
    }
    case "phone": {
      const formats = [
        () => `+1 (${rand(201, 989)}) ${rand(200, 999)}-${rand(1000, 9999)}`,
        () => `+1-${rand(201, 989)}-${rand(200, 999)}-${rand(1000, 9999)}`,
        () => `(${rand(201, 989)}) ${rand(200, 999)}-${rand(1000, 9999)}`,
        () => `${rand(201, 989)}.${rand(200, 999)}.${rand(1000, 9999)}`,
        () => `+44 ${rand(20, 79)} ${rand(1000, 9999)} ${rand(1000, 9999)}`,
        () => `+91 ${rand(70, 99)}${rand(100, 999)} ${rand(10000, 99999)}`,
        () => `+49 ${rand(151, 179)} ${rand(1000000, 9999999)}`,
      ];
      return pick(formats)();
    }
    case "username": {
      const fn = ctx.firstName.toLowerCase();
      const ln = ctx.lastName.toLowerCase();
      const patterns = [
        () => `${fn}${ln}`,
        () => `${fn}_${ln}`,
        () => `${fn}.${ln}${rand(1, 99)}`,
        () => `${fn}${rand(100, 9999)}`,
        () => `${fn[0]}${ln}${rand(1, 999)}`,
        () => `${ln}_${fn[0]}${rand(10, 99)}`,
        () => `the_${fn}`,
        () => `${fn}${ln[0]}${rand(1, 999)}`,
      ];
      return pick(patterns)();
    }
    case "password":
      return generatePassword();
    case "gender":
      return ctx.gender === "male" ? "Male" : "Female";
    case "age":
      return rand(18, 80).toString();
    case "nationality":
      return pick(COUNTRIES);
    case "ssn":
      return generateSSN();

    case "street_address": {
      const base = `${ctx.streetNum} ${ctx.streetName} ${ctx.streetType}`;
      return base + ctx.streetExtra;
    }
    case "city":
      return CITIES_WITH_STATE_ZIP[ctx.cityIdx][0];
    case "state":
      return CITIES_WITH_STATE_ZIP[ctx.cityIdx][1];
    case "zip_code":
      return CITIES_WITH_STATE_ZIP[ctx.cityIdx][2];
    case "country":
      return pick(COUNTRIES);
    case "full_address": {
      const [city, state, zip] = CITIES_WITH_STATE_ZIP[ctx.cityIdx];
      return `${ctx.streetNum} ${ctx.streetName} ${ctx.streetType}${ctx.streetExtra}, ${city}, ${state} ${zip}`;
    }
    case "latitude":
      return (_rng() * 180 - 90).toFixed(6);
    case "longitude":
      return (_rng() * 360 - 180).toFixed(6);
    case "timezone": {
      const tzs = [
        "America/New_York","America/Chicago","America/Denver","America/Los_Angeles",
        "Europe/London","Europe/Paris","Europe/Berlin","Asia/Tokyo","Asia/Shanghai",
        "Asia/Kolkata","Australia/Sydney","Pacific/Auckland","America/Sao_Paulo",
      ];
      return pick(tzs);
    }

    case "credit_card":
      return creditCard();
    case "cvv":
      return rand(100, 999).toString();
    case "expiration_date":
      return `${pad(rand(1, 12))}/${rand(25, 32)}`;
    case "bank_account":
      return Array.from({ length: rand(8, 12) }, () => rand(0, 9)).join("");
    case "iban":
      return generateIBAN();
    case "currency_amount":
      return generateCurrency();
    case "currency_code": {
      const codes = ["USD","EUR","GBP","JPY","CAD","AUD","CHF","CNY","INR","BRL","MXN","SGD","HKD","SEK","NOK"];
      return pick(codes);
    }

    case "uuid":
      return uuid();
    case "ip_address":
      return _rng() < 0.9 ? ipv4() : ipv6();
    case "url": {
      const protocol = _rng() < 0.9 ? "https" : "http";
      const domain = `${pick(COMPANY_PREFIXES).toLowerCase()}.${pick(TLD_LIST)}`;
      const path = pick(URL_PATHS);
      const patterns = [
        () => `${protocol}://${domain}/${path}`,
        () => `${protocol}://${domain}/${path}/${rand(1, 99999)}`,
        () => `${protocol}://www.${domain}/${path}`,
        () => `${protocol}://${domain}/${path}?id=${rand(1000, 99999)}`,
        () => `${protocol}://api.${domain}/v${rand(1, 3)}/${path}`,
      ];
      return pick(patterns)();
    }
    case "user_agent":
      return pick(USER_AGENTS);
    case "mac_address":
      return macAddress();
    case "domain": {
      const name = pick(COMPANY_PREFIXES).toLowerCase();
      return `${name}.${pick(TLD_LIST)}`;
    }
    case "color_hex":
      return `#${rand(0, 0xffffff).toString(16).padStart(6, "0")}`;
    case "mime_type": {
      const types = [
        "application/json","application/xml","text/html","text/plain","text/csv",
        "image/png","image/jpeg","image/svg+xml","application/pdf","application/octet-stream",
        "multipart/form-data","application/x-www-form-urlencoded","video/mp4","audio/mpeg",
      ];
      return pick(types);
    }
    case "http_method":
      return pick(["GET","GET","GET","POST","POST","PUT","PATCH","DELETE","HEAD","OPTIONS"]);
    case "http_status": {
      const codes = [200,200,200,200,201,204,301,302,304,400,401,403,404,404,500,502,503];
      return pick(codes).toString();
    }

    case "company_name":
      return ctx.companyName;
    case "job_title":
      return pick(JOB_TITLES);
    case "department":
      return pick(DEPARTMENTS);
    case "salary": {
      const base = rand(35, 250) * 1000;
      return base.toLocaleString("en-US");
    }
    case "employee_id":
      return `EMP-${pad(rand(1000, 99999), 5)}`;

    case "date_of_birth":
      return randomDate(1950, 2005);
    case "past_date":
      return randomDate(2020, 2025);
    case "future_date":
      return randomDate(2026, 2030);
    case "timestamp": {
      const d = randomDate(2023, 2026);
      const tz = pick(["Z", "+00:00", "-05:00", "+01:00", "+05:30", "+09:00", "-08:00"]);
      return `${d}T${pad(rand(0, 23))}:${pad(rand(0, 59))}:${pad(rand(0, 59))}${tz}`;
    }
    case "time":
      return `${pad(rand(0, 23))}:${pad(rand(0, 59))}:${pad(rand(0, 59))}`;
    case "unix_timestamp":
      return (Math.floor(Date.now() / 1000) - rand(0, 31536000)).toString();
    case "duration_ms":
      return rand(minVal ?? 1, maxVal ?? 30000).toString();

    case "integer_range":
      return rand(minVal ?? 0, maxVal ?? 1000).toString();
    case "decimal_range":
      return (_rng() * ((maxVal ?? 100) - (minVal ?? 0)) + (minVal ?? 0)).toFixed(2);
    case "percentage":
      return (_rng() * 100).toFixed(1);
    case "boolean":
      return _rng() < 0.5 ? "true" : "false";

    case "sentence":
      return _rng() < 0.5 ? pick(SENTENCES) : generateLoremSentence();
    case "paragraph":
      return _rng() < 0.4 ? pick(PARAGRAPHS) : generateLoremParagraph();
    case "json_object": {
      const obj: Record<string, unknown> = {
        id: rand(1, 99999),
        name: `${ctx.firstName} ${ctx.lastName}`,
        active: _rng() < 0.7,
        score: parseFloat((_rng() * 100).toFixed(1)),
        tags: shuffle(["alpha", "beta", "gamma", "delta", "epsilon", "zeta"]).slice(0, rand(1, 3)),
      };
      return JSON.stringify(obj);
    }

    case "enum": {
      const vals = (enumValues || "A,B,C").split(",").map(v => v.trim()).filter(Boolean);
      return vals.length > 0 ? pick(vals) : "A";
    }
    case "weighted_enum": {
      const vals = (enumValues || "Active:70,Inactive:20,Suspended:10").split(",").map(v => v.trim()).filter(Boolean);
      const parsed = vals
        .map(v => {
          const colonIdx = v.lastIndexOf(":");
          if (colonIdx === -1) return { label: v.trim(), weight: 1 };
          const label = v.substring(0, colonIdx).trim();
          const weight = parseFloat(v.substring(colonIdx + 1));
          return { label: label || v.trim(), weight: isNaN(weight) || weight <= 0 ? 1 : weight };
        })
        .filter(p => p.label);
      if (parsed.length === 0) return "A";
      const totalWeight = parsed.reduce((s, p) => s + p.weight, 0);
      let r = _rng() * totalWeight;
      for (const p of parsed) {
        r -= p.weight;
        if (r <= 0) return p.label;
      }
      return parsed[parsed.length - 1].label;
    }
    case "pattern": {
      const p = patternStr || "USR-####";
      let result = "";
      for (const c of p) {
        if (c === "#") result += rand(0, 9);
        else if (c === "?") result += String.fromCharCode(rand(65, 90));
        else if (c === "*") result += String.fromCharCode(rand(0, 1) ? rand(65, 90) : rand(48, 57));
        else result += c;
      }
      return result;
    }
    case "sequential_id":
      return (rowIndex + 1).toString();
    case "row_hash": {
      let h = 0x811c9dc5;
      const s = `${rowIndex}-${ctx.firstName}-${ctx.lastName}-${ctx.cityIdx}-${ctx.streetNum}`;
      for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 0x01000193);
      }
      return ((h >>> 0).toString(16)).padStart(8, "0");
    }

    case "custom_formula":
    case "template_expr":
    case "custom_expression":
      return evaluateTemplate(patternStr || "{uuid}", rowIndex, ctx);

    case "custom_list": {
      const vals = (enumValues || "").split("\n").map(v => v.trim()).filter(Boolean);
      if (vals.length === 0) return "";
      if (minVal === 1) {
        return pick(vals);
      }
      return vals[rowIndex % vals.length];
    }

    case "custom_range_date": {
      const startYear = minVal ?? 2020;
      const endYear = maxVal ?? 2026;
      return randomDate(startYear, endYear);
    }

    case "constant":
      return enumValues || "VALUE";

    case "lorem_words": {
      const wordCount = minVal ?? 5;
      const words: string[] = [];
      for (let i = 0; i < wordCount; i++) words.push(pick(LOREM_WORDS));
      return words.join(" ");
    }

    case "regex_like": {
      return generateFromPattern(patternStr || "[A-Z]{3}-[0-9]{4}", rowIndex);
    }

    case "composite_id": {
      const prefix = enumValues || "ID";
      const len = minVal ?? 6;
      let num = "";
      for (let i = 0; i < len; i++) num += rand(0, 9);
      return `${prefix}-${num}`;
    }

    default:
      return "";
  }
}

const TEMPLATE_TOKEN_REGISTRY: Record<string, (rowIndex: number, ctx: RowContext) => string> = {
  firstName: (_i, ctx) => ctx.firstName,
  first_name: (_i, ctx) => ctx.firstName,
  lastName: (_i, ctx) => ctx.lastName,
  last_name: (_i, ctx) => ctx.lastName,
  fullName: (_i, ctx) => `${ctx.firstName} ${ctx.lastName}`,
  full_name: (_i, ctx) => `${ctx.firstName} ${ctx.lastName}`,
  company: (_i, ctx) => ctx.companyName,
  companyName: (_i, ctx) => ctx.companyName,
  domain: (_i, ctx) => ctx.domainName,
  domainName: (_i, ctx) => ctx.domainName,
  city: (_i, ctx) => CITIES_WITH_STATE_ZIP[ctx.cityIdx][0],
  state: (_i, ctx) => CITIES_WITH_STATE_ZIP[ctx.cityIdx][1],
  zip: (_i, ctx) => CITIES_WITH_STATE_ZIP[ctx.cityIdx][2],
  country: () => pick(COUNTRIES),
  uuid: () => uuid(),
  email: (_i, ctx) => {
    const fn = ctx.firstName.toLowerCase().replace(/[^a-z]/g, "");
    const ln = ctx.lastName.toLowerCase().replace(/[^a-z]/g, "");
    return `${fn}.${ln}@${pick(EMAIL_DOMAINS_PERSONAL)}`;
  },
  username: (_i, ctx) => `${ctx.firstName.toLowerCase()}_${ctx.lastName.toLowerCase()}${rand(1, 99)}`,
  phone: () => `${rand(201, 989)}-${rand(200, 999)}-${rand(1000, 9999)}`,
  date: () => randomDate(2020, 2026),
  pastDate: () => randomDate(2020, 2025),
  futureDate: () => randomDate(2026, 2030),
  timestamp: () => {
    const d = randomDate(2023, 2026);
    return `${d}T${pad(rand(0, 23))}:${pad(rand(0, 59))}:${pad(rand(0, 59))}Z`;
  },
  time: () => `${pad(rand(0, 23))}:${pad(rand(0, 59))}:${pad(rand(0, 59))}`,
  ip: () => ipv4(),
  ipv6: () => ipv6(),
  mac: () => macAddress(),
  hex: () => rand(0, 0xffffff).toString(16).padStart(6, "0"),
  bool: () => _rng() < 0.5 ? "true" : "false",
  gender: (_i, ctx) => ctx.gender === "male" ? "Male" : "Female",
  index: (i) => (i + 1).toString(),
  rowIndex: (i) => (i + 1).toString(),
  row: (i) => (i + 1).toString(),
  year: () => rand(2020, 2026).toString(),
  month: () => pad(rand(1, 12)),
  day: () => pad(rand(1, 28)),
  jobTitle: () => pick(JOB_TITLES),
  job_title: () => pick(JOB_TITLES),
  department: () => pick(DEPARTMENTS),
  salary: () => (rand(35, 250) * 1000).toLocaleString("en-US"),
  streetAddress: (_i, ctx) => `${ctx.streetNum} ${ctx.streetName} ${ctx.streetType}${ctx.streetExtra}`,
  street_address: (_i, ctx) => `${ctx.streetNum} ${ctx.streetName} ${ctx.streetType}${ctx.streetExtra}`,
  fullAddress: (_i, ctx) => {
    const [city, state, zp] = CITIES_WITH_STATE_ZIP[ctx.cityIdx];
    return `${ctx.streetNum} ${ctx.streetName} ${ctx.streetType}${ctx.streetExtra}, ${city}, ${state} ${zp}`;
  },
  creditCard: () => creditCard(),
  cvv: () => rand(100, 999).toString(),
  url: () => `https://${pick(COMPANY_PREFIXES).toLowerCase()}.${pick(TLD_LIST)}/${pick(URL_PATHS)}`,
  ssn: () => generateSSN(),
  iban: () => generateIBAN(),
  password: () => generatePassword(),
  age: () => rand(18, 80).toString(),
  percentage: () => (_rng() * 100).toFixed(1),
  currency: () => pick(["USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CHF", "CNY", "INR"]),
  amount: () => generateCurrency(),
  httpMethod: () => pick(["GET", "GET", "GET", "POST", "POST", "PUT", "PATCH", "DELETE"]),
  httpStatus: () => pick([200, 200, 200, 201, 204, 301, 400, 401, 403, 404, 500]).toString(),
  userAgent: () => pick(USER_AGENTS),
  word: () => pick(LOREM_WORDS),
  sentence: () => pick(SENTENCES),
  paragraph: () => pick(PARAGRAPHS),
  null: () => "",
  empty: () => "",
  space: () => " ",
  newline: () => "\n",
  tab: () => "\t",
};

export const FORMULA_TOKEN_GROUPS = [
  {
    label: "Identity",
    tokens: [
      { token: "firstName", example: "John", desc: "Row-consistent first name" },
      { token: "lastName", example: "Smith", desc: "Row-consistent last name" },
      { token: "fullName", example: "John Smith", desc: "First + last name" },
      { token: "email", example: "john.smith@gmail.com", desc: "Correlated email" },
      { token: "username", example: "john_smith42", desc: "Correlated username" },
      { token: "gender", example: "Male", desc: "Row-consistent gender" },
      { token: "age", example: "34", desc: "Random 18-80" },
      { token: "phone", example: "555-123-4567", desc: "Random phone" },
      { token: "password", example: "xK#9mP2q", desc: "Strong password" },
      { token: "ssn", example: "123-45-6789", desc: "SSN format" },
    ],
  },
  {
    label: "Location",
    tokens: [
      { token: "city", example: "New York", desc: "Row-consistent city" },
      { token: "state", example: "New York", desc: "Matches city" },
      { token: "zip", example: "10001", desc: "Matches city" },
      { token: "country", example: "USA", desc: "Random country" },
      { token: "streetAddress", example: "123 Main St", desc: "Row-consistent" },
      { token: "fullAddress", example: "123 Main St, NY, NY 10001", desc: "Full address" },
    ],
  },
  {
    label: "Business",
    tokens: [
      { token: "company", example: "Apex Tech", desc: "Row-consistent company" },
      { token: "domain", example: "apex.io", desc: "Row-consistent domain" },
      { token: "jobTitle", example: "Software Engineer", desc: "Random job" },
      { token: "department", example: "Engineering", desc: "Random dept" },
      { token: "salary", example: "85,000", desc: "Random salary" },
    ],
  },
  {
    label: "Technical",
    tokens: [
      { token: "uuid", example: "a1b2c3d4-...", desc: "Random UUID" },
      { token: "ip", example: "192.168.1.1", desc: "IPv4 address" },
      { token: "mac", example: "AA:BB:CC:DD:EE:FF", desc: "MAC address" },
      { token: "url", example: "https://apex.io/api", desc: "Random URL" },
      { token: "userAgent", example: "Mozilla/5.0...", desc: "Browser UA" },
      { token: "httpMethod", example: "GET", desc: "HTTP method" },
      { token: "httpStatus", example: "200", desc: "Status code" },
    ],
  },
  {
    label: "Date & Time",
    tokens: [
      { token: "date", example: "2024-03-15", desc: "Random date" },
      { token: "pastDate", example: "2023-06-20", desc: "Past date" },
      { token: "futureDate", example: "2027-01-10", desc: "Future date" },
      { token: "timestamp", example: "2024-03-15T14:30:00Z", desc: "ISO timestamp" },
      { token: "time", example: "14:30:00", desc: "HH:MM:SS" },
      { token: "year", example: "2024", desc: "Random year" },
      { token: "month", example: "03", desc: "01-12 padded" },
      { token: "day", example: "15", desc: "01-28 padded" },
    ],
  },
  {
    label: "Finance",
    tokens: [
      { token: "creditCard", example: "4532XXXXXXXX1234", desc: "Valid Luhn" },
      { token: "cvv", example: "123", desc: "3-digit CVV" },
      { token: "iban", example: "DE89...", desc: "IBAN number" },
      { token: "amount", example: "1,234.56", desc: "Currency amount" },
      { token: "currency", example: "USD", desc: "Currency code" },
    ],
  },
  {
    label: "Generators",
    tokens: [
      { token: "#N", example: "{#4} → 7382", desc: "N random digits" },
      { token: "?N", example: "{?3} → QMB", desc: "N random letters" },
      { token: "*N", example: "{*5} → A3K9B", desc: "N alphanumeric" },
      { token: "int:min-max", example: "{int:1-100} → 42", desc: "Random integer" },
      { token: "dec:min-max", example: "{dec:0-99} → 47.32", desc: "Random decimal" },
      { token: "pick:a|b|c", example: "{pick:USD|EUR} → EUR", desc: "Random choice" },
      { token: "pad:len,max", example: "{pad:5,999} → 00042", desc: "Zero-padded number" },
      { token: "seq:start,step", example: "{seq:100,10} → 100,110,...", desc: "Sequence" },
    ],
  },
  {
    label: "Modifiers",
    tokens: [
      { token: "upper:token", example: "{upper:city} → NEW YORK", desc: "UPPERCASE" },
      { token: "lower:token", example: "{lower:city} → new york", desc: "lowercase" },
      { token: "substr:token,start,len", example: "{substr:firstName,0,1} → J", desc: "Substring" },
    ],
  },
  {
    label: "Utility",
    tokens: [
      { token: "index", example: "1, 2, 3...", desc: "Row number" },
      { token: "bool", example: "true/false", desc: "Random boolean" },
      { token: "hex", example: "a3f29c", desc: "6-char hex" },
      { token: "percentage", example: "73.2", desc: "0-100 decimal" },
      { token: "word", example: "lorem", desc: "Random word" },
    ],
  },
];

export const FORMULA_PRESETS = [
  { label: "Custom Email", formula: "{lower:firstName}.{lower:lastName}@{pick:company.com|corp.net|org.io}", desc: "Correlated corporate email" },
  { label: "Transaction ID", formula: "TXN-{#8}-{pick:USD|EUR|GBP}", desc: "Prefixed ID with currency" },
  { label: "API Endpoint", formula: "/api/v{pick:1|2|3}/{pick:users|orders|products}/{#5}", desc: "RESTful URL path" },
  { label: "Log Entry", formula: "[{timestamp}] [{pick:INFO|WARN|ERROR|DEBUG}] {pick:AuthService|OrderService|PaymentGateway}: {sentence}", desc: "Structured log line" },
  { label: "Server Tag", formula: "{pick:us-east|us-west|eu-west|ap-south}-{pick:web|api|worker}-{#3}", desc: "Cloud server identifier" },
  { label: "Full Record", formula: "{index}|{fullName}|{email}|{city}|{pick:Active|Inactive}", desc: "Pipe-delimited record" },
  { label: "File Path", formula: "/data/{pick:2023|2024|2025}/{month}/{day}/report_{#6}.{pick:csv|json|xml}", desc: "Date-partitioned file" },
  { label: "Custom Username", formula: "{lower:firstName}{substr:lastName,0,1}{int:10-99}", desc: "First name + last initial + number" },
  { label: "Formatted Name", formula: "{upper:lastName}, {firstName} ({department})", desc: "Last, First (Dept)" },
  { label: "DB Connection", formula: "jdbc:{pick:mysql|postgresql|oracle}://{ip}:{pick:3306|5432|1521}/{pick:prod|staging|dev}_db", desc: "JDBC connection string" },
];

export function tryEvaluateFormula(formula: string): { value: string; error: string | null } {
  try {
    const ctx = createRowContext();
    const value = evaluateTemplate(formula, 0, ctx);
    const hasUnresolved = value.match(/\{[^}]+\}/);
    if (hasUnresolved) {
      return { value, error: `Unknown token: ${hasUnresolved[0]}` };
    }
    return { value, error: null };
  } catch (e) {
    return { value: "", error: e instanceof Error ? e.message : "Invalid formula" };
  }
}

function evaluateTemplate(template: string, rowIndex: number, ctx: RowContext): string {
  return template.replace(/\{([^}]+)\}/g, (_match, token: string) => {
    const t = token.trim();

    const directFn = TEMPLATE_TOKEN_REGISTRY[t];
    if (directFn) return directFn(rowIndex, ctx);

    const digitMatch = t.match(/^#(\d+)$/);
    if (digitMatch) {
      const len = Math.min(parseInt(digitMatch[1]), 20);
      let s = "";
      for (let i = 0; i < len; i++) s += rand(0, 9);
      return s;
    }

    const letterMatch = t.match(/^\?(\d+)$/);
    if (letterMatch) {
      const len = Math.min(parseInt(letterMatch[1]), 20);
      let s = "";
      for (let i = 0; i < len; i++) s += String.fromCharCode(rand(65, 90));
      return s;
    }

    const alphaMatch = t.match(/^\*(\d+)$/);
    if (alphaMatch) {
      const len = Math.min(parseInt(alphaMatch[1]), 20);
      let s = "";
      for (let i = 0; i < len; i++) s += String.fromCharCode(rand(0, 1) ? rand(65, 90) : rand(48, 57));
      return s;
    }

    const pickMatch = t.match(/^pick:(.+)$/);
    if (pickMatch) {
      const options = pickMatch[1].split("|").map(o => o.trim()).filter(Boolean);
      return options.length > 0 ? pick(options) : "";
    }

    const intMatch = t.match(/^int:(-?\d+)-(-?\d+)$/);
    if (intMatch) {
      return rand(parseInt(intMatch[1]), parseInt(intMatch[2])).toString();
    }

    const decMatch = t.match(/^dec:(-?\d+)-(-?\d+)$/);
    if (decMatch) {
      const lo = parseInt(decMatch[1]);
      const hi = parseInt(decMatch[2]);
      return (_rng() * (hi - lo) + lo).toFixed(2);
    }

    const padMatch = t.match(/^pad:(\d+),(\d+)$/);
    if (padMatch) {
      return rand(0, parseInt(padMatch[2])).toString().padStart(parseInt(padMatch[1]), "0");
    }

    const seqMatch = t.match(/^seq:(\d+),(\d+)$/);
    if (seqMatch) {
      const start = parseInt(seqMatch[1]);
      const step = parseInt(seqMatch[2]);
      return (start + rowIndex * step).toString();
    }

    const upperMatch = t.match(/^upper:(.+)$/);
    if (upperMatch) return evaluateTemplate(`{${upperMatch[1]}}`, rowIndex, ctx).toUpperCase();

    const lowerMatch = t.match(/^lower:(.+)$/);
    if (lowerMatch) return evaluateTemplate(`{${lowerMatch[1]}}`, rowIndex, ctx).toLowerCase();

    const substrMatch = t.match(/^substr:([^,]+),(\d+),(\d+)$/);
    if (substrMatch) {
      const inner = evaluateTemplate(`{${substrMatch[1]}}`, rowIndex, ctx);
      return inner.substring(parseInt(substrMatch[2]), parseInt(substrMatch[2]) + parseInt(substrMatch[3]));
    }

    const repeatMatch = t.match(/^repeat:([^,]+),(\d+)$/);
    if (repeatMatch) {
      const val = evaluateTemplate(`{${repeatMatch[1]}}`, rowIndex, ctx);
      return val.repeat(Math.min(parseInt(repeatMatch[2]), 20));
    }

    return `{${t}}`;
  });
}

function generateFromPattern(pattern: string, _rowIndex: number): string {
  let result = "";
  let i = 0;
  while (i < pattern.length) {
    if (pattern[i] === "[") {
      const closeIdx = pattern.indexOf("]", i);
      if (closeIdx === -1) { result += pattern[i]; i++; continue; }
      const charClass = pattern.substring(i + 1, closeIdx);
      let repeatCount = 1;
      if (closeIdx + 1 < pattern.length && pattern[closeIdx + 1] === "{") {
        const repeatClose = pattern.indexOf("}", closeIdx + 1);
        if (repeatClose !== -1) {
          const repeatParts = pattern.substring(closeIdx + 2, repeatClose).split(",");
          if (repeatParts.length === 1) repeatCount = parseInt(repeatParts[0]) || 1;
          else repeatCount = rand(parseInt(repeatParts[0]) || 1, parseInt(repeatParts[1]) || 1);
          i = repeatClose + 1;
        } else { i = closeIdx + 1; }
      } else { i = closeIdx + 1; }

      const chars = expandCharClass(charClass);
      for (let r = 0; r < repeatCount; r++) {
        result += chars[rand(0, chars.length - 1)];
      }
    } else if (pattern[i] === "\\") {
      i++;
      if (i < pattern.length) { result += pattern[i]; i++; }
    } else {
      let repeatCount = 1;
      const ch = pattern[i];
      if (i + 1 < pattern.length && pattern[i + 1] === "{") {
        const repeatClose = pattern.indexOf("}", i + 1);
        if (repeatClose !== -1) {
          const repeatParts = pattern.substring(i + 2, repeatClose).split(",");
          if (repeatParts.length === 1) repeatCount = parseInt(repeatParts[0]) || 1;
          else repeatCount = rand(parseInt(repeatParts[0]) || 1, parseInt(repeatParts[1]) || 1);
          i = repeatClose + 1;
        } else { i++; }
      } else { i++; }
      for (let r = 0; r < repeatCount; r++) result += ch;
    }
  }
  return result;
}

function expandCharClass(cls: string): string[] {
  const chars: string[] = [];
  let i = 0;
  while (i < cls.length) {
    if (i + 2 < cls.length && cls[i + 1] === "-") {
      const start = cls.charCodeAt(i);
      const end = cls.charCodeAt(i + 2);
      for (let c = start; c <= end; c++) chars.push(String.fromCharCode(c));
      i += 3;
    } else {
      chars.push(cls[i]);
      i++;
    }
  }
  return chars;
}

export const TYPE_GROUPS = [
  {
    label: "Personal",
    types: [
      { value: "first_name", label: "First Name" },
      { value: "last_name", label: "Last Name" },
      { value: "full_name", label: "Full Name" },
      { value: "email", label: "Email" },
      { value: "phone", label: "Phone" },
      { value: "username", label: "Username" },
      { value: "password", label: "Password" },
      { value: "gender", label: "Gender" },
      { value: "age", label: "Age" },
      { value: "nationality", label: "Nationality" },
      { value: "ssn", label: "SSN" },
    ],
  },
  {
    label: "Location",
    types: [
      { value: "street_address", label: "Street Address" },
      { value: "city", label: "City" },
      { value: "state", label: "State" },
      { value: "zip_code", label: "Zip Code" },
      { value: "country", label: "Country" },
      { value: "full_address", label: "Full Address" },
      { value: "latitude", label: "Latitude" },
      { value: "longitude", label: "Longitude" },
      { value: "timezone", label: "Timezone" },
    ],
  },
  {
    label: "Finance",
    types: [
      { value: "credit_card", label: "Credit Card Number" },
      { value: "cvv", label: "CVV" },
      { value: "expiration_date", label: "Expiration Date" },
      { value: "bank_account", label: "Bank Account" },
      { value: "iban", label: "IBAN" },
      { value: "currency_amount", label: "Currency Amount" },
      { value: "currency_code", label: "Currency Code" },
    ],
  },
  {
    label: "Technical",
    types: [
      { value: "uuid", label: "UUID" },
      { value: "ip_address", label: "IP Address" },
      { value: "url", label: "URL" },
      { value: "domain", label: "Domain Name" },
      { value: "user_agent", label: "User Agent" },
      { value: "mac_address", label: "MAC Address" },
      { value: "color_hex", label: "Hex Color" },
      { value: "mime_type", label: "MIME Type" },
      { value: "http_method", label: "HTTP Method" },
      { value: "http_status", label: "HTTP Status Code" },
    ],
  },
  {
    label: "Business",
    types: [
      { value: "company_name", label: "Company Name" },
      { value: "job_title", label: "Job Title" },
      { value: "department", label: "Department" },
      { value: "salary", label: "Salary" },
      { value: "employee_id", label: "Employee ID" },
    ],
  },
  {
    label: "Dates & Time",
    types: [
      { value: "date_of_birth", label: "Date of Birth" },
      { value: "past_date", label: "Past Date" },
      { value: "future_date", label: "Future Date" },
      { value: "timestamp", label: "ISO Timestamp" },
      { value: "time", label: "Time (HH:MM:SS)" },
      { value: "unix_timestamp", label: "Unix Timestamp" },
      { value: "duration_ms", label: "Duration (ms)" },
    ],
  },
  {
    label: "Numbers",
    types: [
      { value: "integer_range", label: "Integer Range" },
      { value: "decimal_range", label: "Decimal Range" },
      { value: "percentage", label: "Percentage" },
      { value: "boolean", label: "Boolean" },
    ],
  },
  {
    label: "Text",
    types: [
      { value: "sentence", label: "Sentence" },
      { value: "paragraph", label: "Paragraph" },
      { value: "json_object", label: "JSON Object" },
    ],
  },
  {
    label: "Custom",
    types: [
      { value: "custom_formula", label: "Formula Builder" },
      { value: "regex_like", label: "Regex Pattern" },
      { value: "enum", label: "Enum (custom values)" },
      { value: "weighted_enum", label: "Weighted Enum" },
      { value: "pattern", label: "Simple Pattern (# ? *)" },
      { value: "custom_list", label: "Value List" },
      { value: "composite_id", label: "Composite ID" },
      { value: "constant", label: "Constant" },
      { value: "sequential_id", label: "Sequential ID" },
      { value: "row_hash", label: "Row Hash" },
      { value: "custom_range_date", label: "Date Range" },
      { value: "lorem_words", label: "Lorem Words" },
    ],
  },
];

export const ALL_TYPES = TYPE_GROUPS.flatMap(g => g.types);

export function getTypeLabel(value: string): string {
  return ALL_TYPES.find(t => t.value === value)?.label || value;
}
