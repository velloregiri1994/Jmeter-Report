import { useState, useMemo, useCallback, useRef } from "react";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Plus,
  Trash2,
  Download,
  Copy,
  Eye,
  Database,
  RotateCcw,
  Columns,
  Search,
  Info,
  Zap,
  CopyPlus,
  Save,
  FolderOpen,
  ChevronUp,
  ChevronDown,
  FileJson,
  FileSpreadsheet,
  FileCode,
  Sparkles,
  Hash,
  User,
  ShoppingCart,
  Globe,
  Briefcase,
  CreditCard,
  Cpu,
  X,
  ClipboardCopy,
  Shuffle,
  Wand2,
  Check,
  AlertCircle,
  ChevronRight,
  Lightbulb,
} from "lucide-react";
import {
  TYPE_GROUPS,
  ALL_TYPES,
  getTypeLabel,
  generateValue,
  createRowContext,
  createSeededRng,
  setRng,
  resetRng,
  rng,
  tryEvaluateFormula,
  FORMULA_TOKEN_GROUPS,
  FORMULA_PRESETS,
} from "./data-engine";
import { TEMPLATES, type DataTemplate, type FieldTemplate } from "./templates";

interface FieldConfig {
  id: string;
  name: string;
  type: string;
  enumValues?: string;
  pattern?: string;
  min?: number;
  max?: number;
  nullPercent: number;
}

type ExportFormat = "csv" | "json" | "sql" | "tsv";

interface SavedConfig {
  name: string;
  fields: Omit<FieldConfig, "id">[];
  rowCount: number;
  savedAt: number;
}

function getGroupColor(type: string): string {
  const group = TYPE_GROUPS.find(g => g.types.some(t => t.value === type));
  const colors: Record<string, string> = {
    Personal: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    Location: "bg-green-500/10 text-green-500 border-green-500/20",
    Finance: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
    Technical: "bg-purple-500/10 text-purple-500 border-purple-500/20",
    Business: "bg-orange-500/10 text-orange-500 border-orange-500/20",
    "Dates & Time": "bg-cyan-500/10 text-cyan-500 border-cyan-500/20",
    Numbers: "bg-red-500/10 text-red-500 border-red-500/20",
    Text: "bg-teal-500/10 text-teal-500 border-teal-500/20",
    Custom: "bg-pink-500/10 text-pink-500 border-pink-500/20",
  };
  return colors[group?.label || ""] || "bg-muted text-muted-foreground";
}

function getGroupName(type: string): string {
  const group = TYPE_GROUPS.find(g => g.types.some(t => t.value === type));
  return group?.label || "";
}

let fieldIdCounter = 0;
function newFieldId(): string {
  return `field_${++fieldIdCounter}_${Date.now()}`;
}

const ROW_PRESETS = [10, 100, 1000, 10000, 100000];

const TEMPLATE_ICONS: Record<string, React.ReactNode> = {
  "user": <User className="h-4 w-4" />,
  "shopping-cart": <ShoppingCart className="h-4 w-4" />,
  "globe": <Globe className="h-4 w-4" />,
  "briefcase": <Briefcase className="h-4 w-4" />,
  "credit-card": <CreditCard className="h-4 w-4" />,
  "cpu": <Cpu className="h-4 w-4" />,
};

function normalizeFieldType(type: string): string {
  if (type === "template_expr" || type === "custom_expression") return "custom_formula";
  return type;
}

function templateFieldToConfig(f: FieldTemplate): FieldConfig {
  return { id: newFieldId(), name: f.name, type: normalizeFieldType(f.type), enumValues: f.enumValues, pattern: f.pattern, min: f.min, max: f.max, nullPercent: 0 };
}

const STORAGE_KEY = "perfhub_tdg_configs";

function loadSavedConfigs(): SavedConfig[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveSavedConfigs(configs: SavedConfig[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(configs));
}

function withRng<T>(seedVal: number | undefined, fn: () => T): T {
  if (seedVal !== undefined) {
    setRng(createSeededRng(seedVal));
  }
  try {
    return fn();
  } finally {
    resetRng();
  }
}

function formatRow(fields: FieldConfig[], row: Record<string, string>, format: ExportFormat): string {
  switch (format) {
    case "csv":
      return fields.map(f => {
        const val = row[f.name];
        if (val.includes(",") || val.includes('"') || val.includes("\n")) return `"${val.replace(/"/g, '""')}"`;
        return val;
      }).join(",");
    case "tsv":
      return fields.map(f => row[f.name].replace(/\t/g, " ")).join("\t");
    case "json":
      return "";
    case "sql": {
      const cols = fields.map(f => f.name).join(", ");
      const vals = fields.map(f => {
        const v = row[f.name];
        if (!v) return "NULL";
        if (/^\d+(\.\d+)?$/.test(v) && v.length < 15) return v;
        return `'${v.replace(/'/g, "''")}'`;
      }).join(", ");
      return `INSERT INTO test_data (${cols}) VALUES (${vals});`;
    }
  }
}

async function generateExportDataAsync(
  fields: FieldConfig[],
  rowCount: number,
  format: ExportFormat,
  seedVal?: number,
  onProgress?: (pct: number) => void,
  abortRef?: React.RefObject<boolean>,
): Promise<string> {
  const validFields = fields.filter(f => f.name.trim());
  if (validFields.length === 0) return "";

  if (seedVal !== undefined) {
    setRng(createSeededRng(seedVal));
  }

  try {
    const CHUNK = 500;
    const jsonRows: Record<string, string>[] = format === "json" ? [] : [];
    const lines: string[] = [];

    if (format === "csv") lines.push(validFields.map(f => f.name).join(","));
    else if (format === "tsv") lines.push(validFields.map(f => f.name).join("\t"));

    for (let i = 0; i < rowCount; i++) {
      if (abortRef?.current) return "";

      const ctx = createRowContext();
      const row: Record<string, string> = {};
      for (const f of validFields) {
        if (f.nullPercent > 0 && rng() < f.nullPercent / 100) {
          row[f.name] = "";
        } else {
          row[f.name] = generateValue(f.type, i, ctx, f.enumValues, f.pattern, f.min, f.max);
        }
      }

      if (format === "json") {
        jsonRows.push(row);
      } else {
        lines.push(formatRow(validFields, row, format));
      }

      if (i > 0 && i % CHUNK === 0) {
        if (onProgress) onProgress(Math.round((i / rowCount) * 100));
        await new Promise(r => setTimeout(r, 0));
      }
    }

    if (onProgress) onProgress(100);

    if (format === "json") return JSON.stringify(jsonRows, null, 2);
    return lines.join("\n");
  } finally {
    resetRng();
  }
}

export default function TestDataGeneratorPage() {
  const { toast } = useToast();
  const [fields, setFields] = useState<FieldConfig[]>([
    { id: newFieldId(), name: "id", type: "sequential_id", nullPercent: 0 },
    { id: newFieldId(), name: "first_name", type: "first_name", nullPercent: 0 },
    { id: newFieldId(), name: "last_name", type: "last_name", nullPercent: 0 },
    { id: newFieldId(), name: "email", type: "email", nullPercent: 0 },
  ]);
  const [rowCount, setRowCount] = useState(100);
  const [previewKey, setPreviewKey] = useState(0);
  const [exportFormat, setExportFormat] = useState<ExportFormat>("csv");
  const [typeSearch, setTypeSearch] = useState<Record<string, string>>({});
  const [generating, setGenerating] = useState(false);
  const [genProgress, setGenProgress] = useState(0);
  const [useSeed, setUseSeed] = useState(false);
  const [seed, setSeed] = useState(42);
  const [savedConfigs, setSavedConfigs] = useState<SavedConfig[]>(loadSavedConfigs);
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [loadDialogOpen, setLoadDialogOpen] = useState(false);
  const [saveName, setSaveName] = useState("");
  const [bulkDialogOpen, setBulkDialogOpen] = useState(false);
  const [bulkText, setBulkText] = useState("");
  const [copiedCell, setCopiedCell] = useState<string | null>(null);
  const abortRef = useRef(false);

  const addField = useCallback(() => {
    setFields(prev => [...prev, { id: newFieldId(), name: "", type: "first_name", nullPercent: 0 }]);
  }, []);

  const removeField = useCallback((id: string) => {
    setFields(prev => prev.filter(f => f.id !== id));
  }, []);

  const duplicateField = useCallback((id: string) => {
    setFields(prev => {
      const idx = prev.findIndex(f => f.id === id);
      if (idx === -1) return prev;
      const src = prev[idx];
      const dup: FieldConfig = { ...src, id: newFieldId(), name: `${src.name}_copy` };
      const next = [...prev];
      next.splice(idx + 1, 0, dup);
      return next;
    });
  }, []);

  const updateField = useCallback((id: string, updates: Partial<FieldConfig>) => {
    setFields(prev => prev.map(f => f.id === id ? { ...f, ...updates } : f));
  }, []);

  const moveField = useCallback((id: string, dir: -1 | 1) => {
    setFields(prev => {
      const idx = prev.findIndex(f => f.id === id);
      if (idx === -1) return prev;
      const newIdx = idx + dir;
      if (newIdx < 0 || newIdx >= prev.length) return prev;
      const next = [...prev];
      [next[idx], next[newIdx]] = [next[newIdx], next[idx]];
      return next;
    });
  }, []);

  const resetFields = useCallback(() => {
    setFields([
      { id: newFieldId(), name: "id", type: "sequential_id", nullPercent: 0 },
      { id: newFieldId(), name: "first_name", type: "first_name", nullPercent: 0 },
      { id: newFieldId(), name: "last_name", type: "last_name", nullPercent: 0 },
      { id: newFieldId(), name: "email", type: "email", nullPercent: 0 },
    ]);
    setPreviewKey(k => k + 1);
  }, []);

  const applyTemplate = useCallback((tpl: DataTemplate) => {
    setFields(tpl.fields.map(templateFieldToConfig));
    setPreviewKey(k => k + 1);
    toast({ title: "Template Applied", description: `Loaded "${tpl.label}" with ${tpl.fields.length} columns.` });
  }, [toast]);

  const regeneratePreview = useCallback(() => {
    setPreviewKey(k => k + 1);
  }, []);

  const previewData = useMemo(() => {
    const validF = fields.filter(f => f.name.trim());
    if (validF.length === 0) return [];
    const count = Math.min(10, rowCount);
    return withRng(useSeed ? seed : undefined, () => {
      const rows: string[][] = [];
      for (let i = 0; i < count; i++) {
        const ctx = createRowContext();
        rows.push(validF.map(f => {
          if (f.nullPercent > 0 && rng() < f.nullPercent / 100) return "";
          return generateValue(f.type, i, ctx, f.enumValues, f.pattern, f.min, f.max);
        }));
      }
      return rows;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fields, previewKey, useSeed, seed]);

  const handleExport = useCallback(async (mode: "download" | "copy") => {
    const validFields = fields.filter(f => f.name.trim());
    if (validFields.length === 0) return;

    setGenerating(true);
    setGenProgress(0);
    abortRef.current = false;

    await new Promise(resolve => setTimeout(resolve, 50));

    const data = await generateExportDataAsync(
      fields, rowCount, exportFormat,
      useSeed ? seed : undefined,
      setGenProgress,
      abortRef,
    );

    setGenerating(false);

    if (abortRef.current || !data) return;

    const ext = exportFormat === "json" ? "json" : exportFormat === "sql" ? "sql" : exportFormat === "tsv" ? "tsv" : "csv";
    const mime = exportFormat === "json" ? "application/json" : exportFormat === "sql" ? "text/sql" : "text/csv";

    if (mode === "download") {
      const blob = new Blob([data], { type: `${mime};charset=utf-8;` });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `test-data-${rowCount}-rows.${ext}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast({ title: "Downloaded", description: `${exportFormat.toUpperCase()} file with ${rowCount.toLocaleString()} rows downloaded.` });
    } else {
      try {
        await navigator.clipboard.writeText(data);
      } catch {
        const textarea = document.createElement("textarea");
        textarea.value = data;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
      }
      toast({ title: "Copied", description: `${rowCount.toLocaleString()} rows copied as ${exportFormat.toUpperCase()}.` });
    }
  }, [fields, rowCount, exportFormat, useSeed, seed, toast]);

  const handleSaveConfig = useCallback(() => {
    if (!saveName.trim()) return;
    const config: SavedConfig = {
      name: saveName.trim(),
      fields: fields.map(({ id: _id, ...rest }) => rest),
      rowCount,
      savedAt: Date.now(),
    };
    const updated = [config, ...savedConfigs.filter(c => c.name !== config.name)].slice(0, 20);
    setSavedConfigs(updated);
    saveSavedConfigs(updated);
    setSaveDialogOpen(false);
    setSaveName("");
    toast({ title: "Configuration Saved", description: `"${config.name}" saved.` });
  }, [saveName, fields, rowCount, savedConfigs, toast]);

  const handleLoadConfig = useCallback((config: SavedConfig) => {
    setFields(config.fields.map(f => ({ ...f, id: newFieldId(), type: normalizeFieldType(f.type), nullPercent: f.nullPercent ?? 0 })));
    setRowCount(config.rowCount);
    setPreviewKey(k => k + 1);
    setLoadDialogOpen(false);
    toast({ title: "Configuration Loaded", description: `"${config.name}" loaded.` });
  }, [toast]);

  const handleDeleteConfig = useCallback((name: string) => {
    const updated = savedConfigs.filter(c => c.name !== name);
    setSavedConfigs(updated);
    saveSavedConfigs(updated);
  }, [savedConfigs]);

  const handleBulkAdd = useCallback(() => {
    const lines = bulkText.split("\n").map(l => l.trim()).filter(Boolean);
    const newFields: FieldConfig[] = [];
    for (const line of lines) {
      const [name, type] = line.split(":").map(s => s.trim());
      if (!name) continue;
      const matchedType = ALL_TYPES.find(t => t.value === type || t.label.toLowerCase() === type?.toLowerCase());
      newFields.push({
        id: newFieldId(),
        name,
        type: matchedType?.value || "first_name",
        nullPercent: 0,
      });
    }
    if (newFields.length > 0) {
      setFields(prev => [...prev, ...newFields]);
      setBulkDialogOpen(false);
      setBulkText("");
      toast({ title: "Columns Added", description: `${newFields.length} columns added from schema.` });
    }
  }, [bulkText, toast]);

  const handleCopyCell = useCallback(async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedCell(value);
      setTimeout(() => setCopiedCell(null), 1500);
    } catch {}
  }, []);

  const validFields = fields.filter(f => f.name.trim());

  const formatIcons: Record<ExportFormat, React.ReactNode> = {
    csv: <FileSpreadsheet className="h-3.5 w-3.5" />,
    json: <FileJson className="h-3.5 w-3.5" />,
    sql: <FileCode className="h-3.5 w-3.5" />,
    tsv: <FileSpreadsheet className="h-3.5 w-3.5" />,
  };

  return (
    <TooltipProvider>
      <div className="p-4 sm:p-6 lg:p-8 max-w-[1600px] mx-auto">
        <PageHeader
          title="Test Data Generator"
          subtitle="Generate intelligent, correlated test data — names, emails, and addresses stay consistent per row"
          actions={
            <div className="flex items-center gap-2 flex-wrap">
              <Dialog open={loadDialogOpen} onOpenChange={setLoadDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" disabled={savedConfigs.length === 0}>
                    <FolderOpen className="h-4 w-4 mr-1" />
                    Load
                    {savedConfigs.length > 0 && (
                      <Badge variant="secondary" className="ml-1 h-4 px-1 text-[10px]">{savedConfigs.length}</Badge>
                    )}
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Load Configuration</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-2 max-h-[400px] overflow-auto">
                    {savedConfigs.map(c => (
                      <div key={c.name} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                        <button className="text-left flex-1" onClick={() => handleLoadConfig(c)}>
                          <p className="font-medium text-sm">{c.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {c.fields.length} columns, {c.rowCount.toLocaleString()} rows
                            &bull; {new Date(c.savedAt).toLocaleDateString()}
                          </p>
                        </button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => handleDeleteConfig(c.name)}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Save className="h-4 w-4 mr-1" />
                    Save
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Save Configuration</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-3">
                    <Input
                      value={saveName}
                      onChange={e => setSaveName(e.target.value)}
                      placeholder="Configuration name..."
                      onKeyDown={e => e.key === "Enter" && handleSaveConfig()}
                    />
                    <p className="text-xs text-muted-foreground">
                      {fields.length} columns, {rowCount.toLocaleString()} rows
                    </p>
                    <Button onClick={handleSaveConfig} disabled={!saveName.trim()} className="w-full">
                      Save Configuration
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Separator orientation="vertical" className="h-6" />

              <Button variant="outline" size="sm" onClick={resetFields}>
                <RotateCcw className="h-4 w-4 mr-1" />
                Reset
              </Button>
              <Button variant="outline" size="sm" onClick={() => handleExport("copy")} disabled={validFields.length === 0 || generating}>
                <Copy className="h-4 w-4 mr-1" />
                Copy
              </Button>
              <Button size="sm" onClick={() => handleExport("download")} disabled={validFields.length === 0 || generating}>
                <Download className="h-4 w-4 mr-1" />
                Download
              </Button>
            </div>
          }
        />

        {generating && (
          <div className="mb-6 p-4 border rounded-lg bg-muted/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Generating {rowCount.toLocaleString()} rows...</span>
              <Button variant="ghost" size="sm" onClick={() => { abortRef.current = true; setGenerating(false); }}>
                Cancel
              </Button>
            </div>
            <Progress value={genProgress} className="h-2" />
          </div>
        )}

        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left Panel: Config */}
          <div className="xl:col-span-4 space-y-4">
            {/* Quick Templates */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-amber-500" />
                  Quick Templates
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {TEMPLATES.map(tpl => (
                    <button
                      key={tpl.label}
                      onClick={() => applyTemplate(tpl)}
                      className="flex items-start gap-2 p-2.5 border rounded-lg text-left hover:bg-muted/50 hover:border-primary/30 transition-all group"
                    >
                      <span className="mt-0.5 text-muted-foreground group-hover:text-primary transition-colors">
                        {TEMPLATE_ICONS[tpl.icon] || <Database className="h-4 w-4" />}
                      </span>
                      <div className="min-w-0">
                        <p className="text-xs font-medium truncate">{tpl.label}</p>
                        <p className="text-[10px] text-muted-foreground truncate">{tpl.fields.length} columns</p>
                      </div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Column Configuration */}
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Columns className="h-4 w-4" />
                    Columns
                    <Badge variant="secondary" className="text-[10px] h-4 px-1.5">{fields.length}</Badge>
                  </CardTitle>
                  <div className="flex items-center gap-1">
                    <Dialog open={bulkDialogOpen} onOpenChange={setBulkDialogOpen}>
                      <DialogTrigger asChild>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-7 w-7">
                              <FileCode className="h-3.5 w-3.5" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Bulk add from schema</TooltipContent>
                        </Tooltip>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Bulk Add Columns</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-3">
                          <p className="text-xs text-muted-foreground">
                            Enter one column per line as <code className="bg-muted px-1 rounded">name:type</code>
                          </p>
                          <textarea
                            className="w-full h-40 p-3 text-sm font-mono border rounded-lg bg-background resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                            value={bulkText}
                            onChange={e => setBulkText(e.target.value)}
                            placeholder={"user_id:sequential_id\nname:full_name\nemail:email\nage:age\ncity:city"}
                          />
                          <Button onClick={handleBulkAdd} disabled={!bulkText.trim()} className="w-full">
                            Add Columns
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="space-y-1.5 max-h-[calc(100vh-520px)] overflow-auto pr-1">
                  {fields.map((field, idx) => (
                    <FieldRow
                      key={field.id}
                      field={field}
                      index={idx}
                      total={fields.length}
                      typeSearch={typeSearch[field.id] || ""}
                      onTypeSearchChange={(v) => setTypeSearch(prev => ({ ...prev, [field.id]: v }))}
                      onUpdate={(updates) => updateField(field.id, updates)}
                      onRemove={() => removeField(field.id)}
                      onDuplicate={() => duplicateField(field.id)}
                      onMove={(dir) => moveField(field.id, dir)}
                    />
                  ))}
                </div>

                <Button variant="outline" size="sm" className="w-full" onClick={addField}>
                  <Plus className="h-4 w-4 mr-1" />
                  Add Column
                </Button>
              </CardContent>
            </Card>

            {/* Settings Row */}
            <Card>
              <CardContent className="pt-4 space-y-4">
                {/* Row Count */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-sm font-medium flex items-center gap-2">
                      <Hash className="h-3.5 w-3.5" />
                      Rows
                    </Label>
                    <Input
                      type="number"
                      value={rowCount}
                      onChange={e => {
                        const v = parseInt(e.target.value);
                        if (!isNaN(v) && v >= 1 && v <= 1000000) setRowCount(v);
                      }}
                      min={1}
                      max={1000000}
                      className="h-7 w-24 text-sm text-right"
                    />
                  </div>
                  <div className="flex gap-1">
                    {ROW_PRESETS.map(n => (
                      <button
                        key={n}
                        className={`flex-1 h-7 rounded-md text-xs font-medium transition-all ${
                          rowCount === n
                            ? "bg-primary text-primary-foreground shadow-sm"
                            : "bg-muted/50 text-muted-foreground hover:bg-muted"
                        }`}
                        onClick={() => setRowCount(n)}
                      >
                        {n >= 1000 ? `${n / 1000}K` : n}
                      </button>
                    ))}
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-1.5">
                    {fields.length} cols &times; {rowCount.toLocaleString()} rows = {(fields.length * rowCount).toLocaleString()} cells
                  </p>
                </div>

                <Separator />

                {/* Export Format */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">Export Format</Label>
                  <Tabs value={exportFormat} onValueChange={v => setExportFormat(v as ExportFormat)}>
                    <TabsList className="w-full grid grid-cols-4 h-8">
                      {(["csv", "json", "sql", "tsv"] as ExportFormat[]).map(fmt => (
                        <TabsTrigger key={fmt} value={fmt} className="text-xs gap-1 h-7">
                          {formatIcons[fmt]}
                          {fmt.toUpperCase()}
                        </TabsTrigger>
                      ))}
                    </TabsList>
                  </Tabs>
                </div>

                <Separator />

                {/* Seed */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Shuffle className="h-3.5 w-3.5 text-muted-foreground" />
                    <Label className="text-sm">Reproducible Seed</Label>
                  </div>
                  <Switch checked={useSeed} onCheckedChange={setUseSeed} />
                </div>
                {useSeed && (
                  <Input
                    type="number"
                    value={seed}
                    onChange={e => setSeed(parseInt(e.target.value) || 0)}
                    className="h-8 text-sm"
                    placeholder="Seed value"
                  />
                )}
              </CardContent>
            </Card>

            {/* Intelligent Features - Collapsible */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="sm" className="w-full text-muted-foreground hover:text-foreground">
                  <Info className="h-3.5 w-3.5 mr-1.5" />
                  Intelligent Features
                  <Zap className="h-3 w-3 ml-1 text-amber-500" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80" side="top">
                <div className="space-y-2 text-xs text-muted-foreground">
                  <p className="font-medium text-foreground text-sm">How it works</p>
                  <p><strong className="text-foreground">Row Correlation</strong> — First name, last name, email, username, and company stay consistent within each row</p>
                  <p><strong className="text-foreground">Geographic Consistency</strong> — City, state, and zip code are matched to real US locations</p>
                  <p><strong className="text-foreground">Format Variety</strong> — Emails, phones, addresses, and URLs use multiple realistic format patterns</p>
                  <p><strong className="text-foreground">Diverse Names</strong> — 230+ first names and 150+ last names across multiple cultures</p>
                  <p><strong className="text-foreground">Valid Formats</strong> — Credit cards pass Luhn check, SSNs match xxx-xx-xxxx, IBANs use country-specific lengths</p>
                </div>
              </PopoverContent>
            </Popover>
          </div>

          {/* Right Panel: Preview */}
          <div className="xl:col-span-8">
            <Card className="h-full">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Eye className="h-4 w-4" />
                    Preview
                    {previewData.length > 0 && (
                      <Badge variant="secondary" className="text-[10px] h-4 px-1.5">
                        {Math.min(10, rowCount)} of {rowCount.toLocaleString()} rows
                      </Badge>
                    )}
                  </CardTitle>
                  <Button variant="ghost" size="sm" onClick={regeneratePreview} className="h-7">
                    <RotateCcw className="h-3.5 w-3.5 mr-1" />
                    Regenerate
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {validFields.length === 0 ? (
                  <div className="text-center py-16 text-muted-foreground">
                    <Database className="h-12 w-12 mx-auto mb-3 opacity-20" />
                    <p className="text-sm font-medium">No columns configured</p>
                    <p className="text-xs mt-1">Add columns on the left or pick a template to get started.</p>
                  </div>
                ) : (
                  <div className="border rounded-lg overflow-auto max-h-[calc(100vh-240px)]">
                    <Table>
                      <TableHeader className="sticky top-0 bg-background z-10">
                        <TableRow>
                          <TableHead className="w-10 text-center text-xs">#</TableHead>
                          {validFields.map(f => (
                            <TableHead key={f.id} className="min-w-[100px]">
                              <div className="flex flex-col gap-0.5">
                                <span className="text-xs font-medium">{f.name}</span>
                                <Badge variant="outline" className={`text-[9px] w-fit ${getGroupColor(f.type)}`}>
                                  {getTypeLabel(f.type)}
                                </Badge>
                              </div>
                            </TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {previewData.map((row, i) => (
                          <TableRow key={i} className="hover:bg-muted/40 transition-colors">
                            <TableCell className="text-center text-muted-foreground text-xs font-mono">{i + 1}</TableCell>
                            {row.map((cell, j) => (
                              <TableCell
                                key={j}
                                className="text-xs font-mono max-w-[220px] truncate cursor-pointer hover:bg-muted/60 transition-colors relative group"
                                title={cell || "(null)"}
                                onClick={() => handleCopyCell(cell)}
                              >
                                {cell ? (
                                  <span>{cell}</span>
                                ) : (
                                  <span className="text-muted-foreground/40 italic">null</span>
                                )}
                                <span className="absolute right-1 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                                  {copiedCell === cell && cell ? (
                                    <Badge variant="secondary" className="text-[9px] h-4 px-1">Copied</Badge>
                                  ) : (
                                    <ClipboardCopy className="h-3 w-3 text-muted-foreground" />
                                  )}
                                </span>
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
}

interface FieldRowProps {
  field: FieldConfig;
  index: number;
  total: number;
  typeSearch: string;
  onTypeSearchChange: (v: string) => void;
  onUpdate: (updates: Partial<FieldConfig>) => void;
  onRemove: () => void;
  onDuplicate: () => void;
  onMove: (dir: -1 | 1) => void;
}

function FormulaLivePreview({ formula, regexPattern, type }: { formula?: string; regexPattern?: string; type?: string }) {
  const preview = useMemo(() => {
    if (type === "regex_like" && regexPattern) {
      try {
        const ctx = createRowContext();
        return { value: generateValue("regex_like", 0, ctx, undefined, regexPattern), error: null };
      } catch { return { value: "", error: "Invalid pattern" }; }
    }
    if (!formula) return null;
    return tryEvaluateFormula(formula);
  }, [formula, regexPattern, type]);

  if (!preview) return null;

  return (
    <div className={`flex items-start gap-1.5 mt-1 p-1.5 rounded text-[10px] font-mono ${preview.error ? "bg-red-500/5 border border-red-500/20" : "bg-green-500/5 border border-green-500/20"}`}>
      {preview.error
        ? <AlertCircle className="h-3 w-3 text-red-500 shrink-0 mt-0.5" />
        : <Check className="h-3 w-3 text-green-500 shrink-0 mt-0.5" />
      }
      <div className="min-w-0 flex-1">
        {preview.error && <p className="text-red-500 text-[9px]">{preview.error}</p>}
        <p className="text-foreground/80 break-all">{preview.value || <span className="text-muted-foreground italic">empty</span>}</p>
      </div>
    </div>
  );
}

function FormulaEditor({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [showTokens, setShowTokens] = useState(false);
  const [tokenFilter, setTokenFilter] = useState("");

  const insertToken = useCallback((token: string) => {
    const ta = textareaRef.current;
    if (!ta) { onChange(value + `{${token}}`); return; }
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const insert = `{${token}}`;
    const newVal = value.substring(0, start) + insert + value.substring(end);
    onChange(newVal);
    requestAnimationFrame(() => {
      ta.focus();
      const pos = start + insert.length;
      ta.setSelectionRange(pos, pos);
    });
  }, [value, onChange]);

  const filteredTokenGroups = useMemo(() => {
    if (!tokenFilter) return FORMULA_TOKEN_GROUPS;
    const q = tokenFilter.toLowerCase();
    return FORMULA_TOKEN_GROUPS.map(g => ({
      ...g,
      tokens: g.tokens.filter(t =>
        t.token.toLowerCase().includes(q) ||
        t.desc.toLowerCase().includes(q) ||
        t.example.toLowerCase().includes(q)
      ),
    })).filter(g => g.tokens.length > 0);
  }, [tokenFilter]);

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <Label className="text-[10px] text-muted-foreground flex items-center gap-1">
          <Wand2 className="h-3 w-3" />
          Formula
        </Label>
        <div className="flex items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <button className="text-[9px] text-blue-500 hover:underline flex items-center gap-0.5">
                <Lightbulb className="h-2.5 w-2.5" />
                Presets
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-80 max-h-[320px] overflow-auto p-2" side="left" align="start">
              <p className="text-[10px] font-semibold mb-1.5">Quick Presets</p>
              <div className="space-y-1">
                {FORMULA_PRESETS.map((p, i) => (
                  <button
                    key={i}
                    className="w-full text-left p-1.5 rounded hover:bg-muted/80 transition-colors group"
                    onClick={() => onChange(p.formula)}
                  >
                    <span className="text-[10px] font-medium text-foreground">{p.label}</span>
                    <p className="text-[9px] text-muted-foreground">{p.desc}</p>
                    <p className="text-[9px] font-mono text-blue-500/70 group-hover:text-blue-500 break-all">{p.formula}</p>
                  </button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
          <button
            className={`text-[9px] hover:underline flex items-center gap-0.5 ${showTokens ? "text-foreground font-medium" : "text-muted-foreground"}`}
            onClick={() => setShowTokens(!showTokens)}
          >
            <ChevronRight className={`h-2.5 w-2.5 transition-transform ${showTokens ? "rotate-90" : ""}`} />
            Tokens
          </button>
        </div>
      </div>

      <textarea
        ref={textareaRef}
        className={`w-full p-2 text-xs font-mono border rounded-md bg-background resize-none focus:outline-none focus:ring-1 focus:ring-ring ${value ? "h-14" : "h-10"}`}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder="{firstName}.{lastName}@{pick:gmail.com|yahoo.com}"
        spellCheck={false}
      />

      <FormulaLivePreview formula={value} />

      {showTokens && (
        <div className="border rounded-md bg-muted/30 p-2 space-y-2">
          <div className="flex items-center gap-1 border-b pb-1.5">
            <Search className="h-3 w-3 text-muted-foreground" />
            <input
              className="flex-1 text-[10px] bg-transparent outline-none placeholder:text-muted-foreground"
              placeholder="Filter tokens..."
              value={tokenFilter}
              onChange={e => setTokenFilter(e.target.value)}
            />
            {tokenFilter && <button onClick={() => setTokenFilter("")}><X className="h-3 w-3 text-muted-foreground" /></button>}
          </div>
          {filteredTokenGroups.map(group => (
            <div key={group.label}>
              <p className="text-[9px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">{group.label}</p>
              <div className="flex flex-wrap gap-1">
                {group.tokens.map(t => (
                  <Tooltip key={t.token}>
                    <TooltipTrigger asChild>
                      <button
                        className="px-1.5 py-0.5 text-[9px] font-mono bg-background border rounded hover:bg-blue-500/10 hover:border-blue-500/30 hover:text-blue-600 transition-colors"
                        onClick={() => insertToken(t.token)}
                      >
                        {t.token}
                      </button>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="text-[10px]">
                      <span className="font-mono text-blue-500">{t.example}</span>
                      <span className="text-muted-foreground ml-1.5">{t.desc}</span>
                    </TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function FieldRow({ field, index, total, typeSearch, onTypeSearchChange, onUpdate, onRemove, onDuplicate, onMove }: FieldRowProps) {
  const [expanded, setExpanded] = useState(false);
  const hasOptions = field.type === "enum" || field.type === "weighted_enum" || field.type === "pattern" || field.type === "integer_range" || field.type === "decimal_range" || field.type === "duration_ms";
  const groupName = getGroupName(field.type);

  const filteredGroups = useMemo(() => {
    if (!typeSearch) return TYPE_GROUPS;
    const q = typeSearch.toLowerCase();
    return TYPE_GROUPS.map(g => ({
      ...g,
      types: g.types.filter(t =>
        t.label.toLowerCase().includes(q) ||
        t.value.toLowerCase().includes(q) ||
        g.label.toLowerCase().includes(q)
      ),
    })).filter(g => g.types.length > 0);
  }, [typeSearch]);

  return (
    <div className="border rounded-lg p-2.5 bg-muted/20 hover:bg-muted/30 transition-colors space-y-2">
      {/* Main Row: Name | Type | Actions */}
      <div className="flex items-center gap-1.5">
        <span className="text-[10px] font-mono text-muted-foreground/60 w-4 text-right shrink-0">{index + 1}</span>
        <Input
          value={field.name}
          onChange={e => onUpdate({ name: e.target.value })}
          placeholder="column_name"
          className="h-7 text-xs flex-1 min-w-0 font-mono"
        />

        <Select value={field.type} onValueChange={v => { onUpdate({ type: v }); onTypeSearchChange(""); }}>
          <SelectTrigger className="h-7 text-xs w-[140px] shrink-0">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <div className="p-1.5">
              <div className="flex items-center gap-1.5 px-1 pb-1.5 border-b mb-1">
                <Search className="h-3 w-3 text-muted-foreground" />
                <input
                  className="flex-1 text-xs bg-transparent outline-none placeholder:text-muted-foreground"
                  placeholder="Search types..."
                  value={typeSearch}
                  onChange={e => onTypeSearchChange(e.target.value)}
                  onClick={e => e.stopPropagation()}
                />
                {typeSearch && (
                  <button onClick={(e) => { e.stopPropagation(); onTypeSearchChange(""); }}>
                    <X className="h-3 w-3 text-muted-foreground" />
                  </button>
                )}
              </div>
            </div>
            {filteredGroups.map(group => (
              <div key={group.label}>
                <div className="px-2 py-1 text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">{group.label}</div>
                {group.types.map(t => (
                  <SelectItem key={t.value} value={t.value} className="text-xs">{t.label}</SelectItem>
                ))}
              </div>
            ))}
          </SelectContent>
        </Select>

        {/* Actions */}
        <div className="flex items-center shrink-0">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => onMove(-1)} disabled={index === 0}>
                <ChevronUp className="h-3 w-3" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top">Move up</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => onMove(1)} disabled={index === total - 1}>
                <ChevronDown className="h-3 w-3" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top">Move down</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onDuplicate}>
                <CopyPlus className="h-3 w-3" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top">Duplicate</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={onRemove} disabled={total <= 1}>
                <Trash2 className="h-3 w-3" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top">Remove</TooltipContent>
          </Tooltip>
        </div>
      </div>

      {/* Type badge + expand toggle */}
      <div className="flex items-center gap-1.5 pl-5">
        <Badge variant="outline" className={`text-[9px] ${getGroupColor(field.type)}`}>
          {groupName} &bull; {getTypeLabel(field.type)}
        </Badge>
        {field.nullPercent > 0 && (
          <Badge variant="outline" className="text-[9px] bg-muted/50">
            {field.nullPercent}% null
          </Badge>
        )}
        <button
          className="ml-auto text-[10px] text-muted-foreground hover:text-foreground transition-colors"
          onClick={() => setExpanded(!expanded)}
        >
          {expanded ? "Less" : "More"}
        </button>
      </div>

      {expanded && (
        <div className="pl-5 space-y-2 pt-1 border-t border-dashed">
          <div className="flex items-center gap-3">
            <Label className="text-[10px] text-muted-foreground w-16 shrink-0">Null %</Label>
            <Slider
              value={[field.nullPercent]}
              onValueChange={([v]) => onUpdate({ nullPercent: v })}
              max={100}
              step={5}
              className="flex-1"
            />
            <span className="text-[10px] text-muted-foreground w-8 text-right">{field.nullPercent}%</span>
          </div>

          {field.type === "custom_formula" && (
            <FormulaEditor
              value={field.pattern || ""}
              onChange={(v) => onUpdate({ pattern: v })}
            />
          )}
          {field.type === "enum" && (
            <div>
              <Label className="text-[10px] text-muted-foreground">Values (comma-separated)</Label>
              <Input value={field.enumValues || ""} onChange={e => onUpdate({ enumValues: e.target.value })} placeholder="Male,Female,Other" className="h-7 text-xs mt-0.5" />
            </div>
          )}
          {field.type === "weighted_enum" && (
            <div>
              <Label className="text-[10px] text-muted-foreground">Values with weights (value:weight,...)</Label>
              <Input value={field.enumValues || ""} onChange={e => onUpdate({ enumValues: e.target.value })} placeholder="Active:70,Inactive:20,Suspended:10" className="h-7 text-xs mt-0.5" />
            </div>
          )}
          {field.type === "pattern" && (
            <div>
              <Label className="text-[10px] text-muted-foreground"># = digit, ? = letter, * = either</Label>
              <Input value={field.pattern || ""} onChange={e => onUpdate({ pattern: e.target.value })} placeholder="USR-####-??" className="h-7 text-xs mt-0.5 font-mono" />
            </div>
          )}
          {field.type === "regex_like" && (
            <div>
              <Label className="text-[10px] text-muted-foreground">Character classes with repeat: [A-Z]{"{N}"}, [0-9]{"{3}"}</Label>
              <Input value={field.pattern || ""} onChange={e => onUpdate({ pattern: e.target.value })} placeholder="[A-Z]{3}-[0-9]{4}" className="h-7 text-xs mt-0.5 font-mono" />
              <FormulaLivePreview formula="" regexPattern={field.pattern} type="regex_like" />
            </div>
          )}
          {field.type === "custom_list" && (
            <div>
              <div className="flex items-center justify-between mb-0.5">
                <Label className="text-[10px] text-muted-foreground">One value per line</Label>
                <label className="flex items-center gap-1 text-[10px] text-muted-foreground cursor-pointer">
                  <input type="checkbox" className="h-3 w-3 rounded" checked={field.min === 1} onChange={e => onUpdate({ min: e.target.checked ? 1 : 0 })} />
                  Random pick
                </label>
              </div>
              <textarea
                className="w-full h-20 p-2 text-xs font-mono border rounded-md bg-background resize-none focus:outline-none focus:ring-1 focus:ring-ring"
                value={field.enumValues || ""}
                onChange={e => onUpdate({ enumValues: e.target.value })}
                placeholder={"Server-East\nServer-West\nServer-EU\nServer-Asia"}
              />
              <p className="text-[9px] text-muted-foreground mt-0.5">
                {field.min === 1 ? "Picks randomly from list" : "Cycles sequentially through list"}
                {field.enumValues ? ` (${(field.enumValues).split("\n").filter(v => v.trim()).length} values)` : ""}
              </p>
            </div>
          )}
          {field.type === "composite_id" && (
            <div className="flex gap-2">
              <div className="flex-1">
                <Label className="text-[10px] text-muted-foreground">Prefix</Label>
                <Input value={field.enumValues || ""} onChange={e => onUpdate({ enumValues: e.target.value })} placeholder="ORD" className="h-7 text-xs mt-0.5 font-mono" />
              </div>
              <div className="w-20">
                <Label className="text-[10px] text-muted-foreground">Digits</Label>
                <Input type="number" value={field.min ?? 6} onChange={e => onUpdate({ min: Number(e.target.value) || 6 })} className="h-7 text-xs mt-0.5" min={3} max={12} />
              </div>
            </div>
          )}
          {field.type === "constant" && (
            <div>
              <Label className="text-[10px] text-muted-foreground">Fixed value for every row</Label>
              <Input value={field.enumValues || ""} onChange={e => onUpdate({ enumValues: e.target.value })} placeholder="production" className="h-7 text-xs mt-0.5" />
            </div>
          )}
          {field.type === "lorem_words" && (
            <div>
              <Label className="text-[10px] text-muted-foreground">Number of words</Label>
              <Input type="number" value={field.min ?? 5} onChange={e => onUpdate({ min: Number(e.target.value) || 5 })} placeholder="5" className="h-7 text-xs mt-0.5" min={1} max={100} />
            </div>
          )}
          {(field.type === "integer_range" || field.type === "decimal_range" || field.type === "duration_ms" || field.type === "custom_range_date") && (
            <div className="flex gap-2">
              <div className="flex-1">
                <Label className="text-[10px] text-muted-foreground">{field.type === "custom_range_date" ? "Start Year" : "Min"}</Label>
                <Input type="number" value={field.min ?? ""} onChange={e => onUpdate({ min: e.target.value ? Number(e.target.value) : undefined })} placeholder={field.type === "custom_range_date" ? "2020" : "0"} className="h-7 text-xs mt-0.5" />
              </div>
              <div className="flex-1">
                <Label className="text-[10px] text-muted-foreground">{field.type === "custom_range_date" ? "End Year" : "Max"}</Label>
                <Input type="number" value={field.max ?? ""} onChange={e => onUpdate({ max: e.target.value ? Number(e.target.value) : undefined })} placeholder={field.type === "custom_range_date" ? "2026" : "1000"} className="h-7 text-xs mt-0.5" />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
