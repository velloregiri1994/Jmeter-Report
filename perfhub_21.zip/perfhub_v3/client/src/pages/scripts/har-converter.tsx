import { useState, useCallback, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import {
  Upload,
  Wand2,
  Download,
  Save,
  Trash2,
  AlertTriangle,
  Info,
  CheckCircle2,
  Loader2,
  FileCode,
  ArrowLeft,
  RotateCcw,
  Link2,
  Shield,
  FileText,
  Code,
  XCircle,
  Globe,
  Check,
} from "lucide-react";

interface Generation {
  id: number;
  name: string;
  status: string;
  inputType: string;
  inputFileName: string;
  inputFileSize: number;
  hasJmxContent: boolean;
  hasCsvContent: boolean;
  correlations: any[] | null;
  parameterizations: any[] | null;
  issues: any[] | null;
  qualityScore: number | null;
  readinessLevel: string | null;
  stats: any | null;
  errorMessage: string | null;
  scriptId: number | null;
  createdAt: string;
}

function getScoreColor(score: number) {
  if (score >= 80) return "text-blue-600";
  if (score >= 60) return "text-emerald-600";
  if (score >= 40) return "text-amber-600";
  return "text-red-600";
}

function getScoreBg(score: number) {
  if (score >= 80) return "bg-blue-50 border-blue-200";
  if (score >= 60) return "bg-emerald-50 border-emerald-200";
  if (score >= 40) return "bg-amber-50 border-amber-200";
  return "bg-red-50 border-red-200";
}

function getReadinessBadge(level: string) {
  const map: Record<string, string> = {
    "Production Ready": "bg-blue-100 text-blue-700 border-blue-300",
    "Good": "bg-emerald-100 text-emerald-700 border-emerald-300",
    "Moderate": "bg-amber-100 text-amber-700 border-amber-300",
    "Poor": "bg-red-100 text-red-700 border-red-300",
  };
  return map[level] || "bg-muted text-muted-foreground";
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

interface DomainInfo {
  domain: string;
  requestCount: number;
  isThirdParty: boolean;
  included: boolean;
}

const KNOWN_THIRD_PARTY_ROOTS = new Set([
  'google-analytics.com', 'googletagmanager.com', 'googleapis.com', 'gstatic.com',
  'google.com', 'googlesyndication.com', 'googleadservices.com', 'doubleclick.net',
  'youtube.com', 'facebook.com', 'facebook.net', 'fbcdn.net', 'instagram.com',
  'twitter.com', 'twimg.com', 'linkedin.com', 'licdn.com', 'pinterest.com',
  'tiktok.com', 'hotjar.com', 'clarity.ms', 'newrelic.com', 'nr-data.net',
  'segment.io', 'segment.com', 'mixpanel.com', 'optimizely.com', 'fullstory.com',
  'mouseflow.com', 'crazyegg.com', 'heapanalytics.com', 'amplitude.com',
  'sentry.io', 'bugsnag.com', 'rollbar.com', 'intercom.io', 'zendesk.com',
  'zdassets.com', 'crisp.chat', 'drift.com', 'hubspot.com', 'hs-scripts.com',
  'hs-analytics.net', 'hsforms.com', 'marketo.net', 'pardot.com', 'bing.com',
  'cookielaw.org', 'cookiebot.com', 'onetrust.com', 'trustarcedge.com',
  'cloudflare.com', 'cdnjs.cloudflare.com', 'jsdelivr.net', 'unpkg.com',
  'bootstrapcdn.com', 'jquery.com', 'fontawesome.com', 'recaptcha.net',
  'hcaptcha.com', 'stripe.com', 'paypal.com', 'braintreegateway.com',
  'cloudfront.net', 'akamaihd.net', 'akamai.net', 'fastly.net', 'maxcdn.com',
  'stackpath.com', 'azureedge.net', 'appdynamics.com', 'dynatrace.com',
  'datadoghq.com', 'pendo.io', 'walkme.com', 'launchdarkly.com',
  'livechatinc.com', 'tawk.to', 'freshdesk.com', 'typekit.net',
  'gravatar.com', 'wp.com', 'sharethis.com', 'addthis.com', 'disqus.com',
  'chartbeat.com', 'quantserve.com', 'scorecardresearch.com', 'demdex.net',
  'omtrdc.net', 'adobedtm.com', 'cookiepro.com', 'iubenda.com',
  'usercentrics.eu', 'consentmanager.net',
]);

function extractRootDomain(domain: string): string {
  const parts = domain.toLowerCase().split('.');
  if (parts.length <= 2) return domain.toLowerCase();
  const ccTLDs = new Set(['co.uk','co.in','co.jp','com.au','com.br','com.cn','org.uk']);
  const lastTwo = parts.slice(-2).join('.');
  if (ccTLDs.has(lastTwo) && parts.length > 2) return parts.slice(-3).join('.');
  return parts.slice(-2).join('.');
}

function isKnownThirdParty(domain: string): boolean {
  const root = extractRootDomain(domain);
  return KNOWN_THIRD_PARTY_ROOTS.has(root);
}

function scanHarDomains(harContent: string): DomainInfo[] {
  try {
    const domainCounts = new Map<string, number>();
    const urlPattern = /"url"\s*:\s*"(https?:\/\/[^"]+)"/g;
    let match;
    while ((match = urlPattern.exec(harContent)) !== null) {
      try {
        const url = new URL(match[1]);
        const domain = url.hostname;
        if (domain) {
          domainCounts.set(domain, (domainCounts.get(domain) || 0) + 1);
        }
      } catch {}
    }

    const domains: DomainInfo[] = [];
    for (const [domain, count] of domainCounts) {
      domains.push({
        domain,
        requestCount: count,
        isThirdParty: isKnownThirdParty(domain),
        included: !isKnownThirdParty(domain),
      });
    }

    domains.sort((a, b) => {
      if (a.isThirdParty !== b.isThirdParty) return a.isThirdParty ? 1 : -1;
      return b.requestCount - a.requestCount;
    });

    return domains;
  } catch {
    return [];
  }
}

function UploadPhase({ onUploaded }: { onUploaded: (id: number) => void }) {
  const { toast } = useToast();
  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [name, setName] = useState("");
  const [threadCount, setThreadCount] = useState("10");
  const [rampUp, setRampUp] = useState("60");
  const [duration, setDuration] = useState("300");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [detectedDomains, setDetectedDomains] = useState<DomainInfo[]>([]);
  const [scanningDomains, setScanningDomains] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const isJmxFile = file ? /\.(jmx|xml)$/i.test(file.name) : false;

  const scanFile = useCallback(async (f: File) => {
    if (/\.(jmx|xml)$/i.test(f.name)) return;
    setScanningDomains(true);
    try {
      const text = await f.text();
      const domains = scanHarDomains(text);
      setDetectedDomains(domains);
    } catch {
      setDetectedDomains([]);
    }
    setScanningDomains(false);
  }, []);

  const toggleDomain = useCallback((domain: string) => {
    setDetectedDomains(prev =>
      prev.map(d => d.domain === domain ? { ...d, included: !d.included } : d)
    );
  }, []);

  const selectAllDomains = useCallback(() => {
    setDetectedDomains(prev => prev.map(d => ({ ...d, included: true })));
  }, []);

  const deselectThirdParty = useCallback(() => {
    setDetectedDomains(prev =>
      prev.map(d => ({ ...d, included: d.isThirdParty ? false : d.included }))
    );
  }, []);

  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("No file selected");
      const formData = new FormData();
      formData.append("harFile", file);
      const cleanName = name || file.name.replace(/\.(har|jmx|xml)$/i, "");
      formData.append("name", cleanName);
      if (!isJmxFile) {
        formData.append("threadCount", threadCount);
        formData.append("rampUp", rampUp);
        formData.append("duration", duration);
        if (detectedDomains.length > 0) {
          const included = detectedDomains.filter(d => d.included).map(d => d.domain);
          const excluded = detectedDomains.filter(d => !d.included).map(d => d.domain);
          if (included.length > 0 && included.length < detectedDomains.length) {
            formData.append("includeDomains", included.join(','));
          }
          if (excluded.length > 0) {
            formData.append("excludeDomains", excluded.join(','));
          }
        }
      }

      const res = await fetch("/api/har-converter/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
        headers: { "X-Requested-With": "XMLHttpRequest" },
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Upload failed" }));
        throw new Error(err.message || "Upload failed");
      }
      return res.json();
    },
    onSuccess: (data) => {
      onUploaded(data.id);
    },
    onError: (err: Error) => {
      toast({ title: "Upload Failed", description: err.message, variant: "destructive" });
    },
  });

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f && (f.name.endsWith(".har") || f.name.endsWith(".jmx") || f.name.endsWith(".xml") || f.type === "application/json" || f.type === "application/xml" || f.type === "text/xml")) {
      setFile(f);
      if (!name) setName(f.name.replace(/\.(har|jmx|xml)$/i, ""));
      scanFile(f);
    } else {
      toast({ title: "Invalid File", description: "Please upload a .har or .jmx file", variant: "destructive" });
    }
  }, [name, toast, scanFile]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
      if (!name) setName(f.name.replace(/\.(har|jmx|xml)$/i, ""));
      scanFile(f);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 mb-2">
          <Wand2 className="h-7 w-7 text-primary" />
        </div>
        <h2 className="text-2xl font-bold text-foreground">Script Converter & Analyzer</h2>
        <p className="text-muted-foreground">
          Upload a browser HAR recording to generate a JMeter script, or upload an existing JMX file to analyze its quality, correlations, and best practices.
        </p>
      </div>

      <Card>
        <CardContent className="pt-6 space-y-4">
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
              dragOver ? "border-primary bg-primary/5" : file ? "border-emerald-400 bg-emerald-50" : "border-border hover:border-primary/50"
            }`}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileRef.current?.click()}
          >
            <input ref={fileRef} type="file" accept=".har,.jmx,.xml,application/json,application/xml,text/xml" className="hidden" onChange={handleFileChange} />
            {file ? (
              <div className="space-y-2">
                <CheckCircle2 className="h-8 w-8 text-emerald-500 mx-auto" />
                <p className="text-foreground font-medium">{file.name}</p>
                <div className="flex items-center justify-center gap-2">
                  <Badge variant="outline" className={isJmxFile ? "text-blue-600 border-blue-300" : "text-amber-600 border-amber-300"}>
                    {isJmxFile ? "JMX Analysis" : "HAR to JMX"}
                  </Badge>
                  <span className="text-muted-foreground text-sm">{formatBytes(file.size)}</span>
                </div>
                <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); setFile(null); setDetectedDomains([]); }}>
                  Change file
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <Upload className="h-8 w-8 text-muted-foreground mx-auto" />
                <p className="text-foreground">Drop your HAR or JMX file here or click to browse</p>
                <p className="text-muted-foreground text-xs">Supports .har (browser recording) and .jmx (JMeter script) - Max 50 MB</p>
              </div>
            )}
          </div>

          <div>
            <Label>Script Name</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Login Flow, Checkout Process"
            />
          </div>

          {!isJmxFile && scanningDomains && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground py-2">
              <Loader2 className="h-3 w-3 animate-spin" />
              Scanning domains...
            </div>
          )}

          {!isJmxFile && detectedDomains.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm font-medium text-foreground">Domain Filtering</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" className="h-6 text-xs px-2" onClick={selectAllDomains}>
                    Select All
                  </Button>
                  <Button variant="ghost" size="sm" className="h-6 text-xs px-2" onClick={deselectThirdParty}>
                    Deselect Third-Party
                  </Button>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                {detectedDomains.length} domain{detectedDomains.length !== 1 ? 's' : ''} detected.
                Select the domains to include in your JMeter script. Third-party domains are auto-excluded.
              </p>
              <div className="max-h-48 overflow-y-auto border rounded-md divide-y">
                {detectedDomains.map((d) => (
                  <div
                    key={d.domain}
                    className={`flex items-center justify-between px-3 py-2 cursor-pointer hover:bg-accent/50 transition-colors ${
                      d.included ? 'bg-background' : 'bg-muted/30'
                    }`}
                    onClick={() => toggleDomain(d.domain)}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={`flex-shrink-0 w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                        d.included
                          ? 'bg-primary border-primary'
                          : 'border-muted-foreground/30'
                      }`}>
                        {d.included && <Check className="h-3 w-3 text-primary-foreground" />}
                      </div>
                      <span className={`text-sm truncate ${d.included ? 'text-foreground' : 'text-muted-foreground line-through'}`}>
                        {d.domain}
                      </span>
                      {d.isThirdParty && (
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-amber-300 text-amber-600 flex-shrink-0">
                          third-party
                        </Badge>
                      )}
                    </div>
                    <span className="text-xs text-muted-foreground flex-shrink-0 ml-2">
                      {d.requestCount} req{d.requestCount !== 1 ? 's' : ''}
                    </span>
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                {detectedDomains.filter(d => d.included).length} of {detectedDomains.length} domain{detectedDomains.length !== 1 ? 's' : ''} selected
              </p>
            </div>
          )}

          {!isJmxFile && (
            <>
              <Button
                variant="link"
                size="sm"
                className="text-muted-foreground p-0"
                onClick={() => setShowAdvanced(!showAdvanced)}
              >
                {showAdvanced ? "Hide" : "Show"} Advanced Options
              </Button>

              {showAdvanced && (
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <Label className="text-xs text-muted-foreground">Threads</Label>
                      <Input
                        type="number"
                        value={threadCount}
                        onChange={(e) => setThreadCount(e.target.value)}
                        min={1}
                        max={10000}
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Ramp-up (s)</Label>
                      <Input
                        type="number"
                        value={rampUp}
                        onChange={(e) => setRampUp(e.target.value)}
                        min={0}
                        max={86400}
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Duration (s)</Label>
                      <Input
                        type="number"
                        value={duration}
                        onChange={(e) => setDuration(e.target.value)}
                        min={0}
                        max={86400}
                      />
                    </div>
                  </div>
                </div>
              )}
            </>
          )}

          <Button
            className="w-full"
            disabled={!file || uploadMutation.isPending}
            onClick={() => uploadMutation.mutate()}
          >
            {uploadMutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                {isJmxFile ? "Analyzing..." : "Converting..."}
              </>
            ) : (
              <>
                {isJmxFile ? <FileCode className="h-4 w-4 mr-2" /> : <Wand2 className="h-4 w-4 mr-2" />}
                {isJmxFile ? "Analyze JMX Script" : "Convert to JMeter Script"}
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function ResultsPhase({ generationId, onReset, onSaved }: { generationId: number; onReset: () => void; onSaved: (scriptId: number) => void }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [saveName, setSaveName] = useState("");
  const [saveDescription, setSaveDescription] = useState("");
  const [jmxPreview, setJmxPreview] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("correlations");

  const { data: generation, isLoading } = useQuery<Generation>({
    queryKey: [`/api/har-converter/generations/${generationId}`],
    queryFn: async () => {
      const res = await fetch(`/api/har-converter/generations/${generationId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch generation");
      return res.json();
    },
    refetchInterval: (query) => {
      const data = query.state.data;
      if (data && data.status !== "processing") return false;
      return 2000;
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/har-converter/generations/${generationId}/save-as-script`, {
        name: saveName || generation?.name,
        description: saveDescription,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setSaveDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: [`/api/har-converter/generations/${generationId}`] });
      toast({ title: "Script Saved", description: "JMeter script has been saved to the repository" });
      onSaved(data.scriptId);
    },
    onError: (err: Error) => {
      toast({ title: "Save Failed", description: err.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/har-converter/generations/${generationId}`);
    },
    onSuccess: () => {
      toast({ title: "Deleted", description: "Generation has been removed" });
      onReset();
    },
  });

  const handleDownloadJmx = () => {
    window.open(`/api/har-converter/generations/${generationId}/download`, "_blank");
  };

  const handleDownloadCsv = () => {
    window.open(`/api/har-converter/generations/${generationId}/download-csv`, "_blank");
  };

  const loadJmxPreview = async () => {
    if (jmxPreview !== null) return;
    try {
      const res = await fetch(`/api/har-converter/generations/${generationId}/download`, { credentials: "include" });
      if (res.ok) {
        const text = await res.text();
        setJmxPreview(text.length > 100000 ? text.substring(0, 100000) + "\n\n... (truncated)" : text);
      }
    } catch {}
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!generation) {
    return (
      <div className="text-center py-20">
        <XCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
        <p className="text-muted-foreground">Generation not found</p>
        <Button variant="outline" className="mt-4" onClick={onReset}>Start Over</Button>
      </div>
    );
  }

  if (generation.status === "processing") {
    const isJmx = generation.inputType === "jmx";
    return (
      <div className="max-w-lg mx-auto text-center py-20 space-y-4">
        <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
        <h3 className="text-xl font-semibold text-foreground">{isJmx ? "Analyzing JMX file..." : "Converting HAR file..."}</h3>
        <p className="text-muted-foreground">{isJmx ? "Scanning extractors, correlations, parameterizations, and best practices" : "Parsing requests, detecting correlations, generating JMX script"}</p>
        <p className="text-muted-foreground/70 text-sm">This usually takes a few seconds</p>
      </div>
    );
  }

  if (generation.status === "failed") {
    return (
      <div className="max-w-lg mx-auto text-center py-20 space-y-4">
        <XCircle className="h-12 w-12 text-destructive mx-auto" />
        <h3 className="text-xl font-semibold text-foreground">Conversion Failed</h3>
        <p className="text-muted-foreground">{generation.errorMessage || "An unexpected error occurred"}</p>
        <div className="flex gap-3 justify-center">
          <Button variant="outline" onClick={onReset}>
            <RotateCcw className="h-4 w-4 mr-2" />
            Try Again
          </Button>
          <Button variant="ghost" className="text-destructive" onClick={() => deleteMutation.mutate()}>
            <Trash2 className="h-4 w-4 mr-2" />
            Delete
          </Button>
        </div>
      </div>
    );
  }

  const stats = generation.stats || {};
  const correlations = generation.correlations || [];
  const parameterizations = generation.parameterizations || [];
  const issues = generation.issues || [];
  const score = generation.qualityScore || 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onReset}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h2 className="text-xl font-bold text-foreground">{generation.name}</h2>
            <p className="text-muted-foreground text-sm">
              {generation.inputFileName} ({formatBytes(generation.inputFileSize || 0)})
            </p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          {generation.scriptId ? (
            <Badge className="bg-emerald-100 text-emerald-700 border-emerald-300">
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Saved as Script #{generation.scriptId}
            </Badge>
          ) : (
            <Button
              onClick={() => { setSaveName(generation.name); setSaveDialogOpen(true); }}
            >
              <Save className="h-4 w-4 mr-2" />
              Save as Script
            </Button>
          )}
          <Button variant="outline" onClick={handleDownloadJmx}>
            <Download className="h-4 w-4 mr-2" />
            Download JMX
          </Button>
          {generation.hasCsvContent && (
            <Button variant="outline" onClick={handleDownloadCsv}>
              <Download className="h-4 w-4 mr-2" />
              Download CSV
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className={`border ${getScoreBg(score)}`}>
          <CardContent className="pt-4 text-center">
            <div className={`text-4xl font-bold ${getScoreColor(score)}`}>{score}</div>
            <div className="text-muted-foreground text-sm mt-1">Quality Score</div>
            {generation.readinessLevel && (
              <Badge className={`mt-2 ${getReadinessBadge(generation.readinessLevel)}`}>
                {generation.readinessLevel}
              </Badge>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4 text-center">
            <div className="text-3xl font-bold text-foreground">{stats.requestCount || 0}</div>
            <div className="text-muted-foreground text-sm mt-1">API Requests</div>
            <div className="text-muted-foreground/70 text-xs mt-1">
              {generation.inputType === "jmx" ? "In JMX file" : `${stats.totalEntries || 0} total, ${(stats.totalEntries || 0) - (stats.filteredEntries || 0)} filtered`}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4 text-center">
            <div className="text-3xl font-bold text-foreground">{correlations.length}</div>
            <div className="text-muted-foreground text-sm mt-1">Correlations</div>
            <div className="text-muted-foreground/70 text-xs mt-1">Auto-detected</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4 text-center">
            <div className="text-3xl font-bold text-foreground">{stats.transactionGroups || 0}</div>
            <div className="text-muted-foreground text-sm mt-1">Transaction Groups</div>
            <div className="text-muted-foreground/70 text-xs mt-1">
              {(stats.domains || []).length} domain{(stats.domains || []).length !== 1 ? "s" : ""}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="correlations" className="gap-1.5">
            <Link2 className="h-3.5 w-3.5" />
            Correlations ({correlations.length})
          </TabsTrigger>
          <TabsTrigger value="parameterizations" className="gap-1.5">
            <Shield className="h-3.5 w-3.5" />
            Parameterizations ({parameterizations.length})
          </TabsTrigger>
          <TabsTrigger value="issues" className="gap-1.5">
            <AlertTriangle className="h-3.5 w-3.5" />
            Issues ({issues.length})
          </TabsTrigger>
          <TabsTrigger value="preview" className="gap-1.5" onClick={loadJmxPreview}>
            <Code className="h-3.5 w-3.5" />
            JMX Preview
          </TabsTrigger>
        </TabsList>

        <TabsContent value="correlations">
          <Card>
            <CardContent className="pt-4">
              {correlations.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Info className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No {generation.inputType === "jmx" ? "extractors or hardcoded dynamic values" : "dynamic values"} detected for correlation</p>
                  <p className="text-sm mt-1 opacity-70">{generation.inputType === "jmx" ? "The JMX file does not contain extractors, and no repeated dynamic values (tokens, UUIDs) were found across requests" : "The HAR may not contain response bodies, or the application may not use dynamic tokens"}</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {(() => {
                    const FRAMEWORK_VARS: Record<string, string> = {
                      viewState: "ASP.NET", viewStateGenerator: "ASP.NET", eventValidation: "ASP.NET",
                      requestVerificationToken: "ASP.NET", previousPage: "ASP.NET", viewStateEncrypted: "ASP.NET",
                      eventTarget: "ASP.NET", eventArgument: "ASP.NET",
                      csrfMiddlewareToken: "Django", csrfToken_django: "Django",
                      authenticityToken: "Rails",
                      laravelToken: "Laravel", xsrfToken_laravel: "Laravel",
                      springCsrf: "Spring",
                      wpNonce: "WordPress", wpHttpReferer: "WordPress",
                      formBuildId: "Drupal", formToken: "Drupal", formId: "Drupal",
                      formKey: "Magento",
                      icsId: "PeopleSoft", icStateNum: "PeopleSoft", icActionPrompt: "PeopleSoft", icAction: "PeopleSoft",
                      sweCount: "Siebel", sweRowId: "Siebel", sweRowIds: "Siebel", sweFrameId: "Siebel", sweViewLayoutChecksum: "Siebel",
                      sysparmCk: "ServiceNow", sysparmTransactionScope: "ServiceNow", serviceNowUserToken: "ServiceNow",
                      jsfViewState: "JSF", jsfClientWindow: "JSF",
                      icxTicket: "Oracle EBS",
                      sfViewStateId: "Salesforce", sfViewStateVersion: "Salesforce", sfViewStateMAC: "Salesforce",
                      jSessionId: "Java", phpSessionId: "PHP", aspNetSessionId: "ASP.NET",
                      aspNetCoreAntiforgery: "ASP.NET Core", connectSid: "Express/Node.js",
                      laravelSession: "Laravel", railsSession: "Rails", djangoSessionId: "Django",
                      wpLoggedInCookie: "WordPress",
                    };
                    const detectedFrameworks = new Set<string>();
                    for (const c of correlations) {
                      const fw = FRAMEWORK_VARS[c.variable as string];
                      if (fw) detectedFrameworks.add(fw);
                    }
                    const hasFrameworkFields = detectedFrameworks.size > 0;
                    const hasNeedsCorrelation = correlations.some((c: any) => c.pattern?.startsWith("(needs correlation"));
                    const showBanner = (generation.inputType === "jmx" && hasNeedsCorrelation) || hasFrameworkFields;
                    if (!showBanner) return null;
                    const frameworkList = Array.from(detectedFrameworks).join(", ");
                    return (
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-amber-50 border border-amber-200">
                        <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
                        <div>
                          <p className="text-foreground text-sm font-medium">
                            {hasFrameworkFields
                              ? `${frameworkList} Application Detected`
                              : "Recorded Script Detected"
                            }
                          </p>
                          <p className="text-muted-foreground text-xs mt-1">
                            {hasFrameworkFields
                              ? `${generation.inputType === "har" ? "This HAR capture is from" : "This is a recorded script from"} a ${frameworkList} application. The correlations below include framework-specific dynamic fields (CSRF tokens, session state, view state, etc.) that change on every server response. These MUST be correlated using extractors before running a load test.`
                              : "The values below are hardcoded dynamic values (tokens, UUIDs, session IDs) found repeated across multiple requests. These need to be correlated using Regular Expression or JSON extractors in JMeter before running a load test."
                            }
                          </p>
                        </div>
                      </div>
                    );
                  })()}
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b text-muted-foreground">
                          <th className="text-left py-2 px-3">Variable</th>
                          <th className="text-left py-2 px-3">Type</th>
                          <th className="text-left py-2 px-3">Source Request</th>
                          <th className="text-left py-2 px-3">Target Requests</th>
                          <th className="text-left py-2 px-3">{correlations.some((c: any) => c.originalValue) ? "Hardcoded Value" : "Pattern"}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {correlations.map((c: any, i: number) => (
                          <tr key={i} className="border-b text-foreground">
                            <td className="py-2 px-3">
                              <code className="text-primary bg-primary/10 px-1.5 py-0.5 rounded text-xs">${`{${c.variable}}`}</code>
                            </td>
                            <td className="py-2 px-3">
                              <Badge variant="outline" className="text-xs">
                                {c.extractorType}
                              </Badge>
                            </td>
                            <td className="py-2 px-3 text-xs font-mono max-w-[200px] truncate">{c.sourceRequest}</td>
                            <td className="py-2 px-3">
                              <div className="flex flex-wrap gap-1">
                                {(c.targetRequests || []).slice(0, 3).map((t: string, j: number) => (
                                  <span key={j} className="text-xs font-mono bg-muted px-1.5 py-0.5 rounded truncate max-w-[150px] block">{t}</span>
                                ))}
                                {(c.targetRequests || []).length > 3 && (
                                  <span className="text-xs text-muted-foreground">+{c.targetRequests.length - 3} more</span>
                                )}
                              </div>
                          </td>
                          <td className="py-2 px-3 text-xs font-mono max-w-[200px] truncate text-muted-foreground">{c.originalValue || c.pattern}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="parameterizations">
          <Card>
            <CardContent className="pt-4">
              {parameterizations.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Info className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No credentials or repeated values detected</p>
                  <p className="text-sm mt-1 opacity-70">You can manually add CSV Data Set Config in JMeter if needed</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b text-muted-foreground">
                          <th className="text-left py-2 px-3">Variable</th>
                          <th className="text-left py-2 px-3">Original Value</th>
                          <th className="text-left py-2 px-3">Occurrences</th>
                        </tr>
                      </thead>
                      <tbody>
                        {parameterizations.map((p: any, i: number) => (
                          <tr key={i} className="border-b text-foreground">
                            <td className="py-2 px-3">
                              <code className="text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded text-xs">${`{${p.variable}}`}</code>
                            </td>
                            <td className="py-2 px-3 text-muted-foreground">{p.originalValue}</td>
                            <td className="py-2 px-3">
                              <div className="flex flex-wrap gap-1">
                                {(p.occurrences || []).map((o: any, j: number) => (
                                  <Badge key={j} variant="outline" className="text-xs">
                                    {o.location}: {o.fieldName}
                                  </Badge>
                                ))}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {generation.hasCsvContent && (
                    <div className="bg-muted/50 rounded-lg p-3 border">
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="text-foreground text-sm font-medium">Sample CSV Generated</span>
                      </div>
                      <p className="text-muted-foreground text-xs">A sample CSV file with placeholder data has been generated. Download it and replace with real test data.</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="issues">
          <Card>
            <CardContent className="pt-4">
              {issues.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle2 className="h-8 w-8 mx-auto mb-2 text-emerald-500 opacity-50" />
                  <p>No issues detected</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {issues.map((issue: any, i: number) => (
                    <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 border">
                      {issue.severity === "warning" ? (
                        <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
                      ) : (
                        <Info className="h-4 w-4 text-blue-500 mt-0.5 shrink-0" />
                      )}
                      <div>
                        <p className="text-foreground text-sm">{issue.message}</p>
                        {issue.request && (
                          <p className="text-muted-foreground text-xs mt-1 font-mono">{issue.request}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview">
          <Card>
            <CardContent className="pt-4">
              {jmxPreview === null ? (
                <div className="text-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto mb-2" />
                  <p className="text-muted-foreground text-sm">Loading JMX preview...</p>
                </div>
              ) : (
                <pre className="text-xs text-foreground font-mono bg-muted/50 rounded-lg p-4 overflow-auto max-h-[600px] whitespace-pre border">
                  {jmxPreview}
                </pre>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save as Script</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Script Name</Label>
              <Input
                value={saveName}
                onChange={(e) => setSaveName(e.target.value)}
              />
            </div>
            <div>
              <Label>Description (optional)</Label>
              <Textarea
                value={saveDescription}
                onChange={(e) => setSaveDescription(e.target.value)}
                placeholder="Describe the test scenario..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setSaveDialogOpen(false)}>Cancel</Button>
            <Button
              onClick={() => saveMutation.mutate()}
              disabled={saveMutation.isPending}
            >
              {saveMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Script
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function HistoryList({ onSelect }: { onSelect: (id: number) => void }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const { data: generations, isLoading } = useQuery<Generation[]>({
    queryKey: ["/api/har-converter/generations"],
    queryFn: async () => {
      const res = await fetch("/api/har-converter/generations", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch generations");
      return res.json();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/har-converter/generations/${id}`, {
        method: "DELETE",
        credentials: "include",
        headers: { "X-Requested-With": "XMLHttpRequest" },
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Delete failed" }));
        throw new Error(err.message || "Delete failed");
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/har-converter/generations"] });
      toast({ title: "Deleted", description: "Conversion deleted successfully" });
      setDeleteId(null);
    },
    onError: (err: Error) => {
      toast({ title: "Delete Failed", description: err.message, variant: "destructive" });
      setDeleteId(null);
    },
  });

  if (isLoading) return null;
  if (!generations?.length) return null;

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-muted-foreground">Recent Conversions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1">
            {generations.slice(0, 10).map((g) => (
              <div
                key={g.id}
                className="flex items-center justify-between p-2.5 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors group"
                onClick={() => onSelect(g.id)}
              >
                <div className="flex items-center gap-3">
                  <FileCode className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-foreground">{g.name}</p>
                      <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${g.inputType === "jmx" ? "text-blue-600 border-blue-300" : "text-amber-600 border-amber-300"}`}>
                        {g.inputType === "jmx" ? "JMX" : "HAR"}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {new Date(g.createdAt).toLocaleDateString()} - {g.inputFileName}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {g.status === "completed" && g.qualityScore !== null && (
                    <span className={`text-sm font-medium ${getScoreColor(g.qualityScore)}`}>
                      {g.qualityScore}
                    </span>
                  )}
                  <Badge variant="outline" className={
                    g.status === "completed" ? "text-emerald-600 border-emerald-300" :
                    g.status === "failed" ? "text-destructive border-destructive/30" :
                    "text-amber-600 border-amber-300"
                  }>
                    {g.status}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeleteId(g.id);
                    }}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Dialog open={deleteId !== null} onOpenChange={(open) => { if (!open) setDeleteId(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Conversion</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Are you sure you want to delete this conversion? The generated JMX and CSV files will be permanently removed.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button
              variant="destructive"
              disabled={deleteMutation.isPending}
              onClick={() => { if (deleteId) deleteMutation.mutate(deleteId); }}
            >
              {deleteMutation.isPending ? (
                <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Deleting...</>
              ) : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default function HarConverterPage() {
  const [, navigate] = useLocation();
  const [phase, setPhase] = useState<"upload" | "results">("upload");
  const [generationId, setGenerationId] = useState<number | null>(null);

  const handleUploaded = (id: number) => {
    setGenerationId(id);
    setPhase("results");
  };

  const handleReset = () => {
    setPhase("upload");
    setGenerationId(null);
  };

  const handleSaved = (scriptId: number) => {
    navigate(`/scripts/${scriptId}`);
  };

  const handleSelectHistory = (id: number) => {
    setGenerationId(id);
    setPhase("results");
  };

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="Script Converter & Analyzer"
        subtitle="Convert HAR recordings to JMeter scripts, or analyze existing JMX files for quality and best practices"
      />
      {phase === "upload" && (
        <>
          <UploadPhase onUploaded={handleUploaded} />
          <div className="max-w-2xl mx-auto">
            <HistoryList onSelect={handleSelectHistory} />
          </div>
        </>
      )}
      {phase === "results" && generationId && (
        <ResultsPhase
          generationId={generationId}
          onReset={handleReset}
          onSaved={handleSaved}
        />
      )}
    </div>
  );
}
