import { useScript, useUploadScriptFile } from "@/hooks/use-scripts";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Upload, FileCode, Clock, User, File, Target, Activity, Plus, Trash2, AlertTriangle, CheckCircle, Code2, Package, Settings2, Database, FileText } from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryKeys } from "@/lib/query-keys";
import { QueryErrorFallback } from "@/components/error-boundary";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { PageHeader } from "@/components/page-header";
import { ScriptEditor } from "@/components/script-editor";
import { QuickConfig } from "@/components/quick-config";
import { AutoAbortRulesSection } from "@/components/auto-abort-rules";
import { useAuth } from "@/hooks/use-auth";

export default function ScriptDetail() {
  const { canWrite } = useAuth();
  const [, params] = useRoute("/scripts/:id");
  const scriptId = parseInt(params?.id || "0");
  const { data: script, isLoading, isError, error, refetch } = useScript(scriptId);
  const [editorOpen, setEditorOpen] = useState(false);

  if (isLoading) return <DetailSkeleton />;
  if (isError) return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load script" />;
  if (!script) return <div className="p-8">Script not found</div>;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <PageHeader
        title={script.name}
        subtitle={`${script.toolType} • ${script.description || "No description"}`}
        actions={
          <>
            {canWrite && script.filePath && (
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Settings2 className="w-4 h-4 mr-1.5" />
                    Test Config
                  </Button>
                </SheetTrigger>
                <SheetContent className="w-[480px] sm:w-[540px] overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle className="flex items-center gap-2">
                      <Settings2 className="w-5 h-5 text-primary" />
                      Test Configuration
                    </SheetTitle>
                  </SheetHeader>
                  <div className="mt-4">
                    <QuickConfig scriptId={scriptId} hasFile={!!script.filePath} embedded />
                  </div>
                </SheetContent>
              </Sheet>
            )}
            {canWrite && <UploadFileDialog scriptId={scriptId} />}
          </>
        }
      />

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3" style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both' }}>
        <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500/10 to-blue-600/5 border border-blue-500/15">
          <div className="text-[10px] uppercase tracking-wider font-bold text-blue-500/70">Tool</div>
          <div className="text-sm font-bold mt-1">{script.toolType}</div>
        </div>
        <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border border-emerald-500/15">
          <div className="text-[10px] uppercase tracking-wider font-bold text-emerald-500/70">Status</div>
          <div className="text-sm font-bold mt-1 flex items-center gap-1.5">
            {script.filePath ? (
              <><CheckCircle className="w-3.5 h-3.5 text-emerald-500" /> File uploaded</>
            ) : (
              <><AlertTriangle className="w-3.5 h-3.5 text-amber-500" /> No file</>
            )}
          </div>
        </div>
        <div className="p-3 rounded-xl bg-gradient-to-br from-violet-500/10 to-violet-600/5 border border-violet-500/15">
          <div className="text-[10px] uppercase tracking-wider font-bold text-violet-500/70">Created</div>
          <div className="text-sm font-bold mt-1">{script.createdAt ? format(new Date(script.createdAt), "MMM d, yyyy") : "-"}</div>
        </div>
        <div className="p-3 rounded-xl bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/15">
          <div className="text-[10px] uppercase tracking-wider font-bold text-amber-500/70">Dependencies</div>
          <div className="text-sm font-bold mt-1">{(script.dependencyFiles?.length || 0) + (script.jarFiles?.length || 0)} files</div>
        </div>
      </div>

      {script.filePath && <PluginCheck scriptId={scriptId} />}

      <div className="grid gap-5">
        <Card className="overflow-hidden border-0 shadow-lg" style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: '50ms' }}>
          <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5 border-b">
            <CardTitle className="flex items-center gap-2 text-base">
              <FileCode className="w-5 h-5 text-primary" />
              Script File
            </CardTitle>
          </CardHeader>
          <CardContent className="p-5">
            {script.filePath ? (
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 rounded-xl bg-muted/20 border border-border/50 hover:border-primary/20 transition-colors">
                <div className="p-3 bg-primary/10 text-primary rounded-xl">
                  <File className="w-7 h-7" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-base truncate">{script.filePath.split('/').pop()}</div>
                  <div className="text-sm text-muted-foreground flex flex-wrap items-center gap-3 mt-1.5">
                    {script.uploadedBy && (
                      <span className="flex items-center gap-1.5 text-xs">
                        <User className="w-3 h-3" />
                        User {script.uploadedBy}
                      </span>
                    )}
                    {script.createdAt && (
                      <span className="flex items-center gap-1.5 text-xs">
                        <Clock className="w-3 h-3" />
                        {format(new Date(script.createdAt), "PP p")}
                      </span>
                    )}
                  </div>
                </div>
                <Button onClick={() => setEditorOpen(true)} className="shadow-md hover:shadow-lg transition-shadow shrink-0">
                  <Code2 className="w-4 h-4 mr-1.5" />
                  View / Edit Script
                </Button>
              </div>
            ) : (
              <div className="text-center py-10 text-muted-foreground">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-muted/50 flex items-center justify-center">
                  <FileCode className="w-8 h-8 opacity-40" />
                </div>
                <p className="font-medium">No script file uploaded yet</p>
                <p className="text-sm mt-1">Click "Upload File" above to add one.</p>
              </div>
            )}
          </CardContent>
        </Card>

        <div style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: '100ms' }}>
          <DependenciesSection scriptId={scriptId} script={script} canWrite={canWrite} />
        </div>
        
        <div style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: '150ms' }}>
          <JarsSection scriptId={scriptId} script={script} canWrite={canWrite} />
        </div>
        
        <div style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: '200ms' }}>
          <BaselineSection scriptId={scriptId} canWrite={canWrite} />
        </div>

        <div style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: '250ms' }}>
          <RegressionThresholdsSection scriptId={scriptId} canWrite={canWrite} />
        </div>

        <div style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: '300ms' }}>
          <AutoAbortRulesSection scriptId={scriptId} canWrite={canWrite} />
        </div>

        <ScriptEditor scriptId={scriptId} open={editorOpen} onOpenChange={setEditorOpen} />
      </div>
    </div>
  );
}

interface BaselineData {
  baseline: {
    id: number;
    scriptId: number;
    executionId: number;
    createdAt: string;
    setBy: number;
    notes: string | null;
  };
  execution: {
    id: number;
    executionId: string;
    status: string;
    startTime: string;
    resultSummary: any;
  };
}

function BaselineSection({ scriptId, canWrite }: { scriptId: number; canWrite: boolean }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showSetDialog, setShowSetDialog] = useState(false);

  const { data: baselineData, isLoading } = useQuery<BaselineData | null>({
    queryKey: ["baseline", scriptId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/scripts/${scriptId}/baseline`);
      if (res.status === 404) return null;
      return res.json();
    },
  });

  const clearMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/scripts/${scriptId}/baseline`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["baseline", scriptId] });
      toast({ title: "Baseline cleared" });
    },
  });

  const summary = baselineData?.execution?.resultSummary;

  return (
    <Card className="overflow-hidden">
      <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-muted/30 border-b">
        <div>
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="w-5 h-5 text-primary" />
            Performance Baseline
          </CardTitle>
          <CardDescription>
            Compare future test runs against a reference execution
          </CardDescription>
        </div>
        {canWrite && (
          <div className="flex gap-2">
            <Dialog open={showSetDialog} onOpenChange={setShowSetDialog}>
              <DialogTrigger asChild>
                <Button size="sm" variant={baselineData ? "outline" : "default"}>
                  {baselineData ? "Change Baseline" : "Set Baseline"}
                </Button>
              </DialogTrigger>
              <SetBaselineDialog scriptId={scriptId} onClose={() => setShowSetDialog(false)} />
            </Dialog>
            {baselineData && (
              <Button size="sm" variant="ghost" onClick={() => clearMutation.mutate()}>
                Clear
              </Button>
            )}
          </div>
        )}
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-24 w-full" />
        ) : !baselineData ? (
          <div className="text-center py-8 text-muted-foreground">
            <Activity className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p>No baseline set.</p>
            <p className="text-sm">Future test runs will be compared against the baseline.</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-4 p-4 rounded-xl bg-muted/30 border border-border/50">
              <div className="p-3 bg-emerald-500/10 text-emerald-600 rounded-lg">
                <CheckCircle className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <div className="font-semibold">
                  Execution #{baselineData.execution.id}
                </div>
                <div className="text-sm text-muted-foreground">
                  Set on {baselineData.baseline.createdAt ? format(new Date(baselineData.baseline.createdAt), "PP p") : "Unknown"}
                  {baselineData.baseline.notes && ` • ${baselineData.baseline.notes}`}
                </div>
              </div>
              <Link href={`/executions/${baselineData.execution.id}`}>
                <Button variant="outline" size="sm">View Details</Button>
              </Link>
            </div>

            {summary && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500/10 to-blue-600/5 border border-blue-500/15">
                  <div className="text-[10px] uppercase tracking-wider font-bold text-blue-500/70">Avg Response</div>
                  <div className="text-xl font-bold mt-1">{Math.round(summary.avgResponseTime)}<span className="text-xs font-normal text-muted-foreground ml-0.5">ms</span></div>
                </div>
                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border border-emerald-500/15">
                  <div className="text-[10px] uppercase tracking-wider font-bold text-emerald-500/70">Throughput</div>
                  <div className="text-xl font-bold mt-1">{summary.throughput?.toFixed(1)}<span className="text-xs font-normal text-muted-foreground ml-0.5">/s</span></div>
                </div>
                <div className="p-3 rounded-xl bg-gradient-to-br from-violet-500/10 to-violet-600/5 border border-violet-500/15">
                  <div className="text-[10px] uppercase tracking-wider font-bold text-violet-500/70">P95 Latency</div>
                  <div className="text-xl font-bold mt-1">{Math.round(summary.p95 || 0)}<span className="text-xs font-normal text-muted-foreground ml-0.5">ms</span></div>
                </div>
                <div className="p-3 rounded-xl bg-gradient-to-br from-rose-500/10 to-rose-600/5 border border-rose-500/15">
                  <div className="text-[10px] uppercase tracking-wider font-bold text-rose-500/70">Error Rate</div>
                  <div className={`text-xl font-bold mt-1 ${(summary.errorRate * 100) > 0 ? 'text-rose-500' : ''}`}>{(summary.errorRate * 100).toFixed(2)}<span className="text-xs font-normal text-muted-foreground ml-0.5">%</span></div>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function SetBaselineDialog({ scriptId, onClose }: { scriptId: number; onClose: () => void }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedExecution, setSelectedExecution] = useState<string>("");
  const [notes, setNotes] = useState("");

  const { data: executionsResponse } = useQuery({
    queryKey: ["executions", { limit: 50 }],
    queryFn: () => apiRequest("GET", "/api/executions?limit=50").then(r => r.json()),
  });

  const executions = (executionsResponse?.data || []).filter(
    (e: any) => e.status === "completed" && e.schedule?.scriptId === scriptId
  );

  const mutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", `/api/scripts/${scriptId}/baseline`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["baseline", scriptId] });
      toast({ title: "Baseline set successfully" });
      onClose();
    },
    onError: () => {
      toast({ title: "Failed to set baseline", variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutation.mutate({
      executionId: parseInt(selectedExecution),
      notes: notes || undefined,
    });
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Set Performance Baseline</DialogTitle>
        <DialogDescription>
          Select a completed execution to use as the baseline for future comparisons.
        </DialogDescription>
      </DialogHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label>Execution</Label>
          <Select value={selectedExecution} onValueChange={setSelectedExecution}>
            <SelectTrigger>
              <SelectValue placeholder="Select an execution..." />
            </SelectTrigger>
            <SelectContent>
              {executions.map((exec: any) => (
                <SelectItem key={exec.id} value={exec.id.toString()}>
                  #{exec.id} - {exec.schedule?.name} ({format(new Date(exec.startTime), "PP")})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {executions.length === 0 && (
            <p className="text-xs text-muted-foreground">
              No completed executions for this script yet.
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label>Notes (optional)</Label>
          <Input
            placeholder="e.g. v2.1 release baseline"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>

        <DialogFooter>
          <Button type="submit" disabled={mutation.isPending || !selectedExecution}>
            {mutation.isPending ? "Setting..." : "Set as Baseline"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}

function UploadFileDialog({ scriptId }: { scriptId: number }) {
  const { mutate, isPending } = useUploadScriptFile();
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const fileContent = reader.result as string;
      mutate({
        scriptId,
        fileContent,
        fileName: file.name
      }, {
        onSuccess: () => {
          setOpen(false);
          setFile(null);
        }
      });
    };
    reader.readAsText(file);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
           <Upload className="w-4 h-4 mr-2" /> Upload File
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Upload Script File</DialogTitle>
          <DialogDescription>Upload or replace the script file.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid w-full max-w-sm items-center gap-1.5">
            <Label htmlFor="script-file">Script File</Label>
            <Input 
                id="script-file" 
                type="file" 
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                accept=".js,.ts,.jmx,.yaml,.yml,.json"
                required
            />
          </div>
          <DialogFooter>
             <Button type="submit" disabled={isPending || !file}>
                {isPending ? "Uploading..." : "Upload File"}
             </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function DependenciesSection({ scriptId, script, canWrite }: { scriptId: number; script: any; canWrite: boolean }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [files, setFiles] = useState<FileList | null>(null);
  const [uploading, setUploading] = useState(false);

  const deps = script.dependencyFiles || [];

  const uploadMutation = useMutation({
    mutationFn: async (filesToUpload: File[]) => {
      const filesData = await Promise.all(
        filesToUpload.map(async (f) => ({
          fileName: f.name,
          fileContent: await f.text(),
        }))
      );
      const res = await apiRequest("POST", `/api/scripts/${scriptId}/dependencies`, { files: filesData });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.scripts.detail(scriptId) });
      toast({ title: "Dependencies Uploaded", description: `${data.uploaded} file(s) added` });
      setFiles(null);
    },
    onError: (err: any) => {
      toast({ title: "Upload Failed", description: err.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (fileName: string) => {
      const res = await apiRequest("DELETE", `/api/scripts/${scriptId}/dependencies/${encodeURIComponent(fileName)}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.scripts.detail(scriptId) });
      toast({ title: "Dependency Deleted" });
    },
  });

  const handleUpload = async () => {
    if (!files || files.length === 0) return;
    setUploading(true);
    try {
      await uploadMutation.mutateAsync(Array.from(files));
    } finally {
      setUploading(false);
    }
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-muted/30 border-b">
        <CardTitle className="flex items-center justify-between text-base">
          <span className="flex items-center gap-2">
            <Database className="w-5 h-5 text-primary" />
            Test Dependencies
          </span>
          <Badge variant="outline" className="font-mono">{deps.length} file(s)</Badge>
        </CardTitle>
        <CardDescription>
          CSV, JSON, or other data files your JMeter script references
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {canWrite && (
          <div className="flex flex-col sm:flex-row gap-2 sm:items-end">
            <div className="flex-1">
              <Label htmlFor="dep-files">Add Dependency Files</Label>
              <Input
                id="dep-files"
                type="file"
                multiple
                accept=".csv,.json,.xml,.txt,.properties,.dat,.tsv"
                onChange={(e) => setFiles(e.target.files)}
              />
            </div>
            <Button onClick={handleUpload} disabled={uploading || !files?.length}>
              {uploading ? "Uploading..." : "Upload"}
            </Button>
          </div>
        )}

        {deps.length > 0 && (
          <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>File Name</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>Uploaded</TableHead>
                <TableHead className="w-16"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {deps.map((dep: any) => (
                <TableRow key={dep.originalName}>
                  <TableCell className="font-mono text-sm">{dep.originalName}</TableCell>
                  <TableCell>{(dep.size / 1024).toFixed(1)} KB</TableCell>
                  <TableCell>{dep.uploadedAt ? format(new Date(dep.uploadedAt), "PP") : "-"}</TableCell>
                  {canWrite && (
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteMutation.mutate(dep.originalName)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </div>
        )}

        {deps.length === 0 && (
          <div className="text-center py-6 text-muted-foreground">
            <p>No dependency files uploaded yet.</p>
            <p className="text-sm mt-1">Upload CSV, JSON, or other data files your script needs.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function JarsSection({ scriptId, script, canWrite }: { scriptId: number; script: any; canWrite: boolean }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [files, setFiles] = useState<FileList | null>(null);
  const [uploading, setUploading] = useState(false);

  const jars = script.jarFiles || [];

  const uploadMutation = useMutation({
    mutationFn: async (filesToUpload: File[]) => {
      const filesData = await Promise.all(
        filesToUpload.map(async (f) => {
          const arrayBuffer = await f.arrayBuffer();
          const base64 = btoa(
            new Uint8Array(arrayBuffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
          );
          return {
            fileName: f.name,
            fileContent: base64,
          };
        })
      );
      const res = await apiRequest("POST", `/api/scripts/${scriptId}/jars`, { files: filesData });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.scripts.detail(scriptId) });
      toast({ title: "JARs Uploaded", description: `${data.uploaded} file(s) added` });
      setFiles(null);
    },
    onError: (err: any) => {
      toast({ title: "Upload Failed", description: err.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (fileName: string) => {
      const res = await apiRequest("DELETE", `/api/scripts/${scriptId}/jars/${encodeURIComponent(fileName)}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.scripts.detail(scriptId) });
      toast({ title: "JAR Deleted" });
    },
  });

  const handleUpload = async () => {
    if (!files || files.length === 0) return;
    setUploading(true);
    try {
      await uploadMutation.mutateAsync(Array.from(files));
    } finally {
      setUploading(false);
    }
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-muted/30 border-b">
        <CardTitle className="flex items-center justify-between text-base">
          <span className="flex items-center gap-2">
            <Package className="w-5 h-5 text-primary" />
            JAR Dependencies
          </span>
          <Badge variant="outline" className="font-mono">{jars.length} file(s)</Badge>
        </CardTitle>
        <CardDescription>
          Plugins, JDBC drivers, custom samplers — added to JMeter's classpath at runtime
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {canWrite && (
          <div className="flex flex-col sm:flex-row gap-2 sm:items-end">
            <div className="flex-1">
              <Label htmlFor="jar-files">Add JAR Files</Label>
              <Input
                id="jar-files"
                type="file"
                multiple
                accept=".jar"
                onChange={(e) => setFiles(e.target.files)}
              />
            </div>
            <Button onClick={handleUpload} disabled={uploading || !files?.length}>
              {uploading ? "Uploading..." : "Upload"}
            </Button>
          </div>
        )}

        {jars.length > 0 && (
          <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>File Name</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>Uploaded</TableHead>
                <TableHead className="w-16"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {jars.map((jar: any) => (
                <TableRow key={jar.originalName}>
                  <TableCell className="font-mono text-sm">{jar.originalName}</TableCell>
                  <TableCell>{(jar.size / 1024).toFixed(1)} KB</TableCell>
                  <TableCell>{jar.uploadedAt ? format(new Date(jar.uploadedAt), "PP") : "-"}</TableCell>
                  {canWrite && (
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteMutation.mutate(jar.originalName)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </div>
        )}

        {jars.length === 0 && (
          <div className="text-center py-6 text-muted-foreground">
            <p>No JAR files uploaded yet.</p>
            <p className="text-sm mt-1">Upload JMeter plugins, JDBC drivers, or custom libraries.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function PluginCheck({ scriptId }: { scriptId: number }) {
  const { data, isLoading } = useQuery<{ plugins: any[]; hasPlugins: boolean }>({
    queryKey: [...queryKeys.scripts.pluginCheck(scriptId)],
    queryFn: () => apiRequest("GET", `/api/scripts/${scriptId}/plugin-check`).then(r => r.json()),
  });

  if (isLoading || !data?.hasPlugins) return null;

  return (
    <Card className="border-amber-500/30 bg-amber-500/5" style={{ animationName: 'fadeSlideIn', animationDuration: '0.35s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: '30ms' }}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-amber-500/15 rounded-lg mt-0.5">
            <Package className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-bold text-amber-600 dark:text-amber-400 mb-1">Plugin Dependencies Detected</h4>
            <p className="text-xs text-muted-foreground mb-3">This script uses third-party JMeter plugins. Ensure they are installed before running tests.</p>
            <div className="space-y-1.5">
              {data.plugins.map((p: any, i: number) => (
                <div key={i} className="flex items-center gap-2 text-xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                  <span className="font-semibold">{p.displayName}</span>
                  <span className="text-muted-foreground">({p.source})</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

const REGRESSION_METRICS = [
  { key: 'avgResponseTime', label: 'Avg Response Time', defaultWarning: 10, defaultCritical: 25 },
  { key: 'p90', label: 'P90 Response Time', defaultWarning: 10, defaultCritical: 25 },
  { key: 'p95', label: 'P95 Response Time', defaultWarning: 10, defaultCritical: 25 },
  { key: 'p99', label: 'P99 Response Time', defaultWarning: 15, defaultCritical: 30 },
  { key: 'throughput', label: 'Throughput', defaultWarning: 10, defaultCritical: 25 },
  { key: 'errorRate', label: 'Error Rate', defaultWarning: 20, defaultCritical: 50 },
];

function RegressionThresholdsSection({ scriptId, canWrite }: { scriptId: number; canWrite: boolean }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: thresholds, isLoading } = useQuery<any[]>({
    queryKey: ["regressionThresholds", scriptId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/scripts/${scriptId}/regression-thresholds`);
      return res.json();
    },
  });

  const upsertMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", `/api/scripts/${scriptId}/regression-thresholds`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["regressionThresholds", scriptId] });
      toast({ title: "Threshold saved" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/scripts/${scriptId}/regression-thresholds/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["regressionThresholds", scriptId] });
      toast({ title: "Threshold removed" });
    },
  });

  const getThreshold = (metric: string) => thresholds?.find((t: any) => t.metric === metric);

  const handleSave = (metric: string, warningPercent: number, criticalPercent: number, isEnabled: boolean) => {
    upsertMutation.mutate({ metric, warningPercent, criticalPercent, isEnabled });
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            Regression Thresholds
          </CardTitle>
          <Badge variant="outline" className="text-[10px]">
            {thresholds?.filter((t: any) => t.isEnabled).length || 0} active
          </Badge>
        </div>
        <CardDescription className="text-xs">
          Configure automatic regression detection thresholds. When a test result deviates from baseline beyond these percentages, it triggers a warning or critical alert.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : (
          <div className="space-y-1">
            <div className="grid grid-cols-[1fr_100px_100px_60px_40px] gap-2 px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground/70">
              <span>Metric</span>
              <span className="text-center">Warning %</span>
              <span className="text-center">Critical %</span>
              <span className="text-center">Active</span>
              <span />
            </div>
            {REGRESSION_METRICS.map((m) => {
              const t = getThreshold(m.key);
              return (
                <ThresholdRow
                  key={m.key}
                  metric={m}
                  threshold={t}
                  onSave={handleSave}
                  onDelete={(id: number) => deleteMutation.mutate(id)}
                  saving={upsertMutation.isPending}
                  canWrite={canWrite}
                />
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ThresholdRow({
  metric,
  threshold,
  onSave,
  onDelete,
  saving,
  canWrite,
}: {
  metric: { key: string; label: string; defaultWarning: number; defaultCritical: number };
  threshold: any;
  onSave: (metric: string, warning: number, critical: number, enabled: boolean) => void;
  onDelete: (id: number) => void;
  saving: boolean;
  canWrite: boolean;
}) {
  const [warning, setWarning] = useState(threshold?.warningPercent ?? metric.defaultWarning);
  const [critical, setCritical] = useState(threshold?.criticalPercent ?? metric.defaultCritical);
  const [enabled, setEnabled] = useState(threshold?.isEnabled ?? true);
  const [dirty, setDirty] = useState(false);

  const handleChange = (field: 'warning' | 'critical' | 'enabled', value: any) => {
    if (field === 'warning') setWarning(value);
    if (field === 'critical') setCritical(value);
    if (field === 'enabled') setEnabled(value);
    setDirty(true);
  };

  return (
    <div className="grid grid-cols-[1fr_100px_100px_60px_40px] gap-2 items-center px-3 py-2 rounded-lg hover:bg-muted/30 transition-colors">
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium">{metric.label}</span>
        {!threshold && (
          <span className="text-[10px] text-muted-foreground">(default)</span>
        )}
      </div>
      <Input
        type="number"
        min={1}
        max={200}
        value={warning}
        onChange={(e) => handleChange('warning', parseInt(e.target.value) || 0)}
        className="h-8 text-center text-sm"
      />
      <Input
        type="number"
        min={1}
        max={500}
        value={critical}
        onChange={(e) => handleChange('critical', parseInt(e.target.value) || 0)}
        className="h-8 text-center text-sm"
      />
      <div className="flex justify-center">
        <Switch
          checked={enabled}
          onCheckedChange={(v) => handleChange('enabled', v)}
        />
      </div>
      <div className="flex justify-center">
        {canWrite && dirty ? (
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 text-emerald-600"
            onClick={() => { onSave(metric.key, warning, critical, enabled); setDirty(false); }}
            disabled={saving}
          >
            <CheckCircle className="w-4 h-4" />
          </Button>
        ) : canWrite && threshold ? (
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 text-muted-foreground hover:text-red-500"
            onClick={() => onDelete(threshold.id)}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        ) : null}
      </div>
    </div>
  );
}

function DetailSkeleton() {
  return (
    <div className="space-y-6">
       <Skeleton className="h-12 w-1/3" />
       <Skeleton className="h-64 w-full rounded-xl" />
    </div>
  );
}
