import { useScripts, useScriptsPaginated, useCreateScript, useDeleteScript, useUploadScriptFile } from "@/hooks/use-scripts";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertScriptSchema } from "@shared/schema";
import { z } from "zod";
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Plus, Search, FileCode, ArrowRight, Star, Folder, FolderPlus, ChevronRight, Home, MoreVertical, FolderInput, Trash2, AlertTriangle, PlusCircle, Globe, Zap, GitBranch, Server, Radio, MessageSquare, Layers } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState, emptyStates } from "@/components/empty-state";
import { format } from "date-fns";
import { queryKeys } from "@/lib/query-keys";

type FolderType = {
  id: number;
  name: string;
  parentId: number | null;
  createdAt: string;
};

const formSchema = insertScriptSchema;

const PROTOCOL_CONFIG: Record<string, { icon: typeof Globe; label: string; color: string }> = {
  http: { icon: Globe, label: "HTTP", color: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400" },
  websocket: { icon: Zap, label: "WebSocket", color: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400" },
  graphql: { icon: GitBranch, label: "GraphQL", color: "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400" },
  grpc: { icon: Server, label: "gRPC", color: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" },
  mqtt: { icon: Radio, label: "MQTT", color: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400" },
  jms: { icon: MessageSquare, label: "JMS", color: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400" },
  mixed: { icon: Layers, label: "Mixed", color: "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400" },
};

function ProtocolBadge({ protocol }: { protocol?: string | null }) {
  const key = (protocol || "http").toLowerCase();
  const config = PROTOCOL_CONFIG[key] || PROTOCOL_CONFIG.http;
  const Icon = config.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
      <Icon className="w-3 h-3" />
      {config.label}
    </span>
  );
}

export { PROTOCOL_CONFIG, ProtocolBadge };

export default function ScriptRepository() {
  const queryClient = useQueryClient();
  const { canWrite } = useAuth();
  const deleteScript = useDeleteScript();
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [protocolFilter, setProtocolFilter] = useState<string>("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isFolderDialogOpen, setIsFolderDialogOpen] = useState(false);
  const [currentFolderId, setCurrentFolderId] = useState<number | null>(null);
  const [folderPath, setFolderPath] = useState<FolderType[]>([]);
  const [moveScriptId, setMoveScriptId] = useState<number | null>(null);
  const [isMoveDialogOpen, setIsMoveDialogOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 20;

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(searchTerm), 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const { data: paginatedResult, isLoading } = useScriptsPaginated({
    page: currentPage,
    pageSize: ITEMS_PER_PAGE,
    search: debouncedSearch || undefined,
    protocol: protocolFilter !== "all" ? protocolFilter : undefined,
    folderId: currentFolderId,
  });

  const scripts = paginatedResult?.data;
  const totalScripts = paginatedResult?.total || 0;

  const { data: folders = [] } = useQuery<FolderType[]>({
    queryKey: [...queryKeys.folders],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/folders");
      return res.json();
    }
  });

  const { data: favorites = [] } = useQuery<number[]>({
    queryKey: [...queryKeys.dashboard.favorites],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/favorites");
      return res.json();
    }
  });

  const createFolder = useMutation({
    mutationFn: async (name: string) => {
      return await apiRequest("POST", "/api/folders", { name, parentId: currentFolderId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.folders });
      setIsFolderDialogOpen(false);
    }
  });

  const deleteFolder = useMutation({
    mutationFn: async (folderId: number) => {
      await apiRequest("DELETE", `/api/folders/${folderId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.folders });
      queryClient.invalidateQueries({ queryKey: queryKeys.scripts.all });
    }
  });

  const moveScript = useMutation({
    mutationFn: async ({ scriptId, folderId }: { scriptId: number; folderId: number | null }) => {
      return await apiRequest("PATCH", `/api/scripts/${scriptId}`, { folderId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.scripts.all });
      setIsMoveDialogOpen(false);
      setMoveScriptId(null);
    }
  });

  const toggleFavorite = useMutation({
    mutationFn: async (scriptId: number) => {
      if (favorites.includes(scriptId)) {
        await apiRequest("DELETE", `/api/favorites/${scriptId}`);
      } else {
        await apiRequest("POST", "/api/favorites", { scriptId });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.favorites });
    }
  });

  const currentFolderChildren = folders.filter(f => f.parentId === currentFolderId);

  const totalPages = Math.ceil(totalScripts / ITEMS_PER_PAGE);
  const paginatedScripts = scripts;

  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch, currentFolderId, protocolFilter]);

  const filteredFolders = currentFolderChildren.filter(folder =>
    folder.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const navigateToFolder = (folder: FolderType | null) => {
    if (folder === null) {
      setCurrentFolderId(null);
      setFolderPath([]);
    } else {
      setCurrentFolderId(folder.id);
      const existingIndex = folderPath.findIndex(f => f.id === folder.id);
      if (existingIndex >= 0) {
        setFolderPath(folderPath.slice(0, existingIndex + 1));
      } else {
        setFolderPath([...folderPath, folder]);
      }
    }
  };

  const handleMoveScript = (scriptId: number) => {
    setMoveScriptId(scriptId);
    setIsMoveDialogOpen(true);
  };

  return (
    <div className="section-gap">
      <PageHeader
        title="Scripts"
        subtitle={`Manage and organize your performance test scripts${totalScripts > 0 ? ` · ${totalScripts} script${totalScripts !== 1 ? 's' : ''}` : ''}`}
        actions={
          canWrite ? (
            <>
              <Button variant="outline" size="sm" className="sm:size-default" onClick={() => setIsFolderDialogOpen(true)}>
                <FolderPlus className="w-4 h-4 mr-2" /> New Folder
              </Button>
              <CreateScriptDialog open={isDialogOpen} onOpenChange={setIsDialogOpen} folderId={currentFolderId} />
            </>
          ) : null
        }
      />

      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-7 px-2"
          onClick={() => navigateToFolder(null)}
        >
          <Home className="w-4 h-4" />
        </Button>
        {folderPath.map((folder, index) => (
          <div key={folder.id} className="flex items-center gap-1">
            <ChevronRight className="w-4 h-4" />
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-7 px-2"
              onClick={() => navigateToFolder(folder)}
            >
              {folder.name}
            </Button>
          </div>
        ))}
      </div>

      <div className="h-[2px] rounded-full bg-gradient-to-r from-primary/60 via-primary/20 to-transparent" style={{ backgroundSize: '200% 100%', animation: 'gradientShift 3s ease infinite' }} />

      <div className="flex items-center gap-4 bg-card p-4 rounded-xl shadow-sm" style={{ border: '1px solid transparent', backgroundClip: 'padding-box', boxShadow: '0 0 0 1px hsl(var(--primary) / 0.15), 0 1px 3px hsl(var(--primary) / 0.08)' }}>
        <Search className="text-primary/60 w-5 h-5" />
        <Input 
          placeholder="Search scripts and folders..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="border-none shadow-none focus-visible:ring-0 px-0 h-auto text-base flex-1"
          aria-label="Search scripts"
        />
        <Select value={protocolFilter} onValueChange={setProtocolFilter}>
          <SelectTrigger className="w-[140px] h-9">
            <SelectValue placeholder="Protocol" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Protocols</SelectItem>
            <SelectItem value="http">HTTP</SelectItem>
            <SelectItem value="websocket">WebSocket</SelectItem>
            <SelectItem value="graphql">GraphQL</SelectItem>
            <SelectItem value="grpc">gRPC</SelectItem>
            <SelectItem value="mqtt">MQTT</SelectItem>
            <SelectItem value="jms">JMS</SelectItem>
            <SelectItem value="mixed">Mixed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filteredFolders.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
          {filteredFolders.map((folder) => (
            <div
              key={folder.id}
              className="grid-card p-4 cursor-pointer group relative transition-shadow duration-200 hover:shadow-lg hover:shadow-primary/10"
              onClick={() => navigateToFolder(folder)}
            >
              <div className="flex flex-col items-center gap-2">
                <Folder className="w-10 h-10 sm:w-12 sm:h-12 text-amber-500" />
                <span className="font-medium text-xs sm:text-sm text-center truncate w-full">{folder.name}</span>
              </div>
              {canWrite && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                    <Button variant="ghost" size="icon" className="absolute top-2 right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Folder options">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <DropdownMenuItem onSelect={(e) => e.preventDefault()} onClick={(e) => e.stopPropagation()} className="text-destructive">
                          <Trash2 className="w-4 h-4 mr-2" /> Delete Folder
                        </DropdownMenuItem>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete this folder? Scripts inside will be moved to root.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteFolder.mutate(folder.id)}>
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="table-container overflow-x-auto">
        <Table aria-label="Scripts list">
          <TableHeader className="bg-muted/30">
            <TableRow>
              <TableHead className="min-w-[200px]">Name</TableHead>
              <TableHead>Protocol</TableHead>
              <TableHead>Tool Type</TableHead>
              <TableHead>Last Updated</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              [...Array(3)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell><div className="flex items-center gap-3"><Skeleton className="h-9 w-9 rounded-lg" /><div className="space-y-2"><Skeleton className="h-4 w-32" /><Skeleton className="h-3 w-48" /></div></div></TableCell>
                  <TableCell><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-24 rounded-md" /></TableCell>
                  <TableCell className="text-right"><div className="flex items-center justify-end gap-2"><Skeleton className="h-8 w-8 rounded-md" /><Skeleton className="h-8 w-8 rounded-md" /><Skeleton className="h-8 w-28 rounded-md" /></div></TableCell>
                </TableRow>
              ))
            ) : paginatedScripts?.length === 0 && filteredFolders.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="h-32 p-0"><EmptyState {...emptyStates.scripts} /></TableCell></TableRow>
            ) : (
              paginatedScripts?.map((script, index) => (
                <TableRow key={script.id} className="group hover:bg-muted/30 transition-colors" style={{ animationName: 'fadeSlideIn', animationDuration: '0.3s', animationTimingFunction: 'ease-out', animationFillMode: 'both', animationDelay: `${index * 40}ms` }}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-primary/10 text-primary rounded-lg">
                        <FileCode className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{script.name}</span>
                          {!script.filePath && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
                              <AlertTriangle className="w-3 h-3" /> No file
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground line-clamp-1">{script.description}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <ProtocolBadge protocol={(script as any).protocol} />
                  </TableCell>
                  <TableCell>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary text-secondary-foreground border border-border">
                      {script.toolType}
                    </span>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {script.createdAt ? format(new Date(script.createdAt), "MMM d, yyyy") : "-"}
                  </TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" asChild className="h-8">
                      <Link href={`/schedule?scriptId=${script.id}`}>
                        <PlusCircle className="w-3.5 h-3.5 mr-1.5" /> Schedule
                      </Link>
                    </Button>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => toggleFavorite.mutate(script.id)}
                        aria-label={favorites.includes(script.id) ? "Remove from favorites" : "Add to favorites"}
                      >
                        <Star className={`w-4 h-4 ${favorites.includes(script.id) ? 'text-amber-500 fill-amber-500' : 'text-muted-foreground'}`} />
                      </Button>
                      {canWrite && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Script options">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem onClick={() => handleMoveScript(script.id)}>
                              <FolderInput className="w-4 h-4 mr-2" /> Move to Folder
                            </DropdownMenuItem>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-destructive focus:text-destructive">
                                  <Trash2 className="w-4 h-4 mr-2" /> Delete Script
                                </DropdownMenuItem>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Are you sure you want to delete this script? This action cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => deleteScript.mutate(script.id)}>
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                      <Button variant="outline" size="sm" asChild className="h-8 text-primary border-primary/20 hover:bg-primary/10 hover:border-primary/40 transition-all">
                        <Link href={`/scripts/${script.id}`}>
                          View Details <ArrowRight className="ml-1.5 w-3.5 h-3.5" />
                        </Link>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
        {totalPages > 1 && (
          <div className="flex items-center justify-between pt-4 border-t border-border/50" aria-label="Pagination">
            <p className="text-sm text-muted-foreground">
              Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1}-{Math.min(currentPage * ITEMS_PER_PAGE, totalScripts)} of {totalScripts} scripts
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                Previous
              </Button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let pageNum: number;
                if (totalPages <= 5) {
                  pageNum = i + 1;
                } else if (currentPage <= 3) {
                  pageNum = i + 1;
                } else if (currentPage >= totalPages - 2) {
                  pageNum = totalPages - 4 + i;
                } else {
                  pageNum = currentPage - 2 + i;
                }
                return (
                  <Button
                    key={pageNum}
                    variant={currentPage === pageNum ? "default" : "outline"}
                    size="sm"
                    className="w-8 h-8 p-0"
                    onClick={() => setCurrentPage(pageNum)}
                  >
                    {pageNum}
                  </Button>
                );
              })}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </div>

      <Dialog open={isFolderDialogOpen} onOpenChange={setIsFolderDialogOpen}>
        <DialogContent className="sm:max-w-[350px]">
          <DialogHeader>
            <DialogTitle>Create New Folder</DialogTitle>
            <DialogDescription>Add a new folder to organize your scripts.</DialogDescription>
          </DialogHeader>
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const name = formData.get("folderName") as string;
            if (name) createFolder.mutate(name);
          }}>
            <div className="space-y-4 py-4">
              <Input name="folderName" placeholder="Folder name" autoFocus />
            </div>
            <DialogFooter>
              <Button type="submit" disabled={createFolder.isPending}>
                {createFolder.isPending ? "Creating..." : "Create Folder"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={isMoveDialogOpen} onOpenChange={setIsMoveDialogOpen}>
        <DialogContent className="sm:max-w-[350px]">
          <DialogHeader>
            <DialogTitle>Move Script to Folder</DialogTitle>
            <DialogDescription>Select a destination folder.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-4">
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={() => moveScriptId && moveScript.mutate({ scriptId: moveScriptId, folderId: null })}
            >
              <Home className="w-4 h-4 mr-2" /> Root (No Folder)
            </Button>
            {folders.map(folder => (
              <Button 
                key={folder.id}
                variant="outline" 
                className="w-full justify-start"
                onClick={() => moveScriptId && moveScript.mutate({ scriptId: moveScriptId, folderId: folder.id })}
              >
                <Folder className="w-4 h-4 mr-2" /> {folder.name}
              </Button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes gradientShift {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </div>
  );
}

type ProjectType = { id: number; name: string; description?: string | null; };

function CreateScriptDialog({ open, onOpenChange, folderId }: { open: boolean, onOpenChange: (open: boolean) => void, folderId: number | null }) {
  const queryClient = useQueryClient();
  const { mutate, isPending } = useCreateScript();
  const { mutateAsync: uploadFile, isPending: isUploading } = useUploadScriptFile();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedProjectId, setSelectedProjectId] = useState<string>("");
  const [newProjectName, setNewProjectName] = useState("");
  const [showNewProject, setShowNewProject] = useState(false);
  
  const { data: projects = [] } = useQuery<ProjectType[]>({
    queryKey: [...queryKeys.projects],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/projects");
      return res.json();
    }
  });

  const createProject = useMutation({
    mutationFn: async (name: string) => {
      const res = await apiRequest("POST", "/api/projects", { name });
      return res.json();
    },
    onSuccess: (newProject) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.projects });
      setSelectedProjectId(String(newProject.id));
      setNewProjectName("");
      setShowNewProject(false);
    }
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      toolType: "JMeter",
      folderId: folderId
    }
  });

  useEffect(() => {
    form.setValue('folderId', folderId);
  }, [folderId, form]);

  const onSubmit = async (data: z.infer<typeof formSchema>) => {
    try {
      const projectId = selectedProjectId ? Number(selectedProjectId) : null;
      const newScript = await new Promise<any>((resolve, reject) => {
        mutate({ ...data, folderId, projectId }, {
          onSuccess: resolve,
          onError: reject
        });
      });

      // If a file was selected, upload it to the newly uploaded script
      if (selectedFile && newScript?.id) {
        try {
          const fileContent = await selectedFile.text();
          await uploadFile({
            scriptId: newScript.id,
            fileContent,
            fileName: selectedFile.name
          });
        } catch (error) {
          console.error('Error uploading file:', error);
        }
      }
      
      // Close dialog and reset form after everything is done
      onOpenChange(false);
      form.reset();
      setSelectedFile(null);
    } catch (error) {
      console.error('Error uploading script:', error);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      // Auto-fill name if empty
      if (!form.getValues("name")) {
        const fileName = file.name.split('.').slice(0, -1).join('.') || file.name;
        form.setValue("name", fileName);
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button className="shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all">
          <Plus className="w-4 h-4 mr-2" /> Upload Script
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Upload Script</DialogTitle>
          <DialogDescription>Upload a performance test script to the repository.</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
            <div className="p-4 border-2 border-dashed rounded-lg bg-muted/30 flex flex-col items-center gap-2 cursor-pointer hover:bg-muted/50 transition-colors relative">
              <input
                type="file"
                className="absolute inset-0 opacity-0 cursor-pointer"
                onChange={handleFileChange}
                accept=".jmx,.js,.scala"
              />
              <Plus className="w-8 h-8 text-muted-foreground" />
              <div className="text-sm font-medium text-center">
                {selectedFile ? (
                  <span className="text-primary font-semibold">{selectedFile.name}</span>
                ) : (
                  "Click to upload script file (.jmx, .js, .scala)"
                )}
              </div>
              <p className="text-xs text-muted-foreground">or drag and drop</p>
            </div>

            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Script Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Checkout Flow" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="space-y-2">
              <FormLabel>Project (Optional)</FormLabel>
              {!showNewProject ? (
                <div className="flex gap-2">
                  <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select a project" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((p) => (
                        <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button type="button" variant="outline" size="icon" onClick={() => setShowNewProject(true)}>
                    <PlusCircle className="w-4 h-4" />
                  </Button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Input 
                    placeholder="New project name" 
                    value={newProjectName} 
                    onChange={(e) => setNewProjectName(e.target.value)} 
                    className="flex-1"
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    onClick={() => newProjectName && createProject.mutate(newProjectName)}
                    disabled={!newProjectName || createProject.isPending}
                  >
                    Add
                  </Button>
                  <Button type="button" variant="ghost" size="sm" onClick={() => setShowNewProject(false)}>
                    Cancel
                  </Button>
                </div>
              )}
            </div>

            <FormField
              control={form.control}
              name="toolType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tool Type</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a tool" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="JMeter">Apache JMeter</SelectItem>
                      <SelectItem value="LoadRunner">LoadRunner</SelectItem>
                      <SelectItem value="Gatling">Gatling</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="protocol"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Protocol</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value || "http"}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select protocol" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="http">HTTP</SelectItem>
                      <SelectItem value="websocket">WebSocket</SelectItem>
                      <SelectItem value="graphql">GraphQL</SelectItem>
                      <SelectItem value="grpc">gRPC</SelectItem>
                      <SelectItem value="mqtt">MQTT</SelectItem>
                      <SelectItem value="jms">JMS</SelectItem>
                      <SelectItem value="mixed">Mixed</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Input placeholder="Brief description of what this script tests" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="submit" disabled={isPending || isUploading}>
              {isPending ? "Uploading..." : isUploading ? "Uploading file..." : "Upload Script"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
