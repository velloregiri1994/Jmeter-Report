import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";

interface User {
  id: number;
  username: string;
  email: string | null;
  role: string;
  isApproved: boolean;
  createdAt: string;
}

interface AuthSession {
  user: User | null;
  isAuthenticated: boolean;
}

export function useAuth() {
  const queryClient = useQueryClient();

  const { data: session, isLoading } = useQuery<AuthSession>({
    queryKey: [...queryKeys.auth.session],
    queryFn: async () => {
      const res = await fetch("/api/auth/session", { credentials: "include" });
      if (!res.ok) return { user: null, isAuthenticated: false };
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
    retry: false,
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/auth/logout");
      return res.json();
    },
    onSuccess: () => {
      queryClient.setQueryData([...queryKeys.auth.session], { user: null, isAuthenticated: false });
      queryClient.invalidateQueries({ queryKey: queryKeys.auth.session });
    },
  });

  const role = session?.user?.role;
  return {
    user: session?.user || null,
    isAuthenticated: session?.isAuthenticated || false,
    isLoading,
    isAdmin: role === "admin",
    isLead: role === "lead",
    isViewer: role === "viewer",
    canWrite: role === "admin" || role === "engineer" || role === "lead" || role === "manager",
    logout: logoutMutation.mutate,
    isLoggingOut: logoutMutation.isPending,
  };
}
