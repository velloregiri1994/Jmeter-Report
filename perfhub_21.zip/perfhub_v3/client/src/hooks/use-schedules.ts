import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertTestSchedule } from "@shared/schema";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";

export function useSchedules() {
  return useQuery({
    queryKey: [...queryKeys.schedules.all],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/schedules");
      return res.json();
    },
  });
}

export function useSchedule(id: number) {
  return useQuery({
    queryKey: [...queryKeys.schedules.detail(id)],
    queryFn: async () => {
      const url = buildUrl(api.schedules.get.path, { id });
      const res = await apiRequest("GET", url);
      return api.schedules.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateSchedule() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/schedules", data);
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.schedules.all }),
  });
}

export function useUpdateSchedule() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<InsertTestSchedule>) => {
      const res = await apiRequest("PATCH", `/api/schedules/${id}`, updates);
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.schedules.all }),
  });
}

export function useQueueTest() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (scheduleId: number) => {
      const res = await apiRequest("POST", `/api/schedules/${scheduleId}/queue`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.schedules.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.executions.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.stats });
    },
  });
}
