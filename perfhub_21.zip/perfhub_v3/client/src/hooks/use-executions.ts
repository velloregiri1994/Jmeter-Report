import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertComment } from "@shared/schema";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";

export function useExecutions(params?: { status?: 'running' | 'completed' | 'failed'; limit?: number; page?: number; offset?: number; releaseTag?: string }) {
  const queryKey = [...queryKeys.executions.all, JSON.stringify(params)];
  
  return useQuery({
    queryKey,
    queryFn: async () => {
      let url = api.executions.list.path;
      const queryParams = new URLSearchParams();
      if (params?.status) queryParams.set("status", params.status);
      if (params?.limit) queryParams.set("limit", String(params.limit));
      if (params?.page) queryParams.set("page", String(params.page));
      if (params?.offset) queryParams.set("offset", String(params.offset));
      if (params?.releaseTag) queryParams.set("releaseTag", params.releaseTag);
      const queryString = queryParams.toString();
      if (queryString) url += `?${queryString}`;
      
      const res = await apiRequest("GET", url);
      return api.executions.list.responses[200].parse(await res.json());
    },
    refetchInterval: params?.status === 'running' ? 5000 : false,
    staleTime: params?.status === 'running' ? 4000 : 30000
  });
}

export function useExecution(id: number) {
  const query = useQuery({
    queryKey: [...queryKeys.executions.detail(id)],
    queryFn: async () => {
      const url = buildUrl(api.executions.get.path, { id });
      const res = await apiRequest("GET", url);
      return api.executions.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
    refetchInterval: (query) => {
      const status = query.state.data?.status;
      return (status === 'running' || status === 'queued' || status === 'parsing') ? 3000 : false;
    },
    refetchIntervalInBackground: true,
  });
  return query;
}

export function useAddComment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ executionId, ...data }: Omit<InsertComment, "userId"> & { executionId: number }) => {
      const url = buildUrl(api.comments.create.path, { executionId });
      const res = await apiRequest("POST", url, data);
      return api.comments.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.executions.detail(variables.executionId) });
    },
  });
}

export function useDashboardStats() {
    return useQuery({
        queryKey: [...queryKeys.dashboard.stats],
        queryFn: async () => {
            const res = await apiRequest("GET", api.dashboard.stats.path);
            return api.dashboard.stats.responses[200].parse(await res.json());
        },
        staleTime: 20000,
        refetchInterval: 30000,
    });
}
