import { useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { useExecutions } from "@/hooks/use-executions";
import { queryKeys } from "@/lib/query-keys";

export function useNotifications() {
  const queryClient = useQueryClient();
  const previousExecutionsRef = useRef<Map<number, string>>(new Map());
  const initializedRef = useRef(false);

  const { data: executionsResponse } = useExecutions({ limit: 20 });
  const executions = executionsResponse?.data || [];

  useEffect(() => {
    if (!executions || executions.length === 0) return;

    if (!initializedRef.current) {
      executions.forEach((exec) => {
        previousExecutionsRef.current.set(exec.id, exec.status);
      });
      initializedRef.current = true;
      return;
    }

    executions.forEach((exec) => {
      const previousStatus = previousExecutionsRef.current.get(exec.id);

      if (previousStatus && previousStatus !== exec.status) {
        if (exec.status === "completed") {
          const slaViolations = exec.slaViolations as Record<string, any> | null;
          const hasViolations = slaViolations && Object.keys(slaViolations).length > 0;
          
          if (hasViolations) {
            toast({
              title: "Test Completed with SLA Violations",
              description: `${exec.schedule?.name || "Test"} finished with SLA violation(s)`,
              variant: "destructive",
            });
          } else {
            toast({
              title: "Test Completed Successfully",
              description: `${exec.schedule?.name || "Test"} finished without issues`,
            });
          }
          queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.stats });
        } else if (exec.status === "failed") {
          toast({
            title: "Test Failed",
            description: `${exec.schedule?.name || "Test"} encountered an error`,
            variant: "destructive",
          });
        } else if (exec.status === "running" && previousStatus === "queued") {
          toast({
            title: "Test Started",
            description: `${exec.schedule?.name || "Test"} is now running`,
          });
        }
      }

      previousExecutionsRef.current.set(exec.id, exec.status);
    });
  }, [executions, queryClient]);
}
