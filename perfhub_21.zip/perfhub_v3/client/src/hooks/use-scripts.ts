import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertScript } from "@shared/routes";
import { queryKeys } from "@/lib/query-keys";
import { apiRequest } from "@/lib/queryClient";

export function useScripts() {
  return useQuery({
    queryKey: [...queryKeys.scripts.all],
    queryFn: async () => {
      const res = await apiRequest("GET", api.scripts.list.path);
      return api.scripts.list.responses[200].parse(await res.json());
    },
  });
}

export function useScriptsPaginated(params: { page: number; pageSize?: number; search?: string; protocol?: string; folderId?: number | null }) {
  return useQuery<{ data: any[]; total: number; page: number; pageSize: number }>({
    queryKey: [...queryKeys.scripts.all, "paginated", JSON.stringify(params)],
    queryFn: async () => {
      const qp = new URLSearchParams();
      qp.set("page", String(params.page));
      if (params.pageSize) qp.set("pageSize", String(params.pageSize));
      if (params.search) qp.set("search", params.search);
      if (params.protocol && params.protocol !== "all") qp.set("protocol", params.protocol);
      if (params.folderId !== undefined && params.folderId !== null) qp.set("folderId", String(params.folderId));
      if (params.folderId === null) qp.set("folderId", "null");
      const res = await apiRequest("GET", `${api.scripts.list.path}?${qp.toString()}`);
      return res.json();
    },
  });
}

export function useScript(id: number) {
  return useQuery({
    queryKey: [...queryKeys.scripts.detail(id)],
    queryFn: async () => {
      const url = buildUrl(api.scripts.get.path, { id });
      const res = await apiRequest("GET", url);
      return api.scripts.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateScript() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertScript) => {
      const res = await apiRequest("POST", api.scripts.create.path, data);
      return api.scripts.create.responses[201].parse(await res.json());
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: queryKeys.scripts.all });
    },
  });
}

export function useDeleteScript() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.scripts.delete.path, { id });
      await apiRequest("DELETE", url);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.scripts.all });
    },
  });
}

export function useUploadScriptFile() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ scriptId, fileContent, fileName }: { scriptId: number; fileContent: string; fileName: string }) => {
      const url = buildUrl(api.scripts.upload.path, { scriptId });
      const res = await apiRequest("POST", url, { fileContent, fileName });
      return api.scripts.upload.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.scripts.detail(variables.scriptId) });
      queryClient.invalidateQueries({ queryKey: queryKeys.scripts.all });
    },
  });
}
