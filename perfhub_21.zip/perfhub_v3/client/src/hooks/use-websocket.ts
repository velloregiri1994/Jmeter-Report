import { useEffect, useRef, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { queryKeys } from "@/lib/query-keys";

interface ExecutionUpdate {
  type: "execution_update";
  executionId: number;
  status: string;
  resultSummary?: any;
}

interface ScheduleUpdate {
  type: "schedule_update";
  scheduleId: number;
  status: string;
}

export interface SlaViolation {
  ruleId: number;
  metric: string;
  comparator: string;
  threshold: number;
  actualValue: number;
  transactionLabel: string | null;
}

export interface Anomaly {
  metricType: "response_time" | "error_rate" | "throughput";
  timestamp: number;
  severity: "warning" | "critical";
  value: number;
  rollingMean?: number;
  rollingMedian?: number;
  zScore: number;
  description: string;
  explanation?: string;
  confidence?: number;
}

export interface PerformanceInsight {
  type: string;
  severity: "warning" | "critical";
  title: string;
  description: string;
  startTimestamp: number;
  endTimestamp: number;
  evidence: {
    responseTime?: { value: number; baseline: number };
    errorRate?: { value: number; baseline: number };
    throughput?: { value: number; baseline: number };
    p95?: { value: number; baseline: number };
  };
}

export interface LiveMetricsSnapshot {
  summary: {
    throughput: number;
    avgResponseTime: number;
    p95: number;
    p99: number;
    errorRate: number;
    activeThreads: number;
    totalRequests: number;
    totalErrors: number;
    elapsedSeconds: number;
  };
  topErrors: Array<{
    label: string;
    errorRate: number;
    errorCount: number;
    totalCount: number;
    errorCodes: Array<{ code: string; count: number }>;
  }>;
  topSlow: Array<{
    label: string;
    avg: number;
    p95: number;
    p99: number;
    count: number;
  }>;
  allTransactions: Array<{
    label: string;
    count: number;
    errors: number;
    errorRate: number;
    avg: number;
    min: number;
    max: number;
    p50: number;
    p90: number;
    p95: number;
    p99: number;
    throughput: number;
  }>;
  series: Array<{
    t: number;
    throughput: number;
    avgRT: number;
    p50: number;
    p90: number;
    p95: number;
    p99: number;
    errorRate: number;
    errors: number;
    activeThreads: number;
  }>;
  slaViolations: SlaViolation[];
  anomalies?: Anomaly[];
  anomalySummary?: { total: number; warning: number; critical: number };
  insights?: PerformanceInsight[];
  insightSummary?: { total: number; warning: number; critical: number; byType: Record<string, number> };
  systemMetrics?: {
    latest: { ts: number; cpuPercent: number; memUsedMb: number; memTotalMb: number; memPercent: number; diskReadMbps: number; diskWriteMbps: number; jmeterCpuPercent: number | null; jmeterMemMb: number | null } | null;
    history: Array<{ ts: number; cpuPercent: number; memPercent: number; diskReadMbps: number; diskWriteMbps: number; jmeterCpuPercent: number | null }>;
  };
}

interface LiveMetricsUpdate {
  type: "live_metrics_update";
  executionId: number;
  runId: string;
  snapshot: LiveMetricsSnapshot;
}

type WsMessage = ExecutionUpdate | ScheduleUpdate | LiveMetricsUpdate;

interface UseWebSocketOptions {
  onExecutionUpdate?: (data: { executionId: number; status: string; resultSummary?: any }) => void;
  onScheduleUpdate?: (data: { scheduleId: number; status: string }) => void;
  onLiveMetrics?: (data: { executionId: number; snapshot: LiveMetricsSnapshot }) => void;
  onReconnect?: () => void;
  enabled?: boolean;
}

export function useWebSocket(options: UseWebSocketOptions = {}) {
  const { onExecutionUpdate, onScheduleUpdate, onLiveMetrics, onReconnect, enabled = true } = options;
  const wsRef = useRef<WebSocket | null>(null);
  const queryClient = useQueryClient();
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const hasConnectedBefore = useRef(false);
  const callbacksRef = useRef({ onExecutionUpdate, onScheduleUpdate, onLiveMetrics, onReconnect });
  
  useEffect(() => {
    callbacksRef.current = { onExecutionUpdate, onScheduleUpdate, onLiveMetrics, onReconnect };
  }, [onExecutionUpdate, onScheduleUpdate, onLiveMetrics, onReconnect]);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      const ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        console.log("[ws] Connected");
        if (hasConnectedBefore.current) {
          callbacksRef.current.onReconnect?.();
        }
        hasConnectedBefore.current = true;
      };

      ws.onmessage = (event) => {
        try {
          const message: WsMessage = JSON.parse(event.data);

          if (message.type === "execution_update") {
            queryClient.setQueryData(
              [...queryKeys.executions.detail(message.executionId)],
              (oldData: any) => {
                if (!oldData) return oldData;
                return {
                  ...oldData,
                  status: message.status,
                  resultSummary: message.resultSummary ?? oldData.resultSummary,
                };
              }
            );

            queryClient.invalidateQueries({ queryKey: queryKeys.executions.all });
            queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.stats });

            callbacksRef.current.onExecutionUpdate?.({
              executionId: message.executionId,
              status: message.status,
              resultSummary: message.resultSummary,
            });
          }

          if (message.type === "schedule_update") {
            queryClient.invalidateQueries({ queryKey: queryKeys.schedules.all });
            callbacksRef.current.onScheduleUpdate?.({
              scheduleId: message.scheduleId,
              status: message.status,
            });
          }

          if (message.type === "live_metrics_update") {
            callbacksRef.current.onLiveMetrics?.({
              executionId: message.executionId,
              snapshot: message.snapshot,
            });
          }
        } catch (err) {
          console.error("[ws] Failed to parse message:", err);
        }
      };

      ws.onclose = () => {
        console.log("[ws] Disconnected, reconnecting in 3s...");
        wsRef.current = null;
        reconnectTimeoutRef.current = setTimeout(connect, 3000);
      };

      ws.onerror = (err) => {
        console.error("[ws] Error:", err);
        ws.close();
      };

      wsRef.current = ws;
    } catch (err) {
      console.error("[ws] Failed to connect:", err);
      reconnectTimeoutRef.current = setTimeout(connect, 3000);
    }
  }, [queryClient]);

  useEffect(() => {
    if (!enabled) {
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      return;
    }

    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [connect, enabled]);

  return wsRef;
}
