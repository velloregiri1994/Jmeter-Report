import { Switch, Route, Redirect, useLocation } from "wouter";
import { lazy, Suspense } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { LayoutShell } from "@/components/layout-shell";
import { useNotifications } from "@/hooks/use-notifications";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/hooks/use-websocket";
import { Loader2 } from "lucide-react";
import { ErrorBoundary } from "@/components/error-boundary";

const LandingPage = lazy(() => import("@/pages/landing"));
const SetupWizard = lazy(() => import("@/pages/setup"));
const Dashboard = lazy(() => import("@/pages/dashboard"));
const ScriptRepository = lazy(() => import("@/pages/scripts/index"));
const ScriptDetail = lazy(() => import("@/pages/scripts/detail"));
const ExecutionsPage = lazy(() => import("@/pages/executions/index"));
const ExecutionDetail = lazy(() => import("@/pages/executions/detail"));
const SchedulePage = lazy(() => import("@/pages/schedule/index"));
const ComparisonPage = lazy(() => import("@/pages/comparison/index"));
const TrendsPage = lazy(() => import("@/pages/trends/index"));
const ReportsPage = lazy(() => import("@/pages/reports/index"));
const PlatformGeneralPage = lazy(() => import("@/pages/platform/general"));
const PlatformUsersPage = lazy(() => import("@/pages/platform/users"));
const PlatformDistributedPage = lazy(() => import("@/pages/platform/distributed"));
const PlatformRetentionPage = lazy(() => import("@/pages/platform/retention"));
const DumpsPage = lazy(() => import("@/pages/dumps/index"));
const DumpDetailPage = lazy(() => import("@/pages/dumps/[id]"));
const CompareDumpsPage = lazy(() => import("@/pages/dumps/compare"));
const TrackerPage = lazy(() => import("@/pages/tracker/index"));
const CalendarPage = lazy(() => import("@/pages/calendar/index"));
const NotificationsPage = lazy(() => import("@/pages/notifications/index"));
const CompletionReportsPage = lazy(() => import("@/pages/completion-reports/index"));
const CreateCompletionReportPage = lazy(() => import("@/pages/completion-reports/create"));
const CompletionReportDetail = lazy(() => import("@/pages/completion-reports/detail"));
const AuditLogPage = lazy(() => import("@/pages/platform/audit-log"));
const ConsoleLogsPage = lazy(() => import("@/pages/platform/console-logs"));
const CicdPage = lazy(() => import("@/pages/platform/cicd"));
const WebhooksPage = lazy(() => import("@/pages/platform/webhooks"));
const WorkloadModelPage = lazy(() => import("@/pages/workload-model/index"));
const ReportTemplateBuilder = lazy(() => import("@/pages/report-templates/builder"));
const HarConverterPage = lazy(() => import("@/pages/scripts/har-converter"));
const TestDataGeneratorPage = lazy(() => import("@/pages/test-data-generator/index"));

function NotificationProvider({ children }: { children: React.ReactNode }) {
  useNotifications();
  return <>{children}</>;
}

function WebSocketProvider({ children }: { children: React.ReactNode }) {
  useWebSocket();
  return <>{children}</>;
}

function LoadingScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="text-center">
        <Loader2 className="h-12 w-12 animate-spin text-purple-500 mx-auto mb-4" />
        <p className="text-slate-300">Loading PerfHub...</p>
      </div>
    </div>
  );
}

function PageLoader() {
  return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
    </div>
  );
}

function AuthenticatedRouter() {
  const [location] = useLocation();
  const routeBase = location.split('/').slice(0, 3).join('/');

  return (
    <LayoutShell>
      <ErrorBoundary key={routeBase}>
        <Suspense fallback={<PageLoader />}>
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/scripts" component={ScriptRepository} />
            <Route path="/scripts/:id" component={ScriptDetail} />
            <Route path="/schedule" component={SchedulePage} />
            <Route path="/calendar"><Redirect to="/schedule" /></Route>
            <Route path="/executions" component={ExecutionsPage} />
            <Route path="/executions/:id" component={ExecutionDetail} />
            <Route path="/reports" component={ReportsPage} />
            <Route path="/completion-reports/new" component={CreateCompletionReportPage} />
            <Route path="/completion-reports/:id" component={CompletionReportDetail} />
            <Route path="/completion-reports" component={CompletionReportsPage} />
            <Route path="/report-templates/new" component={ReportTemplateBuilder} />
            <Route path="/report-templates/:id" component={ReportTemplateBuilder} />
            <Route path="/tracker" component={TrackerPage} />
            <Route path="/workload-model" component={WorkloadModelPage} />
            <Route path="/har-converter" component={HarConverterPage} />
            <Route path="/test-data-generator" component={TestDataGeneratorPage} />
            <Route path="/comparison" component={ComparisonPage} />
            <Route path="/trends" component={TrendsPage} />
            <Route path="/dumps" component={DumpsPage} />
            <Route path="/dumps/compare" component={CompareDumpsPage} />
            <Route path="/dumps/:id" component={DumpDetailPage} />
            <Route path="/notifications" component={NotificationsPage} />
            <Route path="/platform/general" component={PlatformGeneralPage} />
            <Route path="/platform/users">{() => <AdminGuard><PlatformUsersPage /></AdminGuard>}</Route>
            <Route path="/platform/distributed" component={PlatformDistributedPage} />
            <Route path="/platform/retention">{() => <AdminGuard><PlatformRetentionPage /></AdminGuard>}</Route>
            <Route path="/platform/audit-log">{() => <AdminGuard><AuditLogPage /></AdminGuard>}</Route>
            <Route path="/platform/console-logs">{() => <AdminGuard><ConsoleLogsPage /></AdminGuard>}</Route>
            <Route path="/platform/cicd" component={CicdPage} />
            <Route path="/platform/webhooks" component={WebhooksPage} />
            <Route path="/admin"><Redirect to="/platform/general" /></Route>
            <Route path="/admin/settings"><Redirect to="/platform/general" /></Route>
            <Route path="/admin/users"><Redirect to="/platform/users" /></Route>
            <Route path="/admin/retention"><Redirect to="/platform/retention" /></Route>
            <Route path="/admin/distributed-testing"><Redirect to="/platform/distributed" /></Route>
            <Route path="/admin/remote-ingest"><Redirect to="/platform/distributed" /></Route>
            <Route component={NotFound} />
          </Switch>
        </Suspense>
      </ErrorBoundary>
    </LayoutShell>
  );
}

function AdminGuard({ children }: { children: React.ReactNode }) {
  const { isAdmin } = useAuth();
  if (!isAdmin) return <NotFound />;
  return <>{children}</>;
}

function AppRouter() {
  const { isAuthenticated, isLoading } = useAuth();
  const { data: setupStatus, isLoading: setupLoading } = useQuery({
    queryKey: ["/api/setup/status"],
    queryFn: async () => {
      const res = await fetch("/api/setup/status");
      return res.json();
    },
    staleTime: 30000,
  });

  if (isLoading || setupLoading) {
    return <LoadingScreen />;
  }

  if (setupStatus?.needsSetup && !isAuthenticated) {
    return (
      <Suspense fallback={<LoadingScreen />}>
        <SetupWizard />
      </Suspense>
    );
  }

  if (!isAuthenticated) {
    return (
      <Suspense fallback={<LoadingScreen />}>
        <LandingPage />
      </Suspense>
    );
  }

  return (
    <NotificationProvider>
      <WebSocketProvider>
        <AuthenticatedRouter />
      </WebSocketProvider>
    </NotificationProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppRouter />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
