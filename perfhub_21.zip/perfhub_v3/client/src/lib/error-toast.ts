import { toast } from "@/hooks/use-toast";
import { ApiError, type ErrorSeverity } from "@/lib/queryClient";

const severityVariant: Record<ErrorSeverity, "default" | "destructive"> = {
  info: "default",
  warning: "default",
  error: "destructive",
  critical: "destructive",
};

const actionLabels: Record<string, string> = {
  retry: "Please try again.",
  contact_admin: "Contact your administrator for assistance.",
  check_config: "Check your input and try again.",
  login: "Please sign in to continue.",
  check_permissions: "You don't have permission. Contact an admin.",
  go_back: "The requested resource was not found.",
  refresh: "Try refreshing the page.",
};

export function showErrorToast(error: unknown, fallbackTitle?: string) {
  if (error instanceof ApiError) {
    if (error.status === 401) return;

    const description = [
      error.message,
      actionLabels[error.action],
      error.errorId ? `Ref: ${error.errorId}` : null,
    ].filter(Boolean).join(" ");

    toast({
      title: fallbackTitle || getSeverityTitle(error.severity),
      description,
      variant: severityVariant[error.severity],
    });
    return;
  }

  if (error instanceof Error) {
    toast({
      title: fallbackTitle || "Error",
      description: error.message,
      variant: "destructive",
    });
    return;
  }

  toast({
    title: fallbackTitle || "Error",
    description: String(error),
    variant: "destructive",
  });
}

function getSeverityTitle(severity: ErrorSeverity): string {
  switch (severity) {
    case "info": return "Notice";
    case "warning": return "Warning";
    case "error": return "Error";
    case "critical": return "Critical Error";
  }
}

export function handleMutationError(error: unknown, context?: string) {
  showErrorToast(error, context ? `${context} failed` : undefined);
}
