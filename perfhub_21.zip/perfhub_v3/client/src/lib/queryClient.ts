import { QueryClient, QueryFunction } from "@tanstack/react-query";

export type ErrorSeverity = "info" | "warning" | "error" | "critical";
export type SuggestedAction = "retry" | "contact_admin" | "check_config" | "login" | "check_permissions" | "go_back" | "refresh";

export interface ErrorResponseBody {
  errorId: string;
  correlationId: string;
  code: string;
  severity: ErrorSeverity;
  message: string;
  details?: string;
  action: SuggestedAction;
  timestamp: string;
  path?: string;
}

export class ApiError extends Error {
  public errorId: string;
  public correlationId: string;
  public code: string;
  public severity: ErrorSeverity;
  public status: number;
  public details?: string;
  public action: SuggestedAction;
  public timestamp: string;
  public path?: string;

  constructor(status: number, body: ErrorResponseBody) {
    super(body.message);
    this.name = "ApiError";
    this.status = status;
    this.errorId = body.errorId;
    this.correlationId = body.correlationId;
    this.code = body.code;
    this.severity = body.severity;
    this.details = body.details;
    this.action = body.action;
    this.timestamp = body.timestamp;
    this.path = body.path;
  }
}

function generateClientErrorId(): string {
  return `CLT-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
}

export function createNetworkError(originalError?: Error): ApiError {
  const errorId = generateClientErrorId();
  return new ApiError(0, {
    errorId,
    correlationId: "network",
    code: "NETWORK_ERROR",
    severity: "critical",
    message: "Unable to connect to the server",
    details: originalError?.message || "Network request failed. The server may be down or you may have lost your internet connection.",
    action: "retry",
    timestamp: new Date().toISOString(),
  });
}

async function parseErrorResponse(res: Response): Promise<ApiError> {
  try {
    const body = await res.json();
    if (body.errorId && body.code) {
      return new ApiError(res.status, body as ErrorResponseBody);
    }
    return new ApiError(res.status, {
      errorId: generateClientErrorId(),
      correlationId: "unknown",
      code: res.status === 401 ? "UNAUTHORIZED" : res.status === 403 ? "FORBIDDEN" : res.status === 404 ? "NOT_FOUND" : "API_ERROR",
      severity: res.status >= 500 ? "critical" : "error",
      message: body.message || body.error || res.statusText || "Something went wrong",
      details: typeof body === "object" ? JSON.stringify(body) : undefined,
      action: res.status === 401 ? "login" : res.status >= 500 ? "retry" : "check_config",
      timestamp: new Date().toISOString(),
      path: res.url,
    });
  } catch {
    return new ApiError(res.status, {
      errorId: generateClientErrorId(),
      correlationId: "unknown",
      code: "PARSE_ERROR",
      severity: res.status >= 500 ? "critical" : "error",
      message: res.statusText || "An error occurred",
      action: "retry",
      timestamp: new Date().toISOString(),
      path: res.url,
    });
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      headers: data
        ? { "Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest" }
        : { "X-Requested-With": "XMLHttpRequest" },
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
    });
  } catch (err) {
    throw createNetworkError(err instanceof Error ? err : undefined);
  }

  if (!res.ok) {
    throw await parseErrorResponse(res);
  }
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    let res: Response;
    try {
      res = await fetch(queryKey.join("/") as string, {
        credentials: "include",
      });
    } catch (err) {
      throw createNetworkError(err instanceof Error ? err : undefined);
    }

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    if (!res.ok) {
      throw await parseErrorResponse(res);
    }
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: true,
      staleTime: 30000,
      retry: (failureCount, error) => {
        if (error instanceof ApiError) {
          if (error.status === 401 || error.status === 403 || error.status === 404) return false;
          if (error.code === "VALIDATION_ERROR") return false;
        }
        return failureCount < 3;
      },
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 10000),
    },
    mutations: {
      retry: (failureCount, error) => {
        if (error instanceof ApiError && error.status < 500) return false;
        return failureCount < 1;
      },
      retryDelay: 1000,
      onError: (error) => {
        import("@/lib/error-toast").then(({ showErrorToast }) => {
          showErrorToast(error);
        });
      },
    },
  },
});
