export const queryKeys = {
  scripts: {
    all: ["/api/scripts"] as const,
    detail: (id: number | string) => ["/api/scripts", String(id)] as const,
    pluginCheck: (id: number | string) => [`/api/scripts/${id}/plugin-check`] as const,
    breadcrumbName: (id: string) => ["breadcrumb", "scripts", id] as const,
  },
  executions: {
    all: ["/api/executions"] as const,
    list: (params?: Record<string, unknown>) => ["/api/executions", params] as const,
    detail: (id: number | string) => ["/api/executions", String(id)] as const,
    filteredMetrics: (id: string, filterParams: string) => ["/api/executions", id, "filtered-metrics", filterParams] as const,
    systemMetrics: (id: string) => ["/api/executions", id, "system-metrics"] as const,
    breadcrumbName: (id: string) => ["breadcrumb", "executions", id] as const,
  },
  schedules: {
    all: ["/api/schedules"] as const,
    detail: (id: number | string) => ["/api/schedules", String(id)] as const,
  },
  dumps: {
    all: ["/api/dumps"] as const,
    detail: (id: number | string) => ["/api/dumps", String(id)] as const,
    annotations: (id: number | string) => ["/api/dumps", String(id), "annotations"] as const,
    bookmarks: (id: number | string) => ["/api/dumps", String(id), "bookmarks"] as const,
    comparisons: ["/api/dump-comparisons"] as const,
    breadcrumbName: (id: string) => ["breadcrumb", "dumps", id] as const,
  },
  completionReports: {
    all: ["/api/completion-reports"] as const,
    detail: (id: number | string) => ["/api/completion-reports", String(id)] as const,
    approvals: (id: number | string) => ["/api/completion-reports", String(id), "approvals"] as const,
    breadcrumbName: (id: string) => ["breadcrumb", "completion-reports", id] as const,
  },
  notifications: {
    all: ["/api/notifications"] as const,
    unreadCount: ["/api/notifications/unread-count"] as const,
    preferences: ["/api/notification-preferences"] as const,
  },
  admin: {
    users: ["/api/admin/users"] as const,
    pendingUsers: ["/api/admin/pending-users"] as const,
    ingestTokens: ["/api/admin/ingest-tokens"] as const,
    emailSettings: ["/api/email-settings"] as const,
    emailLogs: ["/api/email-logs"] as const,
    retentionOverview: ["/api/retention/overview"] as const,
    retentionHistory: ["/api/retention/history"] as const,
    retentionSettings: ["/api/settings/retention"] as const,
  },
  dashboard: {
    stats: ["/api/dashboard/stats"] as const,
    favorites: ["/api/favorites"] as const,
  },
  tracker: {
    stats: (params: unknown[]) => ["/api/test-tracker/stats", ...params] as const,
    list: (params: unknown[]) => ["/api/test-tracker", ...params] as const,
  },
  trends: {
    aggregated: (params: unknown[]) => ["/api/trends/aggregated", ...params] as const,
  },
  savedViews: {
    list: (page: string) => ["/api/saved-views", page] as const,
  },
  environments: ["/api/environments"] as const,
  testTypes: ["/api/test-types"] as const,
  projects: ["/api/projects"] as const,
  folders: ["/api/folders"] as const,
  reportDelivery: ["/api/report-delivery-schedules"] as const,
  auth: {
    session: ["/api/auth/session"] as const,
  },
  releaseTags: ["/api/release-tags"] as const,
  auditLogs: ["/api/audit-logs"] as const,
  cicd: {
    tokens: ["/api/ci/tokens"] as const,
  },
  webhooks: {
    all: ["/api/webhooks"] as const,
    detail: (id: number | string) => ["/api/webhooks", String(id)] as const,
    deliveries: (id: number | string) => ["/api/webhooks", String(id), "deliveries"] as const,
    events: ["/api/webhook-events"] as const,
  },
} as const;
