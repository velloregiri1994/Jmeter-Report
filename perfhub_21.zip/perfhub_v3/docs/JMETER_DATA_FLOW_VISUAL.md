# JMeter Data Flow - Visual Summary

## Complete Data Pipeline

```
╔═══════════════════════════════════════════════════════════════════════╗
║                                                                       ║
║                      JMETER TEST EXECUTION                           ║
║                                                                       ║
║  ┌─────────────────────────────────────────────────────────────────┐ ║
║  │ Option A: Server-Side              Option B: Local/External    │ ║
║  │                                                                 │ ║
║  │ JMeter CLI (spawned by worker.ts)   JMeter GUI / CLI           │ ║
║  │    ↓                                    ↓                       │ ║
║  │ Writes: /tmp/jmeter-results-{id}.jtl  Sends Backend Listener   │ ║
║  │    ↓                                    ↓                       │ ║
║  │ Every 3 seconds:                   Every ~5 seconds:           │ ║
║  │ • Polls JTL file                   • HTTP POST (InfluxDB fmt)  │ ║
║  │ • Parses new lines                 • Endpoint: /api/influxdb/  │ ║
║  │ • Calculates aggregates            • Header: X-Ingest-Token    │ ║
║  │                                                                 │ ║
║  └─────────────────────────────────────────────────────────────────┘ ║
║           ↓                                      ↓                    ║
║  ┌────────────────────────────────────────────────────────┐           ║
║  │           PERFHUB SERVER /api/influxdb/write            │           ║
║  │                                                         │           ║
║  │  1. Authenticate (check ingest token)                  │           ║
║  │  2. Parse InfluxDB Line Protocol                       │           ║
║  │     • Extract measurement, tags, fields                │           ║
║  │     • Handle timestamps (convert to ms)                │           ║
║  │  3. Find or Create Execution                           │           ║
║  │     • runId tag → execution ID                         │           ║
║  │     • Create if doesn't exist                          │           ║
║  │  4. Update Live Metrics                                │           ║
║  │     • Append to arrays (avg RT, throughput, etc)       │           ║
║  │     • Keep rolling window (last 100 points)            │           ║
║  │  5. Store Time-Series Metrics                          │           ║
║  │     • Insert row in testMetrics table                  │           ║
║  │  6. Forward to External InfluxDB                       │           ║
║  │     • If configured (INFLUXDB_URL)                     │           ║
║  │  7. Broadcast via WebSocket                            │           ║
║  │     • Send to all connected UI clients                 │           ║
║  │                                                         │           ║
║  └────────────────────────────────────────────────────────┘           ║
║           ↓              ↓              ↓              ↓              ║
║  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌───────────┐ ║
║  │ PostgreSQL   │  │ WebSocket    │  │ External     │  │ Execution │ ║
║  │              │  │              │  │ InfluxDB     │  │ Status    │ ║
║  │ testExecution│  │ Broadcast    │  │              │  │           │ ║
║  │ .liveMetrics │  │              │  │ (if enabled) │  │ running   │ ║
║  │              │  │ All connected│  │              │  │ → complete│ ║
║  │ testMetrics  │  │ browser tabs │  │ For Grafana  │  │           │ ║
║  │ time-series  │  │              │  │              │  │ Sends     │ ║
║  │              │  │ Updates UI   │  │              │  │ WebSocket │ ║
║  │ Rolling window│  │ in real-time │  │              │  │ message   │ ║
║  │ 100 points   │  │              │  │              │  │           │ ║
║  └──────────────┘  └──────────────┘  └──────────────┘  └───────────┘ ║
║                                                                       ║
╚═══════════════════════════════════════════════════════════════════════╝

                            ↓

┌──────────────────────────────────────────────────────────────────────┐
│                       USER INTERFACE                                 │
│                                                                      │
│  ┌─────────────────────────────────┬────────────────────────────┐   │
│  │  Execution Detail Page          │  Live Dashboard            │   │
│  │  /executions/{id}               │  /executions/{id}/live     │   │
│  │                                 │                            │   │
│  │  • Real-Time Metrics Component  │  • Grafana Panels          │   │
│  │    - Current Latency            │    (if Grafana configured) │   │
│  │    - Total Errors               │  • Response Time by TX     │   │
│  │    - Active Threads             │  • Request Distribution    │   │
│  │                                 │  • Error Rate Trends       │   │
│  │  • Transaction Details Table    │  • Throughput by TX        │   │
│  │  • Charts (Recharts)            │                            │   │
│  │    - Avg Response Time          │  Queries:                  │   │
│  │    - Throughput Trend           │  • from(bucket: v.default)│   │
│  │    - Success vs Failed          │  • filter(fn: runId == $id)│   │
│  │    - Error Rate                 │  • Display last 1 hour     │   │
│  │                                 │                            │   │
│  └─────────────────────────────────┴────────────────────────────┘   │
└──────────────────────────────────────────────────────────────────────┘
```

---

## Request-Level vs Interval-Level Metrics

```
JMeter Test Running...

┌─────────────────────────────────────────────────────────────────┐
│ Individual Requests (stored in JTL or Line Protocol)            │
│                                                                 │
│ Request 1: Login      [123ms] ✓                                 │
│ Request 2: Homepage   [145ms] ✓                                 │
│ Request 3: Add Item   [98ms]  ✓                                 │
│ Request 4: Checkout   [890ms] ✗ (timeout)                       │
│ Request 5: Checkout   [456ms] ✓                                 │
│ Request 6: Login      [115ms] ✓                                 │
│ ...                                                              │
│ (Millions of requests during test)                              │
└─────────────────────────────────────────────────────────────────┘
                         ↓
          Every 3-5 seconds, calculate...
                         ↓
┌─────────────────────────────────────────────────────────────────┐
│ Interval Aggregates (what PerfHub stores)                       │
│                                                                 │
│ Interval 1 (16:05:20-16:05:23):                                │
│   • Requests in interval: 18                                   │
│   • Avg response time: 234ms                                   │
│   • Min/Max: 45ms / 890ms                                      │
│   • P50: 120ms, P90: 500ms, P95: 750ms, P99: 890ms            │
│   • Errors: 1 (error rate: 5.5%)                              │
│   • Throughput: 6 req/sec                                      │
│                                                                 │
│ By Transaction (Login):                                        │
│   • Count: 8                                                    │
│   • Avg: 121ms                                                 │
│   • P90: 145ms                                                 │
│   • Throughput: 2.67 req/sec                                   │
│   • Error rate: 0%                                             │
│                                                                 │
│ By Transaction (Checkout):                                     │
│   • Count: 5                                                    │
│   • Avg: 567ms                                                 │
│   • P90: 890ms                                                 │
│   • Throughput: 1.67 req/sec                                   │
│   • Error rate: 20% (1 out of 5)                              │
│                                                                 │
│ Interval 2 (16:05:23-16:05:26):                                │
│   • Requests: 20                                               │
│   • Avg: 245ms                                                 │
│   • ... (repeat pattern)                                       │
└─────────────────────────────────────────────────────────────────┘
        ↓
    Stored in liveMetrics arrays (rolling window):
        ↓
┌─────────────────────────────────────────────────────────────────┐
│ liveMetrics (last 100 intervals)                                │
│                                                                 │
│ avgResponseTime: [234, 245, 232, 250, ...]  (100 points)      │
│ throughput:      [6.0, 6.7, 6.5, 7.0, ...]  (100 points)      │
│ errorRate:       [5.5, 3.2, 2.1, 4.5, ...]  (100 points)      │
│ timestamps:      ["16:05:23", "16:05:26", ...] (100 points)   │
│                                                                 │
│ transactionDetails (current state):                            │
│   - Login: {count: 480, avg: 121, p90: 145, throughput: 2.7}  │
│   - Checkout: {count: 300, avg: 567, p90: 890, throughput: 1.7}│
│   - ...                                                         │
│                                                                 │
│ transactionHistory (trends over time):                         │
│   - Login: {                                                    │
│       avg: [120, 121, 119, 122, ...],       (100 points)      │
│       throughput: [2.7, 2.8, 2.6, 2.9, ...] (100 points)      │
│     }                                                           │
│   - Checkout: { ... }                                          │
└─────────────────────────────────────────────────────────────────┘
```

---

## Data Storage Strategy

```
REAL-TIME (Keep in Memory in liveMetrics):
  ├─ Last 100 data points (~8-15 minutes)
  ├─ Shows rolling trends
  ├─ Fast retrieval for UI
  └─ Updates every metric push

HISTORICAL (PostgreSQL testMetrics):
  ├─ Every point for full duration
  ├─ Searchable and queryable
  ├─ For dashboards and reports
  └─ Down-sampled by retention policy

LONG-TERM (External InfluxDB):
  ├─ If configured
  ├─ For Grafana visualization
  ├─ Separate from PerfHub DB
  └─ Can set retention policies
```

---

## Code Flow for Each Metric Update

### Path 1: Server-Side (JTL Polling)
```
worker.ts → runJMeterTest()
  │
  ├─ setInterval every 3 seconds
  │
  └─ updateMetricsFromJTL()
      │
      ├─ Read JTL file from offset
      ├─ Parse CSV lines
      ├─ Group by transaction
      ├─ Calculate aggregates:
      │  • count, sum, average
      │  • min, max, percentiles
      │
      ├─ storage.addLiveMetric()
      │  └─ Update liveMetrics arrays in PostgreSQL
      │
      ├─ broadcastExecutionUpdate()
      │  └─ Send WebSocket to UI
      │
      └─ addTimeSeriesMetricWithBatch()
         └─ Insert into testMetrics table
```

### Path 2: Backend Listener (HTTP)
```
JMeter → POST /api/influxdb/write
  │
  └─ influxdb-routes.ts
      │
      ├─ Authenticate (check token hash)
      │
      ├─ parseInfluxLineProtocol()
      │  ├─ Split: measurement|tags|fields|timestamp
      │  ├─ Parse tags (runId, transaction, application)
      │  ├─ Parse fields (avg, count, p90, etc)
      │  └─ Normalize timestamp
      │
      ├─ getExecutionByExecution ID() [find or create]
      │
      ├─ storage.updateExecution()
      │  └─ Update liveMetrics array
      │
      ├─ storage.createTestMetric()
      │  └─ Insert time-series row
      │
      ├─ Forward to external InfluxDB [optional]
      │
      └─ broadcastExecutionUpdate()
         └─ Send WebSocket to UI
```

### Path 3: External Ingest API
```
External Tool → POST /api/ingest/metrics
  │
  └─ ingest-routes.ts
      │
      ├─ Authenticate (check token)
      │
      ├─ Find execution by ID
      │
      ├─ Update liveMetrics:
      │  ├─ Append to avgResponseTime[]
      │  ├─ Append to throughput[]
      │  ├─ Rotate arrays (shift if > 100)
      │  └─ Append to timestamps[]
      │
      ├─ storage.createTestMetric()
      │  └─ Insert time-series row
      │
      └─ broadcastExecutionUpdate()
         └─ Send WebSocket to UI
```

---

## State Transitions

```
┌─────────┐
│ queued  │
└────┬────┘
     │ worker finds & claims
     ↓
┌─────────────────────┐
│ running             │
│                     │
│ • Spawn JMeter      │
│ • Poll metrics      │
│ • Update liveMetrics│
│ • Broadcast to UI   │
│ • Write to DB       │
└─────────┬───────────┘
          │
     ┌────┴────┐
     │          │
     ↓          ↓
 ┌────────┐  ┌──────────┐
 │completed│  │  failed  │
 │         │  │          │
 │ Parse   │  │ Error    │
 │ final   │  │ stored in│
 │ results │  │ summary  │
 │ Notify  │  │ Notify   │
 │ user    │  │ user     │
 └────────┘  └──────────┘
```

---

## Key Metrics Formulas

```javascript
// Per-Interval Aggregates

avgResponseTime = sum(allResponseTimes) / count

percentiles = {
  p50: sorted[Math.floor(count * 0.50)],
  p90: sorted[Math.floor(count * 0.90)],
  p95: sorted[Math.floor(count * 0.95)],
  p99: sorted[Math.floor(count * 0.99)],
}

errorRate = (errorCount / totalCount) * 100

throughput = requestCount / interval_seconds

// Overall Summary

totalRequests = sum of all request counts
failedRequests = sum of all error counts
avgResponseTime = sum(all intervals' totalTime) / totalRequests
throughput = totalRequests / testDurationSeconds
```

---

## Memory Efficiency

```
Old Approach (Inefficient):
  arr = arr.slice(-100)  // Creates new array on every update

New Approach (Efficient):
  while (arr.length > 100) {
    arr.shift()  // Remove first element
  }
  arr.push(newValue)  // Add to end
  
Benefits:
  • No array reallocation
  • O(1) queue operations
  • Memory stable at 100 points
  • For 10 metrics * 100 points * ~16 bytes = ~16KB per execution
```

