# JMeter to PerfHub: Quick Reference

## 📡 Three Ways Data Flows from JMeter to PerfHub

### 1️⃣ **Internal Execution** (Server-side)
**When:** JMeter runs on PerfHub server  
**How:** PerfHub spawns JMeter process and polls JTL file  
**Interval:** Every 3 seconds (METRIC_UPDATE_INTERVAL_MS)

```
JMeter Process → JTL File (/tmp/jmeter-results-{id}.jtl)
                    ↓
             updateMetricsFromJTL()
                    ↓
             storage.addLiveMetric()
                    ↓
             PostgreSQL + WebSocket
```

**Code:** `server/worker.ts:570-800` → `runJMeterTest()`

---

### 2️⃣ **Backend Listener** (Real-time streaming)
**When:** JMeter runs on your local machine/CI-CD  
**How:** JMeter Backend Listener sends metrics via HTTP  
**Interval:** Every ~5 seconds (JMeter default)

```
JMeter Backend Listener
    ↓ HTTP POST
PerfHub /api/influxdb/write
    ↓
parseInfluxLineProtocol()
    ↓
PostgreSQL + External InfluxDB + WebSocket
```

**Code:** `server/influxdb-routes.ts:200-400` → `POST /api/influxdb/write`

**JMeter Configuration:**
```
Backend Listener Implementation: 
  org.apache.jmeter.visualizers.backend.influxdb.InfluxdbBackendListenerClient

Parameters:
  influxdbUrl: http://your-perfhub:5000/api/influxdb/write
  application: MyLoadTest
  measurement: jmeter
  influxdbToken: your-ingest-token
```

---

### 3️⃣ **External Ingest API** (API-based)
**When:** Tests run in CI/CD, Kubernetes, or external systems  
**How:** Push metrics via REST API  
**Usage:** Push single metrics or batch

```
External Test Tool
    ↓ HTTP POST
PerfHub /api/ingest/metrics (or /api/ingest/metrics/batch)
    ↓
storage.createTestMetric() + storage.addLiveMetric()
    ↓
PostgreSQL + WebSocket
```

**Code:** `server/ingest-routes.ts:180-350`

**API Examples:**
```bash
# Single metric
curl -X POST http://perfhub:5000/api/ingest/metrics \
  -H "X-Ingest-Token: your-token" \
  -d '{
    "executionId": "EXEC-20260125-120000-ABCD",
    "responseTime": 123,
    "throughput": 45.6,
    "activeThreads": 10,
    "errorCount": 0
  }'

# Batch metrics
curl -X POST http://perfhub:5000/api/ingest/metrics/batch \
  -H "X-Ingest-Token: your-token" \
  -d '{
    "executionId": "EXEC-20260125-120000-ABCD",
    "metrics": [
      { "responseTime": 123, "throughput": 45.6, ... },
      { "responseTime": 125, "throughput": 46.1, ... }
    ]
  }'
```

---

## 📊 What Gets Stored

### PostgreSQL: testExecutions
```json
{
  "id": 42,
  "executionId": "EXEC-20260125-120000",
  "status": "running",
  "liveMetrics": {
    "avgResponseTime": [123, 125, 124, ...],
    "throughput": [10.5, 11.2, 10.8, ...],
    "activeThreads": [10, 10, 10, ...],
    "errorCount": 3,
    "timestamps": ["16:05:20", "16:05:21", ...],
    "transactionDetails": [
      {
        "label": "Login",
        "count": 100,
        "avg": 123,
        "p90": 500,
        "errorRate": 2.0
      }
    ]
  },
  "resultSummary": {
    "totalRequests": 5000,
    "failedRequests": 100,
    "avgResponseTime": 150,
    "throughput": 166.7,
    "transactionDetails": [...]
  }
}
```

### PostgreSQL: testMetrics (Time-Series)
```
executionId | timestamp               | responseTime | throughput | activeThreads
42          | 2026-01-25 16:05:20    | 123          | 10.5       | 10
42          | 2026-01-25 16:05:21    | 125          | 11.2       | 10
42          | 2026-01-25 16:05:22    | 124          | 10.8       | 10
```

### External InfluxDB (Optional)
```
jmeter,runId=EXEC-12345,transaction=Login,application=MyTest 
  avg=123.45,count=100,p90=500,p95=750,p99=900,countError=2
```

---

## 🔑 Key Functions in Data Flow

| Function | File | Purpose |
|----------|------|---------|
| `runJMeterTest()` | worker.ts | Spawns JMeter process |
| `updateMetricsFromJTL()` | worker.ts | Polls JTL file every 3s |
| `parseJMeterResults()` | worker.ts | Parses final JTL for summary |
| `parseInfluxLineProtocol()` | influxdb-routes.ts | Parses Backend Listener data |
| `addLiveMetric()` | storage.ts | Updates liveMetrics in DB |
| `createTestMetric()` | storage.ts | Inserts time-series row |
| `broadcastExecutionUpdate()` | websocket.ts | Sends WebSocket to UI |

---

## 🔒 Authentication

All external data flows require **Ingest Token**:

1. **Create Token** in Admin Settings → Ingest Tokens
2. **Copy Token** (shown only once!)
3. **Add to JMeter** Backend Listener parameter
4. **Or** include in API header: `X-Ingest-Token: your-token`

Tokens are hashed in DB, matching only on exact string comparison.

---

## 📈 Metrics Sent by JMeter Backend Listener

Every ~5 seconds, JMeter sends:

```
InfluxDB Line Protocol:
jmeter,runId=<id>,transaction=<label>,application=<app> \
  count=100i,countError=2i,avg=123.45,min=50,max=1000, \
  pct50.0=110,pct90.0=500,pct95.0=750,pct99.0=900, \
  hit=100i,meanAT=10,maxAT=10,startedT=10,endedT=0 \
  1705664400000000000
```

**Key Fields:**
- `count`: Total samples
- `countError`: Error count
- `avg`: Average response time (ms)
- `pct90.0`, `pct95.0`, `pct99.0`: Percentiles
- `hit`: Hits per interval
- `meanAT` / `maxAT`: Active threads

**Key Tags:**
- `runId`: Execution ID (auto-set by PerfHub)
- `transaction`: Sampler label
- `application`: Test name

---

## 🔧 JTL File Format (for internal execution)

CSV with headers:
```
timeStamp,elapsed,label,responseCode,responseMessage,threadName,dataType,success,failureMessage,bytes,sentBytes,grpThreads,allThreads,Latency,Connect
1705664400000,123,Login,200,,Thread Group 1-1,text,true,,1024,512,10,10,45,23
1705664401000,456,Checkout,200,,Thread Group 1-2,text,false,Connection timeout,0,0,10,10,200,100
```

PerfHub reads:
- `elapsed`: Response time (ms)
- `label`: Transaction name
- `success`: Pass/Fail
- `failureMessage`: Error details
- Groups by label to create per-transaction metrics

---

## 📍 Live Metrics Array Rotation

**Issue Fixed:** Was always pushing throughput = 1

**How it works now:**
```typescript
// Storage
liveMetrics.avgResponseTime.push(123);
liveMetrics.throughput.push(10.5);  // ← NOW USES ACTUAL VALUE
liveMetrics.activeThreads.push(10);
liveMetrics.timestamps.push("16:05:23");

// Keep only last 100 points
while (liveMetrics.avgResponseTime.length > 100) {
  liveMetrics.avgResponseTime.shift();
  liveMetrics.throughput.shift();
  liveMetrics.activeThreads.shift();
  liveMetrics.timestamps.shift();
}
```

Maintains rolling window of recent metrics for UI charts.

---

## 🎯 Which Path Should I Use?

| Scenario | Path | Reason |
|----------|------|--------|
| Testing on same server as PerfHub | **Path 1** | No network overhead, instant feedback |
| JMeter GUI running locally | **Path 2** | Built-in Backend Listener, real-time |
| External JMeter (Jenkins, Docker) | **Path 2 or 3** | Path 2 for live metrics, Path 3 for batch |
| K6 or LoadRunner tests | **Path 3** | Ingest API handles any tool |
| CI/CD pipeline (GitHub Actions) | **Path 3** | Push results after test completes |

---

## 🐛 Recent Fixes Applied

1. ✅ **Throughput hardcoded to 1** → Now uses actual value
2. ✅ **Transaction history missing** → Now tracks per-transaction trends
3. ✅ **Throughput calc wrong** → Fixed formula in JTL polling
4. ✅ **Array slicing inefficient** → Changed to FIFO queue rotation

See: `/docs/JMETER_DATA_FLOW.md` for detailed architecture diagram
