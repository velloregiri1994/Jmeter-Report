# External Metrics Ingestion API

PerfHub supports receiving metrics from external JMeter and K6 tests running on your local machine or CI/CD pipelines.

## Setup

1. Set the `INGEST_SECRET` environment variable on your PerfHub server:
   ```
   INGEST_SECRET=your-secret-token-here
   ```

2. Use this token in the `X-Ingest-Token` header when calling the ingest API.

## API Endpoints

### Check Status
```
GET /api/ingest/status
```
Returns whether the ingest API is enabled.

### Create External Execution
```
POST /api/ingest/executions
X-Ingest-Token: <INGEST_SECRET>
Content-Type: application/json

{
  "name": "My Load Test",
  "toolType": "JMeter",  // or "K6", "LoadRunner", "Gatling", "Locust", "Other"
  "environment": "production",
  "vusers": 100,
  "duration": 3600
}
```

**Response:**
```json
{
  "success": true,
  "executionId": "EXT-20260122-103000-ABCD",
  "internalId": 7,
  "message": "External execution created. Push metrics to /api/ingest/metrics"
}
```

### Push Single Metric
```
POST /api/ingest/metrics
X-Ingest-Token: <INGEST_SECRET>
Content-Type: application/json

{
  "executionId": "EXT-20260122-103000-ABCD",
  "responseTime": 250,
  "throughput": 100,
  "activeThreads": 50,
  "errorCount": 2,
  "transactionLabel": "Login",
  "transactionAvg": 245,
  "transactionP90": 400,
  "transactionP95": 500
}
```

### Push Batch Metrics
```
POST /api/ingest/metrics/batch
X-Ingest-Token: <INGEST_SECRET>
Content-Type: application/json

{
  "executionId": "EXT-20260122-103000-ABCD",
  "metrics": [
    {
      "responseTime": 250,
      "throughput": 100,
      "activeThreads": 50,
      "errorCount": 0
    },
    {
      "responseTime": 280,
      "throughput": 95,
      "activeThreads": 50,
      "errorCount": 1
    }
  ]
}
```

### Complete Execution
```
POST /api/ingest/complete
X-Ingest-Token: <INGEST_SECRET>
Content-Type: application/json

{
  "executionId": "EXT-20260122-103000-ABCD",
  "status": "completed",
  "summary": {
    "totalRequests": 50000,
    "failedRequests": 100,
    "avgResponseTime": 245,
    "throughput": 85,
    "transactionDetails": [
      {
        "label": "Login",
        "count": 10000,
        "avg": 200,
        "p90": 350,
        "p95": 400,
        "throughput": 20,
        "errorRate": 0.1
      }
    ]
  }
}
```

---

## JMeter Configuration

### Using BeanShell/JSR223 Sampler

Add this to a JSR223 PostProcessor (Groovy):

```groovy
import groovy.json.JsonOutput
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.HttpClients

def perfhubUrl = "https://your-perfhub-url"
def ingestSecret = "your-secret-token"
def executionId = vars.get("PERFHUB_EXECUTION_ID")

def metric = [
    executionId: executionId,
    responseTime: prev.getTime(),
    throughput: 1,
    activeThreads: ctx.getThreadGroup().getNumberOfThreads(),
    errorCount: prev.isSuccessful() ? 0 : 1,
    transactionLabel: prev.getSampleLabel()
]

def client = HttpClients.createDefault()
def post = new HttpPost("${perfhubUrl}/api/ingest/metrics")
post.setHeader("X-Ingest-Token", ingestSecret)
post.setHeader("Content-Type", "application/json")
post.setEntity(new StringEntity(JsonOutput.toJson(metric)))

try {
    client.execute(post)
} catch (Exception e) {
    log.error("Failed to push metric: " + e.message)
}
```

---

## K6 Configuration

### Using handleSummary

Add this to your K6 script:

```javascript
import http from 'k6/http';
import { sleep } from 'k6';

const PERFHUB_URL = __ENV.PERFHUB_URL || 'https://your-perfhub-url';
const INGEST_SECRET = __ENV.INGEST_SECRET || 'your-secret-token';

let executionId = null;

export function setup() {
    // Create execution at start
    const res = http.post(
        `${PERFHUB_URL}/api/ingest/executions`,
        JSON.stringify({
            name: 'K6 Load Test',
            toolType: 'K6',
            environment: 'staging',
            vusers: __ENV.VUS || 10,
            duration: __ENV.DURATION || 60
        }),
        {
            headers: {
                'X-Ingest-Token': INGEST_SECRET,
                'Content-Type': 'application/json'
            }
        }
    );
    
    const data = JSON.parse(res.body);
    console.log(`Created execution: ${data.executionId}`);
    return { executionId: data.executionId };
}

export default function(data) {
    executionId = data.executionId;
    
    const start = Date.now();
    const res = http.get('https://test-api.example.com/endpoint');
    const responseTime = Date.now() - start;
    
    // Push metric to PerfHub
    http.post(
        `${PERFHUB_URL}/api/ingest/metrics`,
        JSON.stringify({
            executionId: executionId,
            responseTime: responseTime,
            throughput: 1,
            activeThreads: __VU,
            errorCount: res.status >= 400 ? 1 : 0,
            transactionLabel: 'API Call'
        }),
        {
            headers: {
                'X-Ingest-Token': INGEST_SECRET,
                'Content-Type': 'application/json'
            }
        }
    );
    
    sleep(1);
}

export function handleSummary(data) {
    // Complete execution at end
    const summary = {
        totalRequests: data.metrics.http_reqs.values.count,
        failedRequests: data.metrics.http_req_failed ? 
            Math.round(data.metrics.http_req_failed.values.rate * data.metrics.http_reqs.values.count) : 0,
        avgResponseTime: data.metrics.http_req_duration.values.avg,
        throughput: data.metrics.http_reqs.values.rate
    };
    
    http.post(
        `${PERFHUB_URL}/api/ingest/complete`,
        JSON.stringify({
            executionId: executionId,
            status: 'completed',
            summary: summary
        }),
        {
            headers: {
                'X-Ingest-Token': INGEST_SECRET,
                'Content-Type': 'application/json'
            }
        }
    );
    
    return {
        'stdout': JSON.stringify(data, null, 2)
    };
}
```

### Running K6 with Environment Variables

```bash
PERFHUB_URL=https://your-perfhub-url \
INGEST_SECRET=your-secret-token \
VUS=50 \
DURATION=300 \
k6 run script.js
```

---

## Viewing Results

External test executions appear in PerfHub's Executions page with:
- Execution ID prefix `EXT-` (instead of `EXE-`)
- Real-time metrics updates during test
- Full summary after completion
- All standard charts and reports

---

## Troubleshooting

### "Ingest API not configured"
Set the `INGEST_SECRET` environment variable on the PerfHub server.

### "Invalid ingest token"
Check that your `X-Ingest-Token` header matches `INGEST_SECRET` or a valid token from Admin Settings.

### "Execution not found"
Ensure you're using the correct `executionId` returned from the create execution call.

### "Execution is not running"
The execution was already completed or failed. Create a new execution for new tests.
