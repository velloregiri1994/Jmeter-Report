# Metrics Calculation Quality Improvements

## Overview
This document outlines comprehensive improvements made to JTL parsing, metrics calculation quality, and UI display for real-time metrics monitoring in PerfHub.

---

## Part 1: JTL Parsing Improvements (server/worker.ts)

### Problem Statement
The original JTL parsing implementation had several quality issues:
- Naive CSV parsing without error handling
- Only tracking max response time, missing min value
- Fixed array slice causing memory inefficiency
- Limited bounded array size (1000 items, sliced to 500)
- No per-transaction min/max tracking

### Solutions Implemented

#### 1.1 Better Error Handling
**Before:**
```typescript
const parts = line.split(',');
if (parts.length >= 8) {
  const elapsed = parseInt(parts[1], 10);
  // ...
}
```

**After:**
```typescript
try {
  const parts = line.split(',');
  if (parts.length < 8) continue;
  
  const elapsed = parseInt(parts[1], 10);
  const success = parts[7] === 'true';
  
  // Validate parse results
  if (isNaN(elapsed) || elapsed < 0) continue;
  
  // Only process valid labels
  if (label && label !== 'internal' && label !== 'all' && label.trim()) {
    // Process transaction...
  }
} catch (err) {
  log(`Failed to parse JTL line: ${line}, error: ${(err as Error).message}`, 'worker');
  continue;
}
```

**Benefits:**
- Graceful handling of malformed CSV lines
- Negative elapsed time validation
- Empty label filtering
- Prevents crashes during parsing

#### 1.2 Min/Max Response Time Tracking
**Before:**
```typescript
existing.maxResponseTime = Math.max(existing.maxResponseTime, elapsed);
// No minResponseTime tracking
```

**After:**
```typescript
existing.minResponseTime = Math.min(existing.minResponseTime, elapsed);
existing.maxResponseTime = Math.max(existing.maxResponseTime, elapsed);

// Per-transaction initialization
txMetrics.set(label, {
  count: 1,
  totalResponseTime: elapsed,
  errorCount: success ? 0 : 1,
  minResponseTime: elapsed,        // NEW
  maxResponseTime: elapsed,
  responseTimes: [elapsed],
});
```

**Benefits:**
- Complete min/max tracking per transaction
- Better understanding of response time distribution
- Critical for SLA validation

#### 1.3 Improved Array Rotation for Percentiles
**Before:**
```typescript
existing.responseTimes.push(elapsed);
if (existing.responseTimes.length > 1000) {
  existing.responseTimes = existing.responseTimes.slice(-500);
  // Creates new array, discards 500 items, inefficient
}
```

**After:**
```typescript
existing.responseTimes.push(elapsed);
if (existing.responseTimes.length > 5000) {
  existing.responseTimes.splice(0, 2500);  // Remove oldest 2500 items
  // Efficient FIFO rotation, keeps most recent 2500
}
```

**Benefits:**
- Higher sample size for percentile accuracy (5000 vs 500)
- Efficient FIFO queue rotation without creating new array
- Better percentile accuracy during long-running tests

---

## Part 2: Percentile Calculation Improvements (server/worker.ts)

### Problem Statement
Original percentile calculation used naive floor-based indexing:
```typescript
const p90 = sorted.length > 0 ? sorted[Math.floor(sorted.length * 0.9)] : avg;
```

**Issues:**
- Floor rounding loses precision
- Not accurate for small sample sizes
- Doesn't match industry standard (linear interpolation)

### Solution: Linear Interpolation

**New Implementation:**
```typescript
const calculatePercentile = (sorted: number[], percentile: number): number => {
  if (sorted.length === 0) return 0;
  if (sorted.length === 1) return sorted[0];
  
  const index = (percentile / 100) * (sorted.length - 1);
  const lower = Math.floor(index);
  const upper = Math.ceil(index);
  const weight = index % 1;
  
  if (lower === upper) return sorted[lower];
  // Linear interpolation between two values
  return Math.round(sorted[lower] * (1 - weight) + sorted[upper] * weight);
};

// Usage
const p50 = sorted.length > 0 ? calculatePercentile(sorted, 50) : avg;
const p90 = sorted.length > 0 ? calculatePercentile(sorted, 90) : avg;
const p95 = sorted.length > 0 ? calculatePercentile(sorted, 95) : avg;
const p99 = sorted.length > 0 ? calculatePercentile(sorted, 99) : avg;
```

**Example:**
- Sorted times: [10, 20, 30, 40, 50]
- P90 calculation (90% of 5-1=4, so index 3.6):
  - Floor (3) value: 40ms
  - Ceil (4) value: 50ms
  - Weight: 0.6
  - **Result: 40 × 0.4 + 50 × 0.6 = 46ms** (more accurate than floor value of 40ms)

**Benefits:**
- Industry-standard percentile calculation
- Accurate with any sample size
- Matches Grafana/JMeter reporting standards
- Better for SLA comparisons

---

## Part 3: Throughput Calculation Improvements (server/worker.ts)

### Problem Statement
Throughput calculation needed precision improvement:

**Before:**
```typescript
const throughput = data.count > 0 ? Math.round((data.count / 3) * 10) / 10 : 0;
```

**After:**
```typescript
const throughput = data.count > 0 ? Math.round((data.count / 3) * 100) / 100 : 0;
```

**Example:**
- 37 requests in 3-second interval
- Old: 37/3 = 12.33... → round × 10 → 123 / 10 = **12.3 req/s** (1 decimal)
- New: 37/3 = 12.33... → round × 100 → 1233 / 100 = **12.33 req/s** (2 decimals)

**Benefits:**
- Higher precision throughput values
- Better accuracy for capacity planning
- More precise metrics for trend analysis

---

## Part 4: Error Rate Formatting (server/worker.ts)

### Improvement
**Before:**
```typescript
errorRate: data.count > 0 ? Math.round((data.errorCount / data.count) * 100 * 100) / 100 : 0
```

**After:**
```typescript
errorRate: data.count > 0 ? Math.round((data.errorCount / data.count) * 10000) / 100 : 0
```

Both calculations are equivalent, but the new version is clearer:
- Multiply by 10000 to get 2 decimal places of percentage
- Divide by 100 for final result (or multiply by 100, then divide by 10000)

**Example:**
- 3 errors in 200 requests
- 3/200 = 0.015
- 0.015 × 10000 = 150
- 150 / 100 = **1.50%** (correct percentage with 2 decimals)

---

## Part 5: Storage Layer Improvements (server/storage.ts)

### New Interface

```typescript
async addLiveMetric(id: number, metric: { 
  responseTime: number;           // Average response time
  isError: boolean;               // Has error in this interval
  errorMessage?: string;          // Error message if any
  threadCount: number;            // Active thread count
  transactionDetails?: any[];     // Per-transaction metrics
  throughput?: number;            // Requests per second
  minResponseTime?: number;       // NEW: Minimum response time
  maxResponseTime?: number;       // NEW: Maximum response time
}): Promise<void>;
```

### New Data Structure

**Before:**
```typescript
const liveMetrics = {
  avgResponseTime: [],
  throughput: [],
  activeThreads: [],
  errorCount: 0,
  errorMessages: [],
  timestamps: [],
  transactionDetails: [],
  transactionHistory: {}
};
```

**After:**
```typescript
const liveMetrics = {
  avgResponseTime: [],
  minResponseTime: [],      // NEW
  maxResponseTime: [],      // NEW
  throughput: [],
  activeThreads: [],
  errorCount: 0,
  errorMessages: [],
  timestamps: [],
  transactionDetails: [],
  transactionHistory: {}
};
```

### Enhanced Min/Max Tracking

```typescript
const now = new Date().toLocaleTimeString();
liveMetrics.timestamps.push(now);
liveMetrics.avgResponseTime.push(metric.responseTime);
liveMetrics.minResponseTime.push(metric.minResponseTime || metric.responseTime);
liveMetrics.maxResponseTime.push(metric.maxResponseTime || metric.responseTime);
liveMetrics.activeThreads.push(metric.threadCount);
liveMetrics.throughput.push(metric.throughput || 0);
```

### Improved Array Trimming

```typescript
// Keep only last MAX_METRIC_POINTS points for memory efficiency
while (liveMetrics.timestamps.length > MAX_METRIC_POINTS) {
  liveMetrics.timestamps.shift();
  liveMetrics.avgResponseTime.shift();
  liveMetrics.minResponseTime?.shift();      // NEW
  liveMetrics.maxResponseTime?.shift();      // NEW
  liveMetrics.activeThreads.shift();
  liveMetrics.throughput.shift();
  // ... also trim transaction history
}
```

**Benefits:**
- Consistent min/max tracking with response times
- Optional fields for backward compatibility
- Memory-efficient FIFO queue rotation

---

## Part 6: UI Improvements (client/src/components/real-time-metrics.tsx)

### 6.1 Enhanced Props Interface

**Before:**
```typescript
interface RealTimeMetricsProps {
  metrics: {
    avgResponseTime: number[];
    throughput: number[];
    activeThreads: number[];
    errorCount: number;
    errorMessages: string[];
    timestamps: string[];
    transactionDetails?: Array<{
      label: string;
      avg: number;
      throughput: number;
    }>;
    transactionHistory?: {
      [label: string]: {
        avg: number[];
        throughput: number[];
      };
    };
  } | null;
}
```

**After:**
```typescript
interface RealTimeMetricsProps {
  metrics: {
    avgResponseTime: number[];
    minResponseTime?: number[];           // NEW
    maxResponseTime?: number[];           // NEW
    throughput: number[];
    activeThreads: number[];
    errorCount: number;
    errorMessages: string[];
    timestamps: string[];
    transactionDetails?: Array<{
      label: string;
      avg: number;
      min?: number;                       // NEW
      max?: number;                       // NEW
      p50?: number;                       // NEW
      p90?: number;                       // NEW
      p95?: number;                       // NEW
      p99?: number;                       // NEW
      throughput: number;
      errorRate?: number;                 // NEW
    }>;
    transactionHistory?: {
      [label: string]: {
        avg: number[];
        p50?: number[];                   // NEW
        p90?: number[];                   // NEW
        p95?: number[];                   // NEW
        p99?: number[];                   // NEW
        throughput: number[];
        errorRate?: number[];             // NEW
      };
    };
  } | null;
}
```

### 6.2 Utility Function for Number Formatting

```typescript
const formatNumber = (num: number | undefined, decimals: number = 0): string => {
  if (num === undefined || isNaN(num)) return 'N/A';
  return num.toFixed(decimals);
};

// Usage
formatNumber(123.456, 2)     // "123.46"
formatNumber(undefined, 0)   // "N/A"
formatNumber(1234.5, 0)      // "1235" (rounded)
```

**Benefits:**
- Consistent number formatting across UI
- Handles undefined/NaN gracefully
- Flexible decimal place specification

### 6.3 Enhanced Summary Cards

**Before:**
```typescript
<MetricCard label="Current Latency" 
            value={`${metrics.avgResponseTime?.[metrics.avgResponseTime.length - 1] ?? 0}ms`} />
<MetricCard label="Total Errors" 
            value={(metrics.errorCount ?? 0).toString()} 
            color="text-rose-500" />
<MetricCard label="Active Threads" 
            value={(metrics.activeThreads?.[metrics.activeThreads.length - 1] ?? 0).toString()} />
```

**After:**
```typescript
<MetricCard 
  label="Current Latency (avg)" 
  value={`${formatNumber(metrics.avgResponseTime[lastIdx])}ms`}
  subtext={metrics.minResponseTime && metrics.maxResponseTime 
    ? `Min: ${formatNumber(metrics.minResponseTime[lastIdx])}ms | Max: ${formatNumber(metrics.maxResponseTime[lastIdx])}ms`
    : undefined}
/>
<MetricCard 
  label="Current Throughput" 
  value={`${formatNumber(metrics.throughput[lastIdx], 2)} req/s`}
  color="text-emerald-500" 
/>
<MetricCard 
  label="Active Threads" 
  value={metrics.activeThreads[lastIdx]?.toString() ?? '0'}
  color="text-blue-500" 
/>
<MetricCard 
  label="Total Errors" 
  value={(metrics.errorCount ?? 0).toString()} 
  color="text-rose-500" 
/>
```

**Improvements:**
- Throughput now displays with 2 decimal precision
- Min/Max range shown as subtext for latency
- Better color-coding for different metrics
- More informative card titles
- 4-column layout (was 3-column)

### 6.4 New Transaction Summary Table

```typescript
<Card className="card-shadow">
  <CardHeader className="pb-3">
    <CardTitle className="text-sm font-medium text-muted-foreground uppercase">
      Transaction Summary
    </CardTitle>
  </CardHeader>
  <CardContent className="overflow-x-auto">
    <table className="w-full text-sm">
      <thead>
        <tr className="border-b">
          <th className="text-left py-2 px-3 font-semibold text-xs uppercase">Transaction</th>
          <th className="text-right py-2 px-3 font-semibold text-xs uppercase">Count</th>
          <th className="text-right py-2 px-3 font-semibold text-xs uppercase">Avg (ms)</th>
          <th className="text-right py-2 px-3 font-semibold text-xs uppercase">P50 (ms)</th>
          <th className="text-right py-2 px-3 font-semibold text-xs uppercase">P90 (ms)</th>
          <th className="text-right py-2 px-3 font-semibold text-xs uppercase">P95 (ms)</th>
          <th className="text-right py-2 px-3 font-semibold text-xs uppercase">P99 (ms)</th>
          <th className="text-right py-2 px-3 font-semibold text-xs uppercase">Throughput</th>
          <th className="text-right py-2 px-3 font-semibold text-xs uppercase">Error Rate</th>
        </tr>
      </thead>
      <tbody>
        {currentMetrics.map((tx) => (
          <tr key={tx.label} className="border-b hover:bg-muted/50 transition">
            <td className="py-2 px-3 font-medium">{tx.label}</td>
            <td className="text-right py-2 px-3">{formatNumber(tx.count)}</td>
            <td className="text-right py-2 px-3">{formatNumber(tx.avg)}</td>
            <td className="text-right py-2 px-3">{formatNumber(tx.p50)}</td>
            <td className="text-right py-2 px-3">{formatNumber(tx.p90)}</td>
            <td className="text-right py-2 px-3">{formatNumber(tx.p95)}</td>
            <td className="text-right py-2 px-3">{formatNumber(tx.p99)}</td>
            <td className="text-right py-2 px-3">{formatNumber(tx.throughput, 2)} req/s</td>
            <td className={`text-right py-2 px-3 ${(tx.errorRate || 0) > 5 ? 'text-rose-500 font-semibold' : ''}`}>
              {formatNumber(tx.errorRate, 2)}%
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </CardContent>
</Card>
```

**Benefits:**
- Live table showing all percentiles (P50, P90, P95, P99)
- Per-transaction error rates with color highlighting (>5% red)
- Throughput with 2 decimal places
- Responsive table with horizontal scroll on mobile
- Hover effects for better UX

### 6.5 Enhanced Response Time Chart

**Before:**
```typescript
<Area 
  name="Aggregate Avg"
  type="monotone" 
  dataKey="responseTime" 
  stroke="#6366f1" 
  strokeWidth={3}
  fillOpacity={1} 
  fill="url(#colorRes)" 
/>
{transactionLabels.map((label, idx) => (
  <Area
    key={label}
    name={label}
    type="monotone"
    dataKey={`avg_${label}`}
    stroke={COLORS[(idx + 1) % COLORS.length]}
    fill="transparent"
    strokeWidth={2}
  />
))}
```

**After:**
```typescript
<Area 
  name="Min Response"
  type="monotone" 
  dataKey="minResponse" 
  stroke="#10b981" 
  fill="transparent"
  strokeWidth={1}
  strokeDasharray="5 5"  // Dashed line for reference
/>
<Area 
  name="Avg Response"
  type="monotone" 
  dataKey="responseTime" 
  stroke="#6366f1" 
  strokeWidth={3}
  fillOpacity={1} 
  fill="url(#colorRes)" 
/>
<Area 
  name="Max Response"
  type="monotone" 
  dataKey="maxResponse" 
  stroke="#f43f5e" 
  fill="transparent"
  strokeWidth={1}
  strokeDasharray="5 5"  // Dashed line for reference
/>
{transactionLabels.map((label, idx) => (
  <Area
    key={label}
    name={`${label} Avg`}
    type="monotone"
    dataKey={`avg_${label}`}
    stroke={COLORS[(idx + 1) % COLORS.length]}
    fill="transparent"
    strokeWidth={2}
  />
))}
```

**Improvements:**
- Shows min/max bounds as dashed reference lines
- Aggregate avg highlighted with gradient fill
- Per-transaction averages with clean strokes
- Better visual understanding of response time distribution
- Clear legend showing all data series

### 6.6 Improved Tooltip Formatting

```typescript
<Tooltip formatter={(value: any) => formatNumber(value)} />
```

**Benefits:**
- All tooltip values formatted consistently
- NaN/undefined handled gracefully
- Decimal places applied uniformly

---

## Summary of Key Improvements

| Aspect | Before | After | Impact |
|--------|--------|-------|--------|
| **CSV Parsing** | Basic split, no validation | Try-catch, validation, error logging | Robust, production-ready |
| **Min/Max Tracking** | Only max, no per-transaction min | Both min and max tracked per transaction | Complete distribution data |
| **Array Rotation** | slice(-500) creates new array | splice(0, 2500) FIFO rotation | 5x larger sample size, efficient |
| **Percentiles** | Floor-based indexing (naive) | Linear interpolation (accurate) | Industry-standard accuracy |
| **Throughput Precision** | 1 decimal place (12.3 req/s) | 2 decimal places (12.33 req/s) | Better precision |
| **Error Rate Formatting** | Complex math | Clearer calculation | Easier to maintain |
| **UI Summary Cards** | 3 cards, basic formatting | 4 cards, colors, subtext | More informative |
| **Transaction Display** | Hidden in chart only | Live summary table with percentiles | Immediate visibility |
| **Response Time Chart** | Avg only | Avg + Min + Max + P90 lines | Better distribution visibility |
| **Number Formatting** | Inconsistent, manual | Utility function | Consistent across UI |

---

## Testing Recommendations

### 1. Unit Tests
- Test `calculatePercentile()` with various sample sizes
- Verify min/max tracking per transaction
- Test CSV parsing with malformed lines

### 2. Integration Tests
- Run 5-minute JMeter test with 10+ transactions
- Verify percentiles match JMeter GUI output
- Check error rate calculations

### 3. Performance Tests
- Verify memory usage during 1-hour test
- Compare array rotation efficiency
- Monitor WebSocket broadcast throughput

### 4. Visual Validation
- Check transaction summary table population
- Verify min/max lines appear on chart
- Test responsive layout on mobile

---

## Backward Compatibility

All changes are backward compatible:
- Optional fields: `minResponseTime`, `maxResponseTime`, percentiles
- Existing code continues to work
- New fields gracefully ignored if not provided
- UI handles undefined values gracefully

---

## Next Steps

1. **Deploy** to staging environment
2. **Run** sample JMeter tests to validate
3. **Compare** metrics with production baseline
4. **Monitor** WebSocket broadcast performance
5. **Gather** user feedback on UI improvements

---

## Configuration Constants

Key constants can be adjusted:

```typescript
// server/worker.ts
const MAX_RESPONSE_TIMES = 5000;  // Sample size for percentile calculation
const TRIM_THRESHOLD = 2500;       // Remove oldest when exceeding max

// server/storage.ts
const MAX_METRIC_POINTS = 100;     // Points to retain in UI
const MAX_ERROR_MESSAGES = 50;     // Error messages to retain
```

