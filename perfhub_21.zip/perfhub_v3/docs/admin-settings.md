# PerfHub Admin Settings Configuration Guide

This guide documents all configurable settings in the PerfHub Admin Settings panel.

## Accessing Admin Settings

1. Log in to PerfHub with an **admin** account
2. Click the settings icon in the navigation or go to `/admin/settings`
3. You'll see tabs for different configuration sections

---

## InfluxDB Integration

InfluxDB is used for storing time-series performance metrics from JMeter and K6 tests. This enables advanced querying, historical analysis, and integration with Grafana dashboards.

### Configuration Fields

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| **Enabled** | Yes | `false` | Toggle to enable/disable InfluxDB integration |
| **InfluxDB URL** | Yes | - | The HTTP URL of your InfluxDB 2.x instance |
| **API Token** | Yes | - | Authentication token for InfluxDB API access |
| **Organization** | Yes | - | InfluxDB organization name |
| **Bucket** | Yes | - | Bucket name where metrics will be stored |

### Example Configuration

```
URL:          http://localhost:8086
API Token:    your-influxdb-api-token
Organization: perfhub
Bucket:       jmeter
```

### Docker Compose Defaults

When using the provided `docker-compose.yml`:

| Setting | Default Value |
|---------|---------------|
| URL | `http://influxdb:8086` (internal) or `http://localhost:8086` (external) |
| Username | `perfhub` |
| Password | `perfhub_password` |
| API Token | `perfhub_token` |
| Organization | `perfhub` |
| Bucket | `jmeter` |

### How It Works

1. **Metrics Ingestion**: When a JMeter/K6 test runs, metrics are sent to InfluxDB via the `/api/influxdb/write` endpoint
2. **Data Format**: Uses InfluxDB 2.x line protocol with tags for `runId`, `testId`, and fields for metrics
3. **Retention**: Metrics are stored based on InfluxDB bucket retention policies

### Verification

After configuration:
1. Click **Test Connection** to verify connectivity
2. Run a test and check InfluxDB Data Explorer at `http://localhost:8086`
3. Query: `from(bucket: "jmeter") |> range(start: -1h)`

---

## Grafana Integration

Grafana provides advanced visualization capabilities. When configured, PerfHub embeds Grafana panels directly in the Live Dashboard for real-time metrics viewing.

### Configuration Fields

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| **Enabled** | Yes | `false` | Toggle to enable/disable Grafana integration |
| **Grafana Base URL** | Yes | - | The base URL of your Grafana instance (required for embedding) |
| **Dashboard URL** | No | - | Full URL to the dashboard for external links |
| **Dashboard UID** | Yes | `perfhub-live-metrics` | Unique identifier of the PerfHub dashboard |

### Example Configuration

```
Base URL:      http://localhost:3000
Dashboard URL: http://localhost:3000/d/perfhub-live-metrics/perfhub-live-metrics
Dashboard UID: perfhub-live-metrics
```

### Docker Compose Defaults

When using the provided `docker-compose.yml`:

| Setting | Default Value |
|---------|---------------|
| Base URL | `http://grafana:3000` (internal) or `http://localhost:3000` (external) |
| Admin User | `admin` |
| Admin Password | `perfhub_admin` |
| Anonymous Access | Enabled (Viewer role) |
| Embedding | Enabled |

### Pre-Provisioned Dashboard

The Docker setup auto-provisions:
- **InfluxDB Datasource**: Connected to the InfluxDB container
- **PerfHub Live Metrics Dashboard**: UID `perfhub-live-metrics`

### Dashboard Panels

The provisioned dashboard includes 5 panels:

| Panel ID | Panel Name | Metrics Shown |
|----------|------------|---------------|
| 1 | Response Time (Avg/P95/P99) | Average, 95th, 99th percentile response times |
| 2 | Throughput (req/s) | Requests per second over time |
| 3 | Error Rate (%) | Percentage of failed requests |
| 4 | Active Users | Virtual user count during test |
| 5 | Response Time by Transaction | Per-transaction breakdown |

### Dashboard Variables

| Variable | Description | Usage |
|----------|-------------|-------|
| `runId` | Execution/Run ID | Filters data to specific test run |
| `testId` | Transaction name | Filters to specific transaction (or "All") |

### Security Configuration

Grafana is configured for anonymous viewer access:

```yaml
GF_AUTH_ANONYMOUS_ENABLED: true
GF_AUTH_ANONYMOUS_ORG_ROLE: Viewer
GF_SECURITY_ALLOW_EMBEDDING: true
```

- **Anonymous users**: Can view dashboards but cannot edit
- **Admin credentials**: Only for dashboard management, not exposed in PerfHub

### How Embedding Works

1. PerfHub calls `/api/grafana/panels/:runId` to get panel URLs
2. Each panel is embedded via iframe with:
   - `panelId` - Specific panel to display
   - `var-runId` - Filter by execution ID
   - `var-testId` - Filter by transaction
   - `refresh=5s` - Auto-refresh interval
   - `kiosk` - Minimal UI mode

### Verification

After configuration:
1. Click **Test Connection** to verify Grafana is reachable
2. Open Grafana directly at `http://localhost:3000` (should load without login)
3. Navigate to the PerfHub Live Metrics dashboard
4. In PerfHub, go to a test execution → Live Dashboard → Grafana Panels tab

---

## Data Retention Settings

Configure how long metrics data is retained in InfluxDB.

| Field | Default | Description |
|-------|---------|-------------|
| **Raw Data Retention** | 7 days | How long to keep full-resolution metrics |
| **Downsampled Retention** | 30 days | How long to keep aggregated metrics |

### Recommendations

| Use Case | Raw Data | Downsampled |
|----------|----------|-------------|
| Development | 7 days | 30 days |
| Production | 30 days | 90 days |
| Compliance | 90 days | 365 days |

---

## Ingest Tokens

Manage authentication tokens for external JMeter/K6 instances to send metrics to PerfHub.

### Creating a Token

1. Go to Admin Settings → Ingest Tokens
2. Click **Create New Token**
3. Enter a descriptive name (e.g., "Jenkins CI Pipeline")
4. Copy the generated token immediately (shown only once)

### Using Tokens

External tools use tokens via the `Authorization` header:

```bash
curl -X POST "https://your-perfhub.com/api/influxdb/write" \
  -H "Authorization: Token your-ingest-token" \
  -d "jmeter,runId=EXE-123,testId=Login avg=150,count=100"
```

### Token Management

| Action | Description |
|--------|-------------|
| Create | Generate new token with unique name |
| Revoke | Disable token immediately |
| Delete | Permanently remove token |

---

## Environment Variables

These can be set in Docker or system environment:

### InfluxDB

| Variable | Description |
|----------|-------------|
| `INFLUXDB_URL` | InfluxDB instance URL |
| `INFLUXDB_TOKEN` | API authentication token |
| `INFLUXDB_ORG` | Organization name |
| `INFLUXDB_BUCKET` | Default bucket name |

### Grafana

| Variable | Description |
|----------|-------------|
| `GRAFANA_URL` | Grafana instance URL |
| `GRAFANA_ADMIN_USER` | Admin username (for provisioning) |
| `GRAFANA_ADMIN_PASSWORD` | Admin password (for provisioning) |

### Application

| Variable | Description |
|----------|-------------|
| `INGEST_SECRET` | Fallback secret for metrics ingestion |
| `REDIS_URL` | Redis URL for caching (optional) |

---

## Troubleshooting

### InfluxDB Connection Failed

1. Verify InfluxDB is running: `curl http://localhost:8086/health`
2. Check token permissions in InfluxDB UI
3. Verify organization and bucket names match exactly

### Grafana Panels Not Loading

1. Verify Grafana is running: `curl http://localhost:3000/api/health`
2. Check anonymous access is enabled
3. Verify `GF_SECURITY_ALLOW_EMBEDDING=true`
4. Check browser console for CORS errors

### No Data in Dashboards

1. Run a test first to generate metrics
2. Verify InfluxDB datasource in Grafana is connected
3. Check time range in Grafana (default: last 30 minutes)
4. Query InfluxDB directly to confirm data exists

### Test Connection Timeout

1. If using Docker, use internal hostnames (`influxdb`, `grafana`)
2. If accessing externally, use `localhost` or machine IP
3. Check firewall/network rules allow connections

---

## Quick Reference

### Minimum Required Configuration

**InfluxDB:**
- URL, Token, Organization, Bucket

**Grafana:**
- Base URL, Dashboard UID

### Recommended Test Flow

1. Configure InfluxDB → Test Connection ✓
2. Configure Grafana → Test Connection ✓
3. Run a performance test
4. Open Live Dashboard → Verify both tabs work
5. Check Grafana directly → Verify data appears

---

## Related Documentation

- [JMeter Backend Listener Configuration](./jmeter-backend-listener.md) - How to configure JMeter to send metrics
- [Grafana Integration Guide](./grafana/README.md) - Detailed Grafana setup and dashboard information
