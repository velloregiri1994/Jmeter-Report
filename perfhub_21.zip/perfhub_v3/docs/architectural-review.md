# PerfHub HAR → JMX Conversion Engine — Architectural Review

**Scope:** `perfhub_v3/server/har-converter/` (7 modules, ~2,500 LOC)
**Date:** February 2026

---

## 1. Strengths

### 1.1 Pipeline Isolation
Each stage is a pure function with no shared mutable state. `parseHarFile → filterEntries → detectCorrelations → detectParameterizations → buildJmx → scoreScript` — data flows forward-only with explicit interfaces between stages. This makes each stage independently testable and replaceable.

### 1.2 Dual-Extraction Correlation Strategy
The correlation detector uses a two-strategy approach: structured extraction (JSON path traversal, HTML DOM attribute parsing) combined with pattern-based extraction (regex for UUIDs, JWTs, hex tokens, base64, OAuth Bearer). This catches both explicitly-named dynamic values and anonymous token patterns that appear in response bodies.

### 1.3 Framework-Aware Detection
The 15+ framework field registry (`FRAMEWORK_DYNAMIC_FIELDS`) enables the engine to recognize and label framework-specific dynamic values (ASP.NET ViewState, Django CSRF, Rails authenticity tokens, etc.) even when they can't be automatically correlated. These surface as actionable issues in the results rather than being silently missed.

### 1.4 XML Structural Correctness
The string-based JMX generation maintains correct hashTree pairing throughout — every JMeter element is followed by either `<hashTree>...</hashTree>` (with children) or `<hashTree/>` (empty). The `buildExtractor` function includes its own `<hashTree/>` suffix, preventing orphaned elements. Generated JMX validates structurally against JMeter 5.6.x's parser.

### 1.5 Defensive Parameterization Design
The parameterization detector explicitly skips framework dynamic fields (`isFrameworkDynamicField`) and already-correlated values (`correlatedValues` set), preventing misclassification of CSRF tokens as credentials or double-replacement of correlated session tokens.

---

## 2. Architectural Risks

### 2.1 String Concatenation XML — Fragility Under Modification

**Risk Level: Medium**

The JMX builder constructs XML through ~350 `lines.push()` calls with manually managed indentation. This creates three specific risks:

**Problem A — No structural invariant enforcement.** There is no compile-time or runtime check that every opened `<hashTree>` has a corresponding close. If a future contributor adds a conditional block that exits early (e.g., skipping a request type), the hashTree pairing can break silently. The only detection is opening the JMX in JMeter and seeing a parse error.

**Problem B — Indentation drift.** Extractors use 14-space indentation (`"              "`), while transaction-level elements use 8 spaces. If an extractor is moved to a different nesting level, the indentation becomes inconsistent. While JMeter ignores whitespace, it makes the generated XML difficult to debug visually.

**Problem C — Escape boundary ambiguity.** `applyReplacements()` runs before `escapeXml()` in some paths (e.g., line 318: body text is first replacement-processed, then XML-escaped at line 324). If a correlation's `originalValue` contains `&` or `<`, the split/join replacement will correctly target the raw value — but only because `escapeXml` runs after. If someone reorders these operations, XML injection becomes possible.

**Recommendation:** Introduce a minimal typed builder layer:

```typescript
interface JmxNode {
  tag: string;
  attrs: Record<string, string>;
  props: { type: 'string'|'bool'|'int'; name: string; value: string }[];
  children: JmxNode[];
}

function renderJmx(node: JmxNode, indent: number): string {
  // Single function handles hashTree pairing, indentation, and escaping
}
```

This doesn't require a DOM library. It's a ~50-line rendering function that guarantees structural correctness by construction. Migration can be incremental — convert one element type at a time.

### 2.2 Synchronous File Reads in Parser

**Risk Level: Low-Medium**

`har-parser.ts` line 160: `fs.readFileSync(absolutePath, 'utf-8')` blocks the Node.js event loop for the entire file read. For a 50MB HAR file on a slow disk, this could block for 100-500ms. Since processing already runs via `setImmediate`, the initial read still blocks the event loop tick it runs in.

**Recommendation:** Change to `await fs.promises.readFile()` and make `parseHarFile` async. Minimal code change, eliminates the blocking risk.

### 2.3 No Concurrency Limit on Processing

**Risk Level: Medium**

The orchestrator uses `setImmediate(() => processHarFile(...))` with no queuing or concurrency limit. If 10 users upload simultaneously, 10 conversion pipelines run concurrently in the same Node.js process. The correlation detector's O(n² × m) search is CPU-bound — 10 concurrent conversions of large HAR files could cause event loop starvation, making the entire Express server unresponsive.

**Recommendation:** Add a simple semaphore:

```typescript
const MAX_CONCURRENT = 3;
let active = 0;
const queue: (() => void)[] = [];

function enqueueConversion(fn: () => Promise<void>) {
  if (active < MAX_CONCURRENT) {
    active++;
    fn().finally(() => { active--; if (queue.length > 0) enqueueConversion(queue.shift()!); });
  } else {
    queue.push(() => enqueueConversion(fn));
  }
}
```

For true production hardening, move conversion to a `worker_threads` pool, keeping the Express event loop completely free.

---

## 3. Scalability Risks

### 3.1 Correlation Search — O(n² × m) Complexity

**Current implementation** (lines 436-446 of `correlation-detector.ts`):

```typescript
for (const candidate of sortedCandidates) {        // m candidates
  for (const entry of entries) {                     // n entries
    if (entry.index <= candidate.sourceIndex) continue;
    if (searchInRequest(entry, candidate.value)) {   // O(k) per entry
      targetRequests.push(entry.index);
    }
  }
}
```

For a HAR with 500 filtered entries and 100 candidates per response, this is 50,000 × 500 = 25 million `searchInRequest` calls. Each `searchInRequest` does 4-6 `String.includes()` operations on URL, headers, and body text. In practice, this runs in 1-3 seconds for typical HAR files, but degrades quadratically.

**Indexed approach — O(n × m) with O(n × k) preprocessing:**

```typescript
// Phase 1: Build content index — one pass over all requests
const contentIndex = new Map<string, number[]>(); // value → request indices

for (const entry of entries) {
  const searchable = buildSearchableText(entry); // concat URL + headers + body
  // For each candidate-length substring or known value, index it
}

// Phase 2: Lookup — O(1) per candidate
for (const candidate of sortedCandidates) {
  const targets = contentIndex.get(candidate.value)
    ?.filter(idx => idx > candidate.sourceIndex) || [];
}
```

The practical implementation would build a concatenated text per request, then use exact string search against it. This reduces the inner loop from n entries to a single map lookup.

**Conservative estimate of improvement:** 10-50x faster for HAR files with >200 entries.

### 3.2 Memory Pressure on Large HAR Files

A 50MB HAR file, once parsed by `JSON.parse`, becomes a ~150-200MB JavaScript object graph (due to V8 object overhead). The pipeline then creates additional data structures:

- `HarEntry[]` mapping (~1x of entries)
- `allCandidates[]` in correlation detector (~0.5x)
- `lines[]` array in JMX builder (~0.3x of output)

Peak memory usage for a 50MB HAR file: **~400-500MB**. This is within a single Node.js process's default heap (1.5GB) but leaves little room for concurrent conversions.

**Recommendation:** For files >20MB, consider a two-pass approach:
- Pass 1: Stream-parse the HAR to extract only the fields needed (URL, headers, body text, response headers, response body), discarding raw entry objects.
- Pass 2: Run the pipeline on the lightweight extracted data.

### 3.3 Generated JMX Size

The JMX builder produces verbose XML. For a 200-request HAR, the generated JMX is approximately 50-80KB. For a 1,000-request HAR with per-request headers and assertions, the JMX could reach 500KB-1MB. This is within JMeter's handling capability but creates a slow initial load in JMeter's GUI.

**Not a blocking issue** — JMeter handles multi-MB JMX files. But worth noting as a UX concern for very large conversions.

---

## 4. Immediate Fixes

### 4.1 Base64-Encoded Response Bodies — Silent Correlation Failure

**Severity: High** — Completely prevents correlation detection for a subset of entries.

`har-parser.ts` reads `response.content.text` directly without checking `response.content.encoding`. When a browser exports a HAR with `"encoding": "base64"` on response content (common for binary-like responses or when the browser decides to base64-encode), the correlation detector receives the base64 string instead of the actual response body.

**Fix:**

```typescript
let bodyText = raw.response?.content?.text;
if (bodyText && raw.response?.content?.encoding === 'base64') {
  try {
    bodyText = Buffer.from(bodyText, 'base64').toString('utf-8');
  } catch {
    bodyText = undefined; // Binary content, not useful for correlation
  }
}
```

### 4.2 URL-Encoded Value Matching — Missed Correlations

**Severity: Medium** — Causes missed correlations when tokens contain URL-special characters.

`searchInRequest` uses `String.includes(value)` for exact matching. If a CSRF token contains `/` or `+` characters, it appears URL-encoded (`%2F`, `%2B`) in subsequent request URLs and form bodies. The exact match fails.

**Fix in `searchInRequest`:**

```typescript
function searchInRequest(entry: HarEntry, value: string): boolean {
  const encodedValue = encodeURIComponent(value);
  const searchTargets = [entry.url.full, entry.url.query];
  // Check both raw and encoded forms
  for (const target of searchTargets) {
    if (target.includes(value) || target.includes(encodedValue)) return true;
  }
  // ... rest of function
}
```

### 4.3 Replacement Ordering — Substring Overlap Risk

**Severity: Medium** — Can corrupt JMX output when one correlated value is a substring of another.

`applyReplacements` iterates correlations in array order. If `originalValue` "abc123" is correlated as `token_1` and "abc123def456" is correlated as `token_2`, replacing "abc123" first will corrupt "abc123def456" into "${token_1}def456", and the second replacement for the full value will fail.

**Fix:** Sort correlations by `originalValue.length` descending before replacement:

```typescript
const sortedCorrelations = [...correlations]
  .filter(c => c.targetRequests.includes(entryIndex))
  .sort((a, b) => b.originalValue.length - a.originalValue.length);
```

### 4.4 Framework Field Correlation — Placeholder Pattern in Generated JMX

**Severity: Medium** — Framework fields that are detected but not auto-correlated produce a non-functional extractor.

Lines 530-536 of `correlation-detector.ts` create a `CorrelationResult` with `pattern: "(needs correlation - Django dynamic field, found in 3 request(s))"`. This placeholder string is inserted into the JMX as a `RegexExtractor` pattern — which will always fail at JMeter runtime.

**Fix:** Either:
- (A) Generate a working extractor pattern based on the framework field name: `name="${fieldName}"[^>]*value="(.+?)"` for HTML hidden fields, or `"${fieldName}"\s*:\s*"(.+?)"` for JSON bodies.
- (B) Don't emit a `CorrelationResult` for unresolved framework fields. Instead, emit them as issues only (severity: warning), which is where they surface in the UI anyway.

Option B is safer — it prevents broken extractors in the generated JMX while still alerting the user.

---

## 5. Long-Term Refactoring Plan

### 5.1 Phase 1 — Typed JMX Builder (1-2 weeks)

Replace the string array approach with a typed node tree:

```typescript
interface JmxElement {
  tag: string;
  attributes: Record<string, string>;
  properties: JmxProperty[];
  children: JmxElement[];
}

type JmxProperty =
  | { type: 'string'; name: string; value: string }
  | { type: 'bool'; name: string; value: boolean }
  | { type: 'int'; name: string; value: number }
  | { type: 'collection'; name: string; items: JmxElement[] };
```

A single `renderElement()` function handles:
- hashTree pairing (automatic — every element gets a hashTree containing its children)
- XML escaping (applied at render time, not at construction time)
- Indentation (computed from depth, not hardcoded)
- Structural validation (a child must be a valid JMeter element type)

The existing `buildHttpRequest`, `buildExtractor`, `buildResponseAssertion` functions would return `JmxElement` instead of `string`. Migration is incremental per-function.

### 5.2 Phase 2 — Indexed Correlation Engine (1 week)

Replace the O(n²×m) forward search with an indexed approach:

1. Pre-build a text index: for each request, concatenate all searchable content (URL + headers + body) into a single string, stored in a `Map<number, string>`.
2. For each candidate value, iterate only over requests with index > sourceIndex and do a single `includes()` call against the concatenated string.
3. Add URL-encoded variant matching.
4. Sort correlations by value length descending before the replacement phase.

### 5.3 Phase 3 — Worker Thread Pool (1 week)

Move `processHarFile` and `processJmxFile` to a `worker_threads` pool:

```typescript
import { Worker } from 'worker_threads';

const pool = new WorkerPool('har-converter-worker.ts', { maxWorkers: 3 });

// In route handler:
pool.execute({ filePath, name, userId, generationId, options });
```

This completely isolates CPU-intensive conversion from the Express event loop, eliminates event-loop-starvation risk, and enables true parallel processing.

### 5.4 Phase 4 — Streaming HAR Parser (2 weeks)

For HAR files >20MB, replace `JSON.parse` with a streaming parser (e.g., `stream-json`):

```typescript
import { parser } from 'stream-json';
import { streamArray } from 'stream-json/streamers/StreamArray';

const pipeline = fs.createReadStream(filePath)
  .pipe(parser())
  .pipe(streamArray());

pipeline.on('data', ({ value: entry }) => {
  // Process entry incrementally
});
```

This reduces peak memory from ~4x file size to ~2x single entry size. Requires restructuring the pipeline to process entries incrementally rather than as a complete array.

---

## 6. Enterprise Upgrade Roadmap

### 6.1 Structured Telemetry

Emit metrics at each pipeline stage:

| Metric | Source | Purpose |
|---|---|---|
| `har.parse.duration_ms` | har-parser | Identify slow file reads |
| `har.parse.entry_count` | har-parser | Capacity planning |
| `filter.removed_count` | request-filter | Filter effectiveness |
| `correlation.candidate_count` | correlation-detector | Detection health |
| `correlation.matched_count` | correlation-detector | Hit rate |
| `correlation.duration_ms` | correlation-detector | Performance regression detection |
| `jmx.build.duration_ms` | jmx-builder | Build time monitoring |
| `jmx.build.output_bytes` | jmx-builder | Output size monitoring |
| `quality.score` | quality-scorer | Conversion quality tracking |

### 6.2 Test Fixture Matrix

Minimum HAR fixtures needed for comprehensive coverage:

| Fixture | Tests |
|---|---|
| API-only HAR (REST/JSON) | JSON path extraction, JWT correlation, Bearer token detection |
| MPA HAR (HTML forms) | Hidden field extraction, meta tag extraction, form-urlencoded params |
| SPA HAR (XHR/fetch) | Header-based correlation, dynamic URL segments |
| Framework-specific: ASP.NET | ViewState, RequestVerificationToken, EventValidation |
| Framework-specific: Django | csrfmiddlewaretoken, csrftoken cookie |
| Framework-specific: Rails | authenticity_token |
| Redirect-heavy HAR | 301/302 chain consolidation |
| Large HAR (1000+ entries) | Performance, memory, timeout behavior |
| Adversarial HAR | Missing fields, empty bodies, malformed URLs, base64 content |
| Login flow HAR | Username/password detection, parameterization, CSV generation |

### 6.3 Modularization

Current module boundaries are well-drawn. One structural improvement:

Extract the `isFrameworkField` / `FRAMEWORK_DYNAMIC_FIELDS` / `FRAMEWORK_DYNAMIC_FIELD_NAMES` registries into a shared `framework-registry.ts` module. Currently these are defined separately in `correlation-detector.ts`, `parameterization-detector.ts`, and `jmx-analyzer.ts` and must be kept in sync manually. A single source of truth eliminates drift risk.

---

## 7. Competitive Assessment

### 7.1 Comparison to JMeter's HTTP(S) Test Script Recorder

| Aspect | JMeter Proxy Recorder | PerfHub HAR Converter |
|---|---|---|
| Setup complexity | Requires JMeter install, proxy config, browser cert | Zero-install, drag-drop HAR file |
| Auto-correlation | None (manual post-recording work) | Automatic with 5+ pattern types |
| Framework detection | None | 15+ framework-specific patterns |
| Quality scoring | None | 0-100 with 7-category breakdown |
| Output quality | Raw recorded script with all static resources | Filtered, grouped, correlated, parameterized |

**PerfHub is stronger** in every dimension except one: JMeter's proxy recorder captures WebSocket frames and can record non-browser traffic. PerfHub's HAR-based approach is limited to what browsers export.

### 7.2 Comparison to BlazeMeter Chrome Extension

| Aspect | BlazeMeter Extension | PerfHub HAR Converter |
|---|---|---|
| Correlation | Basic (session cookies only) | Advanced (JSON, HTML, headers, regex patterns) |
| Parameterization | Manual | Automatic credential detection |
| Framework awareness | None | 15+ platform-specific detection |
| Output format | JMX (requires BlazeMeter account for full features) | JMX (no external dependency) |
| Offline capability | Requires BlazeMeter cloud | Fully self-hosted |

**PerfHub is stronger** on correlation depth, parameterization automation, and self-hosted operation. BlazeMeter has better browser integration (captures directly during browsing, no HAR export step).

### 7.3 Comparison to JMeter Correlation Recorder Plugin

| Aspect | Correlation Recorder Plugin | PerfHub Correlation Engine |
|---|---|---|
| Detection method | Rule-based templates per application | Pattern-based + framework registry |
| Rule authoring | Manual XML template creation | Automatic detection |
| Supported extractors | Regex, boundary | JSON path, regex, header |
| Token detection | Template-driven (must know the app) | Pattern-driven (works on unknown apps) |

**PerfHub is stronger** for first-encounter scenarios (unknown applications). The Correlation Recorder Plugin is stronger when you have pre-built templates for a specific application (e.g., SAP, Oracle).

### 7.4 What Would Elevate to Enterprise-Grade

1. **Rule library import/export** — Allow saving correlation rules for specific applications and sharing them across teams. This closes the gap with template-based tools.
2. **Diff/comparison mode** — Compare two HAR conversions to see what changed between application versions (new dynamic values, removed endpoints).
3. **JMX round-trip editing** — After conversion, allow users to modify the JMX structure (reorder requests, add assertions, edit extractors) in the UI before downloading.
4. **Distributed JMeter integration** — Auto-configure the generated JMX for distributed execution with PerfHub's existing test execution engine.
5. **HAR capture proxy** — A built-in browser proxy that captures HAR in real-time, eliminating the export-then-upload step.
