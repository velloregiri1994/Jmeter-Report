# Running External JMeter Tests with PerfHub

This guide explains how to run JMeter tests on your local machine or CI/CD pipeline and send live metrics to PerfHub for real-time monitoring and reporting.

## Overview

PerfHub provides an InfluxDB-compatible endpoint that receives metrics from JMeter's Backend Listener. This allows you to:
- Run JMeter tests anywhere (local machine, CI/CD, dedicated load generators)
- See live metrics in PerfHub's dashboard in real-time
- Generate reports and track SLA violations
- Keep historical test data for comparison

## Prerequisites

1. JMeter 5.0 or later installed
2. Access to your PerfHub server
3. An ingest token (created via Admin UI or environment variable)

---

## Step 1: Create an Ingest Token

You have two options to authenticate external metrics:

### Option A: Create Token via Admin UI (Recommended)

1. Log into PerfHub as admin
2. Go to **Admin Settings** → **Ingest Tokens**
3. Click **Create Token**
4. Give it a name (e.g., "JMeter Token")
5. **Copy the token immediately** - it won't be shown again!

### Option B: Use Environment Variable (Alternative)

Set the `INGEST_SECRET` environment variable on your PerfHub server:

```bash
# Example: Set in your environment
export INGEST_SECRET="your-secure-secret-here"
```

Or add it to your `.env` file:
```
INGEST_SECRET=your-secure-secret-here
```

**Note:** Choose a strong, random secret (e.g., `openssl rand -hex 32`).

---

## Step 2: Add Backend Listener to JMeter Test Plan

1. Open your JMeter test plan (`.jmx` file)
2. Right-click on **Thread Group** → **Add** → **Listener** → **Backend Listener**
3. Configure the Backend Listener with these settings:

### Backend Listener Configuration

| Parameter | Value |
|-----------|-------|
| **Backend Listener implementation** | `org.apache.jmeter.visualizers.backend.influxdb.InfluxdbBackendListenerClient` |
| **influxdbUrl** | `http://YOUR_PERFHUB_SERVER:5000/api/influxdb/write` |
| **application** | Your test name (e.g., `MyLoadTest`) |
| **measurement** | `jmeter` |
| **summaryOnly** | `false` (recommended for detailed metrics) |
| **samplersRegex** | `.*` (or specific sampler pattern) |
| **percentiles** | `50;90;95;99` |
| **testTitle** | Optional: descriptive title |
| **eventTags** | Optional: additional tags |

### Authentication Header

Add a custom parameter to include the authentication token:

| Name | Value |
|------|-------|
| `influxdbToken` | Your ingest token (from Admin UI or INGEST_SECRET) |

**Alternative:** If your JMeter version doesn't support `influxdbToken`, you can use HTTP headers directly by modifying the URL or using a custom implementation.

---

## Step 3: Example JMeter Backend Listener XML

Add this to your `.jmx` file inside the `<hashTree>` under your Thread Group:

```xml
<BackendListener guiclass="BackendListenerGui" testclass="BackendListener" testname="PerfHub Backend Listener" enabled="true">
  <elementProp name="arguments" elementType="Arguments">
    <collectionProp name="Arguments.arguments">
      <elementProp name="influxdbMetricsSender" elementType="Argument">
        <stringProp name="Argument.name">influxdbMetricsSender</stringProp>
        <stringProp name="Argument.value">org.apache.jmeter.visualizers.backend.influxdb.HttpMetricsSender</stringProp>
      </elementProp>
      <elementProp name="influxdbUrl" elementType="Argument">
        <stringProp name="Argument.name">influxdbUrl</stringProp>
        <stringProp name="Argument.value">http://YOUR_PERFHUB_SERVER:5000/api/influxdb/write</stringProp>
      </elementProp>
      <elementProp name="application" elementType="Argument">
        <stringProp name="Argument.name">application</stringProp>
        <stringProp name="Argument.value">MyLoadTest</stringProp>
      </elementProp>
      <elementProp name="measurement" elementType="Argument">
        <stringProp name="Argument.name">measurement</stringProp>
        <stringProp name="Argument.value">jmeter</stringProp>
      </elementProp>
      <elementProp name="summaryOnly" elementType="Argument">
        <stringProp name="Argument.name">summaryOnly</stringProp>
        <stringProp name="Argument.value">false</stringProp>
      </elementProp>
      <elementProp name="samplersRegex" elementType="Argument">
        <stringProp name="Argument.name">samplersRegex</stringProp>
        <stringProp name="Argument.value">.*</stringProp>
      </elementProp>
      <elementProp name="percentiles" elementType="Argument">
        <stringProp name="Argument.name">percentiles</stringProp>
        <stringProp name="Argument.value">50;90;95;99</stringProp>
      </elementProp>
      <elementProp name="testTitle" elementType="Argument">
        <stringProp name="Argument.name">testTitle</stringProp>
        <stringProp name="Argument.value">Performance Test Run</stringProp>
      </elementProp>
      <elementProp name="influxdbToken" elementType="Argument">
        <stringProp name="Argument.name">influxdbToken</stringProp>
        <stringProp name="Argument.value">YOUR_INGEST_TOKEN</stringProp>
      </elementProp>
    </collectionProp>
  </elementProp>
  <stringProp name="classname">org.apache.jmeter.visualizers.backend.influxdb.InfluxdbBackendListenerClient</stringProp>
</BackendListener>
<hashTree/>
```

**Replace:**
- `YOUR_PERFHUB_SERVER` with your PerfHub server address
- `MyLoadTest` with your test name
- `YOUR_INGEST_TOKEN` with your ingest token (from Admin UI or INGEST_SECRET env var)

---

## Step 4: Run Your JMeter Test

Execute your JMeter test from the command line or GUI:

```bash
# Command line (recommended for load tests)
jmeter -n -t your-test-plan.jmx -l results.jtl

# Or with explicit properties
jmeter -n -t your-test-plan.jmx \
  -Jinfluxdb.url=http://YOUR_PERFHUB_SERVER:5000/api/influxdb/write \
  -Japplication=MyLoadTest \
  -l results.jtl
```

---

## Step 5: View Results in PerfHub

1. Open PerfHub in your browser
2. Navigate to **Executions** page
3. You'll see a new execution named `InfluxDB: MyLoadTest` (based on your `application` name)
4. Click on the execution to see:
   - Real-time response time graphs
   - Throughput metrics
   - Active threads
   - Error counts and messages
   - Transaction-level details

---

## How It Works

1. JMeter's Backend Listener sends metrics to PerfHub every 5 seconds (default)
2. PerfHub automatically creates an execution when it receives the first metric
3. Metrics are stored and broadcast via WebSocket to connected clients
4. The UI updates in real-time showing live performance data
5. After 60 seconds of inactivity, the execution is marked as completed

---

## Advanced: Linking to an Existing Execution

If you want to send metrics to a specific execution ID (e.g., one you created via the PerfHub UI):

1. Create a schedule/execution in PerfHub first
2. Note the execution ID (e.g., `EXE-20260122-143000-ABCD`)
3. Set the `testTitle` parameter to the execution ID in your Backend Listener

---

## Troubleshooting

### Metrics not appearing in PerfHub

1. **Check tokens are configured:**
   ```bash
   # Verify via API:
   curl http://YOUR_PERFHUB_SERVER:5000/api/ingest/status
   # Should show: "authConfigured": true
   ```

2. **Verify network connectivity:**
   ```bash
   curl -X POST http://YOUR_PERFHUB_SERVER:5000/api/influxdb/write \
     -H "Authorization: Token YOUR_INGEST_TOKEN" \
     -d "jmeter,application=test responseTime=100 $(date +%s)000000000"
   ```

3. **Check JMeter logs for errors:**
   Look for connection errors or authentication failures in JMeter's log.

### Authentication errors (401/403)

- Ensure the `influxdbToken` matches your ingest token exactly
- Check for trailing whitespace in the token
- Verify the Authorization header format: `Token <token>` or `Bearer <token>`

### Execution not completing

Executions auto-complete after 60 seconds of inactivity. If your test has gaps longer than 60 seconds between samples, you may see multiple executions created.

---

## API Reference

### POST /api/influxdb/write

Accepts InfluxDB line protocol format.

**Headers:**
- `Authorization: Token <ingest_token>` or `Bearer <ingest_token>`
- Or: `X-Ingest-Token: <ingest_token>`
- `Content-Type: text/plain`

**Body (InfluxDB Line Protocol):**
```
jmeter,application=MyTest,transaction=HomePage avg=150.5,count=100,countError=2 1674567890000000000
```

**Expected Fields:**
- `avg`, `mean`, `meanAT` - Average response time (ms)
- `hit`, `count` - Request count / throughput
- `startedT`, `activeThreads` - Active thread count
- `countError`, `errorCount` - Error count
- `pct50`, `pct90`, `pct95`, `pct99` - Percentiles

**Expected Tags:**
- `application` or `testName` - Test identifier (required)
- `transaction` - Sampler/transaction name
- `statut` - Status (ok, ko)

---

## Best Practices

1. **Use descriptive application names** - Makes it easy to find tests in PerfHub
2. **Set summaryOnly=false** - Gets detailed per-sampler metrics
3. **Run JMeter in non-GUI mode** - Better performance for load tests
4. **Monitor PerfHub during tests** - Catch issues early with real-time visibility
5. **Configure SLAs in PerfHub** - Get automatic violation alerts
