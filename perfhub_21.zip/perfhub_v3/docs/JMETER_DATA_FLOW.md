# JMeter to PerfHub Data Flow Architecture

## 🔄 Complete Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│                         JMETER TEST EXECUTION                          │
│                                                                         │
│  ┌────────────────────────────────────────────────────────────────┐    │
│  │  Local Machine / Server / Docker / CI/CD Pipeline             │    │
│  │                                                                │    │
│  │  1. JMeter CLI: jmeter -n -t script.jmx -l results.jtl      │    │
│  │     - Executes test plan with configured threads & duration  │    │
│  │     - Generates JTL (Java Test Language) results file        │    │
│  │                                                                │    │
│  │  2. JTL File (Final Results)                                  │    │
│  │     - CSV format with columns:                               │    │
│  │       * timeStamp, elapsed, label, success, failureMessage  │    │
│  │     - One row per request                                    │    │
│  │     - Generated during test execution                        │    │
│  └────────────────────────────────────────────────────────────────┘    │
│                           ↓↓↓                                           │
└─────────────────────────────────────────────────────────────────────────┘

                    ┌─────────────────────┐
                    │   PERFHUB SERVER    │
                    └─────────────────────┘
                            ↓
    ┌───────────────────────┬────────────────────┬───────────────────┐
    │                       │                    │                   │
    ↓                       ↓                    ↓                   ↓
┌─────────────────┐  ┌────────────────┐  ┌────────────────┐  ┌──────────┐
│  LOCAL EXECUTION│  │ EXTERNAL       │  │  WEBSOCKET     │  │  EXTERNAL
│  METRICS        │  │ JMETER METRICS │  │  BROADCAST     │  │  INFLUXDB
│  (Server-side)  │  │ (Via ingest)   │  │ (UI updates)   │  │ (optional)
└─────────────────┘  └────────────────┘  └────────────────┘  └──────────┘

    1. INTERNAL EXECUTION   2. EXTERNAL INGEST   3. UI UPDATES        4. STORAGE
       (if run on server)      (CI/CD pipelines)   (Clients)          (Grafana)
       
       │                      │                    │                   │
       └──────────────────────┴────────────────────┴───────────────────┘
                                     ↓
                    ┌────────────────────────────────┐
                    │   DATA PROCESSING & STORAGE    │
                    │                                │
                    │  • Parse metrics               │
                    │  • Calculate aggregates        │
                    │  • Update live metrics object  │
                    │  • Store in PostgreSQL         │
                    │  • (Optional) Forward to ext   │
                    │    InfluxDB for Grafana       │
                    └────────────────────────────────┘
                                     ↓
                    ┌────────────────────────────────┐
                    │   POSTGRESQL DATABASE          │
                    │                                │
                    │  testExecutions table:         │
                    │  • id (execution ID)           │
                    │  • status                      │
                    │  • resultSummary (JSON)        │
                    │  • liveMetrics (JSON)          │
                    │  • startTime, endTime          │
                    │                                │
                    │  testMetrics table:            │
                    │  • Time-series metrics         │
                    │  • One row per metric point    │
                    └────────────────────────────────┘
                                     ↓
       ┌─────────────────────────────┬──────────────────┐
       │                             │                  │
       ↓                             ↓                  ↓
   ┌─────────────┐          ┌──────────────────┐   ┌──────────────┐
   │  EXECUTION  │          │ EXTERNAL INFLUXDB│   │  GRAFANA     │
   │   DETAIL    │          │                  │   │  DASHBOARDS  │
   │   PAGE      │          │ (if configured)  │   │              │
   │             │          │                  │   │ • Live Test  │
   │ Shows:      │          │ stores metrics   │   │ • Trend Test │
   │ • Results   │          │ for long-term    │   │              │
   │ • Live      │          │ retention &      │   │ Queries:     │
   │   metrics   │          │ Grafana viz      │   │ • avg RT     │
   │ • Charts    │          │                  │   │ • throughput │
   │ • SLA check │          │                  │   │ • errors     │
   └─────────────┘          └──────────────────┘   └──────────────┘
```

---

## 📡 Two Data Flow Paths

### Path 1: **Internal JMeter Execution** (Server-Side)
When JMeter runs on the PerfHub server:

```
JMeter Process (spawned by worker.ts)
    │
    ├─ Writes JTL file to /tmp/jmeter-results-{id}.jtl
    │
    └─ Every 3 seconds (METRIC_UPDATE_INTERVAL_MS = 3000):
       │
       ├─ updateMetricsFromJTL() reads JTL file
       │  ├─ Parses new lines since last read
       │  ├─ Calculates aggregates (avg, p50, p90, p95, p99)
       │  ├─ Groups by transaction label
       │  └─ Tracks: count, totalResponseTime, errorCount, responseTimes[]
       │
       ├─ Calls storage.addLiveMetric()
       │  └─ Updates liveMetrics object in testExecutions table
       │
       ├─ Broadcasts via WebSocket (broadcastExecutionUpdate)
       │  └─ Sends to all connected UI clients
       │
       └─ Stores time-series metrics
          └─ Inserts rows into testMetrics table
```

**File:** `server/worker.ts` (lines 570-800)  
**Key Function:** `updateMetricsFromJTL()`

---

### Path 2: **External Ingest API** (CI/CD Integration)
When tests run in CI/CD pipelines and push metrics:

```
External Test Runner (Jenkins, GitHub Actions, etc.)
    │
    ├─ JMeter/K6/LoadRunner runs
    │
    ├─ Test completes with results file
    │
    └─ Push metrics via REST API:
       │
       ├─ Single Metric:
       │  POST /api/ingest/metrics
       │  {
       │    "executionId": "EXEC-...",
       │    "responseTime": 123,
       │    "throughput": 45.6,
       │    "activeThreads": 10,
       │    "errorCount": 2,
       │    "transactionLabel": "Login"
       │  }
       │
       ├─ Batch Metrics:
       │  POST /api/ingest/metrics/batch
       │  {
       │    "executionId": "EXEC-...",
       │    "metrics": [
       │      { "responseTime": 123, ... },
       │      { "responseTime": 456, ... }
       │    ]
       │  }
       │
       └─ Flow to PerfHub:
          │
          ├─ Routes to POST /api/ingest/metrics (ingest-routes.ts)
          │
          ├─ Validate ingest token
          │
          ├─ Find execution by ID
          │
          ├─ Update liveMetrics:
          │  ├─ Append to avgResponseTime[]
          │  ├─ Append to throughput[]
          │  ├─ Append to activeThreads[]
          │  ├─ Rotate arrays (keep last 100 points)
          │  └─ Update timestamps[]
          │
          ├─ Store in testMetrics table
          │
          └─ Broadcast via WebSocket
```

**File:** `server/ingest-routes.ts` (lines 180-350)  
**Key Endpoints:**
- `POST /api/ingest/metrics` - Single metric
- `POST /api/ingest/metrics/batch` - Batch metrics

---

## 🔀 Data Structure: From JMeter to PostgreSQL

### JTL File Format (CSV)
```csv
timeStamp,elapsed,label,responseCode,responseMessage,threadName,dataType,success,failureMessage,bytes,sentBytes,grpThreads,allThreads,Latency,Connect
1705664400000,123,Login,200,,Thread Group 1-1,text,true,,1024,512,10,10,45,23
1705664401000,456,Checkout,200,,Thread Group 1-2,text,false,Connection timeout,0,0,10,10,200,100
```

### PostgreSQL: testExecutions.liveMetrics (JSON)
```json
{
  "avgResponseTime": [123, 120, 125, ...],
  "throughput": [10.5, 11.2, 10.8, ...],
  "activeThreads": [10, 10, 10, ...],
  "errorCount": 3,
  "errorMessages": ["16:05:23: Connection timeout", "16:05:25: Read timeout"],
  "timestamps": ["16:05:20", "16:05:21", "16:05:22", ...],
  "transactionDetails": [
    {
      "label": "Login",
      "count": 100,
      "avg": 123,
      "p50": 110,
      "p90": 500,
      "p95": 750,
      "p99": 900,
      "max": 1000,
      "throughput": 10.5,
      "hitsPerSec": 10,
      "errorRate": 2.0
    },
    {
      "label": "Checkout",
      "count": 50,
      ...
    }
  ],
  "transactionHistory": {
    "Login": {
      "avg": [120, 123, 125, ...],
      "throughput": [10.2, 10.5, 10.8, ...],
      "count": [100, 102, 101, ...],
      "errorRate": [2.0, 2.1, 2.0, ...]
    },
    "Checkout": { ... }
  }
}
```

### PostgreSQL: testMetrics (Time-Series Table)
```
id | executionId | timestamp | responseTime | throughput | activeThreads | errorCount | transactionLabel
1  | 42          | 2026-01-25 16:05:20 | 123        | 10.5       | 10            | 0          | Login
2  | 42          | 2026-01-25 16:05:21 | 125        | 10.8       | 10            | 1          | Login
3  | 42          | 2026-01-25 16:05:20 | 456        | 5.2        | 10            | 0          | Checkout
...
```

---

## 🔐 Authentication & Authorization

### Ingest Token Flow
```
1. Admin creates token in Admin Settings
   └─ Token hash stored in ingestTokens table
   
2. User adds token to external ingest API calls
   └─ Header: X-Ingest-Token: {token}
   
3. PerfHub validates token
   ├─ Hash incoming token
   ├─ Compare with DB hashes
   └─ Return 403 if invalid
```

---

## 📊 Key Metrics Calculated

### Per-Request Level (JTL Parsing)
- **responseTime**: `elapsed` field from JTL
- **success**: `success` field (true/false)
- **errorMessage**: `failureMessage` field

### Per-Interval Aggregates (Every 3-5 seconds)
```javascript
{
  avgResponseTime: Math.round(totalTime / count),
  p50: sortedTimes[Math.floor(count * 0.5)],
  p90: sortedTimes[Math.floor(count * 0.9)],
  p95: sortedTimes[Math.floor(count * 0.95)],
  p99: sortedTimes[Math.floor(count * 0.99)],
  max: sortedTimes[count - 1],
  
  count: requestsInInterval,
  errorRate: (errorCount / count) * 100,
  
  // FIXED: Now uses actual throughput from metric
  throughput: metric.throughput || 0
}
```

### Final Summary (After Test Completion)
- **totalRequests**: Sum of all requests
- **failedRequests**: Count of errors
- **avgResponseTime**: Weighted average across all requests
- **throughput**: totalRequests / testDuration

---

## 🔧 How to Enable Each Path

### Path 1: Server-Side Execution
✅ Default - just run JMeter on PerfHub server
```bash
npm run dev  # Starts worker that polls JTL file
```

### Path 2: External Ingest API
✅ Push from CI/CD pipeline
```bash
curl -X POST http://perfhub:5000/api/ingest/metrics \
  -H "X-Ingest-Token: your-token" \
  -H "Content-Type: application/json" \
  -d '{
    "executionId": "EXEC-...",
    "responseTime": 123,
    "throughput": 45.6,
    "activeThreads": 10
  }'
```

---

## 🐛 Fixed Issues (Recent Updates)

1. **Hardcoded Throughput** (storage.ts)
   - Was: `liveMetrics.throughput.push(1)` ❌
   - Now: `liveMetrics.throughput.push(metric.throughput || 0)` ✅

2. **Missing Transaction History** (storage.ts)
   - Now maintains `transactionHistory` object with per-transaction trends ✅

3. **Incorrect Throughput Calc** (worker.ts)
   - Was: `Math.round(count / 3)` ❌
   - Now: `Math.round((count / 3) * 10) / 10` ✅

4. **Inefficient Array Rotation** (ingest-routes.ts)
   - Was: `slice(-maxPoints)` creating new arrays ❌
   - Now: `shift()` in while loop for FIFO rotation ✅

---

## 📍 File Locations

| Component | File | Lines |
|-----------|------|-------|
| Internal Execution | `server/worker.ts` | 570-800 |
| JTL Parsing | `server/worker.ts` | 600-750 |
| Live Metric Updates | `server/storage.ts` | 426-530 |
| External API Ingest | `server/ingest-routes.ts` | 180-350 |
| WebSocket Broadcast | `server/websocket.ts` | 40-90 |
| Frontend Display | `client/src/components/real-time-metrics.tsx` | - |
| Frontend Dashboard | `client/src/pages/executions/detail.tsx` | - |

---

## 🔄 Execution Lifecycle with Data Flow

```
1. USER CREATES SCHEDULE → Execution queued
2. WORKER POLLS → Finds queued execution
3. EXECUTION STARTS → Broadcasts "running" status
4. METRICS STREAM IN (one of 2 paths)
   ├─ Live metrics accumulate in memory
   ├─ WebSocket broadcasts to UI (every message)
   ├─ Database updates (batched or per-interval)
5. EXECUTION ENDS
   ├─ Final JTL parsed if internal execution
   ├─ Result summary calculated
   ├─ SLA violations checked
   ├─ Execution marked "completed" or "failed"
   ├─ WebSocket notifies UI
   └─ Notifications sent to user
```

