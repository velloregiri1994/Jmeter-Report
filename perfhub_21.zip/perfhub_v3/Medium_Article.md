# I Built an Enterprise Performance Testing Platform From Scratch — Here's How

## The problem that started it all

If you've ever worked in performance testing, you know the pain.

Your JMeter scripts live on someone's laptop. Results are shared as CSV attachments over email. SLA compliance is tracked in a spreadsheet that nobody updates. There's no real-time visibility while a test is running — you kick it off, go get coffee, and come back hoping for the best. And when it's time for a release sign-off? Good luck pulling together a coherent report from five different tools.

I lived this reality for long enough. So I built **PerfHub** — a complete enterprise performance testing platform that handles the entire lifecycle, from script management to stakeholder sign-off, in one self-hosted application.

This article walks through what I built, why I made specific architectural decisions, and what I learned along the way.

---

## What PerfHub Does

At its core, PerfHub is a web application that wraps around Apache JMeter and turns it into an enterprise-grade platform. Think of it as what Jenkins did for CI/CD, but for performance testing.

![PerfHub Dashboard — the central command center showing active tests, pass rate, execution results, and recent test history](screenshots/01_dashboard.png)

Here's the scope:

**Test Management**
- Upload and version JMeter (.jmx) scripts with drag-and-drop
- Manage dependencies (CSV data files, JAR plugins, property files)
- Organize scripts with folders, tags, and favorites
- Define SLA rules directly on scripts (P95 < 500ms, error rate < 1%)
- Set baseline runs for automatic regression detection

![Script Management — upload JMeter scripts, manage protocols, and organize with folders](screenshots/02_scripts.png)

![Script Details — view uploaded JMX files, manage test dependencies (CSV, JSON), and JAR plugin dependencies](screenshots/03_script_details.png)

**Test Scheduling**
- One-time or CRON-based recurring schedules
- Override virtual users, ramp-up, and duration per schedule
- Calendar view for team coordination
- Release tagging for version tracking

![Schedule & Calendar — schedule tests with environment tags, view last run results, and trigger runs directly](screenshots/04_schedule_calendar.png)

**Live Test Execution**
- Real-time WebSocket streaming of response times, throughput, error rates, and active threads
- Per-transaction metrics during execution — not just aggregate numbers
- Auto-abort rules that stop tests when thresholds breach for a sustained period
- HTTP polling fallback if WebSocket connection drops

![Executions — command center showing all test runs with status, duration, and quick actions](screenshots/05_executions.png)

**Results Analysis**
- Seven anomaly detection algorithms that identify issues automatically
- Baseline deviation reports showing exact percentage changes per metric
- SLA evaluation with pass/fail verdicts
- Workload achievement analysis (did you hit your target throughput?)

![Execution Results Summary — total requests, pass/fail counts, response times, throughput, percentiles, and per-transaction breakdown with SLA status](screenshots/06_execution_results.png)

![Performance Charts — latency stability, error rate over time, throughput-latency correlation, active users & response trend, plus transaction bottleneck analysis](screenshots/07_execution_charts.png)

![Advanced Charts — response time & throughput overlays, error rate & thread correlation, machine-level CPU and memory monitoring](screenshots/08_execution_advanced_charts.png)

**Reporting & Sign-Off**
- Auto-generated HTML reports after every execution
- Executive completion reports consolidating multiple test runs
- Multi-step approval workflow (Reviewer → Approver)
- Professional Word document (.docx) export

![HTML Reports — preview, download, and manage reports for every execution with custom comments](screenshots/15_html_reports.png)

**Distributed Testing & Remote Monitoring**
- Trigger tests on remote machines and monitor them centrally in real-time
- Remote agents stream metrics back to PerfHub via a secure Ingest API
- GZIP-compressed sample ingestion for high-volume load tests
- Agent heartbeat monitoring with health status tracking
- Abort remote tests from the PerfHub UI — the signal propagates to agents
- Unified dashboard view aggregating data from multiple load generators

**CI/CD Integration**
- Scoped API tokens for Jenkins, GitHub Actions, GitLab CI
- Quality gate API returning PASS/FAIL based on SLA rules
- Webhook notifications to Slack, Microsoft Teams, PagerDuty

**Three Accelerator Tools**
- HAR-to-JMeter script converter with quality scoring
- Test data generator with 60+ correlated data types
- Workload calculator bridging business requirements to thread configuration

---

## The Tech Stack

Here's what I chose and why.

**Frontend: React 18 + TypeScript + Tailwind CSS + shadcn/ui**

I went with React because the dashboard needs to handle real-time data updates efficiently. TypeScript was non-negotiable for a project this size — catching type errors at compile time saved me countless debugging sessions. Tailwind CSS with shadcn/ui gave me a professional look without spending weeks on custom component design. The result is a UI that feels like a modern SaaS product, not an internal tool from 2015.

**Backend: Node.js + Express + TypeScript**

Express gave me the flexibility I needed for a complex API surface. The backend handles REST endpoints, WebSocket connections, JMeter process management, report generation, and webhook dispatching. TypeScript on both ends means shared type definitions between client and server — when I change an API response shape, the compiler tells me every place that breaks.

**Database: PostgreSQL + Drizzle ORM**

PostgreSQL handles everything from user sessions to execution results with JSONB columns storing complex nested data like transaction details and anomaly reports. Drizzle ORM was a deliberate choice over Prisma — it's lighter, generates cleaner SQL, and gives me more control over queries without sacrificing type safety.

**Real-Time: WebSocket**

Live metrics streaming was the most technically challenging feature. When a JMeter test runs, the backend spawns a child process, parses the JTL output line by line, aggregates samples into 1-second windows, and pushes snapshots to every connected WebSocket client. I also built an HTTP polling fallback that activates automatically if the WebSocket connection drops — because in a real enterprise environment, proxies and firewalls can break WebSocket connections.

---

## Deep Dive: Features I'm Most Proud Of

### 1. Anomaly Detection Engine

This is where PerfHub goes beyond being a JMeter wrapper. Instead of just showing numbers, it analyzes them. The system runs seven detection algorithms:

- **Baseline Deviation** — Compares every metric against your designated "golden run"
- **Tail Latency Spread** — Flags when the gap between median and P99 response time is abnormally large (indicates inconsistent performance)
- **Throughput Saturation** — Detects when the system hits a throughput ceiling despite increasing load
- **Error Step Change** — Identifies sudden jumps in error rates (not gradual increases)
- **Transaction Regression** — Finds individual API endpoints that degraded while others stayed stable
- **Time Window Hotspot** — Spots performance issues concentrated in specific time windows (like the first 30 seconds of ramp-up)
- **Gradual Degradation** — Detects slow, steady decline over the test duration (memory leaks, connection pool exhaustion)

These run both in real-time during test execution and as post-hoc analysis on completed results. The goal is to tell engineers *what* went wrong, not just *that* something went wrong.

### 2. HAR-to-JMeter Script Converter

Creating JMeter scripts is the biggest bottleneck in performance testing. You record a user journey, export it, and then spend hours manually correlating session tokens, parameterizing credentials, and adding think times.

The converter automates all of that:

1. Upload a HAR file from Chrome DevTools
2. It filters out noise (static assets, analytics beacons, preflight requests)
3. Groups requests into logical transaction controllers
4. Detects dynamic values (session tokens, CSRF tokens, OAuth tokens) and creates extractors
5. Identifies credentials and generates a sample CSV data file
6. Injects best practices (Cookie Manager, Header Manager, think times)
7. Scores the result on a 0–100 quality scale

The quality score breaks down into weighted categories: correlation completeness (25%), transaction grouping (15%), static content removal (15%), parameterization (15%), best practices (10%), assertions (10%), and think times (10%). It tells you exactly how production-ready your script is before you run your first test.

![Script Converter & Analyzer — a real HAR file converted to JMeter script with 97/100 quality score, 6 auto-detected correlations, 7 transaction groups, and 49 API requests](screenshots/10_script_converter.png)

### 3. Test Data Generator

Performance tests need realistic data. You can't load test with "user1, user2, user3" — you need thousands of correlated records where the email matches the name, the city matches the state and zip code, and the credit card passes a Luhn checksum.

The generator creates all of this in the browser. No data leaves your machine, which matters when you're generating test data with PII-like fields. It supports 60+ data types across 9 categories (Personal, Location, Finance, Technical, Business, Dates, Numbers, Text, Custom), and the key feature is intelligent correlation — within each row, all fields are contextually linked.

You can generate up to 1 million rows, with live preview as you configure columns. Custom types include weighted enums (e.g., Active:70, Inactive:30 for realistic status distributions) and pattern masks (# for digits, ? for letters).

![Test Data Generator — configure columns with 60+ data types, live preview with correlated data (names match emails), and one-click CSV download](screenshots/11_test_data_generator.png)

### 4. Workload Calculator

"How many virtual users do I need to simulate 10,000 transactions per hour?"

This question comes up in every performance test planning session, and most teams answer it with guesswork. The workload calculator takes your business requirements (target TPH), performance assumptions (expected response time, think time), and test configuration (transactions per iteration) and calculates the exact thread count and pacing.

It goes further with a distributed load calculator that estimates how many machines you need based on hardware profiles and script complexity multipliers. And after the test runs, the workload achievement module compares your targets against actual results, explaining exactly why you missed (or hit) your throughput goals.

![Workload Model Calculator — input parameters, calculation flow diagram, and formulas reference for Single Flow, Weighted Mix, and Distributed Load modes](screenshots/09_workload_calculator.png)

### 5. Distributed Testing & Remote Monitoring

In real-world performance testing, a single machine can't generate enough load. You need 500, 1,000, or 5,000 virtual users — and that means distributing the load across multiple machines.

PerfHub handles this with a remote agent architecture. Here's how it works:

1. **Generate an Ingest Token** in the PerfHub admin panel
2. **Deploy JMeter agents** on remote machines (Linux servers, cloud VMs, on-prem hardware) with the PerfHub Backend Listener plugin
3. **Start the test** from the remote machine — the agent authenticates with the ingest token and begins streaming samples
4. **Monitor everything centrally** — all metrics from all agents flow into PerfHub's aggregator and appear on a single unified dashboard

The key insight is that remote agents are lightweight. They just run JMeter and push data. All aggregation, anomaly detection, SLA evaluation, and visualization happens on the PerfHub server. This means you can spin up 10 load generators on AWS, run a massive test, and watch the combined results in real-time from your browser.

The system supports GZIP-compressed sample streaming for high-volume tests (thousands of requests per second generate a lot of metric data). Agents send heartbeats to confirm they're alive, and PerfHub tracks each agent's health — active execution count, total samples ingested, and last heartbeat timestamp.

One of my favorite details: if you cancel a test from the PerfHub UI, the abort signal propagates to every remote agent through the heartbeat response. The agents check for the abort flag on each heartbeat and shut down gracefully. No SSH-ing into servers to kill processes.

### 6. Performance Comparison & Trends

Two of the most powerful analytics features are side-by-side test comparison and performance trend tracking.

The comparison tool lets you select any two test executions as baseline (A) and compare (B), then visualizes everything: response time overlays, throughput charts, a radar chart for overall performance shape, and a detailed regression heatmap showing exactly which transactions improved, regressed, or stayed unchanged — down to Avg, P90, P95, P99, and TPS deltas.

![Comparison Overview — baseline vs compare with response time overlay, throughput overlay, and summary cards showing regressions](screenshots/12_comparison_overview.png)

![Comparison Details — transaction-level regression heatmap with color-coded severity, per-metric deltas, and performance radar chart](screenshots/13_comparison_details.png)

The trends page tracks performance over time across all executions, with automated insights ("slowest transaction: Proceed to Checkout averaging 729ms"), regression lines, and forecasting.

![Performance Trends — response time trend with R² fit, automated insights, forecast predictions, and script performance breakdown table](screenshots/14_trends.png)

### 7. Test Execution Tracker

The tracker gives you a single-pane view of all completed test executions across every project, environment, and release. Filter by date range, export to CSV for stakeholder reporting, and see at-a-glance metrics for every run.

![Test Execution Tracker — all completed tests with project, environment, volume, duration, response times, throughput, error rates, and trend indicators](screenshots/16_tracker.png)

### 8. CI/CD Quality Gates

This is where PerfHub fits into modern delivery pipelines. You generate a scoped API token, add three API calls to your Jenkins/GitHub Actions pipeline, and every build gets automatically performance-tested.

The quality gate evaluates all SLA rules and returns a single verdict: PASS or FAIL. No human interpretation needed. Your pipeline stops if performance degrades — the same way it stops if unit tests fail.

---

## Architecture Decisions I'd Make Differently

**State management**: I used React Query (TanStack Query) for server state, which was the right call. But for some complex UI state (like the live metrics dashboard with multiple interconnected components), I should have reached for Zustand earlier instead of prop drilling.

**Report generation**: The Word document export uses a template-based approach that works but is brittle. If I were starting over, I'd use a headless browser to render the HTML report and convert to PDF/DOCX — more flexible and easier to maintain.

**Testing**: I prioritized shipping features over writing tests. If this were a team project, I'd invest heavily in integration tests for the CI/CD API and WebSocket streaming. The anomaly detection algorithms especially deserve property-based testing.

---

## What I Learned

**1. Real-time systems are harder than they look.** WebSocket connection management, reconnection logic, buffering, backpressure — each of these is a rabbit hole. The polling fallback added significant complexity but was essential for reliability.

**2. Enterprise features matter more than you think.** Role-based access control, audit logging, data retention policies, approval workflows — these aren't exciting to build, but they're often the difference between "cool side project" and "tool my company would actually adopt."

**3. Developer experience compounds.** Shared TypeScript types between client and server, Drizzle's type-safe queries, and Tailwind's utility classes all reduced friction. Over months of development, that friction reduction adds up to weeks of saved time.

**4. Domain knowledge is the real differentiator.** Any competent developer can build a CRUD app with React and Express. What made PerfHub useful is understanding performance testing workflows — knowing that engineers need per-transaction metrics during a running test, or that managers need sign-off reports in Word format.

---

## Numbers

- ~50,000 lines of TypeScript across frontend and backend
- 18+ distinct feature modules
- 3 installer scripts (Linux, macOS, Windows) with auto-detection
- Supports PostgreSQL with configurable data retention
- Role-based access with 3 roles (Admin, Engineer, Manager)
- Full audit trail with IP and user-agent tracking

---

## Try It / Connect

PerfHub is self-hosted — it runs on your infrastructure with your data. No cloud dependency, no vendor lock-in.

I'm currently exploring new opportunities. If you're building something in the performance engineering, DevOps, or platform engineering space — or if you just want to talk about building complex web applications — I'd love to connect.

Find me on LinkedIn or drop a comment below.

---

*Tags: Performance Testing, JMeter, React, Node.js, TypeScript, Full Stack Development, Software Engineering, WebSocket, Enterprise Software, DevOps*
