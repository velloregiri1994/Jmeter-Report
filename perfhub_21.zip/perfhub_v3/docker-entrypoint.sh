#!/bin/bash
# =============================================================================
# PerfHub v3 - Docker Entrypoint
# =============================================================================
# 1. Waits for PostgreSQL to accept connections
# 2. Pushes the Drizzle ORM schema (safe, additive-only)
# 3. Starts the production server
# =============================================================================

set -e

echo "========================================"
echo " PerfHub v3 — Starting up"
echo "========================================"

# ---- Wait for database ----
echo "[entrypoint] Waiting for database connection..."
max_attempts=30
attempt=0

while [ $attempt -lt $max_attempts ]; do
    if node -e "
        const { Pool } = require('pg');
        const pool = new Pool({ connectionString: process.env.DATABASE_URL });
        pool.query('SELECT 1').then(() => { pool.end(); process.exit(0); }).catch(() => { process.exit(1); });
    " 2>/dev/null; then
        echo "[entrypoint] Database is ready!"
        break
    fi
    attempt=$((attempt + 1))
    echo "[entrypoint] Waiting for database... (attempt $attempt/$max_attempts)"
    sleep 2
done

if [ $attempt -eq $max_attempts ]; then
    echo "[entrypoint] ERROR: Could not connect to database after $max_attempts attempts"
    exit 1
fi

# ---- Push schema ----
echo "[entrypoint] Running database schema push..."
npx drizzle-kit push --force 2>&1 || {
    echo "[entrypoint] ERROR: Database schema push failed!"
    exit 1
}
echo "[entrypoint] Database schema is ready!"

# ---- Create runtime directories ----
mkdir -p uploads/scripts uploads/dumps results attached_assets/reports

# ---- Start ----
echo "[entrypoint] Starting PerfHub on port ${PORT:-5000}..."
exec node dist/index.cjs
