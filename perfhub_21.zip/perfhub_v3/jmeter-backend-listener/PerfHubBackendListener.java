package com.perfhub.jmeter;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.visualizers.backend.AbstractBackendListenerClient;
import org.apache.jmeter.visualizers.backend.BackendListenerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.lang.management.ManagementFactory;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class PerfHubBackendListener extends AbstractBackendListenerClient {

    private static final Logger log = LoggerFactory.getLogger(PerfHubBackendListener.class);

    private static final String PARAM_URL = "perfhub.url";
    private static final String PARAM_TOKEN = "perfhub.token";
    private static final String PARAM_RUN_ID = "perfhub.runId";
    private static final String PARAM_TEST_NAME = "perfhub.testName";
    private static final String PARAM_NODE_ID = "perfhub.nodeId";
    private static final String PARAM_BATCH_SIZE = "perfhub.batchSize";
    private static final String PARAM_FLUSH_INTERVAL_MS = "perfhub.flushIntervalMs";
    private static final String PARAM_CONNECT_TIMEOUT_MS = "perfhub.connectTimeoutMs";
    private static final String PARAM_READ_TIMEOUT_MS = "perfhub.readTimeoutMs";
    private static final String PARAM_MAX_RETRIES = "perfhub.maxRetries";
    private static final String PARAM_COLLECT_METRICS = "perfhub.collectSystemMetrics";
    private static final String PARAM_MAX_QUEUE_SIZE = "perfhub.maxQueueSize";
    private static final String PARAM_ABORT_ON_SERVER_SIGNAL = "perfhub.abortOnServerSignal";

    private String url;
    private String token;
    private String runId;
    private String testName;
    private String nodeId;
    private int batchSize;
    private int flushIntervalMs;
    private int connectTimeoutMs;
    private int readTimeoutMs;
    private int maxRetries;
    private boolean collectSystemMetrics;
    private int maxQueueSize;
    private boolean abortOnServerSignal;
    private volatile boolean abortTriggered = false;

    private final AtomicInteger resolvedExecutionId = new AtomicInteger(0);
    private final ConcurrentLinkedQueue<SampleData> queue = new ConcurrentLinkedQueue<>();
    private final AtomicInteger queueSize = new AtomicInteger(0);
    private ScheduledExecutorService scheduler;
    private ExecutorService senderExecutor;
    private final AtomicLong totalSent = new AtomicLong(0);
    private final AtomicLong totalDropped = new AtomicLong(0);
    private final AtomicLong totalErrors = new AtomicLong(0);
    private final AtomicLong lastSuccessfulSend = new AtomicLong(0);
    private final AtomicLong lastDropLogTime = new AtomicLong(0);
    private static final long HEARTBEAT_INTERVAL_MS = 30_000;

    private com.sun.management.OperatingSystemMXBean osMxBean;
    private long prevDiskReadBytes = -1;
    private long prevDiskWriteBytes = -1;
    private long prevDiskTimestamp = -1;

    @Override
    public Arguments getDefaultParameters() {
        Arguments args = new Arguments();
        args.addArgument(PARAM_URL, "https://your-perfhub-url/api/ingest/samples");
        args.addArgument(PARAM_TOKEN, "");
        args.addArgument(PARAM_RUN_ID, "");
        args.addArgument(PARAM_TEST_NAME, "");
        args.addArgument(PARAM_NODE_ID, "");
        args.addArgument(PARAM_BATCH_SIZE, "100");
        args.addArgument(PARAM_FLUSH_INTERVAL_MS, "2000");
        args.addArgument(PARAM_CONNECT_TIMEOUT_MS, "5000");
        args.addArgument(PARAM_READ_TIMEOUT_MS, "10000");
        args.addArgument(PARAM_MAX_RETRIES, "3");
        args.addArgument(PARAM_COLLECT_METRICS, "true");
        args.addArgument(PARAM_MAX_QUEUE_SIZE, "50000");
        args.addArgument(PARAM_ABORT_ON_SERVER_SIGNAL, "true");
        return args;
    }

    @Override
    public void setupTest(BackendListenerContext context) throws Exception {
        url = context.getParameter(PARAM_URL);
        token = context.getParameter(PARAM_TOKEN);
        runId = context.getParameter(PARAM_RUN_ID);
        testName = context.getParameter(PARAM_TEST_NAME, "");
        nodeId = context.getParameter(PARAM_NODE_ID, "");
        batchSize = context.getIntParameter(PARAM_BATCH_SIZE, 100);
        flushIntervalMs = context.getIntParameter(PARAM_FLUSH_INTERVAL_MS, 2000);
        connectTimeoutMs = context.getIntParameter(PARAM_CONNECT_TIMEOUT_MS, 5000);
        readTimeoutMs = context.getIntParameter(PARAM_READ_TIMEOUT_MS, 10000);
        maxRetries = context.getIntParameter(PARAM_MAX_RETRIES, 3);
        collectSystemMetrics = Boolean.parseBoolean(context.getParameter(PARAM_COLLECT_METRICS, "true"));
        maxQueueSize = context.getIntParameter(PARAM_MAX_QUEUE_SIZE, 50000);
        abortOnServerSignal = Boolean.parseBoolean(context.getParameter(PARAM_ABORT_ON_SERVER_SIGNAL, "true"));

        if (url == null || url.isEmpty()) {
            throw new IllegalArgumentException("[PerfHub] perfhub.url is required");
        }
        if (token == null || token.isEmpty()) {
            throw new IllegalArgumentException("[PerfHub] perfhub.token is required");
        }
        if (runId == null || runId.isEmpty()) {
            runId = "run_" + System.currentTimeMillis();
        }

        if (collectSystemMetrics) {
            try {
                osMxBean = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
                osMxBean.getSystemCpuLoad();
                log.info("[PerfHub] System metrics collection ENABLED (CPU + Memory)");
            } catch (Exception e) {
                log.warn("[PerfHub] OS MXBean unavailable, trying basic memory metrics only: {}", e.getMessage());
                osMxBean = null;
            }
            long[] diskIo = readDiskIoBytes();
            if (diskIo != null) {
                prevDiskReadBytes = diskIo[0];
                prevDiskWriteBytes = diskIo[1];
                prevDiskTimestamp = System.currentTimeMillis();
                log.info("[PerfHub] Disk I/O metrics collection ENABLED (/proc/diskstats)");
            } else {
                log.info("[PerfHub] Disk I/O metrics not available (non-Linux or no /proc/diskstats)");
            }
        }

        senderExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "PerfHub-Sender");
            t.setDaemon(true);
            return t;
        });

        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "PerfHub-Flusher");
            t.setDaemon(true);
            return t;
        });

        lastSuccessfulSend.set(System.currentTimeMillis());
        scheduler.scheduleAtFixedRate(this::flush, flushIntervalMs, flushIntervalMs, TimeUnit.MILLISECONDS);

        log.info("[PerfHub] BackendListener initialized: url={}, runId={}, testName={}, batchSize={}, flushInterval={}ms, systemMetrics={}, abortOnServerSignal={}",
                url, runId, testName, batchSize, flushIntervalMs, collectSystemMetrics, abortOnServerSignal);

        log.info("[PerfHub] Testing connectivity to server...");
        try {
            HttpURLConnection testConn = (HttpURLConnection) new URL(url).openConnection();
            testConn.setRequestMethod("HEAD");
            testConn.setConnectTimeout(connectTimeoutMs);
            testConn.setReadTimeout(readTimeoutMs);
            testConn.setRequestProperty("Authorization", "Bearer " + token);
            int testCode = testConn.getResponseCode();
            testConn.disconnect();
            log.info("[PerfHub] Server connectivity test: HTTP {} (any response means server is reachable)", testCode);
        } catch (Exception e) {
            log.warn("[PerfHub] Server connectivity test FAILED: {} — samples may not be delivered. Check URL and network.",
                    e.getMessage());
        }
    }

    @Override
    public void handleSampleResults(List<SampleResult> results, BackendListenerContext context) {
        if (abortTriggered) {
            return;
        }
        for (SampleResult sr : results) {
            int currentSize = queueSize.get();
            if (currentSize >= maxQueueSize) {
                totalDropped.incrementAndGet();
                long now = System.currentTimeMillis();
                long lastLog = lastDropLogTime.get();
                if (now - lastLog > 10_000 && lastDropLogTime.compareAndSet(lastLog, now)) {
                    log.warn("[PerfHub] Queue full ({}/{}), dropping samples. Server may be unreachable.", currentSize, maxQueueSize);
                }
                continue;
            }
            queue.add(new SampleData(
                    sr.getStartTime(),
                    sr.getTime(),
                    escapeJson(sr.getSampleLabel()),
                    escapeJson(sr.getResponseCode()),
                    sr.isSuccessful(),
                    sr.getAllThreads(),
                    escapeJson(truncate(sr.getResponseMessage(), 500)),
                    false
            ));
            queueSize.incrementAndGet();
        }

        if (queueSize.get() >= batchSize) {
            senderExecutor.submit(this::flush);
        }
    }

    private void flush() {
        try {
            List<SampleData> batch = new ArrayList<>(batchSize);
            SampleData item;
            while ((item = queue.poll()) != null && batch.size() < batchSize * 2) {
                batch.add(item);
            }
            queueSize.addAndGet(-batch.size());

            if (batch.isEmpty()) {
                long now = System.currentTimeMillis();
                long lastSend = lastSuccessfulSend.get();
                if (lastSend > 0 && (now - lastSend) >= HEARTBEAT_INTERVAL_MS) {
                    sendHeartbeat();
                }
                return;
            }

            SystemMetrics metrics = collectSystemMetrics ? collectMetrics() : null;
            String json = buildJson(batch, metrics);
            sendWithRetry(json, batch.size());
        } catch (Exception e) {
            log.error("[PerfHub] Unexpected error in flush: {}", e.getMessage(), e);
        }
    }

    private void sendHeartbeat() {
        try {
            String heartbeatUrl = url.replace("/api/ingest/samples", "/api/ingest/heartbeat");
            StringBuilder sb = new StringBuilder();
            sb.append("{\"runId\":\"").append(escapeJson(runId)).append("\"");
            int eid = resolvedExecutionId.get();
            if (eid > 0) {
                sb.append(",\"executionId\":").append(eid);
            }
            sb.append("}");

            byte[] bodyBytes = sb.toString().getBytes(StandardCharsets.UTF_8);
            HttpURLConnection conn = (HttpURLConnection) new URL(heartbeatUrl).openConnection();
            try {
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(connectTimeoutMs);
                conn.setReadTimeout(readTimeoutMs);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + token);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(bodyBytes);
                    os.flush();
                }
                int code = conn.getResponseCode();
                if (code >= 200 && code < 300) {
                    log.debug("[PerfHub] Heartbeat sent successfully");
                } else {
                    log.warn("[PerfHub] Heartbeat response: HTTP {}", code);
                }
            } finally {
                conn.disconnect();
            }
        } catch (Exception e) {
            log.debug("[PerfHub] Heartbeat failed: {}", e.getMessage());
        }
    }

    private SystemMetrics collectMetrics() {
        try {
            double cpuPercent = getCpuPercent();
            if (cpuPercent < 0) cpuPercent = 0;

            double totalMemMb = 0;
            double usedMemMb = 0;
            double memPercent = 0;
            if (osMxBean != null) {
                try {
                    long totalMemBytes = osMxBean.getTotalPhysicalMemorySize();
                    long freeMemBytes = osMxBean.getFreePhysicalMemorySize();
                    long usedMemBytes = totalMemBytes - freeMemBytes;
                    totalMemMb = totalMemBytes / (1024.0 * 1024.0);
                    usedMemMb = usedMemBytes / (1024.0 * 1024.0);
                    memPercent = totalMemBytes > 0 ? (usedMemBytes * 100.0 / totalMemBytes) : 0;
                } catch (Exception e) {
                    log.debug("[PerfHub] Memory metrics unavailable: {}", e.getMessage());
                }
            }

            double diskReadMbps = 0;
            double diskWriteMbps = 0;
            long[] diskIo = readDiskIoBytes();
            if (diskIo != null && prevDiskReadBytes >= 0) {
                long now = System.currentTimeMillis();
                long elapsedMs = now - prevDiskTimestamp;
                if (elapsedMs > 0) {
                    long readDelta = diskIo[0] - prevDiskReadBytes;
                    long writeDelta = diskIo[1] - prevDiskWriteBytes;
                    diskReadMbps = (readDelta / (1024.0 * 1024.0)) / (elapsedMs / 1000.0);
                    diskWriteMbps = (writeDelta / (1024.0 * 1024.0)) / (elapsedMs / 1000.0);
                }
                prevDiskReadBytes = diskIo[0];
                prevDiskWriteBytes = diskIo[1];
                prevDiskTimestamp = now;
            }

            return new SystemMetrics(
                    round2(cpuPercent),
                    round2(usedMemMb),
                    round2(totalMemMb),
                    round2(memPercent),
                    round2(Math.max(0, diskReadMbps)),
                    round2(Math.max(0, diskWriteMbps))
            );
        } catch (Exception e) {
            log.debug("[PerfHub] Failed to collect system metrics: {}", e.getMessage());
            return null;
        }
    }

    private double getCpuPercent() {
        if (osMxBean == null) return -1;
        try {
            double systemLoad = osMxBean.getSystemCpuLoad();
            if (systemLoad >= 0) {
                return systemLoad * 100.0;
            }
        } catch (Exception ignored) {}
        return -1;
    }

    private long[] readDiskIoBytes() {
        try {
            Path diskstats = Paths.get("/proc/diskstats");
            if (!Files.exists(diskstats)) return null;

            long totalRead = 0;
            long totalWrite = 0;
            for (String line : Files.readAllLines(diskstats)) {
                String[] parts = line.trim().split("\\s+");
                if (parts.length >= 13) {
                    String devName = parts[2];
                    if (devName.matches("^(sd[a-z]|vd[a-z]|nvme\\d+n\\d+|xvd[a-z])$")) {
                        totalRead += Long.parseLong(parts[5]) * 512;
                        totalWrite += Long.parseLong(parts[9]) * 512;
                    }
                }
            }
            return new long[]{totalRead, totalWrite};
        } catch (Exception e) {
            return null;
        }
    }

    private void sendWithRetry(String json, int sampleCount) {
        int attempt = 0;
        long backoffMs = 500;

        while (attempt <= maxRetries) {
            try {
                int responseCode = sendBatch(json);
                if (responseCode >= 200 && responseCode < 300) {
                    lastSuccessfulSend.set(System.currentTimeMillis());
                    long sent = totalSent.addAndGet(sampleCount);
                    if (sent == sampleCount || sent % 500 < sampleCount) {
                        log.info("[PerfHub] Batch sent: {} samples (total sent: {})", sampleCount, sent);
                    }
                    return;
                } else if (responseCode == 401 || responseCode == 403) {
                    log.error("[PerfHub] Authentication failed (HTTP {}). Check your perfhub.token value.", responseCode);
                    totalDropped.addAndGet(sampleCount);
                    return;
                } else if (responseCode == 409) {
                    log.warn("[PerfHub] Execution not accepting samples (HTTP 409). Test may be finished.");
                    totalDropped.addAndGet(sampleCount);
                    return;
                } else {
                    log.warn("[PerfHub] Server returned HTTP {} (attempt {}/{})", responseCode, attempt + 1, maxRetries + 1);
                }
            } catch (IOException e) {
                log.error("[PerfHub] Send error (attempt {}/{}): {}", attempt + 1, maxRetries + 1, e.getMessage());
                totalErrors.incrementAndGet();
            }

            attempt++;
            if (attempt <= maxRetries) {
                try {
                    Thread.sleep(Math.min(backoffMs, 10000));
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
                backoffMs *= 2;
            }
        }

        totalDropped.addAndGet(sampleCount);
        log.error("[PerfHub] Dropped {} samples after {} attempts", sampleCount, maxRetries + 1);
    }

    private int sendBatch(String json) throws IOException {
        byte[] bodyBytes = json.getBytes(StandardCharsets.UTF_8);

        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(connectTimeoutMs);
            conn.setReadTimeout(readTimeoutMs);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Content-Length", String.valueOf(bodyBytes.length));
            conn.setRequestProperty("Authorization", "Bearer " + token);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(bodyBytes);
                os.flush();
            }

            int code = conn.getResponseCode();

            if (code >= 200 && code < 300) {
                try (InputStream is = conn.getInputStream()) {
                    byte[] respBody = readFully(is);
                    String respStr = new String(respBody, StandardCharsets.UTF_8);
                    int eid = parseExecutionId(respStr);
                    if (eid > 0 && resolvedExecutionId.compareAndSet(0, eid)) {
                        log.info("[PerfHub] Server assigned executionId: {}", eid);
                    }
                    if (abortOnServerSignal && !abortTriggered && parseAbortSignal(respStr)) {
                        abortTriggered = true;
                        String reason = parseAbortReason(respStr);
                        log.warn("[PerfHub] *** ABORT SIGNAL RECEIVED FROM SERVER *** Reason: {}", reason);
                        log.warn("[PerfHub] Stopping JMeter engine immediately...");
                        try {
                            StandardJMeterEngine.stopEngineNow();
                            log.info("[PerfHub] JMeter engine stop signal sent successfully");
                        } catch (Exception e) {
                            log.error("[PerfHub] Failed to stop JMeter engine: {}", e.getMessage(), e);
                        }
                    }
                }
            } else if (code >= 400) {
                String errStr = "";
                try (InputStream es = conn.getErrorStream()) {
                    if (es != null) {
                        byte[] errBody = readFully(es);
                        errStr = new String(errBody, StandardCharsets.UTF_8);
                        log.error("[PerfHub] Error response (HTTP {}): {}", code, errStr);
                    }
                }
                if (code == 409 && abortOnServerSignal && !abortTriggered && parseAbortSignal(errStr)) {
                    abortTriggered = true;
                    String reason = parseAbortReason(errStr);
                    log.warn("[PerfHub] *** ABORT SIGNAL RECEIVED (HTTP 409) *** Reason: {}", reason);
                    log.warn("[PerfHub] Stopping JMeter engine immediately...");
                    try {
                        StandardJMeterEngine.stopEngineNow();
                        log.info("[PerfHub] JMeter engine stop signal sent successfully");
                    } catch (Exception e) {
                        log.error("[PerfHub] Failed to stop JMeter engine: {}", e.getMessage(), e);
                    }
                }
            }

            return code;
        } finally {
            conn.disconnect();
        }
    }

    private int parseExecutionId(String json) {
        try {
            int idx = json.indexOf("\"executionId\":");
            if (idx < 0) return 0;
            int start = idx + "\"executionId\":".length();
            while (start < json.length() && json.charAt(start) == ' ') start++;
            int end = start;
            while (end < json.length() && Character.isDigit(json.charAt(end))) end++;
            if (end > start) {
                return Integer.parseInt(json.substring(start, end));
            }
        } catch (Exception ignored) {}
        return 0;
    }

    private boolean parseAbortSignal(String json) {
        try {
            int idx = json.indexOf("\"abort\":");
            if (idx < 0) return false;
            int start = idx + "\"abort\":".length();
            while (start < json.length() && json.charAt(start) == ' ') start++;
            return json.regionMatches(start, "true", 0, 4);
        } catch (Exception ignored) {}
        return false;
    }

    private String parseAbortReason(String json) {
        try {
            int idx = json.indexOf("\"abortReason\":\"");
            if (idx < 0) return "No reason provided";
            int start = idx + "\"abortReason\":\"".length();
            int end = json.indexOf("\"", start);
            if (end > start) {
                return json.substring(start, end);
            }
        } catch (Exception ignored) {}
        return "No reason provided";
    }

    private String buildJson(List<SampleData> batch, SystemMetrics metrics) {
        StringBuilder sb = new StringBuilder(batch.size() * 120 + 256);
        sb.append("{\"runId\":\"").append(escapeJson(runId)).append("\"");

        int eid = resolvedExecutionId.get();
        if (eid > 0) {
            sb.append(",\"executionId\":").append(eid);
        }

        if (testName != null && !testName.isEmpty()) {
            sb.append(",\"testName\":\"").append(escapeJson(testName)).append("\"");
        }
        if (nodeId != null && !nodeId.isEmpty()) {
            sb.append(",\"nodeId\":\"").append(escapeJson(nodeId)).append("\"");
        }

        sb.append(",\"samples\":[");
        for (int i = 0; i < batch.size(); i++) {
            if (i > 0) sb.append(',');
            SampleData s = batch.get(i);
            sb.append("{\"timestamp\":").append(s.timestamp);
            sb.append(",\"elapsed\":").append(s.elapsed);
            sb.append(",\"label\":\"").append(s.label).append("\"");
            sb.append(",\"responseCode\":\"").append(s.responseCode).append("\"");
            sb.append(",\"success\":").append(s.success);
            sb.append(",\"allThreads\":").append(s.allThreads);
            sb.append(",\"responseMessage\":\"").append(s.responseMessage).append("\"");
            if (s.parentSample) {
                sb.append(",\"parentSample\":true");
            }
            sb.append('}');
        }
        sb.append("]");

        if (metrics != null) {
            sb.append(",\"systemMetrics\":{");
            sb.append("\"cpuPercent\":").append(metrics.cpuPercent);
            sb.append(",\"memUsedMb\":").append(metrics.memUsedMb);
            sb.append(",\"memTotalMb\":").append(metrics.memTotalMb);
            sb.append(",\"memPercent\":").append(metrics.memPercent);
            sb.append(",\"diskReadMbps\":").append(metrics.diskReadMbps);
            sb.append(",\"diskWriteMbps\":").append(metrics.diskWriteMbps);
            sb.append("}");
        }

        sb.append("}");
        return sb.toString();
    }

    @Override
    public void teardownTest(BackendListenerContext context) throws Exception {
        log.info("[PerfHub] Shutting down — draining remaining samples...");

        scheduler.shutdown();

        List<SampleData> finalBatch = new ArrayList<>();
        SampleData item;
        while ((item = queue.poll()) != null) {
            finalBatch.add(item);
        }

        if (!finalBatch.isEmpty()) {
            log.info("[PerfHub] Sending final batch of {} samples...", finalBatch.size());
            SystemMetrics metrics = collectSystemMetrics ? collectMetrics() : null;
            String json = buildJson(finalBatch, metrics);
            sendWithRetry(json, finalBatch.size());
        }

        try {
            sendComplete();
        } catch (Exception e) {
            log.error("[PerfHub] Failed to send completion signal: {}", e.getMessage());
        }

        senderExecutor.shutdown();
        try {
            if (!senderExecutor.awaitTermination(30, TimeUnit.SECONDS)) {
                senderExecutor.shutdownNow();
            }
        } catch (InterruptedException e) {
            senderExecutor.shutdownNow();
            Thread.currentThread().interrupt();
        }

        log.info("[PerfHub] Shutdown complete. Sent: {}, Dropped: {}, Errors: {}",
                totalSent.get(), totalDropped.get(), totalErrors.get());
    }

    private void sendComplete() throws IOException {
        String completeUrl = url.replace("/api/ingest/samples", "/api/ingest/complete");
        StringBuilder sb = new StringBuilder();
        sb.append("{\"runId\":\"").append(escapeJson(runId)).append("\"");
        int eid = resolvedExecutionId.get();
        if (eid > 0) {
            sb.append(",\"executionId\":").append(eid);
        }
        sb.append("}");
        String json = sb.toString();

        HttpURLConnection conn = (HttpURLConnection) new URL(completeUrl).openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(connectTimeoutMs);
            conn.setReadTimeout(readTimeoutMs);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + token);

            byte[] bodyBytes = json.getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(bodyBytes);
                os.flush();
            }

            int code = conn.getResponseCode();
            log.info("[PerfHub] Completion signal sent, response: HTTP {}", code);
        } finally {
            conn.disconnect();
        }
    }

    private static double round2(double val) {
        return Math.round(val * 100.0) / 100.0;
    }

    private static byte[] readFully(InputStream is) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);
        byte[] buf = new byte[1024];
        int n;
        while ((n = is.read(buf)) != -1) {
            baos.write(buf, 0, n);
        }
        return baos.toByteArray();
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }

    private static String truncate(String s, int maxLen) {
        if (s == null) return "";
        return s.length() <= maxLen ? s : s.substring(0, maxLen);
    }

    private static class SampleData {
        final long timestamp;
        final long elapsed;
        final String label;
        final String responseCode;
        final boolean success;
        final int allThreads;
        final String responseMessage;
        final boolean parentSample;

        SampleData(long timestamp, long elapsed, String label, String responseCode,
                   boolean success, int allThreads, String responseMessage, boolean parentSample) {
            this.timestamp = timestamp;
            this.elapsed = elapsed;
            this.label = label;
            this.responseCode = responseCode;
            this.success = success;
            this.allThreads = allThreads;
            this.responseMessage = responseMessage;
            this.parentSample = parentSample;
        }
    }

    private static class SystemMetrics {
        final double cpuPercent;
        final double memUsedMb;
        final double memTotalMb;
        final double memPercent;
        final double diskReadMbps;
        final double diskWriteMbps;

        SystemMetrics(double cpuPercent, double memUsedMb, double memTotalMb,
                      double memPercent, double diskReadMbps, double diskWriteMbps) {
            this.cpuPercent = cpuPercent;
            this.memUsedMb = memUsedMb;
            this.memTotalMb = memTotalMb;
            this.memPercent = memPercent;
            this.diskReadMbps = diskReadMbps;
            this.diskWriteMbps = diskWriteMbps;
        }
    }
}
