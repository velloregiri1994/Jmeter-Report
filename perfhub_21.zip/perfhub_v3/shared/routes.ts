import { z } from 'zod';
import { 
  insertUserSchema, 
  insertScriptSchema, 
  insertTestScheduleSchema, 
  insertTestExecutionSchema, 
  insertCommentSchema,
  users,
  scripts,
  testSchedules,
  testExecutions,
  comments
} from './schema';

export type { InsertScript, InsertTestSchedule, InsertTestExecution, InsertComment } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  users: {
    list: {
      method: 'GET' as const,
      path: '/api/users',
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      },
    },
  },
  scripts: {
    list: {
      method: 'GET' as const,
      path: '/api/scripts',
      responses: {
        200: z.array(z.custom<typeof scripts.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/scripts',
      input: insertScriptSchema,
      responses: {
        201: z.custom<typeof scripts.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/scripts/:id',
      responses: {
        200: z.custom<typeof scripts.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/scripts/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
    upload: {
      method: 'POST' as const,
      path: '/api/scripts/:scriptId/upload',
      responses: {
        200: z.custom<typeof scripts.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  schedules: {
    list: {
      method: 'GET' as const,
      path: '/api/schedules',
      responses: {
        200: z.array(z.custom<typeof testSchedules.$inferSelect & { 
          script: typeof scripts.$inferSelect;
          creator: typeof users.$inferSelect;
        }>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/schedules',
      input: insertTestScheduleSchema.omit({ createdBy: true }), // Backend infers user
      responses: {
        201: z.custom<typeof testSchedules.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/schedules/:id',
      responses: {
        200: z.custom<typeof testSchedules.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'PATCH' as const,
      path: '/api/schedules/:id',
      input: insertTestScheduleSchema.partial(),
      responses: {
        200: z.custom<typeof testSchedules.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  executions: {
    list: {
      method: 'GET' as const,
      path: '/api/executions',
      input: z.object({
        status: z.enum(['queued', 'running', 'completed', 'failed']).optional(),
        limit: z.coerce.number().optional(),
        offset: z.coerce.number().optional(),
        page: z.coerce.number().optional(),
      }).optional(),
      responses: {
        200: z.object({
          data: z.array(z.custom<typeof testExecutions.$inferSelect & {
            schedule: typeof testSchedules.$inferSelect & { script: typeof scripts.$inferSelect };
          }>()),
          pagination: z.object({
            total: z.number(),
            limit: z.number(),
            offset: z.number(),
            page: z.number(),
            totalPages: z.number(),
            hasMore: z.boolean(),
          }),
        }),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/executions/:id',
      responses: {
        200: z.custom<typeof testExecutions.$inferSelect & {
          schedule: typeof testSchedules.$inferSelect & { script: typeof scripts.$inferSelect };
          comments: (typeof comments.$inferSelect & { user: typeof users.$inferSelect })[];
        }>(),
        404: errorSchemas.notFound,
      },
    },
    generateReport: {
      method: 'POST' as const,
      path: '/api/executions/:id/generate-report',
      responses: {
        200: z.object({ url: z.string() }),
        404: errorSchemas.notFound,
        500: z.object({ message: z.string() }),
      },
    },
  },
  comments: {
    create: {
      method: 'POST' as const,
      path: '/api/executions/:executionId/comments',
      input: insertCommentSchema.omit({ executionId: true, userId: true }),
      responses: {
        201: z.custom<typeof comments.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  dashboard: {
    stats: {
      method: 'GET' as const,
      path: '/api/dashboard/stats',
      responses: {
        200: z.object({
          totalScripts: z.number(),
          totalExecutions: z.number(),
          passRate: z.number(),
          activeTests: z.number(),
          recentExecutions: z.array(z.custom<typeof testExecutions.$inferSelect & {
             schedule: typeof testSchedules.$inferSelect & { script: typeof scripts.$inferSelect };
          }>()),
          performanceMetrics: z.object({
            avgResponseTime: z.number(),
            avgThroughput: z.number(),
            avgP95: z.number(),
            avgErrorRate: z.number(),
            testsAnalyzed: z.number(),
          }).optional(),
          todayStats: z.object({
            completed: z.number(),
            failed: z.number(),
            running: z.number(),
            scheduled: z.number(),
          }).optional(),
        }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
