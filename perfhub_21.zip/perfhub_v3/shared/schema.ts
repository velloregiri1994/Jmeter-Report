import { pgTable, text, serial, integer, boolean, timestamp, jsonb, index, foreignKey, unique, real, doublePrecision } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email"),
  password: text("password").notNull(),
  role: text("role").default("engineer").notNull(), // 'admin', 'engineer', 'manager'
  isApproved: boolean("is_approved").default(false).notNull(),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("users_email_idx").on(table.email),
  index("users_role_idx").on(table.role),
  index("users_is_approved_idx").on(table.isApproved),
]);

export const folders = pgTable("folders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  parentId: integer("parent_id"),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("folders_parent_id_idx").on(table.parentId),
]);

export const scripts = pgTable("scripts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  toolType: text("tool_type").notNull(), // 'JMeter' only
  filePath: text("file_path"),
  dependencyFiles: jsonb("dependency_files").$type<Array<{
    originalName: string;
    storedPath: string;
    size: number;
    uploadedAt: string;
  }>>(),
  jarFiles: jsonb("jar_files").$type<Array<{
    originalName: string;
    storedPath: string;
    size: number;
    uploadedAt: string;
  }>>(),
  workloadTargets: jsonb("workload_targets").$type<{
    threads?: number;
    tph?: number;
    tps?: number;
    pacing?: number;
    testType?: string;
    transactionsPerIteration?: number;
    e2eResponseTime?: number;
    thinkTime?: number;
    perTransaction?: Array<{ name: string; weight: number; tph: number; tps: number }>;
  }>(),
  uploadedBy: integer("uploaded_by").references(() => users.id, { onDelete: "set null" }),
  folderId: integer("folder_id").references(() => folders.id, { onDelete: "set null" }),
  projectId: integer("project_id"),
  protocol: text("protocol").default("http"),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("scripts_name_idx").on(table.name),
  index("scripts_folder_id_idx").on(table.folderId),
  index("scripts_tool_type_idx").on(table.toolType),
  index("scripts_project_id_idx").on(table.projectId),
  foreignKey({ columns: [table.projectId], foreignColumns: [projects.id] }).onDelete("set null"),
]);

export const testSchedules = pgTable("test_schedules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  scriptId: integer("script_id").references(() => scripts.id, { onDelete: "set null" }), // Nullable to support schedules after script deletion
  scheduledTime: timestamp("scheduled_time", { mode: 'string', withTimezone: true }).notNull(),
  status: text("status").default("pending").notNull(), // 'pending', 'running', 'completed', 'failed', 'cancelled'
  recurrence: text("recurrence"), // 'none', 'daily', 'weekly', 'monthly'
  configuration: jsonb("configuration").$type<{
    vusers?: number;
    rampUp?: number; // seconds
    duration?: number; // seconds
    timeoutMinutes?: number; // Custom timeout override (optional)
    environment: string;
    timezone?: string;
    isDistributed?: boolean;
    workerNodes?: number;
    testTypeId?: number;
    testTypeName?: string;
    volume?: string;
    slas?: {
      avgResponseTime?: number;
      throughput?: number;
      p90?: number;
      p95?: number;
      errorRate?: number;
    };
    emailNotification?: {
      recipients?: string[];
      sendOnSuccess?: boolean;
      sendOnFailure?: boolean;
      sendOnSlaBreach?: boolean;
    };
    releaseTag?: string;
  }>(), // Made optional and fields optional
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("test_schedules_status_idx").on(table.status),
  index("test_schedules_scheduled_time_idx").on(table.scheduledTime),
  index("test_schedules_script_id_idx").on(table.scriptId),
]);

export type TransactionDetail = {
  label: string;
  count: number;
  avg: number;
  p50: number;
  p90: number;
  p95: number;
  p99: number;
  max: number;
  throughput: number;
  hitsPerSec: number;
  errorRate: number;
};

export const testExecutions = pgTable("test_executions", {
  id: serial("id").primaryKey(),
  executionId: text("execution_id").notNull().unique(),
  scheduleId: integer("schedule_id").references(() => testSchedules.id, { onDelete: "set null" }), // Nullable to support orphaned executions after schedule deletion
  testName: text("test_name"),
  startTime: timestamp("start_time", { mode: 'string', withTimezone: true }),
  endTime: timestamp("end_time", { mode: 'string', withTimezone: true }),
  status: text("status").notNull(), // 'queued', 'running', 'parsing', 'completed', 'failed'
  resultSummary: jsonb("result_summary").$type<{
    totalRequests: number;
    failedRequests: number;
    avgResponseTime: number;
    throughput: number;
    transactionDetails?: TransactionDetail[];
    transactionHistory?: {
      [label: string]: number[];
    };
  }>(),
  artifactsPath: text("artifacts_path"),
  reportHtmlPath: text("report_html_path"),
  reportComments: text("report_comments"),
  slaViolations: jsonb("sla_violations").$type<{
    avgResponseTime?: { threshold: number; actual: number };
    throughput?: { threshold: number; actual: number };
    p90?: { threshold: number; actual: number };
    p95?: { threshold: number; actual: number };
    errorRate?: { threshold: number; actual: number };
    perTransaction?: Array<{
      label: string;
      metric: string;
      threshold: number;
      actual: number;
      comparator: string;
    }>;
  }>(),
  baselineDeviation: jsonb("baseline_deviation").$type<{
    baselineExecutionId: number;
    global: {
      avgResponseTime?: { baseline: number; current: number; changePercent: number };
      throughput?: { baseline: number; current: number; changePercent: number };
      errorRate?: { baseline: number; current: number; changePercent: number };
      p90?: { baseline: number; current: number; changePercent: number };
      p95?: { baseline: number; current: number; changePercent: number };
    };
    perTransaction?: Array<{
      label: string;
      avgChange: number;
      p90Change: number;
      throughputChange: number;
    }>;
    overallRegression: boolean;
    regressionSeverity?: 'minor' | 'moderate' | 'severe';
  }>(),
  liveMetrics: jsonb("live_metrics").$type<{
    avgResponseTime: number[];
    minResponseTime?: number[];
    maxResponseTime?: number[];
    throughput: number[];
    activeThreads: number[];
    errorCount: number;
    errorMessages: string[];
    timestamps: string[];
    transactionDetails?: TransactionDetail[];
    transactionHistory?: {
      [label: string]: {
        avg: number[];
        throughput: number[];
        count?: number[];
        errorRate?: number[];
      };
    };
  }>(),
  environment: text("environment"),
  remoteAgentTokenId: integer("remote_agent_token_id"),
  scriptId: integer("script_id").references(() => scripts.id, { onDelete: "set null" }),
  executionLabels: jsonb("execution_labels").$type<string[]>(),
  isPinned: boolean("is_pinned").default(false),
  pinnedAt: timestamp("pinned_at", { mode: 'string', withTimezone: true }),
  pinnedBy: integer("pinned_by").references(() => users.id, { onDelete: "set null" }),
  releaseTag: text("release_tag"),
}, (table) => [
  index("test_executions_status_idx").on(table.status),
  index("test_executions_schedule_id_idx").on(table.scheduleId),
  index("test_executions_start_time_idx").on(table.startTime),
  index("test_executions_script_id_idx").on(table.scriptId),
  index("test_executions_remote_agent_idx").on(table.remoteAgentTokenId),
  index("test_executions_status_start_idx").on(table.status, table.startTime),
  index("test_executions_script_status_idx").on(table.scriptId, table.status),
  index("test_executions_release_tag_idx").on(table.releaseTag),
  foreignKey({ columns: [table.remoteAgentTokenId], foreignColumns: [remoteIngestTokens.id] }).onDelete("set null"),
]);

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  executionId: integer("execution_id").notNull().references(() => testExecutions.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  type: text("type").default("comment").notNull(), // 'comment', 'sign-off', 'annotation'
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("comments_execution_id_idx").on(table.executionId),
]);

export const tags = pgTable("tags", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  color: text("color").default("#3b82f6").notNull(),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
});

export const scriptTags = pgTable("script_tags", {
  id: serial("id").primaryKey(),
  scriptId: integer("script_id").notNull().references(() => scripts.id, { onDelete: "cascade" }),
  tagId: integer("tag_id").notNull().references(() => tags.id, { onDelete: "cascade" }),
}, (table) => [
  index("script_tags_script_id_idx").on(table.scriptId),
  index("script_tags_tag_id_idx").on(table.tagId),
  unique("script_tags_unique").on(table.scriptId, table.tagId),
]);

export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  scriptId: integer("script_id").notNull().references(() => scripts.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("favorites_user_id_idx").on(table.userId),
  index("favorites_script_id_idx").on(table.scriptId),
  unique("favorites_user_script_unique").on(table.userId, table.scriptId),
]);

export const testTemplates = pgTable("test_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  configuration: jsonb("configuration").$type<{
    vusers?: number;
    rampUp?: number;
    duration?: number;
    environment: string;
    isDistributed?: boolean;
    workerNodes?: number;
    slas?: {
      avgResponseTime?: number;
      throughput?: number;
      p90?: number;
      p95?: number;
      errorRate?: number;
    };
  }>(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
});

export const baselineExecutions = pgTable("baseline_executions", {
  id: serial("id").primaryKey(),
  scriptId: integer("script_id").notNull().references(() => scripts.id, { onDelete: "cascade" }),
  executionId: integer("execution_id").notNull().references(() => testExecutions.id, { onDelete: "cascade" }),
  setBy: integer("set_by").notNull().references(() => users.id),
  isActive: boolean("is_active").default(true).notNull(),
  name: text("name"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("baseline_executions_script_id_idx").on(table.scriptId),
  index("baseline_executions_active_idx").on(table.scriptId, table.isActive),
]);

// SLA Rules for per-transaction thresholds
export const slaRules = pgTable("sla_rules", {
  id: serial("id").primaryKey(),
  scriptId: integer("script_id").notNull().references(() => scripts.id, { onDelete: "cascade" }),
  transactionLabel: text("transaction_label"), // null = applies to all/global
  metric: text("metric").notNull(), // 'avg', 'p90', 'p95', 'p99', 'max', 'errorRate', 'throughput'
  comparator: text("comparator").notNull(), // 'lt' (less than), 'gt' (greater than), 'lte', 'gte'
  threshold: integer("threshold").notNull(), // threshold value in ms (for response times) or percentage*100 (for error rate)
  isEnabled: boolean("is_enabled").default(true).notNull(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("sla_rules_script_id_idx").on(table.scriptId),
  index("sla_rules_enabled_idx").on(table.scriptId, table.isEnabled),
]);

export const executionSlaRules = pgTable("execution_sla_rules", {
  id: serial("id").primaryKey(),
  executionId: integer("execution_id").notNull().references(() => testExecutions.id, { onDelete: "cascade" }),
  transactionLabel: text("transaction_label"),
  metric: text("metric").notNull(),
  comparator: text("comparator").notNull(),
  threshold: integer("threshold").notNull(),
  isEnabled: boolean("is_enabled").default(true).notNull(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("exec_sla_rules_exec_id_idx").on(table.executionId),
  index("exec_sla_rules_enabled_idx").on(table.executionId, table.isEnabled),
]);

// Auto-Abort Rules: stop tests when metrics breach thresholds for a sustained period
export const autoAbortRules = pgTable("auto_abort_rules", {
  id: serial("id").primaryKey(),
  scriptId: integer("script_id").notNull().references(() => scripts.id, { onDelete: "cascade" }),
  metric: text("metric").notNull(), // 'errorRate', 'avgResponseTime', 'p90', 'p95', 'p99', 'maxResponseTime', 'throughput'
  comparator: text("comparator").notNull(), // 'gt', 'gte', 'lt', 'lte'
  threshold: real("threshold").notNull(), // ms for response times, percentage for errorRate, req/s for throughput
  sustainedSeconds: integer("sustained_seconds").notNull().default(30), // how long breach must persist before aborting
  isEnabled: boolean("is_enabled").default(true).notNull(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("auto_abort_rules_script_id_idx").on(table.scriptId),
  index("auto_abort_rules_enabled_idx").on(table.scriptId, table.isEnabled),
]);

export const executionAutoAbortRules = pgTable("execution_auto_abort_rules", {
  id: serial("id").primaryKey(),
  executionId: integer("execution_id").notNull().references(() => testExecutions.id, { onDelete: "cascade" }),
  metric: text("metric").notNull(),
  comparator: text("comparator").notNull(),
  threshold: real("threshold").notNull(),
  sustainedSeconds: integer("sustained_seconds").notNull().default(30),
  isEnabled: boolean("is_enabled").default(true).notNull(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("exec_auto_abort_rules_exec_id_idx").on(table.executionId),
  index("exec_auto_abort_rules_enabled_idx").on(table.executionId, table.isEnabled),
]);

export const executionWorkloadTargets = pgTable("execution_workload_targets", {
  id: serial("id").primaryKey(),
  executionId: integer("execution_id").notNull().references(() => testExecutions.id, { onDelete: "cascade" }),
  threads: integer("threads"),
  tph: integer("tph"),
  tps: real("tps"),
  pacing: real("pacing"),
  testType: text("test_type"),
  transactionsPerIteration: integer("transactions_per_iteration"),
  e2eResponseTime: real("e2e_response_time"),
  thinkTime: real("think_time"),
  perTransaction: jsonb("per_transaction").$type<Array<{ name: string; weight: number; tph: number; tps: number }>>(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("exec_workload_targets_exec_id_idx").on(table.executionId),
]);

// Projects for organizing scripts
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
});

// Test types for categorizing tests
export const testTypes = pgTable("test_types", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
});

export const savedFilterViews = pgTable("saved_filter_views", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  page: text("page").notNull(),
  filters: jsonb("filters").notNull(),
  isDefault: boolean("is_default").default(false),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("saved_filter_views_user_page_idx").on(table.userId, table.page),
]);

// Test Tracker - denormalized table for reporting
export const testTracker = pgTable("test_tracker", {
  id: serial("id").primaryKey(),
  runId: text("run_id").notNull(),
  executionTimestamp: timestamp("execution_timestamp", { mode: 'string', withTimezone: true }).notNull(),
  projectId: integer("project_id").references(() => projects.id, { onDelete: "set null" }),
  projectName: text("project_name"),
  featureName: text("feature_name").notNull(),
  testTypeId: integer("test_type_id").references(() => testTypes.id, { onDelete: "set null" }),
  testTypeName: text("test_type_name"),
  volume: text("volume"),
  environment: text("environment"),
  comments: text("comments"),
  status: text("status").notNull(),
  durationSeconds: integer("duration_seconds"),
  avgResponseTime: integer("avg_response_time"),
  p95: integer("p95"),
  p99: integer("p99"),
  throughput: integer("throughput"),
  errorRate: integer("error_rate"),
  executionId: integer("execution_id").references(() => testExecutions.id, { onDelete: "set null" }),
  sortOrder: integer("sort_order"),
  releaseTag: text("release_tag"),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("test_tracker_project_id_idx").on(table.projectId),
  index("test_tracker_test_type_id_idx").on(table.testTypeId),
  index("test_tracker_execution_timestamp_idx").on(table.executionTimestamp),
  index("test_tracker_status_idx").on(table.status),
  index("test_tracker_sort_order_idx").on(table.sortOrder),
]);

export const releaseTags = pgTable("release_tags", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  color: text("color"),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  createdBy: integer("created_by").references(() => users.id, { onDelete: "set null" }),
});

// === RELATIONS ===

export const foldersRelations = relations(folders, ({ one, many }) => ({
  parent: one(folders, {
    fields: [folders.parentId],
    references: [folders.id],
  }),
  children: many(folders),
  scripts: many(scripts),
}));

export const scriptsRelations = relations(scripts, ({ one, many }) => ({
  folder: one(folders, {
    fields: [scripts.folderId],
    references: [folders.id],
  }),
  uploader: one(users, {
    fields: [scripts.uploadedBy],
    references: [users.id],
  }),
  schedules: many(testSchedules),
}));

export const testSchedulesRelations = relations(testSchedules, ({ one, many }) => ({
  script: one(scripts, {
    fields: [testSchedules.scriptId],
    references: [scripts.id],
  }),
  creator: one(users, {
    fields: [testSchedules.createdBy],
    references: [users.id],
  }),
  executions: many(testExecutions),
}));

export const testExecutionsRelations = relations(testExecutions, ({ one, many }) => ({
  schedule: one(testSchedules, {
    fields: [testExecutions.scheduleId],
    references: [testSchedules.id],
  }),
  comments: many(comments),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  execution: one(testExecutions, {
    fields: [comments.executionId],
    references: [testExecutions.id],
  }),
  user: one(users, {
    fields: [comments.userId],
    references: [users.id],
  }),
}));

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // 'info', 'warning', 'error', 'sla_violation'
  read: boolean("read").default(false).notNull(),
  link: text("link"),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("notifications_user_id_idx").on(table.userId),
  index("notifications_read_idx").on(table.read),
  index("notifications_user_read_idx").on(table.userId, table.read),
]);

export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export const notificationPreferences = pgTable("notification_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  testCompleted: boolean("test_completed").default(true).notNull(),
  testFailed: boolean("test_failed").default(true).notNull(),
  slaViolation: boolean("sla_violation").default(true).notNull(),
  regressionDetected: boolean("regression_detected").default(true).notNull(),
  approvalRequested: boolean("approval_requested").default(true).notNull(),
  systemAlerts: boolean("system_alerts").default(true).notNull(),
  emailEnabled: boolean("email_enabled").default(false).notNull(),
  emailDigestFrequency: text("email_digest_frequency").default("instant").notNull(),
  emailDigestTime: text("email_digest_time").default("09:00").notNull(),
  emailDigestDay: text("email_digest_day").default("monday").notNull(),
  quietHoursEnabled: boolean("quiet_hours_enabled").default(false).notNull(),
  quietHoursStart: text("quiet_hours_start").default("22:00").notNull(),
  quietHoursEnd: text("quiet_hours_end").default("07:00").notNull(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
});

export const insertNotificationPreferencesSchema = createInsertSchema(notificationPreferences).omit({ id: true, updatedAt: true });
export type NotificationPreferences = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreferences = z.infer<typeof insertNotificationPreferencesSchema>;

// ... existing relations ...
export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

export const notificationPreferencesRelations = relations(notificationPreferences, ({ one }) => ({
  user: one(users, {
    fields: [notificationPreferences.userId],
    references: [users.id],
  }),
}));


export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertFolderSchema = createInsertSchema(folders).omit({ id: true, createdAt: true });
export const insertScriptSchema = createInsertSchema(scripts).omit({ id: true, createdAt: true });
export const insertTestScheduleSchema = createInsertSchema(testSchedules).omit({ id: true, createdAt: true });
export const insertTestExecutionSchema = createInsertSchema(testExecutions).omit({ id: true });
export const insertCommentSchema = createInsertSchema(comments).omit({ id: true, createdAt: true });
export const insertTagSchema = createInsertSchema(tags).omit({ id: true, createdAt: true });
export const insertScriptTagSchema = createInsertSchema(scriptTags).omit({ id: true });
export const insertFavoriteSchema = createInsertSchema(favorites).omit({ id: true, createdAt: true });
export const insertTestTemplateSchema = createInsertSchema(testTemplates).omit({ id: true, createdAt: true });
export const insertBaselineExecutionSchema = createInsertSchema(baselineExecutions).omit({ id: true, createdAt: true });
export const insertSlaRuleSchema = createInsertSchema(slaRules).omit({ id: true, createdAt: true, updatedAt: true });
export const insertExecutionSlaRuleSchema = createInsertSchema(executionSlaRules).omit({ id: true, createdAt: true, updatedAt: true });
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true });
export const insertTestTypeSchema = createInsertSchema(testTypes).omit({ id: true, createdAt: true });
export const insertTestTrackerSchema = createInsertSchema(testTracker).omit({ id: true, createdAt: true });
export const insertSavedFilterViewSchema = createInsertSchema(savedFilterViews).omit({ id: true, createdAt: true });
export const insertAutoAbortRuleSchema = createInsertSchema(autoAbortRules).omit({ id: true, createdAt: true, updatedAt: true });
export const insertExecutionAutoAbortRuleSchema = createInsertSchema(executionAutoAbortRules).omit({ id: true, createdAt: true, updatedAt: true });

// === EXPLICIT API CONTRACT TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Folder = typeof folders.$inferSelect;
export type InsertFolder = z.infer<typeof insertFolderSchema>;

export type Script = typeof scripts.$inferSelect;
export type InsertScript = z.infer<typeof insertScriptSchema>;

export type TestSchedule = typeof testSchedules.$inferSelect;
export type InsertTestSchedule = z.infer<typeof insertTestScheduleSchema>;

export type TestExecution = typeof testExecutions.$inferSelect;
export type InsertTestExecution = z.infer<typeof insertTestExecutionSchema>;

export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export type Tag = typeof tags.$inferSelect;
export type InsertTag = z.infer<typeof insertTagSchema>;

export type ScriptTag = typeof scriptTags.$inferSelect;
export type InsertScriptTag = z.infer<typeof insertScriptTagSchema>;

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;

export type TestTemplate = typeof testTemplates.$inferSelect;
export type InsertTestTemplate = z.infer<typeof insertTestTemplateSchema>;

export type BaselineExecution = typeof baselineExecutions.$inferSelect;
export type InsertBaselineExecution = z.infer<typeof insertBaselineExecutionSchema>;

export type SlaRule = typeof slaRules.$inferSelect;
export type InsertSlaRule = z.infer<typeof insertSlaRuleSchema>;

export type ExecutionSlaRule = typeof executionSlaRules.$inferSelect;
export type InsertExecutionSlaRule = z.infer<typeof insertExecutionSlaRuleSchema>;

export type AutoAbortRule = typeof autoAbortRules.$inferSelect;
export type InsertAutoAbortRule = z.infer<typeof insertAutoAbortRuleSchema>;

export type ExecutionAutoAbortRule = typeof executionAutoAbortRules.$inferSelect;
export type InsertExecutionAutoAbortRule = z.infer<typeof insertExecutionAutoAbortRuleSchema>;

export type ScheduleWithDetails = TestSchedule & { 
  script: Script;
  creator: User;
  executions: TestExecution[];
};
export type ExecutionWithDetails = TestExecution & {
  schedule: TestSchedule & { script: Script };
  comments: (Comment & { user: User })[];
};

export type DashboardStats = {
  totalScripts: number;
  totalExecutions: number;
  passRate: number;
  activeTests: number;
  recentExecutions: ExecutionWithDetails[];
  performanceMetrics?: {
    avgResponseTime: number;
    avgThroughput: number;
    avgP95: number;
    avgErrorRate: number;
    testsAnalyzed: number;
  };
  todayStats?: {
    completed: number;
    failed: number;
    running: number;
    scheduled: number;
  };
};

// === REGRESSION THRESHOLDS ===

export const regressionThresholds = pgTable("regression_thresholds", {
  id: serial("id").primaryKey(),
  scriptId: integer("script_id").notNull().references(() => scripts.id, { onDelete: "cascade" }),
  metric: text("metric").notNull(),
  warningPercent: integer("warning_percent").notNull().default(10),
  criticalPercent: integer("critical_percent").notNull().default(25),
  isEnabled: boolean("is_enabled").default(true).notNull(),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("regression_thresholds_script_id_idx").on(table.scriptId),
]);

export const insertRegressionThresholdSchema = createInsertSchema(regressionThresholds).omit({ id: true, createdAt: true, updatedAt: true });
export type RegressionThreshold = typeof regressionThresholds.$inferSelect;
export type InsertRegressionThreshold = z.infer<typeof insertRegressionThresholdSchema>;

// === PASSWORD RESET TOKENS ===

export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at", { mode: 'string', withTimezone: true }).notNull(),
  used: boolean("used").default(false).notNull(),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("password_reset_tokens_token_idx").on(table.token),
  index("password_reset_tokens_user_id_idx").on(table.userId),
]);

// === DUMP ANALYZER TABLES ===

export const dumpFiles = pgTable("dump_files", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'heap' or 'thread'
  filePath: text("file_path").notNull(),
  fileSize: integer("file_size").notNull(),
  uploadedBy: integer("uploaded_by").notNull().references(() => users.id),
  status: text("status").default("pending").notNull(), // 'pending', 'analyzing', 'completed', 'failed'
  errorMessage: text("error_message"), // stores error details if analysis fails
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("dump_files_type_idx").on(table.type),
  index("dump_files_status_idx").on(table.status),
  index("dump_files_uploaded_by_idx").on(table.uploadedBy),
]);

// Thread dump analysis types
export type ThreadInfo = {
  id: string;
  name: string;
  state: string; // RUNNABLE, BLOCKED, WAITING, TIMED_WAITING, NEW, TERMINATED
  daemon: boolean;
  priority: number;
  lockInfo?: {
    lockName: string;
    lockOwner?: string;
    lockOwnerId?: string;
  };
  stackTrace: string[];
  blockedBy?: string;
  holding?: string[];
};

export type DeadlockInfo = {
  threads: string[];
  locks: string[];
  cycle: string[];
};

export type HotspotInfo = {
  method: string;
  count: number;
  percentage: number;
  callers: string[];
};

export type StackCluster = {
  id: number;
  pattern: string[];
  threadCount: number;
  threadNames: string[];
  similarity: number;
};

export type ContentionInfo = {
  lockName: string;
  waitingThreads: number;
  holdingThread: string;
  avgWaitTime?: number;
};

// Heap dump analysis types
export type ClassHistogramEntry = {
  className: string;
  instanceCount: number;
  shallowSize: number;
  retainedSize?: number;
};

export type LeakSuspect = {
  className: string;
  instanceCount: number;
  retainedSize: number;
  probability: 'high' | 'medium' | 'low';
  reason: string;
  referenceChain?: string[];
};

export type DominatorNode = {
  className: string;
  shallowSize: number;
  retainedSize: number;
  retainedPercentage: number;
  children?: DominatorNode[];
};

export type ReferenceChain = {
  target: string;
  chain: {
    className: string;
    fieldName: string;
  }[];
  gcRoot: string;
};

export const dumpAnalysis = pgTable("dump_analysis", {
  id: serial("id").primaryKey(),
  dumpFileId: integer("dump_file_id").notNull().references(() => dumpFiles.id, { onDelete: "cascade" }),
  analysisType: text("analysis_type").notNull(), // 'thread' or 'heap'
  
  // Thread dump analysis results
  threadSummary: jsonb("thread_summary").$type<{
    totalThreads: number;
    runnable: number;
    blocked: number;
    waiting: number;
    timedWaiting: number;
    terminated: number;
    daemonCount: number;
  }>(),
  threads: jsonb("threads").$type<ThreadInfo[]>(),
  deadlocks: jsonb("deadlocks").$type<DeadlockInfo[]>(),
  hotspots: jsonb("hotspots").$type<HotspotInfo[]>(),
  stackClusters: jsonb("stack_clusters").$type<StackCluster[]>(),
  contentionInfo: jsonb("contention_info").$type<ContentionInfo[]>(),
  detectedIssues: jsonb("detected_issues").$type<DetectedIssue[]>(),
  
  // Heap dump analysis results  
  heapSummary: jsonb("heap_summary").$type<{
    totalHeapSize: number;
    usedHeapSize: number;
    totalClasses: number;
    totalInstances: number;
  }>(),
  classHistogram: jsonb("class_histogram").$type<ClassHistogramEntry[]>(),
  leakSuspects: jsonb("leak_suspects").$type<LeakSuspect[]>(),
  dominatorTree: jsonb("dominator_tree").$type<DominatorNode[]>(),
  referenceChains: jsonb("reference_chains").$type<ReferenceChain[]>(),
  topObjects: jsonb("top_objects").$type<ClassHistogramEntry[]>(),

  gcMetrics: jsonb("gc_metrics").$type<{
    gcThreads?: {
      total: number;
      types: { name: string; count: number }[];
      totalCpuMs: number;
      gcOverheadPct: number;
      threads: { name: string; cpuMs: number; state: string }[];
    };
    heapPressure?: {
      utilizationPct: number;
      pressureLevel: 'low' | 'moderate' | 'high' | 'critical';
      estimatedSurvivorSize: number;
      estimatedOldGenSize: number;
      estimatedYoungGenSize: number;
      estimatedMetaspaceSize: number;
    };
    gcRootAnalysis?: {
      threadLocalRoots: number;
      finalizerObjects: number;
      weakReferences: number;
      softReferences: number;
      phantomReferences: number;
      jniGlobalRefs: number;
    };
    objectLifecycle?: {
      shortLived: { count: number; size: number };
      mediumLived: { count: number; size: number };
      longLived: { count: number; size: number };
    };
    recommendations: string[];
  }>(),

  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("dump_analysis_dump_file_id_idx").on(table.dumpFileId),
  index("dump_analysis_type_idx").on(table.analysisType),
]);

export type DetectedIssue = {
  type: 'deadlock' | 'thread_pool_saturation' | 'blocked_contention' | 'stuck_thread' | 'high_blocked_ratio';
  severity: 'warning' | 'critical';
  description: string;
  relatedThreads: string[];
};

// Comparison table for trend analysis
export const dumpComparisons = pgTable("dump_comparisons", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  dumpFileIds: jsonb("dump_file_ids").$type<number[]>().notNull(),
  comparisonType: text("comparison_type").notNull(), // 'heap' or 'thread'
  results: jsonb("results").$type<{
    growthTrends?: {
      className: string;
      instanceCounts: number[];
      sizeTrends: number[];
      growthRate: number;
    }[];
    threadStateTrends?: {
      timestamp: string;
      runnable: number;
      blocked: number;
      waiting: number;
    }[];
    stuckThreads?: {
      threadName: string;
      state: string;
      stackSignature: string;
      appearsInDumps: number;
      totalDumps: number;
    }[];
    detectedIssues?: DetectedIssue[];
    memoryTrends?: {
      timestamp: string;
      usedHeap: number;
      totalHeap: number;
    }[];
  }>(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
});

// Relations for dump analyzer
export const dumpFilesRelations = relations(dumpFiles, ({ one, many }) => ({
  uploader: one(users, {
    fields: [dumpFiles.uploadedBy],
    references: [users.id],
  }),
  analyses: many(dumpAnalysis),
}));

export const dumpAnalysisRelations = relations(dumpAnalysis, ({ one }) => ({
  dumpFile: one(dumpFiles, {
    fields: [dumpAnalysis.dumpFileId],
    references: [dumpFiles.id],
  }),
}));

export const dumpComparisonsRelations = relations(dumpComparisons, ({ one }) => ({
  creator: one(users, {
    fields: [dumpComparisons.createdBy],
    references: [users.id],
  }),
}));

// Insert schemas and types for dump analyzer
export const insertDumpFileSchema = createInsertSchema(dumpFiles).omit({ id: true, createdAt: true });
export const insertDumpAnalysisSchema = createInsertSchema(dumpAnalysis).omit({ id: true, createdAt: true });
export const insertDumpComparisonSchema = createInsertSchema(dumpComparisons).omit({ id: true, createdAt: true });

export type DumpFile = typeof dumpFiles.$inferSelect;
export type InsertDumpFile = z.infer<typeof insertDumpFileSchema>;

export type DumpAnalysis = typeof dumpAnalysis.$inferSelect;
export type InsertDumpAnalysis = z.infer<typeof insertDumpAnalysisSchema>;

export type DumpComparison = typeof dumpComparisons.$inferSelect;
export type InsertDumpComparison = z.infer<typeof insertDumpComparisonSchema>;

export type DumpFileWithAnalysis = DumpFile & {
  analyses: DumpAnalysis[];
  uploader: User;
};

export const dumpAnnotations = pgTable("dump_annotations", {
  id: serial("id").primaryKey(),
  dumpFileId: integer("dump_file_id").notNull().references(() => dumpFiles.id, { onDelete: "cascade" }),
  threadName: text("thread_name"),
  issueIndex: integer("issue_index"),
  note: text("note").notNull(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("dump_annotations_dump_id_idx").on(table.dumpFileId),
]);

export const dumpBookmarks = pgTable("dump_bookmarks", {
  id: serial("id").primaryKey(),
  dumpFileId: integer("dump_file_id").notNull().references(() => dumpFiles.id, { onDelete: "cascade" }),
  threadName: text("thread_name").notNull(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("dump_bookmarks_dump_id_idx").on(table.dumpFileId),
  index("dump_bookmarks_user_idx").on(table.createdBy),
]);

export const insertDumpAnnotationSchema = createInsertSchema(dumpAnnotations).omit({ id: true, createdAt: true });
export const insertDumpBookmarkSchema = createInsertSchema(dumpBookmarks).omit({ id: true, createdAt: true });

export type DumpAnnotation = typeof dumpAnnotations.$inferSelect;
export type InsertDumpAnnotation = z.infer<typeof insertDumpAnnotationSchema>;
export type DumpBookmark = typeof dumpBookmarks.$inferSelect;
export type InsertDumpBookmark = z.infer<typeof insertDumpBookmarkSchema>;


// === TEST CHECKPOINTS FOR RESUME CAPABILITY ===

export const testCheckpoints = pgTable("test_checkpoints", {
  id: serial("id").primaryKey(),
  executionId: integer("execution_id").notNull().unique().references(() => testExecutions.id, { onDelete: "cascade" }),
  
  // State tracking
  lastProcessedOffset: integer("last_processed_offset").default(0).notNull(), // byte offset in output file
  metricsCount: integer("metrics_count").default(0).notNull(),
  lastMetricTimestamp: timestamp("last_metric_timestamp", { mode: 'string', withTimezone: true }),
  
  // Execution state
  state: text("state").notNull(), // 'running', 'paused', 'resumable', 'completed'
  progress: integer("progress").default(0).notNull(), // percentage 0-100
  
  // Recovery data
  recoveryData: jsonb("recovery_data").$type<{
    pid?: number;
    outputFile?: string;
    startTime?: string;
    elapsedSeconds?: number;
    accumulatedTotals?: {
      totalRequests: number;
      failedRequests: number;
      totalResponseTime: number;
    };
  }>(),
  
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("test_checkpoints_execution_id_idx").on(table.executionId),
  index("test_checkpoints_state_idx").on(table.state),
]);

// === CUSTOM ENVIRONMENTS ===

export const customEnvironments = pgTable("custom_environments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
});

// === DATA RETENTION SETTINGS ===

export const dataRetentionSettings = pgTable("data_retention_settings", {
  id: serial("id").primaryKey(),
  settingKey: text("setting_key").notNull().unique(),
  settingValue: integer("setting_value").notNull(), // in days
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedBy: integer("updated_by").references(() => users.id, { onDelete: "set null" }),
});

export const cleanupHistory = pgTable("cleanup_history", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  thresholdDays: integer("threshold_days").notNull(),
  deletedCount: integer("deleted_count").notNull().default(0),
  status: text("status").notNull().default("completed"),
  initiatedBy: integer("initiated_by").notNull().references(() => users.id),
  startedAt: timestamp("started_at", { mode: 'string', withTimezone: true }).defaultNow(),
  completedAt: timestamp("completed_at", { mode: 'string', withTimezone: true }),
  notes: text("notes"),
}, (table) => [
  index("cleanup_history_category_idx").on(table.category),
  index("cleanup_history_started_at_idx").on(table.startedAt),
]);

export type CleanupHistory = typeof cleanupHistory.$inferSelect;

// === AUDIT LOG ===

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id), // Who performed the action
  action: text("action").notNull(), // CREATE, UPDATE, DELETE, EXECUTE, etc.
  resourceType: text("resource_type").notNull(), // scripts, schedules, executions, users, etc.
  resourceId: text("resource_id"), // ID of the resource (can be string or number)
  details: jsonb("details").$type<{
    changes?: Record<string, any>;
    metadata?: Record<string, any>;
    ipAddress?: string;
    userAgent?: string;
  }>(),
  timestamp: timestamp("timestamp", { mode: 'string', withTimezone: true }).defaultNow().notNull(),
}, (table) => [
  index("audit_logs_user_id_idx").on(table.userId),
  index("audit_logs_resource_type_idx").on(table.resourceType),
  index("audit_logs_timestamp_idx").on(table.timestamp),
  index("audit_logs_action_idx").on(table.action),
  index("audit_logs_user_timestamp_idx").on(table.userId, table.timestamp),
]);

// Relations for new tables
export const testCheckpointsRelations = relations(testCheckpoints, ({ one }) => ({
  execution: one(testExecutions, {
    fields: [testCheckpoints.executionId],
    references: [testExecutions.id],
  }),
}));

export const auditLogsRelations = relations(auditLogs, ({ one }) => ({
  user: one(users, {
    fields: [auditLogs.userId],
    references: [users.id],
  }),
}));

// Insert schemas for new tables
export const insertTestCheckpointSchema = createInsertSchema(testCheckpoints).omit({ id: true, createdAt: true, updatedAt: true });
export const insertDataRetentionSettingSchema = createInsertSchema(dataRetentionSettings).omit({ id: true, updatedAt: true });
export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ id: true, timestamp: true });

// Types for new tables
export type TestCheckpoint = typeof testCheckpoints.$inferSelect;
export type InsertTestCheckpoint = z.infer<typeof insertTestCheckpointSchema>;

export type DataRetentionSetting = typeof dataRetentionSettings.$inferSelect;
export type InsertDataRetentionSetting = z.infer<typeof insertDataRetentionSettingSchema>;

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;

export const insertCustomEnvironmentSchema = createInsertSchema(customEnvironments).omit({ id: true, createdAt: true });
export type CustomEnvironment = typeof customEnvironments.$inferSelect;
export type InsertCustomEnvironment = z.infer<typeof insertCustomEnvironmentSchema>;

// === EMAIL SETTINGS ===

export const emailSettings = pgTable("email_settings", {
  id: serial("id").primaryKey(),
  smtpHost: text("smtp_host").notNull().default("smtp.office365.com"),
  smtpPort: integer("smtp_port").notNull().default(587),
  senderEmail: text("sender_email").notNull(),
  senderPassword: text("sender_password").notNull(),
  defaultRecipients: jsonb("default_recipients").$type<string[]>().default([]),
  enabled: boolean("enabled").notNull().default(false),
  updatedBy: integer("updated_by").references(() => users.id, { onDelete: "set null" }),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
});

export const emailLog = pgTable("email_log", {
  id: serial("id").primaryKey(),
  executionId: integer("execution_id").references(() => testExecutions.id, { onDelete: "set null" }),
  eventType: text("event_type").notNull(),
  recipients: jsonb("recipients").$type<string[]>().notNull(),
  subject: text("subject").notNull(),
  status: text("status").notNull().default("pending"),
  attempts: integer("attempts").notNull().default(0),
  lastError: text("last_error"),
  sentAt: timestamp("sent_at", { mode: 'string', withTimezone: true }),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("email_log_execution_id_idx").on(table.executionId),
  index("email_log_event_type_idx").on(table.eventType),
]);

export const insertEmailSettingsSchema = createInsertSchema(emailSettings).omit({ id: true, updatedAt: true });
export const insertEmailLogSchema = createInsertSchema(emailLog).omit({ id: true, createdAt: true });

export type EmailSettings = typeof emailSettings.$inferSelect;
export type InsertEmailSettings = z.infer<typeof insertEmailSettingsSchema>;
export type EmailLog = typeof emailLog.$inferSelect;
export type InsertEmailLog = z.infer<typeof insertEmailLogSchema>;

export const testCompletionReports = pgTable("test_completion_reports", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  projectId: integer("project_id").references(() => projects.id, { onDelete: "set null" }),
  projectName: text("project_name"),
  featureName: text("feature_name"),
  objective: text("objective"),
  scope: text("scope"),
  environmentNotes: text("environment_notes"),
  recommendations: text("recommendations"),
  overallVerdict: text("overall_verdict"), // 'go', 'no_go', 'conditional', 'pending'
  verdictNotes: text("verdict_notes"),
  executionIds: jsonb("execution_ids").$type<number[]>().notNull(),
  compareExecutionIds: jsonb("compare_execution_ids").$type<number[]>(),
  reportSnapshot: jsonb("report_snapshot").$type<{
    generatedAt: string;
    sections: {
      testType: string;
      executionId: number;
      scheduleName: string;
      scriptName: string;
      environment: string;
      vusers: number;
      duration: number;
      startTime: string;
      endTime: string;
      status: string;
      totalRequests: number;
      failedRequests: number;
      avgResponseTime: number;
      throughput: number;
      errorRate: number;
      transactionDetails?: TransactionDetail[];
      slaViolations?: any;
      baselineDeviation?: any;
    }[];
    consolidatedSla: {
      totalRules: number;
      passed: number;
      failed: number;
      violations: {
        executionId: number;
        testType: string;
        metric: string;
        threshold: number;
        actual: number;
        label?: string;
      }[];
    };
  }>(),
  status: text("status").default("draft").notNull(), // 'draft', 'finalized'
  reviewStatus: text("review_status").default("draft"), // 'draft', 'in_review', 'changes_requested', 'approved', 'rejected'
  reviewRequestedAt: timestamp("review_requested_at", { mode: 'string', withTimezone: true }),
  finalApprovedAt: timestamp("final_approved_at", { mode: 'string', withTimezone: true }),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("test_completion_reports_project_id_idx").on(table.projectId),
  index("test_completion_reports_created_by_idx").on(table.createdBy),
  index("test_completion_reports_status_idx").on(table.status),
  index("test_completion_reports_review_status_idx").on(table.reviewStatus),
]);

export const insertTestCompletionReportSchema = createInsertSchema(testCompletionReports).omit({ id: true, createdAt: true, updatedAt: true });
export type TestCompletionReport = typeof testCompletionReports.$inferSelect;
export type InsertTestCompletionReport = z.infer<typeof insertTestCompletionReportSchema>;

// === REMOTE INGESTION ===

export const remoteIngestTokens = pgTable("remote_ingest_tokens", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  tokenHash: text("token_hash").notNull(),
  tokenPrefix: text("token_prefix").notNull(),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  revokedAt: timestamp("revoked_at", { mode: 'string', withTimezone: true }),
  lastUsedAt: timestamp("last_used_at", { mode: 'string', withTimezone: true }),
  allowedExecutionIds: jsonb("allowed_execution_ids").$type<number[] | null>(),
  lastHeartbeatAt: timestamp("last_heartbeat_at", { mode: 'string', withTimezone: true }),
  activeExecutionCount: integer("active_execution_count").default(0),
  completedExecutionCount: integer("completed_execution_count").default(0),
  totalSamplesIngested: integer("total_samples_ingested").default(0),
  lastNodeId: text("last_node_id"),
}, (table) => [
  index("remote_ingest_tokens_created_by_idx").on(table.createdBy),
  index("remote_ingest_tokens_token_prefix_idx").on(table.tokenPrefix),
]);

export const insertRemoteIngestTokenSchema = createInsertSchema(remoteIngestTokens).omit({ id: true, createdAt: true, revokedAt: true, lastUsedAt: true });
export type RemoteIngestToken = typeof remoteIngestTokens.$inferSelect;
export type InsertRemoteIngestToken = z.infer<typeof insertRemoteIngestTokenSchema>;

// === REPORT DELIVERY SCHEDULES ===

export const reportDeliverySchedules = pgTable("report_delivery_schedules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  recipients: jsonb("recipients").$type<string[]>().notNull(),
  frequency: text("frequency").notNull().default("weekly"),
  dayOfWeek: integer("day_of_week"),
  dayOfMonth: integer("day_of_month"),
  timeOfDay: text("time_of_day").notNull().default("09:00"),
  timezone: text("timezone").notNull().default("UTC"),
  filters: jsonb("filters").$type<{
    projectId?: number;
    testTypeId?: number;
    status?: string;
    environment?: string;
  }>(),
  includeAttachments: boolean("include_attachments").notNull().default(false),
  lastSentAt: timestamp("last_sent_at", { mode: 'string', withTimezone: true }),
  nextRunAt: timestamp("next_run_at", { mode: 'string', withTimezone: true }),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("report_delivery_schedules_enabled_idx").on(table.enabled),
  index("report_delivery_schedules_next_run_idx").on(table.nextRunAt),
  index("report_delivery_schedules_created_by_idx").on(table.createdBy),
]);

export const insertReportDeliveryScheduleSchema = createInsertSchema(reportDeliverySchedules).omit({ id: true, createdAt: true, updatedAt: true, lastSentAt: true });
export type ReportDeliverySchedule = typeof reportDeliverySchedules.$inferSelect;
export type InsertReportDeliverySchedule = z.infer<typeof insertReportDeliveryScheduleSchema>;

// === REPORT APPROVALS (Sign-Off Chain) ===

export const reportApprovals = pgTable("report_approvals", {
  id: serial("id").primaryKey(),
  reportId: integer("report_id").notNull().references(() => testCompletionReports.id, { onDelete: "cascade" }),
  reviewerUserId: integer("reviewer_user_id").notNull().references(() => users.id),
  stepOrder: integer("step_order").notNull().default(1),
  status: text("status").notNull().default("pending"), // 'pending', 'approved', 'rejected', 'changes_requested'
  comment: text("comment"),
  actedAt: timestamp("acted_at", { mode: 'string', withTimezone: true }),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("report_approvals_report_id_idx").on(table.reportId),
  index("report_approvals_reviewer_idx").on(table.reviewerUserId),
]);

export const insertReportApprovalSchema = createInsertSchema(reportApprovals).omit({ id: true, createdAt: true, actedAt: true });
export type ReportApproval = typeof reportApprovals.$inferSelect;
export type InsertReportApproval = z.infer<typeof insertReportApprovalSchema>;

// === CI/CD API TOKENS ===

export const apiTokens = pgTable("api_tokens", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  tokenHash: text("token_hash").notNull(),
  tokenPrefix: text("token_prefix").notNull(),
  scopes: jsonb("scopes").$type<string[]>().notNull().default([]),
  createdBy: integer("created_by").notNull().references(() => users.id),
  lastUsedAt: timestamp("last_used_at", { mode: 'string', withTimezone: true }),
  expiresAt: timestamp("expires_at", { mode: 'string', withTimezone: true }),
  revokedAt: timestamp("revoked_at", { mode: 'string', withTimezone: true }),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("api_tokens_created_by_idx").on(table.createdBy),
  index("api_tokens_token_prefix_idx").on(table.tokenPrefix),
]);

export const insertApiTokenSchema = createInsertSchema(apiTokens).omit({ id: true, createdAt: true, lastUsedAt: true, revokedAt: true });
export type ApiToken = typeof apiTokens.$inferSelect;
export type InsertApiToken = z.infer<typeof insertApiTokenSchema>;

// === WEBHOOKS ===

export const webhooks = pgTable("webhooks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  url: text("url").notNull(),
  secret: text("secret"),
  type: text("type").notNull().default("generic"),
  events: jsonb("events").$type<string[]>().notNull().default([]),
  enabled: boolean("enabled").notNull().default(true),
  headers: jsonb("headers").$type<Record<string, string>>(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  lastDeliveryAt: timestamp("last_delivery_at", { mode: 'string', withTimezone: true }),
  lastDeliveryStatus: text("last_delivery_status"),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("webhooks_created_by_idx").on(table.createdBy),
  index("webhooks_enabled_idx").on(table.enabled),
]);

export const insertWebhookSchema = createInsertSchema(webhooks).omit({ id: true, createdAt: true, updatedAt: true, lastDeliveryAt: true, lastDeliveryStatus: true });
export type Webhook = typeof webhooks.$inferSelect;
export type InsertWebhook = z.infer<typeof insertWebhookSchema>;

export const insertExecutionWorkloadTargetsSchema = createInsertSchema(executionWorkloadTargets).omit({ id: true, createdAt: true });
export type ExecutionWorkloadTarget = typeof executionWorkloadTargets.$inferSelect;
export type InsertExecutionWorkloadTarget = z.infer<typeof insertExecutionWorkloadTargetsSchema>;

export const webhookDeliveries = pgTable("webhook_deliveries", {
  id: serial("id").primaryKey(),
  webhookId: integer("webhook_id").notNull().references(() => webhooks.id, { onDelete: "cascade" }),
  event: text("event").notNull(),
  payload: jsonb("payload"),
  responseStatus: integer("response_status"),
  responseBody: text("response_body"),
  error: text("error"),
  attempts: integer("attempts").notNull().default(1),
  deliveredAt: timestamp("delivered_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("webhook_deliveries_webhook_id_idx").on(table.webhookId),
  index("webhook_deliveries_event_idx").on(table.event),
  index("webhook_deliveries_delivered_at_idx").on(table.deliveredAt),
]);

// === REPORT TEMPLATES ===

export const reportTemplates = pgTable("report_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  sections: jsonb("sections").$type<{
    id: string;
    type: 'builtin' | 'custom';
    key?: string;
    title: string;
    defaultContent?: string;
    enabled: boolean;
  }[]>().notNull(),
  isDefault: boolean("is_default").default(false).notNull(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("report_templates_created_by_idx").on(table.createdBy),
]);

export const insertReportTemplateSchema = createInsertSchema(reportTemplates).omit({ id: true, createdAt: true, updatedAt: true });
export type ReportTemplate = typeof reportTemplates.$inferSelect;
export type InsertReportTemplate = z.infer<typeof insertReportTemplateSchema>;

export const scriptGenerations = pgTable("script_generations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  status: text("status").default("processing").notNull(),
  inputType: text("input_type").notNull(),
  inputFileName: text("input_file_name"),
  inputFileSize: integer("input_file_size"),
  generatedJmxPath: text("generated_jmx_path"),
  sampleCsvPath: text("sample_csv_path"),
  generatedJmxContent: text("generated_jmx_content"),
  sampleCsvContent: text("sample_csv_content"),
  correlations: jsonb("correlations").$type<Array<{
    variable: string;
    extractorType: string;
    pattern: string;
    sourceRequest: string;
    targetRequests: string[];
    originalValue: string;
  }>>(),
  parameterizations: jsonb("parameterizations").$type<Array<{
    variable: string;
    originalValue: string;
    occurrences: Array<{ requestIndex: number; location: string; fieldName: string }>;
  }>>(),
  issues: jsonb("issues").$type<Array<{
    severity: string;
    message: string;
    request?: string;
  }>>(),
  qualityScore: integer("quality_score"),
  readinessLevel: text("readiness_level"),
  stats: jsonb("stats").$type<{
    totalEntries: number;
    filteredEntries: number;
    transactionGroups: number;
    requestCount: number;
    domains: string[];
  }>(),
  errorMessage: text("error_message"),
  scriptId: integer("script_id").references(() => scripts.id, { onDelete: "set null" }),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { mode: 'string', withTimezone: true }).defaultNow(),
}, (table) => [
  index("script_generations_user_id_idx").on(table.userId),
  index("script_generations_status_idx").on(table.status),
]);

export const insertScriptGenerationSchema = createInsertSchema(scriptGenerations).omit({ id: true, createdAt: true });
export type ScriptGeneration = typeof scriptGenerations.$inferSelect;
export type InsertScriptGeneration = z.infer<typeof insertScriptGenerationSchema>;

export const executionMetricBuckets = pgTable("execution_metric_buckets", {
  id: serial("id").primaryKey(),
  executionId: integer("execution_id").notNull(),
  bucketTimeMs: doublePrecision("bucket_time_ms").notNull(),
  transactionLabel: text("transaction_label"),
  count: integer("count").notNull(),
  errorCount: integer("error_count").notNull().default(0),
  sumElapsed: real("sum_elapsed").notNull().default(0),
  minElapsed: real("min_elapsed").notNull().default(0),
  maxElapsed: real("max_elapsed").notNull().default(0),
  activeThreads: integer("active_threads"),
  p50: real("p50"),
  p90: real("p90"),
  p95: real("p95"),
  p99: real("p99"),
  centroids: jsonb("centroids").$type<number[][] | null>(),
}, (table) => [
  index("emb_execution_bucket_idx").on(table.executionId, table.bucketTimeMs),
  index("emb_execution_id_idx").on(table.executionId),
]);

export type ExecutionMetricBucket = typeof executionMetricBuckets.$inferSelect;
export type InsertExecutionMetricBucket = typeof executionMetricBuckets.$inferInsert;
