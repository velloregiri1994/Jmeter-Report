# PerfHub - Performance Engineering Platform

PerfHub is an enterprise-grade web application for performance engineering teams built exclusively around Apache JMeter. It provides end-to-end management of JMeter test scripts, scheduling and execution of load tests, real-time live metrics streaming during active tests, JTL result parsing, SLA monitoring, anomaly detection, baseline comparison, and comprehensive sign-off report generation.

The platform supports team collaboration with role-based access (admin, engineer, manager), user approval workflows, in-app notifications, webhooks, audit logging, CI/CD pipeline integration via API tokens, and remote JMeter test ingestion from distributed environments.

---

## Table of Contents

1. [Quick Start with Docker](#quick-start-with-docker)
2. [Manual Setup](#manual-setup)
   - [Prerequisites](#prerequisites)
   - [Windows](#windows-setup)
   - [macOS](#macos-setup)
   - [Linux](#linux-setup)
   - [Database Setup](#database-setup)
   - [Application Setup](#application-setup)
3. [Running the Application](#running-the-application)
4. [Environment Variables](#environment-variables)
5. [Configuration File](#configuration-file)
6. [Project Structure](#project-structure)
7. [System Architecture](#system-architecture)
8. [Features](#features)
9. [Pages and UI](#pages-and-ui)
10. [API Reference](#api-reference)
11. [Migrations](#migrations)
12. [Troubleshooting](#troubleshooting)

---

## Quick Start with Docker

The fastest way to get PerfHub running with all services.

### Prerequisites

- Docker 20+ and Docker Compose v2+
- At least 4 GB free RAM

### Steps

```bash
# 1. Clone the repository
git clone <repo-url> && cd perfhub_v3

# 2. Create your environment file
cp .env.example .env

# 3. Generate a session secret
openssl rand -base64 32
# Paste the output into .env as SESSION_SECRET

# 4. Start everything
docker-compose up -d

# 5. Open in your browser
open http://localhost:5000
```

First user to sign up is automatically approved as **admin**.

### Docker Services

| Service | Port | Description |
|---------|------|-------------|
| app | 5000 | PerfHub web application |
| db | 5432 | PostgreSQL 15 |
| redis | 6379 | Redis 7 (optional caching) |

### Docker Commands

| Command | Description |
|---------|-------------|
| `docker-compose up -d` | Start all services in background |
| `docker-compose up -d app db` | Start app + database only (minimal) |
| `docker-compose up -d --build` | Rebuild and start |
| `docker-compose logs -f app` | Follow app logs |
| `docker-compose logs -f db` | Follow database logs |
| `docker-compose down` | Stop all services |
| `docker-compose down -v` | Stop and delete all data |
| `docker-compose restart app` | Restart only the app |

### What Docker Installs Automatically

| Component | Version |
|-----------|---------|
| Node.js | 20 LTS |
| npm packages | All dependencies |
| Python 3 | With numpy, scipy, openpyxl, pyyaml |
| PostgreSQL | 15 Alpine |
| Redis | 7 Alpine |
| Apache JMeter | 5.6.3 |
| OpenJDK | 17 |
| Chromium | Headless (for PDF generation) |

### Docker Persistent Data

Data is stored in Docker volumes:
- `postgres_data` — Database files
- `redis_data` — Redis cache
- `app_reports` — Generated reports
- `app_uploads` — Uploaded test scripts
- `app_results` — Test execution results

### Docker Backup & Restore

```bash
# Export database
docker-compose exec db pg_dump -U perfhub perfhub > backup.sql

# Restore database
cat backup.sql | docker-compose exec -T db psql -U perfhub perfhub
```

### Docker Environment

Create a `.env` file to customize settings:

```env
POSTGRES_USER=perfhub
POSTGRES_PASSWORD=your_secure_password
POSTGRES_DB=perfhub
APP_PORT=5000
SESSION_SECRET=your-strong-random-string
```

---

## Automated Installer (Recommended for Manual Setup)

PerfHub includes automated installer scripts that handle all dependency installation, database setup, service configuration, and startup in a single command.

### Linux / macOS

```bash
# Run from the project root
chmod +x scripts/install.sh
sudo ./scripts/install.sh
```

**What it does:**
- Detects your OS (Debian/Ubuntu, RHEL/CentOS, Fedora, Arch, macOS)
- Installs Node.js 20+, PostgreSQL, Python 3 with required packages
- Creates the `perfhub` database and user with secure random password
- Installs npm dependencies
- Generates a `config.json` with connection details and session secret
- Configures a systemd service (Linux) or launchd agent (macOS) for auto-start
- Starts PerfHub and prints the access URL

**Uninstall:**
```bash
sudo ./scripts/uninstall.sh
```
Stops the service, removes the systemd/launchd configuration, and optionally deletes the database and all test data.

### Windows (PowerShell — Run as Administrator)

```powershell
# Run from the project root
.\scripts\install.ps1
```

**What it does:**
- Installs Node.js 20+, PostgreSQL, Python 3 via winget or Chocolatey
- Creates the `perfhub` database and user
- Installs npm dependencies and Python packages
- Configures a Windows service (via NSSM) or startup script for auto-start
- Starts PerfHub and prints the access URL

**Uninstall:**
```powershell
.\scripts\uninstall.ps1
```

### Custom Port

```bash
# Linux/macOS
PERFHUB_PORT=8080 sudo ./scripts/install.sh

# Windows
.\scripts\install.ps1 -Port 8080
```

If no port is specified, the installer automatically finds an available port (prefers 5000, then 3000, 8080, etc.).

---

## Manual Setup

Use this approach to run PerfHub directly on your machine without Docker (if you prefer to install dependencies yourself instead of using the automated installer above).

### Prerequisites

| Software | Version | Purpose |
|----------|---------|---------|
| Node.js | 20 LTS or higher | Application runtime |
| npm | Comes with Node.js | Package manager |
| PostgreSQL | 15 or higher | Database |
| Python | 3.11 or higher | JTL parsing & report generation |
| pip | Comes with Python | Python package manager |
| Apache JMeter | 5.6.3 or higher | Load testing engine |
| Java JDK | 11 or higher | Required by JMeter |

Optional:
- Redis 7+ (caching — falls back to in-memory if unavailable)

### Windows Setup

#### Install Node.js

1. Download LTS from [nodejs.org](https://nodejs.org/)
2. Run the installer, check "Automatically install necessary tools" if prompted

```powershell
node --version
npm --version
```

#### Install PostgreSQL

1. Download from [postgresql.org/download/windows](https://www.postgresql.org/download/windows/)
2. Run installer, select all components, set a password for the `postgres` user, keep default port 5432

```powershell
psql --version
```

#### Install Java JDK

1. Download from [adoptium.net](https://adoptium.net/) (JDK 11 or higher)
2. Set `JAVA_HOME` environment variable to your JDK path (e.g. `C:\Program Files\Eclipse Adoptium\jdk-11.x.x`)

```powershell
java -version
```

#### Install Apache JMeter

1. Download binary zip from [jmeter.apache.org](https://jmeter.apache.org/download_jmeter.cgi)
2. Extract to `C:\apache-jmeter-5.6.3`
3. Add `C:\apache-jmeter-5.6.3\bin` to PATH
4. Set `JMETER_HOME` = `C:\apache-jmeter-5.6.3`

```powershell
jmeter --version
```

#### Install Python

1. Download from [python.org/downloads](https://www.python.org/downloads/) (3.11+)
2. Check "Add Python to PATH" during install

```powershell
python --version
pip install numpy scipy openpyxl pyyaml
```

### macOS Setup

```bash
# Install Homebrew if not already installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install all dependencies
brew install node@20 postgresql@15 python@3.11 openjdk@11 jmeter
brew services start postgresql@15

# Set JAVA_HOME in ~/.zshrc
export JAVA_HOME=$(/usr/libexec/java_home -v 11)
export PATH="$JAVA_HOME/bin:$PATH"

# Install Python packages
pip3 install numpy scipy openpyxl pyyaml

# Verify installations
node --version && psql --version && java -version && jmeter --version && python3 --version
```

### Linux Setup

#### Ubuntu/Debian

```bash
sudo apt update

# Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# PostgreSQL
sudo apt install -y postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Java
sudo apt install -y openjdk-11-jdk
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64

# JMeter
wget https://archive.apache.org/dist/jmeter/binaries/apache-jmeter-5.6.3.tgz
sudo tar -xzf apache-jmeter-5.6.3.tgz -C /opt/
echo 'export JMETER_HOME=/opt/apache-jmeter-5.6.3' >> ~/.bashrc
echo 'export PATH="$JMETER_HOME/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc

# Python
sudo apt install -y python3 python3-pip
pip3 install numpy scipy openpyxl pyyaml
```

#### Fedora/RHEL/CentOS

```bash
sudo dnf install -y nodejs npm
sudo dnf install -y postgresql-server postgresql-contrib
sudo postgresql-setup --initdb
sudo systemctl start postgresql && sudo systemctl enable postgresql
sudo dnf install -y java-11-openjdk java-11-openjdk-devel
sudo dnf install -y python3 python3-pip
pip3 install numpy scipy openpyxl pyyaml

# JMeter
wget https://archive.apache.org/dist/jmeter/binaries/apache-jmeter-5.6.3.tgz
sudo tar -xzf apache-jmeter-5.6.3.tgz -C /opt/
echo 'export JMETER_HOME=/opt/apache-jmeter-5.6.3' >> ~/.bashrc
echo 'export PATH="$JMETER_HOME/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

### Database Setup

Create a database and user:

```sql
-- Windows: psql -U postgres
-- macOS/Linux: sudo -u postgres psql

CREATE DATABASE perfhub;
CREATE USER perfhub WITH PASSWORD 'your_password_here';
GRANT ALL PRIVILEGES ON DATABASE perfhub TO perfhub;
GRANT ALL ON SCHEMA public TO perfhub;
```

### Application Setup

```bash
cd perfhub_v3

# Install Node.js dependencies
npm install

# Create environment file
cp .env.example .env
# Edit .env with your DATABASE_URL and SESSION_SECRET

# Push database schema
npm run db:push

# Start in development mode
npm run dev
```

---

## Running the Application

### Development Mode

```bash
npm run dev
```

Starts at **http://localhost:5000** with hot reload (tsx + Vite dev server proxied through Express).

### Production Mode

```bash
npm run build    # Vite builds frontend to dist/public/, esbuild bundles server to dist/index.cjs
npm start        # NODE_ENV=production node dist/index.cjs
```

### NPM Scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | Start development server with hot reload |
| `npm run build` | Build frontend + bundle backend for production |
| `npm start` | Start production server |
| `npm run check` | Run TypeScript type checking |
| `npm run db:push` | Push database schema changes |
| `npm run migrate:timezone` | Run timezone migration |
| `npm run migrate:script-nullable` | Run script-id nullable migration |

### First-Time Setup

On fresh installs (no users in database), the app displays an enterprise setup wizard that guides through:
1. Welcome screen
2. System requirements check
3. License agreement (EULA with scroll-to-accept)
4. Admin account creation
5. Configuration
6. Completion

The first user is auto-granted admin rights. Detection endpoint: `GET /api/setup/status` returns `{ needsSetup: boolean }`.

---

## Environment Variables

### Required

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | PostgreSQL connection string |
| `SESSION_SECRET` | Secret for session encryption (change in production!) |

### Application

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `5000` | HTTP server port |
| `NODE_ENV` | `development` | `production` or `development` |
| `TRUST_PROXY` | `false` | Set `true` behind a reverse proxy |

### Database Pool

| Variable | Default | Description |
|----------|---------|-------------|
| `DB_POOL_MAX` | `20` | Maximum connections |
| `DB_POOL_MIN` | `2` | Minimum connections |
| `DB_IDLE_TIMEOUT` | `30000` | Idle timeout (ms) |
| `DB_CONNECTION_TIMEOUT` | `10000` | Connection timeout (ms) |

### Optional Services

| Variable | Description |
|----------|-------------|
| `REDIS_URL` | Redis connection string for caching (falls back to in-memory) |
| `JMETER_HOME` | Path to JMeter installation (if not in PATH or config.json) |
| `INGEST_SECRET` | Token for external JMeter metrics ingestion |
| `PYTHON_CMD` | Python command (default: `python3`) |

### Cache TTLs (seconds)

| Variable | Default | Description |
|----------|---------|-------------|
| `CACHE_TTL_DEFAULT` | `60` | General cache TTL |
| `CACHE_TTL_DASHBOARD` | `30` | Dashboard stats cache |
| `CACHE_TTL_SCRIPTS` | `60` | Script list cache |
| `CACHE_TTL_SCHEDULES` | `30` | Schedule list cache |

---

## Configuration File

You can configure the application using a `config.json` file in the project root:

```json
{
  "database": {
    "url": "postgresql://username:password@localhost:5432/perfhub"
  },
  "jmeter": {
    "home": "/path/to/apache-jmeter-5.6.3",
    "executable": ""
  },
  "python": {
    "command": "python3"
  }
}
```

**Resolution order:**
- Database: `config.json` > `DATABASE_URL` env var
- JMeter: `config.json` executable > `config.json` home > `JMETER_HOME` env > system PATH

---

## Project Structure

```
perfhub_v3/
├── client/                 # React frontend (Vite, TypeScript)
│   └── src/
│       ├── components/     # Reusable UI components (shadcn/ui + custom)
│       │   ├── ui/         # shadcn/ui base components
│       │   ├── executions/ # Execution-specific components (live-metrics, charts)
│       │   └── ...         # Feature components (auto-abort, quick-config, etc.)
│       ├── pages/          # Page components (route-based)
│       │   ├── dashboard.tsx
│       │   ├── scripts/    # Script repository
│       │   ├── schedule/   # Test scheduling
│       │   ├── executions/ # Execution monitoring
│       │   ├── comparison/ # Side-by-side comparison
│       │   ├── trends/     # Historical trend analysis
│       │   ├── reports/    # HTML report viewer
│       │   ├── completion-reports/ # Sign-off reports
│       │   ├── dumps/      # Dump file analysis
│       │   ├── tracker/    # Test execution tracker
│       │   ├── calendar/   # Calendar view
│       │   ├── notifications/ # Notification center
│       │   ├── platform/   # Platform settings (admin)
│       │   ├── admin/      # Admin pages
│       │   ├── landing.tsx  # Login/signup
│       │   └── setup.tsx    # First-time setup wizard
│       ├── hooks/          # Custom React hooks
│       └── lib/            # Utility functions
├── server/                 # Express backend (TypeScript)
│   ├── analyzers/          # Thread dump, heap dump, GC log parsers
│   ├── live-metrics/       # Real-time metrics streaming engine
│   │   ├── aggregator.ts           # Metrics aggregation with t-digest percentiles
│   │   ├── live-analysis-engine.ts # Unified spike detection + correlation + insights
│   │   ├── stats-utils.ts          # Shared statistical utilities (RollingStats, etc.)
│   │   ├── remote-stream.ts        # Remote JMeter stream handler
│   │   └── index.ts                # Live metrics coordinator
│   ├── auth-routes.ts      # Login, signup, session, password reset
│   ├── script-routes.ts    # Script CRUD, upload, JMX parsing, dependencies, JARs
│   ├── schedule-routes.ts  # Schedule management with recurrence
│   ├── execution-routes.ts # Execution tracking, results, anomaly detection
│   ├── admin-routes.ts     # User management, email settings, audit logs, ingest tokens
│   ├── cicd-routes.ts      # CI/CD API token management
│   ├── ingest-routes.ts    # Remote JTL sample ingestion
│   ├── completion-report-routes.ts # Sign-off reports with approval workflow
│   ├── report-delivery-routes.ts   # Scheduled email delivery
│   ├── dump-routes.ts      # Dump file upload, analysis, comparison, annotations
│   ├── notification-routes.ts # In-app notifications and preferences
│   ├── webhook-routes.ts   # Outbound webhook integrations
│   ├── anomaly-detector.ts # Post-hoc batch analysis (baseline, regression, step-change)
│   ├── jmeter-worker.ts    # Background worker for test execution
│   ├── scheduler-service.ts # Scheduled test trigger service (polls every 30s)
│   ├── websocket.ts        # WebSocket server for real-time updates
│   ├── routes.ts           # API route registration + inline routes
│   ├── storage.ts          # Database abstraction layer
│   ├── db.ts               # PostgreSQL connection pool
│   ├── error-handler.ts    # Centralized error handling with correlation IDs
│   ├── validation.ts       # Zod validation middleware
│   ├── audit-logger.ts     # Audit log service
│   └── index.ts            # Server entry point
├── shared/                 # Shared types & Drizzle schema
│   └── schema.ts           # Database schema (single source of truth)
├── scripts/                # Python parsers, report generators & installers
│   ├── jtl_parser.py       # Simplified JTL parser (final metrics)
│   ├── jtl_parser_full.py  # Full JTL parser + metrics calculator (used by worker)
│   ├── jmeter-report.py    # HTML dashboard report with health scores (v4.2)
│   ├── install.sh          # Automated installer for Linux/macOS
│   ├── install.ps1         # Automated installer for Windows (PowerShell)
│   ├── uninstall.sh        # Uninstaller for Linux/macOS
│   └── uninstall.ps1       # Uninstaller for Windows
├── migrations/             # SQL migration scripts + TypeScript runners
├── uploads/                # Uploaded files
│   ├── scripts/            # JMeter JMX files
│   ├── dependencies/       # Script data files (CSV, JSON, XML, etc.)
│   └── dumps/              # Thread & heap dump files
├── results/                # Test execution output (JTL files, logs)
├── Dockerfile              # Multi-stage production image
├── docker-compose.yml      # Full stack (app + db + redis)
├── docker-entrypoint.sh    # Container startup script
└── .env.example            # Environment variable template
```

---

## System Architecture

### Frontend

- **Framework**: React 18 with TypeScript, bundled by Vite 7
- **Routing**: Wouter (lightweight client-side router)
- **Server State**: TanStack React Query for data fetching/caching
- **UI Components**: shadcn/ui (Radix primitives + Tailwind CSS, "new-york" style)
- **Charts**: Recharts for data visualization
- **Code Editor**: Monaco Editor for viewing/editing JMX scripts
- **Drag & Drop**: @dnd-kit for sortable interfaces
- **Animations**: Framer Motion for page transitions and micro-interactions
- **Forms**: React Hook Form with Zod resolvers
- **Carousel**: Embla Carousel
- **Resizable Panels**: react-resizable-panels
- **Path Aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend

- **Runtime**: Node.js 20 with Express
- **Language**: TypeScript compiled with tsx (dev) / esbuild (production)
- **Authentication**: Session-based auth with PostgreSQL session store (bcrypt, 12 rounds)
- **Authorization**: Role-based access control (admin, engineer, manager)
- **User Approval**: New signups require admin approval; first user auto-approved as admin
- **Rate Limiting**: express-rate-limit on auth endpoints (15 req/15min for login, 5 signups/hour, 5 password resets/15min), ingest endpoints (100 req/s for samples/heartbeat/metrics, 10/min for completion), CI/CD endpoints (30 req/min per token)
- **CSRF Protection**: Custom header check (`X-Requested-With: XMLHttpRequest`) required on state-changing requests; CI/CD and ingest endpoints exempted (Bearer token auth)
- **Validation**: Zod schemas via middleware
- **Audit Logging**: All significant actions logged to `audit_logs` table
- **Caching**: Redis (ioredis) with automatic fallback to in-memory cache (memorystore)
- **Error Handling**: Centralized `AppError` class with correlation IDs, structured error responses
- **Security**: Helmet middleware, compression, CORS
- **Email**: Nodemailer for SMTP-based notifications and report delivery

### Database

- **Database**: PostgreSQL 15+ (required)
- **ORM**: Drizzle ORM with drizzle-kit for schema management
- **Schema**: Defined in `shared/schema.ts` (single source of truth)
- **Schema Push**: `npm run db:push`
- **Sessions**: Stored in PostgreSQL via connect-pg-simple
- **Connection Pool**: Configurable via env vars (default max 20)
- **Key Tables**: users, scripts, test_schedules, test_executions, test_tracker, comments, notifications, audit_logs, api_tokens, remote_ingest_tokens, test_completion_reports, report_approvals, dump_files, dump_analysis, dump_comparisons, dump_annotations, projects, test_types, folders, sla_rules, execution_sla_rules, auto_abort_rules, saved_filter_views, report_delivery_schedules, cleanup_history, email_settings, notification_preferences, webhooks, tags, favorites, environments, templates, baselines, regression_thresholds

### Test Execution Flow

1. User creates a script (uploads JMX file) and a schedule (with config: vusers, ramp-up, duration, environment)
2. Schedule triggers (manually or via scheduler service every 30s) → creates execution record → queues JMeter run
3. Background worker spawns JMeter CLI process in `results/{runId}/` directory
4. Dependencies (CSV, JSON, JAR files) are automatically copied to the run folder
5. During execution: live metrics streamed via WebSocket, aggregated with t-digest percentiles
6. On completion: Python `jtl_parser_full.py` parses the JTL CSV file → outputs JSON metrics
7. Parser output mapped to DB format (field name conversion only, no recalculation)
8. Final metrics stored in execution's `resultSummary` JSON column
9. SLA violations checked, anomaly detection run, notifications sent, tracker updated
10. WebSocket broadcasts status updates (queued → running → parsing → completed/failed)

### Results Storage

Each run creates a `results/<runId>/` folder containing:
- `results.csv` — Raw JMeter JTL output (CSV format)
- `jmeter.log` — JMeter execution logs
- `metrics.json` — Parsed metrics (output of `jtl_parser_full.py`)
- `buckets.json` — Time-series bucketed aggregation data (generated by parser)
- `system-metrics.jsonl` — System metrics collected during execution
- `{script}.jmx` — Copy of the test script file
- `lib/` — Optional JAR files (if script has JAR dependencies)

### Data Conventions

- Error rates stored as decimals (0.0–1.0); frontend multiplies by 100 for percentage display
- Timestamps use `timestamp with time zone` (UTC storage, auto-converted on display)
- Dependency files schema: `dependencyFiles` JSONB field on scripts table — `[{originalName, storedPath, size, uploadedAt}]`
- JAR files schema: `jarFiles` JSONB field on scripts table — same format as dependency files

### WebSocket Protocol

- Endpoint: `/ws`
- Authentication: always requires valid session cookie (rejects with code 4401 if invalid)
- Heartbeat: 30-second ping/pong cycle detects and terminates dead connections
- Message types:
  - `execution_update` — execution status changes with optional `resultSummary`
  - `schedule_update` — schedule status changes
  - `live_metrics_update` — real-time metrics snapshot during active tests (includes `executionId`, `runId`, `snapshot`)
- Auto-abort warnings and status updates are sent via `execution_update` messages

### Analysis Architecture (Consolidated)

Two-module design for anomaly detection:

1. **`server/live-metrics/live-analysis-engine.ts`** — Unified real-time detection during active tests
   - Single `LiveAnalysisEngine` class handles spike detection, EWMA tracking (alpha=0.15), multi-metric correlation, and insight generation
   - One shared set of rolling buffers for RT, error, throughput, p95
   - Detection algorithms: RT spike, error spike, throughput drop, server overloaded, backend slowdown, throughput collapse, tail latency, gradual degradation
   - Ramp-up aware: skips detection during configured ramp-up period
   - Adaptive thresholds: scale with baseline (50ms min diff for low-baseline <100ms, 500ms for high-baseline >2000ms), throughput drop thresholds scale with stability (CV-based: 30% for stable, 50% for noisy)
   - Each anomaly includes a 0-100 confidence score
   - Exports `detectFromTimeseries()` for post-hoc analysis after test completion

2. **`server/anomaly-detector.ts`** — Post-hoc batch analyzer after test completion
   - Baseline comparison, transaction regression, step-change detection, hotspot scanning
   - Runs via `/api/executions/:id/anomaly-detection` endpoint

3. **`server/live-metrics/stats-utils.ts`** — Shared utilities used by both modules
   - RollingStats class (rolling buffer with median, MAD), RollingBuffer class
   - Error rate computation, timeseries normalization, linear regression slope
   - Percentile, standard deviation, median/MAD statistical functions

### Live Metrics & Stream Recovery

- **Streaming Percentiles**: t-digest algorithm (tdigest npm library) for memory-efficient approximate percentile estimation during live tests
- **Checkpoint Save/Restore**: Remote test streams save periodic checkpoints containing t-digest centroids. On stream recovery, centroids are imported directly (no raw sample expansion)
- **Parent Sample Handling**: Transaction Controller (parent) samples tracked separately, excluded from global percentiles and throughput
- **Adaptive Downsampling**: MAX_SERIES_POINTS=43200 (60 hours at 5s buckets). When series exceeds 14400 points (~20 hours), adjacent pairs are merged to halve the series while preserving trends
- **Memory Safety**: Transaction map capped at 10,000 entries, node metrics map capped at 500 nodes

### Auto-Abort Rules

- Per-script rules stored in `auto_abort_rules` table
- Supported metrics: errorRate, avgResponseTime, p90, p95, p99, maxResponseTime, throughput
- Rules trigger abort only after sustained breach for configurable seconds (default 30s)
- Local JMeter: triggers `cancelRun()` to kill JMeter process
- Remote JMeter: sets abort flag; ingest API response includes `abort: true` and `abortReason`
- Backend Listener Plugin (v1.3.0): parses abort signal from ingest response
- Manual abort: `POST /api/executions/:id/abort` with optional reason
- WebSocket broadcasts `_autoAbortWarning` events when breach tracking starts

---

## Features

### Dashboard
- Overview metrics: Active Tests, Test Scripts, Total Runs, Pass Rate
- Today's Activity summary (Completed, Failed, Running)
- Live Tests Running card with currently executing tests
- Recent Tests table with performance metrics
- Favorite Scripts quick access
- Quick action cards for scheduled, failed, and report sections

### Script Repository
- Upload and manage JMeter .jmx test scripts
- Folder-based organization
- Monaco Editor for in-browser script viewing/editing
- Thread group configuration (modify vusers, ramp-up, duration without editing XML)
- Timer configuration
- Plugin dependency detection
- Script tagging and favorites
- Script templates

### Test Dependency Management
- Upload CSV, JSON, XML, TXT, properties, DAT, TSV files per script (max 10MB each)
- Upload JAR files (plugins, JDBC drivers, custom samplers) per script (max 50MB each)
- Dependencies automatically copied to run folder before each test
- JARs placed in `lib/` subfolder and added to JMeter classpath via `user.classpath`
- Storage: `uploads/dependencies/{scriptId}/`

### Test Scheduling
- One-time or recurring schedules (daily, weekly, monthly, custom patterns)
- Timezone support (30+ time zones)
- Schedule enable/disable
- Bulk operations (run, cancel, delete multiple schedules)
- Schedule cloning
- Calendar view of scheduled tests

### Test Execution Monitoring
- Real-time live metrics during active tests via WebSocket
- Response time, throughput, error rate, active users charts
- Time range filters (1m, 5m, 15m, 30m, 1h, custom)
- Chart layout toggle (1-column or 2-column)
- Transaction performance breakdown
- Latency stability charts
- SLA violation alerts
- Anomaly detection with confidence scores
- Performance insights and correlations
- Execution comments/notes for team collaboration
- Re-run and abort capabilities
- Execution pinning

### Test Execution Tracker
- Denormalized `test_tracker` table for fast querying without joins
- Auto-populated after each test execution completes
- Project organization for grouping scripts
- Test type categorization (Load, Stress, Smoke, Endurance, Spike, Soak, etc.)
- Volume tracking: record test volume (users, TPS, etc.) for each scheduled run
- Environment filtering, date range presets (This Week, This Month, Last Month, This Year)
- Status filtering (pass, fail, blocked)
- Grouping by project, environment, or status
- Table and Gantt Timeline view modes
- Drag-and-drop row reordering
- Inline comments on tracker items
- Mini sparkline charts for performance trends
- Saved views with default view option
- CSV export with all filters applied
- Pagination for large datasets

### Test Comparison
- Side-by-side comparison of two executions
- Radar charts for multi-metric comparison
- Bar charts for relative performance
- Scatter plots for correlation analysis
- Detailed metrics: RT, Throughput, Error Rate, P50/P95/P99
- Visual variance indicators showing improvements/degradations

### Trends Analysis
- Historical trend visualization across multiple executions
- Date range presets (7d, 14d, 30d, 90d, all, custom)
- Filter by script and environment
- Avg Response Time, P95/P99, Throughput, Error Rate trend charts
- Linear regression analysis for trend prediction
- Regression detection with confidence levels
- Aggregated trend summaries

### SLA Monitoring & Baseline Management
- **Per-Script SLA Rules**: Define thresholds per script with global or per-transaction scope
- **Execution-Level SLA Rules**: Configure SLA rules specific to individual executions
- **Metrics**: avg, p90, p95, p99, max response time, error rate, throughput
- **Comparators**: lt, lte, gt, gte
- **Automatic Evaluation**: After each test run, SLA rules checked and violations recorded
- **Baseline Management**: Set any completed execution as baseline, with baseline history tracking
- **Regression Detection**: Automatic detection with configurable thresholds and severity levels (minor: 10-25%, moderate: 25-50%, severe: >50%)
- **Regression Thresholds**: Custom per-script thresholds for regression severity levels
- **Notifications**: Users notified on SLA violations

### Sign-Off / Completion Reports
- Create comprehensive test completion reports
- Dropdown selection for current and baseline test executions
- Test objective, scope, environment notes, recommendations
- Custom sections with enable/disable toggles and file uploads
- Overall verdict (passed, failed, pending)
- Multi-step approval workflow (request review → approve/reject)
- DOCX export with per-transaction bar charts (avg response time and throughput)
- HTML preview via iframe
- Snapshot-based: captures execution data at report creation time
- Refresh snapshot capability

### Report Generation & Delivery
- HTML dashboard reports with health scores (Python-generated)
- Report comments and annotations
- Scheduled email delivery of reports on configurable schedules
- Email delivery history and logs
- SMTP configuration via admin settings

### Dump File Analysis
- **Thread Dump Analysis**: Thread states, lock contention detection, deadlock detection
- **Heap Histogram Analysis**: Memory leak suspects, unbounded collections, top objects by size
- **GC Log Analysis**: GC event parsing, pause time metrics, throughput calculation
- **Dump Comparison**: Compare two dumps side-by-side
- **Annotations & Bookmarks**: Add notes to specific dump findings
- Drag & drop file upload
- Accepted file types: `.hprof`, `.txt`, `.tdump`, `.log`, `.dump`, `.bin` (max 500MB)

### CI/CD Integration
- API tokens with `phub_` prefix (hashed with bcrypt)
- Token scope management
- Bearer token authentication for pipeline endpoints
- Remote JTL sample ingestion from external JMeter instances
- Ingest endpoints: samples, heartbeat, complete, system metrics
- Backend Listener Plugin for JMeter (downloadable from admin panel)
- Rate limited: 100 req/s for samples, 10/min for execution creation, 30 req/min per CI token

### Notifications
- In-app notification center with filtering
- Notification types: Info, Warning, Error, SLA Violation, Success
- Notification preferences: channel selection, event subscriptions, quiet hours, mute rules
- Mark as read/unread, bulk operations

### Webhooks
- Outbound webhook integrations (Slack, Teams, PagerDuty, Generic)
- Event subscriptions management
- Delivery history and logs
- Webhook testing capability
- Custom headers support

### Administration
- **User Management**: Approval workflow, role assignment (admin, engineer, manager), user removal
- **Email Settings**: SMTP configuration, test connection, send test email, delivery logs
- **Ingest Tokens**: Create/manage remote ingest tokens, download backend listener
- **Audit Log**: Full activity tracking with action/resource type filtering
- **Data Retention**: Configurable retention policies, automatic cleanup scheduling, cleanup preview and history
- **Distributed Testing**: Remote agent management, multi-node test coordination
- **Environments**: Manage test environments
- **Projects & Test Types**: Organize scripts and categorize tests

### Additional Features
- **Command Palette**: Global search/navigation via Cmd+K
- **Folder Organization**: Organize scripts into folders
- **Tags**: Tag scripts for flexible categorization
- **Favorites**: Quick access to frequently used scripts
- **Templates**: Save and reuse script configurations
- **Saved Views**: Save tracker filter configurations as named views
- **Execution Pinning**: Pin important executions to prevent auto-cleanup
- **Execution Labels**: Add custom labels to executions

---

## Pages and UI

| Page | Route | Description |
|------|-------|-------------|
| Dashboard | `/` | Overview metrics, active tests, recent results |
| Scripts | `/scripts` | Script repository with folder organization |
| Script Detail | `/scripts/:id` | Script config, dependencies, SLA rules, executions |
| Schedules | `/schedule` | Test schedule management |
| Executions | `/executions` | Execution history with status filters |
| Execution Detail | `/executions/:id` | Live metrics, charts, comments, SLA results |
| Comparison | `/comparison` | Side-by-side execution comparison |
| Trends | `/trends` | Historical performance trend analysis |
| Reports | `/reports` | HTML report viewer and delivery |
| Completion Reports | `/completion-reports` | Sign-off report list |
| Create Report | `/completion-reports/create` | New sign-off report |
| Report Detail | `/completion-reports/:id` | Report preview, approval, export |
| Dump Analysis | `/dumps` | Upload and analyze dump files |
| Tracker | `/tracker` | Test execution tracker dashboard |
| Calendar | `/calendar` | Calendar view of scheduled tests |
| Notifications | `/notifications` | Notification center and preferences |
| Platform Settings | `/platform/*` | General, users, distributed, retention, CI/CD, webhooks, audit log |
| Setup Wizard | `/setup` | First-time platform configuration |

---

## API Reference

### Authentication
- `POST /api/auth/login` — Login (rate limited: 15 req/15min)
- `POST /api/auth/signup` — Register new user (rate limited: 5/hour)
- `POST /api/auth/logout` — Logout
- `GET /api/auth/session` — Get current session
- `POST /api/auth/forgot-password` — Request password reset (rate limited: 5/15min)
- `POST /api/auth/reset-password` — Reset password with token (rate limited: 5/15min)

### Setup
- `GET /api/setup/status` — Check if first-time setup is needed
- `GET /api/setup/check-requirements` — Check system requirements

### Scripts
- `GET/POST /api/scripts` — List/create scripts
- `GET/PATCH/DELETE /api/scripts/:id` — Get/update/delete script
- `POST /api/scripts/:scriptId/upload` — Upload JMX file
- `GET/PUT /api/scripts/:scriptId/content` — Get/update script content
- `GET/PUT /api/scripts/:scriptId/thread-groups` — Get/update thread groups
- `GET/PUT /api/scripts/:scriptId/timers` — Get/update timers
- `POST /api/scripts/:scriptId/dependencies` — Upload dependency files
- `DELETE /api/scripts/:scriptId/dependencies/:fileName` — Delete dependency
- `POST /api/scripts/:scriptId/jars` — Upload JAR files
- `DELETE /api/scripts/:scriptId/jars/:fileName` — Delete JAR
- `GET/POST /api/scripts/:scriptId/auto-abort-rules` — List/create auto-abort rules
- `PUT/DELETE /api/scripts/:scriptId/auto-abort-rules/:id` — Update/delete rule
- `GET /api/scripts/:id/plugin-check` — Check for required plugins

### Schedules
- `GET/POST /api/schedules` — List/create schedules
- `GET/PATCH /api/schedules/:id` — Get/update schedule
- `POST /api/schedules/:id/queue` — Queue a test run
- `POST /api/schedules/:id/cancel` — Cancel schedule
- `POST /api/schedules/:id/clone` — Clone schedule
- `POST /api/schedules/bulk/run` — Run multiple schedules
- `POST /api/schedules/bulk/cancel` — Cancel multiple schedules
- `POST /api/schedules/bulk/delete` — Delete multiple schedules

### Executions
- `GET /api/executions` — List executions
- `GET /api/executions/:id` — Get execution details
- `GET /api/executions/:id/live-metrics` — Get live metrics
- `GET /api/executions/:id/filtered-metrics` — Get metrics by time range
- `GET /api/executions/:id/system-metrics` — Get system metrics
- `GET /api/executions/:id/checkpoint` — Get execution checkpoint
- `POST /api/executions/:id/abort` — Abort a running test
- `POST /api/executions/:id/cancel` — Cancel queued execution
- `POST /api/executions/:id/rerun` — Re-run execution
- `DELETE /api/executions/:id` — Delete execution
- `PATCH /api/executions/:id/labels` — Update execution labels
- `PATCH /api/executions/:id/pin` — Pin/unpin execution
- `GET /api/executions/:id/anomaly-detection` — Get anomaly detection results
- `POST /api/executions/:id/generate-report` — Generate HTML report
- `POST /api/executions/:id/regenerate-report` — Regenerate report
- `POST /api/executions/:id/report-comments` — Add report comments
- `GET/POST /api/executions/:id/comments` — Get/create execution comments
- `DELETE /api/comments/:id` — Delete comment
- `GET/POST /api/executions/:id/sla-rules` — Get/create execution SLA rules
- `POST /api/executions/:id/sla-rules/bulk` — Create multiple SLA rules
- `DELETE /api/execution-sla-rules/:id` — Delete execution SLA rule
- `PATCH /api/execution-sla-rules/:id/toggle` — Toggle SLA rule
- `GET /api/executions/compare` — Compare two executions

### JMeter
- `POST /api/jmeter/start/:scriptId` — Start test (returns immediately)
- `GET /api/jmeter/status/:executionId` — Get current status
- `GET /api/jmeter/results/:executionId` — Get final metrics
- `GET /api/jmeter/queue` — Get queue status

### SLA & Baselines
- `GET/POST /api/scripts/:scriptId/sla-rules` — List/create script SLA rules
- `PUT/DELETE /api/sla-rules/:id` — Update/delete SLA rules
- `GET/POST/DELETE /api/scripts/:scriptId/baseline` — Manage baseline
- `GET /api/scripts/:scriptId/baseline/history` — Baseline history
- `GET/POST/DELETE /api/baselines/:scriptId` — Alternate baseline endpoints
- `GET/POST /api/scripts/:scriptId/regression-thresholds` — Manage regression thresholds
- `DELETE /api/scripts/:scriptId/regression-thresholds/:id` — Delete threshold

### Tracker
- `GET /api/test-tracker` — Query tracker records with filters
- `GET /api/test-tracker/stats` — Tracker statistics
- `GET /api/test-tracker/export` — Export as CSV
- `PATCH /api/test-tracker/:id/comment` — Add comment
- `PATCH /api/test-tracker/reorder` — Reorder records
- `DELETE /api/test-tracker/:id` — Delete record

### Trends
- `GET /api/trends` — Get trend data
- `GET /api/trends/aggregated` — Get aggregated trends

### Comparison
- `GET /api/executions/compare` — Compare two executions side-by-side

### Completion Reports
- `GET/POST /api/completion-reports` — List/create reports
- `GET/PATCH/DELETE /api/completion-reports/:id` — Get/update/delete report
- `POST /api/completion-reports/:id/refresh-snapshot` — Refresh data snapshot
- `GET /api/completion-reports/:id/docx` — Download as DOCX
- `GET /api/completion-reports/:id/preview` — Preview as HTML
- `GET /api/completion-reports/:id/approvals` — Get approval workflow
- `POST /api/completion-reports/:id/request-review` — Request review
- `POST /api/completion-reports/:id/approvals/:approvalId` — Submit approval
- `DELETE /api/completion-reports/:id/approvals` — Cancel review

### Report Delivery
- `GET/POST /api/report-delivery-schedules` — List/create delivery schedules
- `PATCH/DELETE /api/report-delivery-schedules/:id` — Update/delete schedule

### Dump Analysis
- `GET /api/dumps` — List dump files
- `GET /api/dumps/:id` — Get dump file details
- `POST /api/dumps/upload` — Upload dump file
- `DELETE /api/dumps/:id` — Delete dump file
- `GET /api/dumps/:id/analysis` — Get analysis results
- `POST /api/dumps/:id/reanalyze` — Re-analyze dump file
- `POST /api/dumps/:id/gc-log` — Upload and analyze GC log
- `GET/POST /api/dumps/:id/annotations` — Get/add annotations
- `DELETE /api/dumps/:dumpId/annotations/:id` — Delete annotation
- `GET /api/dumps/:id/bookmarks` — Get bookmarks
- `POST /api/dumps/:id/bookmarks/toggle` — Toggle bookmark
- `GET/POST /api/dump-comparisons` — List/create comparisons
- `GET/DELETE /api/dump-comparisons/:id` — Get/delete comparison

### CI/CD
- `GET/POST /api/ci/tokens` — List/create API tokens
- `POST /api/ingest/samples` — Ingest JTL samples
- `POST /api/ingest/heartbeat` — Send heartbeat
- `POST /api/ingest/complete` — Complete execution
- `POST /api/ingest/metrics` — Post system metrics

### Notifications
- `GET /api/notifications` — List notifications
- `GET /api/notifications/unread-count` — Get unread count
- `POST /api/notifications/mark-all-read` — Mark all as read
- `POST /api/notifications/:id/read` — Mark as read
- `DELETE /api/notifications` — Clear all
- `DELETE /api/notifications/:id` — Delete notification
- `GET/PUT /api/notification-preferences` — Get/update preferences

### Webhooks
- `GET/POST /api/webhooks` — List/create webhooks
- `GET /api/webhook-events` — Get available events
- `GET/PATCH/DELETE /api/webhooks/:id` — Get/update/delete webhook
- `POST /api/webhooks/:id/test` — Test webhook
- `GET /api/webhooks/:id/deliveries` — Get delivery history

### Administration
- `GET /api/admin/users` — List all users
- `GET /api/admin/pending-users` — List pending users
- `POST /api/admin/users/:id/approve` — Approve user
- `DELETE /api/admin/users/:id` — Delete user
- `PATCH /api/admin/users/:id/role` — Update user role
- `GET/POST /api/email-settings` — Get/configure email settings
- `POST /api/email-settings/test-connection` — Test email connection
- `POST /api/email-settings/send-test` — Send test email
- `GET /api/email-logs` — Get email delivery logs
- `GET/POST /api/admin/ingest-tokens` — List/create ingest tokens
- `DELETE /api/admin/ingest-tokens/:id` — Delete ingest token
- `GET /api/admin/download-backend-listener` — Download JMeter listener plugin
- `POST /api/admin/remote-execution` — Configure remote execution
- `GET /api/audit-logs` — Get audit logs
- `GET /api/audit-logs/actions` — Get available actions
- `GET /api/audit-logs/resource-types` — Get resource types
- `DELETE /api/audit-logs` — Delete specific logs
- `DELETE /api/audit-logs/all` — Delete all logs

### Organization
- `GET/POST /api/folders` — List/create folders
- `PATCH/DELETE /api/folders/:id` — Update/delete folder
- `GET/POST /api/projects` — List/create projects
- `PUT/DELETE /api/projects/:id` — Update/delete project
- `GET/POST /api/test-types` — List/create test types
- `PUT/DELETE /api/test-types/:id` — Update/delete test type
- `GET/POST /api/environments` — List/create environments
- `DELETE /api/environments/:id` — Delete environment
- `GET/POST /api/tags` — List/create tags
- `DELETE /api/tags/:id` — Delete tag
- `GET/POST/DELETE /api/scripts/:id/tags/:tagId` — Manage script tags
- `GET/POST /api/favorites` — Get/add favorites
- `DELETE /api/favorites/:scriptId` — Remove favorite
- `GET/POST /api/templates` — List/create templates
- `GET/DELETE /api/templates/:id` — Get/delete template
- `GET/POST /api/saved-views` — List/create saved views
- `DELETE /api/saved-views/:id` — Delete saved view
- `PATCH /api/saved-views/:id/default` — Set as default view

### Data Retention
- `GET /api/settings/retention` — Get retention settings
- `PUT /api/settings/retention/:key` — Update retention setting
- `GET /api/retention/overview` — Get retention overview
- `POST /api/retention/:category/preview` — Preview cleanup
- `POST /api/retention/:category/cleanup` — Run cleanup
- `GET /api/retention/history` — Get cleanup history

### Dashboard
- `GET /api/dashboard/stats` — Get dashboard statistics
- `GET /api/public/stats` — Get public stats (no auth)

---

## Migrations

### Timezone Migration

All timestamp columns use `timestamp with time zone` (timestamptz):

```bash
npm run migrate:timezone
```

### Script ID Nullable Migration

Makes script_id nullable on executions for orphaned records:

```bash
npm run migrate:script-nullable
```

### Manual SQL Migration

```bash
psql $DATABASE_URL -f migrations/add_timezone_to_timestamps.sql
```

All migrations are idempotent (safe to run multiple times) and preserve existing data.

---

## Troubleshooting

### "npm command not found"
Restart your terminal after installing Node.js. On Windows, ensure "Add to PATH" was selected.

### "psql: command not found"
- **Windows**: Add `C:\Program Files\PostgreSQL\15\bin` to PATH
- **macOS**: Run `brew link postgresql@15`

### "jmeter: command not found"
Verify JMETER_HOME is set and JMeter's bin directory is in PATH.

### "java: command not found"
Install Java JDK 11+ and set JAVA_HOME environment variable.

### Database connection refused
1. Ensure PostgreSQL is running
2. Verify DATABASE_URL is correct
3. Check the database exists: `psql -U postgres -l`

### Permission denied on database
```sql
GRANT ALL PRIVILEGES ON DATABASE perfhub TO perfhub;
GRANT ALL ON SCHEMA public TO perfhub;
```

### Python "ModuleNotFoundError"
```bash
pip3 install numpy scipy openpyxl pyyaml
```

### Port 5000 already in use
```bash
PORT=3000 npm run dev
```

### Schema push fails
```bash
npx drizzle-kit push --force
```

### JMeter "Java heap space" error
Increase JMeter memory in `jmeter/bin/jmeter` or `jmeter.bat`:
```bash
HEAP="-Xms1g -Xmx4g"
```

### "drizzle-kit: command not found"
```bash
rm -rf node_modules && npm install
```

### Docker: Reset everything
```bash
docker-compose down -v --rmi all
docker-compose up -d --build
```
