# PerfHub - Performance Engineering Platform

## Overview

PerfHub is a full-stack web application for performance engineering teams. It provides capabilities for managing and executing Apache JMeter tests, with comprehensive final metrics reporting and SLA tracking.

The platform follows a monorepo structure with a React frontend, Express backend, PostgreSQL database via Drizzle ORM, and Python scripts for JTL parsing and report generation.

# AI Response Rules

Output policy:

* Do not explain reasoning.
* Do not describe actions.
* Output only final results or code.
* Keep responses extremely short.
* When fixing code, return only the corrected code.
* When modifying files, list changed files and updated sections only.
* Avoid summaries, analysis, or commentary.

Default behavior: minimal output.


## Recent Changes

- **Sign-Off Report Word Doc Overhaul** (Mar 2026): Full rewrite of `completion-report-docx.ts` (~700 lines). Added: TypeScript interfaces for all data types (ReportData, ExecutionSection, TransactionDetail, SlaData, ComparisonData, ApprovalEntry — all nullable-safe). Table of Contents via docx v9 `TableOfContents` with bookmark-linked headings. Page X of Y in footer via `PageNumber.CURRENT`/`PageNumber.TOTAL_PAGES`. Executive dashboard summary table with verdict banner + key metrics. Health score with labels (Excellent/Good/Fair/Degraded/Critical). `chartPlaceholder()` fallback for chart render errors. Aspect-ratio-preserving image sizing via `image-size` package. `features: { updateFields: true }` for Word TOC auto-refresh. Concurrency-safe bookmark counter (function-local closure). Files: `server/completion-report-docx.ts`, `server/completion-report-routes.ts`. Dependency: `image-size`.
- **Test Data Generator UI Overhaul** (Mar 2026): Complete rewrite of the Test Data Generator page with 16+ improvements. Compact horizontal column rows (name | type | actions on one line). Searchable/filterable type selector with 67+ types. 6 quick templates (User Profile, E-commerce Order, API Log, Employee Directory, Financial Transaction, IoT Sensor Data). Column duplicate and reorder (up/down). 4 export formats: CSV, JSON, SQL INSERT, TSV with tab-style picker. Save/load configurations via localStorage (up to 20 configs). Per-column null percentage slider (0-100%). Custom reproducible seed via safe injectable PRNG (no global Math.random mutation). Bulk column add via schema paste (col:type per line). Click-to-copy cell values in preview. Pill-style row count presets (10/100/1K/10K/100K). Intelligent Features moved to info popover. Async chunked generation with progress bar and cancellable export for large datasets (yields to event loop every 500 rows). **Formula Builder**: Consolidated `template_expr`/`custom_expression` into single `custom_formula` type with intelligent UI — `FormulaEditor` sub-component with live preview (real-time `tryEvaluateFormula` validation with green/red feedback), clickable token insertion at cursor position (60+ tokens organized in 9 groups: Identity, Location, Business, Technical, Date & Time, Finance, Generators, Modifiers, Utility), searchable/filterable token reference panel, 10 preset formulas (Custom Email, Transaction ID, API Endpoint, Log Entry, Server Tag, Full Record, File Path, Custom Username, Formatted Name, DB Connection), `TEMPLATE_TOKEN_REGISTRY` architecture replacing if-chain with O(1) lookup. Additional custom types: Regex Pattern, Value List (with random/rotate toggle), Composite ID (prefix + N digits), Constant, Date Range, Lorem Words. Backward-compatible aliases for `template_expr`/`custom_expression` in the engine. Files: `client/src/pages/test-data-generator/index.tsx` (FormulaEditor, FormulaLivePreview components), `client/src/pages/test-data-generator/data-engine.ts` (TEMPLATE_TOKEN_REGISTRY, FORMULA_TOKEN_GROUPS, FORMULA_PRESETS, tryEvaluateFormula exports), `client/src/pages/test-data-generator/templates.ts`.
- **FixedHistogram High-Throughput Architecture** (Mar 2026): Replaced unbounded `StreamingPercentile` (stored every raw value in `number[]`, caused OOM at high throughput) with `FixedHistogram` — 60,001 × 1ms-wide Int32Array counters (0–60,000ms). Memory: ~240 KB per histogram (fixed), ~24 MB for 100 transactions vs 35 GB OOM before. Zero precision loss at millisecond granularity. Nearest-Rank percentile calculation matching JMeter. Sparse serialization for checkpoints and DB storage (only non-zero bins: `[idx, count, idx, count, ...]`). Checkpoint version bumped to v4 with backward-compat import for v2/v3 (including legacy centroid `[[mean,count],...]` arrays). Bucket persistence and file fallback (bucket-merger) both use histogram merging. Python JTL parser fully migrated to histogram counters (TDigest dependency removed). Execution deletion now cleans up metric bucket rows, SLA rules, and artifact directories. Retention service also removes artifact directories during cleanup. Files: `server/live-metrics/fixed-histogram.ts`, `server/live-metrics/aggregator.ts`, `server/bucket-persistence.ts`, `server/bucket-merger.ts`, `server/storage.ts`, `server/retention-service.ts`, `scripts/jtl_parser_full.py`. Deleted: `server/live-metrics/tdigest.ts`.
- **Pre-Aggregated Bucket Metrics Storage** (Mar 2026): Added `execution_metric_buckets` PostgreSQL table to replace filesystem-based `buckets.json` reads for filtered-metrics queries. Post-test processing now persists bucket data (global + per-transaction rows with histogram counters) to DB via transactional bulk inserts. The `/api/executions/:id/filtered-metrics` endpoint queries DB first with automatic file fallback. Retention service cleans up bucket rows when executions are deleted. New file: `server/bucket-persistence.ts` (persistence, querying, histogram-based percentile merging). Schema: `shared/schema.ts` (executionMetricBuckets table). Zero frontend changes.
- **Crash Prevention Hardening** (Feb 2026): Replaced all `readFileSync` calls on potentially large files with async/streaming reads (`jmeter-worker.ts`, `execution-routes.ts`, `dump-routes.ts`, `bucket-merger.ts`). Added 50 KB stderr bounds on JTL parser subprocesses to prevent unbounded string growth. Added 200 MB size guard on metrics.json before reading. Reduced dump file upload limit from 500 MB to 100 MB. Drained stdout on child processes to prevent backpressure stalls.
- **Console Logs System** (Feb 2026): Added centralized logging with local file persistence (`server/logger.ts`). All server modules now use structured logging with levels (debug/info/warn/error/fatal), source tags, and optional metadata. Logs are written to `logs/perfhub-YYYY-MM-DD.log` files with automatic 5 MB rotation and 10-file retention. In-memory buffer (2000 entries) powers real-time API. Admin-only Console Logs page at `/platform/console-logs` with live streaming, level/source filtering, full-text search, expandable metadata, and log file downloads.
- **Distributed Load Calculator** (Feb 2026): Added a third tab "Distributed Load" to the Workload Model Calculator. Features hardware presets (Small/Medium/Large/XL/Custom), script complexity multipliers, distributed overhead slider, bandwidth estimation, calibration from past executions, architecture diagram, and JMeter distributed setup guidance with copy-to-clipboard. Located in `client/src/pages/workload-model/distributed-load-calculator.tsx`.
- **Sign-Off Report Redesign** (Feb 2026): Replaced checkbox-based multi-execution selection with dropdown menus for single current and baseline test selection. Added user-choosable custom sections with enable/disable toggles and upload buttons. Enhanced DOCX generator with per-transaction bar charts (avg response time and throughput). Added document preview tab on detail page with HTML preview via iframe. Custom sections are stored in report snapshot and rendered in both preview HTML and Word document.
- **Test Dependency Management** (Feb 2026): Added ability to upload CSV, JSON, XML, and other data files that JMeter scripts reference. Dependencies are stored per script and automatically copied to run folders so relative paths work.
- **JAR Dependencies** (Feb 2026): Added ability to upload JAR files (plugins, JDBC drivers, custom samplers) per script. JARs are added to JMeter's classpath via `user.classpath` when running tests.
- **Script Converter & Analyzer** (Feb 2026): Supports both HAR-to-JMX conversion and direct JMX file analysis. HAR mode: rule-based engine that converts browser HAR recordings into production-ready JMeter scripts with auto-correlation, parameterization, static resource filtering, transaction grouping, and quality scoring (0-100). JMX mode: analyzes existing JMX files for quality scoring, extracting correlations (Regex/JSON/XPath/Boundary/CSS extractors), CSV parameterizations, and best-practice issues. Both modes show same results view: quality score card, stats, four tabs (Correlations, Parameterizations, Issues, JMX Preview), save-as-script dialog, and download buttons. Files: `server/har-converter/` (har-parser, request-filter, correlation-detector, parameterization-detector, jmx-builder, quality-scorer, jmx-analyzer, jmx-validator), `server/har-converter-routes.ts`, `client/src/pages/scripts/har-converter.tsx`. DB table: `script_generations` (inputType: 'har' or 'jmx'). Route: `/har-converter`, sidebar under Test Management as "Script Converter". Generated JMX/CSV content stored in DB (generatedJmxContent/sampleCsvContent columns) — no disk files for converter output. Legacy file path columns (generatedJmxPath/sampleCsvPath) kept for backward compatibility with fallback reads. Domain picker: client-side HAR scanning extracts all domains with counts, auto-classifies third-party domains, user selects which to include/exclude before conversion. JMX validator runs post-generation (validates XML structure, hashTree pairing, element attributes, property types, objProp format) and on uploaded JMX files (issues surfaced in analysis). Framework-aware dynamic field detection covers 15+ platforms: ASP.NET (ViewState, EventValidation, etc.), Django (csrfmiddlewaretoken), Rails (authenticity_token), Laravel (_token, XSRF-TOKEN), Spring (_csrf), WordPress (_wpnonce), Drupal (form_build_id, form_token), Magento (form_key), PeopleSoft (ICSID, ICStateNum), Siebel (SWEC, SWERowId), ServiceNow (sysparm_ck), JSF (javax.faces.ViewState), Oracle EBS (ICX_TICKET), Salesforce (VisualForce ViewState), plus session cookies (JSESSIONID, PHPSESSID, ASP.NET_SessionId, connect.sid, etc.). Detection runs on all JMX uploads and HAR files (request params, cookies, headers). Issues tab shows framework-specific warnings with detected framework name.
- **Test Execution Tracker** (Feb 2026): Added comprehensive tracker dashboard with denormalized `test_tracker` table for efficient historical reporting. Features project/test type organization, environment filtering, date range presets, pagination, and CSV export.
- **Comments/Notes** (Feb 2026): Added comments/notes section on execution detail page for team collaboration.
- **SLA Monitoring & Baseline Management** (Feb 2026): Added per-transaction SLA rules, baseline execution management, automatic regression detection with severity levels, and comprehensive UI on script detail and execution detail pages.
- **JMeter-Only Execution** (Feb 2026): Refactored to support only Apache JMeter tests. All other load testing tools (K6, LoadRunner, etc.) have been removed.
- **Background Worker Execution**: Tests run asynchronously in a background worker queue. API calls never block.
- **Final Metrics Only**: No live streaming metrics. Results are parsed once after test completion using the Python JTL parser.
- **Live Dashboard Removed**: Real-time metrics dashboard removed in favor of final results view.

## Test Execution Tracker

### Organization
- **Projects**: Organize scripts by project for easier management
- **Test Types**: Categorize tests (Load, Stress, Smoke, Endurance, etc.)
- **Volume Tracking**: Record test volume (users, TPS, etc.) for each scheduled run

### Tracker Dashboard (`/tracker`)
- Denormalized `test_tracker` table for fast querying without joins
- Auto-populated after each test execution completes
- Comprehensive filters: project, test type, environment, status, date range
- Date presets: This Week, This Month, Last Month, This Year
- CSV export with all filters applied
- Pagination for large datasets

### API Endpoints
- `GET /api/tracker` - Query tracker records with filters and pagination
- `GET /api/tracker/export` - Export filtered data as CSV
- `GET/POST /api/projects` - List/create projects
- `GET/POST /api/test-types` - List/create test types

## Test Dependency Management

JMeter scripts often reference external data files (CSV, JSON, XML, etc.) for test data. This feature allows uploading these files alongside your JMX script.

### How It Works
- **Storage**: Dependencies stored in `uploads/dependencies/{scriptId}/`
- **Execution**: Before each test run, the JMX + all dependency files are copied to `runs/{runId}/`
- **Relative Paths**: JMeter executes from the run folder, so relative paths in your JMX (e.g., `users.csv`) resolve correctly

### Supported File Types
`.csv`, `.json`, `.xml`, `.txt`, `.properties`, `.dat`, `.tsv` (max 10MB each)

### Schema
- `dependencyFiles` JSONB field on scripts table: `[{originalName, storedPath, size, uploadedAt}]`

### API Endpoints
- `POST /api/scripts/:scriptId/dependencies` - Upload dependency files
- `DELETE /api/scripts/:scriptId/dependencies/:fileName` - Delete a dependency file

## SLA Monitoring & Baseline Features

### SLA Rules
- **Per-Script Rules**: Define SLA thresholds per script with global or per-transaction scope
- **Metrics Supported**: avg, p90, p95, p99, max response time, error rate, throughput
- **Comparators**: lt (less than), lte (less or equal), gt (greater than), gte (greater or equal)
- **Automatic Evaluation**: After each test run, SLA rules are checked and violations are recorded
- **Notifications**: Users receive notifications when SLA violations are detected

### Baseline Management
- **Set Baseline**: Select any completed execution as the baseline for a script
- **Automatic Comparison**: New test runs are automatically compared to the baseline
- **Regression Detection**: Detects performance regressions with severity levels (minor: 10-25%, moderate: 25-50%, severe: >50%)
- **Key Metrics**: Tracks avgResponseTime, throughput, p90, p95, errorRate deviations

### API Endpoints
- `GET/POST /api/scripts/:scriptId/sla-rules` - List/create SLA rules
- `PATCH/DELETE /api/sla-rules/:id` - Update/delete SLA rules
- `GET/POST/DELETE /api/scripts/:scriptId/baseline` - Manage baseline execution
- `GET /api/comparison` - Compare two executions side-by-side
- `GET /api/trends` - Get performance trends over time

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript, built using Vite
- **State Management**: TanStack React Query for server state
- **Real-time Updates**: WebSocket client for execution status updates (status only, no live metrics)
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **Routing**: Wouter (lightweight React router)
- **Charts**: Recharts for final results visualization
- **Code Location**: `client/src/` directory

### Backend Architecture
- **Runtime**: Node.js 20 with Express
- **Language**: TypeScript compiled with tsx/esbuild
- **API Design**: REST endpoints in `server/routes.ts` with Zod validation
- **Authentication**: Session-based auth with PostgreSQL session store
- **WebSocket**: Status updates only on `/ws` path
- **JMeter Worker**: Background worker in `server/jmeter-worker.ts` handles async execution
- **File Uploads**: Only .jmx files accepted

### Database Layer
- **Database**: PostgreSQL (required)
- **ORM**: Drizzle ORM with drizzle-kit for migrations
- **Schema Location**: `shared/schema.ts`
- **Key Tables**: users, scripts, folders, test_schedules, test_executions, notifications
- **Connection**: Pool-based connection via `server/db.ts`

### JMeter Execution Flow (STRICT)
**Critical: Metrics are calculated ONLY ONCE from the final results.jtl file**

1. Upload JMX script via `/api/scripts/:id/upload`
2. Start test via `/api/jmeter/start/:scriptId` or `/api/schedules/:id/queue` (returns immediately)
3. Test queued in background worker (`server/jmeter-worker.ts`)
4. JMeter runs via CLI - worker WAITS for process to fully exit
5. Status updates broadcast via WebSocket (queued → running → parsing → completed/failed)
6. ONLY AFTER JMeter exits: JTL parsed ONCE using `scripts/jtl_parser_full.py`
7. Parser output mapped to DB format (field name conversion only, no recalculation)
8. Final metrics stored in `test_executions.resultSummary`
9. Results available via `/api/jmeter/results/:executionId`

**Strict Rules:**
- Python parser is the ONLY source of metrics computation
- NO live metrics, streaming calculations, or partial file reads
- Frontend NEVER reads JTL files or computes metrics - only displays DB data
- Error rates stored as decimals (0.0-1.0), frontend multiplies by 100 for display

### JMeter API Endpoints
- `POST /api/jmeter/start/:scriptId` - Start test for a script (returns immediately)
- `GET /api/jmeter/status/:executionId` - Get current status
- `GET /api/jmeter/results/:executionId` - Get final metrics (after completion)
- `GET /api/jmeter/queue` - Get queue status

### Results Storage
- Each run creates `results/<runId>/` folder containing:
  - `results.jtl` - Raw JMeter output
  - `jmeter.log` - JMeter logs
  - `metrics.json` - Parsed metrics

## External Dependencies

### Required Services
- **PostgreSQL 15+**: Primary database via `DATABASE_URL`
- **Python 3.11+**: Required for JTL parsing
- **Apache JMeter**: Required on server (set `JMETER_HOME` if not in PATH)

### Optional Services
- **Redis**: Caching layer via `REDIS_URL` (disabled if not set)

### Configuration File (config.json)

You can configure the application using a `config.json` file in the project root. This is recommended for local development:

```json
{
  "database": {
    "url": "postgresql://username:password@localhost:5432/perfhub"
  },
  "jmeter": {
    "home": "/path/to/apache-jmeter-5.6.3",
    "executable": ""
  },
  "python": {
    "command": "python3"
  }
}
```

**Database Configuration** (checked in this order):
1. `config.json` → `database.url`
2. `DATABASE_URL` environment variable

**JMeter Configuration** (checked in this order):
1. `config.json` → `jmeter.executable` (full path to jmeter binary)
2. `config.json` → `jmeter.home` (JMeter installation folder)
3. `JMETER_HOME` environment variable
4. System PATH

### Key Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (required)
- `SESSION_SECRET`: Secret for session encryption
- `JMETER_HOME`: Path to JMeter installation (optional if using config.json or PATH)
- `PYTHON_CMD`: Python command (default: python3)
- `REDIS_URL`: Redis connection for caching (optional)

### Docker Support
- `docker-compose.yml` provides PostgreSQL and application containers
- Application container includes Node.js, Python, JMeter, and all dependencies
- Default credentials: username `perfhub`, password `Perfx`
