-- Migration: Make scriptId nullable in test_schedules
-- This allows schedules to exist after their associated script is deleted
-- Preserves execution history when scripts are removed

-- First, update any existing schedules that reference deleted scripts
-- Set their scriptId to NULL and cancel pending ones
DO $$ 
BEGIN
  -- Find schedules with non-existent scripts and nullify them
  UPDATE test_schedules 
  SET script_id = NULL,
      status = CASE WHEN status IN ('pending', 'queued') THEN 'cancelled' ELSE status END,
      recurrence = 'none'
  WHERE script_id NOT IN (SELECT id FROM scripts);
END $$;

-- Now make the column nullable
ALTER TABLE test_schedules 
  ALTER COLUMN script_id DROP NOT NULL;

-- Add a comment to document this behavior
COMMENT ON COLUMN test_schedules.script_id IS 'Reference to script. NULL if script was deleted. Schedules are preserved for execution history.';
