CREATE TABLE "api_tokens" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"token_hash" text NOT NULL,
	"token_prefix" text NOT NULL,
	"scopes" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"created_by" integer NOT NULL,
	"last_used_at" timestamp with time zone,
	"expires_at" timestamp with time zone,
	"revoked_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "audit_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"action" text NOT NULL,
	"resource_type" text NOT NULL,
	"resource_id" text,
	"details" jsonb,
	"timestamp" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "auto_abort_rules" (
	"id" serial PRIMARY KEY NOT NULL,
	"script_id" integer NOT NULL,
	"metric" text NOT NULL,
	"comparator" text NOT NULL,
	"threshold" real NOT NULL,
	"sustained_seconds" integer DEFAULT 30 NOT NULL,
	"is_enabled" boolean DEFAULT true NOT NULL,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "baseline_executions" (
	"id" serial PRIMARY KEY NOT NULL,
	"script_id" integer NOT NULL,
	"execution_id" integer NOT NULL,
	"set_by" integer NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"name" text,
	"notes" text,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "cleanup_history" (
	"id" serial PRIMARY KEY NOT NULL,
	"category" text NOT NULL,
	"threshold_days" integer NOT NULL,
	"deleted_count" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'completed' NOT NULL,
	"initiated_by" integer NOT NULL,
	"started_at" timestamp with time zone DEFAULT now(),
	"completed_at" timestamp with time zone,
	"notes" text
);
--> statement-breakpoint
CREATE TABLE "comments" (
	"id" serial PRIMARY KEY NOT NULL,
	"execution_id" integer NOT NULL,
	"user_id" integer NOT NULL,
	"content" text NOT NULL,
	"type" text DEFAULT 'comment' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "custom_environments" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "custom_environments_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "data_retention_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"setting_key" text NOT NULL,
	"setting_value" integer NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now(),
	"updated_by" integer,
	CONSTRAINT "data_retention_settings_setting_key_unique" UNIQUE("setting_key")
);
--> statement-breakpoint
CREATE TABLE "dump_analysis" (
	"id" serial PRIMARY KEY NOT NULL,
	"dump_file_id" integer NOT NULL,
	"analysis_type" text NOT NULL,
	"thread_summary" jsonb,
	"threads" jsonb,
	"deadlocks" jsonb,
	"hotspots" jsonb,
	"stack_clusters" jsonb,
	"contention_info" jsonb,
	"detected_issues" jsonb,
	"heap_summary" jsonb,
	"class_histogram" jsonb,
	"leak_suspects" jsonb,
	"dominator_tree" jsonb,
	"reference_chains" jsonb,
	"top_objects" jsonb,
	"gc_metrics" jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "dump_annotations" (
	"id" serial PRIMARY KEY NOT NULL,
	"dump_file_id" integer NOT NULL,
	"thread_name" text,
	"issue_index" integer,
	"note" text NOT NULL,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "dump_bookmarks" (
	"id" serial PRIMARY KEY NOT NULL,
	"dump_file_id" integer NOT NULL,
	"thread_name" text NOT NULL,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "dump_comparisons" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"dump_file_ids" jsonb NOT NULL,
	"comparison_type" text NOT NULL,
	"results" jsonb,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "dump_files" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"file_path" text NOT NULL,
	"file_size" integer NOT NULL,
	"uploaded_by" integer NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"error_message" text,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "email_log" (
	"id" serial PRIMARY KEY NOT NULL,
	"execution_id" integer,
	"event_type" text NOT NULL,
	"recipients" jsonb NOT NULL,
	"subject" text NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"attempts" integer DEFAULT 0 NOT NULL,
	"last_error" text,
	"sent_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "email_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"smtp_host" text DEFAULT 'smtp.office365.com' NOT NULL,
	"smtp_port" integer DEFAULT 587 NOT NULL,
	"sender_email" text NOT NULL,
	"sender_password" text NOT NULL,
	"default_recipients" jsonb DEFAULT '[]'::jsonb,
	"enabled" boolean DEFAULT false NOT NULL,
	"updated_by" integer,
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "execution_auto_abort_rules" (
	"id" serial PRIMARY KEY NOT NULL,
	"execution_id" integer NOT NULL,
	"metric" text NOT NULL,
	"comparator" text NOT NULL,
	"threshold" real NOT NULL,
	"sustained_seconds" integer DEFAULT 30 NOT NULL,
	"is_enabled" boolean DEFAULT true NOT NULL,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "execution_sla_rules" (
	"id" serial PRIMARY KEY NOT NULL,
	"execution_id" integer NOT NULL,
	"transaction_label" text,
	"metric" text NOT NULL,
	"comparator" text NOT NULL,
	"threshold" integer NOT NULL,
	"is_enabled" boolean DEFAULT true NOT NULL,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "execution_workload_targets" (
	"id" serial PRIMARY KEY NOT NULL,
	"execution_id" integer NOT NULL,
	"threads" integer,
	"tph" integer,
	"tps" real,
	"pacing" real,
	"test_type" text,
	"transactions_per_iteration" integer,
	"e2e_response_time" real,
	"think_time" real,
	"per_transaction" jsonb,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "favorites" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"script_id" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "favorites_user_script_unique" UNIQUE("user_id","script_id")
);
--> statement-breakpoint
CREATE TABLE "folders" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"parent_id" integer,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "notification_preferences" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"test_completed" boolean DEFAULT true NOT NULL,
	"test_failed" boolean DEFAULT true NOT NULL,
	"sla_violation" boolean DEFAULT true NOT NULL,
	"regression_detected" boolean DEFAULT true NOT NULL,
	"approval_requested" boolean DEFAULT true NOT NULL,
	"system_alerts" boolean DEFAULT true NOT NULL,
	"email_enabled" boolean DEFAULT false NOT NULL,
	"email_digest_frequency" text DEFAULT 'instant' NOT NULL,
	"email_digest_time" text DEFAULT '09:00' NOT NULL,
	"email_digest_day" text DEFAULT 'monday' NOT NULL,
	"quiet_hours_enabled" boolean DEFAULT false NOT NULL,
	"quiet_hours_start" text DEFAULT '22:00' NOT NULL,
	"quiet_hours_end" text DEFAULT '07:00' NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "notification_preferences_user_id_unique" UNIQUE("user_id")
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"title" text NOT NULL,
	"message" text NOT NULL,
	"type" text NOT NULL,
	"read" boolean DEFAULT false NOT NULL,
	"link" text,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "password_reset_tokens" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"token" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"used" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "password_reset_tokens_token_unique" UNIQUE("token")
);
--> statement-breakpoint
CREATE TABLE "projects" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "regression_thresholds" (
	"id" serial PRIMARY KEY NOT NULL,
	"script_id" integer NOT NULL,
	"metric" text NOT NULL,
	"warning_percent" integer DEFAULT 10 NOT NULL,
	"critical_percent" integer DEFAULT 25 NOT NULL,
	"is_enabled" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "release_tags" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"color" text,
	"created_at" timestamp with time zone DEFAULT now(),
	"created_by" integer,
	CONSTRAINT "release_tags_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "remote_ingest_tokens" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"token_hash" text NOT NULL,
	"token_prefix" text NOT NULL,
	"created_by" integer,
	"created_at" timestamp with time zone DEFAULT now(),
	"revoked_at" timestamp with time zone,
	"last_used_at" timestamp with time zone,
	"allowed_execution_ids" jsonb,
	"last_heartbeat_at" timestamp with time zone,
	"active_execution_count" integer DEFAULT 0,
	"completed_execution_count" integer DEFAULT 0,
	"total_samples_ingested" integer DEFAULT 0,
	"last_node_id" text
);
--> statement-breakpoint
CREATE TABLE "report_approvals" (
	"id" serial PRIMARY KEY NOT NULL,
	"report_id" integer NOT NULL,
	"reviewer_user_id" integer NOT NULL,
	"step_order" integer DEFAULT 1 NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"comment" text,
	"acted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "report_delivery_schedules" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"recipients" jsonb NOT NULL,
	"frequency" text DEFAULT 'weekly' NOT NULL,
	"day_of_week" integer,
	"day_of_month" integer,
	"time_of_day" text DEFAULT '09:00' NOT NULL,
	"timezone" text DEFAULT 'UTC' NOT NULL,
	"filters" jsonb,
	"include_attachments" boolean DEFAULT false NOT NULL,
	"last_sent_at" timestamp with time zone,
	"next_run_at" timestamp with time zone,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "report_templates" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"sections" jsonb NOT NULL,
	"is_default" boolean DEFAULT false NOT NULL,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "saved_filter_views" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"page" text NOT NULL,
	"filters" jsonb NOT NULL,
	"is_default" boolean DEFAULT false,
	"user_id" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "script_generations" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"status" text DEFAULT 'processing' NOT NULL,
	"input_type" text NOT NULL,
	"input_file_name" text,
	"input_file_size" integer,
	"generated_jmx_path" text,
	"sample_csv_path" text,
	"generated_jmx_content" text,
	"sample_csv_content" text,
	"correlations" jsonb,
	"parameterizations" jsonb,
	"issues" jsonb,
	"quality_score" integer,
	"readiness_level" text,
	"stats" jsonb,
	"error_message" text,
	"script_id" integer,
	"user_id" integer,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "script_tags" (
	"id" serial PRIMARY KEY NOT NULL,
	"script_id" integer NOT NULL,
	"tag_id" integer NOT NULL,
	CONSTRAINT "script_tags_unique" UNIQUE("script_id","tag_id")
);
--> statement-breakpoint
CREATE TABLE "scripts" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"tool_type" text NOT NULL,
	"file_path" text,
	"dependency_files" jsonb,
	"jar_files" jsonb,
	"workload_targets" jsonb,
	"uploaded_by" integer,
	"folder_id" integer,
	"project_id" integer,
	"protocol" text DEFAULT 'http',
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "sla_rules" (
	"id" serial PRIMARY KEY NOT NULL,
	"script_id" integer NOT NULL,
	"transaction_label" text,
	"metric" text NOT NULL,
	"comparator" text NOT NULL,
	"threshold" integer NOT NULL,
	"is_enabled" boolean DEFAULT true NOT NULL,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "tags" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"color" text DEFAULT '#3b82f6' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "tags_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "test_checkpoints" (
	"id" serial PRIMARY KEY NOT NULL,
	"execution_id" integer NOT NULL,
	"last_processed_offset" integer DEFAULT 0 NOT NULL,
	"metrics_count" integer DEFAULT 0 NOT NULL,
	"last_metric_timestamp" timestamp with time zone,
	"state" text NOT NULL,
	"progress" integer DEFAULT 0 NOT NULL,
	"recovery_data" jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "test_checkpoints_execution_id_unique" UNIQUE("execution_id")
);
--> statement-breakpoint
CREATE TABLE "test_completion_reports" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"project_id" integer,
	"project_name" text,
	"feature_name" text,
	"objective" text,
	"scope" text,
	"environment_notes" text,
	"recommendations" text,
	"overall_verdict" text,
	"verdict_notes" text,
	"execution_ids" jsonb NOT NULL,
	"compare_execution_ids" jsonb,
	"report_snapshot" jsonb,
	"status" text DEFAULT 'draft' NOT NULL,
	"review_status" text DEFAULT 'draft',
	"review_requested_at" timestamp with time zone,
	"final_approved_at" timestamp with time zone,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "test_executions" (
	"id" serial PRIMARY KEY NOT NULL,
	"execution_id" text NOT NULL,
	"schedule_id" integer,
	"test_name" text,
	"start_time" timestamp with time zone,
	"end_time" timestamp with time zone,
	"status" text NOT NULL,
	"result_summary" jsonb,
	"artifacts_path" text,
	"report_html_path" text,
	"report_comments" text,
	"sla_violations" jsonb,
	"baseline_deviation" jsonb,
	"live_metrics" jsonb,
	"environment" text,
	"remote_agent_token_id" integer,
	"script_id" integer,
	"execution_labels" jsonb,
	"is_pinned" boolean DEFAULT false,
	"pinned_at" timestamp with time zone,
	"pinned_by" integer,
	"release_tag" text,
	CONSTRAINT "test_executions_execution_id_unique" UNIQUE("execution_id")
);
--> statement-breakpoint
CREATE TABLE "test_schedules" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"script_id" integer,
	"scheduled_time" timestamp with time zone NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"recurrence" text,
	"configuration" jsonb,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "test_templates" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"configuration" jsonb,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "test_tracker" (
	"id" serial PRIMARY KEY NOT NULL,
	"run_id" text NOT NULL,
	"execution_timestamp" timestamp with time zone NOT NULL,
	"project_id" integer,
	"project_name" text,
	"feature_name" text NOT NULL,
	"test_type_id" integer,
	"test_type_name" text,
	"volume" text,
	"environment" text,
	"comments" text,
	"status" text NOT NULL,
	"duration_seconds" integer,
	"avg_response_time" integer,
	"p95" integer,
	"p99" integer,
	"throughput" integer,
	"error_rate" integer,
	"execution_id" integer,
	"sort_order" integer,
	"release_tag" text,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "test_types" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"email" text,
	"password" text NOT NULL,
	"role" text DEFAULT 'engineer' NOT NULL,
	"is_approved" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
--> statement-breakpoint
CREATE TABLE "webhook_deliveries" (
	"id" serial PRIMARY KEY NOT NULL,
	"webhook_id" integer NOT NULL,
	"event" text NOT NULL,
	"payload" jsonb,
	"response_status" integer,
	"response_body" text,
	"error" text,
	"attempts" integer DEFAULT 1 NOT NULL,
	"delivered_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "webhooks" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"url" text NOT NULL,
	"secret" text,
	"type" text DEFAULT 'generic' NOT NULL,
	"events" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"headers" jsonb,
	"created_by" integer NOT NULL,
	"last_delivery_at" timestamp with time zone,
	"last_delivery_status" text,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "api_tokens" ADD CONSTRAINT "api_tokens_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "auto_abort_rules" ADD CONSTRAINT "auto_abort_rules_script_id_scripts_id_fk" FOREIGN KEY ("script_id") REFERENCES "public"."scripts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "auto_abort_rules" ADD CONSTRAINT "auto_abort_rules_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "baseline_executions" ADD CONSTRAINT "baseline_executions_script_id_scripts_id_fk" FOREIGN KEY ("script_id") REFERENCES "public"."scripts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "baseline_executions" ADD CONSTRAINT "baseline_executions_execution_id_test_executions_id_fk" FOREIGN KEY ("execution_id") REFERENCES "public"."test_executions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "baseline_executions" ADD CONSTRAINT "baseline_executions_set_by_users_id_fk" FOREIGN KEY ("set_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cleanup_history" ADD CONSTRAINT "cleanup_history_initiated_by_users_id_fk" FOREIGN KEY ("initiated_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "comments" ADD CONSTRAINT "comments_execution_id_test_executions_id_fk" FOREIGN KEY ("execution_id") REFERENCES "public"."test_executions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "comments" ADD CONSTRAINT "comments_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "custom_environments" ADD CONSTRAINT "custom_environments_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "data_retention_settings" ADD CONSTRAINT "data_retention_settings_updated_by_users_id_fk" FOREIGN KEY ("updated_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dump_analysis" ADD CONSTRAINT "dump_analysis_dump_file_id_dump_files_id_fk" FOREIGN KEY ("dump_file_id") REFERENCES "public"."dump_files"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dump_annotations" ADD CONSTRAINT "dump_annotations_dump_file_id_dump_files_id_fk" FOREIGN KEY ("dump_file_id") REFERENCES "public"."dump_files"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dump_annotations" ADD CONSTRAINT "dump_annotations_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dump_bookmarks" ADD CONSTRAINT "dump_bookmarks_dump_file_id_dump_files_id_fk" FOREIGN KEY ("dump_file_id") REFERENCES "public"."dump_files"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dump_bookmarks" ADD CONSTRAINT "dump_bookmarks_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dump_comparisons" ADD CONSTRAINT "dump_comparisons_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dump_files" ADD CONSTRAINT "dump_files_uploaded_by_users_id_fk" FOREIGN KEY ("uploaded_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "email_log" ADD CONSTRAINT "email_log_execution_id_test_executions_id_fk" FOREIGN KEY ("execution_id") REFERENCES "public"."test_executions"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "email_settings" ADD CONSTRAINT "email_settings_updated_by_users_id_fk" FOREIGN KEY ("updated_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "execution_auto_abort_rules" ADD CONSTRAINT "execution_auto_abort_rules_execution_id_test_executions_id_fk" FOREIGN KEY ("execution_id") REFERENCES "public"."test_executions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "execution_auto_abort_rules" ADD CONSTRAINT "execution_auto_abort_rules_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "execution_sla_rules" ADD CONSTRAINT "execution_sla_rules_execution_id_test_executions_id_fk" FOREIGN KEY ("execution_id") REFERENCES "public"."test_executions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "execution_sla_rules" ADD CONSTRAINT "execution_sla_rules_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "execution_workload_targets" ADD CONSTRAINT "execution_workload_targets_execution_id_test_executions_id_fk" FOREIGN KEY ("execution_id") REFERENCES "public"."test_executions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "execution_workload_targets" ADD CONSTRAINT "execution_workload_targets_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "favorites" ADD CONSTRAINT "favorites_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "favorites" ADD CONSTRAINT "favorites_script_id_scripts_id_fk" FOREIGN KEY ("script_id") REFERENCES "public"."scripts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notification_preferences" ADD CONSTRAINT "notification_preferences_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "password_reset_tokens" ADD CONSTRAINT "password_reset_tokens_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "regression_thresholds" ADD CONSTRAINT "regression_thresholds_script_id_scripts_id_fk" FOREIGN KEY ("script_id") REFERENCES "public"."scripts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "release_tags" ADD CONSTRAINT "release_tags_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "remote_ingest_tokens" ADD CONSTRAINT "remote_ingest_tokens_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "report_approvals" ADD CONSTRAINT "report_approvals_report_id_test_completion_reports_id_fk" FOREIGN KEY ("report_id") REFERENCES "public"."test_completion_reports"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "report_approvals" ADD CONSTRAINT "report_approvals_reviewer_user_id_users_id_fk" FOREIGN KEY ("reviewer_user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "report_delivery_schedules" ADD CONSTRAINT "report_delivery_schedules_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "report_templates" ADD CONSTRAINT "report_templates_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "saved_filter_views" ADD CONSTRAINT "saved_filter_views_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "script_generations" ADD CONSTRAINT "script_generations_script_id_scripts_id_fk" FOREIGN KEY ("script_id") REFERENCES "public"."scripts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "script_generations" ADD CONSTRAINT "script_generations_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "script_tags" ADD CONSTRAINT "script_tags_script_id_scripts_id_fk" FOREIGN KEY ("script_id") REFERENCES "public"."scripts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "script_tags" ADD CONSTRAINT "script_tags_tag_id_tags_id_fk" FOREIGN KEY ("tag_id") REFERENCES "public"."tags"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "scripts" ADD CONSTRAINT "scripts_uploaded_by_users_id_fk" FOREIGN KEY ("uploaded_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "scripts" ADD CONSTRAINT "scripts_folder_id_folders_id_fk" FOREIGN KEY ("folder_id") REFERENCES "public"."folders"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "scripts" ADD CONSTRAINT "scripts_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sla_rules" ADD CONSTRAINT "sla_rules_script_id_scripts_id_fk" FOREIGN KEY ("script_id") REFERENCES "public"."scripts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sla_rules" ADD CONSTRAINT "sla_rules_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_checkpoints" ADD CONSTRAINT "test_checkpoints_execution_id_test_executions_id_fk" FOREIGN KEY ("execution_id") REFERENCES "public"."test_executions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_completion_reports" ADD CONSTRAINT "test_completion_reports_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_completion_reports" ADD CONSTRAINT "test_completion_reports_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_executions" ADD CONSTRAINT "test_executions_schedule_id_test_schedules_id_fk" FOREIGN KEY ("schedule_id") REFERENCES "public"."test_schedules"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_executions" ADD CONSTRAINT "test_executions_script_id_scripts_id_fk" FOREIGN KEY ("script_id") REFERENCES "public"."scripts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_executions" ADD CONSTRAINT "test_executions_pinned_by_users_id_fk" FOREIGN KEY ("pinned_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_executions" ADD CONSTRAINT "test_executions_remote_agent_token_id_remote_ingest_tokens_id_fk" FOREIGN KEY ("remote_agent_token_id") REFERENCES "public"."remote_ingest_tokens"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_schedules" ADD CONSTRAINT "test_schedules_script_id_scripts_id_fk" FOREIGN KEY ("script_id") REFERENCES "public"."scripts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_schedules" ADD CONSTRAINT "test_schedules_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_templates" ADD CONSTRAINT "test_templates_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_tracker" ADD CONSTRAINT "test_tracker_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_tracker" ADD CONSTRAINT "test_tracker_test_type_id_test_types_id_fk" FOREIGN KEY ("test_type_id") REFERENCES "public"."test_types"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_tracker" ADD CONSTRAINT "test_tracker_execution_id_test_executions_id_fk" FOREIGN KEY ("execution_id") REFERENCES "public"."test_executions"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "test_types" ADD CONSTRAINT "test_types_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "webhook_deliveries" ADD CONSTRAINT "webhook_deliveries_webhook_id_webhooks_id_fk" FOREIGN KEY ("webhook_id") REFERENCES "public"."webhooks"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "webhooks" ADD CONSTRAINT "webhooks_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "api_tokens_created_by_idx" ON "api_tokens" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "api_tokens_token_prefix_idx" ON "api_tokens" USING btree ("token_prefix");--> statement-breakpoint
CREATE INDEX "audit_logs_user_id_idx" ON "audit_logs" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "audit_logs_resource_type_idx" ON "audit_logs" USING btree ("resource_type");--> statement-breakpoint
CREATE INDEX "audit_logs_timestamp_idx" ON "audit_logs" USING btree ("timestamp");--> statement-breakpoint
CREATE INDEX "audit_logs_action_idx" ON "audit_logs" USING btree ("action");--> statement-breakpoint
CREATE INDEX "audit_logs_user_timestamp_idx" ON "audit_logs" USING btree ("user_id","timestamp");--> statement-breakpoint
CREATE INDEX "auto_abort_rules_script_id_idx" ON "auto_abort_rules" USING btree ("script_id");--> statement-breakpoint
CREATE INDEX "auto_abort_rules_enabled_idx" ON "auto_abort_rules" USING btree ("script_id","is_enabled");--> statement-breakpoint
CREATE INDEX "baseline_executions_script_id_idx" ON "baseline_executions" USING btree ("script_id");--> statement-breakpoint
CREATE INDEX "baseline_executions_active_idx" ON "baseline_executions" USING btree ("script_id","is_active");--> statement-breakpoint
CREATE INDEX "cleanup_history_category_idx" ON "cleanup_history" USING btree ("category");--> statement-breakpoint
CREATE INDEX "cleanup_history_started_at_idx" ON "cleanup_history" USING btree ("started_at");--> statement-breakpoint
CREATE INDEX "comments_execution_id_idx" ON "comments" USING btree ("execution_id");--> statement-breakpoint
CREATE INDEX "dump_analysis_dump_file_id_idx" ON "dump_analysis" USING btree ("dump_file_id");--> statement-breakpoint
CREATE INDEX "dump_analysis_type_idx" ON "dump_analysis" USING btree ("analysis_type");--> statement-breakpoint
CREATE INDEX "dump_annotations_dump_id_idx" ON "dump_annotations" USING btree ("dump_file_id");--> statement-breakpoint
CREATE INDEX "dump_bookmarks_dump_id_idx" ON "dump_bookmarks" USING btree ("dump_file_id");--> statement-breakpoint
CREATE INDEX "dump_bookmarks_user_idx" ON "dump_bookmarks" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "dump_files_type_idx" ON "dump_files" USING btree ("type");--> statement-breakpoint
CREATE INDEX "dump_files_status_idx" ON "dump_files" USING btree ("status");--> statement-breakpoint
CREATE INDEX "dump_files_uploaded_by_idx" ON "dump_files" USING btree ("uploaded_by");--> statement-breakpoint
CREATE INDEX "email_log_execution_id_idx" ON "email_log" USING btree ("execution_id");--> statement-breakpoint
CREATE INDEX "email_log_event_type_idx" ON "email_log" USING btree ("event_type");--> statement-breakpoint
CREATE INDEX "exec_auto_abort_rules_exec_id_idx" ON "execution_auto_abort_rules" USING btree ("execution_id");--> statement-breakpoint
CREATE INDEX "exec_auto_abort_rules_enabled_idx" ON "execution_auto_abort_rules" USING btree ("execution_id","is_enabled");--> statement-breakpoint
CREATE INDEX "exec_sla_rules_exec_id_idx" ON "execution_sla_rules" USING btree ("execution_id");--> statement-breakpoint
CREATE INDEX "exec_sla_rules_enabled_idx" ON "execution_sla_rules" USING btree ("execution_id","is_enabled");--> statement-breakpoint
CREATE INDEX "exec_workload_targets_exec_id_idx" ON "execution_workload_targets" USING btree ("execution_id");--> statement-breakpoint
CREATE INDEX "favorites_user_id_idx" ON "favorites" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "favorites_script_id_idx" ON "favorites" USING btree ("script_id");--> statement-breakpoint
CREATE INDEX "folders_parent_id_idx" ON "folders" USING btree ("parent_id");--> statement-breakpoint
CREATE INDEX "notifications_user_id_idx" ON "notifications" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "notifications_read_idx" ON "notifications" USING btree ("read");--> statement-breakpoint
CREATE INDEX "notifications_user_read_idx" ON "notifications" USING btree ("user_id","read");--> statement-breakpoint
CREATE INDEX "password_reset_tokens_token_idx" ON "password_reset_tokens" USING btree ("token");--> statement-breakpoint
CREATE INDEX "password_reset_tokens_user_id_idx" ON "password_reset_tokens" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "regression_thresholds_script_id_idx" ON "regression_thresholds" USING btree ("script_id");--> statement-breakpoint
CREATE INDEX "remote_ingest_tokens_created_by_idx" ON "remote_ingest_tokens" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "remote_ingest_tokens_token_prefix_idx" ON "remote_ingest_tokens" USING btree ("token_prefix");--> statement-breakpoint
CREATE INDEX "report_approvals_report_id_idx" ON "report_approvals" USING btree ("report_id");--> statement-breakpoint
CREATE INDEX "report_approvals_reviewer_idx" ON "report_approvals" USING btree ("reviewer_user_id");--> statement-breakpoint
CREATE INDEX "report_delivery_schedules_enabled_idx" ON "report_delivery_schedules" USING btree ("enabled");--> statement-breakpoint
CREATE INDEX "report_delivery_schedules_next_run_idx" ON "report_delivery_schedules" USING btree ("next_run_at");--> statement-breakpoint
CREATE INDEX "report_delivery_schedules_created_by_idx" ON "report_delivery_schedules" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "report_templates_created_by_idx" ON "report_templates" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "saved_filter_views_user_page_idx" ON "saved_filter_views" USING btree ("user_id","page");--> statement-breakpoint
CREATE INDEX "script_generations_user_id_idx" ON "script_generations" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "script_generations_status_idx" ON "script_generations" USING btree ("status");--> statement-breakpoint
CREATE INDEX "script_tags_script_id_idx" ON "script_tags" USING btree ("script_id");--> statement-breakpoint
CREATE INDEX "script_tags_tag_id_idx" ON "script_tags" USING btree ("tag_id");--> statement-breakpoint
CREATE INDEX "scripts_name_idx" ON "scripts" USING btree ("name");--> statement-breakpoint
CREATE INDEX "scripts_folder_id_idx" ON "scripts" USING btree ("folder_id");--> statement-breakpoint
CREATE INDEX "scripts_tool_type_idx" ON "scripts" USING btree ("tool_type");--> statement-breakpoint
CREATE INDEX "scripts_project_id_idx" ON "scripts" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "sla_rules_script_id_idx" ON "sla_rules" USING btree ("script_id");--> statement-breakpoint
CREATE INDEX "sla_rules_enabled_idx" ON "sla_rules" USING btree ("script_id","is_enabled");--> statement-breakpoint
CREATE INDEX "test_checkpoints_execution_id_idx" ON "test_checkpoints" USING btree ("execution_id");--> statement-breakpoint
CREATE INDEX "test_checkpoints_state_idx" ON "test_checkpoints" USING btree ("state");--> statement-breakpoint
CREATE INDEX "test_completion_reports_project_id_idx" ON "test_completion_reports" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "test_completion_reports_created_by_idx" ON "test_completion_reports" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "test_completion_reports_status_idx" ON "test_completion_reports" USING btree ("status");--> statement-breakpoint
CREATE INDEX "test_completion_reports_review_status_idx" ON "test_completion_reports" USING btree ("review_status");--> statement-breakpoint
CREATE INDEX "test_executions_status_idx" ON "test_executions" USING btree ("status");--> statement-breakpoint
CREATE INDEX "test_executions_schedule_id_idx" ON "test_executions" USING btree ("schedule_id");--> statement-breakpoint
CREATE INDEX "test_executions_start_time_idx" ON "test_executions" USING btree ("start_time");--> statement-breakpoint
CREATE INDEX "test_executions_script_id_idx" ON "test_executions" USING btree ("script_id");--> statement-breakpoint
CREATE INDEX "test_executions_remote_agent_idx" ON "test_executions" USING btree ("remote_agent_token_id");--> statement-breakpoint
CREATE INDEX "test_executions_status_start_idx" ON "test_executions" USING btree ("status","start_time");--> statement-breakpoint
CREATE INDEX "test_executions_script_status_idx" ON "test_executions" USING btree ("script_id","status");--> statement-breakpoint
CREATE INDEX "test_executions_release_tag_idx" ON "test_executions" USING btree ("release_tag");--> statement-breakpoint
CREATE INDEX "test_schedules_status_idx" ON "test_schedules" USING btree ("status");--> statement-breakpoint
CREATE INDEX "test_schedules_scheduled_time_idx" ON "test_schedules" USING btree ("scheduled_time");--> statement-breakpoint
CREATE INDEX "test_schedules_script_id_idx" ON "test_schedules" USING btree ("script_id");--> statement-breakpoint
CREATE INDEX "test_tracker_project_id_idx" ON "test_tracker" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "test_tracker_test_type_id_idx" ON "test_tracker" USING btree ("test_type_id");--> statement-breakpoint
CREATE INDEX "test_tracker_execution_timestamp_idx" ON "test_tracker" USING btree ("execution_timestamp");--> statement-breakpoint
CREATE INDEX "test_tracker_status_idx" ON "test_tracker" USING btree ("status");--> statement-breakpoint
CREATE INDEX "test_tracker_sort_order_idx" ON "test_tracker" USING btree ("sort_order");--> statement-breakpoint
CREATE INDEX "users_email_idx" ON "users" USING btree ("email");--> statement-breakpoint
CREATE INDEX "users_role_idx" ON "users" USING btree ("role");--> statement-breakpoint
CREATE INDEX "users_is_approved_idx" ON "users" USING btree ("is_approved");--> statement-breakpoint
CREATE INDEX "webhook_deliveries_webhook_id_idx" ON "webhook_deliveries" USING btree ("webhook_id");--> statement-breakpoint
CREATE INDEX "webhook_deliveries_event_idx" ON "webhook_deliveries" USING btree ("event");--> statement-breakpoint
CREATE INDEX "webhook_deliveries_delivered_at_idx" ON "webhook_deliveries" USING btree ("delivered_at");--> statement-breakpoint
CREATE INDEX "webhooks_created_by_idx" ON "webhooks" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "webhooks_enabled_idx" ON "webhooks" USING btree ("enabled");