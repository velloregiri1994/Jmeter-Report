/**
 * Script ID Nullable Migration
 * Makes scriptId nullable in test_schedules to preserve execution history when scripts are deleted
 */

import 'dotenv/config';
import { pool } from '../server/db.js';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function runMigration() {
  console.log('🔄 Starting script_id nullable migration...\n');

  try {
    // Read the SQL migration file
    const sqlFile = path.join(__dirname, 'make_script_id_nullable.sql');
    const sql = fs.readFileSync(sqlFile, 'utf-8');

    // Execute the migration
    await pool.query(sql);

    console.log('✅ Migration completed successfully!');
    console.log('📝 scriptId in test_schedules is now nullable');
    console.log('🔗 Schedules will be preserved when scripts are deleted\n');

    // Verify the changes
    const result = await pool.query(`
      SELECT column_name, is_nullable, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'test_schedules' 
        AND column_name = 'script_id';
    `);

    console.log('Verified column properties:');
    result.rows.forEach(row => {
      console.log(`  - ${row.column_name}: ${row.data_type}, nullable: ${row.is_nullable}`);
    });

  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

runMigration();
