-- Migration: Add timezone support to timestamp columns
-- This ensures all timestamps are stored in UTC and properly converted to local timezone on display

-- Update test_executions table
ALTER TABLE test_executions 
  ALTER COLUMN start_time TYPE timestamp with time zone USING start_time AT TIME ZONE 'UTC',
  ALTER COLUMN end_time TYPE timestamp with time zone USING end_time AT TIME ZONE 'UTC';

-- Update users table
ALTER TABLE users 
  ALTER COLUMN created_at TYPE timestamp with time zone USING created_at AT TIME ZONE 'UTC';

-- Update folders table
ALTER TABLE folders 
  ALTER COLUMN created_at TYPE timestamp with time zone USING created_at AT TIME ZONE 'UTC';

-- Update scripts table
ALTER TABLE scripts 
  ALTER COLUMN created_at TYPE timestamp with time zone USING created_at AT TIME ZONE 'UTC';

-- Update test_schedules table
ALTER TABLE test_schedules 
  ALTER COLUMN scheduled_time TYPE timestamp with time zone USING scheduled_time AT TIME ZONE 'UTC',
  ALTER COLUMN created_at TYPE timestamp with time zone USING created_at AT TIME ZONE 'UTC';

-- Update comments table (if it exists)
DO $$ 
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'comments') THEN
    ALTER TABLE comments 
      ALTER COLUMN created_at TYPE timestamp with time zone USING created_at AT TIME ZONE 'UTC';
  END IF;
END $$;

-- Update notifications table (if it exists)
DO $$ 
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'notifications') THEN
    ALTER TABLE notifications 
      ALTER COLUMN created_at TYPE timestamp with time zone USING created_at AT TIME ZONE 'UTC';
  END IF;
END $$;

-- Update test_metrics table (if it exists)
DO $$ 
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'test_metrics') THEN
    ALTER TABLE test_metrics 
      ALTER COLUMN timestamp TYPE timestamp with time zone USING timestamp AT TIME ZONE 'UTC';
  END IF;
END $$;
