#!/bin/bash
# Run timezone migration

echo "Running timezone migration..."

# Check if DATABASE_URL is set
if [ -z "$DATABASE_URL" ]; then
  echo "Error: DATABASE_URL environment variable is not set"
  echo "Please set it using: export DATABASE_URL='your_database_url'"
  exit 1
fi

# Run the migration using psql
psql "$DATABASE_URL" -f "$(dirname "$0")/add_timezone_to_timestamps.sql"

if [ $? -eq 0 ]; then
  echo "✅ Migration completed successfully!"
  echo "All timestamp columns now use timezone-aware storage."
else
  echo "❌ Migration failed. Please check the error messages above."
  exit 1
fi
