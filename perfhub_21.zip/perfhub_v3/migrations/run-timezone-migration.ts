/**
 * Timezone Migration Script
 * Updates all timestamp columns to use timezone-aware storage (timestamptz)
 * This ensures timestamps are stored in UTC and properly converted to local timezone
 */

import 'dotenv/config';
import { pool } from '../server/db.js';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function runMigration() {
  console.log('🔄 Starting timezone migration...\n');

  try {
    // Read the SQL migration file
    const sqlFile = path.join(__dirname, 'add_timezone_to_timestamps.sql');
    const sql = fs.readFileSync(sqlFile, 'utf-8');

    // Execute the migration
    await pool.query(sql);

    console.log('✅ Migration completed successfully!');
    console.log('📝 All timestamp columns now use timezone-aware storage (timestamptz)');
    console.log('🌍 Timestamps will be stored in UTC and displayed in local timezone\n');

    // Verify the changes
    const result = await pool.query(`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'test_executions' 
        AND column_name IN ('start_time', 'end_time')
      ORDER BY column_name;
    `);

    console.log('Verified column types:');
    result.rows.forEach(row => {
      console.log(`  - ${row.column_name}: ${row.data_type}`);
    });

  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

runMigration();
