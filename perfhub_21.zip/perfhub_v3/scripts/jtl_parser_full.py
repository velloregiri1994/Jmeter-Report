#!/usr/bin/env python3
"""
Apache JMeter JTL Parser + Metrics Calculator
=============================================

Features
--------
- Stream parsing (handles very large files safely)
- Computes summary metrics
- Can print JSON or save metrics.json
- Uses numpy/pandas for performance when available

Metrics
-------
- totalSamples
- min / max
- avg
- p50 / p90 / p95 / p99
- errorCount
- errorPercent
- throughput (req/sec)
- durationSeconds

Usage
-----
python jtl_parser_full.py results.jtl
python jtl_parser_full.py results.jtl --out metrics.json
"""

import csv
import sys
import json
import math
import statistics
from pathlib import Path
import argparse
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from collections import Counter, defaultdict

try:
    import numpy as np
    import pandas as pd
    EXCEL_SUPPORT = True
except ImportError:
    EXCEL_SUPPORT = False
    np = None
    pd = None

HISTOGRAM_MAX_VALUE = 60000


TRANSACTION_CONTROLLER_MARKER = "Number of samples in transaction"


@dataclass
class Sample:
    timestamp_ms: int
    elapsed_ms: float
    label: str
    response_code: str
    success: bool
    all_threads: Optional[int] = None
    response_message: str = ""
    data_type: str = ""

    @property
    def is_transaction_controller(self) -> bool:
        return TRANSACTION_CONTROLLER_MARKER in self.response_message


@dataclass
class LabelStats:
    label: str
    count: int = 0
    success_count: int = 0
    error_count: int = 0
    elapsed_values_ms: List[float] = field(default_factory=list)

    @property
    def error_rate(self) -> float:
        return self.error_count / self.count if self.count else 0.0

    def to_summary(self) -> Dict[str, Any]:
        if not self.elapsed_values_ms:
            return {
                "label": self.label,
                "count": self.count,
                "min": None,
                "max": None,
                "avg": None,
                "p50": None,
                "p90": None,
                "p95": None,
                "p99": None,
                "error_rate": self.error_rate,
            }
        values = sorted(self.elapsed_values_ms)

        def pct(p: float) -> float:
            return percentile(values, p)

        return {
            "label": self.label,
            "count": self.count,
            "min": min(values),
            "max": max(values),
            "avg": statistics.mean(values),
            "p50": pct(50),
            "p90": pct(90),
            "p95": pct(95),
            "p99": pct(99),
            "error_rate": self.error_rate,
        }


def percentile(sorted_values: List[float], p: float) -> float:
    """Compute percentile p (0-100) for a sorted list using linear interpolation."""
    if not sorted_values:
        return float("nan")
    k = (len(sorted_values) - 1) * (p / 100.0)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return sorted_values[int(k)]
    d0 = sorted_values[f] * (c - k)
    d1 = sorted_values[c] * (k - f)
    return d0 + d1


def epoch_ms_to_sec_bucket(ts_ms: int) -> int:
    return int(ts_ms // 1000)


def format_ms(ms: Optional[float]) -> str:
    if ms is None or ms != ms:
        return "-"
    return f"{ms:.1f}"


def format_pct(p: Optional[float]) -> str:
    if p is None or p != p:
        return "-"
    return f"{p * 100:.2f}%"


def format_duration(seconds: float) -> str:
    total = int(round(seconds))
    h = total // 3600
    m = (total % 3600) // 60
    s = total % 60
    return f"{h}h {m}m {s}s"


BUCKET_WIDTH_MS = 5000


class BucketedAggregator:
    def __init__(self, bucket_width_ms: int = BUCKET_WIDTH_MS):
        self.bucket_width_ms = bucket_width_ms
        self.buckets: Dict[int, Dict[str, Any]] = {}
        self.min_ts: Optional[int] = None
        self.max_ts: Optional[int] = None

    def _bucket_key(self, ts_ms: int) -> int:
        return int(ts_ms // self.bucket_width_ms) * self.bucket_width_ms

    def _ensure_bucket(self, key: int) -> Dict[str, Any]:
        if key not in self.buckets:
            self.buckets[key] = {
                "start_ms": key,
                "count": 0,
                "error_count": 0,
                "sum_elapsed": 0.0,
                "min_elapsed": float("inf"),
                "max_elapsed": float("-inf"),
                "histogram": defaultdict(int),
                "active_threads": None,
                "labels": {},
            }
        return self.buckets[key]

    def _ensure_label(self, bucket: Dict[str, Any], label: str) -> Dict[str, Any]:
        if label not in bucket["labels"]:
            bucket["labels"][label] = {
                "count": 0,
                "error_count": 0,
                "sum_elapsed": 0.0,
                "min_elapsed": float("inf"),
                "max_elapsed": float("-inf"),
                "histogram": defaultdict(int),
            }
        return bucket["labels"][label]

    def add_sample(self, sample: 'Sample') -> None:
        key = self._bucket_key(sample.timestamp_ms)
        b = self._ensure_bucket(key)
        lb = self._ensure_label(b, sample.label)

        b["count"] += 1
        b["sum_elapsed"] += sample.elapsed_ms
        b["min_elapsed"] = min(b["min_elapsed"], sample.elapsed_ms)
        b["max_elapsed"] = max(b["max_elapsed"], sample.elapsed_ms)
        if not sample.success:
            b["error_count"] += 1
        hist_idx = min(round(sample.elapsed_ms), HISTOGRAM_MAX_VALUE)
        b["histogram"][hist_idx] += 1
        if sample.all_threads is not None:
            b["active_threads"] = sample.all_threads

        lb["count"] += 1
        lb["sum_elapsed"] += sample.elapsed_ms
        lb["min_elapsed"] = min(lb["min_elapsed"], sample.elapsed_ms)
        lb["max_elapsed"] = max(lb["max_elapsed"], sample.elapsed_ms)
        if not sample.success:
            lb["error_count"] += 1
        lb["histogram"][hist_idx] += 1

        if self.min_ts is None or sample.timestamp_ms < self.min_ts:
            self.min_ts = sample.timestamp_ms
        if self.max_ts is None or sample.timestamp_ms > self.max_ts:
            self.max_ts = sample.timestamp_ms

    @staticmethod
    def _serialize_histogram(histogram: Dict[int, int]) -> List[int]:
        sparse = []
        for idx in sorted(histogram.keys()):
            cnt = histogram[idx]
            if cnt > 0:
                sparse.append(idx)
                sparse.append(cnt)
        return sparse

    def _serialize_label(self, lb: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "count": lb["count"],
            "error_count": lb["error_count"],
            "sum_elapsed": round(lb["sum_elapsed"], 2),
            "min_elapsed": round(lb["min_elapsed"], 2) if lb["min_elapsed"] != float("inf") else 0,
            "max_elapsed": round(lb["max_elapsed"], 2) if lb["max_elapsed"] != float("-inf") else 0,
            "centroids": self._serialize_histogram(lb["histogram"]),
        }

    def to_json(self) -> Dict[str, Any]:
        sorted_keys = sorted(self.buckets.keys())
        serialized = []
        for key in sorted_keys:
            b = self.buckets[key]
            serialized.append({
                "start_ms": b["start_ms"],
                "count": b["count"],
                "error_count": b["error_count"],
                "sum_elapsed": round(b["sum_elapsed"], 2),
                "min_elapsed": round(b["min_elapsed"], 2) if b["min_elapsed"] != float("inf") else 0,
                "max_elapsed": round(b["max_elapsed"], 2) if b["max_elapsed"] != float("-inf") else 0,
                "centroids": self._serialize_histogram(b["histogram"]),
                "active_threads": b["active_threads"],
                "labels": {
                    label: self._serialize_label(lb)
                    for label, lb in b["labels"].items()
                },
            })
        return {
            "bucket_width_ms": self.bucket_width_ms,
            "min_ts": self.min_ts,
            "max_ts": self.max_ts,
            "bucket_count": len(serialized),
            "buckets": serialized,
        }


def compute_apdex(sorted_values: List[float], threshold_s: float) -> float:
    """Compute Apdex score. threshold_s is the satisfied threshold in seconds."""
    if not sorted_values:
        return 1.0
    threshold_ms = threshold_s * 1000
    tolerating_threshold_ms = threshold_ms * 4
    
    satisfied = sum(1 for v in sorted_values if v <= threshold_ms)
    tolerating = sum(1 for v in sorted_values if threshold_ms < v <= tolerating_threshold_ms)
    
    return (satisfied + tolerating / 2) / len(sorted_values)


def _filter_transaction_duplicates(samples: List[Sample]) -> List[Sample]:
    """Filter out duplicate rows caused by JMeter Transaction Controllers.

    When JMeter uses Transaction Controllers with "Generate parent sample" enabled,
    each request appears twice in the JTL:
    1. The parent (transaction controller) row — responseMessage contains
       "Number of samples in transaction", dataType is empty, URL is "null"
    2. The child (HTTP sub-sample) row — has actual dataType (e.g. "text") and URL

    If both are present, we keep only the parent (transaction-level) rows because
    they represent the user's intended transactions and their elapsed time covers the
    full transaction duration. This prevents double-counting of requests.
    """
    if not samples:
        return samples

    parent_count = sum(1 for s in samples if s.is_transaction_controller)
    if parent_count == 0:
        return samples

    child_count = len(samples) - parent_count
    if child_count == 0:
        return samples

    filtered = [s for s in samples if s.is_transaction_controller]
    removed = len(samples) - len(filtered)
    print(
        f"Transaction Controller detected: kept {len(filtered)} transaction rows, "
        f"filtered out {removed} HTTP sub-sample rows",
        file=sys.stderr,
    )
    return filtered


def parse_jmeter_csv(path: str) -> List[Sample]:
    samples: List[Sample] = []
    
    if EXCEL_SUPPORT and pd is not None:
        try:
            df = pd.read_csv(path, low_memory=False)
            col_map = {
                'timeStamp': 'ts', 'timestamp': 'ts',
                'elapsed': 'elapsed',
                'label': 'label',
                'responseCode': 'rc',
                'success': 'success',
                'allThreads': 'at', 'all_threads': 'at',
                'responseMessage': 'msg', 'failureMessage': 'msg',
                'dataType': 'dt',
            }
            df.columns = [col_map.get(c, c) for c in df.columns]
            
            for row in df.itertuples():
                try:
                    ts = int(getattr(row, 'ts', 0))
                    elapsed = float(getattr(row, 'elapsed', 0))
                    label = str(getattr(row, 'label', 'UNKNOWN'))
                    rc = str(getattr(row, 'rc', '')).strip()
                    success_val = getattr(row, 'success', True)
                    success = str(success_val).lower() in ("true", "1", "yes", "y") if isinstance(success_val, str) else bool(success_val)
                    at = getattr(row, 'at', None)
                    all_threads = int(at) if pd.notnull(at) else None
                    msg = str(getattr(row, 'msg', ''))
                    dt_val = getattr(row, 'dt', '')
                    dt = str(dt_val) if pd.notnull(dt_val) else ''
                    
                    samples.append(Sample(ts, elapsed, label, rc, success, all_threads, msg, dt))
                except (ValueError, AttributeError):
                    continue
            return _filter_transaction_duplicates(samples)
        except Exception as e:
            print(f"Note: Fast CSV parsing failed, falling back to standard: {e}", file=sys.stderr)

    with open(path, "r", newline="", encoding="utf-8", errors="ignore") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                ts = int(row.get("timeStamp") or row.get("timestamp") or 0)
                elapsed = float(row.get("elapsed") or 0)
                label = row.get("label", "UNKNOWN")
                rc = str(row.get("responseCode", "")).strip()
                success_raw = str(row.get("success", "true")).strip().lower()
                success = success_raw in ("true", "1", "yes", "y")
                at = row.get("allThreads") or row.get("all_threads")
                all_threads = int(at) if at and at != "" else None
                msg = row.get("responseMessage") or row.get("failureMessage") or ""
                dt = row.get("dataType", "")
                
                samples.append(Sample(ts, elapsed, label, rc, success, all_threads, msg, dt))
            except (ValueError, TypeError):
                continue
    return _filter_transaction_duplicates(samples)


def compute_metrics(samples: List[Sample], apdex_threshold_s: float = 0.5) -> Dict[str, Any]:
    if not samples:
        return {}

    if EXCEL_SUPPORT and np is not None:
        timestamps = np.array([s.timestamp_ms for s in samples], dtype=np.int64)
        elapsed_all = np.array([s.elapsed_ms for s in samples], dtype=np.float64)
        success_all = np.array([s.success for s in samples], dtype=bool)
        
        min_ts = int(timestamps.min())
        max_ts = int(timestamps.max())
        duration_sec = max(1.0, (max_ts - min_ts) / 1000.0)

        total = len(samples)
        errors = int(np.sum(~success_all))
        error_rate = float(errors / total) if total else 0.0

        p50, p90, p95, p99 = np.percentile(elapsed_all, [50, 90, 95, 99])

        global_stats = {
            "total_requests": total,
            "duration_sec": duration_sec,
            "avg_ms": float(np.mean(elapsed_all)),
            "min_ms": float(np.min(elapsed_all)),
            "max_ms": float(np.max(elapsed_all)),
            "p50_ms": float(p50),
            "p90_ms": float(p90),
            "p95_ms": float(p95),
            "p99_ms": float(p99),
            "error_rate": error_rate,
            "errors": errors,
            "successes": int(total - errors),
            "apdex": compute_apdex(sorted(elapsed_all.tolist()), apdex_threshold_s),
            "throughput_rps": total / duration_sec if duration_sec > 0 else 0,
        }
    else:
        timestamps = [s.timestamp_ms for s in samples]
        elapsed_all = [s.elapsed_ms for s in samples]
        success_all = [s.success for s in samples]
        
        min_ts = min(timestamps)
        max_ts = max(timestamps)
        duration_sec = max(1.0, (max_ts - min_ts) / 1000.0)

        total = len(samples)
        errors = sum(1 for s in success_all if not s)
        error_rate = errors / total if total else 0.0

        sorted_elapsed = sorted(elapsed_all)
        
        global_stats = {
            "total_requests": total,
            "duration_sec": duration_sec,
            "avg_ms": statistics.mean(elapsed_all),
            "min_ms": min(elapsed_all),
            "max_ms": max(elapsed_all),
            "p50_ms": percentile(sorted_elapsed, 50),
            "p90_ms": percentile(sorted_elapsed, 90),
            "p95_ms": percentile(sorted_elapsed, 95),
            "p99_ms": percentile(sorted_elapsed, 99),
            "error_rate": error_rate,
            "errors": errors,
            "successes": total - errors,
            "apdex": compute_apdex(sorted_elapsed, apdex_threshold_s),
            "throughput_rps": total / duration_sec if duration_sec > 0 else 0,
        }

    label_groups: Dict[str, List[Sample]] = defaultdict(list)
    label_first_seen: Dict[str, int] = {}
    for idx, s in enumerate(samples):
        label_groups[s.label].append(s)
        if s.label not in label_first_seen:
            label_first_seen[s.label] = idx

    per_label_summaries = []
    for label, group_samples in label_groups.items():
        group_elapsed = [s.elapsed_ms for s in group_samples]
        group_success = [s.success for s in group_samples]
        
        ls = LabelStats(label=label)
        ls.count = len(group_samples)
        ls.error_count = ls.count - sum(group_success)
        ls.success_count = ls.count - ls.error_count
        ls.elapsed_values_ms = group_elapsed
        
        summary = ls.to_summary()
        summary["throughput"] = ls.count / duration_sec if duration_sec > 0 else 0
        summary["error_count"] = ls.error_count
        summary["_first_seen"] = label_first_seen[label]
        per_label_summaries.append(summary)
    
    # Sort by order of first appearance in the test (chronological)
    per_label_summaries.sort(key=lambda x: x["_first_seen"])
    # Remove internal field
    for s in per_label_summaries:
        del s["_first_seen"]

    buckets: Dict[int, List[Sample]] = defaultdict(list)
    for s in samples:
        buckets[epoch_ms_to_sec_bucket(s.timestamp_ms)].append(s)

    timeseries = []
    for sec_bucket, bucket_samples in sorted(buckets.items()):
        b_elapsed = [b.elapsed_ms for b in bucket_samples]
        b_success = [b.success for b in bucket_samples]
        
        rps = len(bucket_samples)
        avg_rt = statistics.mean(b_elapsed) if b_elapsed else 0
        active_threads = bucket_samples[0].all_threads if bucket_samples and bucket_samples[0].all_threads is not None else None
        errors_sec = rps - sum(b_success)

        timeseries.append({
            "sec": sec_bucket,
            "rps": rps,
            "avg_ms": avg_rt,
            "active_threads": active_threads,
            "errors": errors_sec,
        })

    peak_rps = max(ts["rps"] for ts in timeseries) if timeseries else 0

    error_counter: Counter = Counter()
    error_details_counter: Counter = Counter()
    for s in samples:
        if not s.success:
            code = s.response_code or "UNKNOWN"
            error_counter[code] += 1
            key = (s.label, code, s.response_message or "")
            error_details_counter[key] += 1

    error_summary = []
    for code, count in error_counter.most_common():
        error_summary.append({
            "response_code": code,
            "count": count,
            "pct": count / errors if errors else 0.0,
        })

    error_details = []
    for (label, code, msg), count in error_details_counter.most_common():
        error_details.append({
            "label": label,
            "response_code": code,
            "response_message": msg,
            "count": count,
            "pct": count / errors if errors else 0.0,
        })

    metrics = {
        "global": global_stats,
        "per_label": per_label_summaries,
        "timeseries": timeseries,
        "peak_rps": peak_rps,
        "error_summary": error_summary,
        "error_details": error_details,
        "start_time": min_ts,
        "end_time": max_ts,
    }
    return metrics


def main():
    parser = argparse.ArgumentParser(description="Parse JMeter JTL and compute metrics")
    parser.add_argument("jtl_file", help="Path to the JTL file")
    parser.add_argument("--out", "-o", help="Output file path for metrics JSON")
    parser.add_argument("--apdex-threshold", type=float, default=0.5, 
                        help="Apdex satisfied threshold in seconds (default: 0.5)")
    args = parser.parse_args()

    jtl_path = Path(args.jtl_file)
    if not jtl_path.exists():
        print(f"Error: File not found: {jtl_path}", file=sys.stderr)
        sys.exit(1)

    print(f"Parsing {jtl_path}...", file=sys.stderr)
    samples = parse_jmeter_csv(str(jtl_path))
    
    if not samples:
        print("Error: No samples found in JTL file", file=sys.stderr)
        sys.exit(1)

    print(f"Computing metrics for {len(samples)} samples...", file=sys.stderr)
    metrics = compute_metrics(samples, args.apdex_threshold)

    bucketed_agg = BucketedAggregator()
    for s in samples:
        bucketed_agg.add_sample(s)
    bucket_data = bucketed_agg.to_json()
    print(f"Bucketed aggregation: {bucket_data['bucket_count']} buckets ({bucketed_agg.bucket_width_ms}ms each)", file=sys.stderr)

    if args.out:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "w") as f:
            json.dump(metrics, f, indent=2)
        print(f"Metrics written to {out_path}", file=sys.stderr)

        buckets_path = out_path.parent / "buckets.json"
        with open(buckets_path, "w") as f:
            json.dump(bucket_data, f)
        print(f"Buckets written to {buckets_path}", file=sys.stderr)
    else:
        print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
