#!/usr/bin/env bash

PERFHUB_DIR="$(cd "$(dirname "$0")/.." && pwd)"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_ok() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

check_command() { command -v "$1" >/dev/null 2>&1; }

add_pg_to_path() {
  if check_command psql; then
    return
  fi
  local pg_bin_dirs=(
    "/opt/homebrew/opt/postgresql@16/bin"
    "/opt/homebrew/opt/postgresql@15/bin"
    "/opt/homebrew/opt/postgresql@14/bin"
    "/opt/homebrew/opt/postgresql/bin"
    "/usr/local/opt/postgresql@16/bin"
    "/usr/local/opt/postgresql@15/bin"
    "/usr/local/opt/postgresql@14/bin"
    "/usr/local/opt/postgresql/bin"
    "/usr/lib/postgresql/16/bin"
    "/usr/lib/postgresql/15/bin"
    "/usr/lib/postgresql/14/bin"
    "/usr/pgsql-16/bin"
    "/usr/pgsql-15/bin"
  )
  if check_command brew; then
    local brew_prefix
    brew_prefix="$(brew --prefix 2>/dev/null)"
    if [ -n "$brew_prefix" ]; then
      pg_bin_dirs=(
        "${brew_prefix}/opt/postgresql@16/bin"
        "${brew_prefix}/opt/postgresql@15/bin"
        "${brew_prefix}/opt/postgresql@14/bin"
        "${brew_prefix}/opt/postgresql/bin"
        "${pg_bin_dirs[@]}"
      )
    fi
  fi
  for dir in "${pg_bin_dirs[@]}"; do
    if [ -x "${dir}/psql" ]; then
      export PATH="${dir}:${PATH}"
      return
    fi
  done
}

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                                                  ║${NC}"
echo -e "${CYAN}║${NC}     ${RED}PerfHub${NC} — Complete Uninstaller                ${CYAN}║${NC}"
echo -e "${CYAN}║                                                  ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════╝${NC}"
echo ""

if [[ "$OSTYPE" == "darwin"* ]]; then
  OS="macos"
else
  OS="linux"
fi

echo ""
log_info "Step 1/6: Stopping all PerfHub processes..."

if [ -f "${PERFHUB_DIR}/.perfhub.pid" ]; then
  old_pid=$(cat "${PERFHUB_DIR}/.perfhub.pid" 2>/dev/null)
  if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
    log_info "Stopping PerfHub process (PID: $old_pid)..."
    kill "$old_pid" 2>/dev/null || true
    sleep 2
    kill -9 "$old_pid" 2>/dev/null || true
  fi
  rm -f "${PERFHUB_DIR}/.perfhub.pid"
fi

if [ -f "${PERFHUB_DIR}/.env" ]; then
  PERFHUB_PORT=$(grep '^PORT=' "${PERFHUB_DIR}/.env" 2>/dev/null | cut -d= -f2)
fi
PERFHUB_PORT="${PERFHUB_PORT:-3000}"

for port in "$PERFHUB_PORT" 3000 5000 8080 8000; do
  if check_command lsof; then
    pids=$(lsof -iTCP:"$port" -sTCP:LISTEN -t 2>/dev/null || true)
    for pid in $pids; do
      cmdline=$(ps -p "$pid" -o args= 2>/dev/null || true)
      if echo "$cmdline" | grep -qi "perfhub\|dist/index.cjs\|perfhub-service" 2>/dev/null; then
        log_info "Killing PerfHub on port $port (PID: $pid)..."
        kill -9 "$pid" 2>/dev/null || true
      fi
    done
  fi
done

pkill -f "node.*dist/index.cjs" 2>/dev/null || true
pkill -f "node.*perfhub-service" 2>/dev/null || true
sleep 1

log_ok "All PerfHub processes stopped"

echo ""
log_info "Step 2/6: Removing system service..."

if [[ "$OS" == "macos" ]]; then
  plist_path="$HOME/Library/LaunchAgents/com.perfhub.app.plist"
  if [ -f "$plist_path" ]; then
    launchctl unload "$plist_path" 2>/dev/null || true
    rm -f "$plist_path"
    log_ok "macOS launchd service removed"
  else
    log_ok "No macOS service found (already clean)"
  fi
else
  if [ -f "/etc/systemd/system/perfhub.service" ]; then
    sudo systemctl stop perfhub 2>/dev/null || true
    sudo systemctl disable perfhub 2>/dev/null || true
    sudo rm -f /etc/systemd/system/perfhub.service
    sudo systemctl daemon-reload 2>/dev/null || true
    log_ok "systemd service removed"
  else
    log_ok "No systemd service found (already clean)"
  fi
fi

echo ""
log_info "Step 3/6: Removing database and user..."

db_name="perfhub"
db_user="perfhub"

add_pg_to_path

drop_db_success=false
drop_user_success=false

if check_command psql || check_command dropdb; then

  current_user="$(whoami)"

  try_drop_db() {
    local user="$1"
    local host="$2"
    local cmd_args=""
    [ -n "$user" ] && cmd_args="-U $user"
    [ -n "$host" ] && cmd_args="$cmd_args -h $host"

    if check_command dropdb; then
      if dropdb $cmd_args "$db_name" 2>/dev/null; then
        return 0
      fi
    fi
    if psql $cmd_args -d postgres -c "DROP DATABASE IF EXISTS $db_name;" 2>/dev/null; then
      return 0
    fi
    return 1
  }

  try_drop_user() {
    local user="$1"
    local host="$2"
    local cmd_args=""
    [ -n "$user" ] && cmd_args="-U $user"
    [ -n "$host" ] && cmd_args="$cmd_args -h $host"

    if psql $cmd_args -d postgres -c "DROP USER IF EXISTS $db_user;" 2>/dev/null; then
      return 0
    fi
    return 1
  }

  hosts_to_try=("" "/tmp" "localhost")

  socket_dirs=(
    "/tmp"
    "/var/run/postgresql"
    "/private/tmp"
  )
  if check_command brew; then
    brew_prefix="$(brew --prefix 2>/dev/null || echo "/opt/homebrew")"
    socket_dirs+=(
      "${brew_prefix}/var/postgresql@16"
      "${brew_prefix}/var/postgresql@15"
      "${brew_prefix}/var/postgres"
    )
  fi
  for dir in "${socket_dirs[@]}"; do
    if [ -S "${dir}/.s.PGSQL.5432" ] 2>/dev/null; then
      hosts_to_try+=("$dir")
      break
    fi
  done

  for u in "$current_user" "postgres" ""; do
    for h in "${hosts_to_try[@]}"; do
      if [ "$drop_db_success" = false ]; then
        if try_drop_db "$u" "$h"; then
          drop_db_success=true
          log_ok "Database '$db_name' dropped"
        fi
      fi
      if [ "$drop_user_success" = false ]; then
        if try_drop_user "$u" "$h"; then
          drop_user_success=true
          log_ok "Database user '$db_user' removed"
        fi
      fi
      if [ "$drop_db_success" = true ] && [ "$drop_user_success" = true ]; then
        break 2
      fi
    done
  done

  if [ "$drop_db_success" = false ] && [[ "$OS" == "linux" ]]; then
    if sudo -u postgres dropdb "$db_name" 2>/dev/null; then
      drop_db_success=true
      log_ok "Database '$db_name' dropped (via sudo)"
    fi
  fi
  if [ "$drop_user_success" = false ] && [[ "$OS" == "linux" ]]; then
    if sudo -u postgres psql -c "DROP USER IF EXISTS $db_user;" 2>/dev/null; then
      drop_user_success=true
      log_ok "Database user '$db_user' removed (via sudo)"
    fi
  fi
fi

if [ "$drop_db_success" = false ]; then
  log_warn "Could not drop database '$db_name'. It may not exist or requires manual removal."
  log_warn "  Manual: dropdb $db_name"
fi
if [ "$drop_user_success" = false ]; then
  log_warn "Could not remove user '$db_user'. May require manual removal."
fi

echo ""
log_info "Step 4/7: Uninstalling PostgreSQL (installed by PerfHub)..."

if [[ "$OS" == "macos" ]]; then
  if check_command brew; then
    pg_installed=false
    for pg_ver in postgresql@16 postgresql@15 postgresql@14 postgresql; do
      if brew list "$pg_ver" >/dev/null 2>&1; then
        pg_installed=true
        log_info "Stopping PostgreSQL service..."
        brew services stop "$pg_ver" 2>/dev/null || true
        sleep 2
        log_info "Uninstalling $pg_ver..."
        brew uninstall --force "$pg_ver" 2>/dev/null || true
        log_ok "$pg_ver uninstalled"
        break
      fi
    done
    if [ "$pg_installed" = false ]; then
      log_ok "No Homebrew PostgreSQL found (already removed or installed differently)"
    fi

    brew_prefix="$(brew --prefix 2>/dev/null || echo "/opt/homebrew")"
    pg_data_dirs=(
      "${brew_prefix}/var/postgresql@16"
      "${brew_prefix}/var/postgresql@15"
      "${brew_prefix}/var/postgresql@14"
      "${brew_prefix}/var/postgres"
      "${brew_prefix}/var/postgresql"
    )
    for dir in "${pg_data_dirs[@]}"; do
      if [ -d "$dir" ]; then
        rm -rf "$dir" 2>/dev/null || true
        log_ok "Removed PostgreSQL data: $dir"
      fi
    done
  else
    log_warn "Homebrew not found. Cannot auto-uninstall PostgreSQL."
    log_warn "  Manual: brew uninstall postgresql@16"
  fi
else
  log_info "Uninstalling PostgreSQL..."
  if check_command apt-get; then
    sudo apt-get remove -y postgresql postgresql-contrib 2>/dev/null || true
    sudo apt-get autoremove -y 2>/dev/null || true
    log_ok "PostgreSQL packages removed"
  elif check_command yum; then
    sudo yum remove -y postgresql-server postgresql-contrib 2>/dev/null || true
    log_ok "PostgreSQL packages removed"
  elif check_command dnf; then
    sudo dnf remove -y postgresql-server postgresql-contrib 2>/dev/null || true
    log_ok "PostgreSQL packages removed"
  elif check_command pacman; then
    sudo pacman -Rns --noconfirm postgresql 2>/dev/null || true
    log_ok "PostgreSQL packages removed"
  else
    log_warn "Could not detect package manager to remove PostgreSQL."
    log_warn "  Please remove PostgreSQL manually."
  fi

  sudo rm -rf /var/lib/postgresql 2>/dev/null || true
  sudo rm -rf /etc/postgresql 2>/dev/null || true
  log_ok "PostgreSQL data directories removed"
fi

echo ""
log_info "Step 5/9: Uninstalling Node.js..."

if [[ "$OS" == "macos" ]]; then
  if check_command brew; then
    node_removed=false
    for node_ver in node@20 node@22 node@18 node; do
      if brew list "$node_ver" >/dev/null 2>&1; then
        log_info "Uninstalling $node_ver..."
        brew uninstall --force "$node_ver" 2>/dev/null || true
        node_removed=true
        log_ok "$node_ver uninstalled"
        break
      fi
    done
    if [ "$node_removed" = false ]; then
      log_ok "No Homebrew Node.js found (already removed or installed differently)"
    fi
  fi
else
  if check_command apt-get; then
    sudo apt-get remove -y nodejs 2>/dev/null || true
    sudo apt-get autoremove -y 2>/dev/null || true
    sudo rm -f /etc/apt/sources.list.d/nodesource* 2>/dev/null || true
    log_ok "Node.js removed"
  elif check_command yum; then
    sudo yum remove -y nodejs 2>/dev/null || true
    log_ok "Node.js removed"
  elif check_command dnf; then
    sudo dnf remove -y nodejs 2>/dev/null || true
    log_ok "Node.js removed"
  elif check_command pacman; then
    sudo pacman -Rns --noconfirm nodejs npm 2>/dev/null || true
    log_ok "Node.js removed"
  else
    log_warn "Could not detect package manager to remove Node.js."
  fi
fi

echo ""
log_info "Step 6/9: Uninstalling Python packages..."

python_cmd=""
if check_command python3; then
  python_cmd="python3"
elif check_command python; then
  python_cmd="python"
fi

if [ -n "$python_cmd" ]; then
  pip_cmd=""
  if check_command pip3; then
    pip_cmd="pip3"
  elif check_command pip; then
    pip_cmd="pip"
  elif $python_cmd -m pip --version >/dev/null 2>&1; then
    pip_cmd="$python_cmd -m pip"
  fi

  if [ -n "$pip_cmd" ]; then
    log_info "Removing PerfHub Python packages (numpy, scipy, openpyxl, pyyaml)..."
    $pip_cmd uninstall -y numpy scipy openpyxl pyyaml 2>/dev/null || \
    $pip_cmd uninstall --break-system-packages -y numpy scipy openpyxl pyyaml 2>/dev/null || true
    log_ok "Python packages removed"
  else
    log_warn "pip not found. Python packages may need manual removal."
  fi
else
  log_ok "Python not found (already removed or not installed by PerfHub)"
fi

echo ""
log_info "Step 7/9: Removing build and dependency files..."

rm -rf "${PERFHUB_DIR}/node_modules" && log_ok "Removed node_modules/"
rm -rf "${PERFHUB_DIR}/dist" && log_ok "Removed dist/"
rm -f "${PERFHUB_DIR}/package-lock.json" && log_ok "Removed package-lock.json"

echo ""
log_info "Step 8/9: Removing configuration and credentials..."

rm -f "${PERFHUB_DIR}/.env" && log_ok "Removed .env"
rm -f "${PERFHUB_DIR}/.pg_superpass" && log_ok "Removed database credentials"
rm -f "${PERFHUB_DIR}/config.json" && log_ok "Removed config.json"

echo ""
log_info "Step 9/9: Removing logs, temp files, and run data..."

rm -rf "${PERFHUB_DIR}/logs" && log_ok "Removed logs/"
rm -rf "${PERFHUB_DIR}/runs" && log_ok "Removed test run data (runs/)"
rm -rf "${PERFHUB_DIR}/.drizzle" && log_ok "Removed Drizzle cache"
rm -f "${PERFHUB_DIR}/.perfhub.pid"
rm -f "${PERFHUB_DIR}/scripts/start-macos.sh"
rm -f "${PERFHUB_DIR}/scripts/perfhub-service.js"

find "${PERFHUB_DIR}" -name "*.log" -type f -delete 2>/dev/null || true
find "${PERFHUB_DIR}" -name "*.tmp" -type f -delete 2>/dev/null || true
find "${PERFHUB_DIR}" -name ".DS_Store" -type f -delete 2>/dev/null || true
find "${PERFHUB_DIR}" -name "nohup.out" -type f -delete 2>/dev/null || true
find "${PERFHUB_DIR}" -name "*.bak" -type f -delete 2>/dev/null || true
find "${PERFHUB_DIR}" -name "*.swp" -type f -delete 2>/dev/null || true
find "${PERFHUB_DIR}" -name "*~" -type f -delete 2>/dev/null || true

log_ok "All temporary files removed"

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║       PerfHub completely uninstalled!            ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${GREEN}Removed:${NC}"
echo "    - All PerfHub processes"
echo "    - Background service (launchd/systemd)"
echo "    - PostgreSQL server and data"
echo "    - Database '$db_name' and user '$db_user'"
echo "    - Node.js runtime"
echo "    - Python packages (numpy, scipy, openpyxl, pyyaml)"
echo "    - Environment config (.env, config.json)"
echo "    - Build output (dist/)"
echo "    - Dependencies (node_modules/)"
echo "    - Logs, temp files, and run data"
echo "    - Startup scripts and PID files"
echo ""
echo -e "  ${YELLOW}Kept:${NC}"
echo "    - Python runtime (may be used by other apps)"
echo "    - Homebrew (package manager)"
echo "    - Source code files"
echo ""
echo -e "  ${YELLOW}To delete everything including source code:${NC}"
echo "    rm -rf ${PERFHUB_DIR}"
echo ""
echo -e "  ${YELLOW}To reinstall fresh:${NC}"
echo "    bash ${PERFHUB_DIR}/scripts/install.sh"
echo ""
