#Requires -RunAsAdministrator

$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"

$PERFHUB_DIR = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$SERVICE_NAME = "PerfHub"

function Test-CommandExists {
    param([string]$Command)
    return [bool](Get-Command $Command -ErrorAction SilentlyContinue)
}

Write-Host ""
Write-Host "  +==================================================+" -ForegroundColor Cyan
Write-Host "  |                                                  |" -ForegroundColor Cyan
Write-Host "  |     PerfHub -- Complete Uninstaller              |" -ForegroundColor Cyan
Write-Host "  |                                                  |" -ForegroundColor Cyan
Write-Host "  +==================================================+" -ForegroundColor Cyan
Write-Host ""

$confirm = Read-Host "This will completely uninstall PerfHub. Continue? (y/N)"
if ($confirm -ne "y" -and $confirm -ne "Y") {
    Write-Host "Cancelled."
    exit 0
}

Write-Host ""
$deleteDb = Read-Host "Also delete the database and all test data? (y/N)"
Write-Host ""

Write-Host ""
Write-Host "[INFO] Step 1/9: Stopping all PerfHub processes..." -ForegroundColor Blue
try {

$pidFile = Join-Path $PERFHUB_DIR ".perfhub.pid"
if (Test-Path $pidFile) {
    $oldPid = (Get-Content $pidFile -Raw).Trim()
    if ($oldPid -match '^\d+$') {
        try {
            $proc = Get-Process -Id ([int]$oldPid) -ErrorAction SilentlyContinue
            if ($proc) {
                Write-Host "[INFO] Stopping PerfHub process (PID: $oldPid)..." -ForegroundColor Blue
                Stop-Process -Id ([int]$oldPid) -Force -ErrorAction SilentlyContinue
                Start-Sleep -Seconds 2
            }
        } catch {}
    }
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
}

$perfhubPort = "5000"
$envFile = Join-Path $PERFHUB_DIR ".env"
if (Test-Path $envFile) {
    $content = Get-Content $envFile -Raw
    if ($content -match 'PORT=(\d+)') {
        $perfhubPort = $matches[1]
    }
}

$portsToCheck = @($perfhubPort, "3000", "5000", "8080", "8000") | Select-Object -Unique
foreach ($port in $portsToCheck) {
    try {
        $conns = Get-NetTCPConnection -LocalPort ([int]$port) -State Listen -ErrorAction SilentlyContinue
        foreach ($conn in $conns) {
            try {
                $proc = Get-Process -Id $conn.OwningProcess -ErrorAction SilentlyContinue
                if ($proc -and ($proc.ProcessName -eq "node" -or $proc.CommandLine -match "perfhub|dist[\\/]index\.cjs")) {
                    Write-Host "[INFO] Killing PerfHub on port $port (PID: $($conn.OwningProcess))..." -ForegroundColor Blue
                    Stop-Process -Id $conn.OwningProcess -Force -ErrorAction SilentlyContinue
                }
            } catch {}
        }
    } catch {}
}

Get-Process -Name "node" -ErrorAction SilentlyContinue | Where-Object {
    try {
        $cmdLine = (Get-CimInstance Win32_Process -Filter "ProcessId=$($_.Id)" -ErrorAction SilentlyContinue).CommandLine
        $cmdLine -match "dist[\\/]index\.cjs|perfhub-service"
    } catch { $false }
} | Stop-Process -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 1
Write-Host "[OK] All PerfHub processes stopped" -ForegroundColor Green
} catch {
    Write-Host "[WARN] Error stopping processes: $($_.Exception.Message)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "[INFO] Step 2/9: Removing auto-start and service..." -ForegroundColor Blue

# Remove Scheduled Task
try {
    $task = Get-ScheduledTask -TaskName "PerfHub" -ErrorAction SilentlyContinue
    if ($task) {
        Stop-ScheduledTask -TaskName "PerfHub" -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName "PerfHub" -Confirm:$false -ErrorAction SilentlyContinue
        Write-Host "[OK] Scheduled Task 'PerfHub' removed" -ForegroundColor Green
    }
    $startupTask = Get-ScheduledTask -TaskName "PerfHubStartup" -ErrorAction SilentlyContinue
    if ($startupTask) {
        Stop-ScheduledTask -TaskName "PerfHubStartup" -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName "PerfHubStartup" -Confirm:$false -ErrorAction SilentlyContinue
        Write-Host "[OK] Scheduled Task 'PerfHubStartup' removed" -ForegroundColor Green
    }
} catch {
    Write-Host "[WARN] Error removing scheduled task: $($_.Exception.Message)" -ForegroundColor Yellow
}

# Remove NSSM service (legacy installs)
$svcExists = $false
$svc = Get-Service -Name $SERVICE_NAME -ErrorAction SilentlyContinue
if ($svc) { $svcExists = $true }

if ($svcExists -and (Test-CommandExists "nssm")) {
    try {
        nssm stop $SERVICE_NAME 2>&1 | Out-Null
        Start-Sleep -Seconds 1
        nssm remove $SERVICE_NAME confirm 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "[OK] Windows service '$SERVICE_NAME' removed" -ForegroundColor Green
        } else {
            Write-Host "[WARN] NSSM returned exit code $LASTEXITCODE removing service" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "[WARN] Error removing service: $($_.Exception.Message)" -ForegroundColor Yellow
    }
} elseif ($svcExists) {
    Write-Host "[WARN] Service '$SERVICE_NAME' exists but NSSM not found. Remove manually: sc.exe delete $SERVICE_NAME" -ForegroundColor Yellow
} elseif (-not $task -and -not $startupTask) {
    Write-Host "[OK] No auto-start configuration found (already clean)" -ForegroundColor Green
}

# Remove startup folder shortcut
$startupFolder = [System.IO.Path]::Combine($env:APPDATA, "Microsoft\Windows\Start Menu\Programs\Startup")
$startupBat = Join-Path $startupFolder "start-perfhub.bat"
if (Test-Path $startupBat) {
    Remove-Item $startupBat -Force -ErrorAction SilentlyContinue
    Write-Host "[OK] Startup shortcut removed" -ForegroundColor Green
}

Write-Host ""
Write-Host "[INFO] Step 3/9: Removing database and user..." -ForegroundColor Blue

if ($deleteDb -eq "y" -or $deleteDb -eq "Y") {
    $dbName = "perfhub"
    $dbUser = "perfhub"
    $dropDbSuccess = $false
    $dropUserSuccess = $false

    if (Test-CommandExists "psql") {
        $pgSuperPassFile = Join-Path $PERFHUB_DIR ".pg_superpass"
        $connected = $false

        if (Test-Path $pgSuperPassFile) {
            $env:PGPASSWORD = (Get-Content $pgSuperPassFile -Raw).Trim()
            try {
                $test = psql -U postgres -tAc "SELECT 1" 2>&1
                if ("$test".Trim() -eq "1") { $connected = $true }
            } catch {}
        }

        if (-not $connected) {
            $tryPasswords = @("", "postgres", "password", "admin")
            foreach ($pass in $tryPasswords) {
                $env:PGPASSWORD = $pass
                try {
                    $test = psql -U postgres -tAc "SELECT 1" 2>&1
                    if ("$test".Trim() -eq "1") {
                        $connected = $true
                        break
                    }
                } catch {}
            }
        }

        if (-not $connected) {
            $currentUser = $env:USERNAME
            $env:PGPASSWORD = ""
            try {
                $test = psql -U $currentUser -tAc "SELECT 1" 2>&1
                if ("$test".Trim() -eq "1") { $connected = $true }
            } catch {}
        }

        if (-not $connected) {
            try {
                $test = psql -d postgres -tAc "SELECT 1" 2>&1
                if ("$test".Trim() -eq "1") { $connected = $true }
            } catch {}
        }

        if (-not $connected) {
            try {
                $pgPass = Read-Host "Enter PostgreSQL superuser (postgres) password" -AsSecureString
                $env:PGPASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
                    [Runtime.InteropServices.Marshal]::SecureStringToBSTR($pgPass))
                $test = psql -U postgres -tAc "SELECT 1" 2>&1
                if ("$test".Trim() -eq "1") { $connected = $true }
            } catch {}
        }

        if ($connected) {
            try {
                psql -U postgres -c "DROP DATABASE IF EXISTS $dbName;" 2>&1 | Out-Null
                if ($LASTEXITCODE -eq 0) {
                    $dropDbSuccess = $true
                    Write-Host "[OK] Database '$dbName' dropped" -ForegroundColor Green
                } else {
                    Write-Host "[WARN] Could not drop database '$dbName' (exit code $LASTEXITCODE)" -ForegroundColor Yellow
                }
            } catch {
                Write-Host "[WARN] Could not drop database '$dbName'" -ForegroundColor Yellow
            }
            try {
                psql -U postgres -c "DROP USER IF EXISTS $dbUser;" 2>&1 | Out-Null
                if ($LASTEXITCODE -eq 0) {
                    $dropUserSuccess = $true
                    Write-Host "[OK] Database user '$dbUser' removed" -ForegroundColor Green
                } else {
                    Write-Host "[WARN] Could not remove user '$dbUser' (exit code $LASTEXITCODE)" -ForegroundColor Yellow
                }
            } catch {
                Write-Host "[WARN] Could not remove user '$dbUser'" -ForegroundColor Yellow
            }
        }

        if (Test-CommandExists "dropdb") {
            if (-not $dropDbSuccess) {
                try {
                    dropdb $dbName 2>&1 | Out-Null
                    if ($LASTEXITCODE -eq 0) {
                        $dropDbSuccess = $true
                        Write-Host "[OK] Database '$dbName' dropped (via dropdb)" -ForegroundColor Green
                    }
                } catch {}
            }
        }

        if (-not $dropDbSuccess) {
            Write-Host "[WARN] Could not drop database '$dbName'. Remove manually: psql -U postgres -c 'DROP DATABASE perfhub;'" -ForegroundColor Yellow
        }
        if (-not $dropUserSuccess) {
            Write-Host "[WARN] Could not remove user '$dbUser'. Remove manually: psql -U postgres -c 'DROP USER perfhub;'" -ForegroundColor Yellow
        }
    } else {
        Write-Host "[WARN] psql not found. Database must be removed manually." -ForegroundColor Yellow
    }
} else {
    Write-Host "[OK] Database kept (skipped by user)" -ForegroundColor Green
}

Write-Host ""
Write-Host "[INFO] Step 4/9: Uninstalling PostgreSQL..." -ForegroundColor Blue

if ($deleteDb -eq "y" -or $deleteDb -eq "Y") {
    $pgRemoved = $false
    if (Test-CommandExists "choco") {
        $chocoList = choco list --local-only 2>&1
        if ("$chocoList" -match "postgresql") {
            Write-Host "[INFO] Uninstalling PostgreSQL via Chocolatey..." -ForegroundColor Blue
            choco uninstall postgresql16 postgresql15 postgresql -y --remove-dependencies 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) {
                $pgRemoved = $true
                Write-Host "[OK] PostgreSQL uninstalled" -ForegroundColor Green
            } else {
                Write-Host "[WARN] Chocolatey returned exit code $LASTEXITCODE" -ForegroundColor Yellow
            }
        }
    }
    if (-not $pgRemoved -and (Test-CommandExists "winget")) {
        try {
            winget uninstall PostgreSQL.PostgreSQL.16 --silent 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) {
                $pgRemoved = $true
                Write-Host "[OK] PostgreSQL uninstalled via winget" -ForegroundColor Green
            }
        } catch {}
    }
    if (-not $pgRemoved) {
        Write-Host "[OK] No managed PostgreSQL installation found (may be manually installed)" -ForegroundColor Green
    }

    $pgDataDirs = @(
        "$env:ProgramFiles\PostgreSQL",
        "$env:APPDATA\postgresql"
    )
    foreach ($dir in $pgDataDirs) {
        if (Test-Path $dir) {
            Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "[OK] Removed PostgreSQL data: $dir" -ForegroundColor Green
        }
    }
} else {
    Write-Host "[OK] PostgreSQL kept (database was not deleted)" -ForegroundColor Green
}

Write-Host ""
Write-Host "[INFO] Step 5/9: Uninstalling Node.js..." -ForegroundColor Blue

if ($deleteDb -eq "y" -or $deleteDb -eq "Y") {
    $nodeRemoved = $false
    if (Test-CommandExists "choco") {
        $chocoList = choco list --local-only 2>&1
        if ("$chocoList" -match "nodejs") {
            Write-Host "[INFO] Uninstalling Node.js via Chocolatey..." -ForegroundColor Blue
            choco uninstall nodejs nodejs-lts -y 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) {
                $nodeRemoved = $true
                Write-Host "[OK] Node.js uninstalled" -ForegroundColor Green
            } else {
                Write-Host "[WARN] Chocolatey returned exit code $LASTEXITCODE" -ForegroundColor Yellow
            }
        }
    }
    if (-not $nodeRemoved -and (Test-CommandExists "winget")) {
        try {
            winget uninstall OpenJS.NodeJS.LTS --silent 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) {
                $nodeRemoved = $true
                Write-Host "[OK] Node.js uninstalled via winget" -ForegroundColor Green
            }
        } catch {}
    }
    if (-not $nodeRemoved) {
        Write-Host "[OK] No managed Node.js installation found" -ForegroundColor Green
    }
} else {
    Write-Host "[OK] Node.js kept" -ForegroundColor Green
}

Write-Host ""
Write-Host "[INFO] Step 6/9: Removing Python packages..." -ForegroundColor Blue

$pythonCmd = $null
if (Test-CommandExists "python3") { $pythonCmd = "python3" }
elseif (Test-CommandExists "python") {
    try {
        $pyVer = python --version 2>&1
        if ("$pyVer" -match "Python 3") { $pythonCmd = "python" }
    } catch {}
}

if ($pythonCmd) {
    try {
        Write-Host "[INFO] Removing PerfHub Python packages (numpy, scipy, openpyxl, pyyaml)..." -ForegroundColor Blue
        $oldEAP = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
        try {
            & $pythonCmd -m pip uninstall -y numpy scipy openpyxl pyyaml 2>&1 | Out-Null
        } finally {
            $ErrorActionPreference = $oldEAP
        }
        if ($LASTEXITCODE -eq 0) {
            Write-Host "[OK] Python packages removed" -ForegroundColor Green
        } else {
            Write-Host "[WARN] pip returned exit code $LASTEXITCODE (some packages may not have been installed)" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "[WARN] Could not remove Python packages. Remove manually: pip uninstall numpy scipy openpyxl pyyaml" -ForegroundColor Yellow
    }
} else {
    Write-Host "[OK] Python not found (already removed or not installed by PerfHub)" -ForegroundColor Green
}

Write-Host ""
Write-Host "[INFO] Step 7/9: Removing build and dependency files..." -ForegroundColor Blue

$dirsToRemove = @("node_modules", "dist")
foreach ($dir in $dirsToRemove) {
    $fullPath = Join-Path $PERFHUB_DIR $dir
    if (Test-Path $fullPath) {
        Remove-Item $fullPath -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "[OK] Removed $dir/" -ForegroundColor Green
    }
}
$filesToRemove = @("package-lock.json")
foreach ($file in $filesToRemove) {
    $fullPath = Join-Path $PERFHUB_DIR $file
    if (Test-Path $fullPath) {
        Remove-Item $fullPath -Force -ErrorAction SilentlyContinue
        Write-Host "[OK] Removed $file" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "[INFO] Step 8/9: Removing configuration and credentials..." -ForegroundColor Blue

$configFiles = @(".env", ".pg_superpass", "config.json", ".perfhub.pid")
foreach ($file in $configFiles) {
    $fullPath = Join-Path $PERFHUB_DIR $file
    if (Test-Path $fullPath) {
        Remove-Item $fullPath -Force -ErrorAction SilentlyContinue
        Write-Host "[OK] Removed $file" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "[INFO] Step 9/9: Removing logs, temp files, and run data..." -ForegroundColor Blue

$cleanupDirs = @("logs", "runs", ".drizzle")
foreach ($dir in $cleanupDirs) {
    $fullPath = Join-Path $PERFHUB_DIR $dir
    if (Test-Path $fullPath) {
        Remove-Item $fullPath -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "[OK] Removed $dir/" -ForegroundColor Green
    }
}

$cleanupFiles = @(
    (Join-Path $PERFHUB_DIR "start-perfhub.bat"),
    (Join-Path $PERFHUB_DIR "_launcher.bat"),
    (Join-Path (Join-Path $PERFHUB_DIR "scripts") "perfhub-service.js"),
    (Join-Path (Join-Path $PERFHUB_DIR "scripts") "perfhub-service.cjs"),
    (Join-Path (Join-Path $PERFHUB_DIR "scripts") "start-macos.sh")
)
foreach ($file in $cleanupFiles) {
    if (Test-Path $file) {
        Remove-Item $file -Force -ErrorAction SilentlyContinue
    }
}

Get-ChildItem $PERFHUB_DIR -Recurse -Include "*.log", "*.tmp", "*.bak", "nohup.out" -ErrorAction SilentlyContinue |
    Remove-Item -Force -ErrorAction SilentlyContinue

Write-Host "[OK] All temporary files removed" -ForegroundColor Green

Write-Host ""
Write-Host "  +==================================================+" -ForegroundColor Green
Write-Host "  |       PerfHub completely uninstalled!             |" -ForegroundColor Green
Write-Host "  +==================================================+" -ForegroundColor Green
Write-Host ""
Write-Host "  Removed:" -ForegroundColor Green
Write-Host "    - All PerfHub processes"
Write-Host "    - Scheduled Task auto-start / Windows service"
if ($deleteDb -eq "y" -or $deleteDb -eq "Y") {
    Write-Host "    - PostgreSQL server and data"
    Write-Host "    - Database 'perfhub' and user 'perfhub'"
    Write-Host "    - Node.js runtime"
}
Write-Host "    - Python packages (numpy, scipy, openpyxl, pyyaml)"
Write-Host "    - Environment config (.env, config.json)"
Write-Host "    - Build output (dist/)"
Write-Host "    - Dependencies (node_modules/)"
Write-Host "    - Logs, temp files, and run data"
Write-Host "    - Startup scripts and PID files"
Write-Host ""
Write-Host "  Kept:" -ForegroundColor Yellow
Write-Host "    - Python runtime (may be used by other apps)"
Write-Host "    - Chocolatey (package manager)"
Write-Host "    - Source code files"
if ($deleteDb -ne "y" -and $deleteDb -ne "Y") {
    Write-Host "    - PostgreSQL server and database 'perfhub'" -ForegroundColor Yellow
    Write-Host "    - Node.js runtime"
}
Write-Host ""
Write-Host "  To delete everything including source code:" -ForegroundColor Yellow
Write-Host "    Remove-Item -Recurse -Force '$PERFHUB_DIR'"
Write-Host ""
Write-Host "  To reinstall fresh:" -ForegroundColor Yellow
Write-Host "    PowerShell -File '$PERFHUB_DIR\scripts\install.ps1'"
Write-Host ""
