#!/usr/bin/env python3
"""
Final JTL Parser for PerfHub
Parses JMeter JTL (CSV format) files after test completion.
Outputs JSON to stdout for Node.js consumption.
Uses reservoir sampling for memory-efficient percentile estimation on large files.
"""

import csv
import gzip
import json
import random
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Any

RESERVOIR_SIZE = 100_000


@dataclass
class ReservoirSampler:
    max_size: int = RESERVOIR_SIZE
    samples: List[int] = field(default_factory=list)
    count: int = 0

    def add(self, value: int) -> None:
        self.count += 1
        if len(self.samples) < self.max_size:
            self.samples.append(value)
        else:
            j = random.randint(0, self.count - 1)
            if j < self.max_size:
                self.samples[j] = value


@dataclass
class TxMetrics:
    count: int = 0
    error_count: int = 0
    rt_sampler: ReservoirSampler = field(default_factory=ReservoirSampler)
    ct_sampler: ReservoirSampler = field(default_factory=ReservoirSampler)
    min_rt: int = 10**12
    max_rt: int = 0
    total_rt: int = 0
    total_connect: int = 0
    first_ts: int = 10**18
    last_ts: int = 0


def percentile(sorted_vals: List[int], p: float) -> int:
    """Calculate percentile with linear interpolation."""
    if not sorted_vals:
        return 0
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    k = (p / 100) * (len(sorted_vals) - 1)
    f = int(k)
    c = min(f + 1, len(sorted_vals) - 1)
    if f == c:
        return sorted_vals[int(k)]
    return round(sorted_vals[f] * (c - k) + sorted_vals[c] * (k - f))


def parse_final_jtl(jtl_path: str) -> Dict[str, Any]:
    """
    Accurate full JTL parser for FINAL metrics (after test completion).
    Supports large CSV JTL files (gzipped or plain).
    Uses reservoir sampling to bound memory usage for percentile calculations.
    """

    tx_map: Dict[str, TxMetrics] = defaultdict(TxMetrics)
    all_rt_sampler = ReservoirSampler()
    error_details: Dict[str, Dict[str, Any]] = {}

    total_samples = 0
    total_errors = 0
    total_rt_sum = 0
    global_min_rt = 10**12
    global_max_rt = 0
    global_start = 10**18
    global_end = 0

    opener = gzip.open if jtl_path.endswith(".gz") else open

    with opener(jtl_path, "rt", encoding="utf-8", errors="ignore") as f:
        reader = csv.DictReader(f)

        for row in reader:
            try:
                ts = int(row.get("timeStamp", 0))
                elapsed = int(float(row.get("elapsed", 0)))
                label = (row.get("label") or "Unknown").strip()
                success = str(row.get("success", "")).lower() == "true"
                response_code = row.get("responseCode", "")
                response_message = row.get("responseMessage", "")
                failure_message = row.get("failureMessage", "")
            except Exception:
                continue

            connect_time = 0
            for key in ["Connect Time(ms)", "connectTime", "connect_time"]:
                val = row.get(key, "")
                if val:
                    try:
                        connect_time = int(float(val))
                    except Exception:
                        pass
                    break

            total_samples += 1
            total_rt_sum += elapsed
            global_min_rt = min(global_min_rt, elapsed)
            global_max_rt = max(global_max_rt, elapsed)

            if not success:
                total_errors += 1
                error_msg = failure_message or response_message or "Unknown error"
                error_key = f"{label}:{error_msg}"
                if error_key not in error_details:
                    error_details[error_key] = {
                        "transaction": label,
                        "message": error_msg,
                        "statusCode": response_code,
                        "count": 0,
                        "timestamp": ts
                    }
                error_details[error_key]["count"] += 1

            global_start = min(global_start, ts)
            global_end = max(global_end, ts)

            all_rt_sampler.add(elapsed)

            tx = tx_map[label]
            tx.count += 1
            if not success:
                tx.error_count += 1

            tx.total_rt += elapsed
            tx.min_rt = min(tx.min_rt, elapsed)
            tx.max_rt = max(tx.max_rt, elapsed)
            tx.rt_sampler.add(elapsed)
            tx.ct_sampler.add(connect_time)
            tx.total_connect += connect_time
            tx.first_ts = min(tx.first_ts, ts)
            tx.last_ts = max(tx.last_ts, ts)

    duration_ms = max(global_end - global_start, 1)
    duration_sec = duration_ms / 1000.0

    all_rts_sorted = sorted(all_rt_sampler.samples)

    overall = {
        "totalRequests": total_samples,
        "failedRequests": total_errors,
        "durationSec": round(duration_sec, 2),
        "avgResponseTime": round(total_rt_sum / total_samples) if total_samples else 0,
        "minResponseTime": global_min_rt if global_min_rt < 10**12 else 0,
        "maxResponseTime": global_max_rt,
        "p50": percentile(all_rts_sorted, 50),
        "p90": percentile(all_rts_sorted, 90),
        "p95": percentile(all_rts_sorted, 95),
        "p99": percentile(all_rts_sorted, 99),
        "errorRate": round((total_errors / total_samples) * 100, 2) if total_samples else 0,
        "throughput": round(total_samples / duration_sec, 2) if duration_sec > 0 else 0,
    }

    transactions = []
    for label, tx in tx_map.items():
        rts_sorted = sorted(tx.rt_sampler.samples)
        tx_duration_sec = max((tx.last_ts - tx.first_ts) / 1000.0, 1)

        avg_connect = round(tx.total_connect / tx.count) if tx.count else 0
        avg_elapsed = round(tx.total_rt / tx.count) if tx.count else 0
        avg_transfer = max(0, avg_elapsed - avg_connect)
        connect_sorted = sorted(tx.ct_sampler.samples)

        transactions.append({
            "label": label,
            "count": tx.count,
            "errorCount": tx.error_count,
            "avg": avg_elapsed,
            "min": tx.min_rt if tx.min_rt < 10**12 else 0,
            "max": tx.max_rt,
            "p50": percentile(rts_sorted, 50),
            "p90": percentile(rts_sorted, 90),
            "p95": percentile(rts_sorted, 95),
            "p99": percentile(rts_sorted, 99),
            "errorRate": round((tx.error_count / tx.count) * 100, 2) if tx.count else 0,
            "throughput": round(tx.count / tx_duration_sec, 2),
            "hitsPerSec": round(tx.count / duration_sec, 2) if duration_sec > 0 else 0,
            "avgConnect": avg_connect,
            "avgLatency": avg_transfer,
            "avgTransfer": max(0, avg_elapsed - avg_connect),
            "p50Connect": percentile(connect_sorted, 50),
            "p90Connect": percentile(connect_sorted, 90),
            "p95Connect": percentile(connect_sorted, 95),
        })

    error_list = sorted(error_details.values(), key=lambda x: -x["count"])[:20]

    return {
        "success": True,
        "overall": overall,
        "transactions": transactions,
        "errorDetails": error_list,
        "parsingStats": {
            "totalLines": total_samples,
            "durationMs": duration_ms,
        }
    }


def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            "success": False,
            "error": "Usage: python jtl_parser.py <path_to_jtl_file>"
        }))
        sys.exit(1)

    jtl_path = sys.argv[1]

    try:
        result = parse_final_jtl(jtl_path)
        print(json.dumps(result))
    except FileNotFoundError:
        print(json.dumps({
            "success": False,
            "error": f"JTL file not found: {jtl_path}"
        }))
        sys.exit(1)
    except Exception as e:
        print(json.dumps({
            "success": False,
            "error": f"Error parsing JTL: {str(e)}"
        }))
        sys.exit(1)


if __name__ == "__main__":
    main()
