#!/usr/bin/env bash
set -e

PERFHUB_DIR="$(cd "$(dirname "$0")/.." && pwd)"
NODE_MIN_VERSION=18
PG_MIN_VERSION=14

find_free_port() {
  local preferred_ports=(5000 3000 8080 8000 9000 4000 7000 6000)

  for port in "${preferred_ports[@]}"; do
    if ! lsof -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1 && \
       ! ss -tlnp 2>/dev/null | grep -q ":${port} " 2>/dev/null && \
       ! netstat -an 2>/dev/null | grep -q "\.${port}.*LISTEN" 2>/dev/null; then
      echo "$port"
      return
    fi
  done

  local port=5001
  while [ $port -le 9999 ]; do
    if ! lsof -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1 && \
       ! ss -tlnp 2>/dev/null | grep -q ":${port} " 2>/dev/null; then
      echo "$port"
      return
    fi
    port=$((port + 1))
  done

  echo "5000"
}

if [ -n "$PERFHUB_PORT" ]; then
  PERFHUB_PORT="$PERFHUB_PORT"
else
  PERFHUB_PORT=$(find_free_port)
fi

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

print_banner() {
  echo ""
  echo -e "${CYAN}╔══════════════════════════════════════════════════╗${NC}"
  echo -e "${CYAN}║                                                  ║${NC}"
  echo -e "${CYAN}║${NC}     ${BLUE}PerfHub${NC} — Enterprise Performance Platform     ${CYAN}║${NC}"
  echo -e "${CYAN}║                                                  ║${NC}"
  echo -e "${CYAN}╚══════════════════════════════════════════════════╝${NC}"
  echo ""
}

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_ok() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

check_command() { command -v "$1" >/dev/null 2>&1; }

version_gte() {
  local v1="$1" v2="$2"
  [ "$(printf '%s\n' "$v1" "$v2" | sort -V | head -n1)" = "$v2" ]
}

detect_os() {
  if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    if check_command apt-get; then
      OS="debian"
    elif check_command yum; then
      OS="rhel"
    elif check_command dnf; then
      OS="fedora"
    elif check_command pacman; then
      OS="arch"
    else
      OS="linux"
    fi
  elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macos"
  else
    log_error "Unsupported operating system: $OSTYPE"
    exit 1
  fi
  log_info "Detected OS: $OS"
}

add_node_to_path() {
  if check_command node; then
    return
  fi

  local node_bin_dirs=(
    "/opt/homebrew/opt/node@20/bin"
    "/opt/homebrew/opt/node@22/bin"
    "/opt/homebrew/opt/node/bin"
    "/usr/local/opt/node@20/bin"
    "/usr/local/opt/node@22/bin"
    "/usr/local/opt/node/bin"
  )

  if check_command brew; then
    local brew_prefix
    brew_prefix="$(brew --prefix 2>/dev/null)"
    if [ -n "$brew_prefix" ]; then
      node_bin_dirs=(
        "${brew_prefix}/opt/node@20/bin"
        "${brew_prefix}/opt/node@22/bin"
        "${brew_prefix}/opt/node/bin"
        "${node_bin_dirs[@]}"
      )
    fi
  fi

  for dir in "${node_bin_dirs[@]}"; do
    if [ -x "${dir}/node" ]; then
      export PATH="${dir}:${PATH}"
      log_info "Added Node.js to PATH: ${dir}"
      return
    fi
  done
}

install_nodejs() {
  add_node_to_path

  if check_command node; then
    local node_version
    node_version=$(node -v | sed 's/v//' | cut -d. -f1)
    if [ "$node_version" -ge "$NODE_MIN_VERSION" ]; then
      log_ok "Node.js $(node -v) is already installed"
      return
    else
      log_warn "Node.js $(node -v) is too old (need v${NODE_MIN_VERSION}+)"
    fi
  fi

  log_info "Installing Node.js v20..."
  case $OS in
    debian)
      curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
      sudo apt-get install -y nodejs
      ;;
    rhel)
      curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
      sudo yum install -y nodejs
      ;;
    fedora)
      curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
      sudo dnf install -y nodejs
      ;;
    arch)
      sudo pacman -S --noconfirm nodejs npm
      ;;
    macos)
      if ! check_command brew; then
        log_error "Homebrew is required to install Node.js on macOS."
        log_error "Install Homebrew first: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
        log_error "Then re-run this installer."
        exit 1
      fi
      brew install node@20 || brew upgrade node@20 || true
      brew link --overwrite node@20 2>/dev/null || true

      local brew_prefix
      brew_prefix="$(brew --prefix 2>/dev/null || echo "/opt/homebrew")"
      local node_bin="${brew_prefix}/opt/node@20/bin"
      if [ -d "$node_bin" ]; then
        export PATH="${node_bin}:${PATH}"
        log_info "Added keg-only Node.js to PATH: ${node_bin}"
      fi
      add_node_to_path

      if [ -d "$node_bin" ]; then
        local shell_rc=""
        if [ -f "$HOME/.zshrc" ]; then
          shell_rc="$HOME/.zshrc"
        elif [ -f "$HOME/.bashrc" ]; then
          shell_rc="$HOME/.bashrc"
        elif [ -f "$HOME/.bash_profile" ]; then
          shell_rc="$HOME/.bash_profile"
        fi
        if [ -n "$shell_rc" ] && ! grep -q "node@20/bin" "$shell_rc" 2>/dev/null; then
          echo "" >> "$shell_rc"
          echo "# Added by PerfHub installer -- Homebrew Node.js 20" >> "$shell_rc"
          echo "export PATH=\"${node_bin}:\$PATH\"" >> "$shell_rc"
          log_info "Added Node.js to PATH in $(basename "$shell_rc")"
        fi
      fi
      ;;
  esac

  if check_command node; then
    log_ok "Node.js $(node -v) installed successfully"
  else
    log_error "Failed to install Node.js. Please install Node.js v${NODE_MIN_VERSION}+ manually."
    exit 1
  fi
}

add_pg_to_path() {
  if check_command psql; then
    return
  fi

  local pg_bin_dirs=(
    "/opt/homebrew/opt/postgresql@16/bin"
    "/opt/homebrew/opt/postgresql@15/bin"
    "/opt/homebrew/opt/postgresql@14/bin"
    "/opt/homebrew/opt/postgresql/bin"
    "/usr/local/opt/postgresql@16/bin"
    "/usr/local/opt/postgresql@15/bin"
    "/usr/local/opt/postgresql@14/bin"
    "/usr/local/opt/postgresql/bin"
  )

  if check_command brew; then
    local brew_prefix
    brew_prefix="$(brew --prefix 2>/dev/null)"
    if [ -n "$brew_prefix" ]; then
      pg_bin_dirs=(
        "${brew_prefix}/opt/postgresql@16/bin"
        "${brew_prefix}/opt/postgresql@15/bin"
        "${brew_prefix}/opt/postgresql@14/bin"
        "${brew_prefix}/opt/postgresql/bin"
        "${pg_bin_dirs[@]}"
      )
    fi
  fi

  for dir in "${pg_bin_dirs[@]}"; do
    if [ -x "${dir}/psql" ]; then
      export PATH="${dir}:${PATH}"
      log_info "Added PostgreSQL to PATH: ${dir}"
      return
    fi
  done

  local pg_system_dirs=(
    "/usr/lib/postgresql/16/bin"
    "/usr/lib/postgresql/15/bin"
    "/usr/lib/postgresql/14/bin"
    "/usr/pgsql-16/bin"
    "/usr/pgsql-15/bin"
  )
  for dir in "${pg_system_dirs[@]}"; do
    if [ -x "${dir}/psql" ]; then
      export PATH="${dir}:${PATH}"
      log_info "Added PostgreSQL to PATH: ${dir}"
      return
    fi
  done
}

install_postgresql() {
  add_pg_to_path

  if check_command psql; then
    log_ok "PostgreSQL is already installed ($(psql --version | head -1))"
  else
    log_info "Installing PostgreSQL..."
    case $OS in
      debian)
        sudo apt-get update
        sudo apt-get install -y postgresql postgresql-contrib
        ;;
      rhel)
        sudo yum install -y postgresql-server postgresql-contrib
        sudo postgresql-setup --initdb 2>/dev/null || true
        ;;
      fedora)
        sudo dnf install -y postgresql-server postgresql-contrib
        sudo postgresql-setup --initdb 2>/dev/null || true
        ;;
      arch)
        sudo pacman -S --noconfirm postgresql
        sudo -u postgres initdb -D /var/lib/postgres/data 2>/dev/null || true
        ;;
      macos)
        brew install postgresql@16 || brew upgrade postgresql@16 || true
        brew link --overwrite postgresql@16 2>/dev/null || true
        ;;
    esac

    add_pg_to_path

    if ! check_command psql; then
      log_error "PostgreSQL installed but psql not found in PATH."
      log_error "Please add PostgreSQL bin directory to your PATH and re-run."
      exit 1
    fi
    log_ok "PostgreSQL installed"
  fi

  log_info "Starting PostgreSQL service..."
  case $OS in
    debian|rhel|fedora|arch)
      sudo systemctl start postgresql 2>/dev/null || sudo service postgresql start 2>/dev/null || true
      sudo systemctl enable postgresql 2>/dev/null || true
      ;;
    macos)
      brew services start postgresql@16 2>/dev/null || brew services start postgresql 2>/dev/null || true
      ;;
  esac

  log_info "Waiting for PostgreSQL to accept connections..."
  local pg_started=false
  for i in $(seq 1 30); do
    if pg_isready -q 2>/dev/null; then
      pg_started=true
      break
    fi
    if psql -d postgres -tAc "SELECT 1" >/dev/null 2>&1; then
      pg_started=true
      break
    fi
    sleep 1
  done
  if [ "$pg_started" = true ]; then
    log_ok "PostgreSQL is running and accepting connections"
  else
    log_warn "PostgreSQL started but may need a few more seconds to be ready"
  fi
}

setup_database() {
  local db_name="perfhub"
  local db_user="perfhub"
  local db_pass
  db_pass=$(openssl rand -hex 16 2>/dev/null || head -c 32 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | head -c 32)

  log_info "Setting up PerfHub database..."

  if [ -f "$PERFHUB_DIR/.env" ] && grep -q "DATABASE_URL" "$PERFHUB_DIR/.env"; then
    log_info "Existing .env found. Verifying database connection..."
    set -a; source "$PERFHUB_DIR/.env"; set +a
    if psql "$DATABASE_URL" -c "SELECT 1" >/dev/null 2>&1; then
      log_ok "Using existing database configuration (connection verified)"
      return
    else
      log_warn "Existing .env has invalid DATABASE_URL. Re-creating database..."
    fi
  fi

  find_pg_socket_dir() {
    local socket_dirs=(
      "/tmp"
      "/var/run/postgresql"
      "/var/pgsql_socket"
      "/private/tmp"
    )

    if [[ "$OS" == "macos" ]] && check_command brew; then
      local brew_prefix
      brew_prefix="$(brew --prefix 2>/dev/null || echo "/opt/homebrew")"
      socket_dirs+=(
        "${brew_prefix}/var/postgresql@16"
        "${brew_prefix}/var/postgresql@15"
        "${brew_prefix}/var/postgresql@14"
        "${brew_prefix}/var/postgres"
        "${brew_prefix}/var/postgresql"
        "/usr/local/var/postgresql@16"
        "/usr/local/var/postgresql@15"
        "/usr/local/var/postgres"
      )
    fi

    for dir in "${socket_dirs[@]}"; do
      if [ -S "${dir}/.s.PGSQL.5432" ] 2>/dev/null; then
        echo "$dir"
        return
      fi
    done

    for dir in "${socket_dirs[@]}"; do
      local found
      found=$(find "$dir" -maxdepth 1 -name ".s.PGSQL.*" -type s 2>/dev/null | head -1)
      if [ -n "$found" ]; then
        echo "$dir"
        return
      fi
    done

    echo ""
  }

  try_pg_connect() {
    local timeout_val=5
    if check_command timeout; then
      timeout "$timeout_val" psql "$@" -tAc "SELECT 1" >/dev/null 2>&1
    else
      psql "$@" -tAc "SELECT 1" >/dev/null 2>&1
    fi
  }

  detect_pg_superuser() {
    local current_user
    current_user="$(whoami)"

    if try_pg_connect -d postgres; then
      echo "CURRENT_USER"
      return
    fi

    if try_pg_connect -U "$current_user" -d postgres; then
      echo "CURRENT_USER_EXPLICIT"
      return
    fi

    if [ -n "$reported_socket" ]; then
      if try_pg_connect -U "$current_user" -h "$reported_socket" -d postgres; then
        PG_SOCKET_DIR="$reported_socket"
        echo "MACOS_SOCKET"
        return
      fi
    fi

    local socket_dir
    socket_dir=$(find_pg_socket_dir)
    if [ -n "$socket_dir" ]; then
      if try_pg_connect -U "$current_user" -h "$socket_dir" -d postgres; then
        PG_SOCKET_DIR="$socket_dir"
        echo "MACOS_SOCKET"
        return
      fi
    fi

    if try_pg_connect -U "$current_user" -h /tmp -d postgres; then
      PG_SOCKET_DIR="/tmp"
      echo "MACOS_SOCKET"
      return
    fi

    if try_pg_connect -U "$current_user" -h localhost -d postgres; then
      echo "MACOS_LOCALHOST"
      return
    fi

    if try_pg_connect -U postgres -h localhost -d postgres; then
      echo "POSTGRES_LOCALHOST"
      return
    fi

    if try_pg_connect -U postgres -d postgres; then
      echo "POSTGRES_DEFAULT"
      return
    fi

    if [ -n "$socket_dir" ]; then
      if try_pg_connect -U postgres -h "$socket_dir" -d postgres; then
        PG_SOCKET_DIR="$socket_dir"
        echo "POSTGRES_SOCKET"
        return
      fi
    fi

    if [[ "$OS" != "macos" ]]; then
      if sudo -u postgres psql -tAc "SELECT 1" >/dev/null 2>&1; then
        echo "SUDO_POSTGRES"
        return
      fi
    fi

    echo ""
  }

  run_pg_cmd() {
    local pg_superuser="$1"
    shift
    case "$pg_superuser" in
      SUDO_POSTGRES)
        sudo -u postgres psql "$@" ;;
      CURRENT_USER)
        psql -d postgres "$@" ;;
      CURRENT_USER_EXPLICIT)
        psql -U "$(whoami)" -d postgres "$@" ;;
      MACOS_SOCKET)
        psql -U "$(whoami)" -h "${PG_SOCKET_DIR:-/tmp}" -d postgres "$@" ;;
      MACOS_LOCALHOST)
        psql -U "$(whoami)" -h localhost -d postgres "$@" ;;
      POSTGRES_LOCALHOST)
        psql -U postgres -h localhost -d postgres "$@" ;;
      POSTGRES_DEFAULT)
        psql -U postgres -d postgres "$@" ;;
      POSTGRES_SOCKET)
        psql -U postgres -h "${PG_SOCKET_DIR:-/tmp}" -d postgres "$@" ;;
      *)
        psql -U "$pg_superuser" -d postgres "$@" ;;
    esac
  }

  try_pg_connect_with() {
    local pg_user="$1"
    local pg_host="$2"
    if [ -n "$pg_host" ]; then
      psql -U "$pg_user" -h "$pg_host" -d postgres -tAc "SELECT 1" >/dev/null 2>&1
    else
      psql -U "$pg_user" -d postgres -tAc "SELECT 1" >/dev/null 2>&1
    fi
  }

  run_sql_with() {
    local pg_user="$1"
    local pg_host="$2"
    shift 2
    if [ -n "$pg_host" ]; then
      psql -U "$pg_user" -h "$pg_host" -d postgres "$@"
    else
      psql -U "$pg_user" -d postgres "$@"
    fi
  }

  try_create_database_with() {
    local pg_user="$1"
    local pg_host="$2"

    if ! try_pg_connect_with "$pg_user" "$pg_host"; then
      return 1
    fi

    if [ -n "$pg_host" ]; then
      log_ok "Connected to PostgreSQL as '$pg_user' via host '$pg_host'"
    else
      log_ok "Connected to PostgreSQL as '$pg_user'"
    fi

    run_sql_with "$pg_user" "$pg_host" -c "CREATE USER $db_user WITH PASSWORD '$db_pass'" 2>/dev/null || true
    run_sql_with "$pg_user" "$pg_host" -c "ALTER USER $db_user WITH PASSWORD '$db_pass'" 2>/dev/null || true

    local db_exists
    db_exists=$(run_sql_with "$pg_user" "$pg_host" -tAc "SELECT 1 FROM pg_database WHERE datname='$db_name'" 2>/dev/null || echo "")
    if [ "$db_exists" = "1" ]; then
      log_ok "Database '$db_name' already exists"
    else
      if run_sql_with "$pg_user" "$pg_host" -c "CREATE DATABASE $db_name OWNER $db_user" 2>/dev/null; then
        log_ok "Database '$db_name' created successfully"
      else
        return 1
      fi
    fi

    run_sql_with "$pg_user" "$pg_host" -c "GRANT ALL PRIVILEGES ON DATABASE $db_name TO $db_user" 2>/dev/null || true
    return 0
  }

  get_pg_socket_from_running() {
    local socket_from_pg
    socket_from_pg=$(psql -d postgres -tAc "SHOW unix_socket_directories" 2>/dev/null | tr -d ' ' | head -1)
    if [ -n "$socket_from_pg" ]; then
      local first_dir
      first_dir=$(echo "$socket_from_pg" | cut -d',' -f1)
      if [ -d "$first_dir" ]; then
        echo "$first_dir"
        return
      fi
    fi
    echo ""
  }

  log_info "Waiting for PostgreSQL to be ready..."
  local pg_ready=false
  for attempt in $(seq 1 30); do
    if pg_isready -q 2>/dev/null; then
      pg_ready=true
      break
    fi
    if try_pg_connect -d postgres; then
      pg_ready=true
      break
    fi
    sleep 1
  done
  if [ "$pg_ready" = false ]; then
    log_warn "PostgreSQL may not be fully ready yet. Continuing with connection attempts..."
  fi

  local reported_socket
  reported_socket=$(get_pg_socket_from_running)

  PG_SOCKET_DIR=""
  local pg_superuser
  pg_superuser=$(detect_pg_superuser)

  if [ -z "$pg_superuser" ]; then
    log_warn "Standard detection did not find a working PostgreSQL connection."
    log_info "Trying all known connection methods automatically..."

    local current_user
    current_user="$(whoami)"
    local direct_success=false

    local socket_dir
    socket_dir=$(find_pg_socket_dir)

    local -a try_users=("$current_user" "postgres")
    local -a try_hosts=("" "/tmp" "localhost")
    if [ -n "$socket_dir" ]; then
      try_hosts+=("$socket_dir")
    fi
    if [ -n "$reported_socket" ] && [ "$reported_socket" != "/tmp" ] && [ "$reported_socket" != "$socket_dir" ]; then
      try_hosts+=("$reported_socket")
    fi

    for u in "${try_users[@]}"; do
      for h in "${try_hosts[@]}"; do
        if try_create_database_with "$u" "$h"; then
          direct_success=true
          break 2
        fi
      done
    done

    if [ "$direct_success" = false ]; then
      log_info "Trying createdb command as fallback..."
      if check_command createdb; then
        createdb "$db_name" 2>/dev/null && log_ok "Database '$db_name' created via createdb" && direct_success=true
        if [ "$direct_success" = false ]; then
          createdb -U "$current_user" "$db_name" 2>/dev/null && log_ok "Database '$db_name' created via createdb" && direct_success=true
        fi
        if [ "$direct_success" = false ]; then
          createdb -h /tmp "$db_name" 2>/dev/null && log_ok "Database '$db_name' created via createdb" && direct_success=true
        fi
        if [ "$direct_success" = false ]; then
          createdb -h localhost "$db_name" 2>/dev/null && log_ok "Database '$db_name' created via createdb" && direct_success=true
        fi
        if [ "$direct_success" = true ]; then
          local pg_port
          pg_port=$(psql -d postgres -tAc "SHOW port" 2>/dev/null | tr -d ' ' || echo "5432")
          pg_port="${pg_port:-5432}"

          local session_secret
          session_secret=$(openssl rand -hex 32 2>/dev/null || head -c 64 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | head -c 64)
          cat > "$PERFHUB_DIR/.env" <<EOF
DATABASE_URL=postgresql://${current_user}@localhost:${pg_port}/${db_name}
SESSION_SECRET=${session_secret}
PORT=${PERFHUB_PORT}
NODE_ENV=production
EOF
          chmod 600 "$PERFHUB_DIR/.env"
          log_ok "Environment configuration saved to .env"
          return
        fi
      fi
    fi

    if [ "$direct_success" = false ]; then
      log_error "Could not connect to PostgreSQL automatically."
      log_error "Please ensure PostgreSQL is installed, running, and your user has access."
      echo ""
      echo "  Quick fix — run these commands in a new terminal:"
      echo "    brew services start postgresql@16   (macOS)"
      echo "    sudo systemctl start postgresql     (Linux)"
      echo "  Then re-run this installer."
      echo ""
      exit 1
    fi
  fi

  local db_exists
  db_exists=$(run_pg_cmd "$pg_superuser" -tAc "SELECT 1 FROM pg_database WHERE datname='$db_name'" 2>/dev/null || echo "")

  if [ "$db_exists" != "1" ]; then
    run_pg_cmd "$pg_superuser" -c "CREATE USER $db_user WITH PASSWORD '$db_pass';" 2>/dev/null || true
    run_pg_cmd "$pg_superuser" -c "ALTER USER $db_user WITH PASSWORD '$db_pass';" 2>/dev/null || true
    if ! run_pg_cmd "$pg_superuser" -c "CREATE DATABASE $db_name OWNER $db_user;" 2>/dev/null; then
      local recheck
      recheck=$(run_pg_cmd "$pg_superuser" -tAc "SELECT 1 FROM pg_database WHERE datname='$db_name'" 2>/dev/null || echo "")
      if [ "$recheck" = "1" ]; then
        log_ok "Database '$db_name' already exists"
      else
        log_error "Failed to create database '$db_name'. Check PostgreSQL permissions."
        exit 1
      fi
    else
      log_ok "Database '$db_name' created with user '$db_user'"
    fi
    run_pg_cmd "$pg_superuser" -c "GRANT ALL PRIVILEGES ON DATABASE $db_name TO $db_user;" 2>/dev/null || true
  else
    log_ok "Database '$db_name' already exists"
    run_pg_cmd "$pg_superuser" -c "ALTER USER $db_user WITH PASSWORD '$db_pass';" 2>/dev/null || true
  fi

  local db_url=""
  local pg_port
  pg_port=$(psql -d postgres -tAc "SHOW port" 2>/dev/null | tr -d ' ' || echo "5432")
  pg_port="${pg_port:-5432}"

  if PGPASSWORD="$db_pass" psql -U "$db_user" -d "$db_name" -h localhost -p "$pg_port" -tAc "SELECT 1" >/dev/null 2>&1; then
    db_url="postgresql://${db_user}:${db_pass}@localhost:${pg_port}/${db_name}"
    log_ok "Database connection verified (password auth)"
  elif psql -U "$db_user" -d "$db_name" -h localhost -p "$pg_port" -tAc "SELECT 1" >/dev/null 2>&1; then
    db_url="postgresql://${db_user}@localhost:${pg_port}/${db_name}"
    log_ok "Database connection verified (trust auth via localhost)"
  elif psql -U "$db_user" -d "$db_name" -tAc "SELECT 1" >/dev/null 2>&1; then
    db_url="postgresql://${db_user}@localhost:${pg_port}/${db_name}"
    log_ok "Database connection verified (peer/trust auth via socket)"
  elif psql -d "$db_name" -tAc "SELECT 1" >/dev/null 2>&1; then
    local current_user
    current_user="$(whoami)"
    db_url="postgresql://${current_user}@localhost:${pg_port}/${db_name}"
    log_ok "Database connection verified (current user auth)"
  else
    log_warn "Could not verify database connection with standard methods."
    log_warn "Defaulting to password-based DATABASE_URL. You may need to adjust .env manually."
    db_url="postgresql://${db_user}:${db_pass}@localhost:${pg_port}/${db_name}"
  fi

  local session_secret
  session_secret=$(openssl rand -hex 32 2>/dev/null || head -c 64 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | head -c 64)

  cat > "$PERFHUB_DIR/.env" <<EOF
DATABASE_URL=${db_url}
SESSION_SECRET=${session_secret}
PORT=${PERFHUB_PORT}
NODE_ENV=production
EOF

  chmod 600 "$PERFHUB_DIR/.env"
  log_ok "Environment configuration saved to .env"
}

ensure_production_env() {
  local env_file="$PERFHUB_DIR/.env"
  log_info "Ensuring production-safe settings in .env..."

  # Ensure NODE_ENV=production
  if grep -q "^NODE_ENV=" "$env_file" 2>/dev/null; then
    sed -i.bak "s/^NODE_ENV=.*/NODE_ENV=production/" "$env_file"
  else
    echo "NODE_ENV=production" >> "$env_file"
  fi

  # Ensure COOKIE_SECURE=false (secure cookies require HTTPS; direct installs use HTTP)
  if grep -q "^COOKIE_SECURE=" "$env_file" 2>/dev/null; then
    sed -i.bak "s/^COOKIE_SECURE=.*/COOKIE_SECURE=false/" "$env_file"
  else
    echo "COOKIE_SECURE=false" >> "$env_file"
  fi

  # Ensure TRUST_PROXY=false for direct installs (no reverse proxy)
  if grep -q "^TRUST_PROXY=" "$env_file" 2>/dev/null; then
    sed -i.bak "s/^TRUST_PROXY=.*/TRUST_PROXY=false/" "$env_file"
  else
    echo "TRUST_PROXY=false" >> "$env_file"
  fi

  # Replace default dev SESSION_SECRET with a strong random value
  if grep -q "^SESSION_SECRET=dev-secret-key-change-in-production" "$env_file" 2>/dev/null; then
    local new_secret
    new_secret=$(openssl rand -hex 32 2>/dev/null || head -c 64 /dev/urandom | od -An -tx1 | tr -d ' \n')
    sed -i.bak "s/^SESSION_SECRET=dev-secret-key-change-in-production/SESSION_SECRET=${new_secret}/" "$env_file"
    log_info "Generated new SESSION_SECRET (replaced dev default)"
  fi

  rm -f "$env_file.bak"
  log_ok "Production settings applied to .env"
}

install_native_deps() {
  log_info "Installing native build dependencies (canvas, bcrypt)..."
  case $OS in
    debian)
      sudo apt-get update -qq
      sudo apt-get install -y \
        build-essential \
        pkg-config \
        libcairo2-dev \
        libpango1.0-dev \
        libjpeg-dev \
        libgif-dev \
        librsvg2-dev \
        uuid-dev \
        curl \
        git
      ;;
    rhel)
      sudo yum install -y \
        gcc-c++ \
        make \
        pkgconfig \
        cairo-devel \
        pango-devel \
        libjpeg-turbo-devel \
        giflib-devel \
        librsvg2-devel \
        libuuid-devel \
        curl \
        git
      ;;
    fedora)
      sudo dnf install -y \
        gcc-c++ \
        make \
        pkgconfig \
        cairo-devel \
        pango-devel \
        libjpeg-turbo-devel \
        giflib-devel \
        librsvg2-devel \
        libuuid-devel \
        curl \
        git
      ;;
    arch)
      sudo pacman -S --noconfirm \
        base-devel \
        pkgconf \
        cairo \
        pango \
        libjpeg-turbo \
        giflib \
        librsvg \
        util-linux-libs \
        curl \
        git
      ;;
    macos)
      if ! check_command brew; then
        log_warn "Homebrew not found. Skipping native dependency installation."
        log_warn "Install Homebrew and run: brew install pkg-config cairo pango jpeg giflib librsvg"
        return
      fi
      brew install pkg-config cairo pango jpeg giflib librsvg 2>/dev/null || true
      ;;
  esac
  log_ok "Native build dependencies installed"
}

install_python() {
  local python_cmd=""
  if check_command python3; then
    python_cmd="python3"
  elif check_command python; then
    python_cmd="python"
  fi

  if [ -n "$python_cmd" ]; then
    local py_version
    py_version=$($python_cmd --version 2>&1 | grep -oE '[0-9]+\.[0-9]+' | head -1)
    log_ok "Python $py_version is available ($python_cmd)"
  else
    log_info "Installing Python 3..."
    case $OS in
      debian)
        sudo apt-get install -y python3 python3-pip python3-venv
        ;;
      rhel)
        sudo yum install -y python3 python3-pip
        ;;
      fedora)
        sudo dnf install -y python3 python3-pip
        ;;
      arch)
        sudo pacman -S --noconfirm python python-pip
        ;;
      macos)
        if check_command brew; then
          brew install python@3.11 || brew upgrade python@3.11 || true
          brew link --overwrite python@3.11 2>/dev/null || true
        else
          log_warn "Homebrew not found. Install Python 3.11+ manually from https://www.python.org/downloads/"
          return
        fi
        ;;
    esac
    if check_command python3; then
      python_cmd="python3"
    elif check_command python; then
      python_cmd="python"
    fi
  fi

  if [ -z "$python_cmd" ]; then
    log_warn "Python not found. JTL parsing and report generation will not work."
    log_warn "Install Python 3.11+ manually to enable these features."
    return
  fi

  log_info "Installing/upgrading Python packages (numpy, scipy, openpyxl, pyyaml, pandas)..."
  local pip_cmd=""
  if $python_cmd -m pip --version >/dev/null 2>&1; then
    pip_cmd="$python_cmd -m pip"
  elif check_command pip3; then
    pip_cmd="pip3"
  elif check_command pip; then
    pip_cmd="pip"
  fi

  if [ -z "$pip_cmd" ]; then
    log_warn "pip not found. Install Python packages manually: pip3 install --upgrade numpy pandas scipy openpyxl pyyaml"
    return
  fi

  local pip_installed=false
  local packages="numpy scipy openpyxl pyyaml pandas"

  if $pip_cmd install --upgrade $packages 2>&1; then
    pip_installed=true
  elif $pip_cmd install --upgrade --user $packages 2>&1; then
    pip_installed=true
  elif $pip_cmd install --upgrade --break-system-packages $packages 2>&1; then
    pip_installed=true
  fi

  if [ "$pip_installed" = true ]; then
    local pandas_ver
    pandas_ver=$($python_cmd -c "import pandas; print(pandas.__version__)" 2>/dev/null || echo "unknown")
    local numpy_ver
    numpy_ver=$($python_cmd -c "import numpy; print(numpy.__version__)" 2>/dev/null || echo "unknown")
    log_ok "Python packages installed — pandas=$pandas_ver, numpy=$numpy_ver"
  else
    log_warn "Could not install Python packages automatically."
    log_warn "Install manually: $pip_cmd install --upgrade numpy pandas scipy openpyxl pyyaml"
  fi
}

install_dependencies() {
  log_info "Installing application dependencies..."
  cd "$PERFHUB_DIR"
  npm install --production=false
  log_ok "Dependencies installed"
}

detect_jmeter() {
  log_info "Scanning for JMeter installations..."

  local jmeter_home=""

  if [ -n "$JMETER_HOME" ] && [ -f "$JMETER_HOME/bin/jmeter" ]; then
    jmeter_home="$JMETER_HOME"
    log_ok "Found JMeter via JMETER_HOME: $jmeter_home"
  fi

  if [ -z "$jmeter_home" ]; then
    local jmeter_bin
    jmeter_bin=$(which jmeter 2>/dev/null || true)
    if [ -n "$jmeter_bin" ] && [ -f "$jmeter_bin" ]; then
      local real_bin
      real_bin=$(readlink -f "$jmeter_bin" 2>/dev/null || echo "$jmeter_bin")
      jmeter_home=$(dirname "$(dirname "$real_bin")")
      log_ok "Found JMeter on PATH: $jmeter_home"
    fi
  fi

  if [ -z "$jmeter_home" ]; then
    local search_dirs=("/opt" "/usr/local" "/usr/share" "$HOME")
    if [[ "$OS" == "macos" ]]; then
      local brew_prefix
      brew_prefix=$(brew --prefix 2>/dev/null || echo "/opt/homebrew")
      search_dirs+=("$brew_prefix/Cellar/jmeter")
    fi

    for dir in "${search_dirs[@]}"; do
      if [ -d "$dir" ]; then
        for match in "$dir"/apache-jmeter-*/bin/jmeter "$dir"/jmeter/bin/jmeter "$dir"/jmeter/*/libexec/bin/jmeter; do
          if [ -f "$match" ]; then
            local bin_dir
            bin_dir=$(dirname "$match")
            jmeter_home=$(dirname "$bin_dir")
            log_ok "Found JMeter at: $jmeter_home"
            break 2
          fi
        done
      fi
    done
  fi

  if [ -n "$jmeter_home" ]; then
    local version=""
    version=$("$jmeter_home/bin/jmeter" --version 2>&1 | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1 || true)
    if [ -n "$version" ]; then
      log_ok "JMeter version: $version"
    fi

    local config_file="${PERFHUB_DIR}/config.json"
    if [ -f "$config_file" ]; then
      local tmp_file="${config_file}.tmp"
      if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
with open('$config_file') as f: c = json.load(f)
c.setdefault('jmeter', {})['home'] = '$jmeter_home'
with open('$tmp_file', 'w') as f: json.dump(c, f, indent=2)
" 2>/dev/null && mv "$tmp_file" "$config_file"
      else
        echo "{\"jmeter\":{\"home\":\"$jmeter_home\"}}" > "$config_file"
      fi
    else
      echo "{\"jmeter\":{\"home\":\"$jmeter_home\"}}" > "$config_file"
    fi
    log_ok "JMeter path saved to config.json"
  else
    log_warn "JMeter not found. You can configure it later in Settings > General."
    log_info "Install JMeter: https://jmeter.apache.org/download_jmeter.cgi"
  fi
}

build_app() {
  log_info "Building PerfHub for production..."
  cd "$PERFHUB_DIR"
  npm run build
  log_ok "Production build complete"
}

backup_database() {
  cd "$PERFHUB_DIR"
  set -a
  source "$PERFHUB_DIR/.env"
  set +a

  local table_count
  table_count=$(psql "$DATABASE_URL" -tAc "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public'" 2>/dev/null || echo "0")

  if [[ "$table_count" -gt 0 ]]; then
    local backup_dir="$PERFHUB_DIR/backups"
    mkdir -p "$backup_dir"

    local timestamp
    timestamp=$(date +"%Y%m%d_%H%M%S")
    local backup_file="$backup_dir/perfhub_backup_${timestamp}.sql"

    log_info "Backing up existing database before migration..."
    if pg_dump "$DATABASE_URL" --no-owner --no-acl -f "$backup_file" 2>/dev/null; then
      log_ok "Database backed up to: $backup_file"
    else
      log_warn "Database backup failed (pg_dump not available or connection error)."
      log_warn "Continuing with migration — no data will be deleted, only additive changes applied."
    fi

    local old_backups
    old_backups=$(ls -1t "$backup_dir"/perfhub_backup_*.sql 2>/dev/null | tail -n +6)
    if [[ -n "$old_backups" ]]; then
      echo "$old_backups" | xargs rm -f
    fi
  fi
}

push_schema() {
  log_info "Setting up database tables..."
  cd "$PERFHUB_DIR"
  set -a
  source "$PERFHUB_DIR/.env"
  set +a

  backup_database

  npm run db:migrate
  if [[ $? -ne 0 ]]; then
    log_error "Database migration failed."
    log_error "Check your DATABASE_URL in .env and ensure PostgreSQL is running."
    log_error "If upgrading, a backup was saved in the 'backups' folder."
    exit 1
  fi
  log_ok "Database schema applied (migrations)"
}

create_systemd_service() {
  if [[ "$OS" == "macos" ]]; then
    create_launchd_service
    return
  fi

  log_info "Creating system service..."

  local node_path
  node_path=$(which node)

  sudo tee /etc/systemd/system/perfhub.service > /dev/null <<EOF
[Unit]
Description=PerfHub - Enterprise Performance Testing Platform
After=network.target postgresql.service
Requires=postgresql.service

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=${PERFHUB_DIR}
EnvironmentFile=${PERFHUB_DIR}/.env
ExecStart=${node_path} dist/index.cjs
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=perfhub

[Install]
WantedBy=multi-user.target
EOF

  sudo systemctl daemon-reload
  sudo systemctl enable perfhub
  log_ok "System service created (perfhub)"
}

is_macos_protected_dir() {
  local dir="$1"
  local home="$HOME"
  local protected_dirs=(
    "${home}/Documents"
    "${home}/Desktop"
    "${home}/Downloads"
    "${home}/Movies"
    "${home}/Music"
    "${home}/Pictures"
  )
  for pd in "${protected_dirs[@]}"; do
    if [[ "$dir" == "$pd" || "$dir" == "$pd/"* ]]; then
      return 0
    fi
  done
  return 1
}

create_launchd_service() {
  log_info "Creating launchd service for macOS..."

  local plist_path="$HOME/Library/LaunchAgents/com.perfhub.app.plist"
  local node_path
  node_path=$(which node)

  mkdir -p "$HOME/Library/LaunchAgents"
  mkdir -p "$PERFHUB_DIR/logs"

  local node_dir
  node_dir="$(dirname "$node_path")"

  local pg_dir=""
  if check_command psql; then
    pg_dir="$(dirname "$(which psql)")"
  fi

  local brew_prefix_val=""
  if check_command brew; then
    brew_prefix_val="$(brew --prefix 2>/dev/null)"
  fi

  local safe_support_dir="$HOME/Library/Application Support/PerfHub"
  mkdir -p "$safe_support_dir"

  local safe_log_dir="$safe_support_dir/logs"
  mkdir -p "$safe_log_dir"

  local use_protected_dir=false
  local effective_app_dir="$PERFHUB_DIR"

  if is_macos_protected_dir "$PERFHUB_DIR"; then
    use_protected_dir=true
    effective_app_dir="$safe_support_dir/app"
    log_warn "PerfHub is installed in a macOS-protected directory (${PERFHUB_DIR})."
    log_warn "macOS restricts background processes from accessing ~/Documents, ~/Desktop, etc."
    log_info "Copying runtime files to ~/Library/Application Support/PerfHub/app/ for auto-start..."

    mkdir -p "$effective_app_dir"

    log_info "Copying application files (this may take a moment)..."
    if check_command rsync; then
      rsync -a --delete \
        --exclude '.git' \
        --exclude 'logs' \
        "${PERFHUB_DIR}/" "$effective_app_dir/"
    else
      rm -rf "$effective_app_dir"
      mkdir -p "$effective_app_dir"
      cp -R "${PERFHUB_DIR}/." "$effective_app_dir/"
      rm -rf "$effective_app_dir/.git" 2>/dev/null || true
    fi

    mkdir -p "$effective_app_dir/logs"
    mkdir -p "$effective_app_dir/results"
    mkdir -p "$effective_app_dir/uploads"

    if [ ! -f "$effective_app_dir/dist/index.cjs" ]; then
      log_error "Failed to copy runtime files — dist/index.cjs not found at $effective_app_dir"
      log_error "Please ensure you have built the app (npm run build) before installing."
      exit 1
    fi

    log_ok "Runtime files copied to $effective_app_dir"
  fi

  local safe_start_script="${safe_support_dir}/start-macos.sh"

  {
    echo '#!/usr/bin/env bash'
    echo ''
    echo "export PATH=\"${node_dir}:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin\""
    if [ -n "$pg_dir" ] && [ "$pg_dir" != "$node_dir" ]; then
      echo "export PATH=\"${pg_dir}:\$PATH\""
    fi
    if [ -n "$brew_prefix_val" ]; then
      echo "export PATH=\"${brew_prefix_val}/bin:\$PATH\""
    fi
    echo ''
    echo "PERFHUB_APP_DIR=\"${effective_app_dir}\""
    echo ''
    echo "if [ -f \"\${PERFHUB_APP_DIR}/.env\" ]; then"
    echo "  set -a"
    echo "  source \"\${PERFHUB_APP_DIR}/.env\""
    echo "  set +a"
    echo "fi"
    echo ""
    echo "if lsof -iTCP:\"\${PORT:-${PERFHUB_PORT}}\" -sTCP:LISTEN >/dev/null 2>&1; then"
    echo "  echo \"PerfHub is already running on port \${PORT:-${PERFHUB_PORT}}. Skipping.\""
    echo "  exit 0"
    echo "fi"
    echo ""
    echo "cd \"\${PERFHUB_APP_DIR}\" 2>/dev/null || cd \"${safe_support_dir}\" 2>/dev/null || true"
    echo "exec \"${node_path}\" \"\${PERFHUB_APP_DIR}/dist/index.cjs\""
  } > "$safe_start_script"
  chmod +x "$safe_start_script"

  cp "$safe_start_script" "${PERFHUB_DIR}/scripts/start-macos.sh" 2>/dev/null || true
  chmod +x "${PERFHUB_DIR}/scripts/start-macos.sh" 2>/dev/null || true

  log_info "Startup script created at: ${safe_start_script}"

  cat > "$plist_path" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.perfhub.app</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>${safe_start_script}</string>
  </array>
  <key>WorkingDirectory</key>
  <string>${effective_app_dir}</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>${node_dir}:${pg_dir:+${pg_dir}:}${brew_prefix_val:+${brew_prefix_val}/bin:}/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    <key>HOME</key>
    <string>${HOME}</string>
  </dict>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <dict>
    <key>SuccessfulExit</key>
    <false/>
  </dict>
  <key>ThrottleInterval</key>
  <integer>10</integer>
  <key>StandardOutPath</key>
  <string>${safe_log_dir}/perfhub.log</string>
  <key>StandardErrorPath</key>
  <string>${safe_log_dir}/perfhub-error.log</string>
</dict>
</plist>
EOF

  if [ "$use_protected_dir" = true ]; then
    echo ""
    log_info "Auto-start is configured to use the copied files at:"
    log_info "  ${effective_app_dir}"
    log_info "If you update PerfHub, re-run the installer to sync changes."
  fi

  log_ok "macOS service created"
}

kill_existing_perfhub() {
  if [ -f "${PERFHUB_DIR}/.perfhub.pid" ]; then
    local old_pid
    old_pid=$(cat "${PERFHUB_DIR}/.perfhub.pid" 2>/dev/null)
    if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
      log_info "Stopping previous PerfHub instance (PID: $old_pid)..."
      kill "$old_pid" 2>/dev/null || true
      sleep 2
      kill -9 "$old_pid" 2>/dev/null || true
    fi
    rm -f "${PERFHUB_DIR}/.perfhub.pid"
  fi

  if lsof -iTCP:"${PERFHUB_PORT}" -sTCP:LISTEN >/dev/null 2>&1; then
    log_info "Port ${PERFHUB_PORT} is in use. Stopping existing process..."
    lsof -iTCP:"${PERFHUB_PORT}" -sTCP:LISTEN -t 2>/dev/null | xargs kill -9 2>/dev/null || true
    sleep 2
  fi
}

ensure_port_free() {
  if lsof -iTCP:"${PERFHUB_PORT}" -sTCP:LISTEN >/dev/null 2>&1; then
    log_warn "Port ${PERFHUB_PORT} is still in use after cleanup. Finding a free port..."
    PERFHUB_PORT=$(find_free_port)
    log_info "Using port ${PERFHUB_PORT} instead"

    sed -i.bak "s/^PORT=.*/PORT=${PERFHUB_PORT}/" "$PERFHUB_DIR/.env" 2>/dev/null || \
    sed -i '' "s/^PORT=.*/PORT=${PERFHUB_PORT}/" "$PERFHUB_DIR/.env"
    rm -f "$PERFHUB_DIR/.env.bak"
    log_ok "Updated .env with port ${PERFHUB_PORT}"
  fi
}

start_app() {
  log_info "Starting PerfHub..."

  if [[ "$OS" == "macos" ]]; then
    launchctl unload "$HOME/Library/LaunchAgents/com.perfhub.app.plist" 2>/dev/null || true
  fi

  kill_existing_perfhub
  ensure_port_free

  mkdir -p "${PERFHUB_DIR}/logs"

  cd "$PERFHUB_DIR"

  if [ -f "$PERFHUB_DIR/.env" ]; then
    set -a
    source "$PERFHUB_DIR/.env"
    set +a
  fi
  export PORT="${PERFHUB_PORT}"
  export NODE_ENV="production"

  local node_cmd
  node_cmd="$(which node)"
  local log_out="${PERFHUB_DIR}/logs/perfhub.log"
  local log_err="${PERFHUB_DIR}/logs/perfhub-error.log"

  log_info "Starting PerfHub directly (node dist/index.cjs)..."
  nohup "$node_cmd" dist/index.cjs > "$log_out" 2> "$log_err" &
  local app_pid=$!
  echo "$app_pid" > "${PERFHUB_DIR}/.perfhub.pid"

  log_info "Waiting for PerfHub to be ready (PID: $app_pid)..."
  local app_started=false
  for i in $(seq 1 15); do
    if ! kill -0 "$app_pid" 2>/dev/null; then
      log_error "PerfHub process exited unexpectedly."
      break
    fi
    if curl -s -o /dev/null -w "%{http_code}" "http://localhost:${PERFHUB_PORT}" 2>/dev/null | grep -q "200\|304\|302"; then
      app_started=true
      break
    fi
    sleep 2
  done

  if [ "$app_started" = true ]; then
    log_ok "PerfHub is running at http://localhost:${PERFHUB_PORT} (PID: $app_pid)"

    case $OS in
      macos)
        log_info "Auto-start service registered (launchd — will activate on next login/reboot)"
        ;;
      *)
        sudo systemctl enable perfhub 2>/dev/null || true
        log_info "Auto-start service enabled (systemd — will activate on next boot)"
        ;;
    esac
  else
    log_error "PerfHub failed to start. Check logs:"
    log_error "  $log_err"
    if [ -f "$log_err" ]; then
      echo ""
      tail -15 "$log_err" 2>/dev/null || true
    fi
  fi
}

open_browser() {
  local url="http://localhost:${PERFHUB_PORT}"
  log_info "Opening PerfHub in your browser..."

  case $OS in
    macos)
      open "$url" 2>/dev/null || true
      ;;
    *)
      if check_command xdg-open; then
        xdg-open "$url" 2>/dev/null || true
      elif check_command gnome-open; then
        gnome-open "$url" 2>/dev/null || true
      else
        log_info "Open your browser and navigate to: $url"
      fi
      ;;
  esac
}

print_summary() {
  echo ""
  echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}║         PerfHub installed successfully!          ║${NC}"
  echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "  ${BLUE}URL:${NC}      http://localhost:${PERFHUB_PORT}"
  echo -e "  ${BLUE}Config:${NC}   ${PERFHUB_DIR}/.env"
  echo ""
  echo -e "  ${YELLOW}Commands:${NC}"
  if [[ "$OS" == "macos" ]]; then
    echo -e "    Start:   cd ${PERFHUB_DIR} && source .env && node dist/index.cjs"
    echo -e "    Stop:    kill \$(cat ${PERFHUB_DIR}/.perfhub.pid)"
    echo -e "    Logs:    tail -f ${PERFHUB_DIR}/logs/perfhub.log"
    echo ""
    echo -e "  ${YELLOW}Auto-start (launchd):${NC}"
    echo -e "    Load:    launchctl load ~/Library/LaunchAgents/com.perfhub.app.plist"
    echo -e "    Unload:  launchctl unload ~/Library/LaunchAgents/com.perfhub.app.plist"
  else
    echo -e "    Start:   sudo systemctl start perfhub"
    echo -e "    Stop:    sudo systemctl stop perfhub"
    echo -e "    Status:  sudo systemctl status perfhub"
    echo -e "    Logs:    sudo journalctl -u perfhub -f"
  fi
  echo ""
  echo -e "  ${YELLOW}To uninstall:${NC} bash ${PERFHUB_DIR}/scripts/uninstall.sh"
  echo ""
}

main() {
  print_banner

  if [ "$(id -u)" -eq 0 ]; then
    log_error "Do not run this script as root. It will use sudo when needed."
    exit 1
  fi

  detect_os
  log_info "Using port: ${PERFHUB_PORT}"

  echo ""
  log_info "Step 1/11: Checking Node.js..."
  install_nodejs

  echo ""
  log_info "Step 2/11: Installing native build dependencies..."
  install_native_deps || {
    log_warn "Native dependency installation encountered an error."
    log_warn "If npm install fails later for canvas or bcrypt, install native build tools manually."
  }

  echo ""
  log_info "Step 3/11: Checking Python..."
  install_python || {
    log_warn "Python setup encountered an error."
    log_warn "Python is optional -- JTL parsing and report generation will not work without it."
  }

  echo ""
  log_info "Step 4/11: Checking PostgreSQL..."
  install_postgresql

  echo ""
  log_info "Step 5/11: Setting up database..."
  setup_database

  echo ""
  log_info "Step 6/11: Applying production environment settings..."
  ensure_production_env

  echo ""
  log_info "Step 7/11: Installing dependencies..."
  install_dependencies

  echo ""
  log_info "Step 8/11: Building application..."
  build_app

  echo ""
  log_info "Step 9/11: Applying database schema..."
  push_schema

  echo ""
  log_info "Step 10/11: Detecting JMeter..."
  detect_jmeter || {
    log_warn "JMeter detection encountered an error."
    log_warn "You can configure JMeter later in Settings > General."
  }

  echo ""
  log_info "Step 11/11: Creating service and starting..."
  create_systemd_service || {
    log_warn "Service setup encountered an error."
    log_warn "You can start PerfHub manually with: node dist/index.cjs"
  }
  start_app || {
    log_warn "PerfHub startup check encountered an error."
    log_warn "Try starting manually: node dist/index.cjs"
  }
  open_browser || true

  print_summary
}

main "$@"
