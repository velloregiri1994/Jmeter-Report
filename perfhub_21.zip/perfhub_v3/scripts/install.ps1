﻿#Requires -RunAsAdministrator
param(
    [int]$Port = 0
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$PERFHUB_DIR = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$NODE_MIN_VERSION = 18
$SERVICE_NAME = "PerfHub"

function Find-FreePort {
    $preferredPorts = @(5000, 3000, 8080, 8000, 9000, 4000, 7000, 6000)
    foreach ($p in $preferredPorts) {
        $inUse = Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue
        if (-not $inUse) {
            return $p
        }
    }
    for ($p = 5001; $p -le 9999; $p++) {
        $inUse = Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue
        if (-not $inUse) {
            return $p
        }
    }
    return 5000
}

if ($Port -eq 0) {
    if ($env:PERFHUB_PORT) {
        $Port = [int]$env:PERFHUB_PORT
    } else {
        $Port = Find-FreePort
    }
}

function Write-Banner {
    Write-Host ""
    Write-Host "  +==================================================+" -ForegroundColor Cyan
    Write-Host "  |                                                  |" -ForegroundColor Cyan
    Write-Host "  |     PerfHub -- Enterprise Performance Platform    |" -ForegroundColor Cyan
    Write-Host "  |                                                  |" -ForegroundColor Cyan
    Write-Host "  +==================================================+" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Step { param([string]$Message) Write-Host "[INFO] $Message" -ForegroundColor Blue }
function Write-Ok { param([string]$Message) Write-Host "[OK] $Message" -ForegroundColor Green }
function Write-Warn { param([string]$Message) Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-Err { param([string]$Message) Write-Host "[ERROR] $Message" -ForegroundColor Red }

function Test-CommandExists {
    param([string]$Command)
    return [bool](Get-Command $Command -ErrorAction SilentlyContinue)
}

function Refresh-EnvironmentPath {
    try {
        if (Test-CommandExists "RefreshEnv") {
            RefreshEnv 2>&1 | Out-Null
        }
    } catch {}
    $machinePath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"
}

function Install-Chocolatey {
    if (-not (Test-CommandExists "choco")) {
        Write-Step "Installing Chocolatey package manager..."
        Set-ExecutionPolicy Bypass -Scope Process -Force
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
        Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
        $env:Path = "$env:ProgramData\chocolatey\bin;$env:Path"
        Write-Ok "Chocolatey installed"
    }
}

function Install-NodeJS {
    if (Test-CommandExists "node") {
        $version = (node -v) -replace 'v', '' -split '\.' | Select-Object -First 1
        if ([int]$version -ge $NODE_MIN_VERSION) {
            Write-Ok "Node.js v$(node -v) is already installed"
            return
        }
        Write-Warn "Node.js v$(node -v) is too old (need v${NODE_MIN_VERSION}+)"
    }

    Write-Step "Installing Node.js v20..."

    if (Test-CommandExists "winget") {
        winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements --silent
    } elseif (Test-CommandExists "choco") {
        choco install nodejs-lts -y
    } else {
        Install-Chocolatey
        choco install nodejs-lts -y
    }

    $nodePaths = @(
        "$env:ProgramFiles\nodejs",
        "${env:ProgramFiles(x86)}\nodejs",
        "$env:LOCALAPPDATA\Programs\nodejs"
    )
    foreach ($p in $nodePaths) {
        if (Test-Path $p) {
            $env:Path = "$p;$env:Path"
            break
        }
    }

    Refresh-EnvironmentPath

    if (Test-CommandExists "node") {
        Write-Ok "Node.js $(node -v) installed successfully"
    } else {
        Write-Err "Failed to install Node.js. Please install Node.js v${NODE_MIN_VERSION}+ manually from https://nodejs.org"
        exit 1
    }
}

function Find-PgBinDir {
    $searchRoots = @(
        "$env:ProgramFiles\PostgreSQL",
        "${env:ProgramFiles(x86)}\PostgreSQL",
        "$env:SystemDrive\PostgreSQL",
        "D:\PostgreSQL",
        "E:\PostgreSQL",
        "$env:ProgramFiles\EnterpriseDB",
        "$env:LOCALAPPDATA\Programs\PostgreSQL"
    )
    foreach ($root in $searchRoots) {
        if (Test-Path $root) {
            $binDirs = Get-ChildItem -Path $root -Recurse -Filter "psql.exe" -ErrorAction SilentlyContinue |
                Select-Object -First 1
            if ($binDirs) {
                return $binDirs.DirectoryName
            }
        }
    }

    $drives = Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | Where-Object { $_.Used -gt 0 }
    foreach ($drive in $drives) {
        $drivePgDirs = @(
            (Join-Path $drive.Root "PostgreSQL"),
            (Join-Path $drive.Root "Program Files\PostgreSQL"),
            (Join-Path $drive.Root "Program Files (x86)\PostgreSQL")
        )
        foreach ($pgDir in $drivePgDirs) {
            if (Test-Path $pgDir) {
                $binDirs = Get-ChildItem -Path $pgDir -Recurse -Filter "psql.exe" -ErrorAction SilentlyContinue |
                    Select-Object -First 1
                if ($binDirs) {
                    return $binDirs.DirectoryName
                }
            }
        }
    }
    return $null
}

function Add-PgToPath {
    if (Test-CommandExists "psql") { return }

    $pgPaths = @(
        "$env:ProgramFiles\PostgreSQL\16\bin",
        "$env:ProgramFiles\PostgreSQL\15\bin",
        "$env:ProgramFiles\PostgreSQL\14\bin",
        "${env:ProgramFiles(x86)}\PostgreSQL\16\bin",
        "${env:ProgramFiles(x86)}\PostgreSQL\15\bin",
        "$env:SystemDrive\PostgreSQL\16\bin",
        "D:\PostgreSQL\16\bin",
        "D:\Program Files\PostgreSQL\16\bin"
    )
    foreach ($p in $pgPaths) {
        if (Test-Path $p) {
            $env:Path = "$p;$env:Path"
            Write-Step "Added PostgreSQL to PATH: $p"
            return
        }
    }

    $found = Find-PgBinDir
    if ($found) {
        $env:Path = "$found;$env:Path"
        Write-Step "Found and added PostgreSQL to PATH: $found"
        return
    }

    Write-Warn "Could not find PostgreSQL bin directory in PATH"
}

function Install-PostgreSQL {
    if (Test-CommandExists "psql") {
        Write-Ok "PostgreSQL is already installed"
        return
    }

    Write-Step "Installing PostgreSQL..."

    $pgSuperPass = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 24 | ForEach-Object { [char]$_ })
    $script:PgInstalledVia = ""

    if (Test-CommandExists "choco") {
        $oldEAP = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
        try {
            choco install postgresql16 --params "/Password:$pgSuperPass" -y 2>&1 | Out-Null
        } finally { $ErrorActionPreference = $oldEAP }
        $script:PgInstalledVia = "choco"
    } elseif (Test-CommandExists "winget") {
        Write-Step "Installing PostgreSQL via winget (this may take 5-10 minutes for the 346 MB download + setup)..."
        Write-Step "The EDB installer will run silently with StackBuilder disabled."
        $overrideArgs = "--mode unattended --superpassword $pgSuperPass --enable-components server,commandlinetools --disable-components stackbuilder"
        $wingetExe = (Get-Command winget -ErrorAction SilentlyContinue).Source
        if (-not $wingetExe) { $wingetExe = "winget" }
        $wingetArgs = "install PostgreSQL.PostgreSQL.16 --accept-package-agreements --accept-source-agreements --override `"$overrideArgs`""
        $timeoutMinutes = 15
        $wingetResult = Start-ProcessWithTimeout -ExePath $wingetExe -Arguments $wingetArgs -WorkingDir $PERFHUB_DIR -TimeoutMs ($timeoutMinutes * 60 * 1000)
        $wingetOutput = "$($wingetResult.Output)$($wingetResult.Error)"
        if ($wingetResult.ExitCode -eq 0 -or "$wingetOutput" -match "Successfully installed|already installed") {
            Write-Ok "PostgreSQL installed via winget"
        } elseif ($wingetResult.ExitCode -eq -1) {
            Write-Warn "PostgreSQL installer timed out after $timeoutMinutes minutes."
            $edbProc = Get-Process -Name "postgresql*" -ErrorAction SilentlyContinue
            $msiProc = Get-Process -Name "msiexec" -ErrorAction SilentlyContinue
            if ($edbProc -or $msiProc) {
                Write-Step "PostgreSQL installer process detected. Waiting up to 10 more minutes..."
                $extraWait = 600
                $elapsed = 0
                while ($elapsed -lt $extraWait) {
                    Start-Sleep -Seconds 10
                    $elapsed += 10
                    $stillRunning = (Get-Process -Name "postgresql*" -ErrorAction SilentlyContinue) -or
                                    (Get-Process -Name "msiexec" -ErrorAction SilentlyContinue)
                    if (-not $stillRunning) {
                        Write-Ok "PostgreSQL installer completed"
                        break
                    }
                    if ($elapsed % 60 -eq 0) {
                        Write-Step "Still waiting... ($([int]($elapsed/60)) min elapsed)"
                    }
                }
            }
        } else {
            Write-Warn "winget finished but output was unexpected. Checking if psql is available..."
        }
        $script:PgInstalledVia = "winget"
    } else {
        Install-Chocolatey
        $oldEAP = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
        try {
            choco install postgresql16 --params "/Password:$pgSuperPass" -y 2>&1 | Out-Null
        } finally { $ErrorActionPreference = $oldEAP }
        $script:PgInstalledVia = "choco"
    }

    $pgSuperPassFile = Join-Path $PERFHUB_DIR ".pg_superpass"
    Set-Content -Path $pgSuperPassFile -Value $pgSuperPass -Encoding UTF8
    try {
        $acl = Get-Acl $pgSuperPassFile
        $acl.SetAccessRuleProtection($true, $false)
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            [System.Security.Principal.WindowsIdentity]::GetCurrent().Name, "FullControl", "Allow")
        $acl.SetAccessRule($rule)
        Set-Acl $pgSuperPassFile $acl
    } catch {
        Write-Warn "Could not restrict permissions on .pg_superpass"
    }

    Refresh-EnvironmentPath

    Add-PgToPath

    Start-Service postgresql* -ErrorAction SilentlyContinue

    Write-Step "Waiting for PostgreSQL to accept connections..."
    $pgReady = $false
    $env:PGPASSWORD = $pgSuperPass
    $env:PGCONNECT_TIMEOUT = "5"
    for ($i = 1; $i -le 30; $i++) {
        $test = Invoke-PgSql -ConnMethod "superpass" -PsqlArgs @("-tAc", "SELECT 1")
        if ("$test".Trim() -eq "1") {
            $pgReady = $true
            break
        }
        Start-Sleep -Seconds 1
    }

    if (-not $pgReady) {
        $env:PGPASSWORD = ""
        for ($i = 1; $i -le 10; $i++) {
            $test = Invoke-PgSql -ConnMethod "postgres" -PsqlArgs @("-tAc", "SELECT 1")
            if ("$test".Trim() -eq "1") {
                $pgReady = $true
                break
            }
            Start-Sleep -Seconds 1
        }
    }

    if (Test-CommandExists "psql") {
        if ($pgReady) {
            Write-Ok "PostgreSQL installed and accepting connections"
        } else {
            Write-Ok "PostgreSQL installed (may need a moment to be ready)"
        }
    } else {
        Write-Err "PostgreSQL installed but psql not found in PATH."
        Write-Err "Searching for psql on this system..."
        $found = Find-PgBinDir
        if ($found) {
            Write-Step "Found psql at: $found"
            Write-Step "Add this to your PATH and re-run the installer."
        } else {
            Write-Err "Could not locate psql. Please install PostgreSQL 14+ manually from https://www.postgresql.org/download/windows/"
        }
        exit 1
    }
}

function Detect-PgPort {
    $env:PGCONNECT_TIMEOUT = "5"
    $env:PGPASSWORD = ""
    $portResult = Invoke-PgSql -ConnMethod "postgres" -PsqlArgs @("-tAc", "SHOW port")
    if ($portResult -and $portResult.Trim() -match '^\d+$') {
        return $portResult.Trim()
    }

    $pgSuperPassFile = Join-Path $PERFHUB_DIR ".pg_superpass"
    if (Test-Path $pgSuperPassFile) {
        $env:PGPASSWORD = (Get-Content $pgSuperPassFile -Raw).Trim()
        $portResult = Invoke-PgSql -ConnMethod "superpass" -PsqlArgs @("-tAc", "SHOW port")
        if ($portResult -and $portResult.Trim() -match '^\d+$') {
            return $portResult.Trim()
        }
    }

    return "5432"
}

function Invoke-PgSql {
    param(
        [string]$ConnMethod,
        [string[]]$PsqlArgs
    )
    $psqlExe = (Get-Command psql -ErrorAction SilentlyContinue).Source
    if (-not $psqlExe) { $psqlExe = "psql" }

    $baseArgs = switch ($ConnMethod) {
        "superpass"   { @("-U", "postgres", "-w") }
        "postgres"    { @("-U", "postgres", "-w") }
        "currentuser" { @("-U", $env:USERNAME, "-w") }
        "default"     { @("-d", "postgres", "-w") }
        "localhost"   { @("-U", "postgres", "-h", "localhost", "-w") }
        default       { @("-U", "postgres", "-w") }
    }
    $allArgs = ($baseArgs + $PsqlArgs) -join " "

    $envVars = @{}
    if ($env:PGPASSWORD) { $envVars["PGPASSWORD"] = $env:PGPASSWORD }
    $envVars["PGCONNECT_TIMEOUT"] = "5"

    $result = Start-ProcessWithTimeout -ExePath $psqlExe -Arguments $allArgs -WorkingDir $PERFHUB_DIR -TimeoutMs 15000 -EnvVars $envVars
    if ($result.ExitCode -eq -1) {
        Write-Warn "psql command timed out"
        return ""
    }
    return "$($result.Output)".Trim()
}

function Setup-Database {
    $dbName = "perfhub"
    $dbUser = "perfhub"
    $dbPass = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 32 | ForEach-Object { [char]$_ })
    $env:PGCONNECT_TIMEOUT = "5"

    Write-Step "Setting up PerfHub database..."

    $envFile = Join-Path $PERFHUB_DIR ".env"
    if (Test-Path $envFile) {
        $content = Get-Content $envFile -Raw
        if ($content -match "DATABASE_URL=(.+)") {
            $testUrl = $matches[1].Trim()
            $env:DATABASE_URL = $testUrl
            $existingOk = $false
            $nodeCheck = Test-DbConnectionNode -DbUrl $testUrl
            if ("$nodeCheck".Trim() -eq "OK") {
                $existingOk = $true
            } else {
                $ip4Check = $testUrl -replace '@localhost:', '@127.0.0.1:'
                if ($ip4Check -ne $testUrl) {
                    $nodeCheck2 = Test-DbConnectionNode -DbUrl $ip4Check
                    if ("$nodeCheck2".Trim() -eq "OK") {
                        $testUrl = $ip4Check
                        $env:DATABASE_URL = $ip4Check
                        $content = $content -replace 'DATABASE_URL=.*', "DATABASE_URL=$ip4Check"
                        Set-Content -Path $envFile -Value $content -Encoding UTF8 -NoNewline
                        $existingOk = $true
                    }
                }
            }
            if ($existingOk) {
                Write-Ok "Using existing database configuration (connection verified)"
                return
            }
            Write-Warn "Existing .env has invalid DATABASE_URL. Re-creating database..."
        }
    }

    $pgSuperPassFile = Join-Path $PERFHUB_DIR ".pg_superpass"
    $pgSuperPassword = $null

    if (Test-Path $pgSuperPassFile) {
        $pgSuperPassword = (Get-Content $pgSuperPassFile -Raw).Trim()
    }

    $connected = $false
    $connMethod = ""

    if ($pgSuperPassword) {
        $env:PGPASSWORD = $pgSuperPassword
        $test = Invoke-PgSql -ConnMethod "superpass" -PsqlArgs @("-tAc", "SELECT 1")
        if ("$test".Trim() -eq "1") {
            $connected = $true
            $connMethod = "superpass"
            Write-Ok "Connected to PostgreSQL (saved credentials)"
        }
    }

    if (-not $connected) {
        Write-Step "Trying additional connection methods..."

        $tryPasswords = @("", "postgres", "password", "admin")
        foreach ($pass in $tryPasswords) {
            $env:PGPASSWORD = $pass
            $test = Invoke-PgSql -ConnMethod "postgres" -PsqlArgs @("-tAc", "SELECT 1")
            if ("$test".Trim() -eq "1") {
                $connected = $true
                $connMethod = "postgres"
                Write-Ok "Connected to PostgreSQL as postgres"
                break
            }
        }

        if (-not $connected) {
            $currentUser = $env:USERNAME
            $env:PGPASSWORD = ""
            $test = Invoke-PgSql -ConnMethod "currentuser" -PsqlArgs @("-tAc", "SELECT 1")
            if ("$test".Trim() -eq "1") {
                $connected = $true
                $connMethod = "currentuser"
                Write-Ok "Connected to PostgreSQL as $currentUser"
            }
        }

        if (-not $connected) {
            $test = Invoke-PgSql -ConnMethod "default" -PsqlArgs @("-tAc", "SELECT 1")
            if ("$test".Trim() -eq "1") {
                $connected = $true
                $connMethod = "default"
                Write-Ok "Connected to PostgreSQL via default connection"
            }
        }

        if (-not $connected) {
            $test = Invoke-PgSql -ConnMethod "localhost" -PsqlArgs @("-tAc", "SELECT 1")
            if ("$test".Trim() -eq "1") {
                $connected = $true
                $connMethod = "localhost"
                Write-Ok "Connected to PostgreSQL via localhost"
            }
        }

        if (-not $connected) {
            Write-Err "Could not connect to PostgreSQL automatically."
            Write-Err "Please ensure PostgreSQL is installed and running, then re-run this installer."
            Write-Err ""
            Write-Err "Quick fix: Start-Service postgresql*"
            exit 1
        }
    }

    try {
        $dbExists = Invoke-PgSql -ConnMethod $connMethod -PsqlArgs @("-tAc", "SELECT 1 FROM pg_database WHERE datname='$dbName'") 2>&1
    } catch {
        $dbExists = ""
    }

    if (-not $dbExists -or $dbExists.Trim() -ne "1") {
        try {
            Invoke-PgSql -ConnMethod $connMethod -PsqlArgs @("-c", "CREATE USER $dbUser WITH PASSWORD '$dbPass';") 2>&1 | Out-Null
        } catch {}
        try {
            Invoke-PgSql -ConnMethod $connMethod -PsqlArgs @("-c", "ALTER USER $dbUser WITH PASSWORD '$dbPass';") 2>&1 | Out-Null
        } catch {}
        try {
            Invoke-PgSql -ConnMethod $connMethod -PsqlArgs @("-c", "CREATE DATABASE $dbName OWNER $dbUser;")
        } catch {
            $recheck = Invoke-PgSql -ConnMethod $connMethod -PsqlArgs @("-tAc", "SELECT 1 FROM pg_database WHERE datname='$dbName'") 2>&1
            if (-not $recheck -or $recheck.Trim() -ne "1") {
                Write-Err "Failed to create database '$dbName'. Check PostgreSQL permissions."
                exit 1
            }
        }
        try {
            Invoke-PgSql -ConnMethod $connMethod -PsqlArgs @("-c", "GRANT ALL PRIVILEGES ON DATABASE $dbName TO $dbUser;")
        } catch {}
        Write-Ok "Database '$dbName' created with user '$dbUser'"
    } else {
        Write-Ok "Database '$dbName' already exists"
        try {
            Invoke-PgSql -ConnMethod $connMethod -PsqlArgs @("-c", "ALTER USER $dbUser WITH PASSWORD '$dbPass';") 2>&1 | Out-Null
        } catch {}
    }

    $pgPort = Detect-PgPort

    $dbUrl = ""
    $tryDbUrls = @(
        "postgresql://${dbUser}:${dbPass}@127.0.0.1:${pgPort}/${dbName}",
        "postgresql://${dbUser}:${dbPass}@localhost:${pgPort}/${dbName}",
        "postgresql://${dbUser}@127.0.0.1:${pgPort}/${dbName}",
        "postgresql://${dbUser}@localhost:${pgPort}/${dbName}"
    )

    foreach ($candidateUrl in $tryDbUrls) {
        $nodeTest = Test-DbConnectionNode -DbUrl $candidateUrl
        if ("$nodeTest".Trim() -eq "OK") {
            $dbUrl = $candidateUrl
            Write-Ok "Database connection verified"
            break
        }
    }

    if (-not $dbUrl) {
        Write-Err "Cannot verify database connection with any method."
        Write-Err "PostgreSQL is running but the perfhub user/database may not be set up correctly."
        Write-Err ""
        Write-Err "Troubleshooting:"
        Write-Err "  1. Check PostgreSQL is running: Get-Service postgresql*"
        Write-Err "  2. Ensure pg_hba.conf allows md5 auth for 127.0.0.1"
        Write-Err "  3. Re-run the installer"
        exit 1
    }

    $sessionSecret = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 64 | ForEach-Object { [char]$_ })

    @"
DATABASE_URL=${dbUrl}
SESSION_SECRET=${sessionSecret}
PORT=${Port}
NODE_ENV=production
"@ | Set-Content -Path $envFile -Encoding UTF8

    try {
        $acl = Get-Acl $envFile
        $acl.SetAccessRuleProtection($true, $false)
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            [System.Security.Principal.WindowsIdentity]::GetCurrent().Name, "FullControl", "Allow")
        $acl.SetAccessRule($rule)
        Set-Acl $envFile $acl
    } catch {
        Write-Warn "Could not restrict permissions on .env"
    }

    $pgSuperPassFile = Join-Path $PERFHUB_DIR ".pg_superpass"
    if (Test-Path $pgSuperPassFile) {
        Remove-Item $pgSuperPassFile -Force -ErrorAction SilentlyContinue
        Write-Step "Removed temporary PostgreSQL credentials file"
    }

    Write-Ok "Environment configuration saved to .env"
}

function Test-PythonWorks {
    param([string]$Cmd)
    $oldErrorPref = $ErrorActionPreference
    $ErrorActionPreference = "SilentlyContinue"
    try {
        $output = & $Cmd --version 2>&1
        if ($LASTEXITCODE -eq 0 -and "$output" -match "Python 3") {
            $ErrorActionPreference = $oldErrorPref
            return $true
        }
    } catch {}
    $ErrorActionPreference = $oldErrorPref
    return $false
}

function Install-Python {
    $pythonCmd = $null
    if ((Test-CommandExists "python3") -and (Test-PythonWorks "python3")) {
        $pythonCmd = "python3"
    } elseif ((Test-CommandExists "python") -and (Test-PythonWorks "python")) {
        $pythonCmd = "python"
    }

    if ($pythonCmd) {
        $version = & $pythonCmd --version 2>&1
        Write-Ok "Python is available ($version)"
    } else {
        Write-Step "Installing Python 3..."
        if (Test-CommandExists "winget") {
            winget install Python.Python.3.11 --accept-package-agreements --accept-source-agreements --silent
        } elseif (Test-CommandExists "choco") {
            choco install python311 -y
        } else {
            Install-Chocolatey
            choco install python311 -y
        }

        $pyPaths = @(
            "$env:LOCALAPPDATA\Programs\Python\Python311",
            "$env:LOCALAPPDATA\Programs\Python\Python311\Scripts",
            "$env:ProgramFiles\Python311",
            "$env:ProgramFiles\Python311\Scripts",
            "$env:LOCALAPPDATA\Programs\Python\Python312",
            "$env:LOCALAPPDATA\Programs\Python\Python312\Scripts"
        )
        foreach ($p in $pyPaths) {
            if (Test-Path $p) {
                $env:Path = "$p;$env:Path"
            }
        }

        Refresh-EnvironmentPath

        if ((Test-CommandExists "python") -and (Test-PythonWorks "python")) {
            $pythonCmd = "python"
            Write-Ok "Python installed successfully"
        } elseif ((Test-CommandExists "python3") -and (Test-PythonWorks "python3")) {
            $pythonCmd = "python3"
            Write-Ok "Python installed successfully"
        } else {
            Write-Warn "Python not found. JTL parsing and report generation will not work."
            Write-Warn "Install Python 3.11+ manually from https://www.python.org/downloads/"
            return
        }
    }

    Write-Step "Installing/upgrading Python packages (numpy, scipy, openpyxl, pyyaml, pandas)..."
    $pipInstalled = $false
    try {
        & $pythonCmd -m pip install --upgrade numpy scipy openpyxl pyyaml pandas
        $pipInstalled = $true
    } catch {}
    if (-not $pipInstalled) {
        try {
            & $pythonCmd -m pip install --upgrade --user numpy scipy openpyxl pyyaml pandas
            $pipInstalled = $true
        } catch {}
    }
    if ($pipInstalled) {
        $pandasVer = & $pythonCmd -c "import pandas; print(pandas.__version__)" 2>&1
        $numpyVer = & $pythonCmd -c "import numpy; print(numpy.__version__)" 2>&1
        Write-Ok "Python packages installed - pandas=$pandasVer, numpy=$numpyVer"
    } else {
        Write-Warn "Could not install Python packages. Install manually: pip3 install --upgrade numpy pandas scipy openpyxl pyyaml"
    }
}

function Ensure-ProductionEnv {
    $envFile = Join-Path $PERFHUB_DIR ".env"
    Write-Step "Applying production-safe settings to .env..."

    if (-not (Test-Path $envFile)) {
        Write-Warn ".env not found -- skipping production env check."
        return
    }

    $content = Get-Content $envFile -Raw

    # NODE_ENV=production
    if ($content -match '(?m)^NODE_ENV=') {
        $content = $content -replace '(?m)^NODE_ENV=.*', 'NODE_ENV=production'
    } else {
        $content += "`r`nNODE_ENV=production"
    }

    # COOKIE_SECURE=false (must be false for direct HTTP installs)
    if ($content -match '(?m)^COOKIE_SECURE=') {
        $content = $content -replace '(?m)^COOKIE_SECURE=.*', 'COOKIE_SECURE=false'
    } else {
        $content += "`r`nCOOKIE_SECURE=false"
    }

    # TRUST_PROXY=false for direct installs without a reverse proxy
    if ($content -match '(?m)^TRUST_PROXY=') {
        $content = $content -replace '(?m)^TRUST_PROXY=.*', 'TRUST_PROXY=false'
    } else {
        $content += "`r`nTRUST_PROXY=false"
    }

    # Replace default dev SESSION_SECRET with a strong random value
    if ($content -match '(?m)^SESSION_SECRET=dev-secret-key-change-in-production') {
        $bytes = New-Object byte[] 32
        [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
        $newSecret = ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
        $content = $content -replace '(?m)^SESSION_SECRET=dev-secret-key-change-in-production', "SESSION_SECRET=$newSecret"
        Write-Step "Generated new SESSION_SECRET (replaced dev default)"
    }

    Set-Content -Path $envFile -Value $content -Encoding UTF8
    Write-Ok "Production settings applied to .env"
}

function Install-NativeBuildTools {
    Write-Step "Checking native build tools (required for canvas and bcrypt)..."

    $hasBuildTools = $false

    $vsWhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    if (Test-Path $vsWhere) {
        $oldEAP = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
        $vsPath = & $vsWhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath 2>&1
        $ErrorActionPreference = $oldEAP
        if ($vsPath -and -not ($vsPath -is [System.Management.Automation.ErrorRecord])) {
            $hasBuildTools = $true
            Write-Ok "Visual Studio C++ build tools already installed"
        }
    }

    if (-not $hasBuildTools) {
        $clExists = Get-Command "cl.exe" -ErrorAction SilentlyContinue
        if ($clExists) {
            $hasBuildTools = $true
            Write-Ok "C++ compiler (cl.exe) found"
        }
    }

    if (-not $hasBuildTools) {
        Write-Step "Installing Visual Studio Build Tools (required for native npm packages)..."
        Write-Step "This may take several minutes..."

        $installed = $false
        $oldEAP = $ErrorActionPreference; $ErrorActionPreference = "Continue"

        if (Test-CommandExists "winget") {
            try {
                winget install Microsoft.VisualStudio.2022.BuildTools `
                    --accept-package-agreements --accept-source-agreements --silent `
                    --override "--quiet --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended" 2>&1 | Out-Null
                if ($LASTEXITCODE -eq 0) {
                    $installed = $true
                    Write-Ok "Visual Studio Build Tools installed via winget"
                }
            } catch {
                Write-Warn "winget install failed, trying Chocolatey..."
            }
        }

        if (-not $installed -and (Test-CommandExists "choco")) {
            try {
                choco install visualstudio2022buildtools -y `
                    --package-parameters "--add Microsoft.VisualStudio.Workload.VCTools --includeRecommended" 2>&1 | Out-Null
                if ($LASTEXITCODE -eq 0) {
                    $installed = $true
                    Write-Ok "Visual Studio Build Tools installed via Chocolatey"
                }
            } catch {
                Write-Warn "Chocolatey install failed"
            }
        }

        if (-not $installed) {
            Install-Chocolatey
            try {
                choco install visualstudio2022buildtools -y `
                    --package-parameters "--add Microsoft.VisualStudio.Workload.VCTools --includeRecommended" 2>&1 | Out-Null
                Write-Ok "Visual Studio Build Tools installed"
            } catch {
                Write-Warn "Could not install Visual Studio Build Tools automatically."
                Write-Warn "If npm install fails for native packages (canvas, bcrypt), install manually:"
                Write-Warn "  https://visualstudio.microsoft.com/visual-cpp-build-tools/"
            }
        }

        $ErrorActionPreference = $oldEAP
        Refresh-EnvironmentPath
    }

    Write-Step "Configuring npm for native builds..."
    $oldEAP = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
    npm config set msvs_version 2022 2>&1 | Out-Null
    $ErrorActionPreference = $oldEAP
    Write-Ok "npm configured for MSVC 2022"
}

function Install-Dependencies {
    Write-Step "Installing application dependencies (including build tools)..."
    Set-Location $PERFHUB_DIR
    $savedNodeEnv = $env:NODE_ENV
    $env:NODE_ENV = "development"
    npm install
    $env:NODE_ENV = $savedNodeEnv
    if ($LASTEXITCODE -ne 0) {
        Write-Err "npm install failed (exit code $LASTEXITCODE)."
        exit 1
    }
    Write-Ok "Dependencies installed"
}

function Build-App {
    Write-Step "Building PerfHub for production..."
    Set-Location $PERFHUB_DIR
    npm run build
    if ($LASTEXITCODE -ne 0) {
        Write-Err "Build failed (exit code $LASTEXITCODE). Check above output for errors."
        exit 1
    }
    Write-Ok "Production build complete"
}

function Backup-Database {
    Set-Location $PERFHUB_DIR

    $envFile = Join-Path $PERFHUB_DIR ".env"
    Get-Content $envFile | ForEach-Object {
        $line = $_.Trim()
        if ($line -and -not $line.StartsWith('#') -and $line -match '^([^=]+)=(.*)$') {
            [System.Environment]::SetEnvironmentVariable($matches[1], $matches[2], "Process")
        }
    }

    $nodeExe = (Get-Command node -ErrorAction SilentlyContinue).Source
    if (-not $nodeExe) { $nodeExe = "node" }
    $countScript = Join-Path $PERFHUB_DIR "_count_tables.cjs"
    @"
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL, connectionTimeoutMillis: 5000 });
pool.query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public'")
  .then(r => { console.log(r.rows[0].count); pool.end(); })
  .catch(() => { console.log('0'); pool.end(); });
setTimeout(() => { console.log('0'); process.exit(0); }, 8000);
"@ | Set-Content -Path $countScript -Encoding UTF8
    $countResult = Start-ProcessWithTimeout -ExePath $nodeExe -Arguments "`"$countScript`"" -WorkingDir $PERFHUB_DIR -TimeoutMs 15000 -EnvVars @{ "DATABASE_URL" = $env:DATABASE_URL }
    Remove-Item $countScript -Force -ErrorAction SilentlyContinue

    $tableCount = 0
    if ("$($countResult.Output)".Trim() -match '^\d+$') {
        $tableCount = [int]"$($countResult.Output)".Trim()
    }

    if ($tableCount -gt 0) {
        $backupDir = Join-Path $PERFHUB_DIR "backups"
        if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }

        $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $backupFile = Join-Path $backupDir "perfhub_backup_$timestamp.sql"

        Write-Step "Backing up existing database before migration..."
        $pgDumpExe = (Get-Command pg_dump -ErrorAction SilentlyContinue).Source
        if ($pgDumpExe) {
            $dumpResult = Start-ProcessWithTimeout -ExePath $pgDumpExe -Arguments "`"$($env:DATABASE_URL)`" --no-owner --no-acl -f `"$backupFile`"" -WorkingDir $PERFHUB_DIR -TimeoutMs 60000
            if ($dumpResult.ExitCode -eq 0 -and (Test-Path $backupFile)) {
                Write-Ok "Database backed up to: $backupFile"
            } else {
                Write-Warn "Database backup failed (pg_dump error or timeout)."
                Write-Warn "Continuing with migration -- no data will be deleted, only additive changes applied."
            }
        } else {
            Write-Warn "pg_dump not found -- skipping backup."
            Write-Warn "Continuing with migration -- no data will be deleted, only additive changes applied."
        }

        $backups = Get-ChildItem $backupDir -Filter "perfhub_backup_*.sql" | Sort-Object LastWriteTime -Descending
        if ($backups.Count -gt 5) {
            $backups | Select-Object -Skip 5 | Remove-Item -Force
        }
    }
}


function Start-ProcessWithTimeout {
    param(
        [string]$ExePath,
        [string]$Arguments,
        [string]$WorkingDir,
        [int]$TimeoutMs = 15000,
        [hashtable]$EnvVars = @{}
    )
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $ExePath
    $psi.Arguments = $Arguments
    $psi.WorkingDirectory = $WorkingDir
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    foreach ($key in $EnvVars.Keys) {
        $psi.EnvironmentVariables[$key] = $EnvVars[$key]
    }
    try {
        $proc = [System.Diagnostics.Process]::Start($psi)
        $stdout = $proc.StandardOutput.ReadToEndAsync()
        $stderr = $proc.StandardError.ReadToEndAsync()
        $exited = $proc.WaitForExit($TimeoutMs)
        if (-not $exited) {
            try { $proc.Kill() } catch {}
            try {
                $killArgs = "/PID $($proc.Id) /T /F"
                Start-Process "taskkill" -ArgumentList $killArgs -NoNewWindow -Wait -ErrorAction SilentlyContinue
            } catch {}
            return @{ Output = ""; Error = "timeout"; ExitCode = -1 }
        }
        [System.Threading.Tasks.Task]::WaitAll(@($stdout, $stderr))
        return @{ Output = $stdout.Result; Error = $stderr.Result; ExitCode = $proc.ExitCode }
    } catch {
        return @{ Output = ""; Error = $_.Exception.Message; ExitCode = -1 }
    }
}

function Test-DbConnectionNode {
    param([string]$DbUrl, [switch]$Verbose)
    $scriptFile = Join-Path $PERFHUB_DIR "_test_db.cjs"
    @"
const { Pool } = require('pg');
const url = process.env.TEST_DATABASE_URL;
if (!url) { console.log('FAIL:no-url'); process.exit(1); }
const pool = new Pool({ connectionString: url, connectionTimeoutMillis: 8000 });
pool.query('SELECT 1')
  .then(() => { console.log('OK'); pool.end(); process.exit(0); })
  .catch(e => { console.log('FAIL:' + (e.code || '') + ':' + e.message); pool.end(); process.exit(1); });
setTimeout(() => { console.log('FAIL:timeout'); process.exit(1); }, 12000);
"@ | Set-Content -Path $scriptFile -Encoding UTF8

    $nodeExe = (Get-Command node -ErrorAction SilentlyContinue).Source
    if (-not $nodeExe) { $nodeExe = "node" }

    $result = Start-ProcessWithTimeout -ExePath $nodeExe -Arguments "`"$scriptFile`"" -WorkingDir $PERFHUB_DIR -TimeoutMs 20000 -EnvVars @{ "TEST_DATABASE_URL" = $DbUrl }
    Remove-Item $scriptFile -Force -ErrorAction SilentlyContinue

    $stdout = "$($result.Output)".Trim()
    $stderr = "$($result.Error)".Trim()
    if ($Verbose -and $stderr) { Write-Warn "  Node stderr: $stderr" }
    if ($stdout -match "^OK") { return "OK" }
    if ($stdout) { return $stdout }
    if ($stderr) { return "FAIL:$stderr" }
    return "FAIL:exit=$($result.ExitCode)"
}

function Push-Schema {
    Write-Step "Setting up database tables..."
    Set-Location $PERFHUB_DIR

    $envFile = Join-Path $PERFHUB_DIR ".env"
    Get-Content $envFile | ForEach-Object {
        $line = $_.Trim()
        if ($line -and -not $line.StartsWith('#') -and $line -match '^([^=]+)=(.*)$') {
            [System.Environment]::SetEnvironmentVariable($matches[1], $matches[2], "Process")
        }
    }

    Write-Step "Verifying database connection before migration..."
    $connResult = Test-DbConnectionNode -DbUrl $env:DATABASE_URL -Verbose
    if ("$connResult".Trim() -eq "OK") {
        Write-Ok "Database connection verified"
    } else {
        Write-Warn "DATABASE_URL connection failed: $connResult"

        $ip4Url = $env:DATABASE_URL -replace '@localhost:', '@127.0.0.1:'
        if ($ip4Url -ne $env:DATABASE_URL) {
            Write-Step "Trying 127.0.0.1 instead of localhost..."
            $connResult2 = Test-DbConnectionNode -DbUrl $ip4Url -Verbose
            if ("$connResult2".Trim() -eq "OK") {
                $env:DATABASE_URL = $ip4Url
                $envContent = Get-Content $envFile -Raw
                $envContent = $envContent -replace 'DATABASE_URL=.*', "DATABASE_URL=$ip4Url"
                Set-Content -Path $envFile -Value $envContent -Encoding UTF8 -NoNewline
                Write-Ok "Database connection verified (using 127.0.0.1)"
            }
        }

        if ("$connResult".Trim() -ne "OK" -and "$connResult2".Trim() -ne "OK") {
            Write-Warn "Attempting to find working credentials..."

            $pgSuperPassFile = Join-Path $PERFHUB_DIR ".pg_superpass"
            $dbName = "perfhub"
            $fixedUrl = $null
            $tryUrls = @()

            $existingPass = ""
            if ($env:DATABASE_URL -match '://[^:]+:([^@]+)@') {
                $existingPass = $matches[1]
            }

            $hosts = @("127.0.0.1", "localhost")
            $ports = @("5432", "5433")

            if ($existingPass) {
                foreach ($h in $hosts) {
                    foreach ($p in $ports) {
                        $tryUrls += "postgresql://perfhub:${existingPass}@${h}:${p}/${dbName}"
                        $tryUrls += "postgresql://postgres:${existingPass}@${h}:${p}/${dbName}"
                    }
                }
            }

            if (Test-Path $pgSuperPassFile) {
                $savedPass = (Get-Content $pgSuperPassFile -Raw).Trim()
                if ($savedPass -ne $existingPass) {
                    foreach ($h in $hosts) {
                        foreach ($p in $ports) {
                            $tryUrls += "postgresql://postgres:${savedPass}@${h}:${p}/${dbName}"
                            $tryUrls += "postgresql://perfhub:${savedPass}@${h}:${p}/${dbName}"
                        }
                    }
                }
            }

            foreach ($h in $hosts) {
                foreach ($p in $ports) {
                    $tryUrls += "postgresql://postgres:postgres@${h}:${p}/${dbName}"
                    $tryUrls += "postgresql://postgres:password@${h}:${p}/${dbName}"
                    $tryUrls += "postgresql://postgres@${h}:${p}/${dbName}"
                }
            }

            foreach ($url in $tryUrls) {
                $masked = $url -replace ':([^:@/]+)@', ':***@'
                Write-Step "  Trying: $masked..."
                $testResult = Test-DbConnectionNode -DbUrl $url
                if ("$testResult".Trim() -eq "OK") {
                    $fixedUrl = $url
                    Write-Ok "Connected successfully"
                    break
                } else {
                    $shortErr = "$testResult" -replace '(?s)^FAIL:', ''
                    if ($shortErr.Length -gt 80) { $shortErr = $shortErr.Substring(0, 80) + "..." }
                    Write-Warn "  Failed: $shortErr"
                }
            }

            if ($fixedUrl) {
                $env:DATABASE_URL = $fixedUrl
                $envContent = Get-Content $envFile -Raw
                $envContent = $envContent -replace 'DATABASE_URL=.*', "DATABASE_URL=$fixedUrl"
                Set-Content -Path $envFile -Value $envContent -Encoding UTF8 -NoNewline
                Write-Ok "Updated DATABASE_URL in .env"
            } else {
                Write-Err "Cannot connect to database. PostgreSQL may not be running."
                Write-Err "DATABASE_URL in .env: $($env:DATABASE_URL)"
                Write-Err ""
                Write-Err "Troubleshooting:"
                Write-Err "  1. Check PostgreSQL is running: Get-Service postgresql*"
                Write-Err "  2. Start it if stopped: Start-Service postgresql*"
                Write-Err "  3. Re-run the installer"
                exit 1
            }
        }
    }

    Backup-Database

    Write-Step "Running database migrations..."
    $cmdExe = "$env:SystemRoot\System32\cmd.exe"
    $migrateResult = Start-ProcessWithTimeout -ExePath $cmdExe -Arguments "/d /s /c `"npm run db:migrate`"" -WorkingDir $PERFHUB_DIR -TimeoutMs 120000 -EnvVars @{ "DATABASE_URL" = $env:DATABASE_URL }

    $migrateOutput = "$($migrateResult.Output)$($migrateResult.Error)"
    if ($migrateOutput.Trim()) {
        Write-Host $migrateOutput
    }

    if ($migrateResult.ExitCode -eq -1) {
        Write-Err "Database migration timed out after 2 minutes."
        Write-Err "Check DATABASE_URL in .env and ensure PostgreSQL is running."
        exit 1
    }

    if ($migrateResult.ExitCode -ne 0 -or ("$migrateOutput" -match "Migration failed|ECONNREFUSED")) {
        Write-Err "Database migration failed (exit code $($migrateResult.ExitCode))."
        Write-Err "Check your DATABASE_URL in .env and ensure PostgreSQL is running."
        Write-Err "If upgrading, a backup was saved in the 'backups' folder."
        exit 1
    }
    Write-Ok "Database schema applied (migrations)"
}

function Detect-JMeter {
    Write-Step "Scanning for JMeter installations..."

    $jmeterHome = $null

    if ($env:JMETER_HOME -and (Test-Path (Join-Path $env:JMETER_HOME "bin\jmeter.bat"))) {
        $jmeterHome = $env:JMETER_HOME
        Write-Ok "Found JMeter via JMETER_HOME: $jmeterHome"
    }

    if (-not $jmeterHome) {
        $jmeterBin = Get-Command "jmeter" -ErrorAction SilentlyContinue
        if ($jmeterBin) {
            $binDir = Split-Path $jmeterBin.Source -Parent
            $jmeterHome = Split-Path $binDir -Parent
            Write-Ok "Found JMeter on PATH: $jmeterHome"
        }
    }

    if (-not $jmeterHome) {
        $searchPaths = @(
            "C:\apache-jmeter-*",
            "C:\Program Files\apache-jmeter-*",
            "C:\Program Files\JMeter*",
            "C:\tools\apache-jmeter-*",
            "$env:USERPROFILE\apache-jmeter-*"
        )
        foreach ($pattern in $searchPaths) {
            $foundItems = Get-Item $pattern -ErrorAction SilentlyContinue
            foreach ($match in $foundItems) {
                $batFile = Join-Path $match.FullName "bin\jmeter.bat"
                if (Test-Path $batFile) {
                    $jmeterHome = $match.FullName
                    Write-Ok "Found JMeter at: $jmeterHome"
                    break
                }
            }
            if ($jmeterHome) { break }
        }
    }

    if ($jmeterHome) {
        $oldEAP = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
        try {
            $versionOutput = & (Join-Path $jmeterHome "bin\jmeter.bat") --version 2>&1 | Out-String
            if ($versionOutput -match '(\d+\.\d+(\.\d+)?)') {
                Write-Ok "JMeter version: $($Matches[1])"
            }
        } catch {}
        $ErrorActionPreference = $oldEAP

        $configFile = Join-Path $PERFHUB_DIR "config.json"
        $config = @{}
        if (Test-Path $configFile) {
            try {
                $raw = Get-Content $configFile -Raw | ConvertFrom-Json
                $config = @{}
                $raw.PSObject.Properties | ForEach-Object {
                    if ($_.Value -is [PSCustomObject]) {
                        $nested = @{}
                        $_.Value.PSObject.Properties | ForEach-Object { $nested[$_.Name] = $_.Value }
                        $config[$_.Name] = $nested
                    } else {
                        $config[$_.Name] = $_.Value
                    }
                }
            } catch {
                $config = @{}
            }
        }
        if (-not $config.ContainsKey("jmeter")) {
            $config["jmeter"] = @{}
        }
        $config["jmeter"]["home"] = $jmeterHome
        $config | ConvertTo-Json -Depth 5 | Set-Content $configFile -Encoding UTF8
        Write-Ok "JMeter path saved to config.json"
    } else {
        Write-Warn "JMeter not found. You can configure it later in Settings > General."
        Write-Step "Install JMeter: https://jmeter.apache.org/download_jmeter.cgi"
    }
}

function Stop-ExistingPerfHub {
    # Stop Scheduled Task if it exists
    $oldEAP = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
    try {
        $task = Get-ScheduledTask -TaskName "PerfHub" -ErrorAction SilentlyContinue
        if ($task -and $task.State -eq "Running") {
            Write-Step "Stopping PerfHub scheduled task..."
            Stop-ScheduledTask -TaskName "PerfHub" -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 2
        }
    } catch {}

    # Stop NSSM service if it exists (legacy installs)
    if (Test-CommandExists "nssm") {
        try {
            $status = nssm status $SERVICE_NAME 2>&1
            if ($status -and "$status" -ne "SERVICE_STOPPED" -and -not ($status -is [System.Management.Automation.ErrorRecord])) {
                Write-Step "Stopping existing PerfHub service..."
                nssm stop $SERVICE_NAME 2>&1 | Out-Null
                Start-Sleep -Seconds 2
            }
        } catch {}
    }
    $ErrorActionPreference = $oldEAP

    # Kill by saved PID (process tree kill)
    $pidFile = Join-Path $PERFHUB_DIR ".perfhub.pid"
    if (Test-Path $pidFile) {
        $oldPid = (Get-Content $pidFile -Raw).Trim()
        if ($oldPid -match '^\d+$') {
            try {
                $proc = Get-Process -Id ([int]$oldPid) -ErrorAction SilentlyContinue
                if ($proc) {
                    Write-Step "Stopping previous PerfHub instance (PID: $oldPid)..."
                    $killResult = Start-ProcessWithTimeout -ExePath "taskkill" -Arguments "/T /F /PID $oldPid" -WorkingDir $PERFHUB_DIR -TimeoutMs 10000
                    Start-Sleep -Seconds 2
                }
            } catch {}
        }
        Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
    }
}

function Ensure-PortFree {
    $inUse = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    if ($inUse) {
        Write-Warn "Port $Port is in use. Attempting to free it..."
        foreach ($conn in $inUse) {
            try {
                Stop-Process -Id $conn.OwningProcess -Force -ErrorAction SilentlyContinue
            } catch {}
        }
        Start-Sleep -Seconds 2

        $stillInUse = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
        if ($stillInUse) {
            Write-Warn "Port $Port is still in use. Finding a free port..."
            $script:Port = Find-FreePort
            Write-Step "Using port $Port instead"

            $envFile = Join-Path $PERFHUB_DIR ".env"
            if (Test-Path $envFile) {
                $content = Get-Content $envFile -Raw
                $content = $content -replace 'PORT=\d+', "PORT=$Port"
                Set-Content -Path $envFile -Value $content -Encoding UTF8
                Write-Ok "Updated .env with port $Port"
            }
        }
    }
}

function Install-WindowsService {
    Write-Step "Setting up PerfHub as a Windows service..."

    $nodePath = (Get-Command node).Source
    $serviceScript = Join-Path (Join-Path $PERFHUB_DIR "scripts") "perfhub-service.cjs"

    @"
const { execSync, spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const appDir = path.resolve(__dirname, '..');
const envFile = path.join(appDir, '.env');

if (fs.existsSync(envFile)) {
  const lines = fs.readFileSync(envFile, 'utf8').split('\n');
  for (const line of lines) {
    const match = line.match(/^([^=]+)=(.*)$/);
    if (match) process.env[match[1]] = match[2];
  }
}

process.chdir(appDir);
const child = spawn(process.execPath, ['dist/index.cjs'], {
  cwd: appDir,
  stdio: 'inherit',
  env: process.env
});
child.on('exit', (code) => process.exit(code || 0));
"@ | Set-Content -Path $serviceScript -Encoding UTF8

    # Create start-perfhub.bat for manual starts
    $startupScript = Join-Path $PERFHUB_DIR "start-perfhub.bat"
    @"
@echo off
title PerfHub Server
cd /d "$PERFHUB_DIR"
"$nodePath" "$serviceScript"
if errorlevel 1 (
    echo PerfHub exited with an error. Check logs\perfhub-error.log for details.
    timeout /t 10
)
"@ | Set-Content -Path $startupScript -Encoding ASCII
    Write-Ok "Manual start script created: $startupScript"

    # Register a Windows Scheduled Task to auto-start PerfHub on user login
    # This works without admin rights and without NSSM
    $taskName = "PerfHub"
    try {
        $oldEAP = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false 2>&1 | Out-Null
        $ErrorActionPreference = $oldEAP

        $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        $action = New-ScheduledTaskAction -Execute $nodePath -Argument "`"$serviceScript`"" -WorkingDirectory $PERFHUB_DIR
        $trigger = New-ScheduledTaskTrigger -AtLogon -User $currentUser
        $principal = New-ScheduledTaskPrincipal -UserId $currentUser -LogonType Interactive -RunLevel Limited
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval ([TimeSpan]::FromMinutes(1))

        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description "PerfHub - Enterprise Performance Testing Platform" -Force | Out-Null

        $registeredTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
        if ($registeredTask) {
            Write-Ok "Scheduled Task '$taskName' registered for $currentUser (auto-starts on login)"
        } else {
            throw "Task registration succeeded but task not found afterward"
        }
    } catch {
        Write-Warn "Could not create Scheduled Task: $($_.Exception.Message)"
        Write-Warn "PerfHub will NOT auto-start after reboot."
        Write-Warn "Start manually with: $startupScript"

        # Fallback: copy bat to Startup folder
        try {
            $startupFolder = [System.IO.Path]::Combine($env:APPDATA, "Microsoft\Windows\Start Menu\Programs\Startup")
            Copy-Item $startupScript (Join-Path $startupFolder "start-perfhub.bat") -Force
            Write-Ok "Startup folder shortcut created as fallback"
        } catch {
            Write-Warn "Startup folder fallback also failed: $($_.Exception.Message)"
        }
    }

    New-Item -ItemType Directory -Path (Join-Path $PERFHUB_DIR "logs") -Force | Out-Null
}

function Start-PerfHub {
    Write-Step "Starting PerfHub..."

    Stop-ExistingPerfHub
    Ensure-PortFree

    $logsDir = Join-Path $PERFHUB_DIR "logs"
    New-Item -ItemType Directory -Path $logsDir -Force | Out-Null
    $logFile = Join-Path $logsDir "perfhub.log"
    $errFile = Join-Path $logsDir "perfhub-error.log"

    $nodeExe = (Get-Command node -ErrorAction SilentlyContinue).Source
    if (-not $nodeExe) { $nodeExe = "node" }
    $serviceScript = Join-Path (Join-Path $PERFHUB_DIR "scripts") "perfhub-service.cjs"

    $launched = $false
    $launchMethod = ""

    # Use .NET ProcessStartInfo — avoids all PowerShell path-splitting bugs
    # with Start-Process -RedirectStandardOutput on paths containing spaces
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $nodeExe
        $psi.Arguments = "`"$serviceScript`""
        $psi.WorkingDirectory = $PERFHUB_DIR
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $false
        $psi.RedirectStandardError = $false

        # Inject .env variables into the process environment
        $dotEnv = Join-Path $PERFHUB_DIR ".env"
        if (Test-Path $dotEnv) {
            Get-Content $dotEnv | ForEach-Object {
                $line = $_.Trim()
                if ($line -and -not $line.StartsWith('#') -and $line -match '^([^=]+)=(.*)$') {
                    $psi.EnvironmentVariables[$matches[1]] = $matches[2]
                }
            }
        }

        $proc = [System.Diagnostics.Process]::Start($psi)
        if ($proc -and -not $proc.HasExited) {
            $proc.Id | Set-Content -Path (Join-Path $PERFHUB_DIR ".perfhub.pid") -Encoding UTF8
            $launched = $true
            $launchMethod = "Process"
        }
    } catch {
        Write-Warn "Process start failed: $($_.Exception.Message)"
    }

    # Fallback: Scheduled Task (runs as current user, survives PS exit)
    if (-not $launched) {
        try {
            $taskName = "PerfHubStartup"
            $oldEAP = $ErrorActionPreference; $ErrorActionPreference = "SilentlyContinue"
            Unregister-ScheduledTask -TaskName $taskName -Confirm:$false 2>&1 | Out-Null
            $ErrorActionPreference = $oldEAP

            $action = New-ScheduledTaskAction -Execute "`"$nodeExe`"" -Argument "`"$serviceScript`"" -WorkingDirectory "`"$PERFHUB_DIR`""
            $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(2)
            $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero)
            Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Force | Out-Null
            Start-ScheduledTask -TaskName $taskName
            $launched = $true
            $launchMethod = "ScheduledTask"
        } catch {
            Write-Warn "Scheduled Task launch failed: $($_.Exception.Message)"
        }
    }

    if (-not $launched) {
        Write-Err "Could not start PerfHub automatically."
        Write-Err "Start it manually by running:"
        Write-Err "  cd `"$PERFHUB_DIR`""
        Write-Err "  node scripts\perfhub-service.cjs"
        return
    }

    Write-Step "Waiting for PerfHub to be ready ($launchMethod)..."
    $directStarted = $false
    for ($i = 1; $i -le 20; $i++) {
        try {
            $resp = Invoke-WebRequest -Uri "http://localhost:$Port" -UseBasicParsing -TimeoutSec 3 -ErrorAction Stop
            $directStarted = $true; break
        } catch {
            if ($_.Exception.Response) { $directStarted = $true; break }
        }

        if ($i -eq 5 -and (Test-Path $errFile)) {
            $earlyErr = Get-Content $errFile -Raw -ErrorAction SilentlyContinue
            if ($earlyErr -and $earlyErr.Trim()) {
                Write-Warn "Early error output detected:"
                Write-Host $earlyErr.Trim()
            }
        }
        Start-Sleep -Seconds 2
    }

    if ($directStarted) {
        Write-Ok "PerfHub is running at http://localhost:$Port"
    } else {
        Write-Err "PerfHub did not respond within 40 seconds."
        if (Test-Path $errFile) {
            $errContent = Get-Content $errFile -Raw -ErrorAction SilentlyContinue
            if ($errContent -and $errContent.Trim()) {
                Write-Err "Error log:"
                Write-Host $errContent.Trim()
            }
        }
        if (Test-Path $logFile) {
            $logContent = Get-Content $logFile -Raw -ErrorAction SilentlyContinue
            if ($logContent -and $logContent.Trim()) {
                Write-Step "Output log:"
                Write-Host $logContent.Trim()
            }
        }
        Write-Err ""
        Write-Err "Try starting manually:"
        Write-Err "  cd `"$PERFHUB_DIR`""
        Write-Err "  node scripts\perfhub-service.cjs"
    }
}

function Open-Browser {
    Write-Step "Opening PerfHub in your browser..."
    Start-Process "http://localhost:$Port"
}

function Write-Summary {
    Write-Host ""
    Write-Host "  +==================================================+" -ForegroundColor Green
    Write-Host "  |         PerfHub installed successfully!          |" -ForegroundColor Green
    Write-Host "  +==================================================+" -ForegroundColor Green
    Write-Host ""
    Write-Host "  URL:      http://localhost:$Port" -ForegroundColor White
    Write-Host "  Config:   $PERFHUB_DIR\.env" -ForegroundColor White
    Write-Host ""
    Write-Host "  Auto-start: PerfHub starts automatically when you log in" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Commands:" -ForegroundColor Yellow
    Write-Host "    Start:   $PERFHUB_DIR\start-perfhub.bat"
    Write-Host "    Stop:    taskkill /IM node.exe /F"
    Write-Host "    Logs:    Get-Content `"$PERFHUB_DIR\logs\perfhub.log`" -Tail 50"
    Write-Host ""
    Write-Host "  To uninstall: PowerShell -File $PERFHUB_DIR\scripts\uninstall.ps1" -ForegroundColor Yellow
    Write-Host ""
}

Write-Banner

Write-Host ""
Write-Step "Step 1/11: Checking Node.js..."
Install-NodeJS

Write-Host ""
Write-Step "Step 2/11: Installing native build tools (canvas, bcrypt)..."
try {
    Install-NativeBuildTools
} catch {
    Write-Warn "Native build tools setup encountered an error: $($_.Exception.Message)"
    Write-Warn "If npm install fails later for canvas or bcrypt, install Visual Studio Build Tools manually:"
    Write-Warn "  https://visualstudio.microsoft.com/visual-cpp-build-tools/"
}

Write-Host ""
Write-Step "Step 3/11: Checking Python..."
try {
    Install-Python
} catch {
    Write-Warn "Python setup encountered an error: $($_.Exception.Message)"
    Write-Warn "Python is optional -- JTL parsing and report generation will not work without it."
    Write-Warn "Install Python 3.11+ manually from https://www.python.org/downloads/"
}

Write-Host ""
Write-Step "Step 4/11: Checking PostgreSQL..."
Install-PostgreSQL

Write-Host ""
Write-Step "Step 5/11: Setting up database..."
Setup-Database

Write-Host ""
Write-Step "Step 6/11: Applying production environment settings..."
Ensure-ProductionEnv

Write-Host ""
Write-Step "Step 7/11: Installing dependencies..."
Install-Dependencies

Write-Host ""
Write-Step "Step 8/11: Building application..."
Build-App

Write-Host ""
Write-Step "Step 9/11: Applying database schema..."
Push-Schema

Write-Host ""
Write-Step "Step 10/11: Detecting JMeter..."
try {
    Detect-JMeter
} catch {
    Write-Warn "JMeter detection encountered an error: $($_.Exception.Message)"
    Write-Warn "You can configure JMeter later in Settings > General."
}

Write-Host ""
Write-Step "Step 11/11: Creating service and starting..."
try {
    Install-WindowsService
} catch {
    Write-Warn "Windows service setup encountered an error: $($_.Exception.Message)"
    Write-Warn "You can start PerfHub manually with: node dist/index.cjs"
}
try {
    Start-PerfHub
} catch {
    Write-Warn "PerfHub startup check encountered an error: $($_.Exception.Message)"
    Write-Warn "Try starting manually: node dist/index.cjs"
}
try {
    Open-Browser
} catch {}

Write-Summary
