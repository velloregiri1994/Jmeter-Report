import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

const devPort = parseInt(process.env.PORT || "5000", 10);
const devHost = process.env.HOST || "127.0.0.1";

export default defineConfig({
  plugins: [
    react(),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
    },
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor-react': ['react', 'react-dom', 'wouter'],
          'vendor-recharts': ['recharts'],
          'vendor-radix': [
            '@radix-ui/react-dialog',
            '@radix-ui/react-dropdown-menu',
            '@radix-ui/react-select',
            '@radix-ui/react-slider',
            '@radix-ui/react-tabs',
            '@radix-ui/react-tooltip',
            '@radix-ui/react-accordion',
            '@radix-ui/react-alert-dialog',
            '@radix-ui/react-popover',
          ],
          'vendor-utils': ['date-fns', 'zod', 'clsx', 'tailwind-merge'],
        },
      },
    },
  },
  optimizeDeps: {
    include: [
      '@radix-ui/react-slider',
    ],
  },
  server: {
    allowedHosts: true,
    hmr: {
      path: "/vite-hmr",
      port: devPort,
      clientPort: devPort,
      host: devHost,
    },
    fs: {
      strict: false,
      deny: ["**/.*"],
    },
  },
});
