import { db } from "./db";
import {
  testCompletionReports,
  type InsertTestCompletionReport,
  type TestCompletionReport,
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export async function getCompletionReports(): Promise<TestCompletionReport[]> {
  return await db
    .select()
    .from(testCompletionReports)
    .orderBy(desc(testCompletionReports.createdAt));
}

export async function getCompletionReport(id: number): Promise<TestCompletionReport | undefined> {
  const results = await db
    .select()
    .from(testCompletionReports)
    .where(eq(testCompletionReports.id, id));
  return results[0];
}

export async function createCompletionReport(data: InsertTestCompletionReport): Promise<TestCompletionReport> {
  const results = await db
    .insert(testCompletionReports)
    .values(data)
    .returning();
  return results[0];
}

export async function updateCompletionReport(
  id: number,
  data: Partial<InsertTestCompletionReport>
): Promise<TestCompletionReport | undefined> {
  const results = await db
    .update(testCompletionReports)
    .set({ ...data, updatedAt: new Date().toISOString() })
    .where(eq(testCompletionReports.id, id))
    .returning();
  return results[0];
}

export async function deleteCompletionReport(id: number): Promise<boolean> {
  const results = await db
    .delete(testCompletionReports)
    .where(eq(testCompletionReports.id, id))
    .returning();
  return results.length > 0;
}
