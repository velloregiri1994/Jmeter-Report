import "dotenv/config";
import path from "path";
import fs from "fs";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import { db, pool } from "./db";
import { logger } from "./logger";

const BASELINE_REQUIRED_TABLES = [
  "users", "scripts", "test_executions", "test_schedules", "notifications",
  "api_tokens", "audit_logs", "baseline_executions"
];

async function markBaselineMigrationIfNeeded(): Promise<void> {
  const drizzleTableExists = await pool.query(`
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'drizzle' AND table_name = '__drizzle_migrations'
  `);

  if (drizzleTableExists.rows.length > 0) {
    const existing = await pool.query(`SELECT id FROM drizzle."__drizzle_migrations" LIMIT 1`);
    if (existing.rows.length > 0) {
      return;
    }
  }

  const result = await pool.query(`
    SELECT table_name FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name = ANY($1)
  `, [BASELINE_REQUIRED_TABLES]);

  const existingTables = new Set(result.rows.map((r: any) => r.table_name));

  if (existingTables.size === 0) {
    return;
  }

  const missingTables = BASELINE_REQUIRED_TABLES.filter(t => !existingTables.has(t));
  if (missingTables.length > 0) {
    throw new Error(
      `Database is partially initialized — missing tables: ${missingTables.join(", ")}. ` +
      `Cannot safely mark baseline migration as applied. ` +
      `Resolve manually or restore from backup.`
    );
  }

  logger.info("Existing database detected (installed via push). Marking baseline migration as applied...", "database");

  await pool.query(`CREATE SCHEMA IF NOT EXISTS drizzle`);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS drizzle."__drizzle_migrations" (
      id serial PRIMARY KEY,
      hash text NOT NULL,
      created_at bigint
    )
  `);

  const journalPath = path.resolve(process.cwd(), "migrations", "meta", "_journal.json");
  const journal = JSON.parse(fs.readFileSync(journalPath, "utf-8"));
  const baselineEntry = journal.entries.find((e: any) => e.tag === "0000_magenta_slyde");
  if (!baselineEntry) {
    throw new Error("Baseline migration entry not found in _journal.json");
  }

  const crypto = await import("crypto");
  const migrationFile = path.resolve(process.cwd(), "migrations", "0000_magenta_slyde.sql");
  const content = fs.readFileSync(migrationFile, "utf-8");
  const hash = crypto.createHash("sha256").update(content).digest("hex");

  const already = await pool.query(`SELECT 1 FROM drizzle."__drizzle_migrations" WHERE hash = $1`, [hash]);
  if (already.rows.length === 0) {
    await pool.query(
      `INSERT INTO drizzle."__drizzle_migrations" (hash, created_at) VALUES ($1, $2)`,
      [hash, baselineEntry.when]
    );
    logger.info("Baseline migration (0000) marked as applied — existing data preserved.", "database");
  }
}

export async function runMigrations(): Promise<void> {
  const migrationsFolder = path.resolve(process.cwd(), "migrations");

  await markBaselineMigrationIfNeeded();

  const result = await pool.query(`
    SELECT table_name FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name = ANY($1)
  `, [["users", "scripts", "test_executions"]]);

  const isFirstInstall = result.rows.length === 0;

  if (isFirstInstall) {
    logger.info("Fresh database detected. Running initial migrations...", "database");
  } else {
    logger.info("Applying pending migrations (existing data preserved)...", "database");
  }

  await migrate(db, { migrationsFolder });

  logger.info("Database migrations completed successfully.", "database");
}

const isDirectRun = process.argv[1]?.endsWith("migrate.ts") || process.argv[1]?.endsWith("migrate.js");
if (isDirectRun) {
  runMigrations()
    .then(() => {
      console.log("Migrations complete.");
      process.exit(0);
    })
    .catch((err) => {
      console.error("Migration failed:", err);
      process.exit(1);
    });
}
