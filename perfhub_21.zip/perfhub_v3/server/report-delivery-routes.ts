import { Express, Request, Response } from "express";
import { db } from "./db";
import { reportDeliverySchedules } from "@shared/schema";
import { eq, desc, and } from "drizzle-orm";
import { startReportDeliveryScheduler } from "./report-delivery-scheduler";
import { validate, z, idParam } from "./validation";
import { asyncHandler } from "./error-handler";
import { requireAuth, requireNonViewer } from "./route-middleware";

const VALID_TIMEZONES = new Set([
  "UTC", "America/New_York", "America/Chicago", "America/Denver", "America/Los_Angeles",
  "Europe/London", "Europe/Paris", "Europe/Berlin", "Asia/Tokyo", "Asia/Shanghai",
  "Asia/Kolkata", "Asia/Singapore", "Australia/Sydney", "Pacific/Auckland",
]);

const createScheduleBody = z.object({
  name: z.string().min(1, "Name is required").transform(s => s.trim()),
  recipients: z.array(z.string().email()).min(1, "At least one recipient email is required"),
  frequency: z.enum(["daily", "weekly", "monthly"]).optional(),
  dayOfWeek: z.number().int().min(0).max(6).optional().nullable(),
  dayOfMonth: z.number().int().min(1).max(28).optional().nullable(),
  timeOfDay: z.string().regex(/^\d{2}:\d{2}$/, "timeOfDay must be in HH:MM format").optional(),
  timezone: z.string().refine(tz => VALID_TIMEZONES.has(tz), "Invalid timezone").optional(),
  filters: z.any().optional().nullable(),
  includeAttachments: z.boolean().optional(),
  enabled: z.boolean().optional(),
});

const updateScheduleBody = createScheduleBody.partial();

function getUserId(req: Request): number {
  return (req.session as any).user.id;
}

export function registerReportDeliveryRoutes(app: Express) {
  startReportDeliveryScheduler();

  app.get("/api/report-delivery-schedules", requireAuth, asyncHandler(async (req, res) => {
    const userId = getUserId(req);
    const schedules = await db.select().from(reportDeliverySchedules)
      .where(eq(reportDeliverySchedules.createdBy, userId))
      .orderBy(desc(reportDeliverySchedules.createdAt));
    res.json(schedules);
  }));

  app.post("/api/report-delivery-schedules", requireNonViewer, validate({ body: createScheduleBody }), asyncHandler(async (req, res) => {
    const { name, recipients, frequency, dayOfWeek, dayOfMonth, timeOfDay, timezone, filters, includeAttachments, enabled } = req.body;
    const nextRunAt = computeNextRun(frequency, timeOfDay || "09:00", timezone || "UTC", dayOfWeek, dayOfMonth);

    const [schedule] = await db.insert(reportDeliverySchedules).values({
      name: name.trim(),
      enabled: enabled !== false,
      recipients,
      frequency,
      dayOfWeek: dayOfWeek ?? null,
      dayOfMonth: dayOfMonth ?? null,
      timeOfDay: timeOfDay || "09:00",
      timezone: timezone || "UTC",
      filters: filters || null,
      includeAttachments: includeAttachments || false,
      nextRunAt: nextRunAt.toISOString(),
      createdBy: getUserId(req),
    }).returning();

    res.status(201).json(schedule);
  }));

  app.patch("/api/report-delivery-schedules/:id", requireNonViewer, validate({ params: idParam, body: updateScheduleBody }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;

    const userId = getUserId(req);
    const existing = await db.select().from(reportDeliverySchedules)
      .where(and(eq(reportDeliverySchedules.id, id), eq(reportDeliverySchedules.createdBy, userId)))
      .limit(1);
    if (existing.length === 0) return res.status(404).json({ message: "Schedule not found" });

    const updates: any = { updatedAt: new Date().toISOString() };
    const fields = ["name", "enabled", "recipients", "frequency", "dayOfWeek", "dayOfMonth", "timeOfDay", "timezone", "filters", "includeAttachments"];
    for (const field of fields) {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    }

    const freq = updates.frequency || existing[0].frequency;
    const tod = updates.timeOfDay || existing[0].timeOfDay;
    const tz = updates.timezone || existing[0].timezone;
    const dow = updates.dayOfWeek !== undefined ? updates.dayOfWeek : existing[0].dayOfWeek;
    const dom = updates.dayOfMonth !== undefined ? updates.dayOfMonth : existing[0].dayOfMonth;
    updates.nextRunAt = computeNextRun(freq, tod, tz, dow, dom).toISOString();

    const [updated] = await db.update(reportDeliverySchedules)
      .set(updates)
      .where(and(eq(reportDeliverySchedules.id, id), eq(reportDeliverySchedules.createdBy, userId)))
      .returning();

    res.json(updated);
  }));

  app.delete("/api/report-delivery-schedules/:id", requireNonViewer, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;

    const userId = getUserId(req);
    const existing = await db.select().from(reportDeliverySchedules)
      .where(and(eq(reportDeliverySchedules.id, id), eq(reportDeliverySchedules.createdBy, userId)))
      .limit(1);
    if (existing.length === 0) return res.status(404).json({ message: "Schedule not found" });

    await db.delete(reportDeliverySchedules)
      .where(and(eq(reportDeliverySchedules.id, id), eq(reportDeliverySchedules.createdBy, userId)));
    res.json({ message: "Deleted" });
  }));
}

export function computeNextRun(frequency: string, timeOfDay: string, timezone: string, dayOfWeek?: number | null, dayOfMonth?: number | null): Date {
  const [hours, minutes] = (timeOfDay || "09:00").split(":").map(Number);
  const now = new Date();

  let next = new Date(now);
  next.setUTCHours(hours, minutes, 0, 0);

  try {
    const offsetMs = getTimezoneOffsetMs(timezone);
    next = new Date(next.getTime() - offsetMs);
  } catch {}

  if (next <= now) {
    if (frequency === "daily") {
      next.setDate(next.getDate() + 1);
    } else if (frequency === "weekly") {
      next.setDate(next.getDate() + 7);
    } else if (frequency === "monthly") {
      next.setMonth(next.getMonth() + 1);
    }
  }

  if (frequency === "weekly" && dayOfWeek != null) {
    const currentDay = next.getDay();
    const diff = ((dayOfWeek - currentDay) + 7) % 7;
    if (diff > 0) next.setDate(next.getDate() + diff);
    else if (diff === 0 && next <= now) next.setDate(next.getDate() + 7);
  }

  if (frequency === "monthly" && dayOfMonth != null) {
    next.setDate(Math.min(dayOfMonth, 28));
    if (next <= now) next.setMonth(next.getMonth() + 1);
  }

  return next;
}

function getTimezoneOffsetMs(tz: string): number {
  try {
    const now = new Date();
    const utcStr = now.toLocaleString("en-US", { timeZone: "UTC" });
    const tzStr = now.toLocaleString("en-US", { timeZone: tz });
    return new Date(tzStr).getTime() - new Date(utcStr).getTime();
  } catch {
    return 0;
  }
}
