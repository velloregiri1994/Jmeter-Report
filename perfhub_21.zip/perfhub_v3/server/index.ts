import "dotenv/config";
import express, { type Request, Response, NextFunction } from "express";
import session from "express-session";
import pgSession from "connect-pg-simple";
import compression from "compression";
import cors from "cors";
import helmet from "helmet";
import crypto from "crypto";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import { pool } from "./db";
import { initWebSocket } from "./websocket";
import { startSchedulerService, stopSchedulerService } from "./scheduler-service";
import { cancelAllRuns, getActiveRunCount } from "./jmeter-worker";
import { correlationMiddleware, globalErrorHandler } from "./error-handler";
import { logger } from "./logger";

const app = express();
const httpServer = createServer(app);
initWebSocket(httpServer);

const PgStore = pgSession(session);

export let sessionTableReady = false;

async function ensureSessionTable() {
  const createTableSQL = `
    CREATE TABLE IF NOT EXISTS "session" (
      "sid" varchar NOT NULL COLLATE "default",
      "sess" json NOT NULL,
      "expire" timestamp(6) NOT NULL,
      PRIMARY KEY ("sid")
    );
    CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "session" ("expire");
  `;

  try {
    await pool.query(createTableSQL);
    sessionTableReady = true;
    return;
  } catch (err) {
    console.warn('[Session] Initial session table creation failed, retrying in 2 seconds...', err);
  }

  await new Promise(resolve => setTimeout(resolve, 2000));

  try {
    await pool.query(createTableSQL);
    sessionTableReady = true;
    console.log('[Session] Session table created successfully on retry.');
  } catch (err) {
    console.error('[Session] Session table creation failed after retry.');
    console.error('[Session] Error:', err);
    console.error('[Session] The app will start, but login/session features will not work.');
    console.error('[Session] To fix: ensure the database is accessible and run the app again,');
    console.error('[Session] or manually create the session table with:');
    console.error('[Session]   CREATE TABLE IF NOT EXISTS "session" ("sid" varchar NOT NULL, "sess" json NOT NULL, "expire" timestamp(6) NOT NULL, PRIMARY KEY ("sid"));');
  }
}
// Session table creation is awaited in the async startup block below

// Session middleware for authentication (check before other middleware)
const isProduction = process.env.NODE_ENV === 'production';
const trustProxy = process.env.TRUST_PROXY === 'true';
const sessionSecret = process.env.SESSION_SECRET;
// Secure cookies should only be enabled when explicitly serving over HTTPS.
// Direct (non-proxied) installs on HTTP must keep this false, otherwise the
// browser silently drops the session cookie and every API call returns 401.
const secureCookies = process.env.COOKIE_SECURE === 'true';

// Security: Block startup with default session secret in production
if (isProduction && !sessionSecret) {
  console.error('[SECURITY ERROR] SESSION_SECRET environment variable is not set!');
  console.error('Refusing to start in production without a secure session secret.');
  console.error('Set the SESSION_SECRET environment variable to a strong random value (32+ characters).');
  process.exit(1);
}

if (trustProxy) {
  app.set('trust proxy', 1);
}

// Security headers
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));

// CORS Configuration
// When CORS_ORIGIN is not set, reflect the request's Origin header so that
// same-origin and local installs work out of the box regardless of hostname/IP.
const corsOrigin = process.env.CORS_ORIGIN || true;
app.use(cors({
  origin: corsOrigin,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  maxAge: 86400, // 24 hours
}));

// CSRF protection: require X-Requested-With header on state-changing requests
// Exempt paths that use Bearer token auth (ingest and CI/CD endpoints)
const CSRF_EXEMPT_PREFIXES = ['/api/ingest/', '/api/ci/'];
app.use((req: Request, res: Response, next: NextFunction) => {
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
    return next();
  }
  const path = req.path;
  if (CSRF_EXEMPT_PREFIXES.some(prefix => path.startsWith(prefix))) {
    return next();
  }
  if (req.headers['x-requested-with'] !== 'XMLHttpRequest') {
    return res.status(403).json({ message: 'Forbidden: missing CSRF header' });
  }
  next();
});


// Correlation ID for error tracking
app.use(correlationMiddleware);

// Compression middleware
app.use(compression());

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

// Remote ingest routes — registered before express.json() so gzipped payloads
// aren't rejected by the global JSON parser. Ingest routes parse their own bodies.
import ingestRoutes from "./ingest-routes";
app.use("/api/ingest", express.raw({ type: "*/*", limit: "50mb" }));
app.use(ingestRoutes);

app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);

app.use(express.urlencoded({ extended: false }));

// Text/plain body parser for InfluxDB line protocol
app.use(express.text({ type: 'text/plain', limit: '10mb' }));
app.use(express.raw({ type: 'application/octet-stream', limit: '10mb' }));

// Session middleware
app.use(session({
  store: new PgStore({
    pool: pool,
    tableName: 'session',
    createTableIfMissing: false // We create the table manually above to avoid file read errors in production
  }),
  secret: sessionSecret || 'perfhub-dev-only-not-for-production',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: secureCookies, // Set COOKIE_SECURE=true only when serving over HTTPS
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    path: '/'
  }
}));

export function log(message: string, source = "express") {
  logger.info(message, source);
}

app.use((req, res, next) => {
  const start = Date.now();
  // Normalize URL so we can skip noisy polling routes regardless of query params
  const normalizedPath = (req.originalUrl || req.path || "").split("?")[0];
  const shouldSkipLog =
    normalizedPath === "/api/notifications" ||
    normalizedPath === "/api/notifications/unread-count" ||
    normalizedPath.startsWith("/api/notifications/");

  if (shouldSkipLog) return next();

  const originalJson = res.json.bind(res);
  let responseBody: any = undefined;
  res.json = function (body: any) {
    responseBody = body;
    return originalJson(body);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (normalizedPath.startsWith("/api")) {
      const status = res.statusCode;
      const contentLength = res.getHeader("content-length");
      const size = contentLength ? ` ${contentLength}B` : "";

      if (status >= 500 && responseBody) {
        const errMsg = responseBody.message || responseBody.error || "";
        const errorId = responseBody.errorId ? ` [${responseBody.errorId}]` : "";
        const detail = errMsg ? ` — ${errMsg}` : "";
        logger.error(`${req.method} ${normalizedPath} ${status} in ${duration}ms${size}${errorId}${detail}`, "express");
      } else if (status >= 400 && responseBody) {
        const errMsg = responseBody.message || responseBody.error || responseBody.code || "";
        const errorId = responseBody.errorId ? ` [${responseBody.errorId}]` : "";
        const detail = errMsg ? ` — ${errMsg}` : "";
        logger.warn(`${req.method} ${normalizedPath} ${status} in ${duration}ms${size}${errorId}${detail}`, "express");
      } else {
        let extra = "";
        if (responseBody && Array.isArray(responseBody)) {
          extra = ` (${responseBody.length} items)`;
        } else if (responseBody && typeof responseBody === "object" && responseBody.data && Array.isArray(responseBody.data)) {
          extra = ` (${responseBody.data.length} items)`;
        } else if (responseBody && typeof responseBody === "object" && responseBody.total !== undefined) {
          extra = ` (${responseBody.total} total)`;
        }
        log(`${req.method} ${normalizedPath} ${status} in ${duration}ms${size}${extra}`);
      }
    }
  });

  next();
});

async function ensureDatabaseSchema() {
  const { runMigrations } = await import("./migrate");
  await runMigrations();
}

(async () => {
  await ensureSessionTable();
  await ensureDatabaseSchema();
  await registerRoutes(httpServer, app);

  app.use(globalErrorHandler);

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || "5000", 10);
  const host = "0.0.0.0";
  httpServer.listen(
    {
      port,
      host,
    },
    () => {
      log(`serving on http://${host}:${port}`);
      startSchedulerService();
    },
  );

  let isShuttingDown = false;
  
  const gracefulShutdown = async (signal: string) => {
    if (isShuttingDown) return;
    isShuttingDown = true;
    
    log(`Received ${signal}, shutting down gracefully...`);
    
    stopSchedulerService();

    const activeCount = getActiveRunCount();
    if (activeCount > 0) {
      log(`Cancelling ${activeCount} active JMeter run(s)...`);
      try {
        await cancelAllRuns();
      } catch (err) {
        log(`Error cancelling active runs: ${err}`);
      }
    }
    
    const shutdownTimeout = setTimeout(() => {
      log("Shutdown timeout reached, forcing exit");
      process.exit(1);
    }, 30000);
    
    httpServer.close(async () => {
      log("HTTP server closed");
      try {
        await pool.end();
        log("Database pool closed");
      } catch (err) {
        log(`Error closing database pool: ${err}`);
      }
      clearTimeout(shutdownTimeout);
      log("Shutdown complete");
      process.exit(0);
    });
  };

  process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
  process.on("SIGINT", () => gracefulShutdown("SIGINT"));
  
  process.on("uncaughtException", (err) => {
    logger.fatal(`Uncaught exception: ${err.message}`, "process", { stack: err.stack });
    gracefulShutdown("uncaughtException");
  });
  
  process.on("unhandledRejection", (reason: any) => {
    logger.error(`Unhandled rejection: ${reason?.message || reason}`, "process", { stack: reason?.stack });
  });
})();
