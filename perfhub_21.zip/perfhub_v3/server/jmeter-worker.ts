import { spawn, ChildProcess } from "child_process";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { broadcastExecutionUpdate } from "./websocket";
import { startLiveMetrics, stopLiveMetrics } from "./live-metrics";
import { startSystemMetrics, stopSystemMetrics } from "./system-metrics-collector";
import { log } from "./index";
import { sendTestCompletionEmail } from "./email/email-service";

// Load config from config.json if it exists
function loadConfig(): { jmeter?: { home?: string; executable?: string }; python?: { command?: string } } {
  try {
    const configPath = path.join(process.cwd(), "config.json");
    if (fs.existsSync(configPath)) {
      const content = fs.readFileSync(configPath, "utf-8");
      return JSON.parse(content);
    }
  } catch (err) {
    // Config file not found or invalid, use defaults
  }
  return {};
}

function getJMeterBinName(): string {
  return process.platform === "win32" ? "jmeter.bat" : "jmeter";
}

function getJMeterPath(): string {
  const config = loadConfig();
  const binName = getJMeterBinName();
  
  if (config.jmeter?.executable && config.jmeter.executable.trim()) {
    return config.jmeter.executable.trim();
  }
  
  if (config.jmeter?.home && config.jmeter.home.trim()) {
    const resolved = path.join(config.jmeter.home.trim(), "bin", binName);
    if (fs.existsSync(resolved)) return resolved;
    const alt = path.join(config.jmeter.home.trim(), "bin", process.platform === "win32" ? "jmeter" : "jmeter.bat");
    if (fs.existsSync(alt)) return alt;
    return resolved;
  }
  
  if (process.env.JMETER_HOME) {
    return path.join(process.env.JMETER_HOME, "bin", binName);
  }
  
  return "jmeter";
}

interface DependencyFile {
  originalName: string;
  storedPath: string;
  size: number;
  uploadedAt: string;
}

interface JarFile {
  originalName: string;
  storedPath: string;
  size: number;
  uploadedAt: string;
}

interface RunConfig {
  executionId: string;
  jmxPath: string;
  dependencyFiles?: DependencyFile[];
  jarFiles?: JarFile[];
  vusers?: number;
  rampUp?: number;
  duration?: number;
}

interface QueuedRun {
  runId: string;
  dbExecutionId: number;
  config: RunConfig;
}

const runQueue: QueuedRun[] = [];

const MAX_QUEUE_SIZE = parseInt(process.env.MAX_QUEUE_SIZE || "50", 10);

interface ActiveRun {
  runId: string;
  dbExecutionId: number;
  config: RunConfig;
  process: ChildProcess | null;
}

const activeRuns = new Map<number, ActiveRun>();

const MAX_CONCURRENT_RUNS = parseInt(process.env.MAX_CONCURRENT_TESTS || "20", 10);
const MAX_EXECUTION_TIMEOUT_MS = parseInt(process.env.MAX_EXECUTION_TIMEOUT_MS || String(24 * 60 * 60 * 1000), 10);
const SIGKILL_GRACE_MS = 10_000;

const RESULTS_BASE_DIR = path.join(process.cwd(), "results");

function forceKillProcess(proc: ChildProcess): void {
  try {
    proc.kill("SIGTERM");
  } catch {}
  const killTimer = setTimeout(() => {
    try {
      if (!proc.killed) {
        proc.kill("SIGKILL");
      }
    } catch {}
  }, SIGKILL_GRACE_MS);
  killTimer.unref();
  proc.once("exit", () => clearTimeout(killTimer));
}

// SLA evaluation helpers
function getMetricValue(tx: any, metric: string): number | undefined {
  switch (metric) {
    case 'avg': return tx.avg;
    case 'p90': return tx.p90;
    case 'p95': return tx.p95;
    case 'p99': return tx.p99;
    case 'max': return tx.max;
    case 'errorRate': return tx.errorRate;
    case 'throughput': return tx.throughput;
    default: return undefined;
  }
}

function getGlobalMetricValue(summary: any, metric: string): number | undefined {
  switch (metric) {
    case 'avg': return summary.avgResponseTime;
    case 'p90': return summary.p90;
    case 'p95': return summary.p95;
    case 'p99': return summary.p99;
    case 'max': return summary.maxResponseTime;
    case 'errorRate': return summary.errorRate;
    case 'throughput': return summary.throughput;
    default: return undefined;
  }
}

function evaluateSlaRule(actual: number, threshold: number, comparator: string): boolean {
  switch (comparator) {
    case 'lt': return actual >= threshold; // violation if actual >= threshold (should be less than)
    case 'lte': return actual > threshold;
    case 'gt': return actual <= threshold; // violation if actual <= threshold (should be greater than)
    case 'gte': return actual < threshold;
    default: return false;
  }
}

function ensureResultsDir(runId: string): string {
  const runDir = path.join(RESULTS_BASE_DIR, runId);
  fs.mkdirSync(runDir, { recursive: true });
  return runDir;
}

function sanitizeFilename(filename: string): string {
  return path.basename(filename).replace(/[^a-zA-Z0-9._-]/g, "_");
}

export function generateRunId(): string {
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10).replace(/-/g, "");
  const timeStr = now.toISOString().slice(11, 19).replace(/:/g, "");
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `RUN-${dateStr}-${timeStr}-${random}`;
}

export async function queueJMeterRun(
  dbExecutionId: number,
  config: RunConfig
): Promise<string> {
  if (runQueue.length >= MAX_QUEUE_SIZE) {
    throw new Error(`Queue is full (${MAX_QUEUE_SIZE} pending runs). Please wait for some tests to complete.`);
  }

  const runId = generateRunId();
  
  runQueue.push({
    runId,
    dbExecutionId,
    config,
  });

  log(`Queued JMeter run ${runId} (execution ID: ${dbExecutionId})`, "jmeter-worker");
  
  processQueue();
  
  return runId;
}

async function processQueue(): Promise<void> {
  while (activeRuns.size < MAX_CONCURRENT_RUNS && runQueue.length > 0) {
    const queued = runQueue.shift()!;
    executeRun(queued);
  }
}

async function executeRun(queued: QueuedRun): Promise<void> {
  const { runId, dbExecutionId, config } = queued;

  const activeRun: ActiveRun = { runId, dbExecutionId, config, process: null };
  activeRuns.set(dbExecutionId, activeRun);

  log(`Starting JMeter run ${runId}`, "jmeter-worker");

  try {
    await storage.updateExecution(dbExecutionId, {
      status: "running",
      startTime: new Date().toISOString(),
    });
    broadcastExecutionUpdate(dbExecutionId, "running");

    const runDir = ensureResultsDir(runId);
    const jtlPath = path.join(runDir, "results.csv");
    const logPath = path.join(runDir, "jmeter.log");

    await storage.updateExecution(dbExecutionId, {
      artifactsPath: runDir,
    });

    const jmxSourcePath = path.join(process.cwd(), config.jmxPath);
    
    if (!fs.existsSync(jmxSourcePath)) {
      throw new Error(`JMX file not found: ${jmxSourcePath}`);
    }

    // Copy JMX file to run directory for relative path resolution
    const jmxFileName = path.basename(config.jmxPath);
    const jmxRunPath = path.join(runDir, jmxFileName);
    fs.copyFileSync(jmxSourcePath, jmxRunPath);
    log(`Copied JMX to run folder: ${jmxRunPath}`, "jmeter-worker");

    // Copy all dependency files to run directory
    const missingFiles: string[] = [];
    if (config.dependencyFiles && config.dependencyFiles.length > 0) {
      log(`Copying ${config.dependencyFiles.length} dependency files to run folder`, "jmeter-worker");
      for (const dep of config.dependencyFiles) {
        const depSourcePath = path.join(process.cwd(), dep.storedPath);
        const depDestPath = path.join(runDir, dep.originalName);
        
        if (fs.existsSync(depSourcePath)) {
          fs.copyFileSync(depSourcePath, depDestPath);
          log(`Copied dependency: ${dep.originalName}`, "jmeter-worker");
        } else {
          missingFiles.push(`Dependency: ${dep.originalName}`);
          log(`ERROR: Dependency file not found: ${dep.originalName} (expected at ${depSourcePath})`, "jmeter-worker");
        }
      }
    }

    // Copy JAR files to lib folder in run directory
    let jarClasspath = "";
    if (config.jarFiles && config.jarFiles.length > 0) {
      const libDir = path.join(runDir, "lib");
      fs.mkdirSync(libDir, { recursive: true });
      
      log(`Copying ${config.jarFiles.length} JAR files to lib folder`, "jmeter-worker");
      const jarPaths: string[] = [];
      
      for (const jar of config.jarFiles) {
        const jarSourcePath = path.join(process.cwd(), jar.storedPath);
        const jarDestPath = path.join(libDir, jar.originalName);
        
        if (fs.existsSync(jarSourcePath)) {
          fs.copyFileSync(jarSourcePath, jarDestPath);
          jarPaths.push(path.join("lib", jar.originalName));
          log(`Copied JAR: ${jar.originalName}`, "jmeter-worker");
        } else {
          missingFiles.push(`JAR: ${jar.originalName}`);
          log(`ERROR: JAR file not found: ${jar.originalName} (expected at ${jarSourcePath})`, "jmeter-worker");
        }
      }
      
      if (jarPaths.length > 0) {
        jarClasspath = jarPaths.join(path.delimiter);
      }
    }

    if (missingFiles.length > 0) {
      throw new Error(`Aborting run — ${missingFiles.length} required file(s) not found: ${missingFiles.join("; ")}`);
    }

    // Use relative paths - JMeter will be executed from runDir
    const args = [
      "-n",
      "-t", jmxFileName,
      "-l", "results.csv",
      "-j", "jmeter.log",

      "-Jjmeter.save.saveservice.output_format=csv",
      "-Jjmeter.save.saveservice.autoflush=true",
      "-Jjmeter.save.saveservice.timestamp_format=ms",

      "-Jjmeter.save.saveservice.time=true",
      "-Jjmeter.save.saveservice.elapsed=true",
      "-Jjmeter.save.saveservice.label=true",
      "-Jjmeter.save.saveservice.success=true",
      "-Jjmeter.save.saveservice.response_code=true",
      "-Jjmeter.save.saveservice.response_message=true",
      "-Jjmeter.save.saveservice.thread_counts=true",
      "-Jjmeter.save.saveservice.bytes=true",
      "-Jjmeter.save.saveservice.connect_time=true",
      "-Jjmeter.save.saveservice.idle_time=true",

      "-Jjmeter.save.saveservice.response_data=false",
      "-Jjmeter.save.saveservice.samplerData=false",
      "-Jjmeter.save.saveservice.requestHeaders=false",
      "-Jjmeter.save.saveservice.responseHeaders=false",
    ];

    if (config.vusers) {
      args.push("-Jthreads=" + config.vusers);
    }
    if (config.rampUp) {
      args.push("-Jrampup=" + config.rampUp);
    }
    if (config.duration) {
      args.push("-Jduration=" + config.duration);
    }

    if (jarClasspath) {
      args.push("-Juser.classpath=" + jarClasspath);
      log(`Added JARs to classpath: ${jarClasspath}`, "jmeter-worker");
    }

    const jmeterBin = getJMeterPath();

    log(`Executing from ${runDir}: ${jmeterBin} ${args.join(" ")}`, "jmeter-worker");

    await startLiveMetrics(dbExecutionId, runId, jtlPath);

    const jmeterProcess = spawn(jmeterBin, args, {
      cwd: runDir,
      env: { ...process.env },
    });

    activeRun.process = jmeterProcess;

    const jmeterPid = jmeterProcess.pid || null;
    startSystemMetrics(dbExecutionId, runDir, jmeterPid ?? undefined);

    const MAX_OUTPUT_SIZE = 100 * 1024;
    let stdout = "";
    let stderr = "";
    let stdoutTruncated = false;
    let stderrTruncated = false;

    jmeterProcess.stdout?.on("data", (data) => {
      if (!stdoutTruncated) {
        stdout += data.toString();
        if (stdout.length > MAX_OUTPUT_SIZE) {
          stdout = stdout.slice(-MAX_OUTPUT_SIZE);
          stdoutTruncated = true;
        }
      }
    });

    jmeterProcess.stderr?.on("data", (data) => {
      if (!stderrTruncated) {
        stderr += data.toString();
        if (stderr.length > MAX_OUTPUT_SIZE) {
          stderr = stderr.slice(-MAX_OUTPUT_SIZE);
          stderrTruncated = true;
        }
      }
    });

    const exitCode = await Promise.race([
      new Promise<number>((resolve) => {
        jmeterProcess.on("close", (code) => {
          resolve(code ?? 1);
        });
        jmeterProcess.on("error", (err) => {
          log(`JMeter process error: ${err.message}`, "jmeter-worker");
          resolve(1);
        });
      }),
      new Promise<number>((_, reject) => {
        const timeoutMs = config.duration
          ? Math.max((config.duration + 300) * 1000, MAX_EXECUTION_TIMEOUT_MS)
          : MAX_EXECUTION_TIMEOUT_MS;
        setTimeout(() => {
          reject(new Error(`Execution timeout after ${Math.round(timeoutMs / 60000)} minutes`));
        }, timeoutMs);
      }),
    ]).catch((err) => {
      log(`${err.message} — killing process for run ${runId}`, "jmeter-worker");
      forceKillProcess(jmeterProcess);
      throw err;
    });

    activeRun.process = null;

    if (exitCode !== 0) {
      throw new Error(`JMeter exited with code ${exitCode}. Stderr: ${stderr}`);
    }

    stopLiveMetrics(dbExecutionId);
    const systemMetricsSummary = stopSystemMetrics(dbExecutionId);

    log(`JMeter run ${runId} completed, parsing results...`, "jmeter-worker");

    await storage.updateExecution(dbExecutionId, { status: "parsing" });
    broadcastExecutionUpdate(dbExecutionId, "parsing");

    const metrics = await parseJtlFile(jtlPath, runDir);

    try {
      const { persistBucketsFromFile } = await import("./bucket-persistence");
      const rowCount = await persistBucketsFromFile(dbExecutionId, runDir);
      log(`Persisted ${rowCount} bucket rows to DB for execution ${dbExecutionId}`, "jmeter-worker");
    } catch (bucketErr: any) {
      log(`Warning: failed to persist buckets to DB for execution ${dbExecutionId}: ${bucketErr.message}`, "jmeter-worker");
    }

    const resultSummary = {
      totalRequests: metrics.global?.total_requests || 0,
      successfulRequests: metrics.global?.successes || 0,
      failedRequests: metrics.global?.errors || 0,
      avgResponseTime: metrics.global?.avg_ms || 0,
      minResponseTime: metrics.global?.min_ms || 0,
      maxResponseTime: metrics.global?.max_ms || 0,
      throughput: metrics.global?.throughput_rps || 0,
      peakRps: metrics.peak_rps || 0,
      p50: metrics.global?.p50_ms || 0,
      p90: metrics.global?.p90_ms || 0,
      p95: metrics.global?.p95_ms || 0,
      p99: metrics.global?.p99_ms || 0,
      errorRate: metrics.global?.error_rate || 0,
      apdex: metrics.global?.apdex || 0,
      durationSeconds: metrics.global?.duration_sec || 0,
      startTime: metrics.start_time || null,
      endTime: metrics.end_time || null,
      transactionDetails: metrics.per_label?.map((label: any) => ({
        label: label.label,
        count: label.count,
        avg: label.avg,
        min: label.min,
        max: label.max,
        p50: label.p50,
        p90: label.p90,
        p95: label.p95,
        p99: label.p99,
        errorRate: label.error_rate,
        errorCount: label.error_count,
        throughput: label.throughput,
      })) || [],
      errorSummary: metrics.error_summary || [],
      errorDetails: metrics.error_details || [],
      timeseries: metrics.timeseries || [],
      systemMetrics: systemMetricsSummary || undefined,
    };

    // Evaluate SLA rules and baseline deviation
    const execution = await storage.getExecution(dbExecutionId);
    let slaViolations: any = null;
    let baselineDeviation: any = null;

    if (execution?.schedule?.scriptId) {
      const scriptId = execution.schedule.scriptId;
      const perTransactionViolations: any[] = [];
      
      // Check SLA rules from sla_rules table (per-script rules)
      const slaRules = await storage.getEnabledSlaRules(scriptId);
      if (slaRules.length > 0) {
        for (const rule of slaRules) {
          let actualValue: number | undefined;
          
          if (rule.transactionLabel) {
            const tx = resultSummary.transactionDetails?.find((t: any) => t.label === rule.transactionLabel);
            if (tx) {
              actualValue = getMetricValue(tx, rule.metric);
            }
          } else {
            actualValue = getGlobalMetricValue(resultSummary, rule.metric);
          }
          
          if (actualValue !== undefined) {
            const violated = evaluateSlaRule(actualValue, rule.threshold, rule.comparator);
            if (violated) {
              perTransactionViolations.push({
                label: rule.transactionLabel || 'Global',
                metric: rule.metric,
                threshold: rule.threshold,
                actual: actualValue,
                comparator: rule.comparator,
                ruleName: `${rule.metric} ${rule.comparator} ${rule.threshold}`,
              });
            }
          }
        }
      }

      // Check schedule-level SLA config (configuration.slas from schedule form)
      const scheduleConfig = execution.schedule?.configuration as any;
      const scheduleSlas = scheduleConfig?.slas;
      if (scheduleSlas && typeof scheduleSlas === 'object') {
        const slaMetricMap: Record<string, { metric: string; comparator: string; label: string; unit: string }> = {
          avgResponseTime: { metric: 'avg', comparator: 'lte', label: 'Avg Response Time', unit: 'ms' },
          p90: { metric: 'p90', comparator: 'lte', label: 'P90 Response Time', unit: 'ms' },
          p95: { metric: 'p95', comparator: 'lte', label: 'P95 Response Time', unit: 'ms' },
          p99: { metric: 'p99', comparator: 'lte', label: 'P99 Response Time', unit: 'ms' },
          maxResponseTime: { metric: 'max', comparator: 'lte', label: 'Max Response Time', unit: 'ms' },
          errorRate: { metric: 'errorRate', comparator: 'lte', label: 'Error Rate', unit: '%' },
          throughput: { metric: 'throughput', comparator: 'gte', label: 'Throughput', unit: 'rps' },
        };

        for (const [metricKey, rawThreshold] of Object.entries(scheduleSlas)) {
          if (typeof rawThreshold !== 'number' || rawThreshold < 0) continue;

          const mapping = slaMetricMap[metricKey];
          if (!mapping) continue;

          // Error rate is entered as % in UI (e.g. 1.0 = 1%) but stored as fraction in results (0.01)
          const threshold = metricKey === 'errorRate' ? rawThreshold / 100 : rawThreshold;

          // Check global metric using existing helper
          const globalValue = getGlobalMetricValue(resultSummary, mapping.metric);
          if (globalValue !== undefined) {
            const globalViolated = evaluateSlaRule(globalValue, threshold, mapping.comparator === 'lte' ? 'lt' : 'gt');
            if (globalViolated) {
              const alreadyExists = perTransactionViolations.some(
                (v: any) => v.label === 'Global' && v.metric === mapping.metric
              );
              if (!alreadyExists) {
                perTransactionViolations.push({
                  label: 'Global',
                  metric: mapping.metric,
                  threshold,
                  actual: Math.round(globalValue * 100) / 100,
                  comparator: mapping.comparator === 'lte' ? 'lt' : 'gt',
                  ruleName: `Global ${mapping.label} should be ${mapping.comparator === 'lte' ? '<=' : '>='} ${rawThreshold}${mapping.unit}`,
                });
              }
            }
          }

          // Check each transaction using existing helper
          if (resultSummary.transactionDetails?.length > 0) {
            for (const tx of resultSummary.transactionDetails) {
              const actualValue = getMetricValue(tx, mapping.metric);
              if (actualValue === undefined) continue;

              const violated = evaluateSlaRule(actualValue, threshold, mapping.comparator === 'lte' ? 'lt' : 'gt');
              if (violated) {
                const alreadyExists = perTransactionViolations.some(
                  (v: any) => v.label === tx.label && v.metric === mapping.metric
                );
                if (!alreadyExists) {
                  perTransactionViolations.push({
                    label: tx.label,
                    metric: mapping.metric,
                    threshold,
                    actual: Math.round(actualValue * 100) / 100,
                    comparator: mapping.comparator === 'lte' ? 'lt' : 'gt',
                    ruleName: `${mapping.label} should be ${mapping.comparator === 'lte' ? '<=' : '>='} ${rawThreshold}${mapping.unit}`,
                  });
                }
              }
            }
          }
        }
      }

      if (perTransactionViolations.length > 0) {
        slaViolations = { perTransaction: perTransactionViolations };
        
        if (execution.schedule?.createdBy) {
          const shouldNotify = await storage.shouldSendNotification(execution.schedule.createdBy, 'sla_violation');
          if (shouldNotify) {
            await storage.createNotification({
              userId: execution.schedule.createdBy,
              title: "SLA Violations Detected",
              message: `Test run detected ${perTransactionViolations.length} SLA violation(s)`,
              type: "sla_violation",
              link: `/executions/${dbExecutionId}`,
            });
          }
        }
        log(`SLA violations detected for execution ${dbExecutionId}: ${perTransactionViolations.length} violation(s)`, "jmeter-worker");
      }
      
      // Check baseline deviation with configurable regression thresholds
      const baselineData = await storage.getBaselineWithExecution(scriptId);
      if (baselineData && baselineData.execution.resultSummary) {
        const baselineSummary: any = baselineData.execution.resultSummary;
        
        const computeDeviation = (baseline: number, current: number) => {
          if (baseline === 0) return current === 0 ? 0 : 100;
          return ((current - baseline) / baseline) * 100;
        };
        
        const globalDeviation: Record<string, any> = {};
        const metricPairs: { key: string; baselineVal: number | undefined; currentVal: number }[] = [
          { key: 'avgResponseTime', baselineVal: baselineSummary.avgResponseTime, currentVal: resultSummary.avgResponseTime },
          { key: 'throughput', baselineVal: baselineSummary.throughput, currentVal: resultSummary.throughput },
          { key: 'errorRate', baselineVal: baselineSummary.errorRate ?? 0, currentVal: resultSummary.errorRate },
          { key: 'p90', baselineVal: baselineSummary.p90, currentVal: resultSummary.p90 },
          { key: 'p95', baselineVal: baselineSummary.p95, currentVal: resultSummary.p95 },
          { key: 'p99', baselineVal: baselineSummary.p99, currentVal: resultSummary.p99 },
        ];
        
        for (const mp of metricPairs) {
          if (mp.baselineVal !== undefined) {
            globalDeviation[mp.key] = {
              baseline: mp.baselineVal,
              current: mp.currentVal,
              changePercent: computeDeviation(mp.baselineVal, mp.currentVal),
            };
          }
        }
        
        // Transaction-level deviations
        const transactionDeviations: any[] = [];
        if (resultSummary.transactionDetails?.length > 0 && baselineSummary.transactionDetails?.length > 0) {
          for (const tx of resultSummary.transactionDetails) {
            const baselineTx = baselineSummary.transactionDetails.find((b: any) => b.label === tx.label);
            if (baselineTx) {
              transactionDeviations.push({
                label: tx.label,
                avg: { baseline: baselineTx.avg, current: tx.avg, changePercent: computeDeviation(baselineTx.avg, tx.avg) },
                p90: baselineTx.p90 !== undefined ? { baseline: baselineTx.p90, current: tx.p90, changePercent: computeDeviation(baselineTx.p90, tx.p90) } : undefined,
                p95: baselineTx.p95 !== undefined ? { baseline: baselineTx.p95, current: tx.p95, changePercent: computeDeviation(baselineTx.p95, tx.p95) } : undefined,
                errorRate: { baseline: baselineTx.errorRate || 0, current: tx.errorRate || 0, changePercent: computeDeviation(baselineTx.errorRate || 0, tx.errorRate || 0) },
                throughput: baselineTx.throughput !== undefined ? { baseline: baselineTx.throughput, current: tx.throughput, changePercent: computeDeviation(baselineTx.throughput, tx.throughput) } : undefined,
              });
            }
          }
        }
        
        // Load configurable regression thresholds (fallback to defaults)
        const customThresholds = await storage.getEnabledRegressionThresholds(scriptId);
        const thresholdMap: Record<string, { warning: number; critical: number }> = {
          avgResponseTime: { warning: 10, critical: 25 },
          throughput: { warning: 10, critical: 25 },
          errorRate: { warning: 20, critical: 50 },
          p90: { warning: 10, critical: 25 },
          p95: { warning: 10, critical: 25 },
          p99: { warning: 15, critical: 30 },
        };
        for (const ct of customThresholds) {
          thresholdMap[ct.metric] = { warning: ct.warningPercent, critical: ct.criticalPercent };
        }
        
        // Evaluate regressions per metric using thresholds
        const regressionDetails: { metric: string; changePercent: number; severity: 'warning' | 'critical' }[] = [];
        for (const [metric, dev] of Object.entries(globalDeviation)) {
          const thresh = thresholdMap[metric];
          if (!thresh || !dev) continue;
          const change = Math.abs(dev.changePercent);
          const isHigherBad = metric !== 'throughput';
          const isRegression = isHigherBad ? dev.changePercent > 0 : dev.changePercent < 0;
          if (isRegression && change >= thresh.warning) {
            regressionDetails.push({
              metric,
              changePercent: dev.changePercent,
              severity: change >= thresh.critical ? 'critical' : 'warning',
            });
          }
        }
        
        const overallRegression = regressionDetails.length > 0;
        const hasCritical = regressionDetails.some(r => r.severity === 'critical');
        let regressionSeverity: 'minor' | 'moderate' | 'severe' | undefined;
        if (overallRegression) {
          if (hasCritical) regressionSeverity = 'severe';
          else if (regressionDetails.length >= 2) regressionSeverity = 'moderate';
          else regressionSeverity = 'minor';
        }
        
        baselineDeviation = {
          baselineExecutionId: baselineData.baseline.executionId,
          global: globalDeviation,
          transactionDeviations,
          overallRegression,
          regressionSeverity,
          regressionDetails,
          thresholds: thresholdMap,
        };
        
        if (overallRegression && execution.schedule?.createdBy) {
          const shouldNotify = await storage.shouldSendNotification(execution.schedule.createdBy, 'warning');
          if (shouldNotify) {
            const metricsAffected = regressionDetails.map(r => r.metric).join(', ');
            await storage.createNotification({
              userId: execution.schedule.createdBy,
              title: "Performance Regression Detected",
              message: `Test run shows ${regressionSeverity} regression in: ${metricsAffected}`,
              type: "warning",
              link: `/executions/${dbExecutionId}`,
            });
          }
        }
      }
    }

    if (resultSummary.timeseries && resultSummary.timeseries.length > 0) {
      try {
        const { detectFromTimeseries } = await import("./live-metrics/live-analysis-engine");
        const { anomalies, insights } = detectFromTimeseries(resultSummary.timeseries);
        if (anomalies.length > 0) {
          (resultSummary as any).anomalies = anomalies;
          (resultSummary as any).anomalySummary = {
            total: anomalies.length,
            warning: anomalies.filter(a => a.severity === "warning").length,
            critical: anomalies.filter(a => a.severity === "critical").length,
          };
          log(`Detected ${anomalies.length} spike anomalies for execution ${dbExecutionId}`, "jmeter-worker");
        }

        if (insights.length > 0) {
          (resultSummary as any).insights = insights;
          (resultSummary as any).insightSummary = {
            total: insights.length,
            warning: insights.filter(e => e.severity === "warning").length,
            critical: insights.filter(e => e.severity === "critical").length,
            byType: insights.reduce((acc: Record<string, number>, e) => {
              acc[e.type] = (acc[e.type] || 0) + 1;
              return acc;
            }, {}),
          };
          log(`Detected ${insights.length} performance insights for execution ${dbExecutionId}`, "jmeter-worker");
        }
      } catch (err) {
        log(`Failed to run detection for execution ${dbExecutionId}: ${err}`, "jmeter-worker");
      }
    }

    await storage.updateExecution(dbExecutionId, {
      status: "completed",
      endTime: new Date().toISOString(),
      resultSummary,
      slaViolations,
      baselineDeviation,
    });

    // Update schedule status to completed
    if (execution?.scheduleId) {
      await storage.updateSchedule(execution.scheduleId, { status: "completed" });
    }

    // Auto-populate test tracker record
    try {
      const updatedExecution = await storage.getExecution(dbExecutionId);
      const schedule = execution?.scheduleId ? await storage.getSchedule(execution.scheduleId) : null;
      const script = schedule?.script || null;
      const project = script?.projectId ? await storage.getProject(script.projectId) : null;
      const config = schedule?.configuration as any || {};
      
      const startMs = updatedExecution?.startTime ? new Date(updatedExecution.startTime).getTime() : 0;
      const endMs = updatedExecution?.endTime ? new Date(updatedExecution.endTime).getTime() : Date.now();
      const durationSeconds = startMs ? Math.round((endMs - startMs) / 1000) : 0;
      
      await storage.createTestTrackerRecord({
        runId,
        executionTimestamp: updatedExecution?.startTime || new Date().toISOString(),
        projectId: script?.projectId || null,
        projectName: project?.name || null,
        featureName: script?.name || schedule?.name || "Unknown",
        testTypeId: config.testTypeId || null,
        testTypeName: config.testTypeName || null,
        volume: config.volume || null,
        environment: config.environment || null,
        comments: null,
        status: "completed",
        durationSeconds,
        avgResponseTime: Math.round(resultSummary.avgResponseTime || 0),
        p95: resultSummary.p95 ? Math.round(resultSummary.p95) : null,
        p99: resultSummary.p99 ? Math.round(resultSummary.p99) : null,
        throughput: Math.round(resultSummary.throughput || 0),
        errorRate: Math.round((resultSummary.errorRate || 0) * 100),
        executionId: dbExecutionId,
        releaseTag: updatedExecution?.releaseTag || null,
      });
      log(`Test tracker record created for ${runId}`, "jmeter-worker");
    } catch (trackerError) {
      log(`Failed to create tracker record: ${trackerError}`, "jmeter-worker");
    }

    if (execution?.schedule?.createdBy) {
      try {
        const shouldNotify = await storage.shouldSendNotification(execution!.schedule!.createdBy, 'info');
        if (shouldNotify) {
          const scheduleName = execution?.schedule?.name || "Unknown";
          await storage.createNotification({
            userId: execution!.schedule!.createdBy,
            title: "Test Completed Successfully",
            message: `Test "${scheduleName}" completed — Avg: ${Math.round(resultSummary.avgResponseTime)}ms, P95: ${Math.round(resultSummary.p95)}ms, Throughput: ${Math.round(resultSummary.throughput)} req/s`,
            type: "info",
            link: `/executions/${dbExecutionId}`,
          });
        }
      } catch (notifErr) {
        log(`Failed to create completion notification: ${notifErr}`, "jmeter-worker");
      }
    }

    broadcastExecutionUpdate(dbExecutionId, "completed", resultSummary);
    log(`JMeter run ${runId} completed successfully`, "jmeter-worker");

    // Send email notification for test completion
    try {
      const scheduleName = execution?.schedule?.name || "Unknown Test";
      const config = execution?.schedule?.configuration as any;
      const baseUrl = process.env.APP_BASE_URL || `http://localhost:${process.env.PORT || 5000}`;
      const freshExecution = await storage.getExecution(dbExecutionId);
      await sendTestCompletionEmail({
        executionId: dbExecutionId,
        testName: scheduleName,
        status: "completed",
        startTime: execution?.startTime || new Date().toISOString(),
        endTime: new Date().toISOString(),
        resultSummary,
        slaViolations,
        dashboardBaseUrl: baseUrl,
        scheduleConfig: config,
        execution: freshExecution,
      });
    } catch (emailErr) {
      log(`Failed to send completion email: ${emailErr}`, "jmeter-worker");
    }

  } catch (error) {
    stopLiveMetrics(dbExecutionId);
    stopSystemMetrics(dbExecutionId);
    const message = error instanceof Error ? error.message : String(error);

    const currentExec = await storage.getExecution(dbExecutionId);
    const wasCancelled = currentExec?.status === 'cancelled';

    if (wasCancelled) {
      log(`JMeter run ${runId} was stopped/cancelled by user`, "jmeter-worker");
    } else {
      log(`JMeter run ${runId} failed: ${message}`, "jmeter-worker");
    }

    let partialSummary: any = wasCancelled ? { cancelled: true } : { error: message };
    try {
      const jtlPath = path.join(process.cwd(), "results", runId, "results.csv");
      if (fs.existsSync(jtlPath) && fs.statSync(jtlPath).size > 0) {
        log(`Parsing partial JTL results for ${wasCancelled ? 'cancelled' : 'failed'} run ${runId}...`, "jmeter-worker");
        const runDir = path.join(process.cwd(), "results", runId);
        const metrics = await parseJtlFile(jtlPath, runDir);
        if (metrics?.global?.total_requests > 0) {
          try {
            const { persistBucketsFromFile } = await import("./bucket-persistence");
            const rowCount = await persistBucketsFromFile(dbExecutionId, runDir);
            log(`Persisted ${rowCount} bucket rows to DB for ${wasCancelled ? 'cancelled' : 'failed'} execution ${dbExecutionId}`, "jmeter-worker");
          } catch (bucketErr: any) {
            log(`Warning: failed to persist buckets for ${wasCancelled ? 'cancelled' : 'failed'} execution ${dbExecutionId}: ${bucketErr.message}`, "jmeter-worker");
          }
          partialSummary = {
            ...(wasCancelled ? { cancelled: true } : { error: message }),
            totalRequests: metrics.global.total_requests || 0,
            successfulRequests: metrics.global.successes || 0,
            failedRequests: metrics.global.errors || 0,
            avgResponseTime: metrics.global.avg_ms || 0,
            minResponseTime: metrics.global.min_ms || 0,
            maxResponseTime: metrics.global.max_ms || 0,
            throughput: metrics.global.throughput_rps || 0,
            p50: metrics.global.p50_ms || 0,
            p90: metrics.global.p90_ms || 0,
            p95: metrics.global.p95_ms || 0,
            p99: metrics.global.p99_ms || 0,
            errorRate: metrics.global.error_rate || 0,
            durationSeconds: metrics.global.duration_sec || 0,
            transactionDetails: metrics.per_label?.map((label: any) => ({
              label: label.label, count: label.count, avg: label.avg,
              min: label.min, max: label.max, p50: label.p50, p90: label.p90,
              p95: label.p95, p99: label.p99, errorRate: label.error_rate,
              errorCount: label.error_count, throughput: label.throughput,
            })) || [],
            errorSummary: metrics.error_summary || [],
            timeseries: metrics.timeseries || [],
          };
          log(`Parsed partial results for ${wasCancelled ? 'cancelled' : 'failed'} run ${runId}: ${partialSummary.totalRequests} requests`, "jmeter-worker");
        }
      }
    } catch (parseErr) {
      log(`Could not parse partial results for run ${runId}: ${parseErr}`, "jmeter-worker");
    }

    if (wasCancelled) {
      await storage.updateExecution(dbExecutionId, {
        endTime: new Date().toISOString(),
        resultSummary: partialSummary,
      });
    } else {
      await storage.updateExecution(dbExecutionId, {
        status: "failed",
        endTime: new Date().toISOString(),
        resultSummary: partialSummary,
      });
    }

    const execution = await storage.getExecution(dbExecutionId);
    if (!wasCancelled && execution?.scheduleId) {
      await storage.updateSchedule(execution.scheduleId, { status: "failed" });
    }

    const scheduleCreatedBy = execution?.schedule?.createdBy;
    if (scheduleCreatedBy) {
      try {
        const shouldNotify = await storage.shouldSendNotification(scheduleCreatedBy, 'error');
        if (shouldNotify) {
          const scheduleName = execution?.schedule?.name || "Unknown";
          await storage.createNotification({
            userId: scheduleCreatedBy,
            title: "Test Execution Failed",
            message: `Test "${scheduleName}" failed: ${message.length > 120 ? message.slice(0, 120) + "..." : message}`,
            type: "error",
            link: `/executions/${dbExecutionId}`,
          });
        }
      } catch (notifErr) {
        log(`Failed to create failure notification: ${notifErr}`, "jmeter-worker");
      }
    }

    broadcastExecutionUpdate(dbExecutionId, "failed");

    // Send email notification for test failure
    if (!wasCancelled) {
      try {
        const scheduleName = execution?.schedule?.name || "Unknown Test";
        const config = (execution?.schedule?.configuration as any) || {};
        const baseUrl = process.env.APP_BASE_URL || `http://localhost:${process.env.PORT || 5000}`;
        const freshExecution = await storage.getExecution(dbExecutionId);
        await sendTestCompletionEmail({
          executionId: dbExecutionId,
          testName: scheduleName,
          status: "failed",
          startTime: execution?.startTime || new Date().toISOString(),
          endTime: new Date().toISOString(),
          resultSummary: partialSummary,
          dashboardBaseUrl: baseUrl,
          scheduleConfig: config,
          execution: freshExecution,
        });
      } catch (emailErr) {
        log(`Failed to send failure email: ${emailErr}`, "jmeter-worker");
      }
    }
  } finally {
    activeRuns.delete(dbExecutionId);
    processQueue();
  }
}

async function parseJtlFile(jtlPath: string, runDir: string): Promise<any> {
  const metricsPath = path.join(runDir, "metrics.json");
  const parserScript = path.join(process.cwd(), "scripts", "jtl_parser_full.py");

  if (!fs.existsSync(jtlPath)) {
    throw new Error(`JTL file not found: ${jtlPath}`);
  }

  if (!fs.existsSync(parserScript)) {
    throw new Error(`Parser script not found: ${parserScript}`);
  }

  return new Promise((resolve, reject) => {
    const pythonCmd = process.env.PYTHON_CMD || "python3";
    const proc = spawn(pythonCmd, [parserScript, jtlPath, "--out", metricsPath], {
      cwd: process.cwd(),
    });

    let stderr = "";
    const MAX_STDERR = 50 * 1024;
    proc.stderr?.on("data", (data) => {
      if (stderr.length < MAX_STDERR) {
        stderr += data.toString();
        if (stderr.length > MAX_STDERR) stderr = stderr.slice(-MAX_STDERR);
      }
    });
    proc.stdout?.on("data", () => {});
    proc.on("error", (err) => {
      reject(new Error(`Failed to spawn parser: ${err.message}`));
    });

    proc.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(`JTL parser failed with code ${code}: ${stderr}`));
        return;
      }

      try {
        const MAX_METRICS_SIZE = 500 * 1024 * 1024;
        const stat = fs.statSync(metricsPath);
        if (stat.size > MAX_METRICS_SIZE) {
          reject(new Error(`metrics.json too large (${Math.round(stat.size / 1024 / 1024)}MB > ${MAX_METRICS_SIZE / 1024 / 1024}MB limit)`));
          return;
        }
        const metricsStream = fs.createReadStream(metricsPath, { encoding: "utf-8" });
        let metricsJson = "";
        metricsStream.on("data", (chunk) => { metricsJson += chunk; });
        metricsStream.on("error", (err) => reject(new Error(`Failed to read metrics.json: ${err.message}`)));
        metricsStream.on("end", () => {
          try {
            const metrics = JSON.parse(metricsJson);
            resolve(metrics);
          } catch (parseErr) {
            reject(new Error(`Failed to parse metrics.json: ${parseErr}`));
          }
        });
      } catch (e) {
        reject(new Error(`Failed to read metrics.json: ${e}`));
      }
    });
  });
}

const cancellingRuns = new Set<number>();

export async function cancelRun(executionId: number): Promise<boolean> {
  if (cancellingRuns.has(executionId)) {
    log(`Cancel already in progress for execution ${executionId}, skipping`, "jmeter-worker");
    return false;
  }

  const queueIdx = runQueue.findIndex(q => q.dbExecutionId === executionId);
  if (queueIdx !== -1) {
    runQueue.splice(queueIdx, 1);
    log(`Removed execution ${executionId} from queue`, "jmeter-worker");
    return true;
  }

  const activeRun = activeRuns.get(executionId);
  if (activeRun && activeRun.process) {
    cancellingRuns.add(executionId);
    const { runId } = activeRun;
    stopLiveMetrics(executionId);
    stopSystemMetrics(executionId);
    forceKillProcess(activeRun.process);
    log(`Cancelled JMeter run ${runId} (execution ${executionId})`, "jmeter-worker");

    try {
      const jtlPath = path.join(process.cwd(), "results", runId, "results.csv");
      if (fs.existsSync(jtlPath) && fs.statSync(jtlPath).size > 0) {
        log(`Parsing partial results for cancelled run ${runId}...`, "jmeter-worker");
        const runDir = path.join(process.cwd(), "results", runId);
        const metrics = await parseJtlFile(jtlPath, runDir);
        if (metrics?.global?.total_requests > 0) {
          try {
            const { persistBucketsFromFile } = await import("./bucket-persistence");
            const rowCount = await persistBucketsFromFile(executionId, runDir);
            log(`Persisted ${rowCount} bucket rows to DB for cancelled execution ${executionId}`, "jmeter-worker");
          } catch (bucketErr: any) {
            log(`Warning: failed to persist buckets for cancelled execution ${executionId}: ${bucketErr.message}`, "jmeter-worker");
          }
          const partialSummary = {
            cancelled: true,
            totalRequests: metrics.global.total_requests || 0,
            successfulRequests: metrics.global.successes || 0,
            failedRequests: metrics.global.errors || 0,
            avgResponseTime: metrics.global.avg_ms || 0,
            minResponseTime: metrics.global.min_ms || 0,
            maxResponseTime: metrics.global.max_ms || 0,
            throughput: metrics.global.throughput_rps || 0,
            p50: metrics.global.p50_ms || 0,
            p90: metrics.global.p90_ms || 0,
            p95: metrics.global.p95_ms || 0,
            p99: metrics.global.p99_ms || 0,
            errorRate: metrics.global.error_rate || 0,
            durationSeconds: metrics.global.duration_sec || 0,
            transactionDetails: metrics.per_label?.map((label: any) => ({
              label: label.label, count: label.count, avg: label.avg,
              min: label.min, max: label.max, p50: label.p50, p90: label.p90,
              p95: label.p95, p99: label.p99, errorRate: label.error_rate,
              errorCount: label.error_count, throughput: label.throughput,
            })) || [],
            errorSummary: metrics.error_summary || [],
            timeseries: metrics.timeseries || [],
          };
          await storage.updateExecution(executionId, { resultSummary: partialSummary });
          log(`Saved partial results for cancelled run ${runId}: ${partialSummary.totalRequests} requests`, "jmeter-worker");
        }
      }
    } catch (parseErr) {
      log(`Could not parse partial results for cancelled run ${runId}: ${parseErr}`, "jmeter-worker");
    } finally {
      cancellingRuns.delete(executionId);
    }

    return true;
  }

  return false;
}

export async function cancelCurrentRun(): Promise<boolean> {
  if (activeRuns.size > 0) {
    const firstEntry = activeRuns.values().next().value as ActiveRun;
    return cancelRun(firstEntry.dbExecutionId);
  }
  return false;
}

export function getQueueStatus(): { queueLength: number; currentRunId: string | null; activeRuns: Array<{ executionId: number; runId: string }>; maxConcurrency: number } {
  return {
    queueLength: runQueue.length,
    currentRunId: activeRuns.size > 0 ? (activeRuns.values().next().value as ActiveRun).runId : null,
    activeRuns: Array.from(activeRuns.values()).map(r => ({ executionId: r.dbExecutionId, runId: r.runId })),
    maxConcurrency: MAX_CONCURRENT_RUNS,
  };
}

export async function cancelAllRuns(): Promise<void> {
  runQueue.length = 0;
  const cancelPromises: Promise<boolean>[] = [];
  const execIds = Array.from(activeRuns.keys());
  execIds.forEach((execId) => {
    cancelPromises.push(cancelRun(execId));
  });
  await Promise.allSettled(cancelPromises);
  log(`Cancelled all runs (${cancelPromises.length} active)`, "jmeter-worker");
}

export function getActiveRunCount(): number {
  return activeRuns.size;
}
