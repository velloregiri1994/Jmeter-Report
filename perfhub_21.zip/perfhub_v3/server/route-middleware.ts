import { type Request, type Response, type NextFunction } from "express";
import { storage } from "./storage";
import bcrypt from "bcrypt";

export const BCRYPT_ROUNDS = 12;
const ROLE_CACHE_TTL_MS = 30 * 1000;

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const sessionUser = (req.session as any)?.user;
  if (!sessionUser) {
    return res.status(401).json({ message: "Authentication required" });
  }
  next();
}

const WRITE_ROLES = new Set(['admin', 'engineer', 'lead', 'manager']);

export async function requireNonViewer(req: Request, res: Response, next: NextFunction) {
  const session = req.session as any;
  const sessionUser = session?.user;
  if (!sessionUser) {
    return res.status(401).json({ message: "Authentication required" });
  }

  const now = Date.now();
  const cachedRole = session.cachedRole;
  const cacheExpiry = session.roleCacheExpiry || 0;

  if (cachedRole && cacheExpiry > now) {
    if (!WRITE_ROLES.has(cachedRole)) {
      return res.status(403).json({ message: "Your role does not have write access" });
    }
    return next();
  }

  const user = await storage.getUser(sessionUser.id);
  if (!user) {
    return res.status(403).json({ message: "User not found" });
  }

  session.cachedRole = user.role;
  session.roleCacheExpiry = now + ROLE_CACHE_TTL_MS;

  if (!WRITE_ROLES.has(user.role)) {
    return res.status(403).json({ message: "Your role does not have write access" });
  }
  next();
}

export const requireEngineerOrAdmin = requireNonViewer;

export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const session = req.session as any;
  const sessionUser = session?.user;
  if (!sessionUser) {
    return res.status(401).json({ message: "Authentication required" });
  }

  const now = Date.now();
  const cachedRole = session.cachedRole;
  const cacheExpiry = session.roleCacheExpiry || 0;

  if (cachedRole && cacheExpiry > now) {
    if (cachedRole !== 'admin') {
      return res.status(403).json({ message: "Admin access required" });
    }
    return next();
  }

  const user = await storage.getUser(sessionUser.id);
  if (!user) {
    return res.status(403).json({ message: "User not found" });
  }

  session.cachedRole = user.role;
  session.roleCacheExpiry = now + ROLE_CACHE_TTL_MS;

  if (user.role !== 'admin') {
    return res.status(403).json({ message: "Admin access required" });
  }
  next();
}

export function sanitizeUser(user: any): any {
  if (!user) return user;
  const { password, ...safeUser } = user;
  return safeUser;
}

function normalizeResultSummary(summary: any): any {
  if (!summary || typeof summary !== 'object') return summary;
  const result = { ...summary };
  if (typeof result.errorRate === 'number' && result.errorRate > 1) {
    result.errorRate = result.errorRate / 100;
  }
  if (Array.isArray(result.transactionDetails)) {
    result.transactionDetails = result.transactionDetails.map((tx: any) => {
      if (typeof tx.errorRate === 'number' && tx.errorRate > 1) {
        return { ...tx, errorRate: tx.errorRate / 100 };
      }
      return tx;
    });
  }
  return result;
}

export function sanitizeResponse(data: any): any {
  if (!data) return data;
  if (data instanceof Date) return data;
  if (Array.isArray(data)) {
    return data.map(item => sanitizeResponse(item));
  }
  if (typeof data === 'object') {
    const result: any = {};
    for (const key in data) {
      if (data[key] instanceof Date) {
        result[key] = data[key];
      } else if (key === 'user' && data[key] && typeof data[key] === 'object') {
        result[key] = sanitizeUser(data[key]);
      } else if (key === 'comments' && Array.isArray(data[key])) {
        result[key] = data[key].map((comment: any) => ({
          ...comment,
          user: comment.user ? sanitizeUser(comment.user) : comment.user
        }));
      } else if (key === 'resultSummary' && data[key] && typeof data[key] === 'object') {
        result[key] = normalizeResultSummary(data[key]);
      } else if (typeof data[key] === 'object' && data[key] !== null) {
        result[key] = sanitizeResponse(data[key]);
      } else {
        result[key] = data[key];
      }
    }
    return result;
  }
  return data;
}

export function generateExecutionId(): string {
  const date = new Date();
  const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
  const timeStr = date.toISOString().slice(11, 19).replace(/:/g, '');
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `EXE-${dateStr}-${timeStr}-${random}`;
}

export const hashPassword = async (password: string): Promise<string> => {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
};

export const verifyPassword = async (password: string, hash: string): Promise<boolean> => {
  try {
    return await bcrypt.compare(password, hash);
  } catch {
    return false;
  }
};
