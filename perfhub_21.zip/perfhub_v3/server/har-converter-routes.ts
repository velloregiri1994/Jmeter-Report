import { Express, Request, Response } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { db } from "./db";
import { scriptGenerations, scripts } from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { requireAuth, requireEngineerOrAdmin } from "./route-middleware";
import { asyncHandler } from "./error-handler";
import { logger } from "./logger";
import { parseHarFile } from "./har-converter/har-parser";
import { filterEntries } from "./har-converter/request-filter";
import { detectCorrelations } from "./har-converter/correlation-detector";
import { detectParameterizations } from "./har-converter/parameterization-detector";
import { buildJmx } from "./har-converter/jmx-builder";
import { scoreScript } from "./har-converter/quality-scorer";
import { analyzeJmxFile } from "./har-converter/jmx-analyzer";
import { validateJmx } from "./har-converter/jmx-validator";

const UPLOAD_DIR = path.join(process.cwd(), "uploads", "har-temp");

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const fileUpload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 50 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext === ".har" || ext === ".jmx" || ext === ".xml" || file.mimetype === "application/json" || file.mimetype === "application/xml" || file.mimetype === "text/xml" || file.mimetype === "application/octet-stream") {
      cb(null, true);
    } else {
      cb(new Error("Only .har and .jmx files are accepted"));
    }
  },
});

function countTransactionGroups(entries: any[], pages: any[]): number {
  if (pages && pages.length > 0) {
    const pageRefs = new Set(entries.map((e: any) => e.pageref).filter(Boolean));
    const validPages = pages.filter((p: any) => pageRefs.has(p.id));
    if (validPages.length > 0) {
      const noPageEntries = entries.filter((e: any) => !e.pageref || !pageRefs.has(e.pageref));
      let noPageGroups = 0;
      if (noPageEntries.length > 0) {
        noPageGroups = 1;
        for (let i = 1; i < noPageEntries.length; i++) {
          const prevTs = noPageEntries[i - 1].startedDateTime ? new Date(noPageEntries[i - 1].startedDateTime).getTime() : 0;
          const currTs = noPageEntries[i].startedDateTime ? new Date(noPageEntries[i].startedDateTime).getTime() : 0;
          if (prevTs > 0 && currTs > 0 && (currTs - prevTs) > 2000) noPageGroups++;
        }
      }
      return validPages.length + noPageGroups;
    }
  }
  if (entries.length === 0) return 0;
  let groups = 1;
  for (let i = 1; i < entries.length; i++) {
    const prevTs = entries[i - 1].startedDateTime ? new Date(entries[i - 1].startedDateTime).getTime() : 0;
    const currTs = entries[i].startedDateTime ? new Date(entries[i].startedDateTime).getTime() : 0;
    if (prevTs > 0 && currTs > 0 && (currTs - prevTs) > 2000) groups++;
  }
  return groups;
}

async function processHarFile(
  filePath: string,
  name: string,
  userId: number,
  generationId: number,
  options: { threadCount: number; rampUp: number; duration: number; includeDomains?: string[]; excludeDomains?: string[] }
) {
  try {
    logger.info(`Starting HAR conversion for generation ${generationId}`, "har-converter");

    const harResult = await parseHarFile(filePath);
    const totalEntries = harResult.entries.length;

    const domainOptions = {
      includeDomains: options.includeDomains,
      excludeDomains: options.excludeDomains,
    };
    const filterResult = filterEntries(harResult.entries, domainOptions);
    const filteredEntries = filterResult.entries;

    logger.info(`Domain detection: primary=${filterResult.stats.primaryDomains.join(', ')} | filtered ${filterResult.stats.removedByThirdParty} third-party, ${filterResult.stats.removedByMimeType} static-mime, ${filterResult.stats.removedByExtension} static-ext, ${filterResult.stats.removedByPreflight} preflight, ${filterResult.stats.removedByStatus} bad-status | kept ${filteredEntries.length}/${totalEntries}`, "har-converter");

    if (filteredEntries.length === 0) {
      await db.update(scriptGenerations).set({
        status: "failed",
        errorMessage: "No valid API requests found after filtering static resources and third-party domains. The HAR file may contain only static assets.",
        stats: {
          totalEntries,
          filteredEntries: 0,
          transactionGroups: 0,
          requestCount: 0,
          domains: [],
        },
      }).where(eq(scriptGenerations.id, generationId));
      return;
    }

    const correlations = detectCorrelations(filteredEntries);

    const correlatedValues = correlations.map(c => c.originalValue);
    const { parameterizations, csvContent } = detectParameterizations(filteredEntries, correlatedValues);

    const domains = [...new Set(filteredEntries.map(e => e.url.domain))];
    const transactionGroups = countTransactionGroups(filteredEntries, harResult.pages);

    const csvFileName = parameterizations.length > 0 ? `${name.replace(/\s+/g, '_')}_data.csv` : undefined;

    const jmxContent = buildJmx({
      entries: filteredEntries,
      pages: harResult.pages,
      correlations,
      parameterizations,
      options: {
        threadCount: options.threadCount,
        rampUp: options.rampUp,
        duration: options.duration,
        testName: name,
      },
      csvFileName,
    });

    const jmxValidation = validateJmx(jmxContent);
    if (!jmxValidation.valid) {
      const errorSummary = jmxValidation.errors.map(e => `[${e.code}] ${e.message} (at ${e.path})`).join('; ');
      logger.error(`JMX validation failed for generation ${generationId}: ${errorSummary}`, "har-converter");
      await db.update(scriptGenerations).set({
        status: "failed",
        errorMessage: `Generated JMX failed structural validation: ${jmxValidation.errors[0]?.message || 'Unknown validation error'}`,
      }).where(eq(scriptGenerations.id, generationId));
      return;
    }

    if (jmxValidation.warnings.length > 0) {
      logger.warn(`JMX validation warnings for generation ${generationId}: ${jmxValidation.warnings.map(w => w.message).join('; ')}`, "har-converter");
    }

    logger.info(`JMX validation passed for generation ${generationId} (${jmxValidation.warnings.length} warnings)`, "har-converter");

    const assertionCount = filteredEntries.filter(e =>
      (e.responseStatus >= 200 && e.responseStatus < 300) ||
      (e.responseStatus >= 400 && e.responseStatus < 600)
    ).length;

    const qualityResult = scoreScript({
      filteredEntries,
      filterStats: filterResult.stats,
      correlations,
      parameterizations,
      transactionGroupCount: transactionGroups,
      assertionCount,
      hasCookieManager: true,
      hasHttpDefaults: true,
      hasKeepalive: true,
      hasTimeouts: true,
    });

    const storedCsvContent = (csvFileName && csvContent) ? csvContent : null;

    const issues: Array<{ severity: string; message: string; request?: string }> = [];

    filteredEntries.forEach((entry, i) => {
      if (entry.url.protocol === "ws" || entry.url.protocol === "wss") {
        issues.push({ severity: "warning", message: "WebSocket request detected — requires JMeter WebSocket plugin", request: `${entry.method} ${entry.url.path}` });
      }
      if (entry.postData?.mimeType?.includes("multipart/form-data")) {
        const hasFile = entry.postData.params?.some(p => p.fileName);
        if (hasFile) {
          issues.push({ severity: "info", message: "File upload detected — you may need to configure CSV Data Set Config for file paths", request: `${entry.method} ${entry.url.path}` });
        }
      }
    });

    if (correlations.length === 0 && filteredEntries.length > 3) {
      issues.push({ severity: "info", message: "No dynamic values detected for correlation. If the application uses sessions or tokens, verify the HAR includes response bodies." });
    }

    if (parameterizations.length === 0) {
      issues.push({ severity: "info", message: "No credentials or repeated values detected for parameterization. Consider adding CSV Data Set Config manually if needed." });
    }

    const redirectCount = filterResult.redirectChains.length;
    if (redirectCount > 0) {
      issues.push({ severity: "info", message: `${redirectCount} redirect chain(s) detected and consolidated. JMeter will follow redirects automatically.` });
    }

    for (const w of jmxValidation.warnings) {
      issues.push({ severity: "warning", message: `JMX structure: ${w.message}` });
    }

    await db.update(scriptGenerations).set({
      status: "completed",
      generatedJmxContent: jmxContent,
      sampleCsvContent: storedCsvContent,
      correlations: correlations.map(c => {
        const srcEntry = filteredEntries.find(e => e.index === c.sourceRequest);
        return {
          variable: c.variable,
          extractorType: c.extractorType,
          pattern: c.pattern,
          sourceRequest: srcEntry ? `${srcEntry.method} ${srcEntry.url.path}` : `request #${c.sourceRequest}`,
          targetRequests: c.targetRequests.map(t => {
            const tgtEntry = filteredEntries.find(e => e.index === t);
            return tgtEntry ? `${tgtEntry.method} ${tgtEntry.url.path}` : `request #${t}`;
          }),
          originalValue: c.originalValue.length > 80 ? c.originalValue.substring(0, 80) + "..." : c.originalValue,
        };
      }),
      parameterizations: parameterizations.map(p => ({
        variable: p.variable,
        originalValue: p.originalValue.length > 20 ? p.originalValue.substring(0, 3) + "***" : "***",
        occurrences: p.occurrences,
      })),
      issues,
      qualityScore: qualityResult.score,
      readinessLevel: qualityResult.readinessLevel,
      stats: {
        totalEntries,
        filteredEntries: filteredEntries.length,
        transactionGroups: transactionGroups,
        requestCount: filteredEntries.length,
        domains,
      },
    }).where(eq(scriptGenerations.id, generationId));

    logger.info(`HAR conversion completed for generation ${generationId}: score=${qualityResult.score}, requests=${filteredEntries.length}`, "har-converter");

  } catch (err: any) {
    logger.error(`HAR conversion failed for generation ${generationId}: ${err.message}`, "har-converter", { stack: err.stack });
    await db.update(scriptGenerations).set({
      status: "failed",
      errorMessage: err.message || "Unknown error during conversion",
    }).where(eq(scriptGenerations.id, generationId));
  } finally {
    try {
      if (fs.existsSync(filePath)) await fs.promises.unlink(filePath);
    } catch {}
  }
}

async function processJmxFile(
  filePath: string,
  name: string,
  userId: number,
  generationId: number
) {
  try {
    logger.info(`Starting JMX analysis for generation ${generationId}`, "har-converter");

    const analysis = analyzeJmxFile(filePath);

    const jmxContent = await fs.promises.readFile(filePath, "utf-8");

    const jmxValidation = validateJmx(jmxContent);
    if (jmxValidation.errors.length > 0) {
      logger.warn(`JMX validation errors for uploaded file (generation ${generationId}): ${jmxValidation.errors.map(e => `[${e.code}] ${e.message}`).join('; ')}`, "har-converter");
    }
    if (jmxValidation.warnings.length > 0) {
      logger.info(`JMX validation warnings for uploaded file (generation ${generationId}): ${jmxValidation.warnings.map(w => w.message).join('; ')}`, "har-converter");
    }

    const validationIssues = [
      ...jmxValidation.errors.map(e => ({
        type: "error" as const,
        message: e.message,
        code: e.code,
      })),
      ...jmxValidation.warnings.map(w => ({
        type: "warning" as const,
        message: w.message,
        code: w.code,
      })),
    ];

    let qualityScore = 0;
    const breakdown: Array<{ category: string; score: number; maxScore: number; details: string }> = [];

    let transactionScore = 0;
    if (analysis.transactionGroups > 1) transactionScore = 15;
    else if (analysis.transactionGroups === 1) transactionScore = 8;
    breakdown.push({ category: "Transaction Grouping", score: transactionScore, maxScore: 15, details: `${analysis.transactionGroups} transaction group(s) found` });

    let correlationScore = 0;
    if (analysis.correlations.length > 0) correlationScore = 25;
    breakdown.push({ category: "Correlation Completeness", score: correlationScore, maxScore: 25, details: analysis.correlations.length > 0 ? `${analysis.correlations.length} extractor(s) found` : "No extractors (correlations) found" });

    let paramScore = 0;
    if (analysis.parameterizations.length > 0) paramScore = 15;
    breakdown.push({ category: "Parameterization", score: paramScore, maxScore: 15, details: analysis.parameterizations.length > 0 ? `${analysis.parameterizations.length} CSV variable(s) configured` : "No CSV Data Set Config found" });

    let assertionScore = analysis.hasAssertions ? 10 : 0;
    breakdown.push({ category: "Assertions", score: assertionScore, maxScore: 10, details: analysis.hasAssertions ? "Assertions present on requests" : "No assertions configured" });

    let bestPracticeScore = 0;
    const bpDetails: string[] = [];
    if (analysis.hasCookieManager) { bestPracticeScore += 3; bpDetails.push("Cookie Manager"); }
    if (analysis.hasHttpDefaults) { bestPracticeScore += 3; bpDetails.push("HTTP Defaults"); }
    if (analysis.hasKeepalive) { bestPracticeScore += 2; bpDetails.push("Keep-Alive"); }
    if (analysis.hasTimeouts) { bestPracticeScore += 2; bpDetails.push("Timeouts"); }
    breakdown.push({ category: "Best Practice Config", score: bestPracticeScore, maxScore: 10, details: bpDetails.length > 0 ? `Configured: ${bpDetails.join(", ")}` : "No best practice configurations found" });

    let timerScore = analysis.hasTimers ? 10 : 0;
    breakdown.push({ category: "Think Time", score: timerScore, maxScore: 10, details: analysis.hasTimers ? "Think time timers present" : "No think time timers configured" });

    let staticScore = 15;
    breakdown.push({ category: "Static Content Removal", score: staticScore, maxScore: 15, details: "N/A for direct JMX analysis (already a JMeter script)" });

    qualityScore = Math.min(breakdown.reduce((sum, b) => sum + b.score, 0), 100);

    const readinessLevel = qualityScore >= 80 ? "Production Ready" : qualityScore >= 60 ? "Good" : qualityScore >= 40 ? "Moderate" : "Poor";

    await db.update(scriptGenerations).set({
      status: "completed",
      generatedJmxContent: jmxContent,
      sampleCsvContent: null,
      correlations: analysis.correlations.map(c => ({
        variable: c.variable,
        extractorType: c.extractorType,
        pattern: c.pattern,
        sourceRequest: c.sourceRequest,
        targetRequests: c.targetRequests,
        originalValue: c.originalValue,
      })),
      parameterizations: analysis.parameterizations.map(p => ({
        variable: p.variable,
        originalValue: p.originalValue,
        occurrences: p.occurrences,
      })),
      issues: [...analysis.issues, ...validationIssues],
      qualityScore,
      readinessLevel,
      stats: {
        totalEntries: analysis.requestCount,
        filteredEntries: analysis.requestCount,
        transactionGroups: analysis.transactionGroups,
        requestCount: analysis.requestCount,
        domains: analysis.domains,
      },
    }).where(eq(scriptGenerations.id, generationId));

    logger.info(`JMX analysis completed for generation ${generationId}: score=${qualityScore}, requests=${analysis.requestCount}`, "har-converter");

  } catch (err: any) {
    logger.error(`JMX analysis failed for generation ${generationId}: ${err.message}`, "har-converter", { stack: err.stack });
    await db.update(scriptGenerations).set({
      status: "failed",
      errorMessage: err.message || "Unknown error during JMX analysis",
    }).where(eq(scriptGenerations.id, generationId));
  } finally {
    try {
      if (fs.existsSync(filePath)) await fs.promises.unlink(filePath);
    } catch {}
  }
}

function checkOwnership(generation: any, req: Request): boolean {
  const sessionUser = (req.session as any)?.user;
  const userId = sessionUser?.id;
  const role = sessionUser?.role;
  return generation.userId === userId || role === "admin";
}

export function registerHarConverterRoutes(app: Express) {

  app.post("/api/har-converter/upload", requireEngineerOrAdmin, fileUpload.single("harFile"), asyncHandler(async (req: Request, res: Response) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const ext = path.extname(req.file.originalname).toLowerCase();
    const isJmx = ext === ".jmx" || ext === ".xml";

    const name = (req.body.name || "Untitled Script").trim().substring(0, 200);
    const threadCount = Math.min(Math.max(parseInt(req.body.threadCount) || 10, 1), 10000);
    const rampUp = Math.min(Math.max(parseInt(req.body.rampUp) || 60, 0), 86400);
    const duration = Math.min(Math.max(parseInt(req.body.duration) || 300, 0), 86400);
    const includeDomains = req.body.includeDomains ? req.body.includeDomains.split(',').map((d: string) => d.trim()).filter((d: string) => d) : undefined;
    const excludeDomains = req.body.excludeDomains ? req.body.excludeDomains.split(',').map((d: string) => d.trim()).filter((d: string) => d) : undefined;
    const userId = (req.session as any)?.user?.id;

    const [generation] = await db.insert(scriptGenerations).values({
      name,
      status: "processing",
      inputType: isJmx ? "jmx" : "har",
      inputFileName: req.file.originalname,
      inputFileSize: req.file.size,
      userId,
    }).returning();

    if (isJmx) {
      setImmediate(() => {
        processJmxFile(req.file!.path, name, userId, generation.id);
      });
      res.status(201).json({
        id: generation.id,
        status: "processing",
        message: "JMX file uploaded and analysis started",
      });
    } else {
      setImmediate(() => {
        processHarFile(req.file!.path, name, userId, generation.id, { threadCount, rampUp, duration, includeDomains, excludeDomains });
      });
      res.status(201).json({
        id: generation.id,
        status: "processing",
        message: "HAR file uploaded and processing started",
      });
    }
  }));

  app.get("/api/har-converter/generations", requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const userId = (req.session as any)?.user?.id;
    const generations = await db.select({
      id: scriptGenerations.id,
      name: scriptGenerations.name,
      status: scriptGenerations.status,
      inputType: scriptGenerations.inputType,
      inputFileName: scriptGenerations.inputFileName,
      inputFileSize: scriptGenerations.inputFileSize,
      qualityScore: scriptGenerations.qualityScore,
      readinessLevel: scriptGenerations.readinessLevel,
      scriptId: scriptGenerations.scriptId,
      errorMessage: scriptGenerations.errorMessage,
      createdAt: scriptGenerations.createdAt,
    }).from(scriptGenerations)
      .where(eq(scriptGenerations.userId, userId))
      .orderBy(desc(scriptGenerations.createdAt))
      .limit(50);
    res.json(generations);
  }));

  app.get("/api/har-converter/generations/:id", requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid generation ID" });

    const [generation] = await db.select().from(scriptGenerations).where(eq(scriptGenerations.id, id));
    if (!generation) return res.status(404).json({ message: "Generation not found" });

    if (!checkOwnership(generation, req)) {
      return res.status(403).json({ message: "Access denied" });
    }

    const hasJmxContent = !!(generation.generatedJmxContent || generation.generatedJmxPath);
    const hasCsvContent = !!(generation.sampleCsvContent || generation.sampleCsvPath);

    const { generatedJmxContent: _jmx, sampleCsvContent: _csv, generatedJmxPath: _jmxP, sampleCsvPath: _csvP, ...rest } = generation;
    res.json({
      ...rest,
      hasJmxContent,
      hasCsvContent,
    });
  }));

  app.get("/api/har-converter/generations/:id/download", requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid generation ID" });

    const [generation] = await db.select().from(scriptGenerations).where(eq(scriptGenerations.id, id));
    if (!generation) {
      return res.status(404).json({ message: "Generation not found" });
    }

    if (!checkOwnership(generation, req)) {
      return res.status(403).json({ message: "Access denied" });
    }

    const jmxContent = generation.generatedJmxContent
      || (generation.generatedJmxPath && fs.existsSync(generation.generatedJmxPath) ? await fs.promises.readFile(generation.generatedJmxPath, "utf-8") : null);

    if (!jmxContent) {
      return res.status(404).json({ message: "Generated JMX file not found" });
    }

    const fileName = `${generation.name.replace(/[^a-zA-Z0-9_-]/g, '_')}.jmx`;
    res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
    res.setHeader("Content-Type", "application/xml");
    res.send(jmxContent);
  }));

  app.get("/api/har-converter/generations/:id/download-csv", requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid generation ID" });

    const [generation] = await db.select().from(scriptGenerations).where(eq(scriptGenerations.id, id));
    if (!generation) {
      return res.status(404).json({ message: "Generation not found" });
    }

    if (!checkOwnership(generation, req)) {
      return res.status(403).json({ message: "Access denied" });
    }

    const csvContent = generation.sampleCsvContent
      || (generation.sampleCsvPath && fs.existsSync(generation.sampleCsvPath) ? await fs.promises.readFile(generation.sampleCsvPath, "utf-8") : null);

    if (!csvContent) {
      return res.status(404).json({ message: "Sample CSV file not found" });
    }

    const fileName = `${generation.name.replace(/[^a-zA-Z0-9_-]/g, '_')}_data.csv`;
    res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
    res.setHeader("Content-Type", "text/csv");
    res.send(csvContent);
  }));

  app.post("/api/har-converter/generations/:id/save-as-script", requireEngineerOrAdmin, asyncHandler(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid generation ID" });

    const [generation] = await db.select().from(scriptGenerations).where(eq(scriptGenerations.id, id));
    if (!generation || generation.status !== "completed") {
      return res.status(400).json({ message: "Generation is not completed" });
    }

    const jmxContent = generation.generatedJmxContent
      || (generation.generatedJmxPath && fs.existsSync(generation.generatedJmxPath) ? await fs.promises.readFile(generation.generatedJmxPath, "utf-8") : null);

    if (!jmxContent) {
      return res.status(400).json({ message: "JMX content not available" });
    }

    if (!checkOwnership(generation, req)) {
      return res.status(403).json({ message: "Access denied" });
    }

    if (generation.scriptId) {
      return res.status(400).json({ message: "This generation has already been saved as a script" });
    }

    const scriptName = (req.body.name || generation.name).trim().substring(0, 200);
    const description = (req.body.description || "").trim().substring(0, 2000);
    const folderId = req.body.folderId ? parseInt(req.body.folderId) : null;
    const projectId = req.body.projectId ? parseInt(req.body.projectId) : null;
    const userId = (req.session as any)?.user?.id;

    const timestamp = Date.now();
    const sanitizedName = scriptName.replace(/[^a-zA-Z0-9_-]/g, '_');
    const destDir = path.join(process.cwd(), "uploads", "scripts");
    if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });

    const [script] = await db.insert(scripts).values({
      name: scriptName,
      description: description || `${generation.inputType === 'jmx' ? 'Imported from' : 'Generated from HAR file:'} ${generation.inputFileName || 'unknown'}`,
      toolType: "JMeter",
      uploadedBy: userId,
      folderId,
      projectId,
    }).returning();

    const destFileName = `${script.id}_${timestamp}_${sanitizedName}.jmx`;
    const destPath = path.join(destDir, destFileName);
    await fs.promises.writeFile(destPath, jmxContent, "utf-8");

    await db.update(scripts).set({ filePath: destPath }).where(eq(scripts.id, script.id));

    let dependencyFiles: any[] = [];
    const csvContent = generation.sampleCsvContent
      || (generation.sampleCsvPath && fs.existsSync(generation.sampleCsvPath) ? await fs.promises.readFile(generation.sampleCsvPath, "utf-8") : null);

    if (csvContent) {
      const depDir = path.join(process.cwd(), "uploads", "dependencies", String(script.id));
      if (!fs.existsSync(depDir)) fs.mkdirSync(depDir, { recursive: true });
      const csvBaseName = `${generation.name.replace(/[^a-zA-Z0-9_-]/g, '_')}_data.csv`;
      const depPath = path.join(depDir, csvBaseName);
      await fs.promises.writeFile(depPath, csvContent, "utf-8");
      dependencyFiles.push({
        originalName: csvBaseName,
        storedPath: depPath,
        size: Buffer.byteLength(csvContent, "utf-8"),
        uploadedAt: new Date().toISOString(),
      });
      await db.update(scripts).set({ dependencyFiles }).where(eq(scripts.id, script.id));
    }

    await db.update(scriptGenerations).set({ scriptId: script.id }).where(eq(scriptGenerations.id, id));

    logger.info(`HAR generation ${id} saved as script ${script.id}: ${scriptName}`, "har-converter");

    res.json({
      scriptId: script.id,
      message: "Script saved successfully",
    });
  }));

  app.delete("/api/har-converter/generations/:id", requireEngineerOrAdmin, asyncHandler(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid generation ID" });

    const [generation] = await db.select().from(scriptGenerations).where(eq(scriptGenerations.id, id));
    if (!generation) return res.status(404).json({ message: "Generation not found" });

    if (!checkOwnership(generation, req)) {
      return res.status(403).json({ message: "Access denied" });
    }

    if (generation.generatedJmxPath && fs.existsSync(generation.generatedJmxPath)) {
      try { await fs.promises.unlink(generation.generatedJmxPath); } catch {}
    }
    if (generation.sampleCsvPath && fs.existsSync(generation.sampleCsvPath)) {
      try { await fs.promises.unlink(generation.sampleCsvPath); } catch {}
    }

    await db.delete(scriptGenerations).where(eq(scriptGenerations.id, id));

    res.json({ message: "Generation deleted" });
  }));
}
