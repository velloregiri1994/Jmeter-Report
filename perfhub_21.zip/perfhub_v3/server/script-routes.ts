import express, { type Express } from "express";
import fs from "fs";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { requireAuth, requireEngineerOrAdmin } from "./route-middleware";
import { cacheService, CACHE_KEYS, CACHE_TTL } from "./cache";
import { parseJMXContent, updateThreadGroupsInXml, parseTimersFromContent, updateTimersInXml, type ThreadGroupUpdate, type TimerUpdate, detectPlugins, resolveScriptPath } from "./jmx-parser";
import { parseThreadGroupsWithAdapters, updateThreadGroupWithAdapter } from "./thread-group-adapters";
import { validate, z, idParam, scriptIdParam } from "./validation";
import { asyncHandler } from "./error-handler";

const uploadBodySchema = z.object({
  fileContent: z.string().min(1),
  fileName: z.string().min(1),
});

const contentBodySchema = z.object({
  content: z.string().min(1, "Content must be a non-empty string"),
});

const threadGroupBodySchema = z.object({
  index: z.number().int().min(0, "A valid thread group index is required"),
  values: z.record(z.unknown()).refine(v => v !== null, "Values object is required"),
});

const timerUpdateSchema = z.object({
  index: z.number().int(),
  throughput: z.number().positive("Throughput must be greater than 0"),
  calcMode: z.number().int().min(0).max(5, "Invalid calculation mode"),
  enabled: z.boolean(),
});

const timersBodySchema = z.object({
  updates: z.array(timerUpdateSchema).min(1, "Updates must be a non-empty array"),
});

const dependenciesBodySchema = z.object({
  files: z.array(z.object({
    fileName: z.string(),
    fileContent: z.string(),
  })).min(1, "At least one file is required"),
});

const fileNameParam = scriptIdParam.merge(z.object({
  fileName: z.string().min(1),
}));

export function registerScriptRoutes(app: Express): void {

  app.get(api.scripts.list.path, requireAuth, asyncHandler(async (req, res) => {
    const { folderId, page, pageSize, search, protocol } = req.query as any;

    const filterExternalPlaceholders = (scripts: any[]) => 
      scripts.filter(s => s.name !== "External Test");

    if (page || search || protocol) {
      const result = await storage.getScriptsPaginated({
        page: page ? Number(page) : 1,
        pageSize: pageSize ? Number(pageSize) : 50,
        search: search || undefined,
        protocol: protocol || undefined,
        folderId: folderId !== undefined ? (folderId === "null" ? null : Number(folderId)) : undefined,
      });
      result.data = filterExternalPlaceholders(result.data);
      return res.json(result);
    }

    const cacheKey = folderId !== undefined 
      ? `${CACHE_KEYS.SCRIPTS_LIST}:folder:${folderId}` 
      : CACHE_KEYS.SCRIPTS_LIST;
    
    const cached = await cacheService.get<any[]>(cacheKey);
    if (cached) {
      return res.json(cached);
    }
    
    if (folderId !== undefined) {
      const scripts = await storage.getScriptsByFolder(folderId === "null" ? null : Number(folderId));
      const filtered = filterExternalPlaceholders(scripts);
      await cacheService.set(cacheKey, filtered, CACHE_TTL.SCRIPTS_LIST);
      return res.json(filtered);
    }
    const scripts = await storage.getScripts();
    const filtered = filterExternalPlaceholders(scripts);
    await cacheService.set(cacheKey, filtered, CACHE_TTL.SCRIPTS_LIST);
    res.json(filtered);
  }));

  app.post(api.scripts.create.path, requireEngineerOrAdmin, validate({ body: z.object({
    name: z.string().min(1, "Script name is required").max(255),
    description: z.string().max(1000).optional(),
    toolType: z.enum(["JMeter", "LoadRunner"], { message: "Invalid tool type" }),
    protocol: z.enum(["http", "websocket", "graphql", "grpc", "mqtt", "jms", "mixed"]).optional(),
    folderId: z.number().int().positive().optional().nullable(),
  }) }), asyncHandler(async (req, res) => {
    const script = await storage.createScript(req.body);
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    res.status(201).json(script);
  }));

  app.get(api.scripts.get.path, requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const script = await storage.getScript(id);
    if (!script) return res.status(404).json({ message: "Script not found" });
    res.json(script);
  }));

  app.patch("/api/scripts/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const { folderId } = req.body;
    if (folderId !== undefined && folderId !== null) {
      const folder = await storage.getFolder(Number(folderId));
      if (!folder) return res.status(400).json({ message: "Folder not found" });
    }
    const script = await storage.updateScript(id, req.body);
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    res.json(script);
  }));

  app.delete("/api/scripts/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const script = await storage.getScript(id);
    if (!script) return res.status(404).json({ message: "Script not found" });
    await storage.deleteScript(id);
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    res.sendStatus(204);
  }));

  app.post("/api/scripts/:scriptId/upload", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: uploadBodySchema }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    
    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    
    const { fileContent, fileName } = req.body;
    
    const fs = await import('fs');
    const pathModule = await import('path');
    const uploadsDir = pathModule.join(process.cwd(), 'uploads', 'scripts');
    
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }
    
    const sanitizedFileName = pathModule.basename(fileName).replace(/[^a-zA-Z0-9._-]/g, '_');
    
    if (fileContent.length > 1024 * 1024) {
      return res.status(400).json({ message: "File too large. Maximum size is 1MB." });
    }
    
    const ext = pathModule.extname(sanitizedFileName).toLowerCase();
    
    if (ext !== '.jmx') {
      return res.status(400).json({ 
        message: `Invalid file type. Only .jmx files are supported, got: ${ext || 'no extension'}` 
      });
    }
    
    const uniqueFileName = `${scriptId}_${Date.now()}_${sanitizedFileName}`;
    const filePath = pathModule.join('uploads', 'scripts', uniqueFileName);
    
    fs.writeFileSync(pathModule.join(process.cwd(), filePath), fileContent, 'utf-8');
    
    const userId = (req.session as any)?.user?.id || 1;
    const updatedScript = await storage.updateScript(scriptId, {
      filePath,
      uploadedBy: userId
    });
    
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    
    res.json(updatedScript);
  }));

  app.get("/api/scripts/:scriptId/content", requireAuth, validate({ params: scriptIdParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;

    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    if (!script.filePath) return res.status(404).json({ message: "No script file uploaded" });

    const pathModule = await import('path');
    const fullPath = pathModule.join(process.cwd(), script.filePath);

    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ message: "Script file not found on disk" });
    }

    if (!fullPath.startsWith(pathModule.join(process.cwd(), 'uploads'))) {
      return res.status(400).json({ message: "Invalid file path" });
    }

    const content = fs.readFileSync(fullPath, 'utf-8');
    res.json({ content, fileName: pathModule.basename(script.filePath) });
  }));

  app.put("/api/scripts/:scriptId/content", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: contentBodySchema }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;

    const { content } = req.body;

    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    if (!script.filePath) return res.status(404).json({ message: "No script file to update" });

    const pathModule = await import('path');
    const fullPath = pathModule.join(process.cwd(), script.filePath);

    if (!fullPath.startsWith(pathModule.join(process.cwd(), 'uploads'))) {
      return res.status(400).json({ message: "Invalid file path" });
    }

    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ message: "Script file not found on disk" });
    }

    const backupPath = fullPath + '.bak';
    fs.copyFileSync(fullPath, backupPath);

    try {
      fs.writeFileSync(fullPath, content, 'utf-8');
      await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
      res.json({ message: "Script saved successfully" });
    } catch (err) {
      if (fs.existsSync(backupPath)) {
        fs.copyFileSync(backupPath, fullPath);
      }
      throw err;
    }
  }));

  app.get("/api/scripts/:scriptId/thread-groups", requireAuth, validate({ params: scriptIdParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;

    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    if (!script.filePath) return res.status(404).json({ message: "No script file uploaded" });

    const pathModule = await import('path');
    const fullPath = pathModule.join(process.cwd(), script.filePath);

    if (!fullPath.startsWith(pathModule.join(process.cwd(), 'uploads'))) {
      return res.status(400).json({ message: "Invalid file path" });
    }
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ message: "Script file not found on disk" });
    }

    const content = fs.readFileSync(fullPath, 'utf-8');

    try {
      const threadGroups = parseThreadGroupsWithAdapters(content);
      const config = parseJMXContent(content);
      const testName = config?.testName || 'JMeter Test Plan';
      res.json({ threadGroups, testName });
    } catch (err) {
      return res.status(400).json({ message: "Failed to parse JMX file" });
    }
  }));

  app.put("/api/scripts/:scriptId/thread-groups", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: threadGroupBodySchema }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;

    const { index, values } = req.body;

    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    if (!script.filePath) return res.status(404).json({ message: "No script file to update" });

    const pathModule = await import('path');
    const fullPath = pathModule.join(process.cwd(), script.filePath);

    if (!fullPath.startsWith(pathModule.join(process.cwd(), 'uploads'))) {
      return res.status(400).json({ message: "Invalid file path" });
    }
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ message: "Script file not found on disk" });
    }

    const originalContent = fs.readFileSync(fullPath, 'utf-8');
    const backupPath = fullPath + '.bak';
    fs.copyFileSync(fullPath, backupPath);

    try {
      const { xml: updatedXml, errors } = updateThreadGroupWithAdapter(originalContent, index, values);

      if (errors.length > 0) {
        return res.status(400).json({ message: errors.join('; '), errors });
      }

      const verifyConfig = parseJMXContent(updatedXml);
      if (!verifyConfig) {
        fs.copyFileSync(backupPath, fullPath);
        return res.status(500).json({ message: "Generated XML is invalid. Changes rolled back." });
      }

      fs.writeFileSync(fullPath, updatedXml, 'utf-8');
      await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);

      const threadGroups = parseThreadGroupsWithAdapters(updatedXml);
      res.json({ message: "Thread group configuration saved", threadGroups });
    } catch (err) {
      if (fs.existsSync(backupPath)) {
        fs.copyFileSync(backupPath, fullPath);
      }
      throw err;
    }
  }));

  app.get("/api/scripts/:scriptId/timers", requireAuth, validate({ params: scriptIdParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;

    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    if (!script.filePath) return res.status(404).json({ message: "No script file uploaded" });

    const pathModule = await import('path');
    const fullPath = pathModule.join(process.cwd(), script.filePath);
    if (!fullPath.startsWith(pathModule.join(process.cwd(), 'uploads'))) {
      return res.status(400).json({ message: "Invalid file path" });
    }
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ message: "Script file not found on disk" });
    }

    const content = fs.readFileSync(fullPath, 'utf-8');
    const result = parseTimersFromContent(content);
    if (!result) return res.status(400).json({ message: "Failed to parse JMX file" });

    res.json(result);
  }));

  app.put("/api/scripts/:scriptId/timers", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: timersBodySchema }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;

    const { updates } = req.body;

    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    if (!script.filePath) return res.status(404).json({ message: "No script file to update" });

    const pathModule = await import('path');
    const fullPath = pathModule.join(process.cwd(), script.filePath);
    if (!fullPath.startsWith(pathModule.join(process.cwd(), 'uploads'))) {
      return res.status(400).json({ message: "Invalid file path" });
    }
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ message: "Script file not found on disk" });
    }

    const originalContent = fs.readFileSync(fullPath, 'utf-8');
    const backupPath = fullPath + '.bak';
    fs.copyFileSync(fullPath, backupPath);

    try {
      const updatedXml = updateTimersInXml(originalContent, updates as TimerUpdate[]);

      const verifyConfig = parseJMXContent(updatedXml);
      if (!verifyConfig) {
        fs.copyFileSync(backupPath, fullPath);
        return res.status(500).json({ message: "Generated XML is invalid. Changes rolled back." });
      }

      fs.writeFileSync(fullPath, updatedXml, 'utf-8');
      await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);

      const timerResult = parseTimersFromContent(updatedXml);
      res.json({ message: "Timer configuration saved", timers: timerResult?.timers || [] });
    } catch (err) {
      if (fs.existsSync(backupPath)) {
        fs.copyFileSync(backupPath, fullPath);
      }
      throw err;
    }
  }));

  app.post("/api/scripts/:scriptId/dependencies", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: dependenciesBodySchema }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    
    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    
    const { files } = req.body;
    
    const fs = await import('fs');
    const pathModule = await import('path');
    const depsDir = pathModule.join(process.cwd(), 'uploads', 'dependencies', String(scriptId));
    
    if (!fs.existsSync(depsDir)) {
      fs.mkdirSync(depsDir, { recursive: true });
    }
    
    const uploadedFiles: Array<{ originalName: string; storedPath: string; size: number; uploadedAt: string }> = [];
    const allowedExtensions = ['.csv', '.json', '.xml', '.txt', '.properties', '.dat', '.tsv'];
    
    for (const file of files) {
      if (!file.fileName || !file.fileContent) {
        continue;
      }
      
      const sanitizedFileName = pathModule.basename(file.fileName).replace(/[^a-zA-Z0-9._-]/g, '_');
      const ext = pathModule.extname(sanitizedFileName).toLowerCase();
      
      if (!allowedExtensions.includes(ext)) {
        return res.status(400).json({ 
          message: `Invalid file type: ${ext}. Allowed: ${allowedExtensions.join(', ')}` 
        });
      }
      
      if (file.fileContent.length > 10 * 1024 * 1024) {
        return res.status(400).json({ message: `File ${sanitizedFileName} too large. Max 10MB per file.` });
      }
      
      const storedPath = pathModule.join('uploads', 'dependencies', String(scriptId), sanitizedFileName);
      fs.writeFileSync(pathModule.join(process.cwd(), storedPath), file.fileContent, 'utf-8');
      
      uploadedFiles.push({
        originalName: sanitizedFileName,
        storedPath,
        size: file.fileContent.length,
        uploadedAt: new Date().toISOString(),
      });
    }
    
    const existingDeps = (script as any).dependencyFiles || [];
    const updatedScript = await storage.updateScript(scriptId, {
      dependencyFiles: [...existingDeps, ...uploadedFiles],
    } as any);
    
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    res.json({ uploaded: uploadedFiles.length, files: uploadedFiles, script: updatedScript });
  }));

  app.delete("/api/scripts/:scriptId/dependencies/:fileName", requireEngineerOrAdmin, validate({ params: fileNameParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const fileName = req.params.fileName;
    
    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    
    const deps = (script as any).dependencyFiles || [];
    const fileToDelete = deps.find((d: any) => d.originalName === fileName);
    
    if (!fileToDelete) {
      return res.status(404).json({ message: "Dependency file not found" });
    }
    
    const fs = await import('fs');
    const pathModule = await import('path');
    const fullPath = pathModule.join(process.cwd(), fileToDelete.storedPath);
    
    if (fs.existsSync(fullPath)) {
      fs.unlinkSync(fullPath);
    }
    
    const updatedDeps = deps.filter((d: any) => d.originalName !== fileName);
    await storage.updateScript(scriptId, { dependencyFiles: updatedDeps } as any);
    
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    res.json({ message: "Dependency deleted", remaining: updatedDeps.length });
  }));

  app.post("/api/scripts/:scriptId/jars", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: z.object({
    files: z.array(z.object({
      fileName: z.string().min(1),
      fileContent: z.string().min(1),
    })).min(1, "At least one JAR file is required"),
  }) }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    
    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    
    const { files } = req.body;
    
    const pathModule = await import('path');
    const jarsDir = pathModule.join(process.cwd(), 'uploads', 'jars', String(scriptId));
    
    if (!fs.existsSync(jarsDir)) {
      fs.mkdirSync(jarsDir, { recursive: true });
    }
    
    const uploadedFiles: Array<{ originalName: string; storedPath: string; size: number; uploadedAt: string }> = [];
    
    for (const file of files) {
      if (!file.fileName || !file.fileContent) {
        continue;
      }
      
      const sanitizedFileName = pathModule.basename(file.fileName).replace(/[^a-zA-Z0-9._-]/g, '_');
      const ext = pathModule.extname(sanitizedFileName).toLowerCase();
      
      if (ext !== '.jar') {
        return res.status(400).json({ 
          message: `Invalid file type: ${ext}. Only .jar files are allowed.` 
        });
      }
      
      const maxSize = 50 * 1024 * 1024;
      const fileBuffer = Buffer.from(file.fileContent, 'base64');
      
      if (fileBuffer.length > maxSize) {
        return res.status(400).json({ message: `File ${sanitizedFileName} too large. Max 50MB per file.` });
      }
      
      const storedPath = pathModule.join('uploads', 'jars', String(scriptId), sanitizedFileName);
      fs.writeFileSync(pathModule.join(process.cwd(), storedPath), fileBuffer);
      
      uploadedFiles.push({
        originalName: sanitizedFileName,
        storedPath,
        size: fileBuffer.length,
        uploadedAt: new Date().toISOString(),
      });
    }
    
    const existingJars = (script as any).jarFiles || [];
    const updatedScript = await storage.updateScript(scriptId, {
      jarFiles: [...existingJars, ...uploadedFiles],
    } as any);
    
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    res.json({ uploaded: uploadedFiles.length, files: uploadedFiles, script: updatedScript });
  }));

  app.delete("/api/scripts/:scriptId/jars/:fileName", requireEngineerOrAdmin, validate({ params: fileNameParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const fileName = req.params.fileName;
    
    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    
    const jars = (script as any).jarFiles || [];
    const fileToDelete = jars.find((j: any) => j.originalName === fileName);
    
    if (!fileToDelete) {
      return res.status(404).json({ message: "JAR file not found" });
    }
    
    const pathModule = await import('path');
    const fullPath = pathModule.join(process.cwd(), fileToDelete.storedPath);
    
    if (fs.existsSync(fullPath)) {
      fs.unlinkSync(fullPath);
    }
    
    const updatedJars = jars.filter((j: any) => j.originalName !== fileName);
    await storage.updateScript(scriptId, { jarFiles: updatedJars } as any);
    
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    res.json({ message: "JAR file deleted", remaining: updatedJars.length });
  }));

  // === AUTO-ABORT RULES ===

  const autoAbortBodySchema = z.object({
    metric: z.enum(["errorRate", "avgResponseTime", "p90", "p95", "p99", "maxResponseTime", "throughput"], { message: "Invalid metric" }),
    comparator: z.enum(["gt", "gte", "lt", "lte"], { message: "Invalid comparator" }),
    threshold: z.number({ message: "Threshold is required" }),
    sustainedSeconds: z.number().int().min(1, "Sustained seconds must be at least 1").optional(),
    isEnabled: z.boolean().optional(),
  });

  app.get("/api/scripts/:scriptId/auto-abort-rules", requireAuth, validate({ params: scriptIdParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const rules = await storage.getAutoAbortRules(scriptId);
    res.json(rules);
  }));

  app.post("/api/scripts/:scriptId/auto-abort-rules", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: autoAbortBodySchema }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });

    const sessionUser = (req.session as any).user;
    const { metric, comparator, threshold, sustainedSeconds, isEnabled } = req.body;
    const rule = await storage.createAutoAbortRule({
      scriptId,
      metric,
      comparator,
      threshold,
      sustainedSeconds: sustainedSeconds ?? 30,
      isEnabled: isEnabled !== false,
      createdBy: sessionUser.id,
    });
    res.status(201).json(rule);
  }));

  app.put("/api/scripts/:scriptId/auto-abort-rules/:id", requireEngineerOrAdmin, validate({
    params: scriptIdParam.merge(z.object({ id: z.string().regex(/^\d+$/).transform(Number) })),
    body: autoAbortBodySchema.partial(),
  }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const { metric, comparator, threshold, sustainedSeconds, isEnabled } = req.body;
    const updates: any = {};
    if (metric !== undefined) updates.metric = metric;
    if (comparator !== undefined) updates.comparator = comparator;
    if (threshold !== undefined) updates.threshold = threshold;
    if (sustainedSeconds !== undefined) updates.sustainedSeconds = sustainedSeconds;
    if (isEnabled !== undefined) updates.isEnabled = isEnabled;

    const rule = await storage.updateAutoAbortRule(id, updates);
    if (!rule) return res.status(404).json({ message: "Rule not found" });
    res.json(rule);
  }));

  app.delete("/api/scripts/:scriptId/auto-abort-rules/:id", requireEngineerOrAdmin, validate({
    params: scriptIdParam.merge(z.object({ id: z.string().regex(/^\d+$/).transform(Number) })),
  }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteAutoAbortRule(id);
    res.json({ message: "Auto-abort rule deleted" });
  }));

  app.get("/api/scripts/:id/plugin-check", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.id as unknown as number;
    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });

    if (!script.filePath) {
      return res.json({ plugins: [], hasPlugins: false });
    }

    const resolvedPath = resolveScriptPath(script.filePath);
    if (!resolvedPath) {
      return res.json({ plugins: [], hasPlugins: false });
    }

    const content = fs.readFileSync(resolvedPath, "utf-8");
    const result = detectPlugins(content);
    res.json(result);
  }));
}
