import { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import { logger } from "./logger";

export type ErrorSeverity = "info" | "warning" | "error" | "critical";
export type SuggestedAction = "retry" | "contact_admin" | "check_config" | "login" | "check_permissions" | "go_back" | "refresh";

export interface ErrorResponseBody {
  errorId: string;
  correlationId: string;
  code: string;
  severity: ErrorSeverity;
  message: string;
  details?: string;
  action: SuggestedAction;
  timestamp: string;
  path?: string;
}

export class AppError extends Error {
  public status: number;
  public code: string;
  public severity: ErrorSeverity;
  public details?: string;
  public action: SuggestedAction;

  constructor(
    message: string,
    opts: {
      status?: number;
      code?: string;
      severity?: ErrorSeverity;
      details?: string;
      action?: SuggestedAction;
    } = {},
  ) {
    super(message);
    this.name = "AppError";
    this.status = opts.status ?? 500;
    this.code = opts.code ?? "INTERNAL_ERROR";
    this.severity = opts.severity ?? "error";
    this.details = opts.details;
    this.action = opts.action ?? "retry";
  }
}

function generateErrorId(): string {
  return `ERR-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}

function inferSeverity(status: number): ErrorSeverity {
  if (status >= 500) return "critical";
  if (status === 429) return "warning";
  if (status >= 400) return "error";
  return "info";
}

function inferCode(status: number): string {
  switch (status) {
    case 400: return "BAD_REQUEST";
    case 401: return "UNAUTHORIZED";
    case 403: return "FORBIDDEN";
    case 404: return "NOT_FOUND";
    case 409: return "CONFLICT";
    case 422: return "VALIDATION_ERROR";
    case 429: return "RATE_LIMITED";
    case 500: return "INTERNAL_ERROR";
    case 502: return "BAD_GATEWAY";
    case 503: return "SERVICE_UNAVAILABLE";
    default: return status >= 500 ? "SERVER_ERROR" : "CLIENT_ERROR";
  }
}

function inferAction(status: number): SuggestedAction {
  switch (status) {
    case 401: return "login";
    case 403: return "check_permissions";
    case 404: return "go_back";
    case 422: return "check_config";
    case 429: return "retry";
    default: return status >= 500 ? "retry" : "check_config";
  }
}

export type AsyncRouteHandler = (req: Request, res: Response, next: NextFunction) => Promise<any>;

export function asyncHandler(fn: AsyncRouteHandler) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

export function correlationMiddleware(req: Request, res: Response, next: NextFunction) {
  const id = (req.headers["x-correlation-id"] as string) || `cid-${Date.now().toString(36)}-${crypto.randomBytes(4).toString("hex")}`;
  (req as any).correlationId = id;
  res.setHeader("X-Correlation-ID", id);
  next();
}

export function globalErrorHandler(err: any, req: Request, res: Response, _next: NextFunction) {
  const correlationId: string = (req as any).correlationId || "unknown";
  const errorId = generateErrorId();

  let status: number;
  let code: string;
  let severity: ErrorSeverity;
  let message: string;
  let details: string | undefined;
  let action: SuggestedAction;

  if (err instanceof AppError) {
    status = err.status;
    code = err.code;
    severity = err.severity;
    message = err.message;
    details = err.details;
    action = err.action;
  } else {
    status = err.status || err.statusCode || 500;
    message = status >= 500 ? "An unexpected error occurred" : (err.message || "Something went wrong");
    code = inferCode(status);
    severity = inferSeverity(status);
    details = process.env.NODE_ENV !== "production" ? err.message : undefined;
    action = inferAction(status);
  }

  const logMessage = `${errorId} | cid:${correlationId} | ${req.method} ${req.path} | ${status} ${code}: ${err.message}`;
  const logMeta: Record<string, any> = { errorId, correlationId, status, code, path: req.path, method: req.method };
  if (err.stack) logMeta.stack = err.stack;

  if (severity === "critical") {
    logger.fatal(logMessage, "error-handler", logMeta);
  } else if (severity === "error" || severity === "warning") {
    logger.error(logMessage, "error-handler", logMeta);
  } else {
    logger.warn(logMessage, "error-handler", logMeta);
  }

  const body: ErrorResponseBody = {
    errorId,
    correlationId,
    code,
    severity,
    message,
    details,
    action,
    timestamp: new Date().toISOString(),
    path: req.path,
  };

  res.status(status).json(body);
}
