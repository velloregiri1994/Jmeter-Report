import { z, type ZodSchema } from "zod";
import type { Request, Response, NextFunction } from "express";

export function validate(schema: {
  params?: ZodSchema;
  body?: ZodSchema;
  query?: ZodSchema;
}) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      if (schema.params) {
        req.params = schema.params.parse(req.params) as any;
      }
      if (schema.body) {
        req.body = schema.body.parse(req.body);
      }
      if (schema.query) {
        req.query = schema.query.parse(req.query) as any;
      }
      next();
    } catch (err) {
      if (err instanceof z.ZodError) {
        const messages = err.errors.map((e) => {
          const path = e.path.length > 0 ? `${e.path.join(".")}: ` : "";
          return `${path}${e.message}`;
        });
        return res.status(400).json({ message: messages.join("; ") });
      }
      next(err);
    }
  };
}

export const idParam = z.object({
  id: z.string().regex(/^\d+$/, "Invalid ID").transform(Number),
});

export const scriptIdParam = z.object({
  scriptId: z.string().regex(/^\d+$/, "Invalid script ID").transform(Number),
});

export const paginationQuery = z.object({
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
  offset: z.coerce.number().int().min(0).optional(),
}).passthrough();

export { z };
