import fs from "fs";
import path from "path";
import { mergeHistogramCounts, percentileFromHistogramCounts } from "./live-metrics/fixed-histogram";

interface BucketLabel {
  count: number;
  error_count: number;
  sum_elapsed: number;
  min_elapsed: number;
  max_elapsed: number;
  centroids: number[] | number[][] | null;
}

interface Bucket {
  start_ms: number;
  count: number;
  error_count: number;
  sum_elapsed: number;
  min_elapsed: number;
  max_elapsed: number;
  centroids: number[] | number[][] | null;
  active_threads: number | null;
  labels: Record<string, BucketLabel>;
}

interface BucketsFile {
  bucket_width_ms: number;
  min_ts: number | null;
  max_ts: number | null;
  bucket_count: number;
  buckets: Bucket[];
}

interface MergedStats {
  totalRequests: number;
  errorCount: number;
  errorRate: number;
  avgResponseTime: number;
  minResponseTime: number;
  maxResponseTime: number;
  throughput: number;
  p50: number;
  p90: number;
  p95: number;
  p99: number;
  durationSeconds: number;
}

interface MergedLabel {
  label: string;
  count: number;
  errorCount: number;
  errorRate: number;
  avg: number;
  min: number;
  max: number;
  p50: number;
  p90: number;
  p95: number;
  p99: number;
  throughput: number;
}

interface TimeseriesPoint {
  sec: number;
  rps: number;
  avg_ms: number;
  active_threads: number | null;
  errors: number;
  p50: number | null;
  p90: number | null;
  p95: number | null;
  p99: number | null;
}

export interface FilteredMetrics {
  summary: MergedStats;
  transactionDetails: MergedLabel[];
  timeseries: TimeseriesPoint[];
  startTime: number;
  endTime: number;
  bucketCount: number;
  totalBuckets: number;
}

function toSparseHistogram(raw: unknown): number[] {
  if (!raw) return [];
  if (Array.isArray(raw) && raw.length > 0) {
    if (typeof raw[0] === "number") return raw as number[];
    if (Array.isArray(raw[0])) {
      const hist = new Map<number, number>();
      for (const entry of raw as number[][]) {
        const idx = Math.min(Math.round(entry[0]), 60000);
        hist.set(idx, (hist.get(idx) || 0) + entry[1]);
      }
      const sparse: number[] = [];
      for (const idx of [...hist.keys()].sort((a, b) => a - b)) {
        sparse.push(idx, hist.get(idx)!);
      }
      return sparse;
    }
  }
  return [];
}

function computePercentile(raw: unknown, p: number): number {
  return percentileFromHistogramCounts(toSparseHistogram(raw), p * 100);
}

function mergeSparseArrays(rawList: unknown[]): number[] {
  const sparseArrays: number[][] = [];
  for (const raw of rawList) {
    const s = toSparseHistogram(raw);
    if (s.length > 0) sparseArrays.push(s);
  }
  return mergeHistogramCounts(sparseArrays);
}

export async function loadBuckets(artifactsPath: string): Promise<BucketsFile | null> {
  const bucketsPath = path.join(artifactsPath, "buckets.json");
  if (!fs.existsSync(bucketsPath)) return null;
  const raw = await fs.promises.readFile(bucketsPath, "utf-8");
  return JSON.parse(raw) as BucketsFile;
}

export function mergeBucketsForRange(
  bucketsFile: BucketsFile,
  startMs?: number,
  endMs?: number
): FilteredMetrics {
  const allBuckets = bucketsFile.buckets;
  const totalBuckets = allBuckets.length;

  let selected: Bucket[];
  if (startMs !== undefined && endMs !== undefined) {
    selected = allBuckets.filter(
      (b) => b.start_ms + bucketsFile.bucket_width_ms > startMs! && b.start_ms < endMs!
    );
  } else {
    selected = allBuckets;
  }

  if (selected.length === 0) {
    return {
      summary: {
        totalRequests: 0,
        errorCount: 0,
        errorRate: 0,
        avgResponseTime: 0,
        minResponseTime: 0,
        maxResponseTime: 0,
        throughput: 0,
        p50: 0,
        p90: 0,
        p95: 0,
        p99: 0,
        durationSeconds: 0,
      },
      transactionDetails: [],
      timeseries: [],
      startTime: startMs || 0,
      endTime: endMs || 0,
      bucketCount: 0,
      totalBuckets,
    };
  }

  let totalCount = 0;
  let totalErrors = 0;
  let totalSumElapsed = 0;
  let globalMin = Infinity;
  let globalMax = -Infinity;
  const globalHistList: unknown[] = [];

  const labelAgg: Record<
    string,
    {
      count: number;
      errorCount: number;
      sumElapsed: number;
      min: number;
      max: number;
      histList: unknown[];
    }
  > = {};

  const timeseries: TimeseriesPoint[] = [];

  for (const b of selected) {
    totalCount += b.count;
    totalErrors += b.error_count;
    totalSumElapsed += b.sum_elapsed;
    globalMin = Math.min(globalMin, b.min_elapsed);
    globalMax = Math.max(globalMax, b.max_elapsed);
    globalHistList.push(b.centroids);

    const bucketSec = Math.floor(b.start_ms / 1000);
    const durationSec = bucketsFile.bucket_width_ms / 1000;
    timeseries.push({
      sec: bucketSec,
      rps: Math.round((b.count / durationSec) * 100) / 100,
      avg_ms: b.count > 0 ? Math.round((b.sum_elapsed / b.count) * 100) / 100 : 0,
      active_threads: b.active_threads,
      errors: b.error_count,
      p50: computePercentile(b.centroids, 0.5),
      p90: computePercentile(b.centroids, 0.9),
      p95: computePercentile(b.centroids, 0.95),
      p99: computePercentile(b.centroids, 0.99),
    });

    for (const [label, lb] of Object.entries(b.labels)) {
      if (!labelAgg[label]) {
        labelAgg[label] = {
          count: 0,
          errorCount: 0,
          sumElapsed: 0,
          min: Infinity,
          max: -Infinity,
          histList: [],
        };
      }
      const la = labelAgg[label];
      la.count += lb.count;
      la.errorCount += lb.error_count;
      la.sumElapsed += lb.sum_elapsed;
      la.min = Math.min(la.min, lb.min_elapsed);
      la.max = Math.max(la.max, lb.max_elapsed);
      la.histList.push(lb.centroids);
    }
  }

  const rangeStartMs = selected[0].start_ms;
  const rangeEndMs = selected[selected.length - 1].start_ms + bucketsFile.bucket_width_ms;
  const durationSeconds = Math.max(1, (rangeEndMs - rangeStartMs) / 1000);

  const mergedGlobal = mergeSparseArrays(globalHistList);

  const summary: MergedStats = {
    totalRequests: totalCount,
    errorCount: totalErrors,
    errorRate: totalCount > 0 ? totalErrors / totalCount : 0,
    avgResponseTime: totalCount > 0 ? Math.floor(totalSumElapsed / totalCount) : 0,
    minResponseTime: globalMin === Infinity ? 0 : globalMin,
    maxResponseTime: globalMax === -Infinity ? 0 : globalMax,
    throughput: totalCount / durationSeconds,
    p50: percentileFromHistogramCounts(mergedGlobal, 50),
    p90: percentileFromHistogramCounts(mergedGlobal, 90),
    p95: percentileFromHistogramCounts(mergedGlobal, 95),
    p99: percentileFromHistogramCounts(mergedGlobal, 99),
    durationSeconds,
  };

  const transactionDetails: MergedLabel[] = Object.entries(labelAgg).map(
    ([label, la]) => {
      const labelHist = mergeSparseArrays(la.histList);
      return {
        label,
        count: la.count,
        errorCount: la.errorCount,
        errorRate: la.count > 0 ? la.errorCount / la.count : 0,
        avg: la.count > 0 ? Math.floor(la.sumElapsed / la.count) : 0,
        min: la.min === Infinity ? 0 : la.min,
        max: la.max === -Infinity ? 0 : la.max,
        p50: percentileFromHistogramCounts(labelHist, 50),
        p90: percentileFromHistogramCounts(labelHist, 90),
        p95: percentileFromHistogramCounts(labelHist, 95),
        p99: percentileFromHistogramCounts(labelHist, 99),
        throughput: la.count / durationSeconds,
      };
    }
  );

  return {
    summary,
    transactionDetails,
    timeseries,
    startTime: rangeStartMs,
    endTime: rangeEndMs,
    bucketCount: selected.length,
    totalBuckets,
  };
}
