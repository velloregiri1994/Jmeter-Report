import Redis from "ioredis";
import { logger } from "./logger";

let redis: Redis | null = null;

const REDIS_URL = process.env.REDIS_URL;

interface MemoryCacheEntry {
  value: unknown;
  expiresAt: number;
}

const memoryCache = new Map<string, MemoryCacheEntry>();
const MAX_MEMORY_CACHE_SIZE = 1000;
let memoryCacheEnabled = true;

function cleanupExpiredEntries(): void {
  const now = Date.now();
  const entries = Array.from(memoryCache.entries());
  for (const [key, entry] of entries) {
    if (entry.expiresAt <= now) {
      memoryCache.delete(key);
    }
  }
}

setInterval(cleanupExpiredEntries, 60000);

function evictOldestEntries(): void {
  if (memoryCache.size <= MAX_MEMORY_CACHE_SIZE) return;
  
  const entries = Array.from(memoryCache.entries());
  entries.sort((a, b) => a[1].expiresAt - b[1].expiresAt);
  
  const toRemove = entries.slice(0, Math.floor(MAX_MEMORY_CACHE_SIZE * 0.2));
  for (const [key] of toRemove) {
    memoryCache.delete(key);
  }
}

if (REDIS_URL) {
  try {
    redis = new Redis(REDIS_URL, {
      maxRetriesPerRequest: 3,
      lazyConnect: true,
      retryStrategy: (times) => {
        if (times > 3) {
          logger.warn("Redis retry limit reached, falling back to memory cache", "cache");
          return null;
        }
        return Math.min(times * 100, 3000);
      },
    });

    redis.on("error", (err) => {
      logger.warn(`Redis connection error: ${err.message}`, "cache");
    });

    redis.on("connect", () => {
      logger.info("Redis connected", "cache");
    });

    redis.connect().catch((err) => {
      logger.warn(`Failed to connect to Redis: ${err.message}`, "cache");
      redis = null;
      logger.info("Using in-memory cache as fallback", "cache");
    });
  } catch (err) {
    logger.warn("Redis initialization failed, using in-memory cache", "cache");
    redis = null;
  }
} else {
  logger.info("REDIS_URL not set, using in-memory cache", "cache");
}

const DEFAULT_TTL = parseInt(process.env.CACHE_TTL_DEFAULT || "60", 10);

export async function cacheGet<T>(key: string): Promise<T | null> {
  if (redis) {
    try {
      const data = await redis.get(key);
      if (data) {
        return JSON.parse(data) as T;
      }
    } catch (err) {
      console.warn(`[cache] Redis get error for key ${key}, trying memory cache:`, err);
    }
  }

  if (memoryCacheEnabled) {
    const entry = memoryCache.get(key);
    if (entry && entry.expiresAt > Date.now()) {
      return entry.value as T;
    }
    if (entry) {
      memoryCache.delete(key);
    }
  }

  return null;
}

export async function cacheSet(key: string, value: unknown, ttlSeconds: number = DEFAULT_TTL): Promise<void> {
  if (redis) {
    try {
      await redis.setex(key, ttlSeconds, JSON.stringify(value));
      return;
    } catch (err) {
      console.warn(`[cache] Redis set error for key ${key}, using memory cache:`, err);
    }
  }

  if (memoryCacheEnabled) {
    evictOldestEntries();
    memoryCache.set(key, {
      value,
      expiresAt: Date.now() + (ttlSeconds * 1000),
    });
  }
}

export async function cacheDelete(key: string): Promise<void> {
  if (redis) {
    try {
      await redis.del(key);
    } catch (err) {
      console.warn(`[cache] Redis delete error for key ${key}:`, err);
    }
  }

  memoryCache.delete(key);
}

export async function cacheDeletePattern(pattern: string): Promise<void> {
  if (redis) {
    try {
      const keys = await redis.keys(pattern);
      if (keys.length > 0) {
        await redis.del(...keys);
      }
    } catch (err) {
      console.warn(`[cache] Redis delete pattern error for ${pattern}:`, err);
    }
  }

  const regexPattern = pattern.replace(/\*/g, '.*');
  const regex = new RegExp(`^${regexPattern}$`);
  const keys = Array.from(memoryCache.keys());
  for (const key of keys) {
    if (regex.test(key)) {
      memoryCache.delete(key);
    }
  }
}

export function isCacheEnabled(): boolean {
  return redis !== null || memoryCacheEnabled;
}

export function getCacheStats(): { type: string; size: number; maxSize: number } {
  return {
    type: redis ? 'redis' : 'memory',
    size: memoryCache.size,
    maxSize: MAX_MEMORY_CACHE_SIZE,
  };
}

export const CACHE_KEYS = {
  DASHBOARD_STATS: "dashboard:stats",
  SCRIPTS_LIST: "scripts:list",
  SCHEDULES_LIST: "schedules:list",
  EXECUTIONS_COUNT: "executions:count",
  USER_SESSION: "user:session",
};

export const CACHE_TTL = {
  DASHBOARD_STATS: parseInt(process.env.CACHE_TTL_DASHBOARD || "30", 10),
  SCRIPTS_LIST: parseInt(process.env.CACHE_TTL_SCRIPTS || "60", 10),
  SCHEDULES_LIST: parseInt(process.env.CACHE_TTL_SCHEDULES || "30", 10),
  EXECUTIONS_COUNT: 15,
  USER_SESSION: 300,
};

export const cacheService = {
  get: cacheGet,
  set: cacheSet,
  delete: cacheDelete,
  deletePattern: cacheDeletePattern,
  isEnabled: isCacheEnabled,
  getStats: getCacheStats,
};
