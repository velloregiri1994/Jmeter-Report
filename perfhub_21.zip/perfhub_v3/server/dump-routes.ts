import express, { type Express, type Request, type Response } from "express";
import multer, { type FileFilterCallback } from "multer";
import path from "path";
import fs from "fs";
import * as dumpStorage from "./dump-storage";
import { parseThreadDump, compareThreadDumps } from "./analyzers/thread-dump-parser";
import { parseHeapDump, compareHeapDumps } from "./analyzers/heap-dump-parser";
import { parseGcLog } from "./analyzers/gc-log-parser";
import { validate, z, idParam } from "./validation";
import { asyncHandler } from "./error-handler";
import { requireAuth, requireNonViewer } from "./route-middleware";

const UPLOADS_DIR = path.join(process.cwd(), 'uploads', 'dumps');

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const diskStorage = multer.diskStorage({
  destination: (req: Express.Request, file: Express.Multer.File, cb: (error: Error | null, destination: string) => void) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req: Express.Request, file: Express.Multer.File, cb: (error: Error | null, filename: string) => void) => {
    const timestamp = Date.now();
    const ext = path.extname(file.originalname);
    cb(null, `dump-${timestamp}${ext}`);
  }
});

const upload = multer({
  storage: diskStorage,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB max
  },
  fileFilter: (req: Express.Request, file: Express.Multer.File, cb: FileFilterCallback) => {
    const allowedExtensions = ['.hprof', '.txt', '.tdump', '.log', '.dump', '.bin'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedExtensions.includes(ext) || file.mimetype === 'application/octet-stream' || file.mimetype.startsWith('text/')) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Allowed: .hprof, .txt, .tdump, .log, .dump, .bin'));
    }
  }
});

export function registerDumpRoutes(app: Express): void {
  
  app.get("/api/dumps", requireAuth, asyncHandler(async (req, res) => {
    const files = await dumpStorage.getDumpFiles();
    res.json(files);
  }));

  app.get("/api/dumps/:id", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const file = await dumpStorage.getDumpFileWithAnalysis(id);
    if (!file) {
      return res.status(404).json({ message: "Dump file not found" });
    }
    res.json(file);
  }));

  (app as any).post("/api/dumps/upload", requireNonViewer, upload.single('file'), asyncHandler(async (req: any, res: Response) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const sessionUser = (req.session as any)?.user;
    const dumpType = req.body.type || 'thread';
    
    const dumpFile = await dumpStorage.createDumpFile({
      name: req.file.originalname,
      type: dumpType,
      filePath: req.file.path,
      fileSize: req.file.size,
      uploadedBy: sessionUser.id,
      status: 'pending'
    });

    res.json(dumpFile);

    setImmediate(async () => {
      try {
        await dumpStorage.updateDumpFile(dumpFile.id, { status: 'analyzing' });
        
        let analysisData: any;
        
        if (dumpType === 'thread') {
          const content = await fs.promises.readFile(req.file!.path, 'utf-8');
          analysisData = parseThreadDump(content);
          
          await dumpStorage.createAnalysis({
            dumpFileId: dumpFile.id,
            analysisType: 'thread',
            threadSummary: analysisData.threadSummary,
            threads: analysisData.threads,
            deadlocks: analysisData.deadlocks,
            hotspots: analysisData.hotspots,
            stackClusters: analysisData.stackClusters,
            contentionInfo: analysisData.contentionInfo,
            detectedIssues: analysisData.detectedIssues || null,
            heapSummary: null,
            classHistogram: null,
            leakSuspects: null,
            dominatorTree: null,
            referenceChains: null,
            topObjects: null,
            gcMetrics: analysisData.gcMetrics || null
          });
        } else {
          analysisData = parseHeapDump(req.file!.path);
          
          await dumpStorage.createAnalysis({
            dumpFileId: dumpFile.id,
            analysisType: 'heap',
            threadSummary: null,
            threads: null,
            deadlocks: null,
            hotspots: null,
            stackClusters: null,
            contentionInfo: null,
            detectedIssues: null,
            heapSummary: analysisData.heapSummary,
            classHistogram: analysisData.classHistogram,
            leakSuspects: analysisData.leakSuspects,
            dominatorTree: analysisData.dominatorTree,
            referenceChains: analysisData.referenceChains,
            topObjects: analysisData.topObjects,
            gcMetrics: analysisData.gcMetrics || null
          });
        }
        
        await dumpStorage.updateDumpFile(dumpFile.id, { status: 'completed' });
      } catch (error: any) {
        console.error('Analysis failed:', error);
        const errorMsg = error instanceof Error ? error.message : 'Unknown analysis error';
        await dumpStorage.updateDumpFile(dumpFile.id, { 
          status: 'failed',
          errorMessage: errorMsg
        });
      }
    });
  }));

  app.delete("/api/dumps/:id", requireNonViewer, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const file = await dumpStorage.getDumpFile(id);
    if (!file) {
      return res.status(404).json({ message: "Dump file not found" });
    }
    
    if (fs.existsSync(file.filePath)) {
      fs.unlinkSync(file.filePath);
    }
    
    await dumpStorage.deleteDumpFile(id);
    res.json({ success: true });
  }));

  app.get("/api/dumps/:id/analysis", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const analysis = await dumpStorage.getAnalysis(id);
    if (!analysis) {
      return res.status(404).json({ message: "Analysis not found" });
    }
    res.json(analysis);
  }));

  app.post("/api/dumps/:id/reanalyze", requireNonViewer, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const file = await dumpStorage.getDumpFile(id);
    if (!file) {
      return res.status(404).json({ message: "Dump file not found" });
    }

    await dumpStorage.updateDumpFile(id, { status: 'analyzing' });

    setImmediate(async () => {
      try {
        let analysisData: any;
        
        if (file.type === 'thread') {
          const content = await fs.promises.readFile(file.filePath, 'utf-8');
          analysisData = parseThreadDump(content);
          
          const existingAnalysis = await dumpStorage.getAnalysis(id);
          if (existingAnalysis) {
            await dumpStorage.updateAnalysis(existingAnalysis.id, {
              threadSummary: analysisData.threadSummary,
              threads: analysisData.threads,
              deadlocks: analysisData.deadlocks,
              hotspots: analysisData.hotspots,
              stackClusters: analysisData.stackClusters,
              contentionInfo: analysisData.contentionInfo,
              detectedIssues: analysisData.detectedIssues || null,
              gcMetrics: analysisData.gcMetrics || null
            });
          } else {
            await dumpStorage.createAnalysis({
              dumpFileId: file.id,
              analysisType: 'thread',
              threadSummary: analysisData.threadSummary,
              threads: analysisData.threads,
              deadlocks: analysisData.deadlocks,
              hotspots: analysisData.hotspots,
              stackClusters: analysisData.stackClusters,
              contentionInfo: analysisData.contentionInfo,
              detectedIssues: analysisData.detectedIssues || null,
              heapSummary: null,
              classHistogram: null,
              leakSuspects: null,
              dominatorTree: null,
              referenceChains: null,
              topObjects: null,
              gcMetrics: analysisData.gcMetrics || null
            });
          }
        } else {
          analysisData = parseHeapDump(file.filePath);
          
          const existingAnalysis = await dumpStorage.getAnalysis(id);
          if (existingAnalysis) {
            await dumpStorage.updateAnalysis(existingAnalysis.id, {
              heapSummary: analysisData.heapSummary,
              classHistogram: analysisData.classHistogram,
              leakSuspects: analysisData.leakSuspects,
              dominatorTree: analysisData.dominatorTree,
              referenceChains: analysisData.referenceChains,
              topObjects: analysisData.topObjects,
              gcMetrics: analysisData.gcMetrics || null
            });
          } else {
            await dumpStorage.createAnalysis({
              dumpFileId: file.id,
              analysisType: 'heap',
              threadSummary: null,
              threads: null,
              deadlocks: null,
              hotspots: null,
              stackClusters: null,
              contentionInfo: null,
              detectedIssues: null,
              heapSummary: analysisData.heapSummary,
              classHistogram: analysisData.classHistogram,
              leakSuspects: analysisData.leakSuspects,
              dominatorTree: analysisData.dominatorTree,
              referenceChains: analysisData.referenceChains,
              topObjects: analysisData.topObjects,
              gcMetrics: analysisData.gcMetrics || null
            });
          }
        }
        
        await dumpStorage.updateDumpFile(id, { status: 'completed' });
      } catch (error: any) {
        console.error('Re-analysis failed:', error);
        const errorMsg = error instanceof Error ? error.message : 'Unknown analysis error';
        await dumpStorage.updateDumpFile(id, { 
          status: 'failed',
          errorMessage: errorMsg
        });
      }
    });

    res.json({ message: 'Re-analysis started' });
  }));

  (app as any).post("/api/dumps/:id/gc-log", requireNonViewer, validate({ params: idParam }), upload.single('gcLog'), asyncHandler(async (req: any, res: Response) => {
    const id = req.params.id as unknown as number;
    const file = await dumpStorage.getDumpFile(id);
    if (!file) {
      return res.status(404).json({ message: "Dump file not found" });
    }

    if (!req.file) {
      return res.status(400).json({ message: "No GC log file uploaded" });
    }

    const gcLogContent = await fs.promises.readFile(req.file.path, 'utf-8');
    const gcPerformance = parseGcLog(gcLogContent);

    const existingAnalysis = await dumpStorage.getAnalysis(id);
    if (existingAnalysis) {
      const currentGcMetrics = (existingAnalysis.gcMetrics as any) || {};
      await dumpStorage.updateAnalysis(existingAnalysis.id, {
        gcMetrics: { ...currentGcMetrics, gcPerformance }
      });
    }

    fs.unlinkSync(req.file.path);

    res.json({ success: true, gcPerformance });
  }));

  app.get("/api/dump-comparisons", requireAuth, asyncHandler(async (req, res) => {
    const comparisons = await dumpStorage.getDumpComparisons();
    res.json(comparisons);
  }));

  app.post("/api/dump-comparisons", requireNonViewer, validate({ body: z.object({ name: z.string().min(1, "Name is required"), dumpFileIds: z.array(z.number().int()).min(2, "At least 2 dump files required"), comparisonType: z.string().min(1) }) }), asyncHandler(async (req, res) => {
    const { name, dumpFileIds, comparisonType } = req.body;
    const sessionUser = (req.session as any)?.user;

    const analyses = await dumpStorage.getAnalysesByDumpIds(dumpFileIds);
    
    let results: any = {};
    
    if (comparisonType === 'heap') {
      const heapAnalyses = analyses
        .filter(a => a.analysisType === 'heap')
        .map(a => ({
          heapSummary: a.heapSummary as any,
          classHistogram: a.classHistogram as any || [],
          leakSuspects: a.leakSuspects as any || [],
          dominatorTree: a.dominatorTree as any || [],
          referenceChains: a.referenceChains as any || [],
          topObjects: a.topObjects as any || [],
        }));
      
      if (heapAnalyses.length >= 2) {
        results = compareHeapDumps(heapAnalyses);
      }
    } else {
      const threadAnalyses = analyses.filter(a => a.analysisType === 'thread');
      results.threadStateTrends = threadAnalyses.map((a, i) => ({
        timestamp: `Dump ${i + 1}`,
        runnable: (a.threadSummary as any)?.runnable || 0,
        blocked: (a.threadSummary as any)?.blocked || 0,
        waiting: (a.threadSummary as any)?.waiting || 0,
      }));

      if (threadAnalyses.length >= 2) {
        const crossDumpData = threadAnalyses.map(a => ({
          threads: (a.threads as any) || [],
          threadSummary: (a.threadSummary as any) || { totalThreads: 0, runnable: 0, blocked: 0, waiting: 0, timedWaiting: 0, terminated: 0, daemonCount: 0 },
        }));
        const crossResult = compareThreadDumps(crossDumpData);
        results.stuckThreads = crossResult.stuckThreads;
        results.detectedIssues = crossResult.detectedIssues;
      }
    }

    const comparison = await dumpStorage.createDumpComparison({
      name,
      dumpFileIds,
      comparisonType,
      results,
      createdBy: sessionUser.id
    });

    res.json(comparison);
  }));

  app.get("/api/dump-comparisons/:id", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const comparison = await dumpStorage.getDumpComparison(id);
    if (!comparison) {
      return res.status(404).json({ message: "Comparison not found" });
    }
    res.json(comparison);
  }));

  app.delete("/api/dump-comparisons/:id", requireNonViewer, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await dumpStorage.deleteDumpComparison(id);
    res.json({ success: true });
  }));

  app.get("/api/dumps/:id/annotations", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const annotations = await dumpStorage.getAnnotations(id);
    res.json(annotations);
  }));

  app.post("/api/dumps/:id/annotations", requireNonViewer, validate({ params: idParam, body: z.object({ note: z.string().min(1, "Note is required"), threadName: z.string().optional().nullable(), issueIndex: z.number().optional().nullable() }) }), asyncHandler(async (req, res) => {
    const dumpFileId = req.params.id as unknown as number;
    const sessionUser = (req.session as any)?.user;
    const { note, threadName, issueIndex } = req.body;
    const annotation = await dumpStorage.createAnnotation({
      dumpFileId,
      note,
      threadName: threadName || null,
      issueIndex: issueIndex ?? null,
      createdBy: sessionUser.id,
    });
    res.json(annotation);
  }));

  app.delete("/api/dumps/:dumpId/annotations/:id", requireNonViewer, validate({ params: z.object({ dumpId: z.string().regex(/^\d+$/).transform(Number), id: z.string().regex(/^\d+$/).transform(Number) }) }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await dumpStorage.deleteAnnotation(id);
    res.json({ success: true });
  }));

  app.get("/api/dumps/:id/bookmarks", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const bookmarks = await dumpStorage.getBookmarks(id);
    res.json(bookmarks);
  }));

  app.post("/api/dumps/:id/bookmarks/toggle", requireNonViewer, validate({ params: idParam, body: z.object({ threadName: z.string().min(1, "threadName is required") }) }), asyncHandler(async (req, res) => {
    const dumpFileId = req.params.id as unknown as number;
    const sessionUser = (req.session as any)?.user;
    const { threadName } = req.body;
    const result = await dumpStorage.toggleBookmark(dumpFileId, threadName, sessionUser.id);
    res.json(result);
  }));
}
