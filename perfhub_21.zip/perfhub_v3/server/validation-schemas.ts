import { z } from 'zod';

// Authentication Schemas
export const loginSchema = z.object({
  username: z.string().min(1, 'Username is required').max(255),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

export const signupSchema = z.object({
  username: z.string().min(1, 'Username is required').max(255),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  email: z.string().email('Invalid email address').optional(),
});

// Script Schemas
export const createScriptSchema = z.object({
  name: z.string().min(1, 'Script name is required').max(255),
  description: z.string().max(1000).optional(),
  toolType: z.enum(['JMeter', 'LoadRunner'], {
    errorMap: () => ({ message: 'Invalid tool type' }),
  }),
  folderId: z.number().int().positive().optional(),
});

export const updateScriptSchema = z.object({
  name: z.string().min(1).max(255).optional(),
  description: z.string().max(1000).optional(),
  toolType: z.enum(['JMeter', 'LoadRunner']).optional(),
  folderId: z.number().int().positive().optional(),
});

// Folder Schemas
export const createFolderSchema = z.object({
  name: z.string().min(1, 'Folder name is required').max(255),
  parentId: z.number().int().positive().optional(),
});

export const updateFolderSchema = z.object({
  name: z.string().min(1).max(255).optional(),
  parentId: z.number().int().positive().optional(),
});

// Schedule Schemas
export const createScheduleSchema = z.object({
  name: z.string().min(1, 'Schedule name is required').max(255),
  scriptId: z.number().int().positive('Script ID must be a positive integer'),
  scheduledTime: z.coerce.date(),
  recurrence: z.enum(['none', 'daily', 'weekly', 'monthly']).default('none'),
  configuration: z.object({
    vusers: z.number().int().positive('Virtual users must be positive').optional(),
    rampUp: z.number().int().nonnegative('Ramp up must be non-negative').optional(),
    duration: z.number().int().positive('Duration must be positive').optional(),
    environment: z.string().optional(),
    isDistributed: z.boolean().optional(),
    workerNodes: z.number().int().positive().optional(),
    slas: z.object({
      avgResponseTime: z.number().positive().optional(),
      throughput: z.number().positive().optional(),
      p90: z.number().positive().optional(),
      p95: z.number().positive().optional(),
      errorRate: z.number().min(0).max(100).optional(),
    }).optional(),
  }).optional(),
});

export const updateScheduleSchema = z.object({
  name: z.string().min(1).max(255).optional(),
  scriptId: z.number().int().positive().optional(),
  scheduledTime: z.coerce.date().optional(),
  recurrence: z.enum(['none', 'daily', 'weekly', 'monthly']).optional(),
  configuration: z.object({
    vusers: z.number().int().positive().optional(),
    rampUp: z.number().int().nonnegative().optional(),
    duration: z.number().int().positive().optional(),
    environment: z.string().optional(),
    isDistributed: z.boolean().optional(),
    workerNodes: z.number().int().positive().optional(),
    slas: z.object({
      avgResponseTime: z.number().positive().optional(),
      throughput: z.number().positive().optional(),
      p90: z.number().positive().optional(),
      p95: z.number().positive().optional(),
      errorRate: z.number().min(0).max(100).optional(),
    }).optional(),
  }).optional(),
});

// Execution Schemas
export const createExecutionSchema = z.object({
  scheduleId: z.number().int().positive('Schedule ID must be a positive integer'),
  configuration: z.object({
    vusers: z.number().int().positive().optional(),
    rampUp: z.number().int().nonnegative().optional(),
    duration: z.number().int().positive().optional(),
    environment: z.string().optional(),
  }).optional(),
});

// Comment Schemas
export const createCommentSchema = z.object({
  comment: z.string().min(1, 'Comment cannot be empty').max(5000),
});

// Dump Schemas
export const analyzeDumpSchema = z.object({
  analysisType: z.enum(['memory', 'threads', 'cpu']),
});

// User Management Schemas
export const updateUserSchema = z.object({
  role: z.enum(['admin', 'engineer', 'manager', 'lead', 'viewer']).optional(),
  isApproved: z.boolean().optional(),
});

// Retention Settings Schema
export const updateRetentionSettingsSchema = z.object({
  metricsRetentionDays: z.number().int().positive().optional(),
  dumpRetentionDays: z.number().int().positive().optional(),
  reportRetentionDays: z.number().int().positive().optional(),
  autoDelete: z.boolean().optional(),
});

// Helper function to validate request body
export function validateSchema<T>(schema: z.ZodSchema<T>, data: unknown): T {
  return schema.parse(data);
}

// Helper function to handle validation errors
export function handleValidationError(error: z.ZodError): { field: string; message: string }[] {
  return error.errors.map((err) => ({
    field: err.path.join('.'),
    message: err.message,
  }));
}
