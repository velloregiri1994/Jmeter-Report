import { XMLParser, XMLBuilder } from "fast-xml-parser";

export type FieldType = 'number' | 'text' | 'boolean' | 'select';

export interface FieldOption {
  value: string;
  label: string;
}

export interface SchemaField {
  key: string;
  label: string;
  type: FieldType;
  required?: boolean;
  min?: number;
  max?: number;
  step?: number;
  options?: FieldOption[];
  defaultValue?: any;
  group?: string;
  helpText?: string;
  visibleWhen?: { field: string; value: any };
}

export interface ThreadGroupSchema {
  fields: SchemaField[];
}

export interface ThreadGroupInfo {
  index: number;
  name: string;
  type: string;
  typeLabel: string;
  enabled: boolean;
  adapterType: string;
  schema: ThreadGroupSchema;
  values: Record<string, any>;
}

export interface ThreadGroupAdapter {
  id: string;
  typeLabel: string;
  supports(type: string, xmlNode: any): boolean;
  getSchema(): ThreadGroupSchema;
  extractValues(xmlNode: any): Record<string, any>;
  validate(values: Record<string, any>): string[];
  applyChanges(xmlNode: any, values: Record<string, any>): void;
}

interface PropertyInfo {
  type: string;
  name: string;
  value: any;
}

const PARSER_OPTS = {
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  textNodeName: '#text',
  parseAttributeValue: false,
  parseTagValue: false,
};

const BUILDER_OPTS = {
  ...PARSER_OPTS,
  format: true,
  indentBy: '  ',
  suppressBooleanAttributes: false,
  suppressEmptyNode: false,
};

function getPropertyValue(props: any, propName: string, defaultValue: any = null): any {
  if (!props) return defaultValue;

  const propTypes = ['stringProp', 'intProp', 'longProp', 'boolProp'];

  for (const propType of propTypes) {
    const propList = props[propType];
    if (!propList) continue;

    const items = Array.isArray(propList) ? propList : [propList];
    for (const item of items) {
      if (item?.['@_name'] === propName) {
        const value = item['#text'] ?? item;
        if (propType === 'boolProp') {
          return String(value).toLowerCase() === 'true';
        }
        if (propType === 'intProp' || propType === 'longProp') {
          const parsed = parseInt(String(value), 10);
          return isNaN(parsed) ? defaultValue : parsed;
        }
        return value;
      }
    }
  }

  return defaultValue;
}

function setPropertyValue(props: any, propName: string, value: any): void {
  if (!props) return;

  const propTypes = ['stringProp', 'intProp', 'longProp', 'boolProp'];

  for (const propType of propTypes) {
    const propList = props[propType];
    if (!propList) continue;

    const items = Array.isArray(propList) ? propList : [propList];
    for (const item of items) {
      if (item?.['@_name'] === propName) {
        item['#text'] = String(value);
        return;
      }
    }
  }
}

function getAllProperties(xmlNode: any): Record<string, PropertyInfo> {
  const result: Record<string, PropertyInfo> = {};
  if (!xmlNode) return result;

  const propTypes = ['stringProp', 'intProp', 'longProp', 'boolProp'];

  for (const propType of propTypes) {
    const propList = xmlNode[propType];
    if (!propList) continue;

    const items = Array.isArray(propList) ? propList : [propList];
    for (const item of items) {
      const name = item?.['@_name'];
      if (!name) continue;
      const rawValue = item['#text'] ?? '';
      let value: any = rawValue;

      if (propType === 'boolProp') {
        value = String(rawValue).toLowerCase() === 'true';
      } else if (propType === 'intProp' || propType === 'longProp') {
        const parsed = parseInt(String(rawValue), 10);
        value = isNaN(parsed) ? 0 : parsed;
      }

      result[name] = { type: propType, name, value };
    }
  }

  return result;
}

function humanizePropertyName(propName: string): string {
  const parts = propName.split('.');
  const lastPart = parts[parts.length - 1];
  return lastPart
    .replace(/_/g, ' ')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/\b\w/g, c => c.toUpperCase())
    .trim();
}

function safeParseInt(value: any, defaultValue: number): number {
  const parsed = parseInt(String(value), 10);
  return isNaN(parsed) ? defaultValue : parsed;
}

function safeParseFloat(value: any, defaultValue: number): number {
  const parsed = parseFloat(String(value));
  return isNaN(parsed) ? defaultValue : parsed;
}

function getStandardSchema(): ThreadGroupSchema {
  return {
    fields: [
      { key: 'threads', label: 'Number of Threads (Users)', type: 'number', required: true, min: 1, group: 'Load', defaultValue: 1 },
      { key: 'rampUp', label: 'Ramp-Up Period (seconds)', type: 'number', min: 0, group: 'Load', defaultValue: 0 },
      { key: 'loopCount', label: 'Loop Count', type: 'number', min: -1, group: 'Load', helpText: '-1 for infinite', defaultValue: 1 },
      { key: 'loopForever', label: 'Loop Forever', type: 'boolean', group: 'Load', defaultValue: false },
      { key: 'schedulerEnabled', label: 'Scheduler', type: 'boolean', group: 'Scheduler', defaultValue: false },
      { key: 'duration', label: 'Duration (seconds)', type: 'number', min: 0, group: 'Scheduler', defaultValue: 0, visibleWhen: { field: 'schedulerEnabled', value: true } },
      { key: 'delay', label: 'Startup Delay (seconds)', type: 'number', min: 0, group: 'Scheduler', defaultValue: 0, visibleWhen: { field: 'schedulerEnabled', value: true } },
    ],
  };
}

function extractStandardValues(xmlNode: any): Record<string, any> {
  const threads = safeParseInt(getPropertyValue(xmlNode, 'ThreadGroup.num_threads', 1), 1);
  const rampUp = safeParseInt(getPropertyValue(xmlNode, 'ThreadGroup.ramp_time', 0), 0);
  const schedulerEnabled = getPropertyValue(xmlNode, 'ThreadGroup.scheduler', false);
  const duration = safeParseInt(getPropertyValue(xmlNode, 'ThreadGroup.duration', 0), 0);
  const delay = safeParseInt(getPropertyValue(xmlNode, 'ThreadGroup.delay', 0), 0);

  let loopCount = 1;
  let loopForever = false;

  const loopController = xmlNode.elementProp || xmlNode.LoopController;
  if (loopController) {
    const loops = getPropertyValue(loopController, 'LoopController.loops', 1);
    loopCount = safeParseInt(loops, 1);
    loopForever = getPropertyValue(loopController, 'LoopController.continue_forever', false);
    if (loopCount === -1) loopForever = true;
  }

  return { threads, rampUp, loopCount, loopForever, schedulerEnabled, duration, delay };
}

function validateStandardValues(values: Record<string, any>): string[] {
  const errors: string[] = [];
  const threads = safeParseInt(values.threads, 0);
  if (threads < 1) errors.push('Number of Threads must be at least 1');

  const rampUp = safeParseInt(values.rampUp, -1);
  if (rampUp < 0) errors.push('Ramp-Up Period must be 0 or greater');

  const loopCount = safeParseInt(values.loopCount, 0);
  if (loopCount < -1 || loopCount === 0) errors.push('Loop Count must be -1 (infinite) or at least 1');

  if (values.schedulerEnabled) {
    const duration = safeParseInt(values.duration, -1);
    if (duration < 0) errors.push('Duration must be 0 or greater');
  }

  const delay = safeParseInt(values.delay, -1);
  if (delay < 0) errors.push('Startup Delay must be 0 or greater');

  return errors;
}

function applyStandardChanges(xmlNode: any, values: Record<string, any>): void {
  setPropertyValue(xmlNode, 'ThreadGroup.num_threads', values.threads);
  setPropertyValue(xmlNode, 'ThreadGroup.ramp_time', values.rampUp);
  setPropertyValue(xmlNode, 'ThreadGroup.scheduler', values.schedulerEnabled);
  setPropertyValue(xmlNode, 'ThreadGroup.duration', values.duration ?? 0);
  setPropertyValue(xmlNode, 'ThreadGroup.delay', values.delay ?? 0);

  const loopController = xmlNode.elementProp || xmlNode.LoopController;
  if (loopController) {
    const loopForever = !!values.loopForever;
    const loopCount = loopForever ? -1 : safeParseInt(values.loopCount, 1);
    setPropertyValue(loopController, 'LoopController.loops', loopCount);
    setPropertyValue(loopController, 'LoopController.continue_forever', loopForever);
  }
}

const StandardThreadGroupAdapter: ThreadGroupAdapter = {
  id: 'standard',
  typeLabel: 'Standard Thread Group',
  supports(type: string): boolean {
    return type === 'ThreadGroup';
  },
  getSchema(): ThreadGroupSchema {
    return getStandardSchema();
  },
  extractValues(xmlNode: any): Record<string, any> {
    return extractStandardValues(xmlNode);
  },
  validate(values: Record<string, any>): string[] {
    return validateStandardValues(values);
  },
  applyChanges(xmlNode: any, values: Record<string, any>): void {
    applyStandardChanges(xmlNode, values);
  },
};

const SetupThreadGroupAdapter: ThreadGroupAdapter = {
  id: 'setup',
  typeLabel: 'setUp Thread Group',
  supports(type: string): boolean {
    return type === 'SetupThreadGroup';
  },
  getSchema(): ThreadGroupSchema {
    return getStandardSchema();
  },
  extractValues(xmlNode: any): Record<string, any> {
    return extractStandardValues(xmlNode);
  },
  validate(values: Record<string, any>): string[] {
    return validateStandardValues(values);
  },
  applyChanges(xmlNode: any, values: Record<string, any>): void {
    applyStandardChanges(xmlNode, values);
  },
};

const TeardownThreadGroupAdapter: ThreadGroupAdapter = {
  id: 'teardown',
  typeLabel: 'tearDown Thread Group',
  supports(type: string): boolean {
    return type === 'PostThreadGroup';
  },
  getSchema(): ThreadGroupSchema {
    return getStandardSchema();
  },
  extractValues(xmlNode: any): Record<string, any> {
    return extractStandardValues(xmlNode);
  },
  validate(values: Record<string, any>): string[] {
    return validateStandardValues(values);
  },
  applyChanges(xmlNode: any, values: Record<string, any>): void {
    applyStandardChanges(xmlNode, values);
  },
};

interface GenericAdapter extends ThreadGroupAdapter {
  getDynamicSchema(xmlNode: any): ThreadGroupSchema;
}

const GenericThreadGroupAdapter: GenericAdapter = {
  id: 'generic',
  typeLabel: 'Thread Group',
  supports(): boolean {
    return true;
  },
  getSchema(): ThreadGroupSchema {
    return { fields: [] };
  },
  getDynamicSchema(xmlNode: any): ThreadGroupSchema {
    const allProps = getAllProperties(xmlNode);
    const fields: SchemaField[] = [];

    for (const [propName, info] of Object.entries(allProps)) {
      let fieldType: FieldType;

      if (info.type === 'boolProp') {
        fieldType = 'boolean';
      } else if (info.type === 'intProp' || info.type === 'longProp') {
        fieldType = 'number';
      } else {
        const strVal = String(info.value);
        fieldType = strVal !== '' && !isNaN(Number(strVal)) ? 'number' : 'text';
      }

      fields.push({
        key: propName,
        label: humanizePropertyName(propName),
        type: fieldType,
        defaultValue: info.value,
      });
    }

    return { fields };
  },
  extractValues(xmlNode: any): Record<string, any> {
    const allProps = getAllProperties(xmlNode);
    const values: Record<string, any> = {};
    for (const [propName, info] of Object.entries(allProps)) {
      values[propName] = info.value;
    }
    return values;
  },
  validate(values: Record<string, any>): string[] {
    const errors: string[] = [];
    for (const [key, value] of Object.entries(values)) {
      if (value === undefined || value === null) continue;
      if (typeof value === 'number' && isNaN(value)) {
        errors.push(`${humanizePropertyName(key)} has an invalid numeric value`);
      }
    }
    return errors;
  },
  applyChanges(xmlNode: any, values: Record<string, any>): void {
    for (const [propName, value] of Object.entries(values)) {
      setPropertyValue(xmlNode, propName, value);
    }
  },
};

class ThreadGroupAdapterRegistry {
  private adapters: ThreadGroupAdapter[] = [];

  register(adapter: ThreadGroupAdapter): void {
    this.adapters.push(adapter);
  }

  resolve(type: string, xmlNode: any): ThreadGroupAdapter {
    for (const adapter of this.adapters) {
      if (adapter.supports(type, xmlNode)) {
        return adapter;
      }
    }
    return GenericThreadGroupAdapter;
  }
}

export const registry = new ThreadGroupAdapterRegistry();
registry.register(StandardThreadGroupAdapter);
registry.register(SetupThreadGroupAdapter);
registry.register(TeardownThreadGroupAdapter);
registry.register(GenericThreadGroupAdapter);

export function detectThreadGroupType(xmlNode: any, tagName: string): string {
  if (xmlNode?.['@_testclass']) {
    return xmlNode['@_testclass'];
  }
  return tagName;
}

interface FoundThreadGroup {
  xmlNode: any;
  tagName: string;
  type: string;
}

const KNOWN_TG_TAGS = [
  'ThreadGroup',
  'SetupThreadGroup',
  'PostThreadGroup',
  'kg.apc.jmeter.threads.SteppingThreadGroup',
  'com.blazemeter.jmeter.threads.concurrency.ConcurrencyThreadGroup',
  'com.blazemeter.jmeter.threads.arrivals.ArrivalsThreadGroup',
];

function findAllThreadGroups(obj: any, results: FoundThreadGroup[] = []): FoundThreadGroup[] {
  if (!obj || typeof obj !== 'object') return results;

  for (const tagName of KNOWN_TG_TAGS) {
    if (obj[tagName]) {
      const groups = Array.isArray(obj[tagName]) ? obj[tagName] : [obj[tagName]];
      for (const node of groups) {
        const type = detectThreadGroupType(node, tagName);
        results.push({ xmlNode: node, tagName, type });
      }
    }
  }

  for (const key of Object.keys(obj)) {
    if (KNOWN_TG_TAGS.includes(key)) continue;

    const val = obj[key];
    if (val && typeof val === 'object') {
      if (!Array.isArray(val) && val['@_testclass'] && String(val['@_testclass']).includes('ThreadGroup')) {
        const type = detectThreadGroupType(val, key);
        results.push({ xmlNode: val, tagName: key, type });
      } else if (Array.isArray(val)) {
        for (const item of val) {
          if (item && typeof item === 'object' && item['@_testclass'] && String(item['@_testclass']).includes('ThreadGroup')) {
            const type = detectThreadGroupType(item, key);
            results.push({ xmlNode: item, tagName: key, type });
          }
        }
        for (const item of val) {
          if (item && typeof item === 'object') {
            findAllThreadGroups(item, results);
          }
        }
      } else {
        findAllThreadGroups(val, results);
      }
    }
  }

  return results;
}

export function parseThreadGroupsWithAdapters(xmlContent: string): ThreadGroupInfo[] {
  const parser = new XMLParser(PARSER_OPTS);
  const parsed = parser.parse(xmlContent);

  const found = findAllThreadGroups(parsed);
  const infos: ThreadGroupInfo[] = [];

  for (let i = 0; i < found.length; i++) {
    const { xmlNode, type } = found[i];
    const adapter = registry.resolve(type, xmlNode);

    const name = xmlNode['@_testname'] || 'Thread Group';
    const enabled = xmlNode['@_enabled'] !== 'false';

    let schema: ThreadGroupSchema;
    let values: Record<string, any>;

    if (adapter.id === 'generic' && 'getDynamicSchema' in adapter) {
      schema = (adapter as GenericAdapter).getDynamicSchema(xmlNode);
      values = adapter.extractValues(xmlNode);
    } else {
      schema = adapter.getSchema();
      values = adapter.extractValues(xmlNode);
    }

    infos.push({
      index: i,
      name,
      type,
      typeLabel: adapter.typeLabel,
      enabled,
      adapterType: adapter.id,
      schema,
      values,
    });
  }

  return infos;
}

function findThreadGroupRangesInText(xmlContent: string): { start: number; end: number; tagName: string }[] {
  const ranges: { start: number; end: number; tagName: string }[] = [];
  const escapedTags = KNOWN_TG_TAGS.map(t => t.replace(/\./g, '\\.'));
  const tagPattern = new RegExp(
    `<(${escapedTags.join('|')})(?:\\s[^>]*)?>`,
    'g'
  );

  let match;
  while ((match = tagPattern.exec(xmlContent)) !== null) {
    const tagName = match[1];
    const startPos = match.index;
    if (match[0].endsWith('/>')) continue;
    const closingTag = `</${tagName}>`;
    const endPos = xmlContent.indexOf(closingTag, startPos);
    if (endPos === -1) continue;
    ranges.push({ start: startPos, end: endPos + closingTag.length, tagName });
  }

  return ranges;
}

function replacePropertyInBlock(block: string, propName: string, newValue: any): string {
  const escaped = propName.replace(/\./g, '\\.');
  const propRegex = new RegExp(
    `(<(?:stringProp|intProp|longProp|boolProp)\\s+name="${escaped}"[^>]*>)([^<]*)(</(?:stringProp|intProp|longProp|boolProp)>)`,
    'g'
  );
  if (propRegex.test(block)) {
    propRegex.lastIndex = 0;
    return block.replace(propRegex, `$1${String(newValue)}$3`);
  }
  return block;
}

const PROP_TYPE_MAP: Record<string, string> = {
  'ThreadGroup.scheduler': 'boolProp',
  'ThreadGroup.num_threads': 'intProp',
  'ThreadGroup.ramp_time': 'intProp',
  'ThreadGroup.duration': 'longProp',
  'ThreadGroup.delay': 'longProp',
  'ThreadGroup.same_user_on_next_iteration': 'boolProp',
  'LoopController.loops': 'stringProp',
  'LoopController.continue_forever': 'boolProp',
};

function ensurePropertyInBlock(block: string, propName: string, value: any): string {
  const escaped = propName.replace(/\./g, '\\.');
  const propRegex = new RegExp(
    `<(?:stringProp|intProp|longProp|boolProp)\\s+name="${escaped}"`,
  );
  if (propRegex.test(block)) {
    return replacePropertyInBlock(block, propName, value);
  }
  const propType = PROP_TYPE_MAP[propName] || (typeof value === 'boolean' ? 'boolProp' : typeof value === 'number' ? 'intProp' : 'stringProp');
  const newPropTag = `<${propType} name="${propName}">${String(value)}</${propType}>`;

  if (propName.startsWith('LoopController.')) {
    const loopOpenRegex = /<elementProp[^>]*elementType="LoopController"[^>]*>/;
    const loopOpenMatch = block.match(loopOpenRegex);
    if (loopOpenMatch && loopOpenMatch.index !== undefined) {
      const searchStart = loopOpenMatch.index + loopOpenMatch[0].length;
      const closeIdx = block.indexOf('</elementProp>', searchStart);
      if (closeIdx !== -1) {
        const indent = '          ';
        return block.slice(0, closeIdx) + indent + newPropTag + '\n        ' + block.slice(closeIdx);
      }
    }
    return block;
  }

  const closingTagRegex = /<\/(ThreadGroup|SetupThreadGroup|PostThreadGroup)>/;
  const closingMatch = block.match(closingTagRegex);
  if (closingMatch && closingMatch.index !== undefined) {
    const indent = '        ';
    return block.slice(0, closingMatch.index) + indent + newPropTag + '\n      ' + block.slice(closingMatch.index);
  }
  return block;
}

export function updateThreadGroupWithAdapter(
  xmlContent: string,
  index: number,
  values: Record<string, any>
): { xml: string; errors: string[] } {
  const parser = new XMLParser(PARSER_OPTS);
  const parsed = parser.parse(xmlContent);

  const found = findAllThreadGroups(parsed);

  if (index < 0 || index >= found.length) {
    return { xml: xmlContent, errors: [`Thread group at index ${index} not found`] };
  }

  const { xmlNode, type } = found[index];
  const adapter = registry.resolve(type, xmlNode);

  const errors = adapter.validate(values);
  if (errors.length > 0) {
    return { xml: xmlContent, errors };
  }

  const ranges = findThreadGroupRangesInText(xmlContent);
  if (index >= ranges.length) {
    return { xml: xmlContent, errors: [`Thread group at index ${index} not found in XML text`] };
  }

  const range = ranges[index];
  let block = xmlContent.substring(range.start, range.end);

  if (adapter.id === 'standard' || adapter.id === 'setup' || adapter.id === 'teardown') {
    block = ensurePropertyInBlock(block, 'ThreadGroup.num_threads', values.threads);
    block = ensurePropertyInBlock(block, 'ThreadGroup.ramp_time', values.rampUp);
    block = ensurePropertyInBlock(block, 'ThreadGroup.scheduler', values.schedulerEnabled);
    block = ensurePropertyInBlock(block, 'ThreadGroup.duration', values.duration ?? 0);
    block = ensurePropertyInBlock(block, 'ThreadGroup.delay', values.delay ?? 0);

    const loopForever = !!values.loopForever;
    const loopCount = loopForever ? -1 : safeParseInt(values.loopCount, 1);
    block = ensurePropertyInBlock(block, 'LoopController.loops', loopCount);
    block = ensurePropertyInBlock(block, 'LoopController.continue_forever', loopForever);
  } else {
    for (const [propName, value] of Object.entries(values)) {
      block = replacePropertyInBlock(block, propName, value);
    }
  }

  const result = xmlContent.substring(0, range.start) + block + xmlContent.substring(range.end);

  return { xml: result, errors: [] };
}
