import { db } from "./db";
import { 
  testExecutions, comments, notifications, auditLogs, 
  testCompletionReports, cleanupHistory, dumpFiles, dumpAnalysis,
  executionSlaRules, executionMetricBuckets
} from "@shared/schema";
import { sql, lt, and, eq, ne, count, min } from "drizzle-orm";
import { storage } from "./storage";
import { log } from "./index";

export interface CategoryOverview {
  category: string;
  label: string;
  description: string;
  totalCount: number;
  oldestRecordDate: string | null;
  beyondRetentionCount: number;
  pinnedCount?: number;
  retentionDays: number;
}

export interface PreviewResult {
  category: string;
  thresholdDays: number;
  recordsToDelete: number;
  pinnedExcluded: number;
  sampleIds: number[];
  cutoffDate: string;
}

export interface CleanupResult {
  category: string;
  deletedCount: number;
  thresholdDays: number;
  status: string;
}

const CATEGORIES = {
  executions: {
    label: "Test Executions",
    description: "Completed, failed, and cancelled test runs with metrics data",
  },
  notifications: {
    label: "Notifications",
    description: "System alerts, SLA breach notifications, and user messages",
  },
  auditLogs: {
    label: "Audit Logs",
    description: "User activity and system action history",
  },
  reports: {
    label: "Completion Reports",
    description: "Generated test completion reports and snapshots",
  },
  dumpFiles: {
    label: "Dump Files",
    description: "Thread dumps, heap dumps, and GC log uploads",
  },
};

const DEFAULT_RETENTION_DAYS: Record<string, number> = {
  executions: 90,
  notifications: 30,
  auditLogs: 365,
  reports: 180,
  dumpFiles: 60,
};

function getCutoffDate(days: number): Date {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d;
}

export async function getRetentionOverview(): Promise<CategoryOverview[]> {
  const settings = await storage.getAllRetentionSettings();
  const settingsMap: Record<string, number> = {};
  for (const s of settings) {
    settingsMap[s.settingKey] = s.settingValue;
  }

  const results: CategoryOverview[] = [];

  const execTotal = await db.select({ count: count() }).from(testExecutions)
    .where(and(ne(testExecutions.status, 'running'), ne(testExecutions.status, 'queued')));
  const execOldest = await db.select({ oldest: min(testExecutions.startTime) }).from(testExecutions);
  const retDays = settingsMap['executions'] || DEFAULT_RETENTION_DAYS.executions;
  const cutoff = getCutoffDate(retDays);
  const execBeyond = await db.select({ count: count() }).from(testExecutions)
    .where(and(
      ne(testExecutions.status, 'running'),
      ne(testExecutions.status, 'queued'),
      lt(testExecutions.startTime, cutoff.toISOString()),
      sql`(${testExecutions.isPinned} IS NULL OR ${testExecutions.isPinned} = false)`
    ));
  const execPinned = await db.select({ count: count() }).from(testExecutions)
    .where(eq(testExecutions.isPinned, true));
  
  results.push({
    category: "executions",
    label: CATEGORIES.executions.label,
    description: CATEGORIES.executions.description,
    totalCount: execTotal[0]?.count || 0,
    oldestRecordDate: execOldest[0]?.oldest || null,
    beyondRetentionCount: execBeyond[0]?.count || 0,
    pinnedCount: execPinned[0]?.count || 0,
    retentionDays: retDays,
  });

  const notifTotal = await db.select({ count: count() }).from(notifications);
  const notifOldest = await db.select({ oldest: min(notifications.createdAt) }).from(notifications);
  const notifRetDays = settingsMap['notifications'] || DEFAULT_RETENTION_DAYS.notifications;
  const notifCutoff = getCutoffDate(notifRetDays);
  const notifBeyond = await db.select({ count: count() }).from(notifications)
    .where(lt(notifications.createdAt, notifCutoff));
  results.push({
    category: "notifications",
    label: CATEGORIES.notifications.label,
    description: CATEGORIES.notifications.description,
    totalCount: notifTotal[0]?.count || 0,
    oldestRecordDate: notifOldest[0]?.oldest ? new Date(notifOldest[0].oldest).toISOString() : null,
    beyondRetentionCount: notifBeyond[0]?.count || 0,
    retentionDays: notifRetDays,
  });

  const auditTotal = await db.select({ count: count() }).from(auditLogs);
  const auditOldest = await db.select({ oldest: min(auditLogs.timestamp) }).from(auditLogs);
  const auditRetDays = settingsMap['auditLogs'] || DEFAULT_RETENTION_DAYS.auditLogs;
  const auditCutoff = getCutoffDate(auditRetDays);
  const auditBeyond = await db.select({ count: count() }).from(auditLogs)
    .where(lt(auditLogs.timestamp, auditCutoff));
  results.push({
    category: "auditLogs",
    label: CATEGORIES.auditLogs.label,
    description: CATEGORIES.auditLogs.description,
    totalCount: auditTotal[0]?.count || 0,
    oldestRecordDate: auditOldest[0]?.oldest ? new Date(auditOldest[0].oldest).toISOString() : null,
    beyondRetentionCount: auditBeyond[0]?.count || 0,
    retentionDays: auditRetDays,
  });

  const reportTotal = await db.select({ count: count() }).from(testCompletionReports);
  const reportOldest = await db.select({ oldest: min(testCompletionReports.createdAt) }).from(testCompletionReports);
  const reportRetDays = settingsMap['reports'] || DEFAULT_RETENTION_DAYS.reports;
  const reportCutoff = getCutoffDate(reportRetDays);
  const reportBeyond = await db.select({ count: count() }).from(testCompletionReports)
    .where(lt(testCompletionReports.createdAt, reportCutoff.toISOString()));
  results.push({
    category: "reports",
    label: CATEGORIES.reports.label,
    description: CATEGORIES.reports.description,
    totalCount: reportTotal[0]?.count || 0,
    oldestRecordDate: reportOldest[0]?.oldest || null,
    beyondRetentionCount: reportBeyond[0]?.count || 0,
    retentionDays: reportRetDays,
  });

  const dumpTotal = await db.select({ count: count() }).from(dumpFiles);
  const dumpOldest = await db.select({ oldest: min(dumpFiles.createdAt) }).from(dumpFiles);
  const dumpRetDays = settingsMap['dumpFiles'] || DEFAULT_RETENTION_DAYS.dumpFiles;
  const dumpCutoff = getCutoffDate(dumpRetDays);
  const dumpBeyond = await db.select({ count: count() }).from(dumpFiles)
    .where(sql`${dumpFiles.createdAt} < ${dumpCutoff.toISOString()}`);
  results.push({
    category: "dumpFiles",
    label: CATEGORIES.dumpFiles.label,
    description: CATEGORIES.dumpFiles.description,
    totalCount: dumpTotal[0]?.count || 0,
    oldestRecordDate: dumpOldest[0]?.oldest ? new Date(dumpOldest[0].oldest).toISOString() : null,
    beyondRetentionCount: dumpBeyond[0]?.count || 0,
    retentionDays: dumpRetDays,
  });

  return results;
}

export async function previewCleanup(category: string): Promise<PreviewResult> {
  const settings = await storage.getAllRetentionSettings();
  const settingsMap: Record<string, number> = {};
  for (const s of settings) settingsMap[s.settingKey] = s.settingValue;

  const retDays = settingsMap[category] || DEFAULT_RETENTION_DAYS[category] || 90;
  const cutoff = getCutoffDate(retDays);

  switch (category) {
    case "executions": {
      const beyond = await db.select({ id: testExecutions.id }).from(testExecutions)
        .where(and(
          ne(testExecutions.status, 'running'),
          ne(testExecutions.status, 'queued'),
          lt(testExecutions.startTime, cutoff.toISOString()),
          sql`(${testExecutions.isPinned} IS NULL OR ${testExecutions.isPinned} = false)`
        )).limit(20);
      
      const totalBeyond = await db.select({ count: count() }).from(testExecutions)
        .where(and(
          ne(testExecutions.status, 'running'),
          ne(testExecutions.status, 'queued'),
          lt(testExecutions.startTime, cutoff.toISOString()),
          sql`(${testExecutions.isPinned} IS NULL OR ${testExecutions.isPinned} = false)`
        ));
      
      const pinned = await db.select({ count: count() }).from(testExecutions)
        .where(and(
          eq(testExecutions.isPinned, true),
          lt(testExecutions.startTime, cutoff.toISOString())
        ));

      return {
        category,
        thresholdDays: retDays,
        recordsToDelete: totalBeyond[0]?.count || 0,
        pinnedExcluded: pinned[0]?.count || 0,
        sampleIds: beyond.map(r => r.id),
        cutoffDate: cutoff.toISOString(),
      };
    }
    case "notifications": {
      const beyond = await db.select({ id: notifications.id }).from(notifications)
        .where(lt(notifications.createdAt, cutoff)).limit(20);
      const totalBeyond = await db.select({ count: count() }).from(notifications)
        .where(lt(notifications.createdAt, cutoff));
      return {
        category,
        thresholdDays: retDays,
        recordsToDelete: totalBeyond[0]?.count || 0,
        pinnedExcluded: 0,
        sampleIds: beyond.map(r => r.id),
        cutoffDate: cutoff.toISOString(),
      };
    }
    case "auditLogs": {
      const beyond = await db.select({ id: auditLogs.id }).from(auditLogs)
        .where(lt(auditLogs.timestamp, cutoff)).limit(20);
      const totalBeyond = await db.select({ count: count() }).from(auditLogs)
        .where(lt(auditLogs.timestamp, cutoff));
      return {
        category,
        thresholdDays: retDays,
        recordsToDelete: totalBeyond[0]?.count || 0,
        pinnedExcluded: 0,
        sampleIds: beyond.map(r => r.id),
        cutoffDate: cutoff.toISOString(),
      };
    }
    case "reports": {
      const beyond = await db.select({ id: testCompletionReports.id }).from(testCompletionReports)
        .where(lt(testCompletionReports.createdAt, cutoff.toISOString())).limit(20);
      const totalBeyond = await db.select({ count: count() }).from(testCompletionReports)
        .where(lt(testCompletionReports.createdAt, cutoff.toISOString()));
      return {
        category,
        thresholdDays: retDays,
        recordsToDelete: totalBeyond[0]?.count || 0,
        pinnedExcluded: 0,
        sampleIds: beyond.map(r => r.id),
        cutoffDate: cutoff.toISOString(),
      };
    }
    case "dumpFiles": {
      const beyond = await db.select({ id: dumpFiles.id }).from(dumpFiles)
        .where(sql`${dumpFiles.createdAt} < ${cutoff.toISOString()}`).limit(20);
      const totalBeyond = await db.select({ count: count() }).from(dumpFiles)
        .where(sql`${dumpFiles.createdAt} < ${cutoff.toISOString()}`);
      return {
        category,
        thresholdDays: retDays,
        recordsToDelete: totalBeyond[0]?.count || 0,
        pinnedExcluded: 0,
        sampleIds: beyond.map(r => r.id),
        cutoffDate: cutoff.toISOString(),
      };
    }
    default:
      throw new Error(`Unknown category: ${category}`);
  }
}

export async function runCleanup(category: string, userId: number): Promise<CleanupResult> {
  const settings = await storage.getAllRetentionSettings();
  const settingsMap: Record<string, number> = {};
  for (const s of settings) settingsMap[s.settingKey] = s.settingValue;

  const retDays = settingsMap[category] || DEFAULT_RETENTION_DAYS[category] || 90;
  const cutoff = getCutoffDate(retDays);
  let deletedCount = 0;

  const [historyRecord] = await db.insert(cleanupHistory).values({
    category,
    thresholdDays: retDays,
    initiatedBy: userId,
    status: "running",
  }).returning();

  try {
    const BATCH_SIZE = 100;

    switch (category) {
      case "executions": {
        const fs = await import("fs");
        let batch;
        do {
          batch = await db.select({ id: testExecutions.id, artifactsPath: testExecutions.artifactsPath }).from(testExecutions)
            .where(and(
              ne(testExecutions.status, 'running'),
              ne(testExecutions.status, 'queued'),
              lt(testExecutions.startTime, cutoff.toISOString()),
              sql`(${testExecutions.isPinned} IS NULL OR ${testExecutions.isPinned} = false)`
            )).limit(BATCH_SIZE);

          if (batch.length === 0) break;
          const ids = batch.map(r => r.id);

          await db.delete(comments).where(sql`${comments.executionId} IN (${sql.join(ids.map(id => sql`${id}`), sql`, `)})`);
          await db.delete(executionSlaRules).where(sql`${executionSlaRules.executionId} IN (${sql.join(ids.map(id => sql`${id}`), sql`, `)})`);
          await db.delete(executionMetricBuckets).where(sql`${executionMetricBuckets.executionId} IN (${sql.join(ids.map(id => sql`${id}`), sql`, `)})`);
          await db.delete(testExecutions).where(sql`${testExecutions.id} IN (${sql.join(ids.map(id => sql`${id}`), sql`, `)})`);

          for (const row of batch) {
            if (row.artifactsPath) {
              try {
                if (fs.existsSync(row.artifactsPath)) {
                  fs.rmSync(row.artifactsPath, { recursive: true, force: true });
                }
              } catch {}
            }
          }

          deletedCount += batch.length;
        } while (batch.length === BATCH_SIZE);
        break;
      }
      case "notifications": {
        const result = await db.delete(notifications)
          .where(lt(notifications.createdAt, cutoff));
        deletedCount = (result as any).rowCount || 0;
        break;
      }
      case "auditLogs": {
        const result = await db.delete(auditLogs)
          .where(lt(auditLogs.timestamp, cutoff));
        deletedCount = (result as any).rowCount || 0;
        break;
      }
      case "reports": {
        const result = await db.delete(testCompletionReports)
          .where(lt(testCompletionReports.createdAt, cutoff.toISOString()));
        deletedCount = (result as any).rowCount || 0;
        break;
      }
      case "dumpFiles": {
        const oldDumps = await db.select({ id: dumpFiles.id }).from(dumpFiles)
          .where(sql`${dumpFiles.createdAt} < ${cutoff.toISOString()}`);
        if (oldDumps.length > 0) {
          const ids = oldDumps.map(r => r.id);
          await db.delete(dumpAnalysis).where(sql`${dumpAnalysis.dumpFileId} IN (${sql.join(ids.map(id => sql`${id}`), sql`, `)})`);
          await db.delete(dumpFiles).where(sql`${dumpFiles.id} IN (${sql.join(ids.map(id => sql`${id}`), sql`, `)})`);
          deletedCount = ids.length;
        }
        break;
      }
      default:
        throw new Error(`Unknown category: ${category}`);
    }

    await db.update(cleanupHistory)
      .set({ deletedCount, status: "completed", completedAt: new Date().toISOString() })
      .where(eq(cleanupHistory.id, historyRecord.id));

    log(`Cleanup completed for ${category}: ${deletedCount} records deleted`, "retention");

    return { category, deletedCount, thresholdDays: retDays, status: "completed" };
  } catch (error: any) {
    await db.update(cleanupHistory)
      .set({ status: "failed", notes: error.message, completedAt: new Date().toISOString() })
      .where(eq(cleanupHistory.id, historyRecord.id));

    log(`Cleanup failed for ${category}: ${error.message}`, "retention");
    throw error;
  }
}

export async function getCleanupHistory(limit = 20, offset = 0) {
  const records = await db.select().from(cleanupHistory)
    .orderBy(sql`${cleanupHistory.startedAt} DESC`)
    .limit(limit).offset(offset);
  const total = await db.select({ count: count() }).from(cleanupHistory);
  return { records, total: total[0]?.count || 0 };
}
