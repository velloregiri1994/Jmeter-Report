import { XMLParser } from "fast-xml-parser";
import fs from "fs";

export interface JmxAnalysisResult {
  testName: string;
  requestCount: number;
  transactionGroups: number;
  domains: string[];
  correlations: AnalyzedCorrelation[];
  parameterizations: AnalyzedParameterization[];
  issues: AnalyzedIssue[];
  hasAssertions: boolean;
  hasCookieManager: boolean;
  hasHttpDefaults: boolean;
  hasKeepalive: boolean;
  hasTimeouts: boolean;
  hasTimers: boolean;
  hasCsvDataSet: boolean;
  threadCount: number;
  rampUp: number;
  duration: number;
}

export interface AnalyzedCorrelation {
  variable: string;
  extractorType: "json" | "regex" | "header" | "boundary" | "xpath" | "css";
  pattern: string;
  sourceRequest: string;
  targetRequests: string[];
  originalValue: string;
}

export interface AnalyzedParameterization {
  variable: string;
  originalValue: string;
  occurrences: { requestIndex: number; location: string; fieldName: string }[];
}

export interface AnalyzedIssue {
  severity: "warning" | "info";
  message: string;
  request?: string;
}

function getPropertyValue(props: any, propName: string, defaultValue: any = null): any {
  if (!props) return defaultValue;
  const propTypes = ["stringProp", "intProp", "longProp", "boolProp"];
  for (const propType of propTypes) {
    const propList = props[propType];
    if (!propList) continue;
    const items = Array.isArray(propList) ? propList : [propList];
    for (const item of items) {
      if (item?.["@_name"] === propName) {
        const value = item["#text"];
        if (value === undefined || value === null) {
          if (propType === "boolProp") return false;
          if (propType === "intProp" || propType === "longProp") return defaultValue;
          return "";
        }
        if (propType === "boolProp") return String(value).toLowerCase() === "true";
        if (propType === "intProp" || propType === "longProp") {
          const parsed = parseInt(String(value), 10);
          return Number.isNaN(parsed) ? defaultValue : parsed;
        }
        return typeof value === "string" ? value : String(value);
      }
    }
  }
  const elementProps = props.elementProp;
  if (elementProps) {
    const epItems = Array.isArray(elementProps) ? elementProps : [elementProps];
    for (const ep of epItems) {
      if (ep?.["@_name"] === propName) {
        return ep;
      }
      const nested = getPropertyValue(ep, propName, undefined);
      if (nested !== undefined) return nested;
    }
  }
  const collectionProps = props.collectionProp;
  if (collectionProps) {
    const cpItems = Array.isArray(collectionProps) ? collectionProps : [collectionProps];
    for (const cp of cpItems) {
      if (cp?.["@_name"] === propName) {
        return cp;
      }
    }
  }
  return defaultValue;
}

function extractAllArgumentValues(sampler: any): string[] {
  const values: string[] = [];
  const argsElem = getPropertyValue(sampler, "HTTPsampler.Arguments", null) ||
                   getPropertyValue(sampler, "HTTPSampler.Arguments", null);
  if (!argsElem) return values;

  const collection = argsElem.collectionProp;
  if (!collection) return values;

  const elementProps = collection.elementProp;
  if (!elementProps) return values;

  const items = Array.isArray(elementProps) ? elementProps : [elementProps];
  for (const item of items) {
    const val = getPropertyValue(item, "Argument.value", "");
    const name = getPropertyValue(item, "Argument.name", "");
    if (val) values.push(val);
    if (name) values.push(name);
  }
  return values;
}

function extractAllHeaders(sampler: any): string[] {
  const headers: string[] = [];
  const headerManager = sampler.HeaderManager;
  if (!headerManager) return headers;

  const collection = getPropertyValue(headerManager, "HeaderManager.headers", null);
  if (!collection?.elementProp) return headers;

  const items = Array.isArray(collection.elementProp) ? collection.elementProp : [collection.elementProp];
  for (const item of items) {
    const val = getPropertyValue(item, "Header.value", "");
    if (val) headers.push(val);
  }
  return headers;
}

function getSamplerFullText(sampler: any): string {
  const path = extractPath(sampler);
  const argValues = extractAllArgumentValues(sampler);
  const headers = extractAllHeaders(sampler);
  return [path, ...argValues, ...headers].join(" ");
}

function findAll(obj: any, tagName: string, results: any[] = []): any[] {
  if (!obj || typeof obj !== "object") return results;
  if (obj[tagName]) {
    const items = Array.isArray(obj[tagName]) ? obj[tagName] : [obj[tagName]];
    results.push(...items);
  }
  for (const key of Object.keys(obj)) {
    if (key.startsWith("@_") || key === "#text") continue;
    const child = obj[key];
    if (Array.isArray(child)) {
      for (const item of child) findAll(item, tagName, results);
    } else if (typeof child === "object" && child !== null) {
      findAll(child, tagName, results);
    }
  }
  return results;
}

const EXTRACTOR_TAGS = new Set([
  "RegexExtractor", "JSONPostProcessor",
  "com.atlantbh.jmeter.plugins.jsonutils.jsonpathextractor.JSONPostProcessor",
  "XPathExtractor", "BoundaryExtractor", "CSSJQueryExtractor", "HtmlExtractor",
]);

const CONTAINER_TAGS = new Set([
  "ThreadGroup", "TestPlan", "TransactionController", "GenericController",
  "LoopController", "WhileController", "IfController", "ModuleController",
]);

function buildExtractorToSamplerMap(parsed: any): Map<any, string> {
  const map = new Map<any, string>();

  function markExtractorsInHashTree(ht: any, samplerName: string) {
    if (!ht || typeof ht !== "object") return;
    for (const key of Object.keys(ht)) {
      if (key.startsWith("@_") || key === "#text" || key === "hashTree") continue;
      if (EXTRACTOR_TAGS.has(key)) {
        const items = Array.isArray(ht[key]) ? ht[key] : [ht[key]];
        for (const item of items) {
          if (item && typeof item === "object") {
            map.set(item, samplerName);
          }
        }
      }
    }
  }

  function walkHashTree(ht: any) {
    if (!ht || typeof ht !== "object") return;

    const elementKeys: string[] = [];
    for (const key of Object.keys(ht)) {
      if (key === "hashTree" || key.startsWith("@_") || key === "#text") continue;
      elementKeys.push(key);
    }

    const siblingElements: { tag: string; el: any }[] = [];
    for (const key of elementKeys) {
      const items = Array.isArray(ht[key]) ? ht[key] : [ht[key]];
      for (const item of items) {
        if (item && typeof item === "object") {
          siblingElements.push({ tag: key, el: item });
        }
      }
    }

    const childHashTrees: any[] = [];
    if (ht.hashTree) {
      const htArr = Array.isArray(ht.hashTree) ? ht.hashTree : [ht.hashTree];
      childHashTrees.push(...htArr);
    }

    for (let i = 0; i < siblingElements.length; i++) {
      const { tag, el } = siblingElements[i];
      const childHt = i < childHashTrees.length ? childHashTrees[i] : null;

      if (tag === "HTTPSamplerProxy") {
        const samplerName = el["@_testname"] || "Unnamed Request";
        if (childHt) {
          markExtractorsInHashTree(childHt, samplerName);
        }
      } else if (CONTAINER_TAGS.has(tag)) {
        if (childHt) {
          walkHashTree(childHt);
        }
      }
    }
  }

  const root = parsed?.jmeterTestPlan?.hashTree;
  if (root) {
    walkHashTree(root);
  }

  return map;
}

function extractSamplerName(sampler: any): string {
  return sampler["@_testname"] || "Unnamed Request";
}

function extractDomain(sampler: any): string | null {
  const domain = getPropertyValue(sampler, "HTTPSampler.domain", null);
  return domain || null;
}

function extractMethod(sampler: any): string {
  return getPropertyValue(sampler, "HTTPSampler.method", "GET");
}

function extractPath(sampler: any): string {
  return getPropertyValue(sampler, "HTTPSampler.path", "/");
}

const STATIC_EXTENSIONS = new Set([
  ".css", ".js", ".mjs", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico",
  ".woff", ".woff2", ".ttf", ".eot", ".map", ".webp", ".avif", ".mp4", ".webm",
  ".bmp", ".tiff", ".otf", ".swf", ".less", ".scss",
]);

const THIRD_PARTY_DOMAINS = new Set([
  "google-analytics.com", "googletagmanager.com", "doubleclick.net",
  "googlesyndication.com", "googleapis.com", "gstatic.com",
  "facebook.net", "fbcdn.net", "facebook.com",
  "hotjar.com", "clarity.ms", "mouseflow.com", "crazyegg.com",
  "newrelic.com", "nr-data.net", "dynatrace.com", "appdynamics.com",
  "segment.io", "cdn.segment.com", "segment.com",
  "mixpanel.com", "optimizely.com", "fullstory.com", "sentry.io",
  "intercom.io", "zendesk.com", "hubspot.com", "hs-scripts.com",
  "cdn.jsdelivr.net", "cdnjs.cloudflare.com", "unpkg.com",
  "fonts.googleapis.com", "fonts.gstatic.com",
  "twitter.com", "platform.twitter.com", "linkedin.com",
  "analytics.google.com", "adservice.google.com",
  "bat.bing.com", "snap.licdn.com", "px.ads.linkedin.com",
  "connect.facebook.net", "www.googleadservices.com",
  "tealiumiq.com", "tags.tiqcdn.com",
  "amplitude.com", "heapanalytics.com", "heap.io",
  "launchdarkly.com", "split.io",
  "cdn.cookielaw.org", "onetrust.com",
]);

const UUID_REGEX = /\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b/gi;
const JWT_REGEX = /eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g;
const CSRF_HEX_REGEX = /\b[0-9a-f]{32,64}\b/gi;
const BASE64_TOKEN_REGEX = /(?:[A-Za-z0-9+/]{4}){6,}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?/g;

const CREDENTIAL_FIELD_NAMES: Record<string, string> = {
  username: "P_USERNAME", user: "P_USERNAME", login: "P_USERNAME",
  user_name: "P_USERNAME", username2: "P_USERNAME", email: "P_EMAIL",
  user_email: "P_EMAIL", useremail: "P_EMAIL", password: "P_PASSWORD",
  pass: "P_PASSWORD", pwd: "P_PASSWORD", passwd: "P_PASSWORD",
};

interface FrameworkField {
  variable: string;
  description: string;
  framework: string;
}

const FRAMEWORK_DYNAMIC_FIELDS: Record<string, FrameworkField> = {
  "__viewstate": { variable: "C_viewState", description: "ASP.NET ViewState (changes every page load)", framework: "ASP.NET" },
  "__viewstategenerator": { variable: "C_viewStateGenerator", description: "ASP.NET ViewState Generator", framework: "ASP.NET" },
  "__eventvalidation": { variable: "C_eventValidation", description: "ASP.NET Event Validation", framework: "ASP.NET" },
  "__requestverificationtoken": { variable: "C_requestVerificationToken", description: "ASP.NET Anti-Forgery Token", framework: "ASP.NET" },
  "__previouspage": { variable: "C_previousPage", description: "ASP.NET Previous Page reference", framework: "ASP.NET" },
  "__viewstateencrypted": { variable: "C_viewStateEncrypted", description: "ASP.NET ViewState Encrypted marker", framework: "ASP.NET" },
  "__eventtarget": { variable: "C_eventTarget", description: "ASP.NET Event Target (postback control identifier)", framework: "ASP.NET" },
  "__eventargument": { variable: "C_eventArgument", description: "ASP.NET Event Argument (postback argument)", framework: "ASP.NET" },

  "csrfmiddlewaretoken": { variable: "C_csrfMiddlewareToken", description: "Django CSRF middleware token", framework: "Django" },
  "csrftoken": { variable: "C_csrfToken_django", description: "Django CSRF cookie token", framework: "Django" },

  "authenticity_token": { variable: "C_authenticityToken", description: "Rails CSRF authenticity token", framework: "Rails" },

  "_token": { variable: "C_laravelToken", description: "Laravel CSRF token", framework: "Laravel" },
  "xsrf-token": { variable: "C_xsrfToken_laravel", description: "Laravel XSRF cookie token", framework: "Laravel" },

  "_csrf": { variable: "C_springCsrf", description: "Spring Security CSRF token", framework: "Spring" },

  "_wpnonce": { variable: "C_wpNonce", description: "WordPress nonce (one-time security token)", framework: "WordPress" },
  "wp_nonce": { variable: "C_wpNonce", description: "WordPress nonce", framework: "WordPress" },
  "_wp_http_referer": { variable: "C_wpHttpReferer", description: "WordPress HTTP referer field", framework: "WordPress" },

  "form_build_id": { variable: "C_formBuildId", description: "Drupal form build ID (unique per form render)", framework: "Drupal" },
  "form_token": { variable: "C_formToken", description: "Drupal CSRF form token", framework: "Drupal" },
  "form_id": { variable: "C_formId", description: "Drupal form identifier", framework: "Drupal" },

  "form_key": { variable: "C_formKey", description: "Magento form key (CSRF protection)", framework: "Magento" },

  "icsid": { variable: "C_icsId", description: "PeopleSoft session ID", framework: "PeopleSoft" },
  "icstatenum": { variable: "C_icStateNum", description: "PeopleSoft state number (increments per request)", framework: "PeopleSoft" },
  "icactionprompt": { variable: "C_icActionPrompt", description: "PeopleSoft action prompt", framework: "PeopleSoft" },
  "icaction": { variable: "C_icAction", description: "PeopleSoft navigation action", framework: "PeopleSoft" },

  "swec": { variable: "C_sweCount", description: "Siebel click count (changes every request)", framework: "Siebel" },
  "swerowid": { variable: "C_sweRowId", description: "Siebel record row ID", framework: "Siebel" },
  "swerowids": { variable: "C_sweRowIds", description: "Siebel record row IDs", framework: "Siebel" },
  "swefi": { variable: "C_sweFrameId", description: "Siebel frame ID", framework: "Siebel" },
  "swevlc": { variable: "C_sweViewLayoutChecksum", description: "Siebel view layout checksum", framework: "Siebel" },

  "sysparm_ck": { variable: "C_sysparmCk", description: "ServiceNow session check token", framework: "ServiceNow" },
  "sysparm_transaction_scope": { variable: "C_sysparmTransactionScope", description: "ServiceNow transaction scope", framework: "ServiceNow" },
  "x-usertoken": { variable: "C_serviceNowUserToken", description: "ServiceNow user token header", framework: "ServiceNow" },

  "javax.faces.viewstate": { variable: "C_jsfViewState", description: "JSF ViewState (changes every page)", framework: "JSF" },
  "javax.faces.clientwindow": { variable: "C_jsfClientWindow", description: "JSF client window ID", framework: "JSF" },

  "icx_ticket": { variable: "C_icxTicket", description: "Oracle EBS session ticket", framework: "Oracle EBS" },

  "com.salesforce.visualforce.viewstateid": { variable: "C_sfViewStateId", description: "Salesforce VisualForce ViewState ID", framework: "Salesforce" },
  "com.salesforce.visualforce.viewstateversion": { variable: "C_sfViewStateVersion", description: "Salesforce VisualForce ViewState version", framework: "Salesforce" },
  "com.salesforce.visualforce.viewstatemac": { variable: "C_sfViewStateMAC", description: "Salesforce VisualForce ViewState MAC", framework: "Salesforce" },

  ".aspnetcore.antiforgery": { variable: "C_aspNetCoreAntiforgery", description: "ASP.NET Core Anti-Forgery cookie token", framework: "ASP.NET Core" },

  "jsessionid": { variable: "C_jSessionId", description: "Java session ID cookie", framework: "Java" },
  "phpsessid": { variable: "C_phpSessionId", description: "PHP session ID cookie", framework: "PHP" },
  "asp.net_sessionid": { variable: "C_aspNetSessionId", description: "ASP.NET session ID cookie", framework: "ASP.NET" },
  "connect.sid": { variable: "C_connectSid", description: "Express/Node.js session ID cookie", framework: "Express/Node.js" },
  "laravel_session": { variable: "C_laravelSession", description: "Laravel session cookie", framework: "Laravel" },
  "_rails_session": { variable: "C_railsSession", description: "Rails session cookie", framework: "Rails" },
  "sessionid": { variable: "C_djangoSessionId", description: "Django session ID cookie", framework: "Django" },
};

function isFrameworkDynamicField(name: string): FrameworkField | null {
  const lower = name.toLowerCase().trim();
  const match = FRAMEWORK_DYNAMIC_FIELDS[lower];
  if (match) return match;
  if (lower === "requestverificationtoken" || lower === "__requestverificationtoken_header") {
    return FRAMEWORK_DYNAMIC_FIELDS["__requestverificationtoken"];
  }
  if (lower === "viewstate" || lower === "javax.faces.viewstate") {
    return FRAMEWORK_DYNAMIC_FIELDS["javax.faces.viewstate"] || FRAMEWORK_DYNAMIC_FIELDS["__viewstate"];
  }
  if (lower.startsWith('.aspnetcore.antiforgery')) {
    return FRAMEWORK_DYNAMIC_FIELDS[".aspnetcore.antiforgery"];
  }
  return null;
}

function isDotNetDynamicField(name: string): FrameworkField | null {
  return isFrameworkDynamicField(name);
}

const STATIC_VALUES = new Set([
  "true", "false", "null", "undefined", "none", "yes", "no",
  "application/json", "text/html", "text/plain", "utf-8", "gzip",
  "keep-alive", "close", "no-cache", "no-store", "max-age=0",
]);

function isStaticResourcePath(urlPath: string): boolean {
  const cleanPath = urlPath.split("?")[0].toLowerCase();
  const lastDotIdx = cleanPath.lastIndexOf(".");
  if (lastDotIdx === -1) return false;
  const ext = cleanPath.substring(lastDotIdx);
  return STATIC_EXTENSIONS.has(ext);
}

function isThirdPartyDomain(domain: string): boolean {
  const lower = domain.toLowerCase();
  for (const tpd of THIRD_PARTY_DOMAINS) {
    if (lower === tpd || lower.endsWith("." + tpd)) return true;
  }
  return false;
}

function extractNameValuePairs(sampler: any): { name: string; value: string }[] {
  const pairs: { name: string; value: string }[] = [];
  const argsElem = getPropertyValue(sampler, "HTTPsampler.Arguments", null) ||
                   getPropertyValue(sampler, "HTTPSampler.Arguments", null);
  if (!argsElem) return pairs;

  const collection = argsElem.collectionProp;
  if (!collection) return pairs;

  const elementProps = collection.elementProp;
  if (!elementProps) return pairs;

  const items = Array.isArray(elementProps) ? elementProps : [elementProps];
  for (const item of items) {
    const name = getPropertyValue(item, "Argument.name", "");
    const value = getPropertyValue(item, "Argument.value", "");
    if (name || value) pairs.push({ name, value });
  }
  return pairs;
}

function isDynamicCandidate(value: string): boolean {
  if (value.length < 8) return false;
  if (STATIC_VALUES.has(value.toLowerCase())) return false;
  if (/^https?:\/\//.test(value)) return false;
  if (/^\d+\.\d+\.\d+/.test(value) && value.length < 20) return false;
  if (/^\$\{/.test(value)) return false;
  return true;
}

function matchesKnownPattern(value: string): string | null {
  UUID_REGEX.lastIndex = 0;
  if (UUID_REGEX.test(value)) { UUID_REGEX.lastIndex = 0; return "uuid"; }
  JWT_REGEX.lastIndex = 0;
  if (JWT_REGEX.test(value)) { JWT_REGEX.lastIndex = 0; return "jwt"; }
  CSRF_HEX_REGEX.lastIndex = 0;
  if (CSRF_HEX_REGEX.test(value) && value.length >= 32) { CSRF_HEX_REGEX.lastIndex = 0; return "csrf_hex"; }
  BASE64_TOKEN_REGEX.lastIndex = 0;
  if (BASE64_TOKEN_REGEX.test(value) && value.length >= 24) { BASE64_TOKEN_REGEX.lastIndex = 0; return "base64_token"; }
  return null;
}

function generateVariableName(context: string, existingNames: Set<string>, idx: number): string {
  let base = "C_dynamicValue";
  if (context === "uuid") base = "C_dynamicId";
  else if (context === "jwt") base = "C_authToken";
  else if (context === "csrf_hex") base = "C_csrfToken";
  else if (context === "base64_token") base = "C_sessionToken";

  let name = base;
  let counter = 1;
  while (existingNames.has(name)) {
    name = `${base}_${counter}`;
    counter++;
  }
  existingNames.add(name);
  return name;
}

export function analyzeJmxFile(filePath: string): JmxAnalysisResult {
  const content = fs.readFileSync(filePath, "utf-8");
  return analyzeJmxContent(content);
}

export function analyzeJmxContent(content: string): JmxAnalysisResult {
  const parser = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: "@_",
    textNodeName: "#text",
    parseAttributeValue: false,
    parseTagValue: false,
  });

  const parsed = parser.parse(content);

  if (!parsed?.jmeterTestPlan) {
    throw new Error("Invalid JMX file: missing <jmeterTestPlan> root element. This does not appear to be a valid JMeter test plan.");
  }

  const testName = parsed?.jmeterTestPlan?.hashTree?.TestPlan?.["@_testname"] || "JMeter Test Plan";

  const samplers = findAll(parsed, "HTTPSamplerProxy");
  const transactionControllers = findAll(parsed, "TransactionController");
  const cookieManagers = findAll(parsed, "CookieManager");
  const csvDataSets = findAll(parsed, "CSVDataSet");
  const responseAssertions = findAll(parsed, "ResponseAssertion");
  const jsonAssertions = findAll(parsed, "JSONPathAssertion");
  const configElements = findAll(parsed, "ConfigTestElement");
  const threadGroups = findAll(parsed, "ThreadGroup");

  const constantTimers = findAll(parsed, "ConstantTimer");
  const uniformTimers = findAll(parsed, "UniformRandomTimer");
  const gaussianTimers = findAll(parsed, "GaussianRandomTimer");
  const poissonTimers = findAll(parsed, "PoissonRandomTimer");
  const throughputTimers = findAll(parsed, "ConstantThroughputTimer");

  const regexExtractors = findAll(parsed, "RegexExtractor");
  const jsonExtractors = [
    ...findAll(parsed, "JSONPostProcessor"),
    ...findAll(parsed, "com.atlantbh.jmeter.plugins.jsonutils.jsonpathextractor.JSONPostProcessor"),
  ];
  const xpathExtractors = findAll(parsed, "XPathExtractor");
  const boundaryExtractors = findAll(parsed, "BoundaryExtractor");
  const cssExtractors = [
    ...findAll(parsed, "CSSJQueryExtractor"),
    ...findAll(parsed, "HtmlExtractor"),
  ];

  const domains: string[] = [];
  for (const sampler of samplers) {
    const d = extractDomain(sampler);
    if (d && !domains.includes(d)) domains.push(d);
  }

  for (const cfg of configElements) {
    const d = getPropertyValue(cfg, "HTTPSampler.domain", null);
    if (d && !domains.includes(d)) domains.push(d);
  }

  const hasHttpDefaults = configElements.some(
    (c: any) => c["@_guiclass"] === "HttpDefaultsGui" || getPropertyValue(c, "HTTPSampler.domain", null)
  );

  const hasKeepalive = samplers.some(
    (s: any) => getPropertyValue(s, "HTTPSampler.use_keepalive", null) === true || getPropertyValue(s, "HTTPSampler.use_keepalive", null) === "true"
  ) || hasHttpDefaults;

  const hasTimeouts = samplers.some(
    (s: any) => getPropertyValue(s, "HTTPSampler.connect_timeout", null) || getPropertyValue(s, "HTTPSampler.response_timeout", null)
  ) || configElements.some(
    (c: any) => getPropertyValue(c, "HTTPSampler.connect_timeout", null) || getPropertyValue(c, "HTTPSampler.response_timeout", null)
  );

  let threadCount = 1;
  let rampUp = 1;
  let duration = 0;
  if (threadGroups.length > 0) {
    const tg = threadGroups[0];
    const rawThreads = parseInt(String(getPropertyValue(tg, "ThreadGroup.num_threads", 1)), 10);
    threadCount = Number.isNaN(rawThreads) ? 1 : rawThreads;
    const rawRamp = parseInt(String(getPropertyValue(tg, "ThreadGroup.ramp_time", 1)), 10);
    rampUp = Number.isNaN(rawRamp) ? 1 : rawRamp;
    const rawDuration = parseInt(String(getPropertyValue(tg, "ThreadGroup.duration", 0)), 10);
    duration = Number.isNaN(rawDuration) ? 0 : rawDuration;
  }

  const extractorSamplerMap = buildExtractorToSamplerMap(parsed);

  function resolveSourceRequest(ext: any): string {
    return extractorSamplerMap.get(ext) || ext["@_testname"] || "Unknown";
  }

  const correlations: AnalyzedCorrelation[] = [];

  for (const ext of regexExtractors) {
    const variable = getPropertyValue(ext, "RegexExtractor.refname", "");
    const regex = getPropertyValue(ext, "RegexExtractor.regex", "");
    if (variable) {
      correlations.push({
        variable,
        extractorType: "regex",
        pattern: regex,
        sourceRequest: resolveSourceRequest(ext),
        targetRequests: [],
        originalValue: "",
      });
    }
  }

  for (const ext of jsonExtractors) {
    const variable = getPropertyValue(ext, "JSONPostProcessor.referenceNames", "") ||
                     getPropertyValue(ext, "REFERENCE_NAME", "");
    const jsonPath = getPropertyValue(ext, "JSONPostProcessor.jsonPathExprs", "") ||
                     getPropertyValue(ext, "JSON_PATH", "");
    if (variable) {
      correlations.push({
        variable,
        extractorType: "json",
        pattern: jsonPath,
        sourceRequest: resolveSourceRequest(ext),
        targetRequests: [],
        originalValue: "",
      });
    }
  }

  for (const ext of xpathExtractors) {
    const variable = getPropertyValue(ext, "XPathExtractor.refname", "");
    const xpath = getPropertyValue(ext, "XPathExtractor.xpathQuery", "");
    if (variable) {
      correlations.push({
        variable,
        extractorType: "xpath",
        pattern: xpath,
        sourceRequest: resolveSourceRequest(ext),
        targetRequests: [],
        originalValue: "",
      });
    }
  }

  for (const ext of boundaryExtractors) {
    const variable = getPropertyValue(ext, "BoundaryExtractor.refname", "");
    const left = getPropertyValue(ext, "BoundaryExtractor.lboundary", "");
    const right = getPropertyValue(ext, "BoundaryExtractor.rboundary", "");
    if (variable) {
      correlations.push({
        variable,
        extractorType: "boundary",
        pattern: `${left}...${right}`,
        sourceRequest: resolveSourceRequest(ext),
        targetRequests: [],
        originalValue: "",
      });
    }
  }

  for (const ext of cssExtractors) {
    const variable = getPropertyValue(ext, "CSSJQueryExtractor.refname", "") ||
                     getPropertyValue(ext, "HtmlExtractor.refname", "");
    const expr = getPropertyValue(ext, "CSSJQueryExtractor.expr", "") ||
                 getPropertyValue(ext, "HtmlExtractor.expr", "");
    if (variable) {
      correlations.push({
        variable,
        extractorType: "css",
        pattern: expr,
        sourceRequest: resolveSourceRequest(ext),
        targetRequests: [],
        originalValue: "",
      });
    }
  }

  for (const corr of correlations) {
    const varPattern = `\${${corr.variable}}`;
    for (const sampler of samplers) {
      const samplerName = extractSamplerName(sampler);
      const allText = getSamplerFullText(sampler);
      if (allText.includes(varPattern)) {
        if (!corr.targetRequests.includes(samplerName)) {
          corr.targetRequests.push(samplerName);
        }
      }
    }
  }

  const parameterizations: AnalyzedParameterization[] = [];
  for (const csv of csvDataSets) {
    const filename = getPropertyValue(csv, "filename", "");
    const variableNames = getPropertyValue(csv, "variableNames", "");
    if (variableNames) {
      const vars = variableNames.split(",").map((v: string) => v.trim()).filter(Boolean);
      for (const v of vars) {
        const occurrences: { requestIndex: number; location: string; fieldName: string }[] = [];
        const varPattern = `\${${v}}`;
        samplers.forEach((sampler: any, idx: number) => {
          const path = extractPath(sampler);
          const argValues = extractAllArgumentValues(sampler);
          const headers = extractAllHeaders(sampler);
          if (path.includes(varPattern)) {
            occurrences.push({ requestIndex: idx, location: "param", fieldName: "URL path" });
          }
          if (argValues.some(a => a.includes(varPattern))) {
            occurrences.push({ requestIndex: idx, location: "body", fieldName: "Request body/params" });
          }
          if (headers.some(h => h.includes(varPattern))) {
            occurrences.push({ requestIndex: idx, location: "header", fieldName: "Request header" });
          }
        });

        parameterizations.push({
          variable: v,
          originalValue: `(from ${filename || "CSV file"})`,
          occurrences,
        });
      }
    }
  }

  const hasExistingExtractors = regexExtractors.length > 0 || jsonExtractors.length > 0 ||
    xpathExtractors.length > 0 || boundaryExtractors.length > 0 || cssExtractors.length > 0;
  const isRecordedScript = !hasExistingExtractors && csvDataSets.length === 0 && samplers.length > 1;

  if (isRecordedScript) {
    const variableNames = new Set<string>(correlations.map(c => c.variable));

    const allValueOccurrences = new Map<string, { samplerIdx: number; samplerName: string; location: string; fieldName: string }[]>();

    samplers.forEach((sampler: any, idx: number) => {
      const samplerName = extractSamplerName(sampler);
      const path = extractPath(sampler);
      const pairs = extractNameValuePairs(sampler);

      const pathValues: string[] = [];
      const pathParts = path.split(/[?&=/]/);
      for (const part of pathParts) {
        if (part && isDynamicCandidate(part) && matchesKnownPattern(part)) {
          pathValues.push(part);
          const list = allValueOccurrences.get(part) || [];
          list.push({ samplerIdx: idx, samplerName, location: "param", fieldName: "URL path" });
          allValueOccurrences.set(part, list);
        }
      }

      for (const pair of pairs) {
        if (pair.value && isDynamicCandidate(pair.value) && matchesKnownPattern(pair.value)) {
          const list = allValueOccurrences.get(pair.value) || [];
          list.push({ samplerIdx: idx, samplerName, location: "body", fieldName: pair.name || "Request body" });
          allValueOccurrences.set(pair.value, list);
        }
      }
    });

    for (const [value, occurrences] of allValueOccurrences) {
      if (occurrences.length >= 2) {
        const patternType = matchesKnownPattern(value);
        const varName = generateVariableName(patternType || "dynamic", variableNames, correlations.length);
        const sourceOcc = occurrences[0];
        const targetOccs = occurrences.slice(1);

        let extractorType: AnalyzedCorrelation['extractorType'] = 'regex';
        let pattern = '';

        if (patternType === 'uuid') {
          pattern = `[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}`;
        } else if (patternType === 'jwt') {
          pattern = `(eyJ[A-Za-z0-9_-]+\\.eyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+)`;
        } else if (patternType === 'csrf_hex') {
          pattern = `([0-9a-f]{${Math.max(32, value.length)}})`;
        } else if (patternType === 'base64_token') {
          pattern = `([A-Za-z0-9+/=]{${Math.max(20, value.length - 5)},})`;
        }

        if (sourceOcc.location === 'body') {
          const fieldName = sourceOcc.fieldName || 'field';
          if (!pattern) {
            const escapedFieldName = fieldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            pattern = `"${escapedFieldName}"\\s*[:=]\\s*"?([^"&,;\\s]+)"?`;
          }
        } else if (sourceOcc.location === 'param') {
          const fieldName = sourceOcc.fieldName || 'param';
          if (!pattern) {
            const escapedFieldName = fieldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            pattern = `${escapedFieldName}=([^&]+)`;
          }
        }

        if (!pattern) {
          const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          pattern = `(${escaped.substring(0, 10)}[^"&;\\s]+)`;
        }

        correlations.push({
          variable: varName,
          extractorType,
          pattern: `Suggested: ${pattern}`,
          sourceRequest: sourceOcc.samplerName,
          targetRequests: targetOccs.map(o => o.samplerName),
          originalValue: value.length > 50 ? value.substring(0, 50) + "..." : value,
        });
      }
    }

    const credentialFields = new Map<string, { value: string; occurrences: { requestIndex: number; location: string; fieldName: string }[] }>();

    samplers.forEach((sampler: any, idx: number) => {
      const pairs = extractNameValuePairs(sampler);
      for (const pair of pairs) {
        if (isDotNetDynamicField(pair.name)) continue;

        const normalized = pair.name.toLowerCase().replace(/[-\s]/g, "_");
        const csvVar = CREDENTIAL_FIELD_NAMES[normalized];
        if (csvVar && pair.value && !pair.value.startsWith("${")) {
          const existing = credentialFields.get(csvVar);
          if (existing) {
            existing.occurrences.push({ requestIndex: idx, location: "body", fieldName: pair.name });
          } else {
            credentialFields.set(csvVar, {
              value: pair.value,
              occurrences: [{ requestIndex: idx, location: "body", fieldName: pair.name }],
            });
          }
        }
      }
    });

    for (const [csvVar, data] of credentialFields) {
      parameterizations.push({
        variable: csvVar,
        originalValue: data.value.length > 20 ? data.value.substring(0, 3) + "***" : "***",
        occurrences: data.occurrences,
      });
    }
  }

  const dotnetFields = new Map<string, { variable: string; description: string; occurrences: { samplerIdx: number; samplerName: string; fieldName: string; value: string }[] }>();

  samplers.forEach((sampler: any, idx: number) => {
    const samplerName = extractSamplerName(sampler);
    const pairs = extractNameValuePairs(sampler);
    for (const pair of pairs) {
      const dotnetInfo = isDotNetDynamicField(pair.name);
      if (dotnetInfo && pair.value && !pair.value.startsWith("${")) {
        const existing = dotnetFields.get(dotnetInfo.variable);
        if (existing) {
          existing.occurrences.push({ samplerIdx: idx, samplerName, fieldName: pair.name, value: pair.value });
        } else {
          dotnetFields.set(dotnetInfo.variable, {
            variable: dotnetInfo.variable,
            description: dotnetInfo.description,
            occurrences: [{ samplerIdx: idx, samplerName, fieldName: pair.name, value: pair.value }],
          });
        }
      }
    }
  });

  const allVariableNames = new Set<string>(correlations.map(c => c.variable));

  for (const [, data] of dotnetFields) {
    if (!allVariableNames.has(data.variable)) {
      allVariableNames.add(data.variable);
      const firstOcc = data.occurrences[0];
      const restOccs = data.occurrences.slice(1);

      correlations.push({
        variable: data.variable,
        extractorType: "regex",
        pattern: `(needs correlation - ${data.description}, found in ${data.occurrences.length} request(s))`,
        sourceRequest: firstOcc.samplerName,
        targetRequests: restOccs.map(o => o.samplerName),
        originalValue: firstOcc.value.length > 50 ? firstOcc.value.substring(0, 50) + "..." : firstOcc.value,
      });
    }
  }

  const issues: AnalyzedIssue[] = [];

  const staticResourceSamplers: string[] = [];
  const thirdPartySamplers: string[] = [];
  for (const sampler of samplers) {
    const path = extractPath(sampler);
    const domain = extractDomain(sampler) || "";
    const samplerName = extractSamplerName(sampler);
    if (isStaticResourcePath(path)) {
      staticResourceSamplers.push(samplerName);
    }
    if (domain && isThirdPartyDomain(domain)) {
      thirdPartySamplers.push(samplerName);
    }
  }

  if (staticResourceSamplers.length > 0) {
    issues.push({
      severity: "warning",
      message: `${staticResourceSamplers.length} static resource request(s) found (CSS, JS, images, fonts). These should typically be removed or placed under "Retrieve All Embedded Resources" in HTTP Request Defaults. Requests: ${staticResourceSamplers.slice(0, 5).join(", ")}${staticResourceSamplers.length > 5 ? ` +${staticResourceSamplers.length - 5} more` : ""}`,
    });
  }

  if (thirdPartySamplers.length > 0) {
    issues.push({
      severity: "warning",
      message: `${thirdPartySamplers.length} third-party/analytics request(s) found (Google Analytics, Facebook, etc.). These should be removed from load test scripts. Requests: ${thirdPartySamplers.slice(0, 5).join(", ")}${thirdPartySamplers.length > 5 ? ` +${thirdPartySamplers.length - 5} more` : ""}`,
    });
  }

  if (samplers.length === 0) {
    issues.push({ severity: "warning", message: "No HTTP requests found in the test plan" });
  }

  if (transactionControllers.length === 0 && samplers.length > 1) {
    issues.push({ severity: "info", message: "No Transaction Controllers found. Consider grouping requests into transactions for better reporting." });
  }

  if (cookieManagers.length === 0) {
    issues.push({ severity: "warning", message: "No Cookie Manager found. Add one to handle session cookies automatically." });
  }

  if (!hasHttpDefaults && domains.length > 0) {
    issues.push({ severity: "info", message: "No HTTP Request Defaults found. Consider adding one to avoid repeating domain/port on every request." });
  }

  if (responseAssertions.length === 0 && jsonAssertions.length === 0) {
    issues.push({ severity: "info", message: "No assertions found. Add Response Assertions to validate response codes and content." });
  }

  const allTimerCount = constantTimers.length + uniformTimers.length + gaussianTimers.length + poissonTimers.length + throughputTimers.length;
  if (allTimerCount === 0 && samplers.length > 1) {
    issues.push({ severity: "info", message: "No timers/think time found between requests. Real users have pauses between actions." });
  }

  if (!hasTimeouts) {
    issues.push({ severity: "info", message: "No connect/response timeouts configured. Consider setting timeouts to prevent hanging threads." });
  }

  const allFrameworkVarNames = Object.values(FRAMEWORK_DYNAMIC_FIELDS).map(f => f.variable);
  const frameworkCorrelations = correlations.filter(c => allFrameworkVarNames.includes(c.variable));
  const frameworkCorrelationCount = frameworkCorrelations.length;

  if (frameworkCorrelationCount > 0) {
    const detectedFrameworks = new Map<string, string[]>();
    for (const c of frameworkCorrelations) {
      const field = Object.values(FRAMEWORK_DYNAMIC_FIELDS).find(f => f.variable === c.variable);
      if (field) {
        const list = detectedFrameworks.get(field.framework) || [];
        list.push(c.variable);
        detectedFrameworks.set(field.framework, list);
      }
    }
    for (const [framework, vars] of detectedFrameworks) {
      issues.push({
        severity: "warning",
        message: `${framework} application detected: ${vars.length} dynamic field(s) found (${vars.join(", ")}). These values change on every page load/request and MUST be correlated using Regular Expression Extractors. Extract from the preceding response's HTML/headers using boundary or regex patterns.`,
      });
    }
  }

  if (isRecordedScript && correlations.length > frameworkCorrelationCount) {
    const nonFramework = correlations.length - frameworkCorrelationCount;
    issues.push({ severity: "warning", message: `Detected ${nonFramework} additional hardcoded dynamic value(s) that need correlation (session tokens, UUIDs, CSRF tokens).` });
  } else if (!isRecordedScript && correlations.length === frameworkCorrelationCount && frameworkCorrelationCount === 0 && samplers.length > 3) {
    issues.push({ severity: "info", message: "No extractors (correlations) found. If the application uses dynamic tokens, add Regular Expression or JSON extractors." });
  }

  if (isRecordedScript && parameterizations.length > 0) {
    issues.push({ severity: "warning", message: `Found ${parameterizations.length} hardcoded credential field(s) (username, password, email). These should be parameterized with a CSV Data Set Config for realistic multi-user load testing.` });
  } else if (csvDataSets.length === 0 && samplers.length > 0) {
    issues.push({ severity: "info", message: "No CSV Data Set Config found. Consider parameterizing test data for realistic load simulation." });
  }

  const disabledSamplers = samplers.filter((s: any) => s["@_enabled"] === "false");
  if (disabledSamplers.length > 0) {
    issues.push({ severity: "info", message: `${disabledSamplers.length} disabled HTTP request(s) found in the test plan.` });
  }

  const listeners = findAll(parsed, "ResultCollector");
  const enabledListeners = listeners.filter((l: any) => l["@_enabled"] !== "false");
  if (enabledListeners.length > 0) {
    issues.push({ severity: "warning", message: `${enabledListeners.length} enabled listener(s) found (e.g., View Results Tree). Disable listeners during load tests for better performance.` });
  }

  if (isRecordedScript) {
    issues.push({ severity: "info", message: "This appears to be a recorded script (no extractors or CSV configs). The analysis above identifies values that need manual correlation and parameterization before running a load test." });
  }

  return {
    testName,
    requestCount: samplers.length,
    transactionGroups: transactionControllers.length,
    domains,
    correlations,
    parameterizations,
    issues,
    hasAssertions: responseAssertions.length > 0 || jsonAssertions.length > 0,
    hasCookieManager: cookieManagers.length > 0,
    hasHttpDefaults,
    hasKeepalive,
    hasTimeouts,
    hasTimers: allTimerCount > 0,
    hasCsvDataSet: csvDataSets.length > 0,
    threadCount,
    rampUp,
    duration,
  };
}
