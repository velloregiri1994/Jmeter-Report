export type JmxProperty =
  | { type: 'string'; name: string; value: string }
  | { type: 'bool'; name: string; value: boolean }
  | { type: 'int'; name: string; value: number }
  | { type: 'long'; name: string; value: number }
  | { type: 'element'; name: string; elementType: string; attrs?: Record<string, string>; children: JmxProperty[] }
  | { type: 'collection'; name: string; items: JmxProperty[] }
  | { type: 'objProp'; name: string; rawXml: string[] };

export interface JmxElement {
  tagName: string;
  attrs: Record<string, string>;
  props: JmxProperty[];
  children: JmxElement[];
}

export function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function indent(depth: number): string {
  return '  '.repeat(depth);
}

function renderProperty(prop: JmxProperty, depth: number): string {
  const pad = indent(depth);
  switch (prop.type) {
    case 'string':
      return `${pad}<stringProp name="${escapeXml(prop.name)}">${escapeXml(prop.value)}</stringProp>`;
    case 'bool':
      return `${pad}<boolProp name="${escapeXml(prop.name)}">${prop.value}</boolProp>`;
    case 'int':
      return `${pad}<intProp name="${escapeXml(prop.name)}">${prop.value}</intProp>`;
    case 'long':
      return `${pad}<longProp name="${escapeXml(prop.name)}">${prop.value}</longProp>`;
    case 'element': {
      const attrParts: string[] = [`name="${escapeXml(prop.name)}"`, `elementType="${escapeXml(prop.elementType)}"`];
      if (prop.attrs) {
        for (const [k, v] of Object.entries(prop.attrs)) {
          attrParts.push(`${k}="${escapeXml(v)}"`);
        }
      }
      if (prop.children.length === 0) {
        return `${pad}<elementProp ${attrParts.join(' ')}/>`;
      }
      const lines: string[] = [];
      lines.push(`${pad}<elementProp ${attrParts.join(' ')}>`);
      for (const child of prop.children) {
        lines.push(renderProperty(child, depth + 1));
      }
      lines.push(`${pad}</elementProp>`);
      return lines.join('\n');
    }
    case 'collection': {
      if (prop.items.length === 0) {
        return `${pad}<collectionProp name="${escapeXml(prop.name)}"/>`;
      }
      const lines: string[] = [];
      lines.push(`${pad}<collectionProp name="${escapeXml(prop.name)}">`);
      for (const item of prop.items) {
        lines.push(renderProperty(item, depth + 1));
      }
      lines.push(`${pad}</collectionProp>`);
      return lines.join('\n');
    }
    case 'objProp': {
      const lines: string[] = [];
      lines.push(`${pad}<objProp>`);
      lines.push(`${pad}  <name>${escapeXml(prop.name)}</name>`);
      for (const line of prop.rawXml) {
        lines.push(`${pad}  ${line}`);
      }
      lines.push(`${pad}</objProp>`);
      return lines.join('\n');
    }
  }
}

function renderElement(el: JmxElement, depth: number): string {
  const pad = indent(depth);
  const lines: string[] = [];

  const attrParts = Object.entries(el.attrs)
    .map(([k, v]) => `${k}="${escapeXml(v)}"`)
    .join(' ');

  lines.push(`${pad}<${el.tagName} ${attrParts}>`);

  for (const prop of el.props) {
    lines.push(renderProperty(prop, depth + 1));
  }

  lines.push(`${pad}</${el.tagName}>`);

  if (el.children.length === 0) {
    lines.push(`${pad}<hashTree/>`);
  } else {
    lines.push(`${pad}<hashTree>`);
    for (const child of el.children) {
      lines.push(renderElement(child, depth + 1));
    }
    lines.push(`${pad}</hashTree>`);
  }

  return lines.join('\n');
}

export function renderJmx(root: JmxElement): string {
  const lines: string[] = [];
  lines.push(`<?xml version="1.0" encoding="UTF-8"?>`);
  lines.push(`<jmeterTestPlan version="1.2" properties="5.0" jmeter="5.6.3">`);
  lines.push(`  <hashTree>`);
  lines.push(renderElement(root, 2));
  lines.push(`  </hashTree>`);
  lines.push(`</jmeterTestPlan>`);
  return lines.join('\n');
}

function stringProp(name: string, value: string): JmxProperty {
  return { type: 'string', name, value };
}

function boolProp(name: string, value: boolean): JmxProperty {
  return { type: 'bool', name, value };
}

function intProp(name: string, value: number): JmxProperty {
  return { type: 'int', name, value };
}

function elementProp(name: string, elementType: string, children: JmxProperty[], attrs?: Record<string, string>): JmxProperty {
  return { type: 'element', name, elementType, attrs, children };
}

function collectionProp(name: string, items: JmxProperty[]): JmxProperty {
  return { type: 'collection', name, items };
}

export function testPlan(
  name: string,
  comments: string,
  userVars: { name: string; value: string }[],
  children: JmxElement[]
): JmxElement {
  const varItems: JmxProperty[] = userVars.map(v =>
    elementProp(v.name, 'Argument', [
      stringProp('Argument.name', v.name),
      stringProp('Argument.value', v.value),
      stringProp('Argument.metadata', '='),
    ])
  );

  return {
    tagName: 'TestPlan',
    attrs: { guiclass: 'TestPlanGui', testclass: 'TestPlan', testname: name, enabled: 'true' },
    props: [
      stringProp('TestPlan.comments', comments),
      boolProp('TestPlan.functional_mode', false),
      boolProp('TestPlan.tearDown_on_shutdown', true),
      boolProp('TestPlan.serialize_threadgroups', false),
      elementProp('TestPlan.user_defined_variables', 'Arguments', [
        collectionProp('Arguments.arguments', varItems),
      ], { guiclass: 'ArgumentsPanel', testclass: 'Arguments', testname: 'User Defined Variables', enabled: 'true' }),
      stringProp('TestPlan.user_define_classpath', ''),
    ],
    children,
  };
}

export function threadGroup(
  name: string,
  numThreads: number,
  rampTime: number,
  duration: number,
  children: JmxElement[]
): JmxElement {
  return {
    tagName: 'ThreadGroup',
    attrs: { guiclass: 'ThreadGroupGui', testclass: 'ThreadGroup', testname: name, enabled: 'true' },
    props: [
      stringProp('ThreadGroup.on_sample_error', 'continue'),
      elementProp('ThreadGroup.main_controller', 'LoopController', [
        boolProp('LoopController.continue_forever', false),
        intProp('LoopController.loops', duration > 0 ? -1 : 1),
      ], { guiclass: 'LoopControlPanel', testclass: 'LoopController', testname: 'Loop Controller', enabled: 'true' }),
      stringProp('ThreadGroup.num_threads', numThreads.toString()),
      stringProp('ThreadGroup.ramp_time', rampTime.toString()),
      boolProp('ThreadGroup.scheduler', duration > 0),
      stringProp('ThreadGroup.duration', duration.toString()),
      stringProp('ThreadGroup.delay', '0'),
      boolProp('ThreadGroup.same_user_on_next_iteration', true),
    ],
    children,
  };
}

export function httpDefaults(domain: string, port: string, protocol: string): JmxElement {
  return {
    tagName: 'ConfigTestElement',
    attrs: { guiclass: 'HttpDefaultsGui', testclass: 'ConfigTestElement', testname: 'HTTP Request Defaults', enabled: 'true' },
    props: [
      elementProp('HTTPsampler.Arguments', 'Arguments', [
        collectionProp('Arguments.arguments', []),
      ], { guiclass: 'HTTPArgumentsPanel', testclass: 'Arguments', enabled: 'true' }),
      stringProp('HTTPSampler.domain', domain),
      stringProp('HTTPSampler.port', port),
      stringProp('HTTPSampler.protocol', protocol),
      stringProp('HTTPSampler.contentEncoding', 'UTF-8'),
      stringProp('HTTPSampler.connect_timeout', '10000'),
      stringProp('HTTPSampler.response_timeout', '60000'),
    ],
    children: [],
  };
}

export function cookieManager(): JmxElement {
  return {
    tagName: 'CookieManager',
    attrs: { guiclass: 'CookiePanel', testclass: 'CookieManager', testname: 'HTTP Cookie Manager', enabled: 'true' },
    props: [
      collectionProp('CookieManager.cookies', []),
      boolProp('CookieManager.clearEachIteration', true),
      boolProp('CookieManager.controlledByThreadGroup', false),
      stringProp('CookieManager.implementation', 'HC4CookieHandler'),
    ],
    children: [],
  };
}

export function headerManager(name: string, headers: { name: string; value: string }[]): JmxElement {
  const items: JmxProperty[] = headers.map(h =>
    elementProp('', 'Header', [
      stringProp('Header.name', h.name),
      stringProp('Header.value', h.value),
    ])
  );

  return {
    tagName: 'HeaderManager',
    attrs: { guiclass: 'HeaderPanel', testclass: 'HeaderManager', testname: name, enabled: 'true' },
    props: [
      collectionProp('HeaderManager.headers', items),
    ],
    children: [],
  };
}

export function csvDataSet(filename: string, varNames: string): JmxElement {
  return {
    tagName: 'CSVDataSet',
    attrs: { guiclass: 'TestBeanGUI', testclass: 'CSVDataSet', testname: 'CSV Data Set Config', enabled: 'true' },
    props: [
      stringProp('delimiter', ','),
      stringProp('fileEncoding', 'UTF-8'),
      stringProp('filename', filename),
      boolProp('ignoreFirstLine', false),
      boolProp('quotedData', true),
      boolProp('recycle', true),
      stringProp('shareMode', 'shareMode.all'),
      boolProp('stopThread', false),
      stringProp('variableNames', varNames),
    ],
    children: [],
  };
}

export function transactionController(name: string, children: JmxElement[]): JmxElement {
  return {
    tagName: 'TransactionController',
    attrs: { guiclass: 'TransactionControllerGui', testclass: 'TransactionController', testname: name, enabled: 'true' },
    props: [
      boolProp('TransactionController.includeTimers', false),
      boolProp('TransactionController.parent', true),
    ],
    children,
  };
}

export interface HttpSamplerConfig {
  name: string;
  domain: string;
  port: string;
  protocol: string;
  path: string;
  method: string;
  isMultipart: boolean;
  body?: {
    type: 'raw' | 'params' | 'empty';
    rawText?: string;
    params?: { name: string; value: string }[];
  };
  children?: JmxElement[];
}

export function httpSampler(config: HttpSamplerConfig): JmxElement {
  const props: JmxProperty[] = [];

  if (config.body?.type === 'raw' && config.body.rawText !== undefined) {
    props.push(boolProp('HTTPSampler.postBodyRaw', true));
    props.push(
      elementProp('HTTPsampler.Arguments', 'Arguments', [
        collectionProp('Arguments.arguments', [
          elementProp('', 'HTTPArgument', [
            boolProp('HTTPArgument.always_encode', false),
            stringProp('Argument.value', config.body.rawText),
            stringProp('Argument.metadata', '='),
          ]),
        ]),
      ])
    );
  } else if (config.body?.type === 'params' && config.body.params && config.body.params.length > 0) {
    const paramItems: JmxProperty[] = config.body.params.map(p =>
      elementProp(p.name, 'HTTPArgument', [
        boolProp('HTTPArgument.always_encode', true),
        stringProp('Argument.name', p.name),
        stringProp('Argument.value', p.value),
        stringProp('Argument.metadata', '='),
        boolProp('HTTPArgument.use_equals', true),
      ])
    );
    props.push(
      elementProp('HTTPsampler.Arguments', 'Arguments', [
        collectionProp('Arguments.arguments', paramItems),
      ], { guiclass: 'HTTPArgumentsPanel', testclass: 'Arguments', enabled: 'true' })
    );
  } else {
    props.push(
      elementProp('HTTPsampler.Arguments', 'Arguments', [
        collectionProp('Arguments.arguments', []),
      ], { guiclass: 'HTTPArgumentsPanel', testclass: 'Arguments', enabled: 'true' })
    );
  }

  props.push(
    stringProp('HTTPSampler.domain', config.domain),
    stringProp('HTTPSampler.port', config.port),
    stringProp('HTTPSampler.protocol', config.protocol),
    stringProp('HTTPSampler.contentEncoding', 'UTF-8'),
    stringProp('HTTPSampler.path', config.path),
    stringProp('HTTPSampler.method', config.method),
    boolProp('HTTPSampler.follow_redirects', true),
    boolProp('HTTPSampler.auto_redirects', false),
    boolProp('HTTPSampler.use_keepalive', true),
    boolProp('HTTPSampler.DO_MULTIPART_POST', config.isMultipart),
    stringProp('HTTPSampler.connect_timeout', '10000'),
    stringProp('HTTPSampler.response_timeout', '60000'),
  );

  return {
    tagName: 'HTTPSamplerProxy',
    attrs: { guiclass: 'HttpTestSampleGui', testclass: 'HTTPSamplerProxy', testname: config.name, enabled: 'true' },
    props,
    children: config.children || [],
  };
}

export function regexExtractor(variable: string, pattern: string, useHeaders: boolean): JmxElement {
  return {
    tagName: 'RegexExtractor',
    attrs: { guiclass: 'RegexExtractorGui', testclass: 'RegexExtractor', testname: `Extract ${variable}`, enabled: 'true' },
    props: [
      stringProp('RegexExtractor.useHeaders', useHeaders ? 'true' : 'false'),
      stringProp('RegexExtractor.refname', variable),
      stringProp('RegexExtractor.regex', pattern),
      stringProp('RegexExtractor.template', '$1$'),
      stringProp('RegexExtractor.default', 'NOT_FOUND'),
      stringProp('RegexExtractor.match_number', '1'),
    ],
    children: [],
  };
}

export function jsonExtractor(variable: string, jsonPath: string): JmxElement {
  return {
    tagName: 'JSONPostProcessor',
    attrs: { guiclass: 'JSONPostProcessorGui', testclass: 'JSONPostProcessor', testname: `Extract ${variable}`, enabled: 'true' },
    props: [
      stringProp('JSONPostProcessor.referenceNames', variable),
      stringProp('JSONPostProcessor.jsonPathExprs', jsonPath),
      stringProp('JSONPostProcessor.match_numbers', '1'),
      stringProp('JSONPostProcessor.defaultValues', 'NOT_FOUND'),
    ],
    children: [],
  };
}

export function boundaryExtractor(variable: string, leftBoundary: string, rightBoundary: string, useHeaders: boolean = false): JmxElement {
  return {
    tagName: 'BoundaryExtractor',
    attrs: { guiclass: 'BoundaryExtractorGui', testclass: 'BoundaryExtractor', testname: `Extract ${variable}`, enabled: 'true' },
    props: [
      stringProp('BoundaryExtractor.useHeaders', useHeaders ? 'true' : 'false'),
      stringProp('BoundaryExtractor.refname', variable),
      stringProp('BoundaryExtractor.lboundary', leftBoundary),
      stringProp('BoundaryExtractor.rboundary', rightBoundary),
      stringProp('BoundaryExtractor.default', 'NOT_FOUND'),
      stringProp('BoundaryExtractor.match_number', '1'),
    ],
    children: [],
  };
}

export function xpathExtractor(variable: string, xpathQuery: string): JmxElement {
  return {
    tagName: 'XPathExtractor',
    attrs: { guiclass: 'XPathExtractorGui', testclass: 'XPathExtractor', testname: `Extract ${variable}`, enabled: 'true' },
    props: [
      stringProp('XPathExtractor.refname', variable),
      stringProp('XPathExtractor.xpathQuery', xpathQuery),
      stringProp('XPathExtractor.default', 'NOT_FOUND'),
      boolProp('XPathExtractor.tolerant', true),
      boolProp('XPathExtractor.validate', false),
      boolProp('XPathExtractor.namespace', false),
    ],
    children: [],
  };
}

export function cssJqueryExtractor(variable: string, cssSelector: string, attribute: string = ''): JmxElement {
  return {
    tagName: 'HtmlExtractor',
    attrs: { guiclass: 'HtmlExtractorGui', testclass: 'HtmlExtractor', testname: `Extract ${variable}`, enabled: 'true' },
    props: [
      stringProp('HtmlExtractor.refname', variable),
      stringProp('HtmlExtractor.expr', cssSelector),
      stringProp('HtmlExtractor.attribute', attribute),
      stringProp('HtmlExtractor.default', 'NOT_FOUND'),
      stringProp('HtmlExtractor.match_number', '1'),
      stringProp('HtmlExtractor.extractor_impl', ''),
    ],
    children: [],
  };
}

export function responseAssertion(expectedStatus: number): JmxElement {
  return {
    tagName: 'ResponseAssertion',
    attrs: { guiclass: 'AssertionGui', testclass: 'ResponseAssertion', testname: `Response Code ${expectedStatus}`, enabled: 'true' },
    props: [
      collectionProp('Assertion.test_strings', [
        stringProp('', expectedStatus.toString()),
      ]),
      stringProp('Assertion.custom_message', ''),
      stringProp('Assertion.test_field', 'Assertion.response_code'),
      boolProp('Assertion.assume_success', false),
      intProp('Assertion.test_type', 8),
    ],
    children: [],
  };
}

export function uniformRandomTimer(delay: number, range: number): JmxElement {
  return {
    tagName: 'UniformRandomTimer',
    attrs: { guiclass: 'UniformRandomTimerGui', testclass: 'UniformRandomTimer', testname: 'Think Time', enabled: 'true' },
    props: [
      stringProp('ConstantTimer.delay', delay.toString()),
      stringProp('RandomTimer.range', range.toString()),
    ],
    children: [],
  };
}

export function resultCollector(): JmxElement {
  const saveConfigLines = [
    '<value class="SampleSaveConfiguration">',
    '  <time>true</time>',
    '  <latency>true</latency>',
    '  <timestamp>true</timestamp>',
    '  <success>true</success>',
    '  <label>true</label>',
    '  <code>true</code>',
    '  <message>true</message>',
    '  <threadName>true</threadName>',
    '  <dataType>true</dataType>',
    '  <encoding>false</encoding>',
    '  <assertions>true</assertions>',
    '  <subresults>true</subresults>',
    '  <responseData>false</responseData>',
    '  <samplerData>false</samplerData>',
    '  <xml>false</xml>',
    '  <fieldNames>true</fieldNames>',
    '  <responseHeaders>false</responseHeaders>',
    '  <requestHeaders>false</requestHeaders>',
    '  <responseDataOnError>false</responseDataOnError>',
    '  <saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>',
    '  <assertionsResultsToSave>0</assertionsResultsToSave>',
    '  <bytes>true</bytes>',
    '  <sentBytes>true</sentBytes>',
    '  <url>true</url>',
    '  <threadCounts>true</threadCounts>',
    '  <idleTime>true</idleTime>',
    '  <connectTime>true</connectTime>',
    '</value>',
  ];

  return {
    tagName: 'ResultCollector',
    attrs: { guiclass: 'ViewResultsFullVisualizer', testclass: 'ResultCollector', testname: 'View Results Tree', enabled: 'false' },
    props: [
      boolProp('ResultCollector.error_logging', false),
      { type: 'objProp', name: 'saveConfig', rawXml: saveConfigLines },
      stringProp('filename', ''),
    ],
    children: [],
  };
}
