import { XMLParser } from 'fast-xml-parser';

export interface ValidationIssue {
  code: string;
  message: string;
  path: string;
  severity: 'error' | 'warning';
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
}

const KNOWN_ELEMENT_TYPES: Record<string, { guiclass: string; testclass: string }> = {
  TestPlan: { guiclass: 'TestPlanGui', testclass: 'TestPlan' },
  ThreadGroup: { guiclass: 'ThreadGroupGui', testclass: 'ThreadGroup' },
  ConfigTestElement: { guiclass: 'HttpDefaultsGui', testclass: 'ConfigTestElement' },
  CookieManager: { guiclass: 'CookiePanel', testclass: 'CookieManager' },
  HeaderManager: { guiclass: 'HeaderPanel', testclass: 'HeaderManager' },
  CSVDataSet: { guiclass: 'TestBeanGUI', testclass: 'CSVDataSet' },
  TransactionController: { guiclass: 'TransactionControllerGui', testclass: 'TransactionController' },
  HTTPSamplerProxy: { guiclass: 'HttpTestSampleGui', testclass: 'HTTPSamplerProxy' },
  RegexExtractor: { guiclass: 'RegexExtractorGui', testclass: 'RegexExtractor' },
  JSONPostProcessor: { guiclass: 'JSONPostProcessorGui', testclass: 'JSONPostProcessor' },
  ResponseAssertion: { guiclass: 'AssertionGui', testclass: 'ResponseAssertion' },
  UniformRandomTimer: { guiclass: 'UniformRandomTimerGui', testclass: 'UniformRandomTimer' },
  ResultCollector: { guiclass: 'ViewResultsFullVisualizer', testclass: 'ResultCollector' },
};

const TEST_ELEMENT_TAGS = new Set(Object.keys(KNOWN_ELEMENT_TYPES));

const PROPERTY_TAGS = new Set([
  'stringProp', 'boolProp', 'intProp', 'longProp', 'doubleProp', 'floatProp',
  'elementProp', 'collectionProp', 'objProp',
]);

export function validateJmx(xmlContent: string): ValidationResult {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];

  validateXmlDeclaration(xmlContent, errors, warnings);

  let parsed: any;
  try {
    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: '@_',
      textNodeName: '#text',
      parseAttributeValue: false,
      parseTagValue: false,
      preserveOrder: true,
    });
    parsed = parser.parse(xmlContent);
  } catch (e: any) {
    errors.push({
      code: 'XML_MALFORMED',
      message: `XML parsing failed: ${e.message}`,
      path: '/',
      severity: 'error',
    });
    return { valid: false, errors, warnings };
  }

  validateRootStructure(parsed, errors, warnings);

  const hashTreeContent = findRootHashTree(parsed);
  if (hashTreeContent) {
    validateHashTreeChildren(hashTreeContent, 'jmeterTestPlan/hashTree', errors, warnings);
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

function validateXmlDeclaration(xml: string, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  const trimmed = xml.trimStart();
  if (!trimmed.startsWith('<?xml')) {
    errors.push({
      code: 'MISSING_XML_DECLARATION',
      message: 'JMX file must start with an XML declaration (<?xml version="1.0" encoding="UTF-8"?>)',
      path: '/',
      severity: 'error',
    });
    return;
  }

  if (!trimmed.match(/encoding\s*=\s*["']UTF-8["']/i)) {
    warnings.push({
      code: 'MISSING_UTF8_ENCODING',
      message: 'XML declaration should specify UTF-8 encoding',
      path: '/',
      severity: 'warning',
    });
  }
}

function validateRootStructure(parsed: any, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  if (!Array.isArray(parsed)) {
    errors.push({
      code: 'INVALID_ROOT',
      message: 'Parsed XML has unexpected structure',
      path: '/',
      severity: 'error',
    });
    return;
  }

  const jmeterNode = parsed.find((n: any) => n.jmeterTestPlan !== undefined);
  if (!jmeterNode) {
    errors.push({
      code: 'MISSING_ROOT_ELEMENT',
      message: 'JMX file must have a <jmeterTestPlan> root element',
      path: '/',
      severity: 'error',
    });
    return;
  }

  const attrs = jmeterNode[':@'];
  if (!attrs?.['@_version']) {
    warnings.push({
      code: 'MISSING_VERSION_ATTR',
      message: '<jmeterTestPlan> should have a version attribute',
      path: '/jmeterTestPlan',
      severity: 'warning',
    });
  }
  if (!attrs?.['@_properties']) {
    warnings.push({
      code: 'MISSING_PROPERTIES_ATTR',
      message: '<jmeterTestPlan> should have a properties attribute',
      path: '/jmeterTestPlan',
      severity: 'warning',
    });
  }

  const children = jmeterNode.jmeterTestPlan;
  if (!Array.isArray(children)) {
    errors.push({
      code: 'MISSING_ROOT_HASHTREE',
      message: '<jmeterTestPlan> must contain a <hashTree> element',
      path: '/jmeterTestPlan',
      severity: 'error',
    });
    return;
  }

  const hasHashTree = children.some((c: any) => c.hashTree !== undefined);
  if (!hasHashTree) {
    errors.push({
      code: 'MISSING_ROOT_HASHTREE',
      message: '<jmeterTestPlan> must contain a <hashTree> element',
      path: '/jmeterTestPlan',
      severity: 'error',
    });
  }
}

function findRootHashTree(parsed: any): any[] | null {
  if (!Array.isArray(parsed)) return null;
  const jmeterNode = parsed.find((n: any) => n.jmeterTestPlan !== undefined);
  if (!jmeterNode || !Array.isArray(jmeterNode.jmeterTestPlan)) return null;
  const hashTreeNode = jmeterNode.jmeterTestPlan.find((c: any) => c.hashTree !== undefined);
  if (!hashTreeNode) return null;
  return Array.isArray(hashTreeNode.hashTree) ? hashTreeNode.hashTree : [];
}

function getTagName(node: any): string | null {
  for (const key of Object.keys(node)) {
    if (key !== ':@' && key !== '#text') return key;
  }
  return null;
}

function validateHashTreeChildren(children: any[], parentPath: string, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  let i = 0;
  while (i < children.length) {
    const node = children[i];
    const tag = getTagName(node);

    if (!tag) {
      i++;
      continue;
    }

    if (tag === 'hashTree') {
      if (i === 0) {
        warnings.push({
          code: 'ORPHANED_HASHTREE',
          message: 'Found <hashTree> without a preceding test element',
          path: parentPath,
          severity: 'warning',
        });
      }
      i++;
      continue;
    }

    if (TEST_ELEMENT_TAGS.has(tag) || isTestElement(node, tag)) {
      const testname = node[':@']?.['@_testname'] || tag;
      const elementPath = `${parentPath}/${tag}[${testname}]`;

      validateElementAttributes(node, tag, elementPath, errors, warnings);
      validateElementProperties(node[tag], tag, elementPath, errors, warnings);

      const nextNode = children[i + 1];
      const nextTag = nextNode ? getTagName(nextNode) : null;

      if (nextTag !== 'hashTree') {
        errors.push({
          code: 'MISSING_HASHTREE',
          message: `Element <${tag}> (${testname}) must be followed by a <hashTree> element`,
          path: elementPath,
          severity: 'error',
        });
        i++;
      } else {
        const htChildren = Array.isArray(nextNode.hashTree) ? nextNode.hashTree : [];
        if (htChildren.length > 0) {
          validateHashTreeChildren(htChildren, `${elementPath}/hashTree`, errors, warnings);
        }
        i += 2;
      }
    } else {
      i++;
    }
  }
}

function isTestElement(node: any, tag: string): boolean {
  const attrs = node[':@'];
  return attrs?.['@_testclass'] !== undefined || attrs?.['@_guiclass'] !== undefined;
}

function validateElementAttributes(node: any, tag: string, path: string, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  const attrs = node[':@'] || {};

  const required = ['guiclass', 'testclass', 'testname', 'enabled'];
  for (const attr of required) {
    if (attrs[`@_${attr}`] === undefined) {
      errors.push({
        code: 'MISSING_ELEMENT_ATTR',
        message: `<${tag}> is missing required attribute "${attr}"`,
        path,
        severity: 'error',
      });
    }
  }

  const known = KNOWN_ELEMENT_TYPES[tag];
  if (known) {
    if (attrs['@_guiclass'] && attrs['@_guiclass'] !== known.guiclass) {
      warnings.push({
        code: 'UNEXPECTED_GUICLASS',
        message: `<${tag}> has guiclass="${attrs['@_guiclass']}", expected "${known.guiclass}"`,
        path,
        severity: 'warning',
      });
    }
    if (attrs['@_testclass'] && attrs['@_testclass'] !== known.testclass) {
      warnings.push({
        code: 'UNEXPECTED_TESTCLASS',
        message: `<${tag}> has testclass="${attrs['@_testclass']}", expected "${known.testclass}"`,
        path,
        severity: 'warning',
      });
    }
  }

  if (attrs['@_enabled'] !== undefined && attrs['@_enabled'] !== 'true' && attrs['@_enabled'] !== 'false') {
    errors.push({
      code: 'INVALID_ENABLED_VALUE',
      message: `<${tag}> "enabled" attribute must be "true" or "false", got "${attrs['@_enabled']}"`,
      path,
      severity: 'error',
    });
  }
}

function validateElementProperties(children: any[], tag: string, path: string, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  if (!Array.isArray(children)) return;

  for (const child of children) {
    const childTag = getTagName(child);
    if (!childTag) continue;

    if (PROPERTY_TAGS.has(childTag)) {
      validatePropertyElement(child, childTag, path, errors, warnings);
    }
  }

  if (tag === 'ResultCollector') {
    validateResultCollectorProps(children, path, errors, warnings);
  }

  if (tag === 'HTTPSamplerProxy') {
    validateHttpSamplerProps(children, path, errors, warnings);
  }

  if (tag === 'ThreadGroup') {
    validateThreadGroupProps(children, path, errors, warnings);
  }

  if (tag === 'TestPlan') {
    validateTestPlanProps(children, path, errors, warnings);
  }
}

function validatePropertyElement(node: any, tag: string, parentPath: string, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  const attrs = node[':@'] || {};
  const propPath = `${parentPath}/${tag}`;

  if (tag === 'stringProp' || tag === 'boolProp' || tag === 'intProp' || tag === 'longProp' || tag === 'doubleProp' || tag === 'floatProp') {
    if (attrs['@_name'] === undefined) {
      errors.push({
        code: 'PROPERTY_MISSING_NAME',
        message: `<${tag}> is missing required "name" attribute`,
        path: propPath,
        severity: 'error',
      });
    }
  }

  if (tag === 'elementProp') {
    if (attrs['@_name'] === undefined) {
      warnings.push({
        code: 'ELEMENTPROP_MISSING_NAME',
        message: '<elementProp> is missing "name" attribute',
        path: propPath,
        severity: 'warning',
      });
    }
    if (attrs['@_elementType'] === undefined) {
      errors.push({
        code: 'ELEMENTPROP_MISSING_TYPE',
        message: '<elementProp> is missing required "elementType" attribute',
        path: propPath,
        severity: 'error',
      });
    }
  }

  if (tag === 'collectionProp') {
    if (attrs['@_name'] === undefined) {
      errors.push({
        code: 'COLLECTIONPROP_MISSING_NAME',
        message: '<collectionProp> is missing required "name" attribute',
        path: propPath,
        severity: 'error',
      });
    }
  }

  if (tag === 'objProp') {
    validateObjProp(node, propPath, errors, warnings);
  }
}

function validateObjProp(node: any, path: string, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  const children = node.objProp;
  if (!Array.isArray(children)) {
    errors.push({
      code: 'OBJPROP_EMPTY',
      message: '<objProp> must contain <name> and <value> elements',
      path,
      severity: 'error',
    });
    return;
  }

  const hasNameElement = children.some((c: any) => getTagName(c) === 'name');
  const hasValueElement = children.some((c: any) => getTagName(c) === 'value');
  const hasStringProp = children.some((c: any) => getTagName(c) === 'stringProp');

  if (hasStringProp) {
    errors.push({
      code: 'OBJPROP_HAS_STRINGPROP',
      message: '<objProp> must not contain <stringProp> — use <name> element instead. JMeter will fail with "No such field ObjectProperty.stringProp"',
      path,
      severity: 'error',
    });
  }

  if (!hasNameElement) {
    errors.push({
      code: 'OBJPROP_MISSING_NAME',
      message: '<objProp> must contain a <name> element (not <stringProp>)',
      path,
      severity: 'error',
    });
  }

  if (!hasValueElement) {
    errors.push({
      code: 'OBJPROP_MISSING_VALUE',
      message: '<objProp> must contain a <value> element with a class attribute',
      path,
      severity: 'error',
    });
  }

  if (hasValueElement) {
    const valueNode = children.find((c: any) => getTagName(c) === 'value');
    if (valueNode && !valueNode[':@']?.['@_class']) {
      warnings.push({
        code: 'OBJPROP_VALUE_MISSING_CLASS',
        message: '<value> inside <objProp> should have a "class" attribute (e.g., class="SampleSaveConfiguration")',
        path,
        severity: 'warning',
      });
    }
  }
}

function validateResultCollectorProps(children: any[], path: string, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  const hasObjProp = children.some((c: any) => getTagName(c) === 'objProp');
  if (!hasObjProp) {
    warnings.push({
      code: 'RESULTCOLLECTOR_MISSING_SAVECONFIG',
      message: 'ResultCollector should contain an <objProp> saveConfig element',
      path,
      severity: 'warning',
    });
  }
}

function validateHttpSamplerProps(children: any[], path: string, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  const hasArgs = children.some((c: any) => {
    if (getTagName(c) !== 'elementProp') return false;
    return c[':@']?.['@_name'] === 'HTTPsampler.Arguments';
  });

  if (!hasArgs) {
    warnings.push({
      code: 'HTTPSAMPLER_MISSING_ARGUMENTS',
      message: 'HTTPSamplerProxy should contain an elementProp with name="HTTPsampler.Arguments"',
      path,
      severity: 'warning',
    });
  }
}

function validateThreadGroupProps(children: any[], path: string, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  const hasController = children.some((c: any) => {
    if (getTagName(c) !== 'elementProp') return false;
    return c[':@']?.['@_name'] === 'ThreadGroup.main_controller';
  });

  if (!hasController) {
    warnings.push({
      code: 'THREADGROUP_MISSING_CONTROLLER',
      message: 'ThreadGroup should contain an elementProp with name="ThreadGroup.main_controller"',
      path,
      severity: 'warning',
    });
  }
}

function validateTestPlanProps(children: any[], path: string, errors: ValidationIssue[], warnings: ValidationIssue[]) {
  const hasUserVars = children.some((c: any) => {
    if (getTagName(c) !== 'elementProp') return false;
    return c[':@']?.['@_name'] === 'TestPlan.user_defined_variables';
  });

  if (!hasUserVars) {
    warnings.push({
      code: 'TESTPLAN_MISSING_USER_VARS',
      message: 'TestPlan should contain an elementProp with name="TestPlan.user_defined_variables"',
      path,
      severity: 'warning',
    });
  }
}
