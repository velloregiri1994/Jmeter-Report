import type { HarEntry, HarPage } from './har-parser';
import type { CorrelationResult } from './correlation-detector';
import type { ParameterizationResult } from './parameterization-detector';
import {
  escapeXml,
  renderJmx,
  testPlan,
  threadGroup,
  httpDefaults,
  cookieManager,
  headerManager,
  csvDataSet,
  transactionController,
  httpSampler,
  regexExtractor,
  jsonExtractor,
  boundaryExtractor,
  xpathExtractor,
  cssJqueryExtractor,
  responseAssertion,
  uniformRandomTimer,
  resultCollector,
  type JmxElement,
  type HttpSamplerConfig,
} from './jmx-ast';

export interface JmxBuildOptions {
  threadCount: number;
  rampUp: number;
  duration: number;
  testName: string;
}

export interface JmxBuildConfig {
  entries: HarEntry[];
  pages: HarPage[];
  correlations: CorrelationResult[];
  parameterizations: ParameterizationResult[];
  options: JmxBuildOptions;
  csvFileName?: string;
}

const STRIP_HEADERS = new Set([
  'content-length',
  'host',
  'connection',
  'cookie',
  'sec-fetch-dest',
  'sec-fetch-mode',
  'sec-fetch-site',
  'sec-fetch-user',
  'sec-ch-ua',
  'sec-ch-ua-mobile',
  'sec-ch-ua-platform',
]);

function getMostCommonDomain(entries: HarEntry[]): { protocol: string; domain: string; port: string } {
  const counts = new Map<string, number>();
  for (const e of entries) {
    const key = `${e.url.protocol}://${e.url.domain}:${e.url.port}`;
    counts.set(key, (counts.get(key) || 0) + 1);
  }

  let maxKey = '';
  let maxCount = 0;
  counts.forEach((count, key) => {
    if (count > maxCount) {
      maxCount = count;
      maxKey = key;
    }
  });

  if (!maxKey && entries.length > 0) {
    return { protocol: entries[0].url.protocol, domain: entries[0].url.domain, port: entries[0].url.port };
  }

  const parts = maxKey.match(/^(.+):\/\/(.+):(.+)$/);
  if (parts) {
    return { protocol: parts[1], domain: parts[2], port: parts[3] };
  }
  return { protocol: 'https', domain: 'localhost', port: '443' };
}

function getLastPathSegment(path: string): string {
  const clean = path.replace(/\/$/, '').split('?')[0];
  const segments = clean.split('/').filter(Boolean);
  const last = segments[segments.length - 1] || 'root';
  return last.replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 40);
}

const ACTION_KEYWORDS: Record<string, string> = {
  login: 'Login',
  signin: 'SignIn',
  'sign-in': 'SignIn',
  signup: 'SignUp',
  'sign-up': 'SignUp',
  register: 'Register',
  logout: 'Logout',
  signout: 'SignOut',
  'sign-out': 'SignOut',
  search: 'Search',
  checkout: 'Checkout',
  'check-out': 'Checkout',
  cart: 'Cart',
  addtocart: 'AddToCart',
  'add-to-cart': 'AddToCart',
  payment: 'Payment',
  pay: 'Payment',
  order: 'Order',
  orders: 'Orders',
  dashboard: 'Dashboard',
  home: 'Home',
  index: 'Home',
  profile: 'Profile',
  account: 'Account',
  settings: 'Settings',
  preferences: 'Preferences',
  catalog: 'Catalog',
  products: 'Products',
  product: 'Product',
  categories: 'Categories',
  category: 'Category',
  details: 'Details',
  detail: 'Detail',
  view: 'View',
  list: 'List',
  submit: 'Submit',
  confirm: 'Confirm',
  confirmation: 'Confirmation',
  verify: 'Verify',
  reset: 'Reset',
  forgot: 'ForgotPassword',
  'forgot-password': 'ForgotPassword',
  upload: 'Upload',
  download: 'Download',
  delete: 'Delete',
  remove: 'Remove',
  update: 'Update',
  edit: 'Edit',
  create: 'Create',
  add: 'Add',
  save: 'Save',
  filter: 'Filter',
  sort: 'Sort',
  navigate: 'Navigate',
  launch: 'Launch',
  landing: 'Landing',
  welcome: 'Welcome',
  contact: 'Contact',
  about: 'About',
  help: 'Help',
  faq: 'FAQ',
  support: 'Support',
  admin: 'Admin',
  manage: 'Manage',
  report: 'Report',
  reports: 'Reports',
  analytics: 'Analytics',
  notifications: 'Notifications',
  messages: 'Messages',
  inbox: 'Inbox',
  favorites: 'Favorites',
  wishlist: 'Wishlist',
  review: 'Review',
  reviews: 'Reviews',
  shipping: 'Shipping',
  billing: 'Billing',
  address: 'Address',
  inventory: 'Inventory',
  api: 'API',
  auth: 'Auth',
  token: 'Token',
  refresh: 'Refresh',
  callback: 'Callback',
  redirect: 'Redirect',
};

function inferTransactionName(entries: HarEntry[]): string {
  for (const entry of entries) {
    const pathLower = entry.url.path.toLowerCase();
    const segments = pathLower.replace(/\/$/, '').split('/').filter(Boolean);

    for (const seg of segments) {
      const clean = seg.replace(/[^a-z0-9-]/g, '');
      if (ACTION_KEYWORDS[clean]) {
        return ACTION_KEYWORDS[clean];
      }
      for (const [keyword, label] of Object.entries(ACTION_KEYWORDS)) {
        if (clean.includes(keyword)) {
          return label;
        }
      }
    }
  }

  const firstPath = entries[0].url.path;
  const segments = firstPath.replace(/\/$/, '').split('?')[0].split('/').filter(Boolean);
  const meaningful = segments.filter(s => !/^[0-9a-f-]{8,}$/i.test(s) && !/^\d+$/.test(s));
  if (meaningful.length > 0) {
    const last = meaningful[meaningful.length - 1];
    return last
      .replace(/[^a-zA-Z0-9]/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_|_$/g, '')
      .split('_')
      .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join('_')
      .substring(0, 40);
  }

  return 'Page';
}

function buildRequestName(seqNum: number, method: string, path: string): string {
  const num = String(seqNum).padStart(2, '0');
  const seg = getLastPathSegment(path);
  return `${num}_${method}_${seg}`;
}

function getEntryTimestamp(entry: HarEntry): number {
  if (entry.startedDateTime) {
    const ts = new Date(entry.startedDateTime).getTime();
    if (!isNaN(ts)) return ts;
  }
  return 0;
}

function groupByTimeGap(entries: HarEntry[], gapThresholdMs: number = 2000): { name: string; entries: HarEntry[] }[] {
  if (entries.length === 0) return [];

  const groups: { name: string; entries: HarEntry[] }[] = [];
  let currentGroup: HarEntry[] = [entries[0]];
  let tcNum = 1;

  for (let i = 1; i < entries.length; i++) {
    const prevTs = getEntryTimestamp(entries[i - 1]);
    const currTs = getEntryTimestamp(entries[i]);
    const gap = prevTs > 0 && currTs > 0 ? currTs - prevTs : 0;

    if (gap > gapThresholdMs) {
      const label = inferTransactionName(currentGroup);
      const num = String(tcNum).padStart(2, '0');
      groups.push({ name: `TC_${num}_${label}`, entries: currentGroup });
      currentGroup = [entries[i]];
      tcNum++;
    } else {
      currentGroup.push(entries[i]);
    }
  }

  if (currentGroup.length > 0) {
    const label = inferTransactionName(currentGroup);
    const num = String(tcNum).padStart(2, '0');
    groups.push({ name: `TC_${num}_${label}`, entries: currentGroup });
  }

  return groups;
}

function groupByTransaction(entries: HarEntry[], pages: HarPage[]): { name: string; entries: HarEntry[] }[] {
  const pageMap = new Map<string, string>();
  for (const p of pages) {
    pageMap.set(p.id, p.title || p.id);
  }

  const grouped = new Map<string, HarEntry[]>();
  const firstIndexPerPage = new Map<string, number>();
  const noPage: HarEntry[] = [];

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (entry.pageref && pageMap.has(entry.pageref)) {
      const key = entry.pageref;
      if (!grouped.has(key)) {
        grouped.set(key, []);
        firstIndexPerPage.set(key, i);
      }
      grouped.get(key)!.push(entry);
    } else {
      noPage.push(entry);
    }
  }

  if (grouped.size === 0) {
    return groupByTimeGap(entries);
  }

  const sortedPageIds = Array.from(grouped.keys()).sort((a, b) => {
    return (firstIndexPerPage.get(a) ?? 0) - (firstIndexPerPage.get(b) ?? 0);
  });

  type RawGroup = { name: string; entries: HarEntry[]; firstIdx: number };
  const rawGroups: RawGroup[] = [];

  for (const pageId of sortedPageIds) {
    const groupEntries = grouped.get(pageId)!;
    const title = pageMap.get(pageId) || 'Page';
    const cleanTitle = title.replace(/[^a-zA-Z0-9_\- ]/g, '_').substring(0, 50);
    rawGroups.push({ name: cleanTitle, entries: groupEntries, firstIdx: firstIndexPerPage.get(pageId)! });
  }

  if (noPage.length > 0) {
    const noPageGroups = groupByTimeGap(noPage);
    for (const npg of noPageGroups) {
      const label = inferTransactionName(npg.entries);
      const npFirstIdx = entries.indexOf(npg.entries[0]);
      let insertPos = rawGroups.length;
      for (let g = 0; g < rawGroups.length; g++) {
        if (rawGroups[g].firstIdx > npFirstIdx) {
          insertPos = g;
          break;
        }
      }
      rawGroups.splice(insertPos, 0, { name: label, entries: npg.entries, firstIdx: npFirstIdx });
    }
  }

  const groups: { name: string; entries: HarEntry[] }[] = [];
  let tcNum = 1;
  for (const rg of rawGroups) {
    const num = String(tcNum).padStart(2, '0');
    groups.push({ name: `TC_${num}_${rg.name}`, entries: rg.entries });
    tcNum++;
  }

  return groups;
}

function applyReplacements(text: string, correlations: CorrelationResult[], parameterizations: ParameterizationResult[], entryIndex: number): string {
  let result = text;

  const applicableCorrelations = correlations
    .filter(c => c.targetRequests.includes(entryIndex))
    .sort((a, b) => b.originalValue.length - a.originalValue.length);

  for (const corr of applicableCorrelations) {
    const placeholder = '${' + corr.variable + '}';
    result = result.split(corr.originalValue).join(placeholder);
    const encoded = encodeURIComponent(corr.originalValue);
    if (encoded !== corr.originalValue) {
      result = result.split(encoded).join(placeholder);
    }
  }

  const applicableParams = parameterizations
    .filter(p => p.occurrences.some(o => o.requestIndex === entryIndex))
    .sort((a, b) => b.originalValue.length - a.originalValue.length);

  for (const param of applicableParams) {
    const placeholder = '${' + param.variable + '}';
    result = result.split(param.originalValue).join(placeholder);
    const encoded = encodeURIComponent(param.originalValue);
    if (encoded !== param.originalValue) {
      result = result.split(encoded).join(placeholder);
    }
  }

  return result;
}

function shouldFilterHeader(name: string): boolean {
  return STRIP_HEADERS.has(name.toLowerCase());
}

function getCommonHeaders(entries: HarEntry[]): { name: string; value: string }[] {
  const headerCounts = new Map<string, Map<string, number>>();

  for (const e of entries) {
    for (const h of e.headers) {
      if (shouldFilterHeader(h.name)) continue;
      const lowerName = h.name.toLowerCase();
      if (!headerCounts.has(lowerName)) {
        headerCounts.set(lowerName, new Map());
      }
      const valMap = headerCounts.get(lowerName)!;
      valMap.set(h.value, (valMap.get(h.value) || 0) + 1);
    }
  }

  const threshold = Math.max(1, Math.floor(entries.length * 0.5));
  const common: { name: string; value: string }[] = [];

  const priorityHeaders = ['accept', 'content-type', 'accept-encoding', 'accept-language'];
  for (const ph of priorityHeaders) {
    const valMap = headerCounts.get(ph);
    if (!valMap) continue;
    let bestVal = '';
    let bestCount = 0;
    valMap.forEach((count, val) => {
      if (count > bestCount) {
        bestCount = count;
        bestVal = val;
      }
    });
    if (bestCount >= threshold) {
      common.push({ name: ph.split('-').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('-'), value: bestVal });
    }
  }

  return common;
}

function getPerRequestHeaders(entry: HarEntry, commonHeaders: { name: string; value: string }[]): { name: string; value: string }[] {
  const commonMap = new Map<string, string>();
  for (const h of commonHeaders) {
    commonMap.set(h.name.toLowerCase(), h.value);
  }

  const perRequest: { name: string; value: string }[] = [];
  for (const h of entry.headers) {
    if (shouldFilterHeader(h.name)) continue;
    const lower = h.name.toLowerCase();
    if (commonMap.has(lower) && commonMap.get(lower) === h.value) continue;
    if (lower === 'accept-encoding' || lower === 'accept-language') continue;
    perRequest.push({ name: h.name, value: h.value });
  }

  return perRequest;
}

function buildExtractorElement(corr: CorrelationResult): JmxElement {
  if (corr.extractorType === 'json') {
    return jsonExtractor(corr.variable, corr.pattern);
  }
  if (corr.extractorType === 'boundary' && corr.leftBoundary && corr.rightBoundary) {
    return boundaryExtractor(corr.variable, corr.leftBoundary, corr.rightBoundary, false);
  }
  if (corr.extractorType === 'xpath') {
    return xpathExtractor(corr.variable, corr.pattern);
  }
  if (corr.extractorType === 'css' && corr.cssSelector) {
    return cssJqueryExtractor(corr.variable, corr.cssSelector, corr.cssAttribute || '');
  }
  if (corr.extractorType === 'header') {
    return regexExtractor(corr.variable, corr.pattern, true);
  }
  return regexExtractor(corr.variable, corr.pattern, false);
}

function buildHttpRequestElement(
  entry: HarEntry,
  seqNum: number,
  defaultDomain: string,
  defaultProtocol: string,
  defaultPort: string,
  correlations: CorrelationResult[],
  parameterizations: ParameterizationResult[],
  commonHeaders: { name: string; value: string }[]
): JmxElement {
  const name = buildRequestName(seqNum, entry.method, entry.url.path);
  const entryIndex = entry.index;

  const useDifferentDomain = entry.url.domain !== defaultDomain;
  const domain = useDifferentDomain ? entry.url.domain : '';
  const protocol = useDifferentDomain ? entry.url.protocol : '';
  const port = useDifferentDomain ? (entry.url.port !== '80' && entry.url.port !== '443' ? entry.url.port : '') : '';

  const fullPath = entry.url.query
    ? `${entry.url.path}?${entry.url.query}`
    : entry.url.path;
  const path = applyReplacements(fullPath, correlations, parameterizations, entryIndex);

  const mime = entry.postData?.mimeType?.toLowerCase() || '';
  const isRawBody = mime.includes('application/json') || mime.includes('text/xml') || mime.includes('application/xml');
  const isFormUrlEncoded = mime.includes('application/x-www-form-urlencoded');
  const isMultipart = mime.includes('multipart/form-data');

  let body: HttpSamplerConfig['body'];

  if (entry.postData && isRawBody && entry.postData.text) {
    const bodyText = applyReplacements(entry.postData.text, correlations, parameterizations, entryIndex);
    body = { type: 'raw', rawText: bodyText };
  } else if (entry.postData && (isFormUrlEncoded || isMultipart || entry.postData.params?.length)) {
    const params: { name: string; value: string }[] = [];
    const entryParams = entry.postData.params || [];

    if (entryParams.length > 0) {
      for (const p of entryParams) {
        const val = p.value ? applyReplacements(p.value, correlations, parameterizations, entryIndex) : '';
        params.push({ name: p.name, value: val });
      }
    } else if (entry.postData.text && isFormUrlEncoded) {
      try {
        const sp = new URLSearchParams(entry.postData.text);
        sp.forEach((val, key) => {
          const replacedVal = applyReplacements(val, correlations, parameterizations, entryIndex);
          params.push({ name: key, value: replacedVal });
        });
      } catch {}
    }

    body = { type: 'params', params };
  } else {
    body = { type: 'empty' };
  }

  const children: JmxElement[] = [];

  const perReqHeaders = getPerRequestHeaders(entry, commonHeaders);
  const replacedHeaders = perReqHeaders.map(h => ({
    name: h.name,
    value: applyReplacements(h.value, correlations, parameterizations, entryIndex),
  }));
  if (replacedHeaders.length > 0) {
    children.push(headerManager('HTTP Header Manager', replacedHeaders));
  }

  const extractorsForThis = correlations.filter(c => c.sourceRequest === entryIndex);
  for (const corr of extractorsForThis) {
    children.push(buildExtractorElement(corr));
  }

  if (entry.responseStatus >= 200 && entry.responseStatus < 300) {
    children.push(responseAssertion(entry.responseStatus));
  } else if (entry.responseStatus >= 400 && entry.responseStatus < 600) {
    children.push(responseAssertion(entry.responseStatus));
  }

  return httpSampler({
    name,
    domain,
    port,
    protocol,
    path,
    method: entry.method,
    isMultipart,
    body,
    children,
  });
}

export function buildJmx(config: JmxBuildConfig): string {
  const { entries, pages, correlations, parameterizations, options } = config;
  const csvFileName = config.csvFileName || 'test_data.csv';

  if (entries.length === 0) {
    throw new Error('No entries to build JMX from');
  }

  const { protocol: defaultProtocol, domain: defaultDomain, port: defaultPort } = getMostCommonDomain(entries);
  const commonHeaders = getCommonHeaders(entries);
  const transactionGroups = groupByTransaction(entries, pages);

  const displayPort = (defaultProtocol === 'https' && defaultPort === '443') || (defaultProtocol === 'http' && defaultPort === '80') ? '' : defaultPort;

  const threadGroupChildren: JmxElement[] = [];

  threadGroupChildren.push(httpDefaults(defaultDomain, displayPort, defaultProtocol));
  threadGroupChildren.push(cookieManager());

  if (commonHeaders.length > 0) {
    threadGroupChildren.push(headerManager('HTTP Header Manager', commonHeaders));
  }

  if (parameterizations.length > 0) {
    const uniqueVars: string[] = [];
    const seenVars = new Set<string>();
    for (const p of parameterizations) {
      if (!seenVars.has(p.variable)) {
        seenVars.add(p.variable);
        uniqueVars.push(p.variable);
      }
    }
    threadGroupChildren.push(csvDataSet(csvFileName, uniqueVars.join(',')));
  }

  let globalSeqNum = 1;

  for (let gi = 0; gi < transactionGroups.length; gi++) {
    const group = transactionGroups[gi];

    if (gi > 0) {
      const prevGroup = transactionGroups[gi - 1];
      const prevLastEntry = prevGroup.entries[prevGroup.entries.length - 1];
      const currFirstEntry = group.entries[0];
      const prevTs = getEntryTimestamp(prevLastEntry);
      const currTs = getEntryTimestamp(currFirstEntry);
      const gapMs = prevTs > 0 && currTs > 0 ? currTs - prevTs : 0;

      if (gapMs > 500) {
        const clampedDelay = Math.min(Math.max(gapMs, 1000), 30000);
        const range = Math.round(clampedDelay * 0.5);
        const baseDelay = Math.round(clampedDelay * 0.5);
        threadGroupChildren.push(uniformRandomTimer(baseDelay, range));
      } else {
        threadGroupChildren.push(uniformRandomTimer(1000, 2000));
      }
    }

    const tcChildren: JmxElement[] = [];

    for (const entry of group.entries) {
      tcChildren.push(
        buildHttpRequestElement(entry, globalSeqNum, defaultDomain, defaultProtocol, defaultPort, correlations, parameterizations, commonHeaders)
      );
      globalSeqNum++;
    }

    threadGroupChildren.push(transactionController(group.name, tcChildren));
  }

  threadGroupChildren.push(resultCollector());

  const tg = threadGroup('Thread Group', options.threadCount, options.rampUp, options.duration, threadGroupChildren);

  const root = testPlan(
    options.testName,
    'Generated by PerfHub HAR Converter',
    [{ name: 'BASE_URL', value: defaultDomain }],
    [tg]
  );

  return renderJmx(root);
}
