import { HarEntry } from './har-parser';

const STATIC_MIME_PREFIXES = [
  'image/',
  'font/',
  'video/',
  'audio/',
  'application/font-',
];

const STATIC_MIME_EXACT = new Set([
  'text/css',
  'application/javascript',
  'application/x-javascript',
  'application/wasm',
  'image/svg+xml',
]);

const STATIC_EXTENSIONS = new Set([
  '.css', '.js', '.mjs',
  '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico',
  '.woff', '.woff2', '.ttf', '.eot',
  '.map', '.webp', '.avif',
  '.mp4', '.webm',
]);

const THIRD_PARTY_DOMAIN_PATTERNS = [
  'google-analytics.com',
  'googletagmanager.com',
  'googleapis.com',
  'gstatic.com',
  'google.com',
  'googlesyndication.com',
  'googleadservices.com',
  'googleusercontent.com',
  'doubleclick.net',
  'youtube.com',
  'ytimg.com',
  'facebook.com',
  'facebook.net',
  'fbcdn.net',
  'instagram.com',
  'twitter.com',
  'twimg.com',
  'linkedin.com',
  'licdn.com',
  'pinterest.com',
  'tiktok.com',
  'hotjar.com',
  'clarity.ms',
  'newrelic.com',
  'nr-data.net',
  'segment.io',
  'segment.com',
  'mixpanel.com',
  'optimizely.com',
  'fullstory.com',
  'mouseflow.com',
  'crazyegg.com',
  'heapanalytics.com',
  'amplitude.com',
  'sentry.io',
  'bugsnag.com',
  'rollbar.com',
  'intercom.io',
  'zendesk.com',
  'zdassets.com',
  'crisp.chat',
  'drift.com',
  'hubspot.com',
  'hs-scripts.com',
  'hs-analytics.net',
  'hsforms.com',
  'marketo.net',
  'pardot.com',
  'bat.bing.com',
  'bing.com',
  'ads.linkedin.com',
  'cdn.cookielaw.org',
  'cookiebot.com',
  'onetrust.com',
  'trustarcedge.com',
  'cloudflare.com',
  'cdnjs.cloudflare.com',
  'cdn.jsdelivr.net',
  'jsdelivr.net',
  'unpkg.com',
  'bootstrapcdn.com',
  'jquery.com',
  'fontawesome.com',
  'recaptcha.net',
  'hcaptcha.com',
  'stripe.com',
  'paypal.com',
  'braintreegateway.com',
  'braintree-api.com',
  'cloudfront.net',
  'akamaihd.net',
  'akamai.net',
  'fastly.net',
  'maxcdn.com',
  'stackpath.com',
  'azureedge.net',
  'azurewebsites.net',
  'msecnd.net',
  'appdynamics.com',
  'dynatrace.com',
  'datadoghq.com',
  'statuspage.io',
  'pendo.io',
  'walkme.com',
  'userpilot.com',
  'appcues.com',
  'launchdarkly.com',
  'split.io',
  'livechatinc.com',
  'tawk.to',
  'olark.com',
  'freshdesk.com',
  'freshchat.com',
  'typekit.net',
  'use.typekit.net',
  'gravatar.com',
  'wp.com',
  'sharethis.com',
  'addthis.com',
  'addtoany.com',
  'disqus.com',
  'sumome.com',
  'sumo.com',
  'chartbeat.com',
  'quantserve.com',
  'scorecardresearch.com',
  'demdex.net',
  'omtrdc.net',
  'adobedtm.com',
  'evidon.com',
  'trustarc.com',
  'cookiepro.com',
  'iubenda.com',
  'osano.com',
  'usercentrics.eu',
  'consentmanager.net',
];

function extractRootDomain(domain: string): string {
  const parts = domain.toLowerCase().split('.');
  if (parts.length <= 2) return domain.toLowerCase();

  const knownTLDs = new Set([
    'co.uk', 'co.in', 'co.jp', 'co.kr', 'co.nz', 'co.za',
    'com.au', 'com.br', 'com.cn', 'com.mx', 'com.sg', 'com.tw',
    'org.uk', 'net.au', 'ac.uk', 'gov.uk',
  ]);

  const lastTwo = parts.slice(-2).join('.');
  if (knownTLDs.has(lastTwo) && parts.length > 2) {
    return parts.slice(-3).join('.');
  }
  return parts.slice(-2).join('.');
}

function detectPrimaryDomains(entries: HarEntry[]): Set<string> {
  const rootDomainCounts = new Map<string, number>();

  for (const entry of entries) {
    if (!entry.url.domain) continue;
    const root = extractRootDomain(entry.url.domain);
    rootDomainCounts.set(root, (rootDomainCounts.get(root) || 0) + 1);
  }

  if (rootDomainCounts.size === 0) return new Set();

  const sorted = [...rootDomainCounts.entries()].sort((a, b) => b[1] - a[1]);
  const primaryDomains = new Set<string>();

  const topNonThirdParty = sorted.find(([domain]) => !isKnownThirdPartyRoot(domain));

  if (!topNonThirdParty) {
    primaryDomains.add(sorted[0][0]);
    return primaryDomains;
  }

  primaryDomains.add(topNonThirdParty[0]);
  const topCount = topNonThirdParty[1];

  for (const [domain, count] of sorted) {
    if (domain === topNonThirdParty[0]) continue;
    if (isKnownThirdPartyRoot(domain)) continue;
    if (count >= topCount * 0.10) {
      primaryDomains.add(domain);
    }
  }

  return primaryDomains;
}

function isKnownThirdPartyRoot(rootDomain: string): boolean {
  const lower = rootDomain.toLowerCase();
  for (const pattern of THIRD_PARTY_DOMAIN_PATTERNS) {
    const patternRoot = extractRootDomain(pattern);
    if (lower === patternRoot || lower === pattern) {
      return true;
    }
  }
  return false;
}

export interface FilterStats {
  totalEntries: number;
  filteredEntries: number;
  removedByMimeType: number;
  removedByExtension: number;
  removedByThirdParty: number;
  removedByStatus: number;
  removedByPreflight: number;
  redirectChains: number;
  primaryDomains: string[];
}

export interface RedirectChainInfo {
  entryIndex: number;
  redirectsTo: number;
}

export interface FilterResult {
  entries: HarEntry[];
  stats: FilterStats;
  redirectChains: RedirectChainInfo[];
}

function isStaticMimeType(mimeType: string): boolean {
  if (!mimeType) return false;
  const lower = mimeType.toLowerCase().split(';')[0].trim();
  if (STATIC_MIME_EXACT.has(lower)) return true;
  return STATIC_MIME_PREFIXES.some(prefix => lower.startsWith(prefix));
}

function isStaticExtension(urlPath: string): boolean {
  if (!urlPath) return false;
  const cleanPath = urlPath.split('?')[0];
  const lastDot = cleanPath.lastIndexOf('.');
  if (lastDot === -1) return false;
  const ext = cleanPath.substring(lastDot).toLowerCase();
  return STATIC_EXTENSIONS.has(ext);
}

const INFRASTRUCTURE_PATH_PREFIXES = [
  '/cdn-cgi/',
  '/__cf_chl_',
  '/cdn-cgi/rum',
  '/cdn-cgi/trace',
  '/cdn-cgi/challenge-platform',
  '/_next/webpack-hmr',
  '/__webpack_hmr',
  '/__vite_ping',
  '/sockjs-node/',
  '/browser-sync/',
  '/_blazor/',
  '/.well-known/',
  '/robots.txt',
  '/sitemap.xml',
  '/sw.js',
  '/service-worker.js',
  '/manifest.json',
  '/site.webmanifest',
];

function isInfrastructurePath(path: string): boolean {
  if (!path) return false;
  const lower = path.toLowerCase().split('?')[0];
  for (const prefix of INFRASTRUCTURE_PATH_PREFIXES) {
    if (lower.startsWith(prefix) || lower === prefix || lower.endsWith(prefix)) return true;
  }
  return false;
}

function isThirdPartyDomain(domain: string, primaryDomains: Set<string>): boolean {
  if (!domain) return false;
  const lower = domain.toLowerCase();
  const rootDomain = extractRootDomain(lower);

  if (primaryDomains.has(rootDomain)) {
    return false;
  }

  return true;
}

function isRedirectStatus(status: number): boolean {
  return status === 301 || status === 302 || status === 303 || status === 307 || status === 308;
}

export interface DomainFilterOptions {
  includeDomains?: string[];
  excludeDomains?: string[];
}

function matchesDomainList(domain: string, patterns: string[]): boolean {
  const lower = domain.toLowerCase();
  for (const pattern of patterns) {
    if (lower === pattern || lower.endsWith('.' + pattern)) {
      return true;
    }
  }
  return false;
}

export function filterEntries(entries: HarEntry[], domainOptions?: DomainFilterOptions): FilterResult {
  const userInclude = (domainOptions?.includeDomains || [])
    .map(d => d.trim().toLowerCase())
    .filter(d => d.length > 0);
  const userExclude = (domainOptions?.excludeDomains || [])
    .map(d => d.trim().toLowerCase())
    .filter(d => d.length > 0);

  const primaryDomains = userInclude.length > 0
    ? new Set(userInclude.map(d => extractRootDomain(d)))
    : detectPrimaryDomains(entries);

  const stats: FilterStats = {
    totalEntries: entries.length,
    filteredEntries: 0,
    removedByMimeType: 0,
    removedByExtension: 0,
    removedByThirdParty: 0,
    removedByStatus: 0,
    removedByPreflight: 0,
    redirectChains: 0,
    primaryDomains: [...primaryDomains],
  };

  const redirectChains: RedirectChainInfo[] = [];
  const redirectChainIndices = new Set<number>();

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (isRedirectStatus(entry.responseStatus) && entry.redirectURL) {
      for (let j = i + 1; j < entries.length && j <= i + 3; j++) {
        if (entries[j].url.full === entry.redirectURL ||
            entries[j].url.full.replace(/\/$/, '') === entry.redirectURL.replace(/\/$/, '')) {
          redirectChains.push({ entryIndex: i, redirectsTo: j });
          redirectChainIndices.add(i);
          stats.redirectChains++;
          break;
        }
      }
    }
  }

  const filtered: HarEntry[] = [];

  for (const entry of entries) {
    if (redirectChainIndices.has(entry.index)) {
      continue;
    }

    if (entry.method === 'OPTIONS') {
      stats.removedByPreflight++;
      continue;
    }

    if (entry.responseStatus >= 400 && entry.responseBodySize === 0) {
      stats.removedByStatus++;
      continue;
    }

    if (userExclude.length > 0 && matchesDomainList(entry.url.domain, userExclude)) {
      stats.removedByThirdParty++;
      continue;
    }

    if (userInclude.length > 0) {
      if (!matchesDomainList(entry.url.domain, userInclude)) {
        stats.removedByThirdParty++;
        continue;
      }
    } else if (isThirdPartyDomain(entry.url.domain, primaryDomains)) {
      stats.removedByThirdParty++;
      continue;
    }

    if (isStaticMimeType(entry.responseMimeType)) {
      stats.removedByMimeType++;
      continue;
    }

    if (isStaticExtension(entry.url.path)) {
      stats.removedByExtension++;
      continue;
    }

    if (isInfrastructurePath(entry.url.path)) {
      stats.removedByExtension++;
      continue;
    }

    filtered.push(entry);
  }

  stats.filteredEntries = filtered.length;

  return {
    entries: filtered,
    stats,
    redirectChains,
  };
}
