import type { HarEntry } from './har-parser';
import type { CorrelationResult } from './correlation-detector';
import type { ParameterizationResult } from './parameterization-detector';
import type { FilterStats } from './request-filter';

export interface ScoreBreakdown {
  category: string;
  score: number;
  maxScore: number;
  details: string;
}

export interface ScoreResult {
  score: number;
  readinessLevel: 'Poor' | 'Moderate' | 'Good' | 'Production Ready';
  breakdown: ScoreBreakdown[];
}

export interface ScoreInput {
  filteredEntries: HarEntry[];
  filterStats: FilterStats;
  correlations: CorrelationResult[];
  parameterizations: ParameterizationResult[];
  transactionGroupCount: number;
  assertionCount: number;
  hasCookieManager: boolean;
  hasHttpDefaults: boolean;
  hasKeepalive: boolean;
  hasTimeouts: boolean;
}

function getReadinessLevel(score: number): 'Poor' | 'Moderate' | 'Good' | 'Production Ready' {
  if (score >= 80) return 'Production Ready';
  if (score >= 60) return 'Good';
  if (score >= 40) return 'Moderate';
  return 'Poor';
}

export function scoreScript(config: ScoreInput): ScoreResult {
  const breakdown: ScoreBreakdown[] = [];

  const totalRemoved = config.filterStats.removedByMimeType
    + config.filterStats.removedByExtension
    + config.filterStats.removedByThirdParty
    + config.filterStats.removedByStatus
    + config.filterStats.removedByPreflight;
  const totalOriginal = config.filterStats.totalEntries;
  let staticScore = 0;
  if (totalOriginal > 0 && totalRemoved > 0) {
    const removalRatio = totalRemoved / totalOriginal;
    if (removalRatio >= 0.05) {
      staticScore = Math.min(Math.round(15 * Math.min(removalRatio * 5, 1)), 15);
    } else {
      staticScore = 5;
    }
  } else if (totalOriginal > 0 && totalRemoved === 0) {
    staticScore = 10;
  }
  staticScore = Math.min(staticScore, 15);
  breakdown.push({
    category: 'Static Content Removal',
    score: staticScore,
    maxScore: 15,
    details: totalRemoved > 0
      ? `${totalRemoved} of ${totalOriginal} requests removed (static/analytics)`
      : `No static/analytics requests found to remove (${totalOriginal} total)`,
  });

  let transactionScore = 0;
  if (config.transactionGroupCount > 1) {
    transactionScore = 15;
  } else if (config.transactionGroupCount === 1) {
    transactionScore = 8;
  }
  breakdown.push({
    category: 'Transaction Grouping',
    score: transactionScore,
    maxScore: 15,
    details: `${config.transactionGroupCount} transaction group(s) created`,
  });

  let correlationScore = 0;
  const corrCount = config.correlations.length;
  if (corrCount >= 5) {
    correlationScore = 25;
  } else if (corrCount >= 3) {
    correlationScore = 20;
  } else if (corrCount >= 1) {
    correlationScore = 15;
  }
  breakdown.push({
    category: 'Correlation Completeness',
    score: correlationScore,
    maxScore: 25,
    details: corrCount > 0
      ? `${corrCount} dynamic value(s) correlated`
      : 'No dynamic values detected or correlated',
  });

  let paramScore = 0;
  const paramCount = config.parameterizations.length;
  if (paramCount >= 3) {
    paramScore = 15;
  } else if (paramCount >= 1) {
    paramScore = 10;
  }
  breakdown.push({
    category: 'Parameterization',
    score: paramScore,
    maxScore: 15,
    details: paramCount > 0
      ? `${paramCount} value(s) parameterized`
      : 'No credentials or repeated values detected',
  });

  const entryCount = config.filteredEntries.length;
  let assertionScore = 0;
  if (config.assertionCount > 0 && entryCount > 0) {
    const coverage = config.assertionCount / entryCount;
    if (coverage >= 0.8) {
      assertionScore = 10;
    } else if (coverage >= 0.5) {
      assertionScore = 7;
    } else {
      assertionScore = 4;
    }
  }
  breakdown.push({
    category: 'Assertions',
    score: assertionScore,
    maxScore: 10,
    details: config.assertionCount > 0
      ? `${config.assertionCount} response code assertion(s) on ${entryCount} requests`
      : 'No response assertions configured',
  });

  let bestPracticeScore = 0;
  let bpDetails: string[] = [];
  if (config.hasCookieManager) { bestPracticeScore += 3; bpDetails.push('Cookie Manager'); }
  if (config.hasHttpDefaults) { bestPracticeScore += 3; bpDetails.push('HTTP Defaults'); }
  if (config.hasKeepalive) { bestPracticeScore += 2; bpDetails.push('Keep-Alive'); }
  if (config.hasTimeouts) { bestPracticeScore += 2; bpDetails.push('Timeouts'); }
  breakdown.push({
    category: 'Best Practice Config',
    score: bestPracticeScore,
    maxScore: 10,
    details: bpDetails.length > 0
      ? `Configured: ${bpDetails.join(', ')}`
      : 'No best practice configurations applied',
  });

  const totalScore = breakdown.reduce((sum, b) => sum + b.score, 0);
  const maxPossible = breakdown.reduce((sum, b) => sum + b.maxScore, 0);
  const normalizedScore = maxPossible > 0 ? Math.round((totalScore / maxPossible) * 100) : 0;
  const clampedScore = Math.min(Math.max(normalizedScore, 0), 100);

  return {
    score: clampedScore,
    readinessLevel: getReadinessLevel(clampedScore),
    breakdown,
  };
}
