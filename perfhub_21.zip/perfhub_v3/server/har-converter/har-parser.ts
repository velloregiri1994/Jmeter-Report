import fs from 'fs';
import path from 'path';

export interface HarTiming {
  blocked?: number;
  dns?: number;
  connect?: number;
  send: number;
  wait: number;
  receive: number;
  ssl?: number;
}

export interface HarHeader {
  name: string;
  value: string;
}

export interface HarQueryParam {
  name: string;
  value: string;
}

export interface HarPostParam {
  name: string;
  value?: string;
  fileName?: string;
  contentType?: string;
}

export interface HarPostData {
  mimeType: string;
  text?: string;
  params?: HarPostParam[];
}

export interface HarCookie {
  name: string;
  value: string;
  path?: string;
  domain?: string;
  expires?: string;
  httpOnly?: boolean;
  secure?: boolean;
}

export interface HarResponse {
  status: number;
  statusText: string;
  headers: HarHeader[];
  cookies?: HarCookie[];
  content: {
    size: number;
    mimeType: string;
    text?: string;
    encoding?: string;
  };
  redirectURL: string;
  headersSize: number;
  bodySize: number;
}

export interface HarRequest {
  method: string;
  url: string;
  httpVersion: string;
  headers: HarHeader[];
  queryString: HarQueryParam[];
  cookies?: HarCookie[];
  headersSize: number;
  bodySize: number;
  postData?: HarPostData;
}

export interface HarPage {
  startedDateTime: string;
  id: string;
  title: string;
  pageTimings?: {
    onContentLoad?: number;
    onLoad?: number;
  };
}

export interface HarRawEntry {
  startedDateTime: string;
  time?: number;
  request: HarRequest;
  response: HarResponse;
  cache?: Record<string, unknown>;
  timings: HarTiming;
  serverIPAddress?: string;
  connection?: string;
  pageref?: string;
}

export interface ParsedUrl {
  protocol: string;
  domain: string;
  port: string;
  path: string;
  query: string;
  full: string;
}

export interface HarEntry {
  index: number;
  method: string;
  url: ParsedUrl;
  headers: HarHeader[];
  postData?: HarPostData;
  responseStatus: number;
  responseStatusText: string;
  responseHeaders: HarHeader[];
  responseBodyText?: string;
  responseMimeType: string;
  responseBodySize: number;
  redirectURL: string;
  timings: HarTiming;
  startedDateTime: string;
  time?: number;
  pageref?: string;
}

export interface HarParseResult {
  entries: HarEntry[];
  pages: HarPage[];
}

function parseUrl(rawUrl: string): ParsedUrl {
  try {
    const u = new URL(rawUrl);
    return {
      protocol: u.protocol.replace(':', ''),
      domain: u.hostname,
      port: u.port || (u.protocol === 'https:' ? '443' : '80'),
      path: u.pathname,
      query: u.search.replace(/^\?/, ''),
      full: rawUrl,
    };
  } catch {
    return {
      protocol: '',
      domain: '',
      port: '',
      path: rawUrl,
      query: '',
      full: rawUrl,
    };
  }
}

function decodeBodyText(text?: string, encoding?: string): string | undefined {
  if (!text) return undefined;
  if (encoding === 'base64') {
    try {
      const decoded = Buffer.from(text, 'base64').toString('utf-8');
      if (/[\x00-\x08\x0E-\x1F]/.test(decoded.substring(0, 200))) {
        return undefined;
      }
      return decoded;
    } catch {
      return undefined;
    }
  }
  return text;
}

export async function parseHarFile(filePath: string): Promise<HarParseResult> {
  const absolutePath = path.isAbsolute(filePath) ? filePath : path.resolve(filePath);

  if (!fs.existsSync(absolutePath)) {
    throw new Error(`HAR file not found: ${absolutePath}`);
  }

  const raw = await fs.promises.readFile(absolutePath, 'utf-8');
  let har: any;

  try {
    har = JSON.parse(raw);
  } catch (e: any) {
    throw new Error(`Invalid JSON in HAR file: ${e.message}`);
  }

  if (!har.log) {
    throw new Error('Invalid HAR file: missing "log" property');
  }

  if (!Array.isArray(har.log.entries)) {
    throw new Error('Invalid HAR file: missing "log.entries" array');
  }

  const pages: HarPage[] = Array.isArray(har.log.pages) ? har.log.pages : [];

  const entries: HarEntry[] = [];
  for (let i = 0; i < har.log.entries.length; i++) {
    const raw = har.log.entries[i] as HarRawEntry;
    if (!raw.request?.url || !raw.request?.method) {
      continue;
    }
    try {
      entries.push({
        index: entries.length,
        method: raw.request.method.toUpperCase(),
        url: parseUrl(raw.request.url),
        headers: raw.request.headers || [],
        postData: raw.request.postData,
        responseStatus: raw.response?.status ?? 0,
        responseStatusText: raw.response?.statusText ?? '',
        responseHeaders: raw.response?.headers || [],
        responseBodyText: decodeBodyText(raw.response?.content?.text, raw.response?.content?.encoding),
        responseMimeType: raw.response?.content?.mimeType ?? '',
        responseBodySize: raw.response?.content?.size ?? raw.response?.bodySize ?? 0,
        redirectURL: raw.response?.redirectURL ?? '',
        timings: raw.timings || { send: 0, wait: 0, receive: 0 },
        startedDateTime: raw.startedDateTime || '',
        time: raw.time,
        pageref: raw.pageref,
      });
    } catch {
      continue;
    }
  }

  return { entries, pages };
}
