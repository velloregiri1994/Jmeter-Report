import { HarEntry } from './har-parser';

export interface ParameterizationOccurrence {
  requestIndex: number;
  location: 'body' | 'param' | 'header' | 'path';
  fieldName: string;
}

export interface ParameterizationResult {
  variable: string;
  originalValue: string;
  occurrences: ParameterizationOccurrence[];
}

export interface ParameterizationOutput {
  parameterizations: ParameterizationResult[];
  csvContent: string;
}

const CREDENTIAL_FIELD_NAMES: Record<string, string> = {
  username: 'P_USERNAME',
  user: 'P_USERNAME',
  login: 'P_USERNAME',
  user_name: 'P_USERNAME',
  username_or_email: 'P_USERNAME',
  userid: 'P_USERNAME',
  user_id: 'P_USERNAME',
  loginid: 'P_USERNAME',
  login_id: 'P_USERNAME',
  account: 'P_USERNAME',
  accountname: 'P_USERNAME',
  email: 'P_EMAIL',
  emailaddress: 'P_EMAIL',
  email_address: 'P_EMAIL',
  user_email: 'P_EMAIL',
  useremail: 'P_EMAIL',
  mail: 'P_EMAIL',
  password: 'P_PASSWORD',
  pass: 'P_PASSWORD',
  pwd: 'P_PASSWORD',
  passwd: 'P_PASSWORD',
  user_password: 'P_PASSWORD',
  userpassword: 'P_PASSWORD',
  currentpassword: 'P_PASSWORD',
  current_password: 'P_PASSWORD',
  newpassword: 'P_PASSWORD',
  new_password: 'P_PASSWORD',
  confirmpassword: 'P_PASSWORD',
  confirm_password: 'P_PASSWORD',
  oldpassword: 'P_PASSWORD',
  old_password: 'P_PASSWORD',
};

const PII_FIELD_NAMES: Record<string, string> = {
  firstname: 'P_FIRST_NAME',
  first_name: 'P_FIRST_NAME',
  fname: 'P_FIRST_NAME',
  givenname: 'P_FIRST_NAME',
  given_name: 'P_FIRST_NAME',
  lastname: 'P_LAST_NAME',
  last_name: 'P_LAST_NAME',
  lname: 'P_LAST_NAME',
  surname: 'P_LAST_NAME',
  familyname: 'P_LAST_NAME',
  family_name: 'P_LAST_NAME',
  fullname: 'P_FULL_NAME',
  full_name: 'P_FULL_NAME',
  displayname: 'P_FULL_NAME',
  display_name: 'P_FULL_NAME',
  phone: 'P_PHONE',
  phonenumber: 'P_PHONE',
  phone_number: 'P_PHONE',
  telephone: 'P_PHONE',
  mobile: 'P_PHONE',
  mobilenumber: 'P_PHONE',
  mobile_number: 'P_PHONE',
  cellphone: 'P_PHONE',
  cell_phone: 'P_PHONE',
  address: 'P_ADDRESS',
  address1: 'P_ADDRESS',
  address_1: 'P_ADDRESS',
  streetaddress: 'P_ADDRESS',
  street_address: 'P_ADDRESS',
  addressline1: 'P_ADDRESS',
  address_line_1: 'P_ADDRESS',
  address2: 'P_ADDRESS_2',
  address_2: 'P_ADDRESS_2',
  addressline2: 'P_ADDRESS_2',
  address_line_2: 'P_ADDRESS_2',
  city: 'P_CITY',
  town: 'P_CITY',
  state: 'P_STATE',
  stateprovince: 'P_STATE',
  state_province: 'P_STATE',
  province: 'P_STATE',
  zip: 'P_ZIP_CODE',
  zipcode: 'P_ZIP_CODE',
  zip_code: 'P_ZIP_CODE',
  postalcode: 'P_ZIP_CODE',
  postal_code: 'P_ZIP_CODE',
  postcode: 'P_ZIP_CODE',
  post_code: 'P_ZIP_CODE',
  country: 'P_COUNTRY',
  countrycode: 'P_COUNTRY',
  country_code: 'P_COUNTRY',
  cardnumber: 'P_CARD_NUMBER',
  card_number: 'P_CARD_NUMBER',
  creditcard: 'P_CARD_NUMBER',
  credit_card: 'P_CARD_NUMBER',
  ccnumber: 'P_CARD_NUMBER',
  cc_number: 'P_CARD_NUMBER',
  cardnum: 'P_CARD_NUMBER',
  pan: 'P_CARD_NUMBER',
  cardname: 'P_CARD_NAME',
  card_name: 'P_CARD_NAME',
  nameoncard: 'P_CARD_NAME',
  name_on_card: 'P_CARD_NAME',
  cardholdername: 'P_CARD_NAME',
  cardholder_name: 'P_CARD_NAME',
  expmonth: 'P_CARD_EXP_MONTH',
  exp_month: 'P_CARD_EXP_MONTH',
  expirymonth: 'P_CARD_EXP_MONTH',
  expiry_month: 'P_CARD_EXP_MONTH',
  expyear: 'P_CARD_EXP_YEAR',
  exp_year: 'P_CARD_EXP_YEAR',
  expiryyear: 'P_CARD_EXP_YEAR',
  expiry_year: 'P_CARD_EXP_YEAR',
  cvv: 'P_CVV',
  cvc: 'P_CVV',
  cvv2: 'P_CVV',
  csc: 'P_CVV',
  securitycode: 'P_CVV',
  security_code: 'P_CVV',
  ssn: 'P_SSN',
  socialsecuritynumber: 'P_SSN',
  social_security_number: 'P_SSN',
  dateofbirth: 'P_DATE_OF_BIRTH',
  date_of_birth: 'P_DATE_OF_BIRTH',
  dob: 'P_DATE_OF_BIRTH',
  birthday: 'P_DATE_OF_BIRTH',
  birthdate: 'P_DATE_OF_BIRTH',
  birth_date: 'P_DATE_OF_BIRTH',
  searchquery: 'P_SEARCH_QUERY',
  search_query: 'P_SEARCH_QUERY',
  searchterm: 'P_SEARCH_QUERY',
  search_term: 'P_SEARCH_QUERY',
  q: 'P_SEARCH_QUERY',
  keyword: 'P_SEARCH_QUERY',
  keywords: 'P_SEARCH_QUERY',
  customerid: 'P_CUSTOMER_ID',
  customer_id: 'P_CUSTOMER_ID',
  accountid: 'P_ACCOUNT_ID',
  account_id: 'P_ACCOUNT_ID',
  recipientname: 'P_RECIPIENT_NAME',
  recipient_name: 'P_RECIPIENT_NAME',
  recipientemail: 'P_RECIPIENT_EMAIL',
  recipient_email: 'P_RECIPIENT_EMAIL',
  company: 'P_COMPANY',
  companyname: 'P_COMPANY',
  company_name: 'P_COMPANY',
  organization: 'P_COMPANY',
  organisation: 'P_COMPANY',
  couponcode: 'P_COUPON_CODE',
  coupon_code: 'P_COUPON_CODE',
  coupon: 'P_COUPON_CODE',
  promocode: 'P_PROMO_CODE',
  promo_code: 'P_PROMO_CODE',
  discountcode: 'P_DISCOUNT_CODE',
  discount_code: 'P_DISCOUNT_CODE',
};

const VALUE_PATTERNS: { pattern: RegExp; variable: string; minLength?: number }[] = [
  { pattern: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, variable: 'P_EMAIL' },
  { pattern: /^\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}$/, variable: 'P_CARD_NUMBER' },
];

const FRAMEWORK_DYNAMIC_FIELD_NAMES = new Set([
  '__viewstate', '__viewstategenerator', '__eventvalidation',
  '__requestverificationtoken', '__previouspage', '__viewstateencrypted',
  '__eventtarget', '__eventargument',
  'csrfmiddlewaretoken', 'csrftoken',
  'authenticity_token',
  '_token', 'xsrf-token',
  '_csrf',
  '_wpnonce', 'wp_nonce', '_wp_http_referer',
  'form_build_id', 'form_token', 'form_id',
  'form_key',
  'icsid', 'icstatenum', 'icactionprompt', 'icaction',
  'swec', 'swerowid', 'swerowids', 'swefi', 'swevlc',
  'sysparm_ck', 'sysparm_transaction_scope', 'x-usertoken',
  'javax.faces.viewstate', 'javax.faces.clientwindow',
  'icx_ticket',
  'com.salesforce.visualforce.viewstateid',
  'com.salesforce.visualforce.viewstateversion',
  'com.salesforce.visualforce.viewstatemac',
  'jsessionid', 'phpsessid', 'asp.net_sessionid',
  'connect.sid', 'laravel_session', '_rails_session', 'sessionid',
]);

const SKIP_VALUES = new Set([
  'true', 'false', 'null', 'undefined', 'none', 'yes', 'no',
  'on', 'off', '0', '1', '',
]);

const FUNCTIONAL_FIELD_NAMES = new Set([
  'page', 'pagenumber', 'page_number', 'pagenum', 'pageindex', 'page_index',
  'offset', 'limit', 'pagesize', 'page_size', 'perpage', 'per_page', 'size',
  'sortby', 'sort_by', 'sort', 'orderby', 'order_by',
  'sortorder', 'sort_order', 'sortdir', 'sort_dir', 'direction', 'order',
  'filter', 'filterby', 'filter_by', 'filtertype', 'filter_type',
  'category', 'categoryid', 'category_id', 'catid', 'cat_id',
  'departmentid', 'department_id', 'storeid', 'store_id',
  'locationid', 'location_id', 'warehouseid', 'warehouse_id',
  'startdate', 'start_date', 'fromdate', 'from_date', 'datefrom', 'date_from',
  'enddate', 'end_date', 'todate', 'to_date', 'dateto', 'date_to',
  'date', 'eventdate', 'event_date', 'deliverydate', 'delivery_date',
  'shippingdate', 'shipping_date', 'checkin', 'check_in', 'checkout',
  'checkindate', 'check_in_date', 'checkoutdate', 'checkout_date', 'check_out_date',
  'shippingmethod', 'shipping_method', 'paymentmethod', 'payment_method',
  'paymenttype', 'payment_type',
  'currency', 'currencycode', 'currency_code',
  'language', 'lang', 'locale',
  'comment', 'comments', 'message', 'note', 'notes', 'description',
  'name', 'search', 'query',
  'quantity', 'qty', 'amount', 'price', 'total', 'subtotal', 'sub_total',
  'discount', 'tax', 'fee',
  'productid', 'product_id', 'productcode', 'product_code',
  'sku', 'skuid', 'sku_id', 'itemid', 'item_id', 'itemcode', 'item_code',
  'orderid', 'order_id', 'ordernumber', 'order_number',
  'invoiceid', 'invoice_id', 'invoicenumber', 'invoice_number',
  'region', 'street', 'fax', 'faxnumber', 'fax_number',
  'cardcode', 'card_code',
  'format', 'type', 'status', 'action', 'mode', 'view', 'tab',
]);

function isFrameworkDynamicField(name: string): boolean {
  return FRAMEWORK_DYNAMIC_FIELD_NAMES.has(name.toLowerCase().trim());
}

function isFunctionalField(name: string): boolean {
  return FUNCTIONAL_FIELD_NAMES.has(normalizeFieldName(name));
}

function normalizeFieldName(name: string): string {
  return name.toLowerCase().replace(/[-\s.[\]]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
}

function getVariableName(fieldName: string): string | null {
  const normalized = normalizeFieldName(fieldName);
  return CREDENTIAL_FIELD_NAMES[normalized] || PII_FIELD_NAMES[normalized] || null;
}

function detectValuePattern(value: string): string | null {
  if (!value || value.length < 3) return null;
  for (const { pattern, variable, minLength } of VALUE_PATTERNS) {
    if (minLength && value.length < minLength) continue;
    if (pattern.test(value)) return variable;
  }
  return null;
}

function extractFormParams(entry: HarEntry): { name: string; value: string }[] {
  const params: { name: string; value: string }[] = [];

  if (!entry.postData) return params;

  if (entry.postData.params) {
    for (const p of entry.postData.params) {
      if (p.name && p.value !== undefined) {
        params.push({ name: p.name, value: p.value });
      }
    }
  }

  if (entry.postData.text && entry.postData.mimeType) {
    const mime = entry.postData.mimeType.toLowerCase();

    if (mime.includes('application/json')) {
      try {
        const json = JSON.parse(entry.postData.text);
        extractJsonFields(json, '', params);
      } catch {}
    }

    if (mime.includes('application/x-www-form-urlencoded') && !entry.postData.params?.length) {
      try {
        const sp = new URLSearchParams(entry.postData.text);
        sp.forEach((val, key) => {
          params.push({ name: key, value: val });
        });
      } catch {}
    }
  }

  return params;
}

function extractJsonFields(obj: any, prefix: string, params: { name: string; value: string }[], depth: number = 0): void {
  if (depth > 5 || !obj || typeof obj !== 'object') return;

  if (Array.isArray(obj)) {
    for (let i = 0; i < obj.length && i < 20; i++) {
      const item = obj[i];
      if (typeof item === 'string') {
        params.push({ name: prefix || `item_${i}`, value: item });
      } else if (typeof item === 'object' && item !== null) {
        extractJsonFields(item, prefix, params, depth + 1);
      }
    }
    return;
  }

  for (const [key, val] of Object.entries(obj)) {
    const fieldName = prefix ? `${prefix}.${key}` : key;
    if (typeof val === 'string') {
      params.push({ name: fieldName, value: val });
    } else if (typeof val === 'number') {
      params.push({ name: fieldName, value: String(val) });
    } else if (typeof val === 'object' && val !== null) {
      extractJsonFields(val, fieldName, params, depth + 1);
    }
  }
}

function extractQueryParams(entry: HarEntry): { name: string; value: string }[] {
  const params: { name: string; value: string }[] = [];
  if (entry.url.query) {
    try {
      const sp = new URLSearchParams(entry.url.query);
      sp.forEach((val, key) => {
        params.push({ name: key, value: val });
      });
    } catch {}
  }
  return params;
}

function extractApiKeyHeaders(entry: HarEntry): { variable: string; value: string; fieldName: string }[] {
  const results: { variable: string; value: string; fieldName: string }[] = [];

  for (const h of entry.headers) {
    const lowerName = h.name.toLowerCase();

    if (lowerName === 'x-api-key' || lowerName === 'api-key' || lowerName === 'apikey') {
      if (h.value.length > 8) {
        results.push({ variable: 'P_API_KEY', value: h.value, fieldName: h.name });
      }
    }
  }

  return results;
}

function shouldSkipValue(value: string): boolean {
  if (!value || value.length === 0) return true;
  if (SKIP_VALUES.has(value.toLowerCase())) return true;
  if (value.length > 500) return true;
  return false;
}

function getLeafFieldName(fieldName: string): string {
  const parts = fieldName.split('.');
  return parts[parts.length - 1];
}

export function detectParameterizations(entries: HarEntry[], correlatedValues?: string[]): ParameterizationOutput {
  const correlated = new Set(correlatedValues || []);
  const variableMap = new Map<string, { variable: string; originalValue: string; occurrences: ParameterizationOccurrence[] }>();

  function addToMap(variable: string, value: string, occurrence: ParameterizationOccurrence) {
    const key = `${variable}::${value}`;
    if (!variableMap.has(key)) {
      variableMap.set(key, { variable, originalValue: value, occurrences: [] });
    }
    const existing = variableMap.get(key)!;
    const dup = existing.occurrences.some(
      o => o.requestIndex === occurrence.requestIndex && o.fieldName === occurrence.fieldName && o.location === occurrence.location
    );
    if (!dup) {
      existing.occurrences.push(occurrence);
    }
  }

  for (const entry of entries) {
    const allParams = [
      ...extractFormParams(entry),
      ...extractQueryParams(entry),
    ];

    for (const param of allParams) {
      const leafName = getLeafFieldName(param.name);
      if (isFrameworkDynamicField(leafName)) continue;
      if (isFunctionalField(leafName)) continue;
      if (shouldSkipValue(param.value)) continue;
      if (correlated.has(param.value)) continue;

      const varName = getVariableName(leafName);

      if (varName) {
        const location: ParameterizationOccurrence['location'] =
          extractFormParams(entry).some(p => p.name === param.name && p.value === param.value) ? 'body' : 'param';
        addToMap(varName, param.value, { requestIndex: entry.index, location, fieldName: param.name });
        continue;
      }

      const patternVar = detectValuePattern(param.value);
      if (patternVar) {
        const location: ParameterizationOccurrence['location'] =
          extractFormParams(entry).some(p => p.name === param.name && p.value === param.value) ? 'body' : 'param';
        addToMap(patternVar, param.value, { requestIndex: entry.index, location, fieldName: param.name });
      }
    }

    const apiKeyHeaders = extractApiKeyHeaders(entry);
    for (const auth of apiKeyHeaders) {
      if (correlated.has(auth.value)) continue;
      addToMap(auth.variable, auth.value, { requestIndex: entry.index, location: 'header', fieldName: auth.fieldName });
    }
  }

  const valueOccurrences = new Map<string, { entries: Set<number>; fieldName: string; locations: ParameterizationOccurrence[] }>();

  for (const entry of entries) {
    const allParams = [
      ...extractFormParams(entry),
      ...extractQueryParams(entry),
    ];

    for (const param of allParams) {
      if (shouldSkipValue(param.value)) continue;
      if (param.value.length < 2) continue;
      const leafName = getLeafFieldName(param.name);
      if (isFrameworkDynamicField(leafName)) continue;
      if (isFunctionalField(leafName)) continue;
      if (getVariableName(leafName)) continue;
      if (detectValuePattern(param.value)) continue;
      if (correlated.has(param.value)) continue;

      const key = param.value;
      if (!valueOccurrences.has(key)) {
        valueOccurrences.set(key, { entries: new Set(), fieldName: param.name, locations: [] });
      }

      const record = valueOccurrences.get(key)!;
      record.entries.add(entry.index);

      const location: ParameterizationOccurrence['location'] =
        extractFormParams(entry).some(p => p.name === param.name && p.value === param.value) ? 'body' : 'param';
      const dup = record.locations.some(
        o => o.requestIndex === entry.index && o.fieldName === param.name && o.location === location
      );
      if (!dup) {
        record.locations.push({ requestIndex: entry.index, location, fieldName: param.name });
      }
    }
  }

  valueOccurrences.forEach((record, value) => {
    if (record.entries.size < 2) return;

    if (/^\d+(\.\d+)?$/.test(value)) return;

    const leafName = getLeafFieldName(record.fieldName);
    if (isFunctionalField(leafName)) return;

    const varKey = `P_${leafName.toUpperCase().replace(/[^A-Z0-9]/g, '_')}`;
    const mapKey = `${varKey}::${value}`;

    if (!variableMap.has(mapKey)) {
      variableMap.set(mapKey, {
        variable: varKey,
        originalValue: value,
        occurrences: record.locations,
      });
    }
  });

  const byVariable = new Map<string, { variable: string; originalValue: string; occurrences: ParameterizationOccurrence[] }[]>();
  for (const entry of variableMap.values()) {
    if (entry.occurrences.length === 0) continue;
    if (!byVariable.has(entry.variable)) {
      byVariable.set(entry.variable, []);
    }
    const existing = byVariable.get(entry.variable)!;
    const sameValue = existing.find(e => e.originalValue === entry.originalValue);
    if (sameValue) {
      for (const occ of entry.occurrences) {
        const dup = sameValue.occurrences.some(
          o => o.requestIndex === occ.requestIndex && o.fieldName === occ.fieldName && o.location === occ.location
        );
        if (!dup) sameValue.occurrences.push(occ);
      }
    } else {
      existing.push({ variable: entry.variable, originalValue: entry.originalValue, occurrences: [...entry.occurrences] });
    }
  }

  const parameterizations: ParameterizationResult[] = [];
  const csvVariables = new Set<string>();
  for (const [varName, entries] of byVariable) {
    csvVariables.add(varName);
    for (const entry of entries) {
      parameterizations.push({
        variable: varName,
        originalValue: entry.originalValue,
        occurrences: entry.occurrences,
      });
    }
  }

  const csvContent = generateCsvContent(parameterizations);

  return { parameterizations, csvContent };
}

const CSV_SAMPLE_DATA: Record<string, string[]> = {
  P_USERNAME: ['user1', 'user2', 'user3', 'user4', 'user5'],
  P_PASSWORD: ['Pass@1234', 'Pass@5678', 'Pass@9012', 'Pass@3456', 'Pass@7890'],
  P_EMAIL: ['user1@testmail.com', 'user2@testmail.com', 'user3@testmail.com', 'user4@testmail.com', 'user5@testmail.com'],
  P_FIRST_NAME: ['John', 'Jane', 'Robert', 'Emily', 'Michael'],
  P_LAST_NAME: ['Smith', 'Johnson', 'Williams', 'Brown', 'Davis'],
  P_FULL_NAME: ['John Smith', 'Jane Johnson', 'Robert Williams', 'Emily Brown', 'Michael Davis'],
  P_PHONE: ['555-0101', '555-0102', '555-0103', '555-0104', '555-0105'],
  P_ADDRESS: ['123 Main St', '456 Oak Ave', '789 Pine Rd', '321 Elm Blvd', '654 Maple Dr'],
  P_ADDRESS_2: ['Apt 1A', 'Suite 200', 'Floor 3', 'Unit B', 'Room 101'],
  P_CITY: ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix'],
  P_STATE: ['NY', 'CA', 'IL', 'TX', 'AZ'],
  P_ZIP_CODE: ['10001', '90001', '60601', '77001', '85001'],
  P_COUNTRY: ['US', 'US', 'US', 'US', 'US'],
  P_CARD_NUMBER: ['4111111111111111', '4222222222222222', '4333333333333333', '4444444444444444', '4555555555555555'],
  P_CARD_NAME: ['John Smith', 'Jane Johnson', 'Robert Williams', 'Emily Brown', 'Michael Davis'],
  P_CARD_EXP_MONTH: ['01', '03', '06', '09', '12'],
  P_CARD_EXP_YEAR: ['2027', '2028', '2027', '2028', '2029'],
  P_CVV: ['123', '456', '789', '012', '345'],
  P_COMPANY: ['Acme Corp', 'Global Inc', 'Tech Solutions', 'DataFlow Ltd', 'CloudPeak'],
  P_SSN: ['123-45-6789', '234-56-7890', '345-67-8901', '456-78-9012', '567-89-0123'],
  P_DATE_OF_BIRTH: ['1990-01-15', '1985-06-22', '1992-11-03', '1988-04-17', '1995-09-28'],
  P_SEARCH_QUERY: ['laptop', 'smartphone', 'headphones', 'tablet', 'monitor'],
  P_CUSTOMER_ID: ['CUST-001', 'CUST-002', 'CUST-003', 'CUST-004', 'CUST-005'],
  P_ACCOUNT_ID: ['ACC-001', 'ACC-002', 'ACC-003', 'ACC-004', 'ACC-005'],
  P_RECIPIENT_NAME: ['John Smith', 'Jane Doe', 'Bob Wilson', 'Alice Brown', 'Tom Davis'],
  P_RECIPIENT_EMAIL: ['recv1@test.com', 'recv2@test.com', 'recv3@test.com', 'recv4@test.com', 'recv5@test.com'],
  P_COUPON_CODE: ['SAVE5', 'SAVE10', 'WELCOME', 'VIP15', 'FIRST'],
  P_PROMO_CODE: ['PROMO10', 'PROMO20', 'SUMMER', 'WINTER', 'FLASH'],
  P_DISCOUNT_CODE: ['SAVE5', 'SAVE10', 'WELCOME', 'VIP15', 'FIRST'],
};

function generateCsvContent(parameterizations: ParameterizationResult[]): string {
  if (parameterizations.length === 0) return '';

  const uniqueVars: string[] = [];
  const seen = new Set<string>();
  for (const p of parameterizations) {
    if (!seen.has(p.variable)) {
      seen.add(p.variable);
      uniqueVars.push(p.variable);
    }
  }

  const lines: string[] = [uniqueVars.join(',')];

  for (let row = 0; row < 5; row++) {
    const values = uniqueVars.map(varName => {
      const samples = CSV_SAMPLE_DATA[varName];
      if (samples && samples[row]) {
        return escapeCsvValue(samples[row]);
      }
      const first = parameterizations.find(p => p.variable === varName);
      return escapeCsvValue(`${first?.originalValue || varName}_${row + 1}`);
    });
    lines.push(values.join(','));
  }

  return lines.join('\n');
}

function escapeCsvValue(value: string): string {
  if (value.includes(',') || value.includes('"') || value.includes('\n')) {
    return '"' + value.replace(/"/g, '""') + '"';
  }
  return value;
}
