import type { HarEntry, HarHeader } from './har-parser';

export interface CorrelationResult {
  variable: string;
  extractorType: 'json' | 'regex' | 'header' | 'boundary' | 'xpath' | 'css';
  pattern: string;
  leftBoundary?: string;
  rightBoundary?: string;
  cssSelector?: string;
  cssAttribute?: string;
  sourceRequest: number;
  targetRequests: number[];
  originalValue: string;
}

interface CandidateValue {
  value: string;
  sourceIndex: number;
  extractorType: 'json' | 'regex' | 'header' | 'boundary' | 'xpath' | 'css';
  pattern: string;
  leftBoundary?: string;
  rightBoundary?: string;
  cssSelector?: string;
  cssAttribute?: string;
  context: string;
}

const UUID_REGEX = /\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b/gi;
const JWT_REGEX = /eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g;
const CSRF_HEX_REGEX = /\b[0-9a-f]{32,128}\b/gi;
const NUMERIC_ID_REGEX = /\b\d{4,18}\b/g;
const BASE64_TOKEN_REGEX = /(?:[A-Za-z0-9+/]{4}){6,}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?/g;
const OAUTH_BEARER_REGEX = /Bearer\s+([A-Za-z0-9._~+/=-]{20,})/g;

const KNOWN_DYNAMIC_HEADERS = [
  'set-cookie',
  'location',
  'x-csrf-token',
  'x-xsrf-token',
  'authorization',
  'x-auth-token',
  'x-request-id',
  'x-correlation-id',
];

interface FrameworkFieldInfo {
  variable: string;
  framework: string;
}

const FRAMEWORK_DYNAMIC_FIELD_NAMES: Record<string, FrameworkFieldInfo> = {
  "__viewstate": { variable: "C_viewState", framework: "ASP.NET" },
  "__viewstategenerator": { variable: "C_viewStateGenerator", framework: "ASP.NET" },
  "__eventvalidation": { variable: "C_eventValidation", framework: "ASP.NET" },
  "__requestverificationtoken": { variable: "C_requestVerificationToken", framework: "ASP.NET" },
  "__previouspage": { variable: "C_previousPage", framework: "ASP.NET" },
  "__viewstateencrypted": { variable: "C_viewStateEncrypted", framework: "ASP.NET" },
  "__eventtarget": { variable: "C_eventTarget", framework: "ASP.NET" },
  "__eventargument": { variable: "C_eventArgument", framework: "ASP.NET" },

  "csrfmiddlewaretoken": { variable: "C_csrfMiddlewareToken", framework: "Django" },
  "csrftoken": { variable: "C_csrfToken_django", framework: "Django" },

  "authenticity_token": { variable: "C_authenticityToken", framework: "Rails" },

  "_token": { variable: "C_laravelToken", framework: "Laravel" },
  "xsrf-token": { variable: "C_xsrfToken_laravel", framework: "Laravel" },

  "_csrf": { variable: "C_springCsrf", framework: "Spring" },

  "_wpnonce": { variable: "C_wpNonce", framework: "WordPress" },
  "wp_nonce": { variable: "C_wpNonce", framework: "WordPress" },
  "_wp_http_referer": { variable: "C_wpHttpReferer", framework: "WordPress" },

  "form_build_id": { variable: "C_formBuildId", framework: "Drupal" },
  "form_token": { variable: "C_formToken", framework: "Drupal" },
  "form_id": { variable: "C_formId", framework: "Drupal" },

  "form_key": { variable: "C_formKey", framework: "Magento" },

  "icsid": { variable: "C_icsId", framework: "PeopleSoft" },
  "icstatenum": { variable: "C_icStateNum", framework: "PeopleSoft" },
  "icactionprompt": { variable: "C_icActionPrompt", framework: "PeopleSoft" },
  "icaction": { variable: "C_icAction", framework: "PeopleSoft" },

  "swec": { variable: "C_sweCount", framework: "Siebel" },
  "swerowid": { variable: "C_sweRowId", framework: "Siebel" },
  "swerowids": { variable: "C_sweRowIds", framework: "Siebel" },
  "swefi": { variable: "C_sweFrameId", framework: "Siebel" },
  "swevlc": { variable: "C_sweViewLayoutChecksum", framework: "Siebel" },

  "sysparm_ck": { variable: "C_sysparmCk", framework: "ServiceNow" },
  "sysparm_transaction_scope": { variable: "C_sysparmTransactionScope", framework: "ServiceNow" },
  "x-usertoken": { variable: "C_serviceNowUserToken", framework: "ServiceNow" },

  "javax.faces.viewstate": { variable: "C_jsfViewState", framework: "JSF" },
  "javax.faces.clientwindow": { variable: "C_jsfClientWindow", framework: "JSF" },

  "icx_ticket": { variable: "C_icxTicket", framework: "Oracle EBS" },

  "com.salesforce.visualforce.viewstateid": { variable: "C_sfViewStateId", framework: "Salesforce" },
  "com.salesforce.visualforce.viewstateversion": { variable: "C_sfViewStateVersion", framework: "Salesforce" },
  "com.salesforce.visualforce.viewstatemac": { variable: "C_sfViewStateMAC", framework: "Salesforce" },

  "jsessionid": { variable: "C_jSessionId", framework: "Java" },
  "phpsessid": { variable: "C_phpSessionId", framework: "PHP" },
  "asp.net_sessionid": { variable: "C_aspNetSessionId", framework: "ASP.NET" },
  ".aspnetcore.antiforgery": { variable: "C_aspNetCoreAntiforgery", framework: "ASP.NET Core" },
  "connect.sid": { variable: "C_connectSid", framework: "Express/Node.js" },
  "laravel_session": { variable: "C_laravelSession", framework: "Laravel" },
  "_rails_session": { variable: "C_railsSession", framework: "Rails" },
  "sessionid": { variable: "C_djangoSessionId", framework: "Django" },
};

function isFrameworkField(name: string): FrameworkFieldInfo | null {
  const lower = name.toLowerCase().trim();
  const exact = FRAMEWORK_DYNAMIC_FIELD_NAMES[lower];
  if (exact) return exact;
  if (lower.startsWith('.aspnetcore.antiforgery')) {
    return { variable: "C_aspNetCoreAntiforgery", framework: "ASP.NET Core" };
  }
  if (lower.startsWith('wordpress_logged_in')) {
    return { variable: "C_wpLoggedInCookie", framework: "WordPress" };
  }
  return null;
}

const STATIC_VALUES = new Set([
  'true', 'false', 'null', 'undefined', 'none', 'yes', 'no',
  'application/json', 'text/html', 'text/plain', 'utf-8', 'gzip',
  'keep-alive', 'close', 'no-cache', 'no-store', 'max-age=0',
]);

function isDynamicCandidate(value: string): boolean {
  if (value.length < 8) return false;
  if (STATIC_VALUES.has(value.toLowerCase())) return false;
  if (/^https?:\/\//.test(value)) return false;
  if (/^\d+\.\d+\.\d+/.test(value) && value.length < 20) return false;
  return true;
}

function matchesKnownPattern(value: string): string | null {
  UUID_REGEX.lastIndex = 0;
  if (UUID_REGEX.test(value)) { UUID_REGEX.lastIndex = 0; return 'uuid'; }
  JWT_REGEX.lastIndex = 0;
  if (JWT_REGEX.test(value)) { JWT_REGEX.lastIndex = 0; return 'jwt'; }
  CSRF_HEX_REGEX.lastIndex = 0;
  if (CSRF_HEX_REGEX.test(value) && value.length >= 32) { CSRF_HEX_REGEX.lastIndex = 0; return 'csrf_hex'; }
  BASE64_TOKEN_REGEX.lastIndex = 0;
  if (BASE64_TOKEN_REGEX.test(value) && value.length >= 24) { BASE64_TOKEN_REGEX.lastIndex = 0; return 'base64_token'; }
  return null;
}

function extractJsonLeafValues(text: string, sourceIndex: number): CandidateValue[] {
  const candidates: CandidateValue[] = [];
  try {
    const obj = JSON.parse(text);
    walkJson(obj, '$', sourceIndex, candidates);
  } catch {
  }
  return candidates;
}

function walkJson(obj: any, jsonPath: string, sourceIndex: number, candidates: CandidateValue[]): void {
  if (obj === null || obj === undefined) return;

  if (typeof obj === 'string') {
    if (isDynamicCandidate(obj) || matchesKnownPattern(obj)) {
      candidates.push({
        value: obj,
        sourceIndex,
        extractorType: 'json',
        pattern: jsonPath,
        context: deriveContext(jsonPath, obj),
      });
    }
    return;
  }

  if (typeof obj === 'number') {
    const str = String(obj);
    if (str.length >= 4 && NUMERIC_ID_REGEX.test(str)) {
      NUMERIC_ID_REGEX.lastIndex = 0;
      candidates.push({
        value: str,
        sourceIndex,
        extractorType: 'json',
        pattern: jsonPath,
        context: deriveContext(jsonPath, str),
      });
    }
    return;
  }

  if (Array.isArray(obj)) {
    for (let i = 0; i < obj.length && i < 50; i++) {
      walkJson(obj[i], `${jsonPath}[${i}]`, sourceIndex, candidates);
    }
    return;
  }

  if (typeof obj === 'object') {
    for (const key of Object.keys(obj)) {
      walkJson(obj[key], `${jsonPath}.${key}`, sourceIndex, candidates);
    }
  }
}

function extractHtmlHiddenFields(text: string, sourceIndex: number): CandidateValue[] {
  const candidates: CandidateValue[] = [];
  const inputRegex = /<input\b[^>]*>/gi;
  let match;

  while ((match = inputRegex.exec(text)) !== null) {
    const tag = match[0];
    const typeMatch = tag.match(/type\s*=\s*["']([^"']+)["']/i);
    if (!typeMatch || typeMatch[1].toLowerCase() !== 'hidden') continue;

    const nameMatch = tag.match(/name\s*=\s*["']([^"']+)["']/i);
    const valueMatch = tag.match(/value\s*=\s*["']([^"']*)["']/i);
    if (nameMatch && valueMatch && valueMatch[1].length >= 8) {
      const fieldName = nameMatch[1];
      const escapedFieldName = fieldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      candidates.push({
        value: valueMatch[1],
        sourceIndex,
        extractorType: 'css',
        pattern: `input[name="${escapedFieldName}"]`,
        cssSelector: `input[name="${fieldName}"]`,
        cssAttribute: 'value',
        context: fieldName,
      });
    }
  }

  const metaRegex = /<meta\b[^>]*>/gi;
  while ((match = metaRegex.exec(text)) !== null) {
    const tag = match[0];
    const nameMatch = tag.match(/name\s*=\s*["'](csrf[^"']*|token[^"']*|authenticity[^"']*|_?csrf[^"']*)["']/i);
    const contentMatch = tag.match(/content\s*=\s*["']([^"']+)["']/i);
    if (nameMatch && contentMatch && contentMatch[1].length >= 8) {
      const metaName = nameMatch[1];
      candidates.push({
        value: contentMatch[1],
        sourceIndex,
        extractorType: 'css',
        pattern: `meta[name="${metaName}"]`,
        cssSelector: `meta[name="${metaName}"]`,
        cssAttribute: 'content',
        context: metaName,
      });
    }
  }

  const selectRegex = /<select\b[^>]*name\s*=\s*["']([^"']+)["'][^>]*>[\s\S]*?<option\b[^>]*selected[^>]*value\s*=\s*["']([^"']+)["']/gi;
  while ((match = selectRegex.exec(text)) !== null) {
    if (match[2] && match[2].length >= 4) {
      candidates.push({
        value: match[2],
        sourceIndex,
        extractorType: 'css',
        pattern: `select[name="${match[1]}"] option[selected]`,
        cssSelector: `select[name="${match[1]}"] option[selected]`,
        cssAttribute: 'value',
        context: match[1],
      });
    }
  }

  return candidates;
}

function extractXmlValues(text: string, sourceIndex: number): CandidateValue[] {
  const candidates: CandidateValue[] = [];
  const seen = new Set<string>();

  const tokenTags = [
    'token', 'csrf', 'csrfToken', 'sessionId', 'sessionID',
    'requestToken', 'accessToken', 'refreshToken', 'nonce',
    'transactionId', 'correlationId', 'requestId', 'messageId',
    'ticketId', 'authToken', 'securityToken', 'verificationToken',
  ];

  for (const tagName of tokenTags) {
    const tagRegex = new RegExp(`<${tagName}[^>]*>([^<]+)</${tagName}>`, 'gi');
    let match;
    while ((match = tagRegex.exec(text)) !== null) {
      const val = match[1].trim();
      if (val.length >= 8 && !seen.has(val)) {
        seen.add(val);
        candidates.push({
          value: val,
          sourceIndex,
          extractorType: 'xpath',
          pattern: `//${tagName}/text()`,
          context: tagName.toLowerCase(),
        });
      }
    }
  }

  const attrTokenRegex = /<(\w[\w:-]*)\b[^>]*([\w:-]+)=["']([^"']{8,})["'][^>]*>/gi;
  let attrMatch;
  while ((attrMatch = attrTokenRegex.exec(text)) !== null) {
    const attrName = attrMatch[2].toLowerCase();
    const val = attrMatch[3];
    if (/(?:id|token|session|nonce|key|csrf|auth)/i.test(attrName) && !seen.has(val) && isDynamicCandidate(val)) {
      seen.add(val);
      candidates.push({
        value: val,
        sourceIndex,
        extractorType: 'xpath',
        pattern: `//${attrMatch[1]}/@${attrMatch[2]}`,
        context: attrMatch[1].toLowerCase(),
      });
    }
  }

  return candidates;
}

function extractHeaderValues(headers: HarHeader[], sourceIndex: number): CandidateValue[] {
  const candidates: CandidateValue[] = [];

  for (const header of headers) {
    const lowerName = header.name.toLowerCase();

    if (lowerName === 'set-cookie') {
      const cookies = header.value.split(/;\s*/);
      if (cookies.length > 0) {
        const firstPart = cookies[0];
        const eqIdx = firstPart.indexOf('=');
        if (eqIdx > 0) {
          const cookieName = firstPart.substring(0, eqIdx);
          const cookieValue = firstPart.substring(eqIdx + 1);
          if (cookieValue.length >= 8) {
            candidates.push({
              value: cookieValue,
              sourceIndex,
              extractorType: 'header',
              pattern: `Set-Cookie: ${cookieName}=(.+?)(?:;|$)`,
              context: `cookie_${cookieName}`,
            });
          }
        }
      }
    } else if (lowerName === 'location') {
      const locUrl = header.value;
      const paramMatches = locUrl.match(/[?&]([^=]+)=([^&]+)/g);
      if (paramMatches) {
        for (const pm of paramMatches) {
          const parts = pm.replace(/^[?&]/, '').split('=');
          if (parts.length === 2 && parts[1].length >= 8) {
            candidates.push({
              value: parts[1],
              sourceIndex,
              extractorType: 'header',
              pattern: `Location: .*[?&]${parts[0]}=([^&]+)`,
              context: `redirect_${parts[0]}`,
            });
          }
        }
      }
    } else if (KNOWN_DYNAMIC_HEADERS.includes(lowerName) && lowerName !== 'set-cookie' && lowerName !== 'location') {
      if (header.value.length >= 8) {
        candidates.push({
          value: header.value,
          sourceIndex,
          extractorType: 'header',
          pattern: `${header.name}: (.+)`,
          context: lowerName.replace(/[^a-z]/g, '_'),
        });
      }
    }
  }

  return candidates;
}

function extractPatternMatchValues(text: string, sourceIndex: number): CandidateValue[] {
  const candidates: CandidateValue[] = [];
  const seen = new Set<string>();

  const patterns: { regex: RegExp; context: string; group?: number }[] = [
    { regex: UUID_REGEX, context: 'uuid' },
    { regex: JWT_REGEX, context: 'auth_token' },
    { regex: CSRF_HEX_REGEX, context: 'csrf_token' },
    { regex: OAUTH_BEARER_REGEX, context: 'bearer_token', group: 1 },
  ];

  for (const { regex, context, group } of patterns) {
    regex.lastIndex = 0;
    let match;
    while ((match = regex.exec(text)) !== null) {
      const val = group !== undefined && match[group] ? match[group] : match[0];
      if (!seen.has(val) && val.length >= 8) {
        seen.add(val);

        const matchStart = group !== undefined && match[group] ? text.indexOf(val, match.index) : match.index;
        const leftCtx = text.substring(Math.max(0, matchStart - 40), matchStart);
        const rightCtx = text.substring(matchStart + val.length, Math.min(text.length, matchStart + val.length + 20));

        let extractorType: CandidateValue['extractorType'] = 'regex';
        let leftBoundary: string | undefined;
        let rightBoundary: string | undefined;

        const delimiterSearch = /["=:]\s*"?$/;
        const delimMatch = delimiterSearch.exec(leftCtx);
        if (delimMatch) {
          const keyStart = leftCtx.lastIndexOf('"', delimMatch.index - 1);
          const startPos = keyStart >= 0 && keyStart >= delimMatch.index - 40 ? keyStart : Math.max(0, delimMatch.index - 15);
          const lb = leftCtx.substring(startPos);
          const rbEnd = rightCtx.search(/[&";\s<>,\]}\n]/);
          const rb = rbEnd >= 0 ? rightCtx.substring(0, rbEnd + 1) : rightCtx.substring(0, 1) || '"';
          if (lb.length >= 1 && rb.length >= 1) {
            extractorType = 'boundary';
            leftBoundary = lb;
            rightBoundary = rb;
          }
        }

        let regexPattern = regex.source;
        if (extractorType === 'regex') {
          if (!regexPattern.includes('(')) {
            regexPattern = `(${regexPattern.replace(/^\\b/, '').replace(/\\b$/, '')})`;
          }
        }

        candidates.push({
          value: val,
          sourceIndex,
          extractorType,
          pattern: regexPattern,
          leftBoundary,
          rightBoundary,
          context,
        });
      }
      if (seen.size > 200) break;
    }
  }

  return candidates;
}

function deriveContext(jsonPath: string, value: string): string {
  const lastSegment = jsonPath.split('.').pop() || '';
  const clean = lastSegment.replace(/\[\d+\]$/, '').toLowerCase();

  if (/token/i.test(clean)) return 'token';
  if (/csrf|xsrf/i.test(clean)) return 'csrf_token';
  if (/session/i.test(clean)) return 'session_id';
  if (/auth/i.test(clean)) return 'auth_token';
  if (/access.?token/i.test(clean)) return 'access_token';
  if (/refresh.?token/i.test(clean)) return 'refresh_token';
  if (/nonce/i.test(clean)) return 'nonce';
  if (/cursor|next.?page|page.?token/i.test(clean)) return 'pagination_cursor';
  if (/redirect|location|return.?url/i.test(clean)) return 'redirect_url';
  if (/id$/i.test(clean)) return clean;
  JWT_REGEX.lastIndex = 0;
  if (JWT_REGEX.test(value)) { JWT_REGEX.lastIndex = 0; return 'auth_token'; }
  UUID_REGEX.lastIndex = 0;
  if (UUID_REGEX.test(value)) { UUID_REGEX.lastIndex = 0; return 'uuid'; }

  return clean || 'dynamic_value';
}

function generateVariableName(context: string, usedNames: Set<string>): string {
  const base = context
    .replace(/[^a-zA-Z0-9_]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '')
    .toLowerCase();

  const name = 'C_' + (base || 'dynamic_value');

  if (!usedNames.has(name)) {
    usedNames.add(name);
    return name;
  }

  let counter = 1;
  while (usedNames.has(`${name}_${counter}`)) {
    counter++;
  }
  const finalName = `${name}_${counter}`;
  usedNames.add(finalName);
  return finalName;
}

const TOKEN_BOUNDARY = /[^a-zA-Z0-9_\-+/]/;

function isTokenBoundaryMatch(text: string, value: string): boolean {
  let startIdx = 0;
  while (true) {
    const idx = text.indexOf(value, startIdx);
    if (idx === -1) return false;

    const charBefore = idx > 0 ? text[idx - 1] : '';
    const charAfter = idx + value.length < text.length ? text[idx + value.length] : '';

    const leftOk = idx === 0 || TOKEN_BOUNDARY.test(charBefore);
    const rightOk = idx + value.length >= text.length || TOKEN_BOUNDARY.test(charAfter);

    if (leftOk && rightOk) return true;

    startIdx = idx + 1;
  }
}

function searchInRequest(entry: HarEntry, value: string): boolean {
  const encoded = encodeURIComponent(value);
  const hasEncoded = encoded !== value;
  const isShort = value.length < 12;

  const matchFn = isShort ? isTokenBoundaryMatch : (text: string, val: string) => text.includes(val);

  if (matchFn(entry.url.full, value) || (hasEncoded && matchFn(entry.url.full, encoded))) return true;
  if (entry.url.query && (matchFn(entry.url.query, value) || (hasEncoded && matchFn(entry.url.query, encoded)))) return true;

  for (const h of entry.headers) {
    if (matchFn(h.value, value)) return true;
  }

  if (entry.postData) {
    if (entry.postData.text) {
      if (matchFn(entry.postData.text, value) || (hasEncoded && matchFn(entry.postData.text, encoded))) return true;
    }
    if (entry.postData.params) {
      for (const p of entry.postData.params) {
        if (p.value && (matchFn(p.value, value) || (hasEncoded && matchFn(p.value, encoded)))) return true;
      }
    }
  }

  return false;
}

const MAX_CANDIDATES = 2000;
const MAX_CORRELATIONS = 500;

export function detectCorrelations(entries: HarEntry[]): CorrelationResult[] {
  const allCandidates: CandidateValue[] = [];

  for (const entry of entries) {
    if (allCandidates.length >= MAX_CANDIDATES) break;
    const idx = entry.index;

    if (entry.responseBodyText) {
      const mime = entry.responseMimeType.toLowerCase();
      if (mime.includes('json')) {
        allCandidates.push(...extractJsonLeafValues(entry.responseBodyText, idx));
      } else if (mime.includes('html')) {
        allCandidates.push(...extractHtmlHiddenFields(entry.responseBodyText, idx));
      } else if (mime.includes('xml') || mime.includes('soap')) {
        allCandidates.push(...extractXmlValues(entry.responseBodyText, idx));
      }
      if (!mime.includes('json') && entry.responseBodyText.trimStart().startsWith('{')) {
        allCandidates.push(...extractJsonLeafValues(entry.responseBodyText, idx));
      }
      allCandidates.push(...extractPatternMatchValues(entry.responseBodyText, idx));
    }

    allCandidates.push(...extractHeaderValues(entry.responseHeaders, idx));
  }

  const uniqueCandidates = new Map<string, CandidateValue>();
  for (const c of allCandidates) {
    const key = `${c.sourceIndex}:${c.value}`;
    if (!uniqueCandidates.has(key)) {
      uniqueCandidates.set(key, c);
    }
  }

  const usedNames = new Set<string>();
  const results: CorrelationResult[] = [];
  const correlatedValues = new Set<string>();

  const sortedCandidates = Array.from(uniqueCandidates.values()).sort((a, b) => a.sourceIndex - b.sourceIndex);

  for (const candidate of sortedCandidates) {
    if (results.length >= MAX_CORRELATIONS) break;
    if (correlatedValues.has(candidate.value)) continue;

    const targetRequests: number[] = [];

    for (const entry of entries) {
      if (entry.index <= candidate.sourceIndex) continue;
      if (searchInRequest(entry, candidate.value)) {
        targetRequests.push(entry.index);
      }
    }

    if (targetRequests.length > 0) {
      correlatedValues.add(candidate.value);
      const variable = generateVariableName(candidate.context, usedNames);

      const result: CorrelationResult = {
        variable,
        extractorType: candidate.extractorType,
        pattern: candidate.pattern,
        sourceRequest: candidate.sourceIndex,
        targetRequests,
        originalValue: candidate.value,
      };
      if (candidate.leftBoundary) result.leftBoundary = candidate.leftBoundary;
      if (candidate.rightBoundary) result.rightBoundary = candidate.rightBoundary;
      if (candidate.cssSelector) result.cssSelector = candidate.cssSelector;
      if (candidate.cssAttribute) result.cssAttribute = candidate.cssAttribute;
      results.push(result);
    }
  }

  results.sort((a, b) => a.sourceRequest - b.sourceRequest);

  const frameworkFieldsSeen = new Map<string, { variable: string; framework: string; firstRequestIndex: number; requestIndices: number[]; value: string; originalFieldName: string }>();

  for (const entry of entries) {
    const params: { name: string; value: string }[] = [];
    if (entry.postData?.params) {
      for (const p of entry.postData.params) {
        if (p.name && p.value) params.push({ name: p.name, value: p.value });
      }
    }
    if (entry.postData?.text && entry.postData.mimeType?.toLowerCase().includes('x-www-form-urlencoded') && !entry.postData.params?.length) {
      try {
        const sp = new URLSearchParams(entry.postData.text);
        sp.forEach((val, key) => params.push({ name: key, value: val }));
      } catch {}
    }

    for (const header of entry.headers) {
      const lowerName = header.name.toLowerCase();
      if (lowerName === 'x-csrf-token' || lowerName === 'x-xsrf-token' || lowerName === 'x-csrftoken' || lowerName === 'x-usertoken') {
        if (header.value && header.value.length >= 8) {
          params.push({ name: lowerName, value: header.value });
        }
      }
      if (lowerName === 'cookie') {
        const cookiePairs = header.value.split(/;\s*/);
        for (const pair of cookiePairs) {
          const eqIdx = pair.indexOf('=');
          if (eqIdx > 0) {
            const cookieName = pair.substring(0, eqIdx).trim();
            const cookieValue = pair.substring(eqIdx + 1).trim();
            if (cookieValue.length >= 8 && isFrameworkField(cookieName)) {
              params.push({ name: cookieName, value: cookieValue });
            }
          }
        }
      }
    }

    for (const param of params) {
      const fieldInfo = isFrameworkField(param.name);
      if (!fieldInfo || !param.value || param.value.length === 0) continue;

      const alreadyCorrelated = correlatedValues.has(param.value) || results.some(
        r => r.originalValue === param.value || r.variable === fieldInfo.variable
      );
      if (alreadyCorrelated) continue;

      const existing = frameworkFieldsSeen.get(fieldInfo.variable);
      if (existing) {
        existing.requestIndices.push(entry.index);
      } else {
        frameworkFieldsSeen.set(fieldInfo.variable, {
          variable: fieldInfo.variable,
          framework: fieldInfo.framework,
          firstRequestIndex: entry.index,
          requestIndices: [entry.index],
          value: param.value,
          originalFieldName: param.name,
        });
      }
    }
  }

  const entryIndices = new Set(entries.map(e => e.index));

  for (const [, data] of frameworkFieldsSeen) {
    if (!usedNames.has(data.variable)) {
      usedNames.add(data.variable);
      const escapedFieldName = data.originalFieldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const extractPattern = `name=["']?${escapedFieldName}["']?[^>]*value=["']([^"']+)["']`;

      let sourceIdx = -1;
      const sortedIndices = Array.from(entryIndices).sort((a, b) => a - b);
      for (const idx of sortedIndices) {
        if (idx >= data.firstRequestIndex) break;
        const entry = entries.find(e => e.index === idx);
        if (entry?.responseBodyText && entry.responseBodyText.includes(data.value)) {
          sourceIdx = idx;
          break;
        }
      }

      if (sourceIdx === -1) {
        for (const idx of sortedIndices) {
          if (idx >= data.firstRequestIndex) break;
          const entry = entries.find(e => e.index === idx);
          if (entry?.responseHeaders?.some(h => h.value.includes(data.value))) {
            sourceIdx = idx;
            break;
          }
        }
      }

      if (sourceIdx === -1) {
        continue;
      }

      results.push({
        variable: data.variable,
        extractorType: 'regex',
        pattern: extractPattern,
        sourceRequest: sourceIdx,
        targetRequests: data.requestIndices,
        originalValue: data.value,
      });
    }
  }

  return results;
}
