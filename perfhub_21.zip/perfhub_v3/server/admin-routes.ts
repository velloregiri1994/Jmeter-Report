import { type Express } from "express";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { db } from "./db";
import { remoteIngestTokens, auditLogs, users } from "@shared/schema";
import { eq, desc, and, gte, lte, sql, inArray } from "drizzle-orm";
import { requireAdmin, requireAuth, sanitizeUser } from "./route-middleware";
import { getEmailSettings, saveEmailSettings, testEmailConnection, sendTestEmail, getEmailLogs } from "./email/email-service";
import { generateRunId } from "./jmeter-worker";
import { validate, z, idParam } from "./validation";
import { logAudit } from "./audit-logger";
import { asyncHandler } from "./error-handler";

export function registerAdminRoutes(app: Express): void {

  app.get("/api/admin/users", requireAdmin, asyncHandler(async (req, res) => {
    const users = await storage.getUsers();
    res.json(users.map(sanitizeUser));
  }));

  app.get("/api/admin/pending-users", requireAdmin, asyncHandler(async (req, res) => {
    const pendingUsers = await storage.getPendingUsers();
    res.json(pendingUsers.map(sanitizeUser));
  }));

  app.post("/api/admin/users/:id/approve", requireAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    
    const user = await storage.updateUser(id, { isApproved: true });
    logAudit(req, "user_approve", "user", id);
    res.json({ message: "User approved", user: sanitizeUser(user) });
  }));

  app.delete("/api/admin/users/:id", requireAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const sessionUser = (req.session as any).user;
    const id = req.params.id as unknown as number;
    
    if (id === sessionUser.id) {
      return res.status(400).json({ message: "Cannot delete your own account" });
    }

    const targetUser = await storage.getUser(id);
    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    if (targetUser.role === "admin") {
      const admins = await storage.getAdminUsers();
      if (admins.length <= 1) {
        return res.status(400).json({ message: "Cannot delete the last administrator" });
      }
    }
    
    await storage.deleteUser(id);
    logAudit(req, "user_delete", "user", id);
    res.json({ message: "User deleted" });
  }));

  app.patch("/api/admin/users/:id/role", requireAdmin, validate({
    params: idParam,
    body: z.object({ role: z.enum(["admin", "engineer", "manager", "lead", "viewer"], { message: "Invalid role" }) })
  }), asyncHandler(async (req, res) => {
    const sessionUser = (req.session as any).user;
    const id = req.params.id as unknown as number;
    const { role } = req.body;

    if (id === sessionUser.id) {
      return res.status(400).json({ message: "Cannot change your own role" });
    }

    const targetUser = await storage.getUser(id);
    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    if (targetUser.role === "admin" && role !== "admin") {
      const admins = await storage.getAdminUsers();
      if (admins.length <= 1) {
        return res.status(400).json({ message: "Cannot demote the last administrator" });
      }
    }
    
    const user = await storage.updateUser(id, { role });
    logAudit(req, "user_role_change", "user", id, { role });
    res.json({ message: "User role updated", user: sanitizeUser(user) });
  }));

  app.get("/api/email-settings", requireAdmin, asyncHandler(async (req, res) => {
    const settings = await getEmailSettings();
    if (settings) {
      res.json({ ...settings, senderPassword: "••••••••" });
    } else {
      res.json(null);
    }
  }));

  app.post("/api/email-settings", requireAdmin, validate({
    body: z.object({
      senderEmail: z.string().email("Sender email is required"),
      smtpHost: z.string().optional(),
      smtpPort: z.number().optional(),
      senderPassword: z.string().optional(),
      defaultRecipients: z.array(z.string()).optional(),
      enabled: z.boolean().optional()
    })
  }), asyncHandler(async (req, res) => {
    const sessionUser = (req.session as any).user;
    const { smtpHost, smtpPort, senderEmail, senderPassword, defaultRecipients, enabled } = req.body;

    const existingSettings = await getEmailSettings();
    const passwordToSave = senderPassword === "••••••••" && existingSettings
      ? existingSettings.senderPassword
      : senderPassword;

    if (!passwordToSave) {
      return res.status(400).json({ message: "Sender password is required" });
    }

    const saved = await saveEmailSettings({
      smtpHost: smtpHost || "smtp.office365.com",
      smtpPort: smtpPort || 587,
      senderEmail,
      senderPassword: passwordToSave,
      defaultRecipients: defaultRecipients || [],
      enabled: enabled ?? false,
      updatedBy: sessionUser.id,
    });
    logAudit(req, "email_settings_update", "email_settings");
    res.json({ ...saved, senderPassword: "••••••••" });
  }));

  app.post("/api/email-settings/test-connection", requireAdmin, asyncHandler(async (req, res) => {
    const result = await testEmailConnection();
    res.json(result);
  }));

  app.post("/api/email-settings/send-test", requireAdmin, validate({
    body: z.object({ recipientEmail: z.string().email("Recipient email is required") })
  }), asyncHandler(async (req, res) => {
    const { recipientEmail } = req.body;
    const result = await sendTestEmail(recipientEmail);
    res.json(result);
  }));

  app.get("/api/email-logs", requireAdmin, validate({ query: z.object({ limit: z.coerce.number().int().min(1).max(200).optional() }).passthrough() }), asyncHandler(async (req, res) => {
    const limit = (req.query as any).limit || 50;
    const logs = await getEmailLogs(limit);
    res.json(logs);
  }));

  app.get("/api/admin/ingest-tokens", requireAdmin, asyncHandler(async (req, res) => {
    const tokens = await db.select({
      id: remoteIngestTokens.id,
      name: remoteIngestTokens.name,
      description: remoteIngestTokens.description,
      tokenPrefix: remoteIngestTokens.tokenPrefix,
      createdBy: remoteIngestTokens.createdBy,
      createdAt: remoteIngestTokens.createdAt,
      revokedAt: remoteIngestTokens.revokedAt,
      lastUsedAt: remoteIngestTokens.lastUsedAt,
      allowedExecutionIds: remoteIngestTokens.allowedExecutionIds,
      lastHeartbeatAt: remoteIngestTokens.lastHeartbeatAt,
      activeExecutionCount: remoteIngestTokens.activeExecutionCount,
      completedExecutionCount: remoteIngestTokens.completedExecutionCount,
      totalSamplesIngested: remoteIngestTokens.totalSamplesIngested,
      lastNodeId: remoteIngestTokens.lastNodeId,
    }).from(remoteIngestTokens).orderBy(desc(remoteIngestTokens.createdAt));
    res.json(tokens);
  }));

  app.post("/api/admin/ingest-tokens", requireAdmin, validate({
    body: z.object({
      name: z.string().min(1, "Token name is required"),
      description: z.string().optional().nullable(),
      allowedExecutionIds: z.array(z.number()).optional().nullable()
    })
  }), asyncHandler(async (req, res) => {
    const { name, description, allowedExecutionIds } = req.body;
    const sessionUser = (req.session as any).user;
    const { generateToken, hashToken } = await import("./ingest-routes");
    const { raw, prefix, hash } = generateToken();

    const [token] = await db.insert(remoteIngestTokens).values({
      name,
      description: description || null,
      tokenHash: hash,
      tokenPrefix: prefix,
      createdBy: sessionUser.id,
      allowedExecutionIds: allowedExecutionIds || null,
    }).returning();

    res.json({
      ...token,
      rawToken: raw,
      tokenHash: undefined,
    });
  }));

  app.delete("/api/admin/ingest-tokens/:id", requireAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const force = req.query.force === "true";

    const { invalidateTokenCache } = await import("./ingest-routes");
    if (force) {
      await db.delete(remoteIngestTokens).where(eq(remoteIngestTokens.id, id));
      invalidateTokenCache(id);
      res.json({ success: true, deleted: true });
    } else {
      await db.update(remoteIngestTokens)
        .set({ revokedAt: new Date().toISOString() })
        .where(eq(remoteIngestTokens.id, id));
      invalidateTokenCache(id);
      res.json({ success: true });
    }
  }));

  app.get("/api/admin/download-demo-guide", requireAdmin, (req, res) => {
    const pdfPath = path.join(process.cwd(), "PerfHub_v3_Demo_Guide.pdf");
    if (!fs.existsSync(pdfPath)) {
      return res.status(404).json({ message: "Demo guide PDF not found" });
    }
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", "attachment; filename=PerfHub_v3_Demo_Guide.pdf");
    res.setHeader("Cache-Control", "no-cache");
    const stream = fs.createReadStream(pdfPath);
    stream.on("error", (err) => {
      console.error("Error streaming demo guide PDF:", err);
      if (!res.headersSent) {
        res.status(500).json({ message: "Error reading PDF file" });
      } else {
        res.end();
      }
    });
    stream.pipe(res);
  });

  app.get("/api/admin/download-demo-presentation", requireAdmin, (req, res) => {
    const pdfPath = path.join(process.cwd(), "PerfHub_Demo_Presentation.pdf");
    if (!fs.existsSync(pdfPath)) {
      return res.status(404).json({ message: "Demo presentation PDF not found" });
    }
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", "attachment; filename=PerfHub_Demo_Presentation.pdf");
    res.setHeader("Cache-Control", "no-cache");
    const stream = fs.createReadStream(pdfPath);
    stream.on("error", (err) => {
      console.error("Error streaming demo presentation PDF:", err);
      if (!res.headersSent) {
        res.status(500).json({ message: "Error reading PDF file" });
      } else {
        res.end();
      }
    });
    stream.pipe(res);
  });

  app.get("/api/admin/download-backend-listener", requireAuth, (req, res) => {
    const jarPath = path.join(process.cwd(), "public", "downloads", "perfhub-backend-listener-1.4.0.jar");
    if (!fs.existsSync(jarPath)) {
      return res.status(404).json({ message: "JAR file not found" });
    }
    res.setHeader("Content-Type", "application/java-archive");
    res.setHeader("Content-Disposition", "attachment; filename=perfhub-backend-listener-1.4.0.jar");
    res.setHeader("Cache-Control", "no-cache");
    const stream = fs.createReadStream(jarPath);
    stream.pipe(res);
  });

  app.post("/api/admin/remote-execution", requireAdmin, validate({
    body: z.object({
      name: z.string().min(1, "Execution name is required"),
      scheduleId: z.number().optional().nullable(),
      scriptId: z.number().optional().nullable()
    })
  }), asyncHandler(async (req, res) => {
    const { name, scheduleId, scriptId } = req.body;

    const runId = generateRunId();
    const execution = await storage.createExecution({
      executionId: runId,
      scheduleId: scheduleId || null,
      status: "queued",
      resultSummary: null,
      artifactsPath: null,
      liveMetrics: null,
    });

    logAudit(req, "execution_start", "execution", undefined, { remote: true });
    res.json({
      executionId: execution.id,
      runId,
      status: "queued",
    });
  }));

  app.get("/api/audit-logs", requireAdmin, validate({ query: z.object({
    limit: z.coerce.number().int().min(1).max(200).optional(),
    offset: z.coerce.number().int().min(0).optional(),
    userId: z.coerce.number().int().optional(),
    action: z.string().optional(),
    resourceType: z.string().optional(),
    startDate: z.string().optional(),
    endDate: z.string().optional(),
  }).passthrough() }), asyncHandler(async (req, res) => {
    const q = req.query as any;
    const limit = q.limit || 50;
    const offset = q.offset || 0;
    const userId = q.userId as number | undefined;
    const action = q.action as string | undefined;
    const resourceType = q.resourceType as string | undefined;
    const startDate = q.startDate as string | undefined;
    const endDate = q.endDate as string | undefined;

    const conditions = [];
    if (userId) conditions.push(eq(auditLogs.userId, userId));
    if (action) conditions.push(eq(auditLogs.action, action));
    if (resourceType) conditions.push(eq(auditLogs.resourceType, resourceType));
    if (startDate) conditions.push(gte(auditLogs.timestamp, startDate));
    if (endDate) conditions.push(lte(auditLogs.timestamp, endDate));

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const [logs, countResult] = await Promise.all([
      db.select({
        id: auditLogs.id,
        userId: auditLogs.userId,
        action: auditLogs.action,
        resourceType: auditLogs.resourceType,
        resourceId: auditLogs.resourceId,
        details: auditLogs.details,
        timestamp: auditLogs.timestamp,
        username: users.username,
      })
        .from(auditLogs)
        .leftJoin(users, eq(auditLogs.userId, users.id))
        .where(whereClause)
        .orderBy(desc(auditLogs.timestamp))
        .limit(limit)
        .offset(offset),
      db.select({ count: sql<number>`count(*)::int` })
        .from(auditLogs)
        .where(whereClause),
    ]);

    res.json({
      logs,
      total: countResult[0]?.count || 0,
      limit,
      offset,
    });
  }));

  app.get("/api/audit-logs/actions", requireAdmin, asyncHandler(async (_req, res) => {
    const result = await db.selectDistinct({ action: auditLogs.action }).from(auditLogs).orderBy(auditLogs.action);
    res.json(result.map(r => r.action));
  }));

  app.get("/api/audit-logs/resource-types", requireAdmin, asyncHandler(async (_req, res) => {
    const result = await db.selectDistinct({ resourceType: auditLogs.resourceType }).from(auditLogs).orderBy(auditLogs.resourceType);
    res.json(result.map(r => r.resourceType));
  }));

  app.delete("/api/audit-logs", requireAdmin, validate({ body: z.object({ ids: z.array(z.number().int()).min(1, "Provide an array of log ids to delete") }) }), asyncHandler(async (req, res) => {
    const { ids } = req.body;
    const deleted = await db.delete(auditLogs).where(inArray(auditLogs.id, ids)).returning({ id: auditLogs.id });
    logAudit(req, "audit_log_delete", "audit_log", undefined, { deletedCount: deleted.length });
    res.json({ deleted: deleted.length });
  }));

  app.delete("/api/audit-logs/all", requireAdmin, asyncHandler(async (req, res) => {
    const result = await db.delete(auditLogs).returning({ id: auditLogs.id });
    logAudit(req, "audit_log_delete", "audit_log", undefined, { deletedCount: result.length, scope: "all" });
    res.json({ deleted: result.length });
  }));
}
