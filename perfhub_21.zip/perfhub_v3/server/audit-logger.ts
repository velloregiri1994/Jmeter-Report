import { type Request } from "express";
import { storage } from "./storage";

export type AuditAction =
  | "login" | "logout" | "signup" | "password_reset"
  | "user_approve" | "user_delete" | "user_role_change"
  | "execution_start" | "execution_cancel" | "execution_delete" | "execution_rerun"
  | "script_create" | "script_update" | "script_delete"
  | "schedule_create" | "schedule_update" | "schedule_delete"
  | "baseline_set" | "baseline_remove"
  | "sla_create" | "sla_update" | "sla_delete"
  | "report_create" | "report_update" | "report_delete" | "report_approve" | "report_reject"
  | "folder_create" | "folder_update" | "folder_delete"
  | "email_settings_update"
  | "api_token_create" | "api_token_revoke"
  | "webhook_create" | "webhook_update" | "webhook_delete" | "webhook_test"
  | "retention_cleanup"
  | "ci_trigger"
  | "audit_log_delete";

export async function logAudit(
  req: Request,
  action: AuditAction,
  resourceType: string,
  resourceId?: string | number,
  metadata?: Record<string, any>
): Promise<void> {
  try {
    const sessionUser = (req.session as any)?.user;
    const userId = sessionUser?.id || (req as any).apiTokenUserId;
    if (!userId) return;

    await storage.createAuditLog({
      userId,
      action,
      resourceType,
      resourceId: resourceId != null ? String(resourceId) : null,
      details: {
        metadata,
        ipAddress: req.ip || req.socket.remoteAddress || "unknown",
        userAgent: req.headers["user-agent"] || "unknown",
      },
    });
  } catch (err) {
    console.error("[audit] Failed to log audit event:", err);
  }
}
