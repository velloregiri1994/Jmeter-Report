export interface WorkloadTargets {
  threads?: number | null;
  tph?: number | null;
  tps?: number | null;
  pacing?: number | null;
  testType?: string | null;
  transactionsPerIteration?: number | null;
  e2eResponseTime?: number | null;
  thinkTime?: number | null;
  perTransaction?: Array<{ name: string; weight: number; tph: number; tps: number }> | null;
}

export interface ActualMetrics {
  totalRequests: number;
  failedRequests: number;
  avgResponseTime: number;
  throughput: number;
  errorRate: number;
  p90?: number;
  p95?: number;
  durationSeconds?: number;
  maxActiveThreads?: number;
  transactionDetails?: Array<{
    label: string;
    count: number;
    avg: number;
    throughput: number;
    errorRate: number;
  }>;
}

export type DiagnosticCategory =
  | "response_time_increased"
  | "high_error_rate"
  | "low_throughput"
  | "pacing_mismatch"
  | "thread_count_insufficient"
  | "error_rate_consuming_capacity"
  | "workload_model_validated";

export type Severity = "info" | "warning" | "critical";

export interface DiagnosticFinding {
  category: DiagnosticCategory;
  severity: Severity;
  title: string;
  detail: string;
  metric?: string;
  targetValue?: number;
  actualValue?: number;
  deviation?: number;
}

export interface MetricComparison {
  metric: string;
  label: string;
  target: number;
  actual: number;
  unit: string;
  achieved: boolean;
  deviationPercent: number;
}

export type OverallVerdict = "achieved" | "partially_achieved" | "not_achieved";

export interface WorkloadAchievementResult {
  verdict: OverallVerdict;
  comparisons: MetricComparison[];
  findings: DiagnosticFinding[];
  suggestions: string[];
  perTransaction?: Array<{
    name: string;
    targetTph: number;
    actualTph: number;
    achieved: boolean;
    deviationPercent: number;
  }>;
}

const TOLERANCE = 0.10;

function pctDev(target: number, actual: number): number {
  if (target === 0) return actual === 0 ? 0 : 100;
  return ((actual - target) / target) * 100;
}

function isAchieved(target: number, actual: number, higherIsBetter: boolean): boolean {
  if (higherIsBetter) {
    return actual >= target * (1 - TOLERANCE);
  }
  return actual <= target * (1 + TOLERANCE);
}

export function analyzeWorkloadAchievement(
  targets: WorkloadTargets,
  actual: ActualMetrics
): WorkloadAchievementResult {
  const comparisons: MetricComparison[] = [];
  const findings: DiagnosticFinding[] = [];
  const suggestions: string[] = [];

  const durationSec = actual.durationSeconds || 0;
  const durationHrs = durationSec / 3600;

  let actualTph: number;
  if (durationHrs > 0) {
    actualTph = Math.round(actual.totalRequests / durationHrs);
  } else if (actual.throughput > 0) {
    actualTph = Math.round(actual.throughput * 3600);
  } else {
    actualTph = 0;
  }
  const actualTps = actual.throughput;
  const actualErrorRate = actual.errorRate;
  const actualAvgRt = actual.avgResponseTime / 1000;
  const actualMaxThreads = actual.maxActiveThreads || 0;

  if (targets.tph) {
    const dev = pctDev(targets.tph, actualTph);
    comparisons.push({
      metric: "tph",
      label: "Transactions Per Hour",
      target: targets.tph,
      actual: actualTph,
      unit: "TPH",
      achieved: isAchieved(targets.tph, actualTph, true),
      deviationPercent: parseFloat(dev.toFixed(1)),
    });
  }

  if (targets.tps) {
    const dev = pctDev(targets.tps, actualTps);
    comparisons.push({
      metric: "tps",
      label: "Transactions Per Second",
      target: targets.tps,
      actual: parseFloat(actualTps.toFixed(2)),
      unit: "TPS",
      achieved: isAchieved(targets.tps, actualTps, true),
      deviationPercent: parseFloat(dev.toFixed(1)),
    });
  }

  if (targets.threads && actualMaxThreads > 0) {
    const dev = pctDev(targets.threads, actualMaxThreads);
    comparisons.push({
      metric: "threads",
      label: "Concurrent Threads",
      target: targets.threads,
      actual: actualMaxThreads,
      unit: "threads",
      achieved: Math.abs(dev) <= TOLERANCE * 100,
      deviationPercent: parseFloat(dev.toFixed(1)),
    });
  }

  if (targets.e2eResponseTime) {
    const dev = pctDev(targets.e2eResponseTime, actualAvgRt);
    comparisons.push({
      metric: "avgResponseTime",
      label: "Avg Response Time",
      target: targets.e2eResponseTime,
      actual: parseFloat(actualAvgRt.toFixed(3)),
      unit: "s",
      achieved: isAchieved(targets.e2eResponseTime, actualAvgRt, false),
      deviationPercent: parseFloat(dev.toFixed(1)),
    });
  }

  if (targets.pacing) {
    const txnsPerIter = targets.transactionsPerIteration || 1;
    const iterationTps = actualTps / txnsPerIter;
    const actualPacing = actualMaxThreads > 0 && iterationTps > 0
      ? actualMaxThreads / iterationTps
      : 0;
    if (actualPacing > 0) {
      const dev = pctDev(targets.pacing, actualPacing);
      comparisons.push({
        metric: "pacing",
        label: "Pacing (Iteration Time)",
        target: targets.pacing,
        actual: parseFloat(actualPacing.toFixed(2)),
        unit: "s",
        achieved: Math.abs(dev) <= TOLERANCE * 100,
        deviationPercent: parseFloat(dev.toFixed(1)),
      });
    }
  }

  const tphComparison = comparisons.find(c => c.metric === "tph");
  const rtComparison = comparisons.find(c => c.metric === "avgResponseTime");
  const pacingComparison = comparisons.find(c => c.metric === "pacing");

  const tphMissed = tphComparison && !tphComparison.achieved;
  const rtExceeded = rtComparison && !rtComparison.achieved;
  const errorRateHigh = actualErrorRate > 2;

  if (rtExceeded && targets.e2eResponseTime) {
    const rtIncreasePct = pctDev(targets.e2eResponseTime, actualAvgRt);
    const severity: Severity = rtIncreasePct > 50 ? "critical" : rtIncreasePct > 20 ? "warning" : "info";
    findings.push({
      category: "response_time_increased",
      severity,
      title: "Response Time Higher Than Expected",
      detail: `Average response time is ${actualAvgRt.toFixed(2)}s vs expected ${targets.e2eResponseTime}s (+${rtIncreasePct.toFixed(1)}%). Slower responses mean each thread completes fewer iterations per hour, directly reducing TPH. This is often the primary cause of missed throughput targets.`,
      metric: "avgResponseTime",
      targetValue: targets.e2eResponseTime,
      actualValue: actualAvgRt,
      deviation: rtIncreasePct,
    });
    suggestions.push("Investigate slow transactions — check database query times, external API latency, and server resource utilization");
    suggestions.push("Review application logs for timeout or retry patterns during the test");
    if (tphMissed) {
      suggestions.push("The response time increase is likely the primary reason TPH was not achieved — fixing response time should bring TPH closer to target");
    }
  }

  if (errorRateHigh) {
    const severity: Severity = actualErrorRate > 10 ? "critical" : actualErrorRate > 5 ? "warning" : "info";
    findings.push({
      category: "high_error_rate",
      severity,
      title: "Error Rate Is Elevated",
      detail: `Error rate is ${actualErrorRate.toFixed(1)}% (${actual.failedRequests.toLocaleString()} failed out of ${actual.totalRequests.toLocaleString()} total requests). Failed requests consume thread time without completing useful work, reducing effective throughput.`,
      metric: "errorRate",
      actualValue: actualErrorRate,
    });
    suggestions.push("Check error response codes and messages to identify the failure type (5xx server errors, timeouts, connection refused, etc.)");
    if (actualErrorRate > 5) {
      findings.push({
        category: "error_rate_consuming_capacity",
        severity: "warning",
        title: "Errors Consuming Thread Capacity",
        detail: `With ${actualErrorRate.toFixed(1)}% of requests failing, approximately ${Math.round(actualErrorRate / 100 * (targets.threads || actualMaxThreads))} threads are effectively wasted on failed requests at any given time.`,
      });
      suggestions.push("Consider reducing load to find the error-free throughput ceiling, then investigate what causes errors at higher load");
    }
  }

  if (tphMissed && !rtExceeded && !errorRateHigh && targets.threads && actualMaxThreads > 0) {
    const threadDef = pctDev(targets.threads, actualMaxThreads);
    if (threadDef < -10) {
      findings.push({
        category: "thread_count_insufficient",
        severity: "warning",
        title: "Thread Count Below Target",
        detail: `Only ${actualMaxThreads} threads reached vs ${targets.threads} expected (${threadDef.toFixed(1)}%). Response times and error rates are acceptable, so the system can likely handle more load — the bottleneck is the test configuration, not the application.`,
        metric: "threads",
        targetValue: targets.threads,
        actualValue: actualMaxThreads,
        deviation: threadDef,
      });
      suggestions.push(`Increase JMeter thread count to ${targets.threads} or add more load generators if running distributed`);
    }
  }

  if (tphMissed && !rtExceeded && !errorRateHigh && targets.tph) {
    const throughputDev = tphComparison!.deviationPercent;
    if (throughputDev < -10) {
      findings.push({
        category: "low_throughput",
        severity: "warning",
        title: "Throughput Below Target Despite Good Response Times",
        detail: `TPH is ${actualTph.toLocaleString()} vs target ${targets.tph.toLocaleString()} (${throughputDev.toFixed(1)}%), but response times and error rates are within expected ranges. This typically indicates the test wasn't configured with enough threads, or think time / pacing was set too high.`,
        metric: "tph",
        targetValue: targets.tph,
        actualValue: actualTph,
        deviation: throughputDev,
      });
      suggestions.push("Check think time configuration in the JMeter script — a higher-than-expected think time directly reduces TPH");
      suggestions.push("Verify that the Constant Timer or pacing timer values match the workload model inputs");
    }
  }

  if (pacingComparison && !pacingComparison.achieved && targets.pacing) {
    const pacingDev = pacingComparison.deviationPercent;
    const pacingDeviationSignificant = Math.abs(pacingDev) > 20;
    if (tphMissed || pacingDeviationSignificant) {
      findings.push({
        category: "pacing_mismatch",
        severity: pacingDev > 30 ? "warning" : "info",
        title: "Actual Pacing Differs From Model",
        detail: `Observed pacing is ${pacingComparison.actual}s vs calculated ${targets.pacing}s (${pacingDev > 0 ? "+" : ""}${pacingDev.toFixed(1)}%). ${pacingDev > 0 ? "Longer pacing means fewer iterations — possibly due to higher response times or excessive think time." : "Shorter pacing may mean think time is lower than modeled."}`,
        metric: "pacing",
        targetValue: targets.pacing,
        actualValue: pacingComparison.actual,
        deviation: pacingDev,
      });
      if (pacingDev > 15) {
        suggestions.push("Recalculate the workload model using the actual observed response time to get realistic targets");
      }
    }
  }

  if (findings.length === 0 && comparisons.length > 0) {
    const allAchieved = comparisons.every(c => c.achieved);
    if (allAchieved) {
      findings.push({
        category: "workload_model_validated",
        severity: "info",
        title: "Workload Model Validated",
        detail: "All target metrics were achieved within the 10% tolerance. The workload model accurately reflects the system's performance under the tested conditions.",
      });
    }
  }

  let perTransaction: WorkloadAchievementResult["perTransaction"];
  if (targets.perTransaction && actual.transactionDetails) {
    perTransaction = [];
    for (const t of targets.perTransaction) {
      const actualTx = actual.transactionDetails.find(
        a => a.label.toLowerCase() === t.name.toLowerCase()
      );
      if (actualTx) {
        let txActualTph: number;
        if (durationHrs > 0) {
          txActualTph = Math.round(actualTx.count / durationHrs);
        } else if (actualTx.throughput > 0) {
          txActualTph = Math.round(actualTx.throughput * 3600);
        } else {
          txActualTph = 0;
        }
        const dev = pctDev(t.tph, txActualTph);
        perTransaction.push({
          name: t.name,
          targetTph: t.tph,
          actualTph: txActualTph,
          achieved: isAchieved(t.tph, txActualTph, true),
          deviationPercent: parseFloat(dev.toFixed(1)),
        });
      }
    }
  }

  const achievedCount = comparisons.filter(c => c.achieved).length;
  const totalComparisons = comparisons.length;
  let verdict: OverallVerdict;
  if (totalComparisons === 0) {
    verdict = "not_achieved";
    findings.push({
      category: "low_throughput",
      severity: "info",
      title: "No Metrics Could Be Compared",
      detail: "No target metrics could be matched against actual execution data. Ensure workload targets include at least one of: TPH, TPS, threads, response time, or pacing — and that the execution produced result data.",
    });
  } else if (achievedCount === totalComparisons) {
    verdict = "achieved";
  } else if (achievedCount >= totalComparisons * 0.5) {
    verdict = "partially_achieved";
  } else {
    verdict = "not_achieved";
  }

  return { verdict, comparisons, findings, suggestions, perTransaction };
}
