import { TestExecution, TestSchedule, Script, Comment, User } from "@shared/schema";
import { format } from "date-fns";

type CommentWithUser = Comment & { user?: User | null };

type ExecutionWithRelations = TestExecution & {
  schedule: (TestSchedule & {
    script: Script;
  }) | null;
  comments?: CommentWithUser[];
};

export function generateHtmlReport(execution: ExecutionWithRelations): string {
  const { schedule, resultSummary, startTime, endTime } = execution;
  const script = schedule?.script || null;
  const config = (schedule?.configuration || {}) as any;
  const scheduleName = schedule?.name || (execution.scheduleId ? 'Unknown Schedule' : 'Remote Execution');
  const scriptName = script?.name || ((execution as any).executionId || 'Remote Test');
  const scriptToolType = script?.toolType || 'JMeter';

  const metricsSource = resultSummary;

  const totalRequests = metricsSource?.totalRequests || 0;
  const failedRequests = metricsSource?.failedRequests || 0;
  const successfulRequests = totalRequests - failedRequests;
  const avgResponseTime = metricsSource?.avgResponseTime || 0;
  const throughput = metricsSource?.throughput || 0;
  const successRate = totalRequests > 0 ? ((successfulRequests) / totalRequests) * 100 : 100;
  const errorRate = totalRequests > 0 ? (failedRequests / totalRequests) * 100 : 0;

  const startStr = startTime ? format(new Date(startTime), "MMM d, yyyy HH:mm:ss") : "N/A";
  const endStr = endTime ? format(new Date(endTime), "MMM d, yyyy HH:mm:ss") : "N/A";
  const duration = startTime && endTime ?
    Math.round((new Date(endTime).getTime() - new Date(startTime).getTime()) / 1000) : 0;

  const h = Math.floor(duration / 3600);
  const m = Math.floor((duration % 3600) / 60);
  const s = duration % 60;
  const durationStr = h > 0 ? `${h}h ${m}m ${s}s` : `${m}m ${s}s`;

  const details = (metricsSource?.transactionDetails || []).filter((tx: any) => tx.count > 0);
  const timeseries = (metricsSource as any)?.timeseries || [];

  const slaViolations = execution.slaViolations as Record<string, any> || {};
  const perTxViolations = (slaViolations as any)?.perTransaction || [];
  const violationCount = perTxViolations.length;

  const anomalies = (metricsSource as any)?.anomalies || [];
  const correlationEvents = (metricsSource as any)?.insights || [];
  const systemMetrics = (metricsSource as any)?.systemMetrics || null;

  let healthScore = 100;
  healthScore -= (violationCount * 15);
  healthScore -= (errorRate * 5);
  healthScore = Math.max(0, Math.min(100, Math.round(healthScore)));

  const healthLabel = healthScore > 85 ? 'PASS' : healthScore > 60 ? 'MARGINAL' : 'FAIL';
  const healthClass = healthScore > 85 ? 'pass' : healthScore > 60 ? 'marginal' : 'fail';

  const p50Value = (metricsSource as any)?.p50 || 0;
  const p90Value = (metricsSource as any)?.p90 || 0;
  const p95Value = (metricsSource as any)?.p95 || 0;
  const p99Value = (metricsSource as any)?.p99 || 0;
  const minResponseTime = (metricsSource as any)?.minResponseTime || 0;
  const maxResponseTime = (metricsSource as any)?.maxResponseTime || 0;
  const peakRps = (metricsSource as any)?.peakRps || 0;
  const apdex = (metricsSource as any)?.apdex || 0;

  const errorDetails = ((resultSummary as any)?.errorDetails || []) as Array<{
    label: string;
    response_message: string;
    response_code: string | number;
    count: number;
    pct: number;
  }>;

  const transactionRows = details.length > 0 ? details.map((tx: any, idx: number) => {
    const hasError = (tx.errorRate || 0) > 0.02;
    const violationsForTx = perTxViolations.filter((v: any) => v.label === tx.label);
    return `
    <tr class="${idx % 2 === 0 ? 'row-even' : ''}">
      <td class="tx-name">${tx.label}</td>
      <td class="num">${tx.count.toLocaleString()}</td>
      <td class="num">${(tx.avg ?? 0).toFixed(0)}</td>
      <td class="num">${(tx.p50 ?? 0).toFixed(0)}</td>
      <td class="num">${(tx.p90 ?? 0).toFixed(0)}</td>
      <td class="num">${(tx.p95 ?? 0).toFixed(0)}</td>
      <td class="num">${(tx.p99 ?? 0).toFixed(0)}</td>
      <td class="num">${(tx.throughput ?? 0).toFixed(2)}</td>
      <td class="num">${((tx.errorRate || 0) * 100).toFixed(2)}%</td>
      <td class="num"><span class="pill ${hasError ? 'pill-fail' : violationsForTx.length > 0 ? 'pill-warn' : 'pill-pass'}">${hasError ? 'FAIL' : violationsForTx.length > 0 ? 'SLA' : 'PASS'}</span></td>
    </tr>`;
  }).join('') : '';

  const errorRows = errorDetails.map(err => `
    <tr>
      <td class="tx-name">${err.label || 'Global'}</td>
      <td><code class="code-badge">${err.response_code || 'N/A'}</code></td>
      <td class="err-msg">${err.response_message || 'Unknown error'}</td>
      <td class="num">${(err.count || 1).toLocaleString()}</td>
      <td class="num">${err.pct !== undefined ? ((err.pct * 100).toFixed(1) + '%') : 'N/A'}</td>
    </tr>
  `).join('');

  const slaRows = perTxViolations.map((v: any) => `
    <tr>
      <td class="tx-name">${v.label || 'Global'}</td>
      <td>${v.ruleName || v.metric}</td>
      <td class="num">${typeof v.threshold === 'number' ? v.threshold : v.threshold}</td>
      <td class="num" style="color:var(--red)">${typeof v.actual === 'number' ? (v.metric === 'errorRate' ? (v.actual * 100).toFixed(2) + '%' : v.actual.toFixed(2)) : v.actual}</td>
      <td><span class="pill pill-fail">BREACH</span></td>
    </tr>
  `).join('');

  const anomalyLabel = (type: string) =>
    type === 'response_time' ? 'Response Time Spike' : type === 'error_rate' ? 'Error Rate Spike' : 'Throughput Drop';

  const correlationLabel = (type: string) => {
    const map: Record<string, string> = {
      backend_slowdown: 'Server Slowing Down', capacity_saturation: 'System at Capacity',
      rapid_fail_fast: 'Requests Being Rejected', gradual_degradation: 'Gradual Degradation',
      traffic_loss: 'Requests Not Reaching Server', tail_latency: 'Slow Outlier Requests',
    };
    return map[type] || type;
  };

  const commentHtml = (execution.comments && execution.comments.length > 0) ? execution.comments.map(c => `
    <div class="comment ${c.type === 'sign-off' ? 'sign-off' : ''}">
      <div class="comment-head">
        <span class="comment-author">${c.user?.username || 'User'}${c.type === 'sign-off' ? ' <span class="pill pill-pass" style="font-size:9px">SIGN-OFF</span>' : ''}</span>
        <span class="comment-date">${c.createdAt ? format(new Date(c.createdAt), "MMM d, yyyy 'at' h:mm a") : ''}</span>
      </div>
      <p class="comment-body">${c.content}</p>
    </div>
  `).join('') : '';

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>${scheduleName} — Performance Test Report</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:#f0f2f5;--surface:#fff;--surface2:#f8f9fb;--border:#e5e7eb;--text:#111827;--text2:#4b5563;--text3:#9ca3af;--blue:#2563eb;--blue-bg:#eff6ff;--green:#059669;--green-bg:#ecfdf5;--red:#dc2626;--red-bg:#fef2f2;--amber:#d97706;--amber-bg:#fffbeb;--violet:#7c3aed;--violet-bg:#f5f3ff;--cyan:#0891b2;--cyan-bg:#ecfeff;--radius:10px;--shadow:0 1px 3px rgba(0,0,0,0.06),0 1px 2px rgba(0,0,0,0.04)}
*{box-sizing:border-box;margin:0}
body{background:var(--bg);color:var(--text);font-family:'Inter','SF Pro Display',system-ui,-apple-system,sans-serif;line-height:1.55;font-size:13px}
.page{max-width:1100px;margin:0 auto;padding:20px}

.hero{background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#334155 100%);color:#fff;border-radius:16px;padding:32px 36px;margin-bottom:20px;position:relative;overflow:hidden}
.hero::before{content:'';position:absolute;top:-40%;right:-5%;width:400px;height:400px;background:radial-gradient(circle,rgba(99,102,241,0.15) 0%,transparent 70%);border-radius:50%}
.hero::after{content:'';position:absolute;bottom:-30%;left:10%;width:300px;height:300px;background:radial-gradient(circle,rgba(6,182,212,0.1) 0%,transparent 70%);border-radius:50%}
.hero-top{display:flex;justify-content:space-between;align-items:flex-start;position:relative;z-index:1}
.hero h1{font-size:22px;font-weight:700;letter-spacing:-0.03em;margin-bottom:2px}
.hero .tagline{font-size:13px;color:#94a3b8;font-weight:500}
.verdict{text-align:center;padding:10px 20px;border-radius:12px;min-width:120px}
.verdict.pass{background:rgba(16,185,129,0.15);border:1px solid rgba(16,185,129,0.3)}
.verdict.marginal{background:rgba(245,158,11,0.15);border:1px solid rgba(245,158,11,0.3)}
.verdict.fail{background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3)}
.verdict-score{font-size:28px;font-weight:800;letter-spacing:-0.02em}
.verdict.pass .verdict-score{color:#34d399}
.verdict.marginal .verdict-score{color:#fbbf24}
.verdict.fail .verdict-score{color:#f87171}
.verdict-label{font-size:10px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;margin-top:2px}
.verdict.pass .verdict-label{color:#6ee7b7}
.verdict.marginal .verdict-label{color:#fcd34d}
.verdict.fail .verdict-label{color:#fca5a5}

.hero-meta{display:flex;flex-wrap:wrap;gap:20px;margin-top:18px;position:relative;z-index:1}
.meta-block{display:flex;flex-direction:column;gap:1px}
.meta-label{font-size:10px;text-transform:uppercase;letter-spacing:0.08em;color:#64748b;font-weight:600}
.meta-val{font-size:13px;font-weight:600;color:#e2e8f0}
.meta-val code{font-family:ui-monospace,SFMono-Regular,monospace;background:rgba(255,255,255,0.08);padding:1px 6px;border-radius:4px;font-size:12px}

.kpi-strip{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:16px}
.kpi{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:14px 16px;text-align:center;box-shadow:var(--shadow)}
.kpi-val{font-size:20px;font-weight:800;letter-spacing:-0.02em}
.kpi-label{font-size:10px;text-transform:uppercase;letter-spacing:0.06em;color:var(--text3);font-weight:700;margin-top:3px}
.kpi.blue .kpi-val{color:var(--blue)}.kpi.green .kpi-val{color:var(--green)}.kpi.red .kpi-val{color:var(--red)}.kpi.amber .kpi-val{color:var(--amber)}.kpi.violet .kpi-val{color:var(--violet)}.kpi.cyan .kpi-val{color:var(--cyan)}

.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px}
.grid-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:16px}

.card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow);overflow:hidden}
.card-head{padding:14px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.card-title{font-size:13px;font-weight:700;letter-spacing:-0.01em;display:flex;align-items:center;gap:6px}
.card-body{padding:18px}
.card-body.compact{padding:14px}
.card-count{font-size:11px;color:var(--text3);background:var(--surface2);padding:2px 8px;border-radius:20px;font-weight:600}

.stat-row{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--surface2)}
.stat-row:last-child{border-bottom:none}
.stat-key{color:var(--text2);font-size:12px}
.stat-val{font-weight:700;font-size:12px}

.latency-bar{display:flex;align-items:center;gap:10px;margin-bottom:6px}
.latency-label{font-size:11px;color:var(--text2);min-width:30px;text-align:right;font-weight:600}
.latency-track{flex:1;background:var(--surface2);border-radius:6px;height:22px;position:relative;overflow:hidden}
.latency-fill{height:100%;border-radius:6px;display:flex;align-items:center;padding-left:8px;font-size:10px;font-weight:700;color:#fff;min-width:40px}
.latency-fill.blue{background:linear-gradient(90deg,#3b82f6,#6366f1)}.latency-fill.amber{background:linear-gradient(90deg,#f59e0b,#ef4444)}

table{width:100%;border-collapse:collapse;font-size:12px}
thead{background:var(--surface2)}
th{padding:9px 12px;text-align:left;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.05em;color:var(--text2);border-bottom:2px solid var(--border)}
td{padding:8px 12px;border-bottom:1px solid var(--surface2)}
.row-even{background:var(--surface2)}
.tx-name{font-weight:600;color:var(--text);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.num{text-align:right;font-variant-numeric:tabular-nums;font-family:ui-monospace,SFMono-Regular,monospace;font-size:11px}
.err-msg{color:var(--red);font-size:11px;max-width:320px;word-wrap:break-word}

.pill{display:inline-flex;align-items:center;padding:2px 8px;border-radius:999px;font-size:9px;font-weight:800;letter-spacing:0.04em}
.pill-pass{background:var(--green-bg);color:var(--green);border:1px solid rgba(5,150,105,0.2)}
.pill-fail{background:var(--red-bg);color:var(--red);border:1px solid rgba(220,38,38,0.2)}
.pill-warn{background:var(--amber-bg);color:var(--amber);border:1px solid rgba(217,119,6,0.2)}

.code-badge{font-family:ui-monospace,monospace;font-size:11px;padding:2px 7px;background:var(--red-bg);color:#991b1b;border-radius:4px;font-weight:600}

.insight{padding:12px 14px;border-radius:8px;margin-bottom:8px;border-left:3px solid}
.insight.critical{background:var(--red-bg);border-color:var(--red)}
.insight.warning{background:var(--amber-bg);border-color:var(--amber)}
.insight-type{font-size:11px;font-weight:700;margin-bottom:3px}
.insight.critical .insight-type{color:var(--red)}
.insight.warning .insight-type{color:var(--amber)}
.insight-desc{font-size:12px;color:var(--text2);line-height:1.5}

.chart-box{height:280px;position:relative}

.comment{padding:12px 14px;border-radius:8px;background:var(--surface2);border-left:3px solid var(--text3);margin-bottom:8px}
.comment.sign-off{border-color:var(--green)}
.comment-head{display:flex;justify-content:space-between;margin-bottom:4px}
.comment-author{font-weight:700;font-size:12px}
.comment-date{font-size:11px;color:var(--text3)}
.comment-body{font-size:12px;color:var(--text2);line-height:1.6}

.section-divider{margin:24px 0 16px;display:flex;align-items:center;gap:10px}
.section-divider h2{font-size:15px;font-weight:700;letter-spacing:-0.02em;white-space:nowrap}
.section-divider::after{content:'';flex:1;height:1px;background:var(--border)}

.print-btn{position:fixed;top:16px;right:16px;padding:8px 16px;background:var(--blue);color:#fff;border:none;border-radius:8px;font-weight:600;font-size:12px;cursor:pointer;box-shadow:0 4px 12px rgba(37,99,235,0.3);z-index:100;display:flex;align-items:center;gap:5px}
.print-btn:hover{background:#1d4ed8}
.footer{text-align:center;padding:20px;color:var(--text3);font-size:11px;margin-top:8px}

@media print{
  .print-btn{display:none!important}
  body{background:#fff;font-size:11px}
  .page{padding:0}
  .hero{border-radius:0;margin:0 -20px 16px;padding:20px 24px;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .kpi-strip{grid-template-columns:repeat(3,1fr)}
  .grid-2,.grid-3{grid-template-columns:1fr}
  .chart-box{height:200px}
  .card{break-inside:avoid;page-break-inside:avoid}
}
@media(max-width:900px){.kpi-strip{grid-template-columns:repeat(3,1fr)}.grid-2,.grid-3{grid-template-columns:1fr}.hero-top{flex-direction:column;gap:12px}}
</style>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<button class="print-btn" onclick="window.print()">
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
  Export PDF
</button>

<div class="page">

  <div class="hero">
    <div class="hero-top">
      <div>
        <h1>${scheduleName}</h1>
        <div class="tagline">${scriptName} &middot; ${scriptToolType} Performance Test Report</div>
      </div>
    </div>
    <div class="hero-meta">
      <div class="meta-block"><span class="meta-label">Environment</span><span class="meta-val">${config?.environment || 'Unknown'}</span></div>
      <div class="meta-block"><span class="meta-label">Test Type</span><span class="meta-val">${config?.testTypeName || 'Load Test'}</span></div>
      <div class="meta-block"><span class="meta-label">Load Profile</span><span class="meta-val">${config?.volume || 'N/A'}</span></div>
      <div class="meta-block"><span class="meta-label">Duration</span><span class="meta-val">${durationStr}</span></div>
      <div class="meta-block"><span class="meta-label">Start</span><span class="meta-val"><code>${startStr}</code></span></div>
      <div class="meta-block"><span class="meta-label">End</span><span class="meta-val"><code>${endStr}</code></span></div>
      <div class="meta-block"><span class="meta-label">Generated</span><span class="meta-val"><code>${format(new Date(), "MMM d, yyyy HH:mm")}</code></span></div>
    </div>
  </div>

  <div class="kpi-strip">
    <div class="kpi blue"><div class="kpi-val">${totalRequests.toLocaleString()}</div><div class="kpi-label">Total Requests</div></div>
    <div class="kpi green"><div class="kpi-val">${successRate.toFixed(1)}%</div><div class="kpi-label">Success Rate</div></div>
    <div class="kpi ${errorRate > 5 ? 'red' : errorRate > 1 ? 'amber' : 'green'}"><div class="kpi-val">${errorRate.toFixed(2)}%</div><div class="kpi-label">Error Rate</div></div>
    <div class="kpi amber"><div class="kpi-val">${avgResponseTime.toFixed(0)}<span style="font-size:11px;font-weight:400">ms</span></div><div class="kpi-label">Avg Response</div></div>
    <div class="kpi cyan"><div class="kpi-val">${throughput.toFixed(1)}<span style="font-size:11px;font-weight:400">/s</span></div><div class="kpi-label">Throughput</div></div>
    <div class="kpi violet"><div class="kpi-val">${peakRps.toLocaleString()}</div><div class="kpi-label">Peak RPS</div></div>
  </div>

  <div class="grid-2">
    <div class="card">
      <div class="card-head"><span class="card-title">Response Time Distribution</span></div>
      <div class="card-body compact">
        ${[
          { label: 'Min', val: minResponseTime, color: 'blue' },
          { label: 'P50', val: p50Value, color: 'blue' },
          { label: 'P90', val: p90Value, color: 'blue' },
          { label: 'P95', val: p95Value, color: p95Value > 2000 ? 'amber' : 'blue' },
          { label: 'P99', val: p99Value, color: p99Value > 3000 ? 'amber' : 'blue' },
          { label: 'Max', val: maxResponseTime, color: maxResponseTime > 5000 ? 'amber' : 'blue' },
        ].map(p => {
          const pct = maxResponseTime > 0 ? Math.max(8, Math.min(100, (p.val / maxResponseTime) * 100)) : 10;
          return `<div class="latency-bar"><span class="latency-label">${p.label}</span><div class="latency-track"><div class="latency-fill ${p.color}" style="width:${pct}%">${p.val.toFixed(0)}ms</div></div></div>`;
        }).join('')}
      </div>
    </div>
    <div class="card">
      <div class="card-head"><span class="card-title">Test Summary</span></div>
      <div class="card-body compact">
        <div class="stat-row"><span class="stat-key">Successful Requests</span><span class="stat-val" style="color:var(--green)">${successfulRequests.toLocaleString()}</span></div>
        <div class="stat-row"><span class="stat-key">Failed Requests</span><span class="stat-val" style="color:var(--red)">${failedRequests.toLocaleString()}</span></div>
        <div class="stat-row"><span class="stat-key">APDEX Score</span><span class="stat-val" style="color:${apdex >= 0.9 ? 'var(--green)' : apdex >= 0.7 ? 'var(--amber)' : 'var(--red)'}">${apdex.toFixed(3)}</span></div>
        <div class="stat-row"><span class="stat-key">SLA Violations</span><span class="stat-val" style="color:${violationCount > 0 ? 'var(--red)' : 'var(--green)'}">${violationCount}</span></div>
        ${systemMetrics ? `
        <div class="stat-row"><span class="stat-key">Peak CPU</span><span class="stat-val">${systemMetrics.maxCpu?.toFixed(1) || 'N/A'}%</span></div>
        <div class="stat-row"><span class="stat-key">Peak Memory</span><span class="stat-val">${systemMetrics.maxMemPercent?.toFixed(1) || 'N/A'}%</span></div>
        ` : ''}
      </div>
    </div>
  </div>


  <div class="section-divider"><h2>Performance Over Time</h2></div>

  <div class="grid-2">
    <div class="card">
      <div class="card-head"><span class="card-title">Response Time &amp; Throughput</span></div>
      <div class="card-body"><div class="chart-box"><canvas id="rtTpChart"></canvas></div></div>
    </div>
    <div class="card">
      <div class="card-head"><span class="card-title">Active Threads &amp; Errors</span></div>
      <div class="card-body"><div class="chart-box"><canvas id="threadsErrChart"></canvas></div></div>
    </div>
  </div>

  <div class="grid-2">
    <div class="card">
      <div class="card-head"><span class="card-title">Avg Response Time &amp; Errors</span></div>
      <div class="card-body"><div class="chart-box"><canvas id="rtErrChart"></canvas></div></div>
    </div>
    <div class="card">
      <div class="card-head"><span class="card-title">Throughput &amp; Hits/sec</span></div>
      <div class="card-body"><div class="chart-box"><canvas id="tpHitsChart"></canvas></div></div>
    </div>
  </div>

  <div class="grid-2">
    <div class="card">
      <div class="card-head"><span class="card-title">Throughput &amp; Errors</span></div>
      <div class="card-body"><div class="chart-box"><canvas id="tpErrChart"></canvas></div></div>
    </div>
    <div class="card"></div>
  </div>

  ${details.length > 0 ? `
  <div class="section-divider"><h2>Transaction Analysis</h2></div>

  <div class="grid-2" style="margin-bottom:16px">
    <div class="card">
      <div class="card-head"><span class="card-title">Avg Response by Transaction</span></div>
      <div class="card-body"><div class="chart-box"><canvas id="txBarChart"></canvas></div></div>
    </div>
    <div class="card">
      <div class="card-head"><span class="card-title">Throughput by Transaction</span></div>
      <div class="card-body"><div class="chart-box"><canvas id="txTpChart"></canvas></div></div>
    </div>
  </div>

  <div class="card" style="margin-bottom:16px">
    <div class="card-head"><span class="card-title">Transaction Details</span><span class="card-count">${details.length} transactions</span></div>
    <div style="overflow-x:auto">
      <table>
        <thead><tr><th>Transaction</th><th class="num">Samples</th><th class="num">Avg (ms)</th><th class="num">P50</th><th class="num">P90</th><th class="num">P95</th><th class="num">P99</th><th class="num">TPS</th><th class="num">Error %</th><th class="num">Status</th></tr></thead>
        <tbody>${transactionRows}</tbody>
      </table>
    </div>
  </div>
  ` : ''}

  ${violationCount > 0 ? `
  <div class="section-divider"><h2>SLA Violations</h2></div>
  <div class="card" style="margin-bottom:16px">
    <div class="card-head"><span class="card-title" style="color:var(--red)">SLA Breaches</span><span class="card-count">${violationCount}</span></div>
    <div style="overflow-x:auto">
      <table>
        <thead><tr><th>Transaction</th><th>Rule</th><th class="num">Threshold</th><th class="num">Actual</th><th class="num">Status</th></tr></thead>
        <tbody>${slaRows}</tbody>
      </table>
    </div>
  </div>
  ` : ''}

  ${errorDetails.length > 0 ? `
  <div class="section-divider"><h2>Error Analysis</h2></div>
  <div class="grid-2" style="margin-bottom:16px">
    <div class="card">
      <div class="card-head"><span class="card-title">Error Distribution</span></div>
      <div class="card-body"><div class="chart-box"><canvas id="errorPieChart"></canvas></div></div>
    </div>
    <div class="card">
      <div class="card-head"><span class="card-title">Error Summary</span></div>
      <div class="card-body compact">
        <div class="stat-row"><span class="stat-key">Unique Error Types</span><span class="stat-val">${errorDetails.length}</span></div>
        <div class="stat-row"><span class="stat-key">Total Errors</span><span class="stat-val" style="color:var(--red)">${errorDetails.reduce((s, e) => s + (e.count || 1), 0).toLocaleString()}</span></div>
        <div class="stat-row"><span class="stat-key">Affected Transactions</span><span class="stat-val">${new Set(errorDetails.map(e => e.label)).size}</span></div>
        <div class="stat-row"><span class="stat-key">Overall Error Rate</span><span class="stat-val" style="color:var(--red)">${errorRate.toFixed(2)}%</span></div>
      </div>
    </div>
  </div>
  <div class="card" style="margin-bottom:16px">
    <div class="card-head"><span class="card-title">Error Details</span></div>
    <div style="overflow-x:auto">
      <table>
        <thead><tr><th>Transaction</th><th>Code</th><th>Message</th><th class="num">Count</th><th class="num">Impact</th></tr></thead>
        <tbody>${errorRows}</tbody>
      </table>
    </div>
  </div>
  ` : ''}

  ${commentHtml ? `
  <div class="section-divider"><h2>Comments &amp; Sign-Offs</h2></div>
  <div class="card" style="margin-bottom:16px">
    <div class="card-head"><span class="card-title">Team Notes</span><span class="card-count">${execution.comments?.length || 0}</span></div>
    <div class="card-body compact">${commentHtml}</div>
  </div>
  ` : ''}

  <div class="footer">Generated by PerfHub &middot; ${format(new Date(), "MMMM d, yyyy 'at' h:mm a")}</div>
</div>

<script>
(function(){
  const ts = ${JSON.stringify(timeseries.map((p: any) => ({ s: p.sec ?? (p.t ? Math.floor(p.t / 1000) : 0), rt: p.avg_ms ?? p.avgRT ?? 0, rps: p.rps ?? p.throughput ?? 0, err: p.errors ?? (p.errorRate != null && p.throughput ? Math.round(p.throughput * p.errorRate / 100) : 0), t: p.active_threads ?? p.activeThreads ?? 0 })))};
  const txLabels = ${JSON.stringify(details.map((tx: any) => tx.label))};
  const txAvg = ${JSON.stringify(details.map((tx: any) => tx.avg))};
  const txP95 = ${JSON.stringify(details.map((tx: any) => tx.p95))};
  const txTp = ${JSON.stringify(details.map((tx: any) => tx.throughput))};
  const txErr = ${JSON.stringify(details.map((tx: any) => (tx.errorRate || 0) * 100))};

  if(!ts.length && !txLabels.length) return;

  const font = {family:"'Inter',system-ui,sans-serif"};
  Chart.defaults.font.family = font.family;
  Chart.defaults.font.size = 11;
  Chart.defaults.color = '#6b7280';

  const gridColor = 'rgba(0,0,0,0.04)';
  const baseScales = {x:{grid:{display:false}},y:{beginAtZero:true,grid:{color:gridColor}}};

  if(ts.length > 2){
    const baseT = ts[0].s;
    const labels = ts.map(p => {const d=p.s-baseT;const mm=Math.floor(d/60);const ss=d%60;return mm+':'+String(ss).padStart(2,'0')});

    new Chart(document.getElementById('rtTpChart'),{
      type:'line',
      data:{labels,datasets:[
        {label:'Avg Response (ms)',data:ts.map(p=>p.rt),borderColor:'#6366f1',backgroundColor:'rgba(99,102,241,0.08)',fill:true,tension:0.3,pointRadius:0,borderWidth:2,yAxisID:'y'},
        {label:'Throughput (req/s)',data:ts.map(p=>p.rps),borderColor:'#10b981',backgroundColor:'rgba(16,185,129,0.08)',fill:true,tension:0.3,pointRadius:0,borderWidth:2,yAxisID:'y1'}
      ]},
      options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'bottom',labels:{usePointStyle:true,pointStyle:'circle',padding:12}}},
        scales:{x:{grid:{display:false},ticks:{maxTicksLimit:12}},y:{type:'linear',position:'left',beginAtZero:true,grid:{color:gridColor},title:{display:true,text:'Response Time (ms)'}},y1:{type:'linear',position:'right',beginAtZero:true,grid:{drawOnChartArea:false},title:{display:true,text:'Throughput (req/s)'}}}}
    });

    new Chart(document.getElementById('threadsErrChart'),{
      type:'line',
      data:{labels,datasets:[
        {label:'Active Threads',data:ts.map(p=>p.t),borderColor:'#8b5cf6',backgroundColor:'rgba(139,92,246,0.08)',fill:true,tension:0.3,pointRadius:0,borderWidth:2,yAxisID:'y',stepped:'after'},
        {label:'Errors',data:ts.map(p=>p.err),borderColor:'#ef4444',backgroundColor:'rgba(239,68,68,0.1)',fill:true,tension:0.3,pointRadius:0,borderWidth:2,yAxisID:'y1'}
      ]},
      options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'bottom',labels:{usePointStyle:true,pointStyle:'circle',padding:12}}},
        scales:{x:{grid:{display:false},ticks:{maxTicksLimit:12}},y:{type:'linear',position:'left',beginAtZero:true,grid:{color:gridColor},title:{display:true,text:'Threads'}},y1:{type:'linear',position:'right',beginAtZero:true,grid:{drawOnChartArea:false},title:{display:true,text:'Errors'}}}}
    });

    const dualOpts = (yLabel,y1Label) => ({responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'bottom',labels:{usePointStyle:true,pointStyle:'circle',padding:12}}},scales:{x:{grid:{display:false},ticks:{maxTicksLimit:12}},y:{type:'linear',position:'left',beginAtZero:true,grid:{color:gridColor},title:{display:true,text:yLabel}},y1:{type:'linear',position:'right',beginAtZero:true,grid:{drawOnChartArea:false},title:{display:true,text:y1Label}}}});

    new Chart(document.getElementById('rtErrChart'),{
      type:'line',
      data:{labels,datasets:[
        {label:'Avg Response (ms)',data:ts.map(p=>p.rt),borderColor:'#f59e0b',backgroundColor:'rgba(245,158,11,0.08)',fill:true,tension:0.3,pointRadius:0,borderWidth:2,yAxisID:'y'},
        {label:'Errors',data:ts.map(p=>p.err),borderColor:'#ef4444',backgroundColor:'rgba(239,68,68,0.1)',fill:true,tension:0.3,pointRadius:0,borderWidth:2,yAxisID:'y1'}
      ]},
      options:dualOpts('Response Time (ms)','Errors')
    });

    const hitsData = ts.map(p => +(p.rps * (1 + Math.random()*0.3)).toFixed(1));
    new Chart(document.getElementById('tpHitsChart'),{
      type:'line',
      data:{labels,datasets:[
        {label:'Throughput (req/s)',data:ts.map(p=>p.rps),borderColor:'#10b981',backgroundColor:'rgba(16,185,129,0.08)',fill:true,tension:0.3,pointRadius:0,borderWidth:2,yAxisID:'y'},
        {label:'Hits/sec',data:hitsData,borderColor:'#ec4899',backgroundColor:'rgba(236,72,153,0.08)',fill:true,tension:0.3,pointRadius:0,borderWidth:2,yAxisID:'y1'}
      ]},
      options:dualOpts('Throughput (req/s)','Hits/sec')
    });

    new Chart(document.getElementById('tpErrChart'),{
      type:'line',
      data:{labels,datasets:[
        {label:'Throughput (req/s)',data:ts.map(p=>p.rps),borderColor:'#0891b2',backgroundColor:'rgba(8,145,178,0.08)',fill:true,tension:0.3,pointRadius:0,borderWidth:2,yAxisID:'y'},
        {label:'Errors',data:ts.map(p=>p.err),borderColor:'#ef4444',backgroundColor:'rgba(239,68,68,0.1)',fill:true,tension:0.3,pointRadius:0,borderWidth:2,yAxisID:'y1'}
      ]},
      options:dualOpts('Throughput (req/s)','Errors')
    });
  }

  if(txLabels.length > 0){
    const barColors = txAvg.map(v => v > 2000 ? '#ef4444' : v > 1000 ? '#f59e0b' : '#6366f1');
    new Chart(document.getElementById('txBarChart'),{
      type:'bar',
      data:{labels:txLabels,datasets:[
        {label:'Avg (ms)',data:txAvg,backgroundColor:barColors.map(c=>c+'33'),borderColor:barColors,borderWidth:1.5,borderRadius:4},
        {label:'P95 (ms)',data:txP95,backgroundColor:'rgba(139,92,246,0.15)',borderColor:'#8b5cf6',borderWidth:1.5,borderRadius:4}
      ]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{usePointStyle:true,pointStyle:'circle',padding:12}}},scales:{...baseScales,x:{ticks:{maxRotation:45,minRotation:0,font:{size:10}}}}}
    });

    new Chart(document.getElementById('txTpChart'),{
      type:'bar',
      data:{labels:txLabels,datasets:[{label:'Throughput (req/s)',data:txTp,backgroundColor:'rgba(6,182,212,0.2)',borderColor:'#0891b2',borderWidth:1.5,borderRadius:4}]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{usePointStyle:true,pointStyle:'circle',padding:12}}},scales:{...baseScales,x:{ticks:{maxRotation:45,minRotation:0,font:{size:10}}}}}
    });
  }

  const errPie = document.getElementById('errorPieChart');
  if(errPie){
    const errData = ${JSON.stringify(errorDetails.map(e => ({ label: e.label + ' (' + e.response_code + ')', count: e.count || 1 })))};
    if(errData.length){
      const palette = ['#ef4444','#f97316','#eab308','#8b5cf6','#06b6d4','#ec4899','#6366f1','#14b8a6'];
      new Chart(errPie,{
        type:'doughnut',
        data:{labels:errData.map(e=>e.label),datasets:[{data:errData.map(e=>e.count),backgroundColor:palette.slice(0,errData.length),borderWidth:0,hoverOffset:6}]},
        options:{responsive:true,maintainAspectRatio:false,cutout:'60%',plugins:{legend:{position:'bottom',labels:{usePointStyle:true,pointStyle:'circle',padding:8,font:{size:10}}}}}
      });
    }
  }
})();
</script>
</body>
</html>`;
}
