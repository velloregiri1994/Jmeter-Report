import { type Express, type Request, type Response, type NextFunction } from "express";
import rateLimit from "express-rate-limit";
import { db } from "./db";
import { apiTokens, testExecutions, executionSlaRules, scripts } from "@shared/schema";
import { eq, desc, and, isNull } from "drizzle-orm";
import { requireAuth, requireEngineerOrAdmin, requireAdmin } from "./route-middleware";
import { validate, z, idParam } from "./validation";
import { logAudit } from "./audit-logger";
import { storage } from "./storage";
import { queueJMeterRun, generateRunId } from "./jmeter-worker";
import crypto from "crypto";
import bcrypt from "bcrypt";
import { asyncHandler } from "./error-handler";

const cicdTokenLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  message: { message: "Too many CI/CD API requests. Please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer phub_")) {
      const rawToken = authHeader.slice(7);
      return rawToken.slice(5, 13);
    }
    return req.ip || req.socket.remoteAddress || 'unknown';
  },
});

function requireScope(scope: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    const tokenId = (req as any).apiTokenId;
    const tokenScopes: string[] = (req as any).apiTokenScopes || [];
    if (!tokenScopes.includes(scope)) {
      return res.status(403).json({ message: `Token missing required scope: ${scope}` });
    }
    next();
  };
}

async function authenticateApiToken(req: Request, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer phub_")) {
      return res.status(401).json({ message: "Invalid or missing API token" });
    }

    const rawToken = authHeader.slice(7);
    const prefix = rawToken.slice(5, 13);

    const [tokenRecord] = await db
      .select()
      .from(apiTokens)
      .where(and(eq(apiTokens.tokenPrefix, prefix), isNull(apiTokens.revokedAt)));

    if (!tokenRecord) {
      return res.status(401).json({ message: "Invalid or revoked API token" });
    }

    const valid = await bcrypt.compare(rawToken, tokenRecord.tokenHash);
    if (!valid) {
      return res.status(401).json({ message: "Invalid API token" });
    }

    if (tokenRecord.expiresAt && new Date(tokenRecord.expiresAt) < new Date()) {
      return res.status(401).json({ message: "API token has expired" });
    }

    await db
      .update(apiTokens)
      .set({ lastUsedAt: new Date().toISOString() })
      .where(eq(apiTokens.id, tokenRecord.id));

    (req as any).apiTokenUserId = tokenRecord.createdBy;
    (req as any).apiTokenId = tokenRecord.id;
    (req as any).apiTokenScopes = tokenRecord.scopes || [];

    next();
  } catch (error) {
    console.error("[cicd] Token auth error:", error);
    return res.status(401).json({ message: "Authentication failed" });
  }
}

export function registerCicdRoutes(app: Express): void {
  app.get("/api/ci/tokens", requireEngineerOrAdmin, asyncHandler(async (_req: Request, res: Response) => {
    const tokens = await db
      .select({
        id: apiTokens.id,
        name: apiTokens.name,
        description: apiTokens.description,
        tokenPrefix: apiTokens.tokenPrefix,
        scopes: apiTokens.scopes,
        createdBy: apiTokens.createdBy,
        lastUsedAt: apiTokens.lastUsedAt,
        expiresAt: apiTokens.expiresAt,
        revokedAt: apiTokens.revokedAt,
        createdAt: apiTokens.createdAt,
      })
      .from(apiTokens)
      .orderBy(desc(apiTokens.createdAt));

    res.json(tokens);
  }));

  app.post(
    "/api/ci/tokens",
    requireEngineerOrAdmin,
    validate({
      body: z.object({
        name: z.string().min(1, "Token name is required"),
        description: z.string().optional(),
        scopes: z.array(z.enum(["trigger", "status", "results"])).min(1, "At least one scope is required"),
        expiresAt: z.string().optional(),
      }),
    }),
    asyncHandler(async (req: Request, res: Response) => {
      const { name, description, scopes, expiresAt } = req.body;
      const userId = (req.session as any)?.user?.id;

      const rawToken = `phub_${crypto.randomBytes(32).toString("hex")}`;
      const tokenHash = await bcrypt.hash(rawToken, 10);
      const tokenPrefix = rawToken.slice(5, 13);

      const [created] = await db
        .insert(apiTokens)
        .values({
          name,
          description: description || null,
          tokenHash,
          tokenPrefix,
          scopes,
          createdBy: userId,
          expiresAt: expiresAt || null,
        })
        .returning();

      logAudit(req, "api_token_create", "api_token", created.id, { name, scopes });

      res.status(201).json({
        id: created.id,
        name: created.name,
        description: created.description,
        tokenPrefix: created.tokenPrefix,
        scopes: created.scopes,
        createdBy: created.createdBy,
        expiresAt: created.expiresAt,
        createdAt: created.createdAt,
        token: rawToken,
      });
    })
  );

  app.delete(
    "/api/ci/tokens/:id",
    requireEngineerOrAdmin,
    validate({ params: idParam }),
    asyncHandler(async (req: Request, res: Response) => {
      const id = req.params.id as unknown as number;
      const force = req.query.force === "true";

      if (force) {
        const [deleted] = await db
          .delete(apiTokens)
          .where(eq(apiTokens.id, id))
          .returning();

        if (!deleted) {
          return res.status(404).json({ message: "Token not found" });
        }

        logAudit(req, "api_token_delete", "api_token", id);
        res.json({ message: "Token deleted permanently" });
      } else {
        const [updated] = await db
          .update(apiTokens)
          .set({ revokedAt: new Date().toISOString() })
          .where(eq(apiTokens.id, id))
          .returning();

        if (!updated) {
          return res.status(404).json({ message: "Token not found" });
        }

        logAudit(req, "api_token_revoke", "api_token", id);
        res.json({ message: "Token revoked" });
      }
    })
  );

  app.post(
    "/api/ci/trigger",
    cicdTokenLimiter,
    authenticateApiToken,
    requireScope("trigger"),
    validate({
      body: z.object({
        scriptId: z.number().int().positive("scriptId is required"),
        config: z
          .object({
            vusers: z.number().int().positive().optional(),
            rampUp: z.number().int().positive().optional(),
            duration: z.number().int().positive().optional(),
            environment: z.string().optional(),
          })
          .optional(),
        releaseTag: z.string().max(100).optional(),
      }),
    }),
    asyncHandler(async (req: Request, res: Response) => {
      const { scriptId, config, releaseTag } = req.body;
      const userId = (req as any).apiTokenUserId;

      const script = await storage.getScript(scriptId);
      if (!script) {
        return res.status(404).json({ message: "Script not found" });
      }

      if (!script.filePath) {
        return res.status(400).json({ message: "Script has no file uploaded" });
      }

      const runId = generateRunId();
      const executionId = `CI-${runId}`;

      const execution = await storage.createExecution({
        executionId,
        scheduleId: null,
        scriptId,
        status: "queued",
        startTime: null,
        endTime: null,
        resultSummary: null,
        artifactsPath: null,
        reportHtmlPath: null,
        reportComments: null,
        liveMetrics: null,
        environment: config?.environment || null,
        releaseTag: releaseTag?.trim() || null,
      } as any);

      queueJMeterRun(execution.id, {
        executionId,
        jmxPath: script.filePath,
        dependencyFiles: script.dependencyFiles || [],
        jarFiles: script.jarFiles || [],
        vusers: config?.vusers,
        rampUp: config?.rampUp,
        duration: config?.duration,
      });

      logAudit(req, "ci_trigger", "execution", execution.id, {
        scriptId,
        runId,
        config,
      });

      res.status(201).json({
        executionId: execution.id,
        runId,
        status: "queued",
        statusUrl: `/api/ci/status/${execution.id}`,
      });
    })
  );

  app.get(
    "/api/ci/status/:id",
    cicdTokenLimiter,
    authenticateApiToken,
    requireScope("status"),
    validate({ params: idParam }),
    asyncHandler(async (req: Request, res: Response) => {
      const id = req.params.id as unknown as number;

      const execution = await storage.getExecution(id);
      if (!execution) {
        return res.status(404).json({ message: "Execution not found" });
      }

      const summary: any = execution.resultSummary || {};

      let sla: { passed: boolean; rules: any[] } = { passed: true, rules: [] };

      if (execution.status === "completed" || execution.status === "failed") {
        const slaRules = await storage.getExecutionSlaRules(execution.id);

        if (slaRules.length > 0) {
          const evaluatedRules = slaRules.map((rule) => {
            let actualValue: number | undefined;

            if (rule.transactionLabel) {
              const tx = summary.transactionDetails?.find(
                (t: any) => t.label === rule.transactionLabel
              );
              if (tx) {
                actualValue = getMetricValue(tx, rule.metric);
              }
            } else {
              actualValue = getGlobalMetricValue(summary, rule.metric);
            }

            let passed = true;
            if (actualValue !== undefined) {
              passed = !evaluateViolation(actualValue, rule.threshold, rule.comparator);
            }

            return {
              metric: rule.metric,
              comparator: rule.comparator,
              threshold: rule.threshold,
              actual: actualValue ?? null,
              transactionLabel: rule.transactionLabel || "Global",
              passed,
            };
          });

          sla = {
            passed: evaluatedRules.every((r) => r.passed),
            rules: evaluatedRules,
          };
        }
      }

      let gate: { verdict: "pass" | "fail" | "pending"; exitCode: number; reason: string; evaluatedAt: string | null; failedRules: string[] } = {
        verdict: "pending",
        exitCode: -1,
        reason: "Test is still in progress",
        evaluatedAt: null,
        failedRules: [],
      };

      if (execution.status === "completed" || execution.status === "failed") {
        const failedDescriptions = sla.rules
          .filter((r) => !r.passed)
          .map((r) => `${r.transactionLabel} ${r.metric} ${r.comparator} ${r.threshold} (actual: ${r.actual ?? "N/A"})`);

        if (execution.status === "failed") {
          gate = {
            verdict: "fail",
            exitCode: 1,
            reason: "Test execution failed",
            evaluatedAt: new Date().toISOString(),
            failedRules: failedDescriptions,
          };
        } else if (!sla.passed) {
          gate = {
            verdict: "fail",
            exitCode: 1,
            reason: `${failedDescriptions.length} SLA rule(s) violated`,
            evaluatedAt: new Date().toISOString(),
            failedRules: failedDescriptions,
          };
        } else {
          gate = {
            verdict: "pass",
            exitCode: 0,
            reason: sla.rules.length > 0 ? `All ${sla.rules.length} SLA rule(s) passed` : "Test completed successfully (no SLA rules defined)",
            evaluatedAt: new Date().toISOString(),
            failedRules: [],
          };
        }
      } else if (execution.status === "aborted" || execution.status === "cancelled") {
        gate = {
          verdict: "fail",
          exitCode: 1,
          reason: `Test was ${execution.status}`,
          evaluatedAt: new Date().toISOString(),
          failedRules: [],
        };
      }

      res.json({
        executionId: execution.id,
        status: execution.status,
        startTime: execution.startTime,
        endTime: execution.endTime,
        metrics: {
          avgResponseTime: summary.avgResponseTime ?? null,
          p95: summary.p95 ?? null,
          errorRate: summary.errorRate ?? null,
          throughput: summary.throughput ?? null,
        },
        sla,
        gate,
      });
    })
  );
}

function getMetricValue(tx: any, metric: string): number | undefined {
  switch (metric) {
    case "avg":
      return tx.avg;
    case "p90":
      return tx.p90;
    case "p95":
      return tx.p95;
    case "p99":
      return tx.p99;
    case "max":
      return tx.max;
    case "errorRate":
      return tx.errorRate;
    case "throughput":
      return tx.throughput;
    default:
      return undefined;
  }
}

function getGlobalMetricValue(summary: any, metric: string): number | undefined {
  switch (metric) {
    case "avg":
      return summary.avgResponseTime;
    case "p90":
      return summary.p90;
    case "p95":
      return summary.p95;
    case "p99":
      return summary.p99;
    case "max":
      return summary.maxResponseTime;
    case "errorRate":
      return summary.errorRate;
    case "throughput":
      return summary.throughput;
    default:
      return undefined;
  }
}

function evaluateViolation(actual: number, threshold: number, comparator: string): boolean {
  switch (comparator) {
    case "lt":
      return actual >= threshold;
    case "lte":
      return actual > threshold;
    case "gt":
      return actual <= threshold;
    case "gte":
      return actual < threshold;
    default:
      return false;
  }
}
