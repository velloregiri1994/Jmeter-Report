import { db } from "./db";
import { executionMetricBuckets } from "@shared/schema";
import { sql, eq } from "drizzle-orm";
import fs from "fs";
import path from "path";
import { mergeHistogramCounts, percentileFromHistogramCounts } from "./live-metrics/fixed-histogram";

interface BucketLabel {
  count: number;
  error_count: number;
  sum_elapsed: number;
  min_elapsed: number;
  max_elapsed: number;
  centroids: number[] | number[][] | null;
}

interface FileBucket {
  start_ms: number;
  count: number;
  error_count: number;
  sum_elapsed: number;
  min_elapsed: number;
  max_elapsed: number;
  centroids: number[] | number[][] | null;
  active_threads: number | null;
  labels: Record<string, BucketLabel>;
}

interface BucketsFile {
  bucket_width_ms: number;
  min_ts: number | null;
  max_ts: number | null;
  bucket_count: number;
  buckets: FileBucket[];
}

type InsertRow = typeof executionMetricBuckets.$inferInsert;

const BATCH_SIZE = 500;

export async function persistBucketsFromFile(executionId: number, artifactsPath: string): Promise<number> {
  const bucketsPath = path.join(artifactsPath, "buckets.json");
  if (!fs.existsSync(bucketsPath)) return 0;

  const raw = await fs.promises.readFile(bucketsPath, "utf-8");
  const bucketsFile: BucketsFile = JSON.parse(raw);

  const allRows: InsertRow[] = [];

  for (const b of bucketsFile.buckets) {
    allRows.push({
      executionId,
      bucketTimeMs: b.start_ms,
      transactionLabel: null,
      count: b.count,
      errorCount: b.error_count,
      sumElapsed: b.sum_elapsed,
      minElapsed: b.min_elapsed,
      maxElapsed: b.max_elapsed,
      activeThreads: b.active_threads ?? null,
      p50: null,
      p90: null,
      p95: null,
      p99: null,
      centroids: b.centroids,
    });

    for (const [label, lb] of Object.entries(b.labels)) {
      allRows.push({
        executionId,
        bucketTimeMs: b.start_ms,
        transactionLabel: label,
        count: lb.count,
        errorCount: lb.error_count,
        sumElapsed: lb.sum_elapsed,
        minElapsed: lb.min_elapsed,
        maxElapsed: lb.max_elapsed,
        activeThreads: null,
        p50: null,
        p90: null,
        p95: null,
        p99: null,
        centroids: lb.centroids,
      });
    }
  }

  await db.transaction(async (tx) => {
    await tx.delete(executionMetricBuckets).where(eq(executionMetricBuckets.executionId, executionId));
    for (let i = 0; i < allRows.length; i += BATCH_SIZE) {
      const batch = allRows.slice(i, i + BATCH_SIZE);
      await tx.insert(executionMetricBuckets).values(batch);
    }
  });

  return allRows.length;
}

export async function deleteExecutionBuckets(executionId: number): Promise<void> {
  await db.delete(executionMetricBuckets).where(eq(executionMetricBuckets.executionId, executionId));
}

function isHistogramSparse(raw: unknown): raw is number[] {
  if (!Array.isArray(raw) || raw.length === 0) return false;
  return typeof raw[0] === "number";
}

function legacyCentroidsToSparse(centroids: number[][]): number[] {
  const hist = new Map<number, number>();
  for (const [mean, count] of centroids) {
    const idx = Math.min(Math.round(mean), 60000);
    hist.set(idx, (hist.get(idx) || 0) + count);
  }
  const sparse: number[] = [];
  for (const idx of [...hist.keys()].sort((a, b) => a - b)) {
    sparse.push(idx, hist.get(idx)!);
  }
  return sparse;
}

function toSparseHistogram(raw: unknown): number[] {
  if (!raw) return [];
  if (isHistogramSparse(raw)) return raw;
  if (Array.isArray(raw) && raw.length > 0 && Array.isArray(raw[0])) {
    return legacyCentroidsToSparse(raw as number[][]);
  }
  return [];
}

function computePercentile(raw: unknown, p: number): number {
  const sparse = toSparseHistogram(raw);
  return percentileFromHistogramCounts(sparse, p * 100);
}

function mergeSparseArrays(rawList: unknown[]): number[] {
  const sparseArrays: number[][] = [];
  for (const raw of rawList) {
    const s = toSparseHistogram(raw);
    if (s.length > 0) sparseArrays.push(s);
  }
  return mergeHistogramCounts(sparseArrays);
}

interface MergedStats {
  totalRequests: number;
  errorCount: number;
  errorRate: number;
  avgResponseTime: number;
  minResponseTime: number;
  maxResponseTime: number;
  throughput: number;
  p50: number;
  p90: number;
  p95: number;
  p99: number;
  durationSeconds: number;
}

interface MergedLabel {
  label: string;
  count: number;
  errorCount: number;
  errorRate: number;
  avg: number;
  min: number;
  max: number;
  p50: number;
  p90: number;
  p95: number;
  p99: number;
  throughput: number;
}

interface TimeseriesPoint {
  sec: number;
  rps: number;
  avg_ms: number;
  active_threads: number | null;
  errors: number;
  p50: number | null;
  p90: number | null;
  p95: number | null;
  p99: number | null;
}

export interface FilteredMetrics {
  summary: MergedStats;
  transactionDetails: MergedLabel[];
  timeseries: TimeseriesPoint[];
  startTime: number;
  endTime: number;
  bucketCount: number;
  totalBuckets: number;
}

const BUCKET_WIDTH_MS = 5000;

export async function queryFilteredMetrics(
  executionId: number,
  startMs?: number,
  endMs?: number
): Promise<FilteredMetrics | null> {
  const totalCountResult = await db.select({ cnt: sql<number>`count(distinct ${executionMetricBuckets.bucketTimeMs})` })
    .from(executionMetricBuckets)
    .where(sql`${executionMetricBuckets.executionId} = ${executionId} AND ${executionMetricBuckets.transactionLabel} IS NULL`);

  const totalBuckets = Number(totalCountResult[0]?.cnt ?? 0);
  if (totalBuckets === 0) return null;

  const conditions = [sql`${executionMetricBuckets.executionId} = ${executionId}`];
  if (startMs !== undefined && endMs !== undefined) {
    conditions.push(sql`${executionMetricBuckets.bucketTimeMs} + ${BUCKET_WIDTH_MS} > ${startMs}`);
    conditions.push(sql`${executionMetricBuckets.bucketTimeMs} < ${endMs}`);
  }

  const rows = await db.select()
    .from(executionMetricBuckets)
    .where(sql.join(conditions, sql` AND `))
    .orderBy(executionMetricBuckets.bucketTimeMs);

  if (rows.length === 0) {
    return {
      summary: { totalRequests: 0, errorCount: 0, errorRate: 0, avgResponseTime: 0, minResponseTime: 0, maxResponseTime: 0, throughput: 0, p50: 0, p90: 0, p95: 0, p99: 0, durationSeconds: 0 },
      transactionDetails: [],
      timeseries: [],
      startTime: startMs || 0,
      endTime: endMs || 0,
      bucketCount: 0,
      totalBuckets,
    };
  }

  let totalCount = 0;
  let totalErrors = 0;
  let totalSumElapsed = 0;
  let globalMin = Infinity;
  let globalMax = -Infinity;
  const globalHistList: unknown[] = [];

  const labelAgg: Record<string, {
    count: number;
    errorCount: number;
    sumElapsed: number;
    min: number;
    max: number;
    histList: unknown[];
  }> = {};

  const timeseries: TimeseriesPoint[] = [];
  const seenBucketTimes = new Set<number>();

  for (const row of rows) {
    if (row.transactionLabel === null) {
      totalCount += row.count;
      totalErrors += row.errorCount;
      totalSumElapsed += row.sumElapsed;
      globalMin = Math.min(globalMin, row.minElapsed);
      globalMax = Math.max(globalMax, row.maxElapsed);
      globalHistList.push(row.centroids);

      const bucketSec = Math.floor(row.bucketTimeMs / 1000);
      const durationSec = BUCKET_WIDTH_MS / 1000;
      timeseries.push({
        sec: bucketSec,
        rps: Math.round((row.count / durationSec) * 100) / 100,
        avg_ms: row.count > 0 ? Math.round((row.sumElapsed / row.count) * 100) / 100 : 0,
        active_threads: row.activeThreads,
        errors: row.errorCount,
        p50: row.p50 ?? computePercentile(row.centroids, 0.5),
        p90: row.p90 ?? computePercentile(row.centroids, 0.9),
        p95: row.p95 ?? computePercentile(row.centroids, 0.95),
        p99: row.p99 ?? computePercentile(row.centroids, 0.99),
      });
      seenBucketTimes.add(row.bucketTimeMs);
    } else {
      const label = row.transactionLabel;
      if (!labelAgg[label]) {
        labelAgg[label] = { count: 0, errorCount: 0, sumElapsed: 0, min: Infinity, max: -Infinity, histList: [] };
      }
      const la = labelAgg[label];
      la.count += row.count;
      la.errorCount += row.errorCount;
      la.sumElapsed += row.sumElapsed;
      la.min = Math.min(la.min, row.minElapsed);
      la.max = Math.max(la.max, row.maxElapsed);
      la.histList.push(row.centroids);
    }
  }

  const bucketCount = seenBucketTimes.size;

  const sortedTimes = Array.from(seenBucketTimes).sort((a, b) => a - b);
  const rangeStartMs = sortedTimes[0];
  const rangeEndMs = sortedTimes[sortedTimes.length - 1] + BUCKET_WIDTH_MS;
  const durationSeconds = Math.max(1, (rangeEndMs - rangeStartMs) / 1000);

  const mergedGlobal = mergeSparseArrays(globalHistList);

  const summary: MergedStats = {
    totalRequests: totalCount,
    errorCount: totalErrors,
    errorRate: totalCount > 0 ? totalErrors / totalCount : 0,
    avgResponseTime: totalCount > 0 ? Math.floor(totalSumElapsed / totalCount) : 0,
    minResponseTime: globalMin === Infinity ? 0 : globalMin,
    maxResponseTime: globalMax === -Infinity ? 0 : globalMax,
    throughput: totalCount / durationSeconds,
    p50: percentileFromHistogramCounts(mergedGlobal, 50),
    p90: percentileFromHistogramCounts(mergedGlobal, 90),
    p95: percentileFromHistogramCounts(mergedGlobal, 95),
    p99: percentileFromHistogramCounts(mergedGlobal, 99),
    durationSeconds,
  };

  const transactionDetails: MergedLabel[] = Object.entries(labelAgg).map(([label, la]) => {
    const labelHist = mergeSparseArrays(la.histList);
    return {
      label,
      count: la.count,
      errorCount: la.errorCount,
      errorRate: la.count > 0 ? la.errorCount / la.count : 0,
      avg: la.count > 0 ? Math.floor(la.sumElapsed / la.count) : 0,
      min: la.min === Infinity ? 0 : la.min,
      max: la.max === -Infinity ? 0 : la.max,
      p50: percentileFromHistogramCounts(labelHist, 50),
      p90: percentileFromHistogramCounts(labelHist, 90),
      p95: percentileFromHistogramCounts(labelHist, 95),
      p99: percentileFromHistogramCounts(labelHist, 99),
      throughput: la.count / durationSeconds,
    };
  });

  return {
    summary,
    transactionDetails,
    timeseries,
    startTime: rangeStartMs,
    endTime: rangeEndMs,
    bucketCount,
    totalBuckets,
  };
}
