export interface GcPauseEvent {
  timestamp: number;
  type: 'minor' | 'major' | 'mixed' | 'full';
  pauseTimeMs: number;
  heapBeforeKB: number;
  heapAfterKB: number;
  heapTotalKB: number;
  youngBeforeKB?: number;
  youngAfterKB?: number;
  oldBeforeKB?: number;
  oldAfterKB?: number;
}

export interface GcPerformanceMetrics {
  maxGcPauseTimeMs: number;
  avgGcPauseTimeMs: number;
  totalPauseTimeMs: number;
  gcThroughputPct: number;
  minorGcRate: number;
  majorGcRate: number;
  heapUsedBytes: number;
  heapCommittedBytes: number;
  heapMaxBytes: number;
  allocationRateMBps: number;
  promotionRateMBps: number;
  reclaimedPerCycleKB: number;
  totalGcEvents: number;
  minorGcCount: number;
  majorGcCount: number;
  pauseDistribution: { range: string; count: number }[];
  source: 'gc_log' | 'heap_estimate';
}

export function parseGcLog(content: string): GcPerformanceMetrics {
  const lines = content.split('\n');
  const events: GcPauseEvent[] = [];

  let firstTimestamp = Infinity;
  let lastTimestamp = 0;

  for (const line of lines) {
    const event = parseGcLine(line);
    if (event) {
      events.push(event);
      if (event.timestamp >= 0) {
        if (event.timestamp < firstTimestamp) firstTimestamp = event.timestamp;
        if (event.timestamp > lastTimestamp) lastTimestamp = event.timestamp;
      }
    }
  }

  if (firstTimestamp === Infinity) firstTimestamp = 0;

  if (events.length === 0) {
    return emptyMetrics('gc_log');
  }

  const pauseTimes = events.map(e => e.pauseTimeMs);
  const maxGcPauseTimeMs = Math.max(...pauseTimes);
  const avgGcPauseTimeMs = pauseTimes.reduce((a, b) => a + b, 0) / pauseTimes.length;
  const totalPauseTimeMs = pauseTimes.reduce((a, b) => a + b, 0);

  const rawDuration = lastTimestamp - firstTimestamp;
  const durationSec = rawDuration > 0 ? rawDuration : Math.max(1, totalPauseTimeMs / 1000 * 10);
  const gcThroughputPct = Math.max(0, ((durationSec * 1000 - totalPauseTimeMs) / (durationSec * 1000)) * 100);

  const minorEvents = events.filter(e => e.type === 'minor' || e.type === 'mixed');
  const majorEvents = events.filter(e => e.type === 'major' || e.type === 'full');

  const minorGcRate = durationSec > 0 ? (minorEvents.length / durationSec) * 60 : 0;
  const majorGcRate = durationSec > 0 ? (majorEvents.length / durationSec) * 60 : 0;

  const lastEvent = events[events.length - 1];
  const heapUsedBytes = lastEvent.heapAfterKB * 1024;
  const heapCommittedBytes = lastEvent.heapTotalKB * 1024;
  const heapMaxBytes = Math.max(...events.map(e => e.heapTotalKB)) * 1024;

  let totalAllocated = 0;
  let totalPromoted = 0;
  for (let i = 1; i < events.length; i++) {
    const prev = events[i - 1];
    const curr = events[i];
    const allocated = curr.heapBeforeKB - prev.heapAfterKB;
    if (allocated > 0) totalAllocated += allocated;

    if (curr.oldAfterKB !== undefined && prev.oldAfterKB !== undefined) {
      const promoted = curr.oldAfterKB - prev.oldAfterKB;
      if (promoted > 0) totalPromoted += promoted;
    } else if (curr.youngBeforeKB !== undefined && curr.youngAfterKB !== undefined) {
      const youngReclaimed = curr.youngBeforeKB - curr.youngAfterKB;
      const heapReclaimed = curr.heapBeforeKB - curr.heapAfterKB;
      const promoted = youngReclaimed - heapReclaimed;
      if (promoted > 0) totalPromoted += promoted;
    }
  }

  const allocationRateMBps = durationSec > 0 ? (totalAllocated / 1024) / durationSec : 0;
  const promotionRateMBps = durationSec > 0 ? (totalPromoted / 1024) / durationSec : 0;

  const totalReclaimed = events.reduce((sum, e) => sum + Math.max(0, e.heapBeforeKB - e.heapAfterKB), 0);
  const reclaimedPerCycleKB = events.length > 0 ? totalReclaimed / events.length : 0;

  const pauseDistribution = computePauseDistribution(pauseTimes);

  return {
    maxGcPauseTimeMs,
    avgGcPauseTimeMs,
    totalPauseTimeMs,
    gcThroughputPct,
    minorGcRate,
    majorGcRate,
    heapUsedBytes,
    heapCommittedBytes,
    heapMaxBytes,
    allocationRateMBps,
    promotionRateMBps,
    reclaimedPerCycleKB,
    totalGcEvents: events.length,
    minorGcCount: minorEvents.length,
    majorGcCount: majorEvents.length,
    pauseDistribution,
    source: 'gc_log',
  };
}

function parseGcLine(line: string): GcPauseEvent | null {
  const g1DetailPattern = /\[(\d+\.\d+)s\].*GC\((\d+)\)\s+Pause\s+(Young|Mixed|Full|Remark|Cleanup).*?(\d+)M->(\d+)M\((\d+)M\).*?(\d+\.\d+)ms/;
  let match = line.match(g1DetailPattern);
  if (match) {
    const gcType = match[3];
    let type: GcPauseEvent['type'] = 'minor';
    if (gcType === 'Full') type = 'full';
    else if (gcType === 'Mixed') type = 'mixed';
    else if (gcType === 'Remark' || gcType === 'Cleanup') type = 'major';

    const heapBeforeMB = parseInt(match[4]);
    const heapAfterMB = parseInt(match[5]);
    const heapTotalMB = parseInt(match[6]);

    const estYoungFraction = type === 'minor' ? 0.33 : type === 'mixed' ? 0.5 : 1.0;
    const heapReclaimedMB = heapBeforeMB - heapAfterMB;
    const estYoungBeforeMB = Math.round(heapBeforeMB * estYoungFraction);
    const estYoungAfterMB = Math.round(Math.max(0, estYoungBeforeMB - heapReclaimedMB * 0.9));
    const estOldAfterMB = heapAfterMB - estYoungAfterMB;

    return {
      timestamp: parseFloat(match[1]),
      type,
      pauseTimeMs: parseFloat(match[7]),
      heapBeforeKB: heapBeforeMB * 1024,
      heapAfterKB: heapAfterMB * 1024,
      heapTotalKB: heapTotalMB * 1024,
      youngBeforeKB: estYoungBeforeMB * 1024,
      youngAfterKB: estYoungAfterMB * 1024,
      oldAfterKB: Math.max(0, estOldAfterMB) * 1024,
    };
  }

  const parallelPattern = /(\d+\.\d+):\s+\[GC\s*(?:\(([^)]+)\))?\s+\[(?:PSYoungGen|ParNew|DefNew):\s+(\d+)K->(\d+)K\(\d+K\)\]\s+(\d+)K->(\d+)K\((\d+)K\),\s+(\d+\.\d+)\s+secs/;
  match = line.match(parallelPattern);
  if (match) {
    return {
      timestamp: parseFloat(match[1]),
      type: 'minor',
      pauseTimeMs: parseFloat(match[8]) * 1000,
      heapBeforeKB: parseInt(match[5]),
      heapAfterKB: parseInt(match[6]),
      heapTotalKB: parseInt(match[7]),
      youngBeforeKB: parseInt(match[3]),
      youngAfterKB: parseInt(match[4]),
    };
  }

  const fullGcPattern = /(\d+\.\d+):\s+\[Full\s+GC\s*(?:\(([^)]+)\))?\s+(\d+)K->(\d+)K\((\d+)K\),\s+(\d+\.\d+)\s+secs/;
  match = line.match(fullGcPattern);
  if (match) {
    return {
      timestamp: parseFloat(match[1]),
      type: 'full',
      pauseTimeMs: parseFloat(match[6]) * 1000,
      heapBeforeKB: parseInt(match[3]),
      heapAfterKB: parseInt(match[4]),
      heapTotalKB: parseInt(match[5]),
    };
  }

  const jdk17Unified = /\[(\d+\.\d+)s\].*?GC\(\d+\)\s+Pause\s+(Young|Old|Full|Mixed).*?(\d+)M->(\d+)M\((\d+)M\)\s+(\d+\.\d+)ms/;
  match = line.match(jdk17Unified);
  if (match) {
    let type: GcPauseEvent['type'] = 'minor';
    if (match[2] === 'Old' || match[2] === 'Full') type = 'full';
    else if (match[2] === 'Mixed') type = 'mixed';

    const hBeforeMB = parseInt(match[3]);
    const hAfterMB = parseInt(match[4]);
    const hTotalMB = parseInt(match[5]);
    const yFrac = type === 'minor' ? 0.33 : type === 'mixed' ? 0.5 : 1.0;
    const reclMB = hBeforeMB - hAfterMB;
    const yBefore = Math.round(hBeforeMB * yFrac);
    const yAfter = Math.round(Math.max(0, yBefore - reclMB * 0.9));

    return {
      timestamp: parseFloat(match[1]),
      type,
      pauseTimeMs: parseFloat(match[6]),
      heapBeforeKB: hBeforeMB * 1024,
      heapAfterKB: hAfterMB * 1024,
      heapTotalKB: hTotalMB * 1024,
      youngBeforeKB: yBefore * 1024,
      youngAfterKB: yAfter * 1024,
      oldAfterKB: Math.max(0, hAfterMB - yAfter) * 1024,
    };
  }

  const genericPause = /(?:real|elapsed)=(\d+\.\d+)/;
  const heapChange = /(\d+)K->(\d+)K\((\d+)K\)/;
  const timestampPrefix = /^(\d+\.\d+):/;
  const hMatch = line.match(heapChange);
  const pMatch = line.match(genericPause);
  if (hMatch && pMatch) {
    const isFull = /Full GC|Major|Old/i.test(line);
    const tMatch = line.match(timestampPrefix);
    return {
      timestamp: tMatch ? parseFloat(tMatch[1]) : -1,
      type: isFull ? 'full' : 'minor',
      pauseTimeMs: parseFloat(pMatch[1]) * 1000,
      heapBeforeKB: parseInt(hMatch[1]),
      heapAfterKB: parseInt(hMatch[2]),
      heapTotalKB: parseInt(hMatch[3]),
    };
  }

  return null;
}

function computePauseDistribution(pauseTimes: number[]): { range: string; count: number }[] {
  const buckets = [
    { range: '0-10ms', min: 0, max: 10, count: 0 },
    { range: '10-50ms', min: 10, max: 50, count: 0 },
    { range: '50-100ms', min: 50, max: 100, count: 0 },
    { range: '100-500ms', min: 100, max: 500, count: 0 },
    { range: '500ms-1s', min: 500, max: 1000, count: 0 },
    { range: '>1s', min: 1000, max: Infinity, count: 0 },
  ];

  for (const time of pauseTimes) {
    for (const bucket of buckets) {
      if (time >= bucket.min && time < bucket.max) {
        bucket.count++;
        break;
      }
    }
  }

  return buckets.filter(b => b.count > 0).map(b => ({ range: b.range, count: b.count }));
}

export function estimateGcMetricsFromHeap(
  usedHeapSize: number,
  totalHeapSize: number,
  totalInstances: number,
  shortLivedCount: number,
  longLivedCount: number,
  estimatedYoungGenSize: number,
  estimatedOldGenSize: number,
  finalizerCount: number
): GcPerformanceMetrics {
  const utilizationPct = totalHeapSize > 0 ? (usedHeapSize / totalHeapSize) * 100 : 0;

  const estMinorGcFreq = shortLivedCount > 10000 ? 12 : shortLivedCount > 5000 ? 8 : shortLivedCount > 1000 ? 4 : 2;
  const estMajorGcFreq = utilizationPct > 80 ? 2 : utilizationPct > 60 ? 0.5 : 0.1;

  const estMinorPauseMs = estimatedYoungGenSize > 100 * 1024 * 1024 ? 50 :
    estimatedYoungGenSize > 50 * 1024 * 1024 ? 30 :
    estimatedYoungGenSize > 10 * 1024 * 1024 ? 15 : 8;

  const estMajorPauseMs = estimatedOldGenSize > 500 * 1024 * 1024 ? 800 :
    estimatedOldGenSize > 200 * 1024 * 1024 ? 400 :
    estimatedOldGenSize > 50 * 1024 * 1024 ? 150 : 50;

  const maxGcPauseTimeMs = Math.max(estMajorPauseMs, estMinorPauseMs * 2);
  const avgGcPauseTimeMs = (estMinorPauseMs * estMinorGcFreq + estMajorPauseMs * estMajorGcFreq) /
    Math.max(1, estMinorGcFreq + estMajorGcFreq);
  const totalPauseTimeMs = estMinorPauseMs * estMinorGcFreq + estMajorPauseMs * estMajorGcFreq;

  const gcThroughputPct = Math.max(0, (1 - totalPauseTimeMs / 60000) * 100);

  const heapMaxBytes = Math.round(totalHeapSize * 1.25);

  const estYoungGenSizeMB = estimatedYoungGenSize / (1024 * 1024);
  const allocationRateMBps = estYoungGenSizeMB * estMinorGcFreq / 60;

  const promotionRatio = longLivedCount > 0 ? Math.min(0.15, longLivedCount / Math.max(1, totalInstances)) : 0.05;
  const promotionRateMBps = allocationRateMBps * promotionRatio;

  const reclaimedPerCycleKB = estimatedYoungGenSize > 0
    ? (estimatedYoungGenSize * 0.85) / 1024
    : (usedHeapSize * 0.1) / 1024;

  return {
    maxGcPauseTimeMs: Math.round(maxGcPauseTimeMs * 10) / 10,
    avgGcPauseTimeMs: Math.round(avgGcPauseTimeMs * 10) / 10,
    totalPauseTimeMs: Math.round(totalPauseTimeMs * 10) / 10,
    gcThroughputPct: Math.round(gcThroughputPct * 100) / 100,
    minorGcRate: Math.round(estMinorGcFreq * 10) / 10,
    majorGcRate: Math.round(estMajorGcFreq * 100) / 100,
    heapUsedBytes: usedHeapSize,
    heapCommittedBytes: totalHeapSize,
    heapMaxBytes,
    allocationRateMBps: Math.round(allocationRateMBps * 100) / 100,
    promotionRateMBps: Math.round(promotionRateMBps * 100) / 100,
    reclaimedPerCycleKB: Math.round(reclaimedPerCycleKB),
    totalGcEvents: estMinorGcFreq + Math.round(estMajorGcFreq),
    minorGcCount: estMinorGcFreq,
    majorGcCount: Math.round(estMajorGcFreq),
    pauseDistribution: [
      { range: '0-10ms', count: Math.round(estMinorGcFreq * 0.3) },
      { range: '10-50ms', count: Math.round(estMinorGcFreq * 0.7) },
      { range: '100-500ms', count: Math.round(estMajorGcFreq) },
    ].filter(d => d.count > 0),
    source: 'heap_estimate',
  };
}

function emptyMetrics(source: 'gc_log' | 'heap_estimate'): GcPerformanceMetrics {
  return {
    maxGcPauseTimeMs: 0,
    avgGcPauseTimeMs: 0,
    totalPauseTimeMs: 0,
    gcThroughputPct: 100,
    minorGcRate: 0,
    majorGcRate: 0,
    heapUsedBytes: 0,
    heapCommittedBytes: 0,
    heapMaxBytes: 0,
    allocationRateMBps: 0,
    promotionRateMBps: 0,
    reclaimedPerCycleKB: 0,
    totalGcEvents: 0,
    minorGcCount: 0,
    majorGcCount: 0,
    pauseDistribution: [],
    source,
  };
}
