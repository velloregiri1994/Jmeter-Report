import type { 
  ThreadInfo, 
  DeadlockInfo, 
  HotspotInfo, 
  StackCluster, 
  ContentionInfo,
  DetectedIssue 
} from "@shared/schema";

interface ThreadDumpAnalysis {
  threadSummary: {
    totalThreads: number;
    runnable: number;
    blocked: number;
    waiting: number;
    timedWaiting: number;
    terminated: number;
    daemonCount: number;
  };
  threads: ThreadInfo[];
  deadlocks: DeadlockInfo[];
  hotspots: HotspotInfo[];
  stackClusters: StackCluster[];
  contentionInfo: ContentionInfo[];
  detectedIssues: DetectedIssue[];
}

interface GcThreadMetrics {
  total: number;
  types: { name: string; count: number }[];
  totalCpuMs: number;
  gcOverheadPct: number;
  threads: { name: string; cpuMs: number; state: string }[];
}

export function parseThreadDump(content: string): ThreadDumpAnalysis & { gcMetrics: { gcThreads: GcThreadMetrics; recommendations: string[] } } {
  const threads = parseThreads(content);
  const threadSummary = calculateThreadSummary(threads);
  const deadlocks = detectDeadlocks(threads);
  const hotspots = findHotspots(threads);
  const stackClusters = clusterStackTraces(threads);
  const contentionInfo = analyzeContention(threads);
  const gcMetrics = analyzeGcThreads(content, threads);
  const detectedIssues = detectIssues(threads, threadSummary, deadlocks, stackClusters, contentionInfo);

  return {
    threadSummary,
    threads,
    deadlocks,
    hotspots,
    stackClusters,
    contentionInfo,
    detectedIssues,
    gcMetrics,
  };
}

function detectIssues(
  threads: ThreadInfo[],
  summary: ThreadDumpAnalysis['threadSummary'],
  deadlocks: DeadlockInfo[],
  clusters: StackCluster[],
  contention: ContentionInfo[]
): DetectedIssue[] {
  const issues: DetectedIssue[] = [];

  for (const dl of deadlocks) {
    issues.push({
      type: 'deadlock',
      severity: 'critical',
      description: `Circular lock dependency detected among ${dl.cycle.length} threads: ${dl.cycle.join(' → ')} → ${dl.cycle[0]}`,
      relatedThreads: dl.cycle,
    });
  }

  if (summary.totalThreads > 0) {
    const blockedPct = (summary.blocked / summary.totalThreads) * 100;
    if (blockedPct > 50) {
      issues.push({
        type: 'high_blocked_ratio',
        severity: 'critical',
        description: `${blockedPct.toFixed(1)}% of threads (${summary.blocked}/${summary.totalThreads}) are in BLOCKED state — severe lock contention`,
        relatedThreads: threads.filter(t => t.state === 'BLOCKED').map(t => t.name).slice(0, 20),
      });
    } else if (blockedPct > 30) {
      issues.push({
        type: 'high_blocked_ratio',
        severity: 'warning',
        description: `${blockedPct.toFixed(1)}% of threads (${summary.blocked}/${summary.totalThreads}) are in BLOCKED state — possible lock contention`,
        relatedThreads: threads.filter(t => t.state === 'BLOCKED').map(t => t.name).slice(0, 20),
      });
    }
  }

  for (const cluster of clusters) {
    if (cluster.threadCount < 5) continue;
    const clusterThreads = threads.filter(t => cluster.threadNames.includes(t.name));
    const waitingInCluster = clusterThreads.filter(t => t.state === 'WAITING' || t.state === 'TIMED_WAITING').length;
    const runnableInCluster = clusterThreads.filter(t => t.state === 'RUNNABLE').length;
    const waitingRatio = waitingInCluster / clusterThreads.length;

    if (waitingRatio > 0.7 && runnableInCluster <= Math.max(1, clusterThreads.length * 0.1)) {
      const poolNameMatch = cluster.threadNames[0]?.match(/^(.*?)[-\s]?\d+$/);
      const poolName = poolNameMatch ? poolNameMatch[1].trim() : 'Thread pool';

      issues.push({
        type: 'thread_pool_saturation',
        severity: waitingRatio > 0.9 ? 'critical' : 'warning',
        description: `${poolName}: ${waitingInCluster}/${clusterThreads.length} threads waiting, only ${runnableInCluster} active — pool appears saturated with similar stack traces`,
        relatedThreads: cluster.threadNames.slice(0, 15),
      });
    }
  }

  for (const ci of contention) {
    if (ci.waitingThreads >= 5) {
      issues.push({
        type: 'blocked_contention',
        severity: ci.waitingThreads >= 10 ? 'critical' : 'warning',
        description: `Lock hotspot: ${ci.waitingThreads} threads blocked on ${ci.lockName}, held by ${ci.holdingThread}`,
        relatedThreads: [ci.holdingThread],
      });
    }
  }

  return issues;
}

export function compareThreadDumps(
  analyses: Array<{ threads: ThreadInfo[]; threadSummary: ThreadDumpAnalysis['threadSummary'] }>
): {
  stuckThreads: Array<{ threadName: string; state: string; stackSignature: string; appearsInDumps: number; totalDumps: number }>;
  detectedIssues: DetectedIssue[];
} {
  const totalDumps = analyses.length;
  const STUCK_THRESHOLD = 3;

  if (totalDumps < STUCK_THRESHOLD) {
    return { stuckThreads: [], detectedIssues: [] };
  }

  const allThreadNames = new Set<string>();
  for (const analysis of analyses) {
    for (const thread of analysis.threads) {
      allThreadNames.add(thread.name);
    }
  }

  const stuckThreads: Array<{ threadName: string; state: string; stackSignature: string; appearsInDumps: number; totalDumps: number }> = [];
  const detectedIssues: DetectedIssue[] = [];

  for (const threadName of Array.from(allThreadNames)) {
    const perDumpSigs: (string | null)[] = [];
    const perDumpStates: (string | null)[] = [];

    for (const analysis of analyses) {
      const thread = analysis.threads.find(t => t.name === threadName);
      if (thread && thread.stackTrace && thread.stackTrace.length > 0) {
        perDumpSigs.push(thread.stackTrace.slice(0, 5).join('|'));
        perDumpStates.push(thread.state);
      } else {
        perDumpSigs.push(null);
        perDumpStates.push(null);
      }
    }

    let maxConsecutive = 0;
    let currentRun = 0;
    let longestSig = '';
    let longestState = '';

    for (let i = 0; i < perDumpSigs.length; i++) {
      const sig = perDumpSigs[i];
      if (sig === null) {
        currentRun = 0;
        continue;
      }
      if (i > 0 && sig === perDumpSigs[i - 1] && sig.length > 0) {
        currentRun++;
      } else {
        currentRun = 1;
      }
      if (currentRun > maxConsecutive) {
        maxConsecutive = currentRun;
        longestSig = sig;
        longestState = perDumpStates[i] || 'UNKNOWN';
      }
    }

    if (maxConsecutive >= STUCK_THRESHOLD && longestSig.length > 0) {
      const topFrame = longestSig.split('|')[0] || 'unknown';
      stuckThreads.push({
        threadName,
        state: longestState,
        stackSignature: topFrame,
        appearsInDumps: maxConsecutive,
        totalDumps,
      });
    }
  }

  if (stuckThreads.length > 0) {
    const stuckNames = stuckThreads.map(s => s.threadName);
    detectedIssues.push({
      type: 'stuck_thread',
      severity: stuckThreads.length >= 5 ? 'critical' : 'warning',
      description: `${stuckThreads.length} thread(s) appear stuck with identical stack traces across ${STUCK_THRESHOLD}+ consecutive dumps`,
      relatedThreads: stuckNames.slice(0, 20),
    });
  }

  return { stuckThreads: stuckThreads.sort((a, b) => b.appearsInDumps - a.appearsInDumps), detectedIssues };
}

function analyzeGcThreads(rawContent: string, threads: ThreadInfo[]): { gcThreads: GcThreadMetrics; recommendations: string[] } {
  const gcPatterns = [
    { regex: /G1\s/i, type: 'G1 GC' },
    { regex: /ParallelGC|Parallel\sGC|PS\s/i, type: 'Parallel GC' },
    { regex: /ZGC|Z\sGC/i, type: 'ZGC' },
    { regex: /Shenandoah/i, type: 'Shenandoah' },
    { regex: /CMS|ConcurrentMarkSweep/i, type: 'CMS' },
    { regex: /GC\sThread|GC\stask/i, type: 'GC Worker' },
    { regex: /Concurrent\sMark|concurrent\smarking/i, type: 'Concurrent Mark' },
    { regex: /Reference\sHandler/i, type: 'Reference Handler' },
    { regex: /Finalizer/i, type: 'Finalizer' },
  ];

  const lines = rawContent.split('\n');
  const gcThreadDetails: { name: string; cpuMs: number; state: string }[] = [];
  const typeCounts = new Map<string, number>();
  let totalGcCpuMs = 0;
  let totalAllCpuMs = 0;

  const cpuRegex = /cpu=([0-9.]+)(ms|s)/;
  const elapsedRegex = /elapsed=([0-9.]+)s/;

  for (const line of lines) {
    if (!line.startsWith('"')) continue;

    const nameMatch = line.match(/"([^"]+)"/);
    if (!nameMatch) continue;
    const threadName = nameMatch[1];

    const cpuMatch = line.match(cpuRegex);
    let cpuMs = 0;
    if (cpuMatch) {
      cpuMs = parseFloat(cpuMatch[1]);
      if (cpuMatch[2] === 's') cpuMs *= 1000;
    }
    totalAllCpuMs += cpuMs;

    let isGcThread = false;
    let gcType = 'GC Worker';

    for (const pat of gcPatterns) {
      if (pat.regex.test(threadName)) {
        isGcThread = true;
        gcType = pat.type;
        break;
      }
    }

    if (isGcThread) {
      totalGcCpuMs += cpuMs;
      typeCounts.set(gcType, (typeCounts.get(gcType) || 0) + 1);

      let state = 'RUNNABLE';
      if (line.includes('waiting')) state = 'WAITING';
      if (line.includes('runnable')) state = 'RUNNABLE';
      if (line.includes('sleeping')) state = 'TIMED_WAITING';

      gcThreadDetails.push({ name: threadName, cpuMs, state });
    }
  }

  const jniMatch = rawContent.match(/JNI global references:\s*(\d+)/);
  const jniRefs = jniMatch ? parseInt(jniMatch[1]) : 0;

  const gcOverheadPct = totalAllCpuMs > 0 ? (totalGcCpuMs / totalAllCpuMs) * 100 : 0;

  const types = Array.from(typeCounts.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);

  const recommendations: string[] = [];

  if (gcOverheadPct > 20) {
    recommendations.push('GC overhead is very high (' + gcOverheadPct.toFixed(1) + '%). Consider increasing heap size or tuning GC parameters.');
  } else if (gcOverheadPct > 10) {
    recommendations.push('GC overhead is elevated (' + gcOverheadPct.toFixed(1) + '%). Monitor for GC pauses during load tests.');
  } else if (gcOverheadPct > 0) {
    recommendations.push('GC overhead is within normal range (' + gcOverheadPct.toFixed(1) + '%).');
  }

  if (gcThreadDetails.length > 12) {
    recommendations.push('High number of GC threads (' + gcThreadDetails.length + '). Consider reducing -XX:ParallelGCThreads if CPU count is lower.');
  }

  const finalizerThreads = gcThreadDetails.filter(t => t.name.includes('Finalizer'));
  if (finalizerThreads.length > 0) {
    const finalizerCpu = finalizerThreads.reduce((sum, t) => sum + t.cpuMs, 0);
    if (finalizerCpu > 500) {
      recommendations.push('Finalizer thread has high CPU usage (' + finalizerCpu.toFixed(0) + 'ms). Objects with finalize() methods are delaying GC. Consider using Cleaner or try-with-resources.');
    }
  }

  const refHandlerThreads = gcThreadDetails.filter(t => t.name.includes('Reference Handler'));
  if (refHandlerThreads.some(t => t.state === 'WAITING')) {
    recommendations.push('Reference Handler thread is waiting. Large numbers of soft/weak references may be increasing GC work.');
  }

  if (types.some(t => t.name === 'CMS')) {
    recommendations.push('Using deprecated CMS collector. Consider migrating to G1GC (-XX:+UseG1GC) or ZGC (-XX:+UseZGC) for better pause times.');
  }

  if (gcThreadDetails.length === 0) {
    recommendations.push('No GC threads found in this dump. GC thread information may not be captured in all thread dump formats.');
  }

  return {
    gcThreads: {
      total: gcThreadDetails.length,
      types,
      totalCpuMs: totalGcCpuMs,
      gcOverheadPct,
      threads: gcThreadDetails,
    },
    recommendations,
  };
}

function parseThreads(content: string): ThreadInfo[] {
  const threads: ThreadInfo[] = [];
  const lines = content.split('\n');
  
  let currentThread: Partial<ThreadInfo> | null = null;
  let stackTrace: string[] = [];
  let holdingLocks: string[] = [];

  const threadHeaderRegex = /^"([^"]+)".*(?:tid=|Id=)(\w+).*(?:nid=\w+\s+)?(\w+(?:\s+\w+)?)/;
  const stateRegex = /java\.lang\.Thread\.State:\s*(\w+)/;
  const lockingRegex = /- locked\s+<([^>]+)>\s*\(a\s+([^)]+)\)/;
  const waitingRegex = /- (?:waiting on|waiting to lock|parking to wait for|waiting on condition)\s+<([^>]+)>\s*\(a\s+([^)]+)\)/;
  const daemonRegex = /daemon/i;
  const prioRegex = /prio=(\d+)/;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    const headerMatch = line.match(threadHeaderRegex);
    if (headerMatch || (line.startsWith('"') && line.includes('Thread'))) {
      if (currentThread && currentThread.name) {
        currentThread.stackTrace = [...stackTrace];
        currentThread.holding = [...holdingLocks];
        threads.push(currentThread as ThreadInfo);
      }
      
      const name = headerMatch ? headerMatch[1] : line.match(/"([^"]+)"/)?.[1] || 'Unknown';
      const id = headerMatch ? headerMatch[2] : `thread-${threads.length}`;
      
      let state = 'RUNNABLE';
      if (line.includes('BLOCKED')) state = 'BLOCKED';
      else if (line.includes('WAITING')) state = 'WAITING';
      else if (line.includes('TIMED_WAITING')) state = 'TIMED_WAITING';
      else if (line.includes('runnable')) state = 'RUNNABLE';
      else if (line.includes('sleeping')) state = 'TIMED_WAITING';
      else if (line.includes('waiting')) state = 'WAITING';
      
      const prioMatch = line.match(prioRegex);
      
      currentThread = {
        id,
        name,
        state,
        daemon: daemonRegex.test(line),
        priority: prioMatch ? parseInt(prioMatch[1]) : 5,
        stackTrace: [],
        holding: [],
      };
      stackTrace = [];
      holdingLocks = [];
      continue;
    }

    if (currentThread) {
      const stateMatch = line.match(stateRegex);
      if (stateMatch) {
        currentThread.state = stateMatch[1];
        continue;
      }

      const lockMatch = line.match(lockingRegex);
      if (lockMatch) {
        holdingLocks.push(`${lockMatch[2]}@${lockMatch[1]}`);
        continue;
      }

      const waitMatch = line.match(waitingRegex);
      if (waitMatch) {
        currentThread.blockedBy = `${waitMatch[2]}@${waitMatch[1]}`;
        currentThread.lockInfo = {
          lockName: waitMatch[2],
          lockOwner: undefined,
        };
        continue;
      }

      if (line.trim().startsWith('at ')) {
        stackTrace.push(line.trim().substring(3));
      }
    }
  }

  if (currentThread && currentThread.name) {
    currentThread.stackTrace = [...stackTrace];
    currentThread.holding = [...holdingLocks];
    threads.push(currentThread as ThreadInfo);
  }

  return threads;
}

function calculateThreadSummary(threads: ThreadInfo[]) {
  return {
    totalThreads: threads.length,
    runnable: threads.filter(t => t.state === 'RUNNABLE').length,
    blocked: threads.filter(t => t.state === 'BLOCKED').length,
    waiting: threads.filter(t => t.state === 'WAITING').length,
    timedWaiting: threads.filter(t => t.state === 'TIMED_WAITING').length,
    terminated: threads.filter(t => t.state === 'TERMINATED').length,
    daemonCount: threads.filter(t => t.daemon).length,
  };
}

function detectDeadlocks(threads: ThreadInfo[]): DeadlockInfo[] {
  const deadlocks: DeadlockInfo[] = [];
  
  const lockGraph = new Map<string, string>();
  const lockOwners = new Map<string, string>();
  
  for (const thread of threads) {
    if (thread.holding) {
      for (const lock of thread.holding) {
        lockOwners.set(lock, thread.name);
      }
    }
  }
  
  for (const thread of threads) {
    if (thread.blockedBy && thread.state === 'BLOCKED') {
      const owner = lockOwners.get(thread.blockedBy);
      if (owner) {
        lockGraph.set(thread.name, owner);
      }
    }
  }
  
  const visited = new Set<string>();
  const recStack = new Set<string>();
  
  function findCycle(node: string, path: string[]): string[] | null {
    visited.add(node);
    recStack.add(node);
    path.push(node);
    
    const next = lockGraph.get(node);
    if (next) {
      if (!visited.has(next)) {
        const cycle = findCycle(next, path);
        if (cycle) return cycle;
      } else if (recStack.has(next)) {
        const cycleStart = path.indexOf(next);
        return path.slice(cycleStart);
      }
    }
    
    path.pop();
    recStack.delete(node);
    return null;
  }
  
  for (const thread of threads) {
    if (!visited.has(thread.name) && lockGraph.has(thread.name)) {
      const cycle = findCycle(thread.name, []);
      if (cycle && cycle.length > 1) {
        const cycleThreads = threads.filter(t => cycle.includes(t.name));
        const locks = cycleThreads
          .filter(t => t.blockedBy)
          .map(t => t.blockedBy as string);
        
        const exists = deadlocks.some(d => 
          d.cycle.length === cycle.length && 
          d.cycle.every(c => cycle.includes(c))
        );
        
        if (!exists) {
          deadlocks.push({
            threads: cycle,
            locks,
            cycle,
          });
        }
      }
    }
  }
  
  return deadlocks;
}

function findHotspots(threads: ThreadInfo[]): HotspotInfo[] {
  const methodCounts = new Map<string, { count: number; callers: Set<string> }>();
  
  for (const thread of threads) {
    if (!thread.stackTrace || thread.stackTrace.length === 0) continue;
    
    for (let i = 0; i < thread.stackTrace.length; i++) {
      const method = thread.stackTrace[i];
      const caller = i + 1 < thread.stackTrace.length ? thread.stackTrace[i + 1] : 'root';
      
      if (!methodCounts.has(method)) {
        methodCounts.set(method, { count: 0, callers: new Set() });
      }
      const entry = methodCounts.get(method)!;
      entry.count++;
      entry.callers.add(caller);
    }
  }
  
  const totalMethods = Array.from(methodCounts.values()).reduce((sum, e) => sum + e.count, 0);
  
  const hotspots: HotspotInfo[] = Array.from(methodCounts.entries())
    .map(([method, data]) => ({
      method,
      count: data.count,
      percentage: (data.count / totalMethods) * 100,
      callers: Array.from(data.callers).slice(0, 5),
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 50);
  
  return hotspots;
}

function clusterStackTraces(threads: ThreadInfo[]): StackCluster[] {
  const clusters: StackCluster[] = [];
  const assignedThreads = new Set<string>();
  
  function calculateSimilarity(trace1: string[], trace2: string[]): number {
    if (trace1.length === 0 || trace2.length === 0) return 0;
    
    const set1 = new Set(trace1);
    const set2 = new Set(trace2);
    
    let intersection = 0;
    Array.from(set1).forEach(item => {
      if (set2.has(item)) intersection++;
    });
    
    const union = set1.size + set2.size - intersection;
    return union > 0 ? intersection / union : 0;
  }
  
  function getCommonPattern(traces: string[][]): string[] {
    if (traces.length === 0) return [];
    if (traces.length === 1) return traces[0].slice(0, 10);
    
    const pattern: string[] = [];
    const minLen = Math.min(...traces.map(t => t.length));
    
    for (let i = 0; i < minLen && pattern.length < 10; i++) {
      const methods = traces.map(t => t[i]);
      const counts = new Map<string, number>();
      for (const m of methods) {
        counts.set(m, (counts.get(m) || 0) + 1);
      }
      
      const [mostCommon, count] = Array.from(counts.entries())
        .sort((a, b) => b[1] - a[1])[0];
      
      if (count >= traces.length * 0.5) {
        pattern.push(mostCommon);
      }
    }
    
    return pattern;
  }
  
  const SIMILARITY_THRESHOLD = 0.3;
  let clusterId = 0;
  
  for (const thread of threads) {
    if (assignedThreads.has(thread.id)) continue;
    if (!thread.stackTrace || thread.stackTrace.length === 0) continue;
    
    const clusterMembers: ThreadInfo[] = [thread];
    assignedThreads.add(thread.id);
    
    for (const other of threads) {
      if (assignedThreads.has(other.id)) continue;
      if (!other.stackTrace || other.stackTrace.length === 0) continue;
      
      const similarity = calculateSimilarity(thread.stackTrace, other.stackTrace);
      if (similarity >= SIMILARITY_THRESHOLD) {
        clusterMembers.push(other);
        assignedThreads.add(other.id);
      }
    }
    
    if (clusterMembers.length >= 1) {
      const traces = clusterMembers.map(t => t.stackTrace);
      const avgSimilarity = clusterMembers.length > 1 
        ? clusterMembers.slice(1).reduce((sum, t) => 
            sum + calculateSimilarity(thread.stackTrace, t.stackTrace), 0
          ) / (clusterMembers.length - 1)
        : 1.0;
      
      clusters.push({
        id: clusterId++,
        pattern: getCommonPattern(traces),
        threadCount: clusterMembers.length,
        threadNames: clusterMembers.map(t => t.name),
        similarity: avgSimilarity,
      });
    }
  }
  
  return clusters.sort((a, b) => b.threadCount - a.threadCount);
}

function analyzeContention(threads: ThreadInfo[]): ContentionInfo[] {
  const lockWaiters = new Map<string, { waiting: string[]; holder?: string }>();
  
  for (const thread of threads) {
    if (thread.holding) {
      for (const lock of thread.holding) {
        if (!lockWaiters.has(lock)) {
          lockWaiters.set(lock, { waiting: [], holder: undefined });
        }
        lockWaiters.get(lock)!.holder = thread.name;
      }
    }
  }
  
  for (const thread of threads) {
    if (thread.blockedBy && thread.state === 'BLOCKED') {
      if (!lockWaiters.has(thread.blockedBy)) {
        lockWaiters.set(thread.blockedBy, { waiting: [], holder: undefined });
      }
      lockWaiters.get(thread.blockedBy)!.waiting.push(thread.name);
    }
  }
  
  const contentionInfo: ContentionInfo[] = Array.from(lockWaiters.entries())
    .filter(([_, data]) => data.waiting.length > 0)
    .map(([lockName, data]) => ({
      lockName,
      waitingThreads: data.waiting.length,
      holdingThread: data.holder || 'Unknown',
      avgWaitTime: undefined,
    }))
    .sort((a, b) => b.waitingThreads - a.waitingThreads);
  
  return contentionInfo;
}
