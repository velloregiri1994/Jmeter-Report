import { Router, Request, Response } from "express";
import { logger, type LogLevel } from "./logger";
import { asyncHandler } from "./error-handler";
import { requireAuth, requireAdmin } from "./route-middleware";

const router = Router();

router.get("/api/logs", requireAuth, requireAdmin, asyncHandler(async (req: Request, res: Response) => {
  const level = req.query.level as LogLevel | undefined;
  const source = req.query.source as string | undefined;
  const search = req.query.search as string | undefined;
  const limit = Math.min(parseInt(req.query.limit as string) || 100, 500);
  const offset = parseInt(req.query.offset as string) || 0;

  const result = logger.getRecentLogs({ level, source, search, limit, offset });
  res.json(result);
}));

router.get("/api/logs/stats", requireAuth, requireAdmin, asyncHandler(async (_req: Request, res: Response) => {
  const stats = logger.getStats();
  const sources = logger.getSources();
  res.json({ ...stats, sources });
}));

router.get("/api/logs/files", requireAuth, requireAdmin, asyncHandler(async (_req: Request, res: Response) => {
  const files = logger.getLogFiles();
  res.json({ files });
}));

router.get("/api/logs/files/:fileName", requireAuth, requireAdmin, asyncHandler(async (req: Request, res: Response) => {
  const { fileName } = req.params;
  const tail = parseInt(req.query.tail as string) || undefined;
  try {
    const content = logger.readLogFile(fileName, { tail });
    res.type("text/plain").send(content);
  } catch (err: any) {
    const msg = err?.message || "Failed to read log file";
    if (msg.includes("not found")) {
      res.status(404).json({ message: msg });
    } else if (msg.includes("Invalid")) {
      res.status(400).json({ message: msg });
    } else {
      res.status(500).json({ message: msg });
    }
  }
}));

export function registerLogRoutes(app: Router) {
  app.use(router);
}
