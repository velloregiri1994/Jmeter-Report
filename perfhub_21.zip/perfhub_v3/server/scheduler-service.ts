import crypto from "crypto";
import { storage } from "./storage";
import { queueJMeterRun } from "./jmeter-worker";
import { log } from "./index";

let schedulerInterval: NodeJS.Timeout | null = null;
const SCHEDULER_CHECK_INTERVAL_MS = 30 * 1000; // Check every 30 seconds

function generateExecutionId(): string {
  return `EXEC-${Date.now()}-${crypto.randomUUID().replace(/-/g, "").substring(0, 8).toUpperCase()}`;
}

async function processScheduledTests() {
  try {
    const pendingSchedules = await storage.getPendingSchedulesToRun();
    
    if (pendingSchedules.length === 0) {
      return;
    }

    log(`Found ${pendingSchedules.length} pending scheduled test(s) to run`, "scheduler");

    for (const schedule of pendingSchedules) {
      try {
        if (!schedule.scriptId) {
          log(`Schedule ${schedule.id} has no script assigned, skipping`, "scheduler");
          continue;
        }

        const script = await storage.getScript(schedule.scriptId);
        if (!script?.filePath) {
          log(`Schedule ${schedule.id}: Script ${schedule.scriptId} has no JMX file, skipping`, "scheduler");
          continue;
        }

        const executionId = generateExecutionId();

        const result = await storage.atomicClaimSchedule(schedule.id, executionId);
        if (!result) {
          log(`Schedule ${schedule.id} already has an active execution or was claimed concurrently, skipping`, "scheduler");
          continue;
        }

        const { execution } = result;

        const scheduleConfig = schedule.configuration as { vusers?: number; duration?: number; rampUp?: number } | null;
        await queueJMeterRun(execution.id, {
          executionId,
          jmxPath: script.filePath,
          vusers: scheduleConfig?.vusers || undefined,
          duration: scheduleConfig?.duration || undefined,
          rampUp: scheduleConfig?.rampUp || undefined,
        });

        log(`Queued scheduled test: Schedule ${schedule.id} -> Execution ${execution.id}`, "scheduler");

      } catch (err: any) {
        log(`Error processing schedule ${schedule.id}: ${err.message}`, "scheduler");
      }
    }
  } catch (err: any) {
    log(`Scheduler error: ${err.message}`, "scheduler");
  }
}

export function startSchedulerService() {
  if (schedulerInterval) {
    log("Scheduler service already running", "scheduler");
    return;
  }

  log("Starting scheduler service (checking every 30 seconds)", "scheduler");
  
  processScheduledTests();
  
  schedulerInterval = setInterval(processScheduledTests, SCHEDULER_CHECK_INTERVAL_MS);
}

export function stopSchedulerService() {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
    log("Scheduler service stopped", "scheduler");
  }
}
