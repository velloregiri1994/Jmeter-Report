import express, { type Express, type Request, type Response, type NextFunction } from "express";
import path from "path";
import fs from "fs";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { validate, z, idParam, scriptIdParam } from "./validation";

import { db } from "./db";
import { remoteIngestTokens, testTracker, testExecutions, testSchedules, scripts, savedFilterViews, executionWorkloadTargets } from "@shared/schema";
import { eq, desc, and, gte, lte, inArray, isNotNull, asc, sql } from "drizzle-orm";
import { generateHtmlReport } from "./report-generator";
import { cacheService, CACHE_KEYS, CACHE_TTL } from "./cache";
import { registerDumpRoutes } from "./dump-routes";
import { registerCompletionReportRoutes } from "./completion-report-routes";
import { registerReportDeliveryRoutes } from "./report-delivery-routes";
import { queueJMeterRun, generateRunId, getQueueStatus, cancelRun, cancelCurrentRun } from "./jmeter-worker";
import { registerAuthRoutes } from "./auth-routes";
import { registerScriptRoutes } from "./script-routes";
import { registerExecutionRoutes } from "./execution-routes";
import { registerScheduleRoutes } from "./schedule-routes";
import { registerAdminRoutes } from "./admin-routes";
import { registerLogRoutes } from "./log-routes";
import { registerNotificationRoutes } from "./notification-routes";
import { registerWebhookRoutes } from "./webhook-routes";
import { registerCicdRoutes } from "./cicd-routes";
import { registerReportTemplateRoutes } from "./report-template-routes";
import { registerHarConverterRoutes } from "./har-converter-routes";
import { registerReleaseTagRoutes } from "./release-tag-routes";
import { analyzeWorkloadAchievement, type WorkloadTargets, type ActualMetrics } from "./workload-achievement";
import { requireAuth, requireEngineerOrAdmin, requireAdmin, requireNonViewer, sanitizeUser, sanitizeResponse, generateExecutionId } from "./route-middleware";
import { asyncHandler } from "./error-handler";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get("/api/setup/status", asyncHandler(async (_req: Request, res: Response) => {
    const userCount = await storage.getUserCount();
    res.json({ needsSetup: userCount === 0 });
  }));

  app.get("/api/setup/check-requirements", asyncHandler(async (_req: Request, res: Response) => {
    let database = false;
    try {
      await db.execute(sql`SELECT 1`);
      database = true;
    } catch {}

    let diskSpace = "sufficient";
    let diskSpaceDetail = "Available";
    try {
      const { execSync } = await import("child_process");
      const os = await import("os");
      let availMb = 0;

      if (os.platform() === "darwin") {
        const dfOutput = execSync("df -k / | tail -1", { encoding: "utf-8" });
        const parts = dfOutput.trim().split(/\s+/);
        const availKb = parseInt(parts[3]);
        if (!isNaN(availKb)) {
          availMb = Math.round(availKb / 1024);
        }
      } else {
        const dfOutput = execSync("df -BM --output=avail / 2>/dev/null || df -k / | tail -1 | awk '{print $4}'", { encoding: "utf-8" });
        const matchM = dfOutput.match(/(\d+)M/);
        if (matchM) {
          availMb = parseInt(matchM[1]);
        } else {
          const matchK = dfOutput.match(/(\d+)/);
          if (matchK) {
            availMb = Math.round(parseInt(matchK[1]) / 1024);
          }
        }
      }

      if (availMb > 0) {
        diskSpaceDetail = `${Math.round(availMb / 1024 * 10) / 10} GB available`;
        if (availMb < 500) {
          diskSpace = "insufficient";
        } else if (availMb < 2000) {
          diskSpace = "low";
        }
      } else {
        diskSpaceDetail = "Could not determine";
      }
    } catch {
      diskSpaceDetail = "Could not determine";
    }

    res.json({
      database,
      nodeVersion: process.version,
      diskSpace,
      diskSpaceDetail,
    });
  }));

  app.get("/api/detect-jmeter", asyncHandler(async (_req: Request, res: Response) => {
    const { execSync } = await import("child_process");
    const os = await import("os");
    const platform = os.platform();

    const candidates: string[] = [];

    if (process.env.JMETER_HOME) {
      const jmeterBin = path.join(process.env.JMETER_HOME, "bin", platform === "win32" ? "jmeter.bat" : "jmeter");
      if (fs.existsSync(jmeterBin)) {
        candidates.push(process.env.JMETER_HOME);
      }
    }

    try {
      const whichCmd = platform === "win32" ? "where jmeter" : "which jmeter";
      const jmeterBin = execSync(whichCmd, { encoding: "utf-8", timeout: 5000 }).trim().split("\n")[0].trim();
      if (jmeterBin) {
        const binDir = path.dirname(jmeterBin);
        const home = path.dirname(binDir);
        if (!candidates.includes(home)) {
          candidates.push(home);
        }
      }
    } catch {}

    const searchDirs = platform === "win32"
      ? [
          { dir: "C:\\", prefix: "apache-jmeter" },
          { dir: "C:\\Program Files", prefix: "apache-jmeter" },
          { dir: "C:\\Program Files", prefix: "JMeter" },
          { dir: "C:\\tools", prefix: "apache-jmeter" },
        ]
      : platform === "darwin"
        ? [
            { dir: "/opt", prefix: "apache-jmeter" },
            { dir: "/usr/local", prefix: "apache-jmeter" },
            { dir: os.homedir(), prefix: "apache-jmeter" },
          ]
        : [
            { dir: "/opt", prefix: "apache-jmeter" },
            { dir: "/usr/local", prefix: "apache-jmeter" },
            { dir: "/usr/share", prefix: "jmeter" },
            { dir: os.homedir(), prefix: "apache-jmeter" },
          ];

    for (const { dir, prefix } of searchDirs) {
      try {
        if (fs.existsSync(dir)) {
          const entries = fs.readdirSync(dir);
          for (const entry of entries) {
            if (entry.startsWith(prefix)) {
              const fullPath = path.join(dir, entry);
              const binFile = path.join(fullPath, "bin", platform === "win32" ? "jmeter.bat" : "jmeter");
              if (fs.existsSync(binFile) && !candidates.includes(fullPath)) {
                candidates.push(fullPath);
              }
            }
          }
        }
      } catch {}
    }

    if (platform === "darwin") {
      try {
        const cellarDir = "/opt/homebrew/Cellar/jmeter";
        if (fs.existsSync(cellarDir)) {
          for (const ver of fs.readdirSync(cellarDir)) {
            const libexecPath = path.join(cellarDir, ver, "libexec");
            if (fs.existsSync(path.join(libexecPath, "bin", "jmeter")) && !candidates.includes(libexecPath)) {
              candidates.push(libexecPath);
            }
          }
        }
      } catch {}
    }

    let version: string | null = null;
    let detectedPath: string | null = candidates.length > 0 ? candidates[0] : null;

    if (detectedPath) {
      try {
        const jmeterBin = path.join(detectedPath, "bin", platform === "win32" ? "jmeter.bat" : "jmeter");
        const output = execSync(`"${jmeterBin}" --version 2>&1`, { encoding: "utf-8", timeout: 10000 });
        const vMatch = output.match(/(\d+\.\d+(?:\.\d+)?)/);
        if (vMatch) version = vMatch[1];
      } catch {}
    }

    const configPath = path.join(process.cwd(), "config.json");
    let configuredPath: string | null = null;
    try {
      if (fs.existsSync(configPath)) {
        const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
        configuredPath = config.jmeter?.home || null;
      }
    } catch {}

    res.json({
      detected: detectedPath,
      configured: configuredPath,
      candidates,
      version,
      platform,
    });
  }));

  app.post("/api/config/jmeter", requireNonViewer, asyncHandler(async (req: Request, res: Response) => {
    const { jmeterHome } = req.body;
    if (typeof jmeterHome !== "string") {
      return res.status(400).json({ error: "jmeterHome must be a string" });
    }

    const configPath = path.join(process.cwd(), "config.json");
    let config: any = {};
    try {
      if (fs.existsSync(configPath)) {
        config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
      }
    } catch {}

    if (jmeterHome.trim()) {
      const binFile = path.join(jmeterHome.trim(), "bin", "jmeter");
      const batFile = path.join(jmeterHome.trim(), "bin", "jmeter.bat");
      if (!fs.existsSync(binFile) && !fs.existsSync(batFile)) {
        return res.status(400).json({ error: `JMeter not found at ${jmeterHome}/bin/jmeter. Please provide the JMeter home directory (e.g., /opt/apache-jmeter-5.6.3)` });
      }
      config.jmeter = { ...config.jmeter, home: jmeterHome.trim() };
    } else {
      if (config.jmeter) {
        delete config.jmeter.home;
        delete config.jmeter.executable;
        if (Object.keys(config.jmeter).length === 0) delete config.jmeter;
      }
    }

    fs.writeFileSync(configPath, JSON.stringify(config, null, 2), "utf-8");
    res.json({ success: true, jmeterHome: jmeterHome.trim() || null });
  }));

  app.get("/api/config/jmeter", requireAuth, asyncHandler(async (_req: Request, res: Response) => {
    const configPath = path.join(process.cwd(), "config.json");
    let jmeterHome: string | null = null;
    try {
      if (fs.existsSync(configPath)) {
        const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
        jmeterHome = config.jmeter?.home || null;
      }
    } catch {}
    res.json({ jmeterHome });
  }));

  registerDumpRoutes(app);
  registerCompletionReportRoutes(app);
  registerReportDeliveryRoutes(app);
  registerAuthRoutes(app);
  registerScriptRoutes(app);
  registerExecutionRoutes(app);
  registerScheduleRoutes(app);
  registerAdminRoutes(app);
  registerLogRoutes(app);
  registerNotificationRoutes(app);
  registerWebhookRoutes(app);
  registerCicdRoutes(app);
  registerReportTemplateRoutes(app);
  registerHarConverterRoutes(app);
  registerReleaseTagRoutes(app);
  
  // Folders (all require authentication)
  app.get("/api/folders", requireAuth, asyncHandler(async (req, res) => {
    const folders = await storage.getFolders();
    res.json(folders);
  }));

  app.post("/api/folders", requireEngineerOrAdmin, validate({ body: z.object({ name: z.string().min(1, "Folder name is required").transform(s => s.trim()), parentId: z.number().optional().nullable() }) }), asyncHandler(async (req, res) => {
    const { name, parentId } = req.body;
    if (parentId !== null && parentId !== undefined) {
      const parent = await storage.getFolder(parentId);
      if (!parent) return res.status(400).json({ message: "Parent folder not found" });
    }
    const folder = await storage.createFolder({ name, parentId: parentId || null });
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    res.status(201).json(folder);
  }));

  app.patch("/api/folders/:id", requireEngineerOrAdmin, validate({ params: idParam, body: z.object({ name: z.string().min(1, "Folder name cannot be empty").transform(s => s.trim()).optional(), parentId: z.number().optional().nullable() }).partial() }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const { name, parentId } = req.body;
    const updates: any = {};
    if (name !== undefined) {
      updates.name = name;
    }
    if (parentId !== undefined) {
      if (parentId !== null) {
        const parent = await storage.getFolder(parentId);
        if (!parent) return res.status(400).json({ message: "Parent folder not found" });
      }
      updates.parentId = parentId;
    }
    const folder = await storage.updateFolder(id, updates);
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    res.json(folder);
  }));

  app.delete("/api/folders/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteFolder(id);
    await cacheService.deletePattern(`${CACHE_KEYS.SCRIPTS_LIST}*`);
    res.sendStatus(204);
  }));

  // Data retention settings endpoints
  app.get("/api/settings/retention", requireAuth, asyncHandler(async (req, res) => {
    const settings = await storage.getAllRetentionSettings();
    res.json(settings);
  }));

  app.put("/api/settings/retention/:key", requireEngineerOrAdmin, validate({ params: z.object({ key: z.string().min(1) }), body: z.object({ value: z.number().int().min(1, "Value must be a positive number") }) }), asyncHandler(async (req, res) => {
    const { key } = req.params;
    const { value } = req.body;
    
    const userId = (req.session as any)?.user?.id;
    await storage.updateRetentionSetting(key, value, userId);
    
    res.json({ message: "Setting updated", key, value });
  }));

  app.get("/api/retention/overview", requireAdmin, asyncHandler(async (_req, res) => {
    const { getRetentionOverview } = await import("./retention-service");
    const overview = await getRetentionOverview();
    res.json(overview);
  }));

  app.post("/api/retention/:category/preview", requireAdmin, validate({ params: z.object({ category: z.string().min(1) }) }), asyncHandler(async (req, res) => {
    const { previewCleanup } = await import("./retention-service");
    const preview = await previewCleanup(req.params.category);
    res.json(preview);
  }));

  app.post("/api/retention/:category/cleanup", requireAdmin, validate({ params: z.object({ category: z.string().min(1) }) }), asyncHandler(async (req, res) => {
    const userId = (req.session as any)?.user?.id;
    const { runCleanup } = await import("./retention-service");
    const result = await runCleanup(req.params.category, userId);
    res.json(result);
  }));

  app.get("/api/retention/history", requireAdmin, validate({ query: z.object({
    limit: z.coerce.number().int().min(1).max(200).optional(),
    offset: z.coerce.number().int().min(0).optional(),
  }).passthrough() }), asyncHandler(async (req, res) => {
    const { getCleanupHistory } = await import("./retention-service");
    const q = req.query as any;
    const limit = q.limit || 20;
    const offset = q.offset || 0;
    const history = await getCleanupHistory(limit, offset);
    res.json(history);
  }));

  app.patch("/api/executions/:id/pin", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const userId = (req.session as any)?.user?.id;
    const exec = await storage.getExecution(id);
    if (!exec) return res.status(404).json({ message: "Execution not found" });
    const newPinned = !(exec as any).isPinned;
    await storage.updateExecutionPin(id, newPinned, userId);
    res.json({ id, isPinned: newPinned });
  }));

  // Seed Data Endpoint (Hidden)
  if (process.env.NODE_ENV !== 'production') {
    app.post('/api/seed', requireAdmin, asyncHandler(async (req, res) => {
      await seedDatabase();
      res.json({ message: "Database seeded" });
    }));
  }

  // Auto-seed on startup (disabled)
  if (process.env.NODE_ENV !== "test" && process.env.ENABLE_SEED === "true") {
    seedDatabase().catch(console.error);
  }

  // Tags (require authentication)
  app.get("/api/tags", requireAuth, asyncHandler(async (req, res) => {
    const allTags = await storage.getTags();
    res.json(allTags);
  }));

  app.post("/api/tags", requireEngineerOrAdmin, validate({ body: z.object({ name: z.string().min(1).max(100), color: z.string().max(20).optional() }) }), asyncHandler(async (req, res) => {
    const tag = await storage.createTag(req.body);
    res.json(tag);
  }));

  app.delete("/api/tags/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteTag(id);
    res.sendStatus(204);
  }));

  app.get("/api/scripts/:id/tags", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const scriptTags = await storage.getScriptTags(id);
    res.json(scriptTags);
  }));

  const idTagIdParam = z.object({ id: z.string().regex(/^\d+$/).transform(Number), tagId: z.string().regex(/^\d+$/).transform(Number) });

  app.post("/api/scripts/:id/tags/:tagId", requireEngineerOrAdmin, validate({ params: idTagIdParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const tagId = req.params.tagId as unknown as number;
    await storage.addTagToScript(id, tagId);
    res.sendStatus(200);
  }));

  app.delete("/api/scripts/:id/tags/:tagId", requireEngineerOrAdmin, validate({ params: idTagIdParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const tagId = req.params.tagId as unknown as number;
    await storage.removeTagFromScript(id, tagId);
    res.sendStatus(204);
  }));

  // Favorites (require authentication, use session userId)
  app.get("/api/favorites", requireAuth, asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    const favs = await storage.getFavorites(userId);
    res.json(favs);
  }));

  app.post("/api/favorites", requireAuth, validate({ body: z.object({ scriptId: z.number().int() }) }), asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    const fav = await storage.addFavorite(userId, req.body.scriptId);
    res.json(fav);
  }));

  app.delete("/api/favorites/:scriptId", requireAuth, validate({ params: z.object({ scriptId: z.string().regex(/^\d+$/).transform(Number) }) }), asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    const scriptId = req.params.scriptId as unknown as number;
    await storage.removeFavorite(userId, scriptId);
    res.sendStatus(204);
  }));

  // Templates (require authentication)
  app.get("/api/templates", requireAuth, asyncHandler(async (req, res) => {
    const templates = await storage.getTemplates();
    res.json(templates);
  }));

  app.get("/api/templates/:id", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const template = await storage.getTemplate(id);
    if (!template) return res.status(404).json({ message: "Template not found" });
    res.json(template);
  }));

  app.post("/api/templates", requireEngineerOrAdmin, validate({ body: z.object({
    name: z.string().min(1, "Name is required"),
    description: z.string().optional().nullable(),
    configuration: z.object({
      vusers: z.number().int().positive().optional(),
      rampUp: z.number().int().min(0).optional(),
      duration: z.number().int().positive().optional(),
      environment: z.string().min(1),
      isDistributed: z.boolean().optional(),
      workerNodes: z.number().int().positive().optional(),
      slas: z.object({
        avgResponseTime: z.number().optional(),
        throughput: z.number().optional(),
        p90: z.number().optional(),
        p95: z.number().optional(),
        errorRate: z.number().optional(),
      }).optional(),
    }).optional(),
  }) }), asyncHandler(async (req, res) => {
    const template = await storage.createTemplate(req.body);
    res.json(template);
  }));

  app.delete("/api/templates/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteTemplate(id);
    res.sendStatus(204);
  }));

  // Baselines (require authentication, use session userId)
  const scriptIdParamBaseline = z.object({ scriptId: z.string().regex(/^\d+$/).transform(Number) });

  app.get("/api/baselines/:scriptId", requireAuth, validate({ params: scriptIdParamBaseline }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const baseline = await storage.getBaseline(scriptId);
    res.json(baseline || null);
  }));

  app.post("/api/baselines", requireEngineerOrAdmin, validate({ body: z.object({ scriptId: z.number().int(), executionId: z.number().int() }) }), asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    const baseline = await storage.setBaseline(
      req.body.scriptId,
      req.body.executionId,
      userId
    );
    res.json(baseline);
  }));

  app.delete("/api/baselines/:scriptId", requireEngineerOrAdmin, validate({ params: scriptIdParamBaseline }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    await storage.removeBaseline(scriptId);
    res.sendStatus(204);
  }));

  // === SLA RULES ===

  const slaBodySchema = z.object({ metric: z.enum(["avg","p90","p95","p99","max","errorRate","throughput"], { message: "Invalid metric" }), comparator: z.enum(["lt","gt","lte","gte"], { message: "Invalid comparator" }), threshold: z.number(), transactionLabel: z.string().optional().nullable(), isEnabled: z.boolean().optional() });

  app.get("/api/scripts/:scriptId/sla-rules", requireEngineerOrAdmin, validate({ params: scriptIdParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const rules = await storage.getSlaRules(scriptId);
    res.json(rules);
  }));

  app.post("/api/scripts/:scriptId/sla-rules", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: slaBodySchema }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const { transactionLabel, metric, comparator, threshold, isEnabled } = req.body;

    const sessionUser = (req.session as any).user;
    const rule = await storage.createSlaRule({
      scriptId,
      transactionLabel: transactionLabel || null,
      metric,
      comparator,
      threshold,
      isEnabled: isEnabled !== false,
      createdBy: sessionUser.id,
    });
    res.status(201).json(rule);
  }));

  app.put("/api/sla-rules/:id", requireEngineerOrAdmin, validate({ params: idParam, body: slaBodySchema.partial() }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const { transactionLabel, metric, comparator, threshold, isEnabled } = req.body;
    const updates: any = {};
    if (transactionLabel !== undefined) updates.transactionLabel = transactionLabel;
    if (metric !== undefined) updates.metric = metric;
    if (comparator !== undefined) updates.comparator = comparator;
    if (threshold !== undefined) updates.threshold = threshold;
    if (isEnabled !== undefined) updates.isEnabled = isEnabled;

    const rule = await storage.updateSlaRule(id, updates);
    if (!rule) return res.status(404).json({ message: "Rule not found" });
    res.json(rule);
  }));

  app.delete("/api/sla-rules/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteSlaRule(id);
    res.json({ message: "Rule deleted" });
  }));

  // === BASELINE MANAGEMENT ===

  app.get("/api/scripts/:scriptId/baseline", requireAuth, validate({ params: scriptIdParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    
    const result = await storage.getBaselineWithExecution(scriptId);
    if (!result) return res.json(null);
    res.json(result);
  }));

  app.post("/api/scripts/:scriptId/baseline", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: z.object({ executionId: z.number().int({ message: "executionId is required" }), name: z.string().optional(), notes: z.string().optional() }) }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const { executionId, name, notes } = req.body;

    const sessionUser = (req.session as any).user;
    const baseline = await storage.setBaseline(scriptId, executionId, sessionUser.id, name, notes);
    res.status(201).json(baseline);
  }));

  app.delete("/api/scripts/:scriptId/baseline", requireEngineerOrAdmin, validate({ params: scriptIdParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    await storage.removeBaseline(scriptId);
    res.json({ message: "Baseline removed" });
  }));

  app.get("/api/scripts/:scriptId/baseline/history", requireAuth, validate({ params: scriptIdParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const history = await storage.getBaselineHistory(scriptId);
    res.json(history);
  }));

  // === REGRESSION THRESHOLDS ===

  app.get("/api/scripts/:scriptId/regression-thresholds", requireAuth, validate({ params: scriptIdParam }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const thresholds = await storage.getRegressionThresholds(scriptId);
    res.json(thresholds);
  }));

  app.post("/api/scripts/:scriptId/regression-thresholds", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: z.object({ metric: z.string().min(1, "metric is required"), warningPercent: z.number().optional(), criticalPercent: z.number().optional(), isEnabled: z.boolean().optional() }) }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;
    const { metric, warningPercent, criticalPercent, isEnabled } = req.body;
    const threshold = await storage.upsertRegressionThreshold({
      scriptId,
      metric,
      warningPercent: warningPercent ?? 10,
      criticalPercent: criticalPercent ?? 25,
      isEnabled: isEnabled !== false,
    });
    res.status(201).json(threshold);
  }));

  const scriptIdAndIdParam = scriptIdParam.merge(z.object({ id: z.string().regex(/^\d+$/).transform(Number) }));

  app.delete("/api/scripts/:scriptId/regression-thresholds/:id", requireEngineerOrAdmin, validate({ params: scriptIdAndIdParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteRegressionThreshold(id);
    res.json({ message: "Threshold deleted" });
  }));

  // === PROJECTS ===

  app.get("/api/projects", requireAuth, asyncHandler(async (req, res) => {
    const projectList = await storage.getProjects();
    res.json(projectList);
  }));

  app.post("/api/projects", requireEngineerOrAdmin, validate({ body: z.object({ name: z.string().min(1, "Project name is required"), description: z.string().optional() }) }), asyncHandler(async (req, res) => {
    const sessionUser = (req.session as any).user;
    const { name, description } = req.body;
    const project = await storage.createProject({ name, description, createdBy: sessionUser.id });
    res.status(201).json(project);
  }));

  app.put("/api/projects/:id", requireEngineerOrAdmin, validate({ params: idParam, body: z.object({ name: z.string().optional(), description: z.string().optional() }) }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const { name, description } = req.body;
    const project = await storage.updateProject(id, { name, description });
    if (!project) return res.status(404).json({ message: "Project not found" });
    res.json(project);
  }));

  app.delete("/api/projects/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteProject(id);
    res.json({ message: "Project deleted" });
  }));

  // === TEST TYPES ===

  app.get("/api/test-types", requireAuth, asyncHandler(async (req, res) => {
    const types = await storage.getTestTypes();
    res.json(types);
  }));

  app.post("/api/test-types", requireEngineerOrAdmin, validate({ body: z.object({ name: z.string().min(1, "Test type name is required"), description: z.string().optional() }) }), asyncHandler(async (req, res) => {
    const sessionUser = (req.session as any).user;
    const { name, description } = req.body;
    const testType = await storage.createTestType({ name, description, createdBy: sessionUser.id });
    res.status(201).json(testType);
  }));

  app.put("/api/test-types/:id", requireEngineerOrAdmin, validate({ params: idParam, body: z.object({ name: z.string().optional(), description: z.string().optional() }) }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const { name, description } = req.body;
    const testType = await storage.updateTestType(id, { name, description });
    if (!testType) return res.status(404).json({ message: "Test type not found" });
    res.json(testType);
  }));

  app.delete("/api/test-types/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteTestType(id);
    res.json({ message: "Test type deleted" });
  }));

  // === TEST TRACKER ===

  app.get("/api/test-tracker", requireAuth, validate({ query: z.object({
    projectId: z.coerce.number().int().optional(),
    projectName: z.string().optional(),
    testTypeId: z.coerce.number().int().optional(),
    environment: z.string().optional(),
    status: z.string().optional(),
    startDate: z.string().optional(),
    endDate: z.string().optional(),
    releaseTag: z.string().optional(),
    page: z.coerce.number().int().min(1).optional(),
    limit: z.coerce.number().int().min(1).max(100).optional(),
    sortBy: z.string().optional(),
    sortDir: z.enum(["asc", "desc"]).optional(),
  }).passthrough() }), asyncHandler(async (req, res) => {
    const q = req.query as any;
    const filters: any = {};
    if (q.projectId) filters.projectId = q.projectId;
    if (q.projectName) filters.projectName = q.projectName;
    if (q.testTypeId) filters.testTypeId = q.testTypeId;
    if (q.environment) filters.environment = q.environment;
    if (q.status) filters.status = q.status;
    if (q.startDate) filters.startDate = q.startDate;
    if (q.endDate) filters.endDate = q.endDate;
    if (q.releaseTag) filters.releaseTag = q.releaseTag;
    
    const result = await storage.getTestTrackerRecordsPaginated(filters, {
      page: Number(q.page) || 1,
      pageSize: Number(q.limit) || 25,
      sortBy: q.sortBy || undefined,
      sortDir: q.sortDir === "asc" ? "asc" : "desc",
    });
    
    res.json({ data: result.data, total: result.total, page: result.page, pageSize: result.pageSize });
  }));

  app.get("/api/test-tracker/stats", requireAuth, asyncHandler(async (req, res) => {
    const filters: any = {};
    if (req.query.projectId) filters.projectId = Number(req.query.projectId);
    if (req.query.projectName) filters.projectName = req.query.projectName as string;
    if (req.query.testTypeId) filters.testTypeId = Number(req.query.testTypeId);
    if (req.query.environment) filters.environment = req.query.environment as string;
    if (req.query.status) filters.status = req.query.status as string;
    if (req.query.startDate) filters.startDate = req.query.startDate as string;
    if (req.query.endDate) filters.endDate = req.query.endDate as string;
    if (req.query.releaseTag) filters.releaseTag = req.query.releaseTag as string;

    const records = await storage.getTestTrackerRecords(filters);
    const total = records.length;
    const completed = records.filter(r => r.status === "completed").length;
    const failed = records.filter(r => r.status === "failed").length;
    const running = records.filter(r => r.status === "running").length;
    const passRate = total > 0 ? (completed / total) * 100 : 0;
    const avgResponseTime = records.filter(r => r.avgResponseTime != null).length > 0
      ? records.filter(r => r.avgResponseTime != null).reduce((sum, r) => sum + (r.avgResponseTime || 0), 0) / records.filter(r => r.avgResponseTime != null).length
      : 0;
    const totalDurationHours = records.reduce((sum, r) => sum + (r.durationSeconds || 0), 0) / 3600;
    const avgThroughput = records.filter(r => r.throughput != null).length > 0
      ? records.filter(r => r.throughput != null).reduce((sum, r) => sum + (r.throughput || 0), 0) / records.filter(r => r.throughput != null).length
      : 0;
    const avgErrorRate = records.filter(r => r.errorRate != null).length > 0
      ? records.filter(r => r.errorRate != null).reduce((sum, r) => sum + (r.errorRate || 0), 0) / records.filter(r => r.errorRate != null).length
      : 0;

    const projects = Array.from(new Set(records.map(r => r.projectName).filter(Boolean)));
    const environments = Array.from(new Set(records.map(r => r.environment).filter(Boolean)));
    const testTypes = Array.from(new Set(records.map(r => r.testTypeName).filter(Boolean)));

    res.json({
      total, completed, failed, running, passRate,
      avgResponseTime, totalDurationHours, avgThroughput, avgErrorRate,
      projects, environments, testTypes,
    });
  }));

  app.patch("/api/test-tracker/:id/comment", requireNonViewer, validate({ params: idParam, body: z.object({ comments: z.string() }) }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const { comments } = req.body;
    await storage.updateTestTrackerComment(id, comments);
    res.json({ message: "Comment updated" });
  }));

  app.delete("/api/test-tracker/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteTrackerRecord(id);
    res.json({ message: "Tracker record deleted" });
  }));

  app.patch("/api/test-tracker/reorder", requireEngineerOrAdmin, validate({ body: z.object({ orderedIds: z.array(z.number().int()).min(1, "orderedIds array is required") }) }), asyncHandler(async (req, res) => {
    const { orderedIds } = req.body;
    await db.transaction(async (tx) => {
      for (let i = 0; i < orderedIds.length; i++) {
        await tx.update(testTracker).set({ sortOrder: i + 1 }).where(eq(testTracker.id, orderedIds[i]));
      }
    });
    res.json({ message: "Order updated" });
  }));

  app.get("/api/test-tracker/export", requireAuth, asyncHandler(async (req, res) => {
    const filters: any = {};
    if (req.query.projectId) filters.projectId = Number(req.query.projectId);
    if (req.query.projectName) filters.projectName = req.query.projectName as string;
    if (req.query.testTypeId) filters.testTypeId = Number(req.query.testTypeId);
    if (req.query.environment) filters.environment = req.query.environment as string;
    if (req.query.status) filters.status = req.query.status as string;
    if (req.query.startDate) filters.startDate = req.query.startDate as string;
    if (req.query.endDate) filters.endDate = req.query.endDate as string;
    if (req.query.releaseTag) filters.releaseTag = req.query.releaseTag as string;
    
    const records = await storage.getTestTrackerRecords(filters);
    
    const csvHeader = "Run ID,Execution Date,Project,Feature,Test Type,Volume,Environment,Release Tag,Status,Duration (s),Avg (ms),P95 (ms),P99 (ms),Throughput,Error %,Comments\n";
    const csvRows = records.map(r => 
      `"${r.runId}","${r.executionTimestamp}","${r.projectName || ''}","${r.featureName}","${r.testTypeName || ''}","${r.volume || ''}","${r.environment || ''}","${r.releaseTag || ''}","${r.status}","${r.durationSeconds || ''}","${r.avgResponseTime || ''}","${r.p95 || ''}","${r.p99 || ''}","${r.throughput || ''}","${r.errorRate || ''}","${(r.comments || '').replace(/"/g, '""')}"`
    ).join("\n");
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=test-tracker-${new Date().toISOString().split('T')[0]}.csv`);
    res.send(csvHeader + csvRows);
  }));

  // === TREND ANALYSIS ===

  app.get("/api/trends", requireAuth, validate({ query: z.object({ scriptId: z.coerce.number().optional(), scheduleId: z.coerce.number().optional(), metric: z.string().optional(), limit: z.coerce.number().int().min(1).max(100).optional() }).passthrough().refine(d => d.scriptId || d.scheduleId, { message: "scriptId or scheduleId is required" }) }), asyncHandler(async (req, res) => {
    const scriptId = req.query.scriptId as unknown as number | undefined ?? null;
    const scheduleId = req.query.scheduleId as unknown as number | undefined ?? null;
    const metric = (req.query.metric as string) || "avgResponseTime";
    const limit = (req.query.limit as unknown as number) || 20;

    let executions: any[];
    if (scheduleId) {
      executions = await storage.getExecutionsByScheduleId(scheduleId, limit);
    } else {
      executions = await storage.getExecutionsByScriptId(scriptId!, limit);
    }

    const completedExecutions = executions.filter(e => e.status === 'completed' && e.resultSummary);
    const trendData = completedExecutions.map(exec => {
      const summary = exec.resultSummary || {};
      return {
        executionId: exec.id,
        executionUid: exec.executionId,
        startTime: exec.startTime,
        avgResponseTime: summary.avgResponseTime,
        throughput: summary.throughput,
        errorRate: summary.failedRequests && summary.totalRequests 
          ? (summary.failedRequests / summary.totalRequests) * 100 
          : 0,
        totalRequests: summary.totalRequests,
        p90: summary.transactionDetails?.[0]?.p90,
        p95: summary.transactionDetails?.[0]?.p95,
      };
    }).reverse();

    res.json({
      metric,
      data: trendData,
      scriptId,
      scheduleId,
    });
  }));

  app.get("/api/trends/aggregated", requireAuth, asyncHandler(async (req, res) => {
    const startDate = req.query.startDate as string | undefined;
    const endDate = req.query.endDate as string | undefined;
    const scriptId = req.query.scriptId ? Number(req.query.scriptId) : undefined;
    const environment = req.query.environment as string | undefined;
    const releaseTag = req.query.releaseTag as string | undefined;
    const limit = Math.min(Number(req.query.limit) || 500, 1000);

    const conditions: any[] = [
      eq(testExecutions.status, 'completed'),
      isNotNull(testExecutions.resultSummary),
      isNotNull(testExecutions.startTime),
    ];

    if (startDate) conditions.push(gte(testExecutions.startTime, startDate));
    if (endDate) conditions.push(lte(testExecutions.startTime, endDate));
    if (releaseTag) conditions.push(eq(testExecutions.releaseTag, releaseTag));

    if (scriptId) {
      const scheduleRows = await db.select({ id: testSchedules.id }).from(testSchedules)
        .where(eq(testSchedules.scriptId, scriptId));
      if (scheduleRows.length > 0) {
        conditions.push(inArray(testExecutions.scheduleId, scheduleRows.map(s => s.id)));
      } else {
        return res.json({ data: [], scripts: [], environments: [], total: 0 });
      }
    }

    const rows = await db.select({
      id: testExecutions.id,
      executionId: testExecutions.executionId,
      scheduleId: testExecutions.scheduleId,
      testName: testExecutions.testName,
      startTime: testExecutions.startTime,
      status: testExecutions.status,
      resultSummary: testExecutions.resultSummary,
    }).from(testExecutions)
      .where(and(...conditions))
      .orderBy(asc(testExecutions.startTime))
      .limit(limit);

    const scheduleIds = Array.from(new Set(rows.map(r => r.scheduleId).filter(Boolean))) as number[];
    let scheduleMap: Record<number, { name: string; scriptId: number | null; scriptName: string | null; environment: string | null }> = {};
    if (scheduleIds.length > 0) {
      const schedRows = await db.select({
        id: testSchedules.id,
        name: testSchedules.name,
        scriptId: testSchedules.scriptId,
        configuration: testSchedules.configuration,
      }).from(testSchedules).where(inArray(testSchedules.id, scheduleIds));

      const scriptIds = Array.from(new Set(schedRows.map(s => s.scriptId).filter(Boolean))) as number[];
      let scriptMap: Record<number, string> = {};
      if (scriptIds.length > 0) {
        const scriptRows = await db.select({ id: scripts.id, name: scripts.name }).from(scripts)
          .where(inArray(scripts.id, scriptIds));
        scriptMap = Object.fromEntries(scriptRows.map(s => [s.id, s.name]));
      }

      scheduleMap = Object.fromEntries(schedRows.map(s => [s.id, {
        name: s.name,
        scriptId: s.scriptId,
        scriptName: s.scriptId ? scriptMap[s.scriptId] || null : null,
        environment: (s.configuration as any)?.environment || null,
      }]));
    }

    if (environment) {
      const filteredRows = rows.filter(r => {
        if (!r.scheduleId) return false;
        const sched = scheduleMap[r.scheduleId];
        return sched?.environment === environment;
      });
      rows.length = 0;
      rows.push(...filteredRows);
    }

    const prevAvgByScript = new Map<string, number[]>();
    const data = rows.map((row, idx) => {
      const summary = row.resultSummary as any;
      if (!summary) return null;
      const details = summary.transactionDetails || [];
      const totalCount = details.reduce((s: number, d: any) => s + d.count, 0);
      const weightedP50 = totalCount > 0
        ? details.reduce((s: number, d: any) => s + (d.p50 || d.avg || 0) * d.count, 0) / totalCount : (summary.p50 || 0);
      const weightedP90 = totalCount > 0
        ? details.reduce((s: number, d: any) => s + (d.p90 || 0) * d.count, 0) / totalCount : (summary.p90 || 0);
      const weightedP95 = totalCount > 0
        ? details.reduce((s: number, d: any) => s + d.p95 * d.count, 0) / totalCount : 0;
      const weightedP99 = totalCount > 0
        ? details.reduce((s: number, d: any) => s + d.p99 * d.count, 0) / totalCount : 0;

      const transactions = details.map((d: any) => ({
        label: d.label,
        avg: Math.round(d.avg || 0),
        p95: Math.round(d.p95 || 0),
        throughput: Math.round((d.throughput || d.hitsPerSec || 0) * 100) / 100,
        errorRate: Math.round((d.errorRate || 0) * 100) / 100,
      }));

      const sched = row.scheduleId ? scheduleMap[row.scheduleId] : null;
      const scriptKey = sched?.scriptId?.toString() || `remote-${row.id}`;
      const avgRT = summary.avgResponseTime || 0;

      const history = prevAvgByScript.get(scriptKey) || [];
      let isRegression = false;
      let regressionConfidence: 'none' | 'low' | 'medium' | 'high' = 'none';
      if (history.length >= 3) {
        const baselineWindow = history.slice(-5);
        const baselineMean = baselineWindow.reduce((s, v) => s + v, 0) / baselineWindow.length;
        const baselineStdDev = Math.sqrt(baselineWindow.reduce((s, v) => s + (v - baselineMean) ** 2, 0) / baselineWindow.length);
        const zScore = baselineStdDev > 0 ? (avgRT - baselineMean) / baselineStdDev : 0;
        const pctChange = baselineMean > 0 ? ((avgRT - baselineMean) / baselineMean) * 100 : 0;

        if (zScore > 2.5 && pctChange > 20) {
          isRegression = true;
          regressionConfidence = zScore > 4 ? 'high' : zScore > 3 ? 'medium' : 'low';
        }
      } else if (history.length >= 1) {
        const prev = history[history.length - 1];
        const pctChange = prev > 0 ? ((avgRT - prev) / prev) * 100 : 0;
        if (pctChange > 30) {
          isRegression = true;
          regressionConfidence = 'low';
        }
      }
      history.push(avgRT);
      prevAvgByScript.set(scriptKey, history);

      const errorRate = summary.totalRequests
        ? (summary.failedRequests / summary.totalRequests) * 100 : 0;

      return {
        id: row.id,
        executionId: row.executionId,
        startTime: row.startTime,
        scheduleName: sched?.name || (row.testName || 'Remote Execution'),
        scriptId: scriptKey,
        scriptName: sched?.scriptName || (row.testName || 'Remote Test'),
        environment: sched?.environment || 'unknown',
        avgResponseTime: Math.round(avgRT),
        p50: Math.round(weightedP50),
        p90: Math.round(weightedP90),
        p95: Math.round(weightedP95),
        p99: Math.round(weightedP99),
        throughput: Math.round((summary.throughput || 0) * 100) / 100,
        errorRate: Math.round(errorRate * 100) / 100,
        totalRequests: summary.totalRequests || 0,
        failedRequests: summary.failedRequests || 0,
        isRegression,
        regressionConfidence,
        transactions,
      };
    }).filter(Boolean);

    const allScripts = new Map<string, string>();
    const allEnvs = new Set<string>();
    data.forEach(d => {
      if (d) {
        allScripts.set(d.scriptId, d.scriptName);
        if (d.environment !== 'unknown') allEnvs.add(d.environment);
      }
    });

    const executionIds = data.filter(Boolean).map(d => d!.id);
    let achievementMap: Record<number, string> = {};
    try {
      if (executionIds.length > 0) {
        const execTargets = await db.select({
          executionId: executionWorkloadTargets.executionId,
          targets: executionWorkloadTargets,
        }).from(executionWorkloadTargets)
          .where(inArray(executionWorkloadTargets.executionId, executionIds));

        const scriptTargetMap: Record<number, any> = {};
        const scriptIdsForTargets = Array.from(new Set(
          rows.filter(r => r.scheduleId && scheduleMap[r.scheduleId]?.scriptId)
            .map(r => scheduleMap[r.scheduleId!]!.scriptId!)
        ));
        if (scriptIdsForTargets.length > 0) {
          const scriptTargetRows = await db.select({
            id: scripts.id,
            workloadTargets: scripts.workloadTargets,
          }).from(scripts)
            .where(and(inArray(scripts.id, scriptIdsForTargets), isNotNull(scripts.workloadTargets)));
          scriptTargetRows.forEach(s => {
            if (s.workloadTargets) scriptTargetMap[s.id] = s.workloadTargets;
          });
        }

        const execTargetMap: Record<number, any> = {};
        execTargets.forEach(et => {
          execTargetMap[et.executionId] = et.targets;
        });

        for (const row of rows) {
          const summary = row.resultSummary as any;
          if (!summary) continue;

          let targets: any = execTargetMap[row.id];
          if (!targets && row.scheduleId) {
            const sched = scheduleMap[row.scheduleId];
            if (sched?.scriptId) {
              targets = scriptTargetMap[sched.scriptId];
            }
          }
          if (!targets) continue;

          try {
            const actual: ActualMetrics = {
              totalRequests: summary.totalRequests || 0,
              failedRequests: summary.failedRequests || 0,
              avgResponseTime: summary.avgResponseTime || 0,
              throughput: summary.throughput || 0,
              errorRate: summary.totalRequests ? (summary.failedRequests / summary.totalRequests) * 100 : 0,
              durationSeconds: summary.durationSeconds || 0,
              maxActiveThreads: summary.maxActiveThreads || 0,
            };
            const result = analyzeWorkloadAchievement(targets as WorkloadTargets, actual);
            achievementMap[row.id] = result.verdict;
          } catch {}
        }
      }
    } catch {}

    const enrichedData = data.map(d => d ? { ...d, achievementVerdict: achievementMap[d.id] || null } : null);

    res.json({
      data: enrichedData,
      scripts: Array.from(allScripts.entries()).map(([id, name]) => ({ id, name })),
      environments: Array.from(allEnvs).sort(),
      total: enrichedData.length,
    });
  }));

  // === SAVED FILTER VIEWS ===

  app.get("/api/saved-views", requireAuth, asyncHandler(async (req, res) => {
    const userId = (req.session as any).user?.id;
    const page = (req.query.page as string) || "tracker";
    const views = await storage.getSavedFilterViews(userId, page);
    res.json(views);
  }));

  app.post("/api/saved-views", requireAuth, validate({ body: z.object({
    name: z.string().min(1).max(100),
    page: z.string().min(1),
    filters: z.record(z.unknown()),
    isDefault: z.boolean().optional(),
  }) }), asyncHandler(async (req, res) => {
    const userId = (req.session as any).user?.id;
    const { name, page, filters, isDefault } = req.body;
    const view = await storage.createSavedFilterView({ name, page, filters, isDefault: isDefault || false, userId });
    if (isDefault) {
      await storage.updateSavedFilterViewDefault(view.id, userId, page, true);
    }
    res.status(201).json(view);
  }));

  app.delete("/api/saved-views/:id", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const userId = (req.session as any).user?.id;
    const id = req.params.id as unknown as number;
    await storage.deleteSavedFilterView(id, userId);
    res.json({ message: "View deleted" });
  }));

  app.patch("/api/saved-views/:id/default", requireAuth, validate({ params: idParam, body: z.object({ isDefault: z.boolean() }) }), asyncHandler(async (req, res) => {
    const userId = (req.session as any).user?.id;
    const id = req.params.id as unknown as number;
    const page = (req.query.page as string) || "tracker";
    await storage.updateSavedFilterViewDefault(id, userId, page, req.body.isDefault);
    res.json({ message: "Default updated" });
  }));

  // === CUSTOM ENVIRONMENTS ===

  app.get("/api/environments", requireAuth, asyncHandler(async (req, res) => {
    const customEnvs = await storage.getCustomEnvironments();
    res.json(customEnvs);
  }));

  app.post("/api/environments", requireNonViewer, validate({ body: z.object({ name: z.string().min(1, "Environment name is required").transform(s => s.trim()), description: z.string().optional().nullable() }) }), asyncHandler(async (req, res) => {
    const sessionUser = (req.session as any).user;
    const { name, description } = req.body;
    
    try {
      const env = await storage.createCustomEnvironment({
        name,
        description: description || null,
        createdBy: sessionUser.id
      });
      res.status(201).json(env);
    } catch (error: any) {
      if (error.code === '23505') {
        return res.status(400).json({ message: "Environment with this name already exists" });
      }
      throw error;
    }
  }));

  app.delete("/api/environments/:id", requireAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    
    await storage.deleteCustomEnvironment(id);
    res.json({ message: "Environment deleted" });
  }));

  // ================== JMETER EXECUTION API ==================
  
  const executionIdParam = z.object({ executionId: z.string().regex(/^\d+$/).transform(Number) });

  app.post("/api/jmeter/start/:scriptId", requireEngineerOrAdmin, validate({ params: scriptIdParam, body: z.object({ vusers: z.number().optional(), rampUp: z.number().optional(), duration: z.number().optional() }).optional() }), asyncHandler(async (req, res) => {
    const scriptId = req.params.scriptId as unknown as number;

    const script = await storage.getScript(scriptId);
    if (!script) return res.status(404).json({ message: "Script not found" });
    if (!script.filePath) {
      return res.status(400).json({ message: "Script does not have a JMX file uploaded" });
    }

    const { vusers, rampUp, duration } = req.body || {};
    const executionId = generateExecutionId();

    const execution = await storage.createExecution({
      executionId,
      scheduleId: null,
      status: "queued",
      startTime: null,
      endTime: null,
      resultSummary: null,
      artifactsPath: null,
      reportHtmlPath: null,
      reportComments: null,
      liveMetrics: null,
    } as any);

    queueJMeterRun(execution.id, {
      executionId,
      jmxPath: script.filePath,
      dependencyFiles: (script as any).dependencyFiles || [],
      jarFiles: (script as any).jarFiles || [],
      vusers: vusers ? Number(vusers) : undefined,
      rampUp: rampUp ? Number(rampUp) : undefined,
      duration: duration ? Number(duration) : undefined,
    });

    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);

    res.status(202).json({
      message: "Test queued for execution",
      executionId: execution.id,
      runId: executionId,
      status: "queued",
    });
  }));

  app.get("/api/jmeter/status/:executionId", requireAuth, validate({ params: executionIdParam }), asyncHandler(async (req, res) => {
    const id = req.params.executionId as unknown as number;

    const execution = await storage.getExecution(id);
    if (!execution) return res.status(404).json({ message: "Execution not found" });

    res.json({
      executionId: execution.id,
      runId: execution.executionId,
      status: execution.status,
      startTime: execution.startTime,
      endTime: execution.endTime,
      artifactsPath: execution.artifactsPath,
    });
  }));

  app.get("/api/jmeter/results/:executionId", requireAuth, validate({ params: executionIdParam }), asyncHandler(async (req, res) => {
    const id = req.params.executionId as unknown as number;

    const execution = await storage.getExecution(id);
    if (!execution) return res.status(404).json({ message: "Execution not found" });

    if (execution.status !== "completed" && execution.status !== "failed") {
      return res.status(202).json({
        message: "Test is still running",
        status: execution.status,
      });
    }

    res.json({
      executionId: execution.id,
      runId: execution.executionId,
      status: execution.status,
      startTime: execution.startTime,
      endTime: execution.endTime,
      results: execution.resultSummary,
      artifactsPath: execution.artifactsPath,
    });
  }));

  app.get("/api/jmeter/queue", requireAuth, asyncHandler(async (req, res) => {
    const status = getQueueStatus();
    res.json(status);
  }));

  return httpServer;
}

async function seedDatabase() {
  const userCount = await storage.getUserCount();
  if (userCount === 0) {
    console.log("No users found. The first user to sign up will become the admin.");
    return;
  }
  
  const existingScripts = await storage.getScripts();
  if (existingScripts.length > 0) return;
  
  const allUsers = await storage.getUsers();
  const admin = allUsers.find(u => u.role === 'admin') || allUsers[0];
  if (!admin) return;
  
  console.log("Seeding sample data for existing admin...");

  const script1 = await storage.createScript({ name: "Login & Checkout Flow", description: "Critical user path for e-commerce", toolType: "JMeter", filePath: "uploads/scripts/sample-jmeter-test.jmx", uploadedBy: admin.id });

  const schedule1 = await storage.createSchedule({
    name: "Nightly Regression",
    scriptId: script1.id,
    scheduledTime: new Date(Date.now() - 86400000).toISOString(),
    status: "completed",
    configuration: { environment: "Staging" },
    createdBy: admin.id
  });

  const schedule3 = await storage.createSchedule({
    name: "Live Flash Sale Simulation",
    scriptId: script1.id,
    scheduledTime: new Date().toISOString(),
    status: "running",
    configuration: { environment: "Production" },
    createdBy: admin.id
  });

  const resultSummary = {
    totalRequests: 15000,
    failedRequests: 12,
    avgResponseTime: 250,
    throughput: 45.5,
    transactionDetails: [
      { label: "Login", count: 5000, avg: 200, p50: 180, p90: 300, p95: 350, p99: 500, max: 800, hitsPerSec: 15, throughput: 15, errorRate: 0.1 },
      { label: "Search", count: 7000, avg: 150, p50: 120, p90: 240, p95: 280, p99: 400, max: 600, hitsPerSec: 20, throughput: 20, errorRate: 0.2 },
      { label: "Checkout", count: 3000, avg: 450, p50: 400, p90: 700, p95: 800, p99: 1200, max: 1500, hitsPerSec: 10.5, throughput: 10.5, errorRate: 0.5 }
    ]
  };

  const exec1 = await storage.createExecution({
    executionId: "EXE-20260117-134308-SEED",
    scheduleId: schedule1.id,
    startTime: new Date(Date.now() - 90000000).toISOString(),
    endTime: new Date(Date.now() - 86400000).toISOString(),
    status: "completed",
    resultSummary,
    artifactsPath: "/results/exec_1.zip",
    reportHtmlPath: "/reports/report_1.html"
  });

  
  const exec3 = await storage.createExecution({
    executionId: "EXE-20260118-143308-SEED",
    scheduleId: schedule3.id,
    startTime: new Date(Date.now() - 600000),
    status: "queued",
    resultSummary: null,
    artifactsPath: null,
    liveMetrics: null,
  } as any);

  const reportDir = path.join(process.cwd(), "attached_assets", "reports");
  fs.mkdirSync(reportDir, { recursive: true });

  const execution1WithRelations = await storage.getExecution(exec1.id);

  if (execution1WithRelations) {
    const html1 = generateHtmlReport(execution1WithRelations as any);
    fs.writeFileSync(path.join(reportDir, `report_${exec1.id}.html`), html1);
  }

  await storage.createComment({ executionId: exec1.id, userId: admin.id, content: "Looks good, response times are stable.", type: "sign-off" });
  await storage.createComment({ executionId: exec1.id, userId: admin.id, content: "Agreed. Ready for release.", type: "comment" });
}
