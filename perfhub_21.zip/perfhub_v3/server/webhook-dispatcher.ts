import { db } from "./db";
import { webhooks, webhookDeliveries } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import crypto from "crypto";

export const WEBHOOK_EVENTS = {
  EXECUTION_COMPLETED: "execution.completed",
  EXECUTION_FAILED: "execution.failed",
  SLA_BREACH: "sla.breach",
  ANOMALY_DETECTED: "anomaly.detected",
  REPORT_APPROVED: "report.approved",
} as const;

function formatSlackPayload(event: string, payload: any): any {
  const summary = typeof payload === "object"
    ? Object.entries(payload)
        .filter(([k]) => k !== "event")
        .map(([k, v]) => `*${k}:* ${typeof v === "object" ? JSON.stringify(v) : v}`)
        .join("\n")
    : String(payload);
  return {
    text: `[PerfHub] ${event}\n${summary}`,
  };
}

function formatTeamsPayload(event: string, payload: any): any {
  const summary = typeof payload === "object"
    ? Object.entries(payload)
        .filter(([k]) => k !== "event")
        .map(([k, v]) => `**${k}:** ${typeof v === "object" ? JSON.stringify(v) : v}`)
        .join("\n\n")
    : String(payload);
  return {
    "@type": "MessageCard",
    title: `[PerfHub] ${event}`,
    text: summary,
  };
}

function formatPagerDutyPayload(event: string, payload: any, url: string): any {
  const routingKey = url.split("/").pop() || url;
  const severity = event.includes("failed") || event.includes("breach")
    ? "critical"
    : event.includes("anomaly")
      ? "warning"
      : "info";
  const summary = typeof payload === "object"
    ? `[PerfHub] ${event}: ${JSON.stringify(payload)}`
    : `[PerfHub] ${event}: ${payload}`;
  return {
    routing_key: routingKey,
    event_action: "trigger",
    payload: {
      summary: summary.slice(0, 1024),
      severity,
      source: "PerfHub",
    },
  };
}

function signPayload(payload: string, secret: string): string {
  return crypto.createHmac("sha256", secret).update(payload).digest("hex");
}

async function deliverWebhook(
  webhook: any,
  event: string,
  payload: any,
): Promise<void> {
  let body: any;
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "User-Agent": "PerfHub-Webhook/1.0",
    ...(webhook.headers || {}),
  };

  switch (webhook.type) {
    case "slack":
      body = formatSlackPayload(event, payload);
      break;
    case "teams":
      body = formatTeamsPayload(event, payload);
      break;
    case "pagerduty":
      body = formatPagerDutyPayload(event, payload, webhook.url);
      break;
    default: {
      body = { event, ...payload };
      if (webhook.secret) {
        const raw = JSON.stringify(body);
        headers["X-Webhook-Signature"] = `sha256=${signPayload(raw, webhook.secret)}`;
      }
      break;
    }
  }

  const bodyStr = JSON.stringify(body);
  let lastError: string | null = null;
  let responseStatus: number | null = null;
  let responseBody: string | null = null;
  let attempts = 0;
  const maxAttempts = 3;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    attempts = attempt + 1;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);

      const res = await fetch(webhook.url, {
        method: "POST",
        headers,
        body: bodyStr,
        signal: controller.signal,
      });

      clearTimeout(timeout);
      responseStatus = res.status;
      responseBody = await res.text().catch(() => null);

      if (res.ok) {
        lastError = null;
        break;
      }

      lastError = `HTTP ${res.status}: ${responseBody?.slice(0, 500) || "No response body"}`;
    } catch (err: any) {
      lastError = err.name === "AbortError" ? "Request timed out (10s)" : err.message;
      responseStatus = null;
      responseBody = null;
    }

    if (attempt < maxAttempts - 1) {
      const delay = Math.pow(attempt + 1, 2) * 1000;
      await new Promise((r) => setTimeout(r, delay));
    }
  }

  const deliveryStatus = lastError ? "failed" : "success";

  try {
    await db.insert(webhookDeliveries).values({
      webhookId: webhook.id,
      event,
      payload,
      responseStatus,
      responseBody: responseBody?.slice(0, 2000) || null,
      error: lastError,
      attempts,
    });
  } catch (err) {
    console.error("[webhook] Failed to record delivery:", err);
  }

  try {
    await db
      .update(webhooks)
      .set({
        lastDeliveryAt: new Date().toISOString(),
        lastDeliveryStatus: deliveryStatus,
      })
      .where(eq(webhooks.id, webhook.id));
  } catch (err) {
    console.error("[webhook] Failed to update webhook status:", err);
  }
}

export async function deliverToWebhook(
  webhook: any,
  event: string,
  payload: any,
): Promise<void> {
  return deliverWebhook(webhook, event, payload);
}

export async function dispatchWebhookEvent(
  event: string,
  payload: any,
): Promise<void> {
  try {
    const allWebhooks = await db
      .select()
      .from(webhooks)
      .where(eq(webhooks.enabled, true));

    const matching = allWebhooks.filter(
      (w) => Array.isArray(w.events) && w.events.includes(event),
    );

    if (matching.length === 0) return;

    await Promise.allSettled(
      matching.map((w) => deliverWebhook(w, event, payload)),
    );
  } catch (err) {
    console.error("[webhook] Failed to dispatch event:", event, err);
  }
}
