import { type Express, type Request, type Response } from "express";
import * as reportStorage from "./completion-report-storage";
import { db } from "./db";
import { testExecutions, testSchedules, scripts, projects, reportApprovals, testCompletionReports, users, notifications } from "@shared/schema";
import { eq, inArray, asc, and, sql } from "drizzle-orm";
import { generateDocxReport } from "./completion-report-docx";
import { validate, z, idParam } from "./validation";
import { asyncHandler } from "./error-handler";
import { storage } from "./storage";
import { requireAuth, requireNonViewer } from "./route-middleware";

function escapeHtml(str: string): string {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function buildReviewRequestEmail(data: { reportTitle: string; requesterName: string; reviewerName: string; stepOrder: number; totalReviewers: number; reportLink: string }): string {
  const title = escapeHtml(data.reportTitle);
  const requester = escapeHtml(data.requesterName);
  const reviewer = escapeHtml(data.reviewerName);
  const baseUrl = process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : "";
  const reportUrl = `${baseUrl}${data.reportLink}`;
  return `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background: linear-gradient(135deg, #3b82f6, #1d4ed8); padding: 24px; border-radius: 12px 12px 0 0; text-align: center;">
        <h1 style="color: white; margin: 0; font-size: 20px;">Sign-Off Review Requested</h1>
      </div>
      <div style="background: #ffffff; border: 1px solid #e5e7eb; border-top: none; padding: 24px; border-radius: 0 0 12px 12px;">
        <p style="color: #374151; font-size: 15px; line-height: 1.6;">Hi ${reviewer},</p>
        <p style="color: #374151; font-size: 15px; line-height: 1.6;">
          <strong>${requester}</strong> has requested your review on the following performance report:
        </p>
        <div style="background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; margin: 16px 0;">
          <p style="margin: 0 0 8px 0; font-size: 14px; color: #6b7280;">Report</p>
          <p style="margin: 0; font-size: 16px; font-weight: 600; color: #111827;">${title}</p>
        </div>
        <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 12px 16px; margin: 16px 0;">
          <p style="margin: 0; font-size: 14px; color: #1d4ed8;">
            You are reviewer <strong>#${data.stepOrder}</strong> of <strong>${data.totalReviewers}</strong>.
            ${data.stepOrder > 1 ? " You will be able to review once previous reviewers have acted." : " You are first in the review queue."}
          </p>
        </div>
        <div style="text-align: center; margin: 20px 0;">
          <a href="${reportUrl}" style="display: inline-block; background: #3b82f6; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 14px;">Review Report</a>
        </div>
        <p style="color: #374151; font-size: 15px; line-height: 1.6;">
          Please log in to PerfHub to review and download the report, then approve, reject, or request changes.
        </p>
        <p style="color: #9ca3af; font-size: 12px; margin-top: 24px; border-top: 1px solid #e5e7eb; padding-top: 16px;">
          This is an automated notification from PerfHub. You can manage your notification preferences in Settings.
        </p>
      </div>
    </div>
  `;
}

export function registerCompletionReportRoutes(app: Express): void {
  app.get("/api/completion-reports", requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const reports = await reportStorage.getCompletionReports();
    res.json(reports);
  }));

  app.get("/api/completion-reports/reviewers", requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const allUsers = await db
      .select({
        id: users.id,
        username: users.username,
        email: users.email,
        role: users.role,
        isApproved: users.isApproved,
      })
      .from(users)
      .where(eq(users.isApproved, true));
    res.json(allUsers);
  }));

  app.get("/api/completion-reports/:id", requireAuth, validate({ params: idParam }), asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as unknown as number;
    const report = await reportStorage.getCompletionReport(id);
    if (!report) return res.status(404).json({ message: "Report not found" });
    res.json(report);
  }));

  app.post("/api/completion-reports", requireNonViewer, validate({ body: z.object({ title: z.string().min(1, "Title is required"), executionIds: z.array(z.number().int()).min(1, "At least one execution is required"), projectId: z.number().optional().nullable(), projectName: z.string().optional().nullable(), featureName: z.string().optional().nullable(), objective: z.string().optional().nullable(), scope: z.string().optional().nullable(), environmentNotes: z.string().optional().nullable(), recommendations: z.string().optional().nullable(), overallVerdict: z.string().optional(), verdictNotes: z.string().optional().nullable(), compareExecutionIds: z.array(z.number().int()).optional().nullable(), status: z.string().optional(), customSections: z.array(z.object({ title: z.string(), content: z.string() })).optional().nullable() }) }), asyncHandler(async (req: Request, res: Response) => {
    const userId = (req.session as any).user.id;
    const { title, projectId, projectName, featureName, objective, scope, environmentNotes, recommendations, overallVerdict, verdictNotes, executionIds, compareExecutionIds, status, customSections } = req.body;

    const compareIds = Array.isArray(compareExecutionIds) && compareExecutionIds.length > 0 ? compareExecutionIds : null;
    const snapshot = await buildReportSnapshot(executionIds, compareIds);

    if (customSections && customSections.length > 0) {
      (snapshot as any).customSections = customSections;
    }

    const report = await reportStorage.createCompletionReport({
      title,
      projectId: projectId || null,
      projectName: projectName || null,
      featureName: featureName || null,
      objective: objective || null,
      scope: scope || null,
      environmentNotes: environmentNotes || null,
      recommendations: recommendations || null,
      overallVerdict: overallVerdict || 'pending',
      verdictNotes: verdictNotes || null,
      executionIds,
      compareExecutionIds: compareIds,
      reportSnapshot: snapshot,
      status: status || 'draft',
      createdBy: userId,
    });

    res.status(201).json(report);
  }));

  app.patch("/api/completion-reports/:id", requireNonViewer, validate({ params: idParam, body: z.object({ title: z.string().min(1).optional(), executionIds: z.array(z.number().int()).optional(), projectId: z.number().optional().nullable(), projectName: z.string().optional().nullable(), featureName: z.string().optional().nullable(), objective: z.string().optional().nullable(), scope: z.string().optional().nullable(), environmentNotes: z.string().optional().nullable(), recommendations: z.string().optional().nullable(), overallVerdict: z.string().optional(), verdictNotes: z.string().optional().nullable(), compareExecutionIds: z.array(z.number().int()).optional().nullable(), status: z.string().optional() }) }), asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as unknown as number;

    const existing = await reportStorage.getCompletionReport(id);
    if (!existing) return res.status(404).json({ message: "Report not found" });

    const updates: any = {};
    const allowedFields = ['title', 'projectId', 'projectName', 'featureName', 'objective', 'scope', 'environmentNotes', 'recommendations', 'overallVerdict', 'verdictNotes', 'status'];
    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field];
      }
    }

    if (req.body.compareExecutionIds !== undefined) {
      updates.compareExecutionIds = Array.isArray(req.body.compareExecutionIds) && req.body.compareExecutionIds.length > 0
        ? req.body.compareExecutionIds : null;
    }

    if (req.body.executionIds && Array.isArray(req.body.executionIds)) {
      updates.executionIds = req.body.executionIds;
      const compareIds = updates.compareExecutionIds !== undefined ? updates.compareExecutionIds : (existing.compareExecutionIds || null);
      updates.reportSnapshot = await buildReportSnapshot(req.body.executionIds, compareIds);
    } else if (updates.compareExecutionIds !== undefined) {
      updates.reportSnapshot = await buildReportSnapshot(existing.executionIds, updates.compareExecutionIds);
    }

    const report = await reportStorage.updateCompletionReport(id, updates);
    res.json(report);
  }));

  app.post("/api/completion-reports/:id/refresh-snapshot", requireNonViewer, validate({ params: idParam }), asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as unknown as number;

    const existing = await reportStorage.getCompletionReport(id);
    if (!existing) return res.status(404).json({ message: "Report not found" });

    const snapshot = await buildReportSnapshot(existing.executionIds, existing.compareExecutionIds || null);
    const report = await reportStorage.updateCompletionReport(id, { reportSnapshot: snapshot });
    res.json(report);
  }));

  app.delete("/api/completion-reports/:id", requireNonViewer, validate({ params: idParam }), asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as unknown as number;
    const deleted = await reportStorage.deleteCompletionReport(id);
    if (!deleted) return res.status(404).json({ message: "Report not found" });
    res.json({ success: true });
  }));

  app.get("/api/completion-reports/:id/docx", requireAuth, validate({ params: idParam }), asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as unknown as number;
    const report = await reportStorage.getCompletionReport(id);
    if (!report) return res.status(404).json({ message: "Report not found" });
    const approvals = await db
      .select({
        id: reportApprovals.id,
        stepOrder: reportApprovals.stepOrder,
        status: reportApprovals.status,
        comment: reportApprovals.comment,
        actedAt: reportApprovals.actedAt,
        reviewerName: users.username,
        reviewerEmail: users.email,
      })
      .from(reportApprovals)
      .leftJoin(users, eq(reportApprovals.reviewerUserId, users.id))
      .where(eq(reportApprovals.reportId, id))
      .orderBy(asc(reportApprovals.stepOrder));
    const buffer = await generateDocxReport(report, approvals);
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
    res.setHeader("Content-Disposition", `attachment; filename="signoff-report-${id}.docx"`);
    res.send(buffer);
  }));

  app.get("/api/completion-reports/:id/preview", requireAuth, validate({ params: idParam }), asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as unknown as number;
    const report = await reportStorage.getCompletionReport(id);
    if (!report) return res.status(404).json({ message: "Report not found" });

    const approvals = await db
      .select({
        id: reportApprovals.id,
        stepOrder: reportApprovals.stepOrder,
        status: reportApprovals.status,
        comment: reportApprovals.comment,
        actedAt: reportApprovals.actedAt,
        reviewerName: users.username,
        reviewerEmail: users.email,
      })
      .from(reportApprovals)
      .leftJoin(users, eq(reportApprovals.reviewerUserId, users.id))
      .where(eq(reportApprovals.reportId, id))
      .orderBy(asc(reportApprovals.stepOrder));

    const { generateReportPreviewHtml } = await import("./completion-report-html");
    const html = generateReportPreviewHtml(report, approvals);
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");
    res.send(html);
  }));

  app.get("/api/completion-reports/:id/approvals", requireAuth, validate({ params: idParam }), asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as unknown as number;

    const approvals = await db
      .select({
        id: reportApprovals.id,
        reportId: reportApprovals.reportId,
        reviewerUserId: reportApprovals.reviewerUserId,
        stepOrder: reportApprovals.stepOrder,
        status: reportApprovals.status,
        comment: reportApprovals.comment,
        actedAt: reportApprovals.actedAt,
        createdAt: reportApprovals.createdAt,
        reviewerUsername: users.username,
        reviewerEmail: users.email,
        reviewerRole: users.role,
      })
      .from(reportApprovals)
      .leftJoin(users, eq(reportApprovals.reviewerUserId, users.id))
      .where(eq(reportApprovals.reportId, id))
      .orderBy(asc(reportApprovals.stepOrder));

    res.json(approvals);
  }));

  app.post("/api/completion-reports/:id/request-review", requireNonViewer, validate({ params: idParam, body: z.object({ reviewers: z.array(z.number().int()).min(1, "At least one reviewer is required") }) }), asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as unknown as number;

    const userId = (req.session as any).user.id;
    const report = await reportStorage.getCompletionReport(id);
    if (!report) return res.status(404).json({ message: "Report not found" });

    if (report.createdBy !== userId) {
      const user = (req.session as any).user;
      if (user.role !== "admin" && user.role !== "lead") {
        return res.status(403).json({ message: "Only the report author, a lead, or an admin can request review" });
      }
    }

    const { reviewers: rawReviewers } = req.body;
    const reviewers = Array.from(new Set(rawReviewers as number[]));

    const validUsers = await db.select({ id: users.id }).from(users)
      .where(and(inArray(users.id, reviewers), eq(users.isApproved, true)));
    const validIds = new Set(validUsers.map(u => u.id));
    const invalidIds = reviewers.filter(id => !validIds.has(id));
    if (invalidIds.length > 0) {
      return res.status(400).json({ message: `Invalid or unapproved reviewer IDs: ${invalidIds.join(", ")}` });
    }

    const createdApprovals = await db.transaction(async (tx) => {
      await tx.delete(reportApprovals).where(eq(reportApprovals.reportId, id));

      const approvalValues = reviewers.map((reviewerId: number, index: number) => ({
        reportId: id,
        reviewerUserId: reviewerId,
        stepOrder: index + 1,
        status: "pending" as const,
      }));

      await tx.insert(reportApprovals).values(approvalValues);

      await tx.update(testCompletionReports)
        .set({
          reviewStatus: "in_review",
          reviewRequestedAt: new Date().toISOString(),
          finalApprovedAt: null,
          updatedAt: new Date().toISOString(),
        })
        .where(eq(testCompletionReports.id, id));

      return tx
        .select({
          id: reportApprovals.id,
          reportId: reportApprovals.reportId,
          reviewerUserId: reportApprovals.reviewerUserId,
          stepOrder: reportApprovals.stepOrder,
          status: reportApprovals.status,
          comment: reportApprovals.comment,
          actedAt: reportApprovals.actedAt,
          createdAt: reportApprovals.createdAt,
          reviewerUsername: users.username,
          reviewerEmail: users.email,
          reviewerRole: users.role,
        })
        .from(reportApprovals)
        .leftJoin(users, eq(reportApprovals.reviewerUserId, users.id))
        .where(eq(reportApprovals.reportId, id))
        .orderBy(asc(reportApprovals.stepOrder));
    });

    const requesterUsername = (req.session as any).user.username || "Someone";
    setImmediate(async () => {
      try {
        for (const approval of createdApprovals) {
          const reviewerUserId = approval.reviewerUserId;
          const shouldNotify = await storage.shouldSendNotification(reviewerUserId, "approval");
          if (shouldNotify) {
            await storage.createNotification({
              userId: reviewerUserId,
              title: "Sign-Off Review Requested",
              message: `${requesterUsername} has requested your review on report "${report.title}". You are reviewer #${approval.stepOrder}.`,
              type: "info",
              read: false,
              link: `/completion-reports/${id}`,
            });
          }
        }

        try {
          const { getEmailSettings } = await import("./email/email-service");
          const { sendEmail } = await import("./email/email-provider");
          const emailConfig = await getEmailSettings();
          if (emailConfig?.enabled) {
            for (const approval of createdApprovals) {
              const reviewerEmail = approval.reviewerEmail;
              if (reviewerEmail) {
                const html = buildReviewRequestEmail({
                  reportTitle: report.title,
                  requesterName: requesterUsername,
                  reviewerName: approval.reviewerUsername || "Reviewer",
                  stepOrder: approval.stepOrder,
                  totalReviewers: createdApprovals.length,
                  reportLink: `/completion-reports/${id}`,
                });
                sendEmail(
                  { host: emailConfig.smtpHost, port: emailConfig.smtpPort, email: emailConfig.senderEmail, password: emailConfig.senderPassword },
                  [reviewerEmail],
                  `[PerfHub] Sign-Off Review Requested — ${report.title}`,
                  html,
                ).catch(err => console.warn("[reports] Failed to send review request email:", err?.message));
              }
            }
          }
        } catch (err: any) {
          console.warn("[reports] Email notification skipped:", err?.message);
        }
      } catch (err: any) {
        console.error("[reports] Failed to create sign-off notifications:", err?.message);
      }
    });

    res.status(201).json(createdApprovals);
  }));

  app.post("/api/completion-reports/:id/approvals/:approvalId", requireNonViewer, validate({ params: z.object({ id: z.string().regex(/^\d+$/).transform(Number), approvalId: z.string().regex(/^\d+$/).transform(Number) }), body: z.object({ action: z.enum(["approved", "rejected", "changes_requested"], { message: "Action must be approved, rejected, or changes_requested" }), comment: z.string().optional().nullable() }) }), asyncHandler(async (req: Request, res: Response) => {
    const reportId = req.params.id as unknown as number;
    const approvalId = req.params.approvalId as unknown as number;

    const userId = (req.session as any).user.id;
    const userRole = (req.session as any).user.role;

    const [approval] = await db.select().from(reportApprovals)
      .where(and(eq(reportApprovals.id, approvalId), eq(reportApprovals.reportId, reportId)));

    if (!approval) return res.status(404).json({ message: "Approval step not found" });

    if (approval.reviewerUserId !== userId && userRole !== "admin" && userRole !== "lead") {
      return res.status(403).json({ message: "You are not assigned as a reviewer for this step" });
    }

    if (approval.status !== "pending") {
      return res.status(400).json({ message: `This step has already been ${approval.status}. Cannot act again.` });
    }

    const reportRows = await db.select().from(testCompletionReports).where(eq(testCompletionReports.id, reportId));
    if (reportRows.length > 0 && reportRows[0].reviewStatus !== "in_review") {
      return res.status(400).json({ message: "Review is not currently active for this report" });
    }

    const priorSteps = await db.select().from(reportApprovals)
      .where(and(eq(reportApprovals.reportId, reportId), sql`${reportApprovals.stepOrder} < ${approval.stepOrder}`));
    const hasPendingPrior = priorSteps.some(s => s.status === "pending");
    if (hasPendingPrior) {
      return res.status(400).json({ message: "Previous reviewers must act before you can review" });
    }

    const { action, comment } = req.body;

    const reviewStatus = await db.transaction(async (tx) => {
      await tx.update(reportApprovals)
        .set({
          status: action,
          comment: comment || null,
          actedAt: new Date().toISOString(),
        })
        .where(eq(reportApprovals.id, approvalId));

      const allApprovals = await tx.select().from(reportApprovals)
        .where(eq(reportApprovals.reportId, reportId));

      let status = "in_review";
      const hasRejected = allApprovals.some(a => a.id === approvalId ? action === "rejected" : a.status === "rejected");
      const hasChangesRequested = allApprovals.some(a => a.id === approvalId ? action === "changes_requested" : a.status === "changes_requested");
      const allApproved = allApprovals.every(a => a.id === approvalId ? action === "approved" : a.status === "approved");

      if (hasRejected) status = "rejected";
      else if (hasChangesRequested) status = "changes_requested";
      else if (allApproved) status = "approved";

      const updateData: any = { reviewStatus: status, updatedAt: new Date().toISOString() };
      if (allApproved) {
        updateData.finalApprovedAt = new Date().toISOString();
        updateData.status = "finalized";
      }

      await tx.update(testCompletionReports)
        .set(updateData)
        .where(eq(testCompletionReports.id, reportId));

      return status;
    });

    if (reviewStatus === "approved") {
      import("./webhook-dispatcher").then(({ dispatchWebhookEvent, WEBHOOK_EVENTS }) => {
        dispatchWebhookEvent(WEBHOOK_EVENTS.REPORT_APPROVED, {
          reportId,
          reviewStatus: "approved",
          approvedBy: userId,
        });
      }).catch((err) => console.warn("[reports] Failed to dispatch report approval webhook:", err?.message));
    }

    const reviewerUsername = (req.session as any).user.username || "A reviewer";
    setImmediate(async () => {
      try {
        const report = await reportStorage.getCompletionReport(reportId);
        if (report && report.createdBy && report.createdBy !== userId) {
          const actionLabel = action === "approved" ? "approved" : action === "rejected" ? "rejected" : "requested changes on";
          const shouldNotify = await storage.shouldSendNotification(report.createdBy, "approval");
          if (shouldNotify) {
            await storage.createNotification({
              userId: report.createdBy,
              title: `Report ${action === "approved" ? "Approved" : action === "rejected" ? "Rejected" : "Changes Requested"}`,
              message: `${reviewerUsername} has ${actionLabel} your report "${report.title}".${comment ? ` Comment: "${comment}"` : ""}`,
              type: action === "approved" ? "info" : action === "rejected" ? "warning" : "info",
              read: false,
              link: `/completion-reports/${reportId}`,
            });
          }
        }

        if (reviewStatus === "approved" && report) {
          const allApprovalRows = await db.select({ reviewerUserId: reportApprovals.reviewerUserId }).from(reportApprovals).where(eq(reportApprovals.reportId, reportId));
          for (const row of allApprovalRows) {
            if (row.reviewerUserId !== userId) {
              const shouldNotifyReviewer = await storage.shouldSendNotification(row.reviewerUserId, "approval");
              if (shouldNotifyReviewer) {
                await storage.createNotification({
                  userId: row.reviewerUserId,
                  title: "Report Fully Approved",
                  message: `Report "${report.title}" has been fully approved by all reviewers.`,
                  type: "info",
                  read: false,
                  link: `/completion-reports/${reportId}`,
                });
              }
            }
          }
        }
      } catch (err: any) {
        console.error("[reports] Failed to create approval action notification:", err?.message);
      }
    });

    res.json({ success: true, reviewStatus });
  }));

  app.delete("/api/completion-reports/:id/approvals", requireNonViewer, validate({ params: idParam }), asyncHandler(async (req: Request, res: Response) => {
    const reportId = req.params.id as unknown as number;

    const userId = (req.session as any).user.id;
    const userRole = (req.session as any).user.role;
    const report = await reportStorage.getCompletionReport(reportId);
    if (!report) return res.status(404).json({ message: "Report not found" });

    if (report.createdBy !== userId && userRole !== "admin" && userRole !== "lead") {
      return res.status(403).json({ message: "Only the report author, a lead, or admin can cancel the review" });
    }

    await db.transaction(async (tx) => {
      await tx.delete(reportApprovals).where(eq(reportApprovals.reportId, reportId));
      await tx.update(testCompletionReports)
        .set({
          reviewStatus: "draft",
          reviewRequestedAt: null,
          finalApprovedAt: null,
          updatedAt: new Date().toISOString(),
        })
        .where(eq(testCompletionReports.id, reportId));
    });

    res.json({ success: true });
  }));
}

async function buildReportSnapshot(executionIds: number[], compareExecutionIds: number[] | null) {
  const execRows = await db
    .select()
    .from(testExecutions)
    .where(inArray(testExecutions.id, executionIds));

  const scheduleIds = Array.from(new Set(execRows.map(e => e.scheduleId).filter(Boolean))) as number[];
  const scheduleRows = scheduleIds.length > 0
    ? await db.select().from(testSchedules).where(inArray(testSchedules.id, scheduleIds))
    : [];

  const scriptIds = Array.from(new Set(scheduleRows.map(s => s.scriptId).filter(Boolean))) as number[];
  const scriptRows = scriptIds.length > 0
    ? await db.select().from(scripts).where(inArray(scripts.id, scriptIds))
    : [];

  const scheduleMap = new Map(scheduleRows.map(s => [s.id, s]));
  const scriptMap = new Map(scriptRows.map(s => [s.id, s]));

  const sections = execRows.map(exec => {
    const schedule = exec.scheduleId ? scheduleMap.get(exec.scheduleId) : null;
    const script = schedule?.scriptId ? scriptMap.get(schedule.scriptId) : null;
    const config = schedule?.configuration as any;
    const result = exec.resultSummary as any;

    return {
      testType: config?.testTypeName || 'Load Test',
      executionId: exec.id,
      scheduleName: schedule?.name || 'Unknown',
      scriptName: script?.name || 'Unknown',
      environment: config?.environment || 'Unknown',
      vusers: config?.vusers || 0,
      duration: config?.duration || 0,
      startTime: exec.startTime || '',
      endTime: exec.endTime || '',
      status: exec.status,
      totalRequests: result?.totalRequests || 0,
      failedRequests: result?.failedRequests || 0,
      avgResponseTime: result?.avgResponseTime || 0,
      throughput: result?.throughput || 0,
      errorRate: result?.totalRequests > 0
        ? ((result?.failedRequests || 0) / result.totalRequests * 100)
        : 0,
      p50: result?.p50 || null,
      p90: result?.p90 || null,
      p95: result?.p95 || null,
      p99: result?.p99 || null,
      maxResponseTime: result?.maxResponseTime || null,
      minResponseTime: result?.minResponseTime || null,
      transactionDetails: result?.transactionDetails || [],
      slaViolations: exec.slaViolations || null,
      baselineDeviation: exec.baselineDeviation || null,
    };
  });

  const violations: any[] = [];
  sections.forEach(section => {
    if (section.slaViolations) {
      const sla = section.slaViolations as any;
      if (sla.avgResponseTime) {
        violations.push({ executionId: section.executionId, testType: section.testType, metric: 'Avg Response Time', threshold: sla.avgResponseTime.threshold, actual: sla.avgResponseTime.actual });
      }
      if (sla.throughput) {
        violations.push({ executionId: section.executionId, testType: section.testType, metric: 'Throughput', threshold: sla.throughput.threshold, actual: sla.throughput.actual });
      }
      if (sla.p90) {
        violations.push({ executionId: section.executionId, testType: section.testType, metric: 'P90', threshold: sla.p90.threshold, actual: sla.p90.actual });
      }
      if (sla.p95) {
        violations.push({ executionId: section.executionId, testType: section.testType, metric: 'P95', threshold: sla.p95.threshold, actual: sla.p95.actual });
      }
      if (sla.errorRate) {
        violations.push({ executionId: section.executionId, testType: section.testType, metric: 'Error Rate', threshold: sla.errorRate.threshold, actual: sla.errorRate.actual });
      }
      if (sla.perTransaction && Array.isArray(sla.perTransaction)) {
        sla.perTransaction.forEach((pt: any) => {
          violations.push({ executionId: section.executionId, testType: section.testType, metric: pt.metric, threshold: pt.threshold, actual: pt.actual, label: pt.label });
        });
      }
    }
  });

  const baselineSections = sections.filter(s => s.baselineDeviation);
  const regressionSections = baselineSections.filter(s => (s.baselineDeviation as any)?.overallRegression);

  const consolidatedBaseline = {
    totalWithBaseline: baselineSections.length,
    totalWithoutBaseline: sections.length - baselineSections.length,
    totalRegressions: regressionSections.length,
    regressions: regressionSections.map(s => ({
      executionId: s.executionId,
      testType: s.testType,
      severity: (s.baselineDeviation as any)?.regressionSeverity || 'unknown',
      global: (s.baselineDeviation as any)?.global || {},
    })),
    comparisons: baselineSections.map(s => {
      const dev = s.baselineDeviation as any;
      return {
        executionId: s.executionId,
        testType: s.testType,
        scheduleName: s.scheduleName,
        baselineExecutionId: dev?.baselineExecutionId,
        overallRegression: dev?.overallRegression || false,
        regressionSeverity: dev?.regressionSeverity || null,
        global: dev?.global || {},
        perTransaction: dev?.perTransaction || [],
      };
    }),
  };

  let compareSections: any[] | null = null;
  let runComparison: any | null = null;

  if (compareExecutionIds && compareExecutionIds.length > 0) {
    const compareExecRows = await db
      .select()
      .from(testExecutions)
      .where(inArray(testExecutions.id, compareExecutionIds));

    const compareScheduleIds = Array.from(new Set(compareExecRows.map(e => e.scheduleId).filter(Boolean))) as number[];
    const compareScheduleRows = compareScheduleIds.length > 0
      ? await db.select().from(testSchedules).where(inArray(testSchedules.id, compareScheduleIds))
      : [];
    const compareScriptIds = Array.from(new Set(compareScheduleRows.map(s => s.scriptId).filter(Boolean))) as number[];
    const compareScriptRows = compareScriptIds.length > 0
      ? await db.select().from(scripts).where(inArray(scripts.id, compareScriptIds))
      : [];

    const compareScheduleMap = new Map(compareScheduleRows.map(s => [s.id, s]));
    const compareScriptMap = new Map(compareScriptRows.map(s => [s.id, s]));

    compareSections = compareExecRows.map(exec => {
      const schedule = exec.scheduleId ? compareScheduleMap.get(exec.scheduleId) : null;
      const script = schedule?.scriptId ? compareScriptMap.get(schedule.scriptId) : null;
      const config = schedule?.configuration as any;
      const result = exec.resultSummary as any;
      return {
        testType: config?.testTypeName || 'Load Test',
        executionId: exec.id,
        executionIdStr: (exec as any).executionId || '',
        scheduleName: schedule?.name || 'Unknown',
        scriptName: script?.name || 'Unknown',
        environment: config?.environment || 'Unknown',
        startTime: exec.startTime || '',
        endTime: exec.endTime || '',
        status: exec.status,
        totalRequests: result?.totalRequests || 0,
        failedRequests: result?.failedRequests || 0,
        avgResponseTime: result?.avgResponseTime || 0,
        throughput: result?.throughput || 0,
        errorRate: result?.totalRequests > 0 ? ((result?.failedRequests || 0) / result.totalRequests * 100) : 0,
        p90: result?.p90 || null,
        p95: result?.p95 || null,
        transactionDetails: result?.transactionDetails || [],
      };
    });

    const pairComparisons: any[] = [];
    for (const current of sections) {
      const match = compareSections.find(c => c.scheduleName === current.scheduleName || c.scriptName === current.scriptName);
      if (match) {
        const calcChange = (curr: number, prev: number) => prev !== 0 ? ((curr - prev) / prev) * 100 : 0;
        pairComparisons.push({
          testType: current.testType,
          scheduleName: current.scheduleName,
          currentExecutionId: current.executionId,
          compareExecutionId: match.executionId,
          metrics: {
            avgResponseTime: { current: current.avgResponseTime, compare: match.avgResponseTime, changePercent: calcChange(current.avgResponseTime, match.avgResponseTime) },
            throughput: { current: current.throughput, compare: match.throughput, changePercent: calcChange(current.throughput, match.throughput) },
            errorRate: { current: current.errorRate, compare: match.errorRate, changePercent: match.errorRate !== 0 ? calcChange(current.errorRate, match.errorRate) : (current.errorRate > 0 ? 100 : 0) },
            totalRequests: { current: current.totalRequests, compare: match.totalRequests },
            ...(current.p90 && match.p90 ? { p90: { current: current.p90, compare: match.p90, changePercent: calcChange(current.p90, match.p90) } } : {}),
            ...(current.p95 && match.p95 ? { p95: { current: current.p95, compare: match.p95, changePercent: calcChange(current.p95, match.p95) } } : {}),
          },
          transactionComparison: current.transactionDetails
            ?.map((txn: any) => {
              const compareTxn = match.transactionDetails?.find((ct: any) => ct.label === txn.label);
              if (!compareTxn) return null;
              return {
                label: txn.label,
                avgCurrent: txn.avg || 0,
                avgCompare: compareTxn.avg || 0,
                avgChange: compareTxn.avg ? calcChange(txn.avg || 0, compareTxn.avg) : 0,
                p90Current: txn.p90 || 0,
                p90Compare: compareTxn.p90 || 0,
                p90Change: compareTxn.p90 ? calcChange(txn.p90 || 0, compareTxn.p90) : 0,
                tpsCurrent: txn.throughput || 0,
                tpsCompare: compareTxn.throughput || 0,
                tpsChange: compareTxn.throughput ? calcChange(txn.throughput || 0, compareTxn.throughput) : 0,
              };
            })
            .filter(Boolean) || [],
        });
      }
    }

    runComparison = {
      compareSections,
      pairComparisons,
      unmatchedCurrent: sections.filter(s => !compareSections!.find(c => c.scheduleName === s.scheduleName || c.scriptName === s.scriptName)).map(s => s.executionId),
      unmatchedCompare: compareSections.filter(c => !sections.find(s => s.scheduleName === c.scheduleName || s.scriptName === c.scriptName)).map(c => c.executionId),
    };
  }

  return {
    generatedAt: new Date().toISOString(),
    sections,
    consolidatedSla: {
      totalRules: violations.length + sections.filter(s => !s.slaViolations).length,
      passed: sections.filter(s => !s.slaViolations || Object.keys(s.slaViolations).length === 0).length,
      failed: sections.filter(s => s.slaViolations && Object.keys(s.slaViolations).length > 0).length,
      violations,
    },
    consolidatedBaseline,
    runComparison,
  };
}
