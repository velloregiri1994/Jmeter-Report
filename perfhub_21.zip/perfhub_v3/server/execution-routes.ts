import express, { type Express } from "express";
import path from "path";
import fs from "fs";
import { spawn } from "child_process";
import multer from "multer";
import { storage } from "./storage";
import { db } from "./db";
import { comments as commentsTable } from "@shared/schema";
import { eq } from "drizzle-orm";
import { api } from "@shared/routes";
import { requireAuth, requireEngineerOrAdmin, requireNonViewer, sanitizeResponse, generateExecutionId } from "./route-middleware";
import { cacheService, CACHE_KEYS, CACHE_TTL } from "./cache";
import { generateHtmlReport } from "./report-generator";
import { getLiveSnapshot } from "./live-metrics";
import { broadcastExecutionUpdate } from "./websocket";
import { queueJMeterRun, generateRunId, cancelRun, cancelCurrentRun } from "./jmeter-worker";
import { validate, z, idParam } from "./validation";
import { runAnomalyDetection } from "./anomaly-detector";
import { logAudit } from "./audit-logger";
import { asyncHandler } from "./error-handler";
import { analyzeWorkloadAchievement, type WorkloadTargets, type ActualMetrics } from "./workload-achievement";

export function registerExecutionRoutes(app: Express): void {

  app.get(api.executions.list.path, requireAuth, validate({ query: z.object({ status: z.string().optional(), limit: z.coerce.number().int().min(1).max(100).optional(), offset: z.coerce.number().int().min(0).optional(), page: z.coerce.number().int().min(1).optional() }).passthrough() }), asyncHandler(async (req, res) => {
    const status = req.query.status as string | undefined;
    const limit = req.query.limit ? Math.min(Number(req.query.limit), 100) : 50;
    const offset = req.query.offset ? Number(req.query.offset) : 0;
    const page = req.query.page ? Number(req.query.page) : undefined;
    
    const actualOffset = page ? (page - 1) * limit : offset;
    
    const [executions, totalCount] = await Promise.all([
      storage.getExecutions(limit, status, actualOffset),
      storage.getExecutionCount(status)
    ]);
    
    res.json(sanitizeResponse({
      data: executions,
      pagination: {
        total: totalCount,
        limit,
        offset: actualOffset,
        page: page || Math.floor(actualOffset / limit) + 1,
        totalPages: Math.ceil(totalCount / limit),
        hasMore: actualOffset + executions.length < totalCount
      }
    }));
  }));

  app.get(api.executions.get.path, requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    
    const execution = await storage.getExecution(id);
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    
    res.json(sanitizeResponse(execution));
  }));


  app.get("/api/executions/:id/live-metrics", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const { snapshot, warning } = getLiveSnapshot(id);
    if (snapshot) return res.json({ active: true, snapshot, warning });
    const { getRemoteStreamSnapshot } = await import("./live-metrics/remote-stream");
    const remoteSnapshot = getRemoteStreamSnapshot(id);
    if (remoteSnapshot) return res.json({ active: true, snapshot: remoteSnapshot, warning: null, remote: true });
    return res.json({ active: false, snapshot: null, warning: null });
  }));

  app.get("/api/executions/:id/filtered-metrics", requireAuth, validate({ params: idParam, query: z.object({ start: z.coerce.number().optional(), end: z.coerce.number().optional() }).passthrough() }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;

    const execution = await storage.getExecution(id);
    if (!execution) return res.status(404).json({ message: "Execution not found" });

    const startMs = req.query.start ? Number(req.query.start) : undefined;
    const endMs = req.query.end ? Number(req.query.end) : undefined;

    try {
      const { queryFilteredMetrics } = await import("./bucket-persistence");
      const filtered = await queryFilteredMetrics(id, startMs, endMs);
      if (filtered) return res.json(filtered);
    } catch (dbErr) {
      console.warn(`[filtered-metrics] DB query failed for execution ${id}, falling back to file:`, (dbErr as Error).message);
    }

    if (!execution.artifactsPath) return res.status(404).json({ message: "No bucket data available for this execution" });

    const { loadBuckets, mergeBucketsForRange } = await import("./bucket-merger");
    const bucketsFile = await loadBuckets(execution.artifactsPath);
    if (!bucketsFile) return res.status(404).json({ message: "No bucket data available for this execution" });

    const fileFallback = mergeBucketsForRange(bucketsFile, startMs, endMs);
    res.json(fileFallback);
  }));


  app.get("/api/executions/:id/sla-rules", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const rules = await storage.getExecutionSlaRules(id);
    res.json(rules);
  }));

  app.post("/api/executions/:id/sla-rules", requireEngineerOrAdmin, validate({
    params: idParam,
    body: z.object({
      transactionLabel: z.string().nullable().optional(),
      metric: z.enum(['avg', 'p90', 'p95', 'p99', 'max', 'errorRate', 'throughput']),
      comparator: z.enum(['lt', 'gt', 'lte', 'gte']),
      threshold: z.number().int().min(0),
    })
  }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    const execution = await storage.getExecution(executionId);
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    const userId = (req.session as any)?.user?.id;
    const rule = await storage.createExecutionSlaRule({
      executionId,
      transactionLabel: req.body.transactionLabel || null,
      metric: req.body.metric,
      comparator: req.body.comparator,
      threshold: req.body.threshold,
      isEnabled: true,
      createdBy: userId,
    });
    logAudit(req, "sla_create", "sla_rule", undefined, { executionId });
    res.status(201).json(rule);
  }));

  app.post("/api/executions/:id/sla-rules/bulk", requireEngineerOrAdmin, validate({
    params: idParam,
    body: z.object({
      rules: z.array(z.object({
        transactionLabel: z.string().nullable().optional(),
        metric: z.enum(['avg', 'p90', 'p95', 'p99', 'max', 'errorRate', 'throughput']),
        comparator: z.enum(['lt', 'gt', 'lte', 'gte']),
        threshold: z.number().int().min(0),
      })).min(1).max(50)
    })
  }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    const execution = await storage.getExecution(executionId);
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    const userId = (req.session as any)?.user?.id;
    const created = [];
    for (const r of req.body.rules) {
      const rule = await storage.createExecutionSlaRule({
        executionId,
        transactionLabel: r.transactionLabel || null,
        metric: r.metric,
        comparator: r.comparator,
        threshold: r.threshold,
        isEnabled: true,
        createdBy: userId,
      });
      created.push(rule);
    }
    res.status(201).json(created);
  }));

  app.delete("/api/execution-sla-rules/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteExecutionSlaRule(id);
    res.json({ message: "Rule deleted" });
  }));

  app.patch("/api/execution-sla-rules/:id/toggle", requireEngineerOrAdmin, validate({
    params: idParam,
    body: z.object({ isEnabled: z.boolean() })
  }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const updated = await storage.updateExecutionSlaRule(id, { isEnabled: req.body.isEnabled });
    if (!updated) return res.status(404).json({ message: "Rule not found" });
    res.json(updated);
  }));

  app.get("/api/executions/:id/auto-abort-rules", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const rules = await storage.getExecutionAutoAbortRules(id);
    res.json(rules);
  }));

  app.post("/api/executions/:id/auto-abort-rules", requireEngineerOrAdmin, validate({
    params: idParam,
    body: z.object({
      metric: z.enum(['errorRate', 'avgResponseTime', 'p90', 'p95', 'p99', 'maxResponseTime', 'throughput']),
      comparator: z.enum(['lt', 'gt', 'lte', 'gte']),
      threshold: z.number().min(0),
      sustainedSeconds: z.number().int().min(1).default(30),
    })
  }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    const execution = await storage.getExecution(executionId);
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    const userId = (req.session as any)?.user?.id;
    const rule = await storage.createExecutionAutoAbortRule({
      executionId,
      metric: req.body.metric,
      comparator: req.body.comparator,
      threshold: req.body.threshold,
      sustainedSeconds: req.body.sustainedSeconds,
      isEnabled: true,
      createdBy: userId,
    });
    logAudit(req, "auto_abort_rule_create" as any, "auto_abort_rule" as any, undefined, { executionId });
    res.status(201).json(rule);
  }));

  app.delete("/api/execution-auto-abort-rules/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    await storage.deleteExecutionAutoAbortRule(id);
    res.json({ message: "Rule deleted" });
  }));

  app.patch("/api/execution-auto-abort-rules/:id/toggle", requireEngineerOrAdmin, validate({
    params: idParam,
    body: z.object({ isEnabled: z.boolean() })
  }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const updated = await storage.updateExecutionAutoAbortRule(id, { isEnabled: req.body.isEnabled });
    if (!updated) return res.status(404).json({ message: "Rule not found" });
    res.json(updated);
  }));

  // Execution Workload Targets
  app.get("/api/executions/:id/workload-targets", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    const execution = await storage.getExecution(executionId);
    if (!execution) return res.status(404).json({ message: "Execution not found" });

    const execTargets = await storage.getExecutionWorkloadTargets(executionId);
    if (execTargets) {
      return res.json({ source: "execution", targets: execTargets });
    }

    if (execution.scriptId) {
      const script = await storage.getScript(execution.scriptId);
      if (script?.workloadTargets) {
        return res.json({ source: "script", targets: script.workloadTargets, scriptName: script.name, scriptId: script.id });
      }
    }

    res.json({ source: null, targets: null });
  }));

  app.post("/api/executions/:id/workload-targets", requireEngineerOrAdmin, validate({
    params: idParam,
    body: z.object({
      threads: z.number().int().min(1).optional(),
      tph: z.number().min(1).optional(),
      tps: z.number().min(0).optional(),
      pacing: z.number().min(0).optional(),
      testType: z.string().optional(),
      transactionsPerIteration: z.number().int().min(1).optional(),
      e2eResponseTime: z.number().min(0).optional(),
      thinkTime: z.number().min(0).optional(),
      perTransaction: z.array(z.object({
        name: z.string(),
        weight: z.number(),
        tph: z.number(),
        tps: z.number(),
      })).optional(),
    }).refine(data => data.threads || data.tph, { message: "At least threads or TPH must be provided" })
  }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    const execution = await storage.getExecution(executionId);
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    const userId = (req.session as any)?.user?.id;
    const target = await storage.setExecutionWorkloadTargets({
      executionId,
      threads: req.body.threads ?? null,
      tph: req.body.tph ?? null,
      tps: req.body.tps ?? null,
      pacing: req.body.pacing ?? null,
      testType: req.body.testType ?? null,
      transactionsPerIteration: req.body.transactionsPerIteration ?? null,
      e2eResponseTime: req.body.e2eResponseTime ?? null,
      thinkTime: req.body.thinkTime ?? null,
      perTransaction: req.body.perTransaction ?? null,
      createdBy: userId,
    });
    res.status(201).json(target);
  }));

  app.delete("/api/executions/:id/workload-targets", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    await storage.deleteExecutionWorkloadTargets(executionId);
    res.json({ message: "Workload targets removed" });
  }));

  app.get("/api/executions/:id/workload-achievement", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    const execution = await storage.getExecution(executionId);
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    if (execution.status !== "completed" && execution.status !== "failed" && execution.status !== "aborted") {
      return res.status(400).json({ message: "Achievement analysis is only available for completed executions" });
    }

    let targets: WorkloadTargets | null = null;
    let source: "execution" | "script" = "execution";

    const execTargets = await storage.getExecutionWorkloadTargets(executionId);
    if (execTargets) {
      targets = execTargets;
      source = "execution";
    } else if (execution.scriptId) {
      const script = await storage.getScript(execution.scriptId);
      if (script?.workloadTargets) {
        targets = script.workloadTargets as WorkloadTargets;
        source = "script";
      }
    }

    if (!targets) {
      return res.json({ available: false });
    }

    const summary = execution.resultSummary as any;
    if (!summary) {
      return res.json({ available: false });
    }

    const liveMetrics = execution.liveMetrics as any;
    const maxActiveThreads = liveMetrics?.activeThreads
      ? Math.max(...(liveMetrics.activeThreads as number[]).filter((v: number) => v > 0))
      : 0;

    const startTime = execution.startTime ? new Date(execution.startTime).getTime() : 0;
    const endTime = execution.endTime ? new Date(execution.endTime).getTime() : 0;
    const durationSeconds = startTime && endTime ? (endTime - startTime) / 1000 : 0;

    const errorRate = typeof summary.errorRate === "number"
      ? (summary.errorRate <= 1 ? summary.errorRate * 100 : summary.errorRate)
      : (summary.totalRequests > 0 ? (summary.failedRequests / summary.totalRequests) * 100 : 0);

    const actual: ActualMetrics = {
      totalRequests: summary.totalRequests || 0,
      failedRequests: summary.failedRequests || 0,
      avgResponseTime: summary.avgResponseTime || 0,
      throughput: summary.throughput || 0,
      errorRate,
      p90: summary.p90,
      p95: summary.p95,
      durationSeconds,
      maxActiveThreads,
      transactionDetails: summary.transactionDetails,
    };

    const result = analyzeWorkloadAchievement(targets, actual);
    res.json({ available: true, source, result });
  }));

  app.patch("/api/executions/:id/labels", requireEngineerOrAdmin, validate({ params: idParam, body: z.object({ labels: z.array(z.string().max(50)).max(20) }) }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const { labels } = req.body;
    const updated = await storage.updateExecution(id, { executionLabels: labels } as any);
    logAudit(req, "execution_update" as any, "execution", id, { labels: req.body.labels });
    res.json(updated);
  }));

  app.get("/api/executions/:id/system-metrics", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;

    const execution = await storage.getExecution(id);
    if (!execution) return res.status(404).json({ message: "Execution not found" });

    if (execution.artifactsPath) {
      const { readSystemMetricsTimeseries, readSystemMetricsSummary } = await import("./system-metrics-collector");
      const timeseries = readSystemMetricsTimeseries(execution.artifactsPath);
      const summary = readSystemMetricsSummary(execution.artifactsPath);
      return res.json({ timeseries, summary, machineMetrics: null });
    }

    const isRemote = !execution.scheduleId;
    if (isRemote) {
      const { getRemoteMachineMetrics } = await import("./live-metrics/remote-stream");
      const liveNodeMetrics = getRemoteMachineMetrics(id);
      if (liveNodeMetrics) {
        return res.json({ timeseries: [], summary: null, machineMetrics: liveNodeMetrics });
      }

      const resultSummary = execution.resultSummary as any;
      if (resultSummary?.machineMetrics) {
        return res.json({ timeseries: [], summary: null, machineMetrics: resultSummary.machineMetrics });
      }
    }

    return res.json({ timeseries: [], summary: null, machineMetrics: null });
  }));

  app.get("/api/executions/:id/checkpoint", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    
    const checkpoint = await storage.getCheckpoint(id);
    if (!checkpoint) return res.status(404).json({ message: "No checkpoint found" });
    
    res.json(checkpoint);
  }));

  app.post("/api/executions/:id/abort", requireEngineerOrAdmin, validate({ params: idParam, body: z.object({ reason: z.string().max(500).optional() }).optional() }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    const execution = await storage.getExecution(executionId);
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    if (execution.status !== "running") {
      return res.status(400).json({ message: `Cannot abort execution in '${execution.status}' state` });
    }
    const reason = req.body?.reason || "Manual abort requested by user";
    const { triggerAbort, isAborted } = await import("./live-metrics/remote-stream");
    if (isAborted(executionId)) {
      return res.status(409).json({ message: "Execution is already being aborted" });
    }
    triggerAbort(executionId, reason);
    try {
      await cancelRun(executionId);
    } catch {}
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    logAudit(req, "execution_abort" as any, "execution", executionId, { reason });
    res.json({ message: "Abort triggered", executionId, reason });
  }));

  app.post("/api/executions/:id/cancel", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    const execution = await storage.cancelExecution(executionId);
    if (!execution) return res.status(404).json({ message: "Execution not found or not running" });
    await cancelRun(executionId);
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    logAudit(req, "execution_cancel", "execution", executionId);
    const updated = await storage.getExecution(executionId);
    res.json(updated || execution);
  }));

  app.delete("/api/executions/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    const execution = await storage.getExecution(executionId);
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    if (execution.status === 'running' || execution.status === 'queued') {
      return res.status(400).json({ message: "Cannot delete a running or queued execution. Cancel it first." });
    }
    await storage.deleteExecution(executionId);
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    logAudit(req, "execution_delete", "execution", executionId);
    res.json({ message: "Execution deleted" });
  }));

  app.post("/api/executions/:id/rerun", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;

    const execution = await storage.getExecution(executionId);
    if (!execution) return res.status(404).json({ message: "Execution not found" });

    if (!execution.scheduleId) return res.status(400).json({ message: "No schedule linked to this execution" });

    const schedule = await storage.getSchedule(execution.scheduleId);
    if (!schedule) return res.status(404).json({ message: "Original schedule not found" });

    if (!schedule.script?.filePath) {
      return res.status(400).json({ message: "Script file not found. Cannot re-run." });
    }

    const userId = (req.session as any)?.user?.id || 1;

    const newSchedule = await storage.createSchedule({
      name: `Re-run: ${schedule.name}`,
      scriptId: schedule.scriptId,
      scheduledTime: new Date().toISOString(),
      status: "queued",
      recurrence: "none",
      configuration: schedule.configuration,
      createdBy: userId,
    });

    const newExecutionId = generateExecutionId();
    const newExecution = await storage.createExecution({
      executionId: newExecutionId,
      scheduleId: newSchedule.id,
      status: "queued",
      startTime: null,
      endTime: null,
      resultSummary: null,
      artifactsPath: null,
      reportHtmlPath: null,
      reportComments: null,
      liveMetrics: null,
    } as any);

    queueJMeterRun(newExecution.id, {
      executionId: newExecutionId,
      jmxPath: schedule.script.filePath,
      dependencyFiles: (schedule.script as any).dependencyFiles || [],
      jarFiles: (schedule.script as any).jarFiles || [],
      vusers: schedule.configuration?.vusers,
      rampUp: schedule.configuration?.rampUp,
      duration: schedule.configuration?.duration,
    });

    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);

    logAudit(req, "execution_rerun", "execution", executionId);
    res.status(201).json({ execution: newExecution, schedule: newSchedule });
  }));

  app.use("/reports", express.static(path.join(process.cwd(), "attached_assets", "reports")));

  app.post("/api/executions/:id/generate-report", requireNonViewer, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const execution = await storage.getExecution(req.params.id as unknown as number);
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    
    const reportName = `report_${execution.id}.html`;
    const reportDir = path.join(process.cwd(), "attached_assets", "reports");
    const reportPath = path.join(reportDir, reportName);
    const publicReportPath = `/reports/${reportName}`;
    
    fs.mkdirSync(reportDir, { recursive: true });

    const html = generateHtmlReport(execution as any);
    fs.writeFileSync(reportPath, html);
    
    await storage.updateExecution(execution.id, { reportHtmlPath: publicReportPath });
    res.json({ url: publicReportPath });
  }));

  app.post("/api/executions/:id/regenerate-report", requireNonViewer, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const execution = await storage.getExecution(req.params.id as unknown as number);
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    
    const reportName = `report_${execution.id}.html`;
    const reportDir = path.join(process.cwd(), "attached_assets", "reports");
    const reportPath = path.join(reportDir, reportName);
    const publicReportPath = `/reports/${reportName}`;
    
    const html = generateHtmlReport(execution as any);
    fs.writeFileSync(reportPath, html);
    await storage.updateExecution(execution.id, { reportHtmlPath: publicReportPath });
    res.json({ url: publicReportPath });
  }));


  app.post("/api/executions/:id/report-comments", requireNonViewer, validate({ params: idParam, body: z.object({ comments: z.string().optional().nullable() }) }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const { comments: reportComments } = req.body;
    
    const execution = await storage.updateExecution(id, { reportComments });
    if (!execution) return res.status(404).json({ message: "Execution not found" });
    res.json(execution);
  }));

  app.get("/api/executions/:id/comments", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    
    const commentsList = await storage.getCommentsByExecutionId(id);
    res.json(commentsList);
  }));

  app.post("/api/executions/:id/comments", requireAuth, validate({ params: idParam, body: z.object({ content: z.string().min(1, "Content is required"), type: z.string().optional() }) }), asyncHandler(async (req, res) => {
    const executionId = req.params.id as unknown as number;
    
    const { content, type } = req.body;
    
    const userId = (req.session as any)?.user?.id;
    if (!userId) {
      return res.status(401).json({ message: "User not authenticated" });
    }
    const comment = await storage.createComment({
      executionId,
      userId,
      content,
      type: type || "comment",
    });
    res.status(201).json(comment);
  }));

  app.delete("/api/comments/:id", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const sessionUser = (req.session as any).user;

    const allComments = await db.select().from(commentsTable).where(eq(commentsTable.id, id));
    const comment = allComments[0];
    if (!comment) return res.status(404).json({ message: "Comment not found" });

    if (comment.userId !== sessionUser.id && sessionUser.role !== "admin") {
      return res.status(403).json({ message: "You can only delete your own comments" });
    }

    await storage.deleteComment(id);
    res.json({ message: "Comment deleted" });
  }));

  app.get("/api/executions/compare", requireAuth, validate({ query: z.object({ left: z.coerce.number({ required_error: "left execution ID is required" }), right: z.coerce.number({ required_error: "right execution ID is required" }) }).passthrough() }), asyncHandler(async (req, res) => {
    const leftId = req.query.left as unknown as number;
    const rightId = req.query.right as unknown as number;

    const [leftExec, rightExec] = await Promise.all([
      storage.getExecution(leftId),
      storage.getExecution(rightId),
    ]);

    if (!leftExec || !rightExec) {
      return res.status(404).json({ message: "One or both executions not found" });
    }

    const leftSummary: any = leftExec.resultSummary || {};
    const rightSummary: any = rightExec.resultSummary || {};

    const computeChange = (left: number | undefined, right: number | undefined) => {
      if (left === undefined || right === undefined || left === 0) return null;
      return ((right - left) / left) * 100;
    };

    const comparison = {
      left: {
        id: leftExec.id,
        executionId: leftExec.executionId,
        startTime: leftExec.startTime,
        status: leftExec.status,
        summary: leftSummary,
      },
      right: {
        id: rightExec.id,
        executionId: rightExec.executionId,
        startTime: rightExec.startTime,
        status: rightExec.status,
        summary: rightSummary,
      },
      diff: {
        avgResponseTime: computeChange(leftSummary.avgResponseTime, rightSummary.avgResponseTime),
        throughput: computeChange(leftSummary.throughput, rightSummary.throughput),
        failedRequests: computeChange(leftSummary.failedRequests, rightSummary.failedRequests),
        totalRequests: computeChange(leftSummary.totalRequests, rightSummary.totalRequests),
      },
      transactionComparison: [] as any[],
    };

    const leftTx: any[] = leftSummary.transactionDetails || [];
    const rightTx: any[] = rightSummary.transactionDetails || [];
    const leftTxMap = new Map(leftTx.map((t: any) => [t.label, t]));
    const rightTxMap = new Map(rightTx.map((t: any) => [t.label, t]));
    const allLabels = Array.from(new Set([...Array.from(leftTxMap.keys()), ...Array.from(rightTxMap.keys())]));

    for (const label of allLabels) {
      const l: any = leftTxMap.get(label);
      const r: any = rightTxMap.get(label);
      comparison.transactionComparison.push({
        label,
        left: l || null,
        right: r || null,
        diff: l && r ? {
          avgChange: computeChange(l.avg, r.avg),
          p90Change: computeChange(l.p90, r.p90),
          p95Change: computeChange(l.p95, r.p95),
          throughputChange: computeChange(l.throughput, r.throughput),
          errorRateChange: computeChange(l.errorRate, r.errorRate),
        } : null,
      });
    }

    res.json(comparison);
  }));


  app.get('/api/public/stats', asyncHandler(async (_req, res) => {
    try {
      const cached = await cacheService.get<any>('public_stats');
      if (cached) return res.json(cached);
      const stats = await storage.getDashboardStats();
      const publicStats = {
        totalScripts: stats.totalScripts || 0,
        totalExecutions: stats.totalExecutions || 0,
        passRate: Math.round(stats.passRate || 0),
      };
      await cacheService.set('public_stats', publicStats, 60);
      res.json(publicStats);
    } catch {
      res.json({ totalScripts: 0, totalExecutions: 0, passRate: 0 });
    }
  }));

  app.get(api.dashboard.stats.path, requireAuth, asyncHandler(async (req, res) => {
    const cached = await cacheService.get<any>(CACHE_KEYS.DASHBOARD_STATS);
    if (cached) {
      return res.json(sanitizeResponse(cached));
    }
    const stats = await storage.getDashboardStats();
    await cacheService.set(CACHE_KEYS.DASHBOARD_STATS, stats, CACHE_TTL.DASHBOARD_STATS);
    res.json(sanitizeResponse(stats));
  }));

  app.get("/api/executions/:id/anomaly-detection", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const execution = await storage.getExecution(id);
    if (!execution) return res.status(404).json({ message: "Execution not found" });

    const resultSummary = execution.resultSummary as any;
    if (!resultSummary || !resultSummary.totalRequests) {
      return res.status(400).json({ message: "No metrics available for anomaly detection" });
    }

    const normalizeErrorRate = (er: any, errCount?: number, failedReqs?: number, total?: number): number => {
      const errors = (typeof errCount === 'number' && errCount > 0) ? errCount
        : (typeof failedReqs === 'number' && failedReqs > 0) ? failedReqs
        : 0;
      if (typeof total === 'number' && total > 0 && errors > 0) {
        return errors / total;
      }
      if (typeof er !== 'number') return 0;
      return er > 1 ? er / 100 : er;
    };

    const errorCount = resultSummary.errorCount || resultSummary.failedRequests || 0;
    const currentMetrics = {
      totalRequests: resultSummary.totalRequests || 0,
      errorCount,
      errorRate: normalizeErrorRate(resultSummary.errorRate, resultSummary.errorCount, resultSummary.failedRequests, resultSummary.totalRequests),
      avgResponseTime: resultSummary.avgResponseTime || 0,
      minResponseTime: resultSummary.minResponseTime || 0,
      maxResponseTime: resultSummary.maxResponseTime || 0,
      throughput: resultSummary.throughput || 0,
      p50: resultSummary.p50 || 0,
      p90: resultSummary.p90 || 0,
      p95: resultSummary.p95 || 0,
      p99: resultSummary.p99 || 0,
      durationSeconds: resultSummary.durationSeconds || 0,
    };

    const timeseries = resultSummary.timeseries || [];
    const transactionDetails = resultSummary.transactionDetails || [];

    let baselineMetrics = null;
    let baselineExecutionId: number | undefined;

    if (execution.scriptId) {
      const baselineData = await storage.getBaselineWithExecution(execution.scriptId);
      if (baselineData && baselineData.execution.id !== id && baselineData.execution.status === "completed") {
        const bResult = baselineData.execution.resultSummary as any;
        if (bResult && bResult.totalRequests > 0) {
          baselineExecutionId = baselineData.execution.id;
          let stdResponseTime: number | undefined;
          let stdP95: number | undefined;
          let stdP99: number | undefined;
          let stdThroughput: number | undefined;
          let stdErrorRate: number | undefined;

          const bTimeseries = bResult.timeseries;
          if (Array.isArray(bTimeseries) && bTimeseries.length >= 3) {
            const rtValues = bTimeseries.map((p: any) => p.avgRT ?? p.avg_ms ?? p.avg ?? 0).filter((v: number) => v > 0);
            const p95Values = bTimeseries.map((p: any) => p.p95 ?? p.p95_ms ?? 0).filter((v: number) => v > 0);
            const p99Values = bTimeseries.map((p: any) => p.p99 ?? p.p99_ms ?? 0).filter((v: number) => v > 0);
            const tpValues = bTimeseries.map((p: any) => p.throughput ?? p.rps ?? 0).filter((v: number) => v > 0);
            const erValues = bTimeseries
              .map((p: any) => p.errorRate ?? p.error_rate ?? null)
              .filter((v: number | null): v is number => v !== null);

            const computeStd = (vals: number[]) => {
              if (vals.length < 3) return undefined;
              const mean = vals.reduce((s, v) => s + v, 0) / vals.length;
              return Math.sqrt(vals.reduce((s, v) => s + (v - mean) ** 2, 0) / (vals.length - 1));
            };

            stdResponseTime = computeStd(rtValues);
            stdP95 = computeStd(p95Values);
            stdP99 = computeStd(p99Values);
            stdThroughput = computeStd(tpValues);
            if (erValues.length >= 3) {
              const maxEr = Math.max(...erValues);
              const erDecimal = maxEr > 1
                ? erValues.map(v => v / 100)
                : erValues;
              stdErrorRate = computeStd(erDecimal);
            }
          }

          baselineMetrics = {
            avgResponseTime: bResult.avgResponseTime || 0,
            p50: bResult.p50 || 0,
            p90: bResult.p90 || 0,
            p95: bResult.p95 || 0,
            p99: bResult.p99 || 0,
            errorRate: normalizeErrorRate(bResult.errorRate, bResult.errorCount, bResult.failedRequests, bResult.totalRequests),
            throughput: bResult.throughput || 0,
            totalRequests: bResult.totalRequests || 0,
            transactionDetails: bResult.transactionDetails || [],
            stdResponseTime,
            stdP95,
            stdP99,
            stdThroughput,
            stdErrorRate,
          };
        }
      }
    }

    const result = runAnomalyDetection(
      currentMetrics,
      timeseries,
      transactionDetails,
      baselineMetrics,
      baselineExecutionId
    );

    res.json(sanitizeResponse(result));
  }));

  const RESULTS_BASE_DIR = path.join(process.cwd(), "results");
  const REQUIRED_JTL_HEADERS = ["timestamp", "elapsed", "label", "success"];

  const csvUpload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 500 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      if (ext === ".csv" || ext === ".jtl") {
        cb(null, true);
      } else {
        cb(new Error("Invalid file type. Only .csv and .jtl files are accepted."));
      }
    },
  });

  function parseJtlFile(jtlPath: string, runDir: string): Promise<any> {
    const metricsPath = path.join(runDir, "metrics.json");
    const parserScript = path.join(process.cwd(), "scripts", "jtl_parser_full.py");

    if (!fs.existsSync(parserScript)) {
      throw new Error("Parser script not found");
    }

    return new Promise((resolve, reject) => {
      const pythonCmd = process.env.PYTHON_CMD || "python3";
      const proc = spawn(pythonCmd, [parserScript, jtlPath, "--out", metricsPath], {
        cwd: process.cwd(),
      });

      let stderr = "";
      const MAX_STDERR = 50 * 1024;
      proc.stderr?.on("data", (data: Buffer) => {
        if (stderr.length < MAX_STDERR) {
          stderr += data.toString();
          if (stderr.length > MAX_STDERR) stderr = stderr.slice(-MAX_STDERR);
        }
      });
      proc.stdout?.on("data", () => {});

      proc.on("close", async (code: number | null) => {
        if (code !== 0) {
          reject(new Error(`JTL parser failed with code ${code}: ${stderr}`));
          return;
        }
        try {
          const MAX_METRICS_SIZE = 500 * 1024 * 1024;
          const stat = await fs.promises.stat(metricsPath);
          if (stat.size > MAX_METRICS_SIZE) {
            reject(new Error(`metrics.json too large (${Math.round(stat.size / 1024 / 1024)}MB > ${MAX_METRICS_SIZE / 1024 / 1024}MB limit)`));
            return;
          }
          const metricsJson = await fs.promises.readFile(metricsPath, "utf-8");
          resolve(JSON.parse(metricsJson));
        } catch (e) {
          reject(new Error(`Failed to read parsed metrics: ${e}`));
        }
      });

      proc.on("error", (err: Error) => {
        reject(new Error(`Failed to spawn parser: ${err.message}`));
      });
    });
  }

  function validateJtlHeaders(csvContent: string): { valid: boolean; error?: string } {
    const firstNewline = csvContent.indexOf("\n");
    if (firstNewline === -1) return { valid: false, error: "File appears to be empty or has no header row" };

    const headerLine = csvContent.substring(0, firstNewline).trim();
    const headers = headerLine.toLowerCase().split(",").map(h => h.trim());

    const missing = REQUIRED_JTL_HEADERS.filter(h => !headers.includes(h.toLowerCase()));
    if (missing.length > 0) {
      return { valid: false, error: `Missing required JMeter CSV columns: ${missing.join(", ")}. Found: ${headers.join(", ")}` };
    }
    return { valid: true };
  }

  app.post("/api/results/import", requireEngineerOrAdmin, csvUpload.single("file"), asyncHandler(async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const csvContent = req.file.buffer.toString("utf-8");

    const validation = validateJtlHeaders(csvContent);
    if (!validation.valid) {
      return res.status(400).json({ message: validation.error });
    }

    const testName = (req.body.testName as string) || req.file.originalname.replace(/\.(csv|jtl)$/i, "");
    const environment = (req.body.environment as string) || null;
    const rawScriptId = req.body.scriptId ? Number(req.body.scriptId) : null;
    const scriptId = rawScriptId && !isNaN(rawScriptId) ? rawScriptId : null;

    if (scriptId) {
      const script = await storage.getScript(scriptId);
      if (!script) {
        return res.status(400).json({ message: "Script not found" });
      }
    }

    const runId = generateRunId();
    const executionId = generateExecutionId();
    const runDir = path.join(RESULTS_BASE_DIR, runId);
    fs.mkdirSync(runDir, { recursive: true });

    const csvPath = path.join(runDir, "results.csv");
    fs.writeFileSync(csvPath, csvContent);

    const sessionUser = (req.session as any).user;
    const startTime = new Date().toISOString();

    const execution = await storage.createExecution({
      executionId,
      testName: `[Imported] ${testName}`,
      status: "parsing",
      startTime,
      environment,
      scriptId,
      artifactsPath: runDir,
    } as any);

    broadcastExecutionUpdate(execution.id, "parsing");

    try {
      const metrics = await parseJtlFile(csvPath, runDir);

      const resultSummary: any = {
        totalRequests: metrics.global?.total_requests || 0,
        successfulRequests: metrics.global?.successes || 0,
        failedRequests: metrics.global?.errors || 0,
        avgResponseTime: metrics.global?.avg_ms || 0,
        minResponseTime: metrics.global?.min_ms || 0,
        maxResponseTime: metrics.global?.max_ms || 0,
        throughput: metrics.global?.throughput_rps || 0,
        peakRps: metrics.peak_rps || 0,
        p50: metrics.global?.p50_ms || 0,
        p90: metrics.global?.p90_ms || 0,
        p95: metrics.global?.p95_ms || 0,
        p99: metrics.global?.p99_ms || 0,
        errorRate: metrics.global?.error_rate || 0,
        apdex: metrics.global?.apdex || 0,
        durationSeconds: metrics.global?.duration_sec || 0,
        startTime: metrics.start_time
          ? new Date(typeof metrics.start_time === "number" ? metrics.start_time : metrics.start_time).toISOString()
          : startTime,
        endTime: metrics.end_time
          ? new Date(typeof metrics.end_time === "number" ? metrics.end_time : metrics.end_time).toISOString()
          : new Date().toISOString(),
        transactionDetails: metrics.per_label?.map((label: any) => ({
          label: label.label,
          count: label.count,
          avg: label.avg,
          min: label.min,
          max: label.max,
          p50: label.p50,
          p90: label.p90,
          p95: label.p95,
          p99: label.p99,
          errorRate: label.error_rate,
          errorCount: label.error_count,
          throughput: label.throughput,
        })) || [],
        errorSummary: metrics.error_summary || [],
        errorDetails: metrics.error_details || [],
        timeseries: metrics.timeseries || [],
        imported: true,
        importedFrom: req.file!.originalname,
      };

      if (resultSummary.timeseries && resultSummary.timeseries.length > 0) {
        try {
          const { detectFromTimeseries } = await import("./live-metrics/live-analysis-engine");
          const { anomalies, insights } = detectFromTimeseries(resultSummary.timeseries);
          if (anomalies.length > 0) {
            resultSummary.anomalies = anomalies;
            resultSummary.anomalySummary = {
              total: anomalies.length,
              warning: anomalies.filter((a: any) => a.severity === "warning").length,
              critical: anomalies.filter((a: any) => a.severity === "critical").length,
            };
          }
          if (insights.length > 0) {
            resultSummary.insights = insights;
            resultSummary.insightSummary = {
              total: insights.length,
              warning: insights.filter((e: any) => e.severity === "warning").length,
              critical: insights.filter((e: any) => e.severity === "critical").length,
              byType: insights.reduce((acc: Record<string, number>, e: any) => {
                acc[e.type] = (acc[e.type] || 0) + 1;
                return acc;
              }, {}),
            };
          }
        } catch (err) {
          console.error("Failed to run anomaly detection on imported results:", err);
        }
      }

      const endTime = metrics.end_time
        ? new Date(typeof metrics.end_time === "number" ? metrics.end_time : metrics.end_time).toISOString()
        : new Date().toISOString();
      const parsedStartTime = metrics.start_time
        ? new Date(typeof metrics.start_time === "number" ? metrics.start_time : metrics.start_time).toISOString()
        : startTime;
      await storage.updateExecution(execution.id, {
        status: "completed",
        startTime: parsedStartTime,
        endTime,
        resultSummary,
      });

      broadcastExecutionUpdate(execution.id, "completed", resultSummary);

      await logAudit({
        userId: sessionUser.id,
        action: "import_results",
        resourceType: "execution",
        resourceId: execution.id,
        details: {
          fileName: req.file!.originalname,
          runId,
          testName,
          totalRequests: resultSummary.totalRequests,
        },
      });

      res.status(201).json(sanitizeResponse({
        id: execution.id,
        executionId,
        runId,
        testName: `[Imported] ${testName}`,
        status: "completed",
        resultSummary,
      }));
    } catch (parseError) {
      const message = parseError instanceof Error ? parseError.message : String(parseError);
      await storage.updateExecution(execution.id, {
        status: "failed",
        endTime: new Date().toISOString(),
        resultSummary: { error: message, imported: true, importedFrom: req.file!.originalname } as any,
      });

      broadcastExecutionUpdate(execution.id, "failed");

      res.status(422).json({ message: `Failed to parse CSV file: ${message}` });
    }
  }));
}
