function esc(str: string | null | undefined): string {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function fmtDate(d: string | null | undefined): string {
  if (!d) return '-';
  try { return new Date(d).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }); }
  catch { return d; }
}

function fmtNum(n: number | null | undefined, decimals = 0): string {
  if (n === null || n === undefined || isNaN(n)) return '-';
  return Number(n).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

function changeArrow(pct: number | null | undefined, higherIsBad: boolean): string {
  if (pct === null || pct === undefined || isNaN(pct)) return '<span class="delta-neutral">-</span>';
  const abs = Math.abs(pct);
  if (abs < 0.5) return `<span class="delta-neutral">&asymp; 0%</span>`;
  const isUp = pct > 0;
  const cls = (higherIsBad ? isUp : !isUp) ? 'delta-bad' : 'delta-good';
  const arrow = isUp ? '&#9650;' : '&#9660;';
  return `<span class="${cls}">${arrow} ${isUp ? '+' : ''}${pct.toFixed(1)}%</span>`;
}

function verdictInfo(v: string | null | undefined): { text: string; cls: string; icon: string; color: string } {
  switch (v) {
    case 'go': return { text: 'GO', cls: 'verdict-go', icon: '&#10003;', color: '#059669' };
    case 'no_go': return { text: 'NO GO', cls: 'verdict-nogo', icon: '&#10007;', color: '#dc2626' };
    case 'conditional': return { text: 'CONDITIONAL', cls: 'verdict-conditional', icon: '!', color: '#d97706' };
    default: return { text: 'PENDING', cls: 'verdict-pending', icon: '?', color: '#6b7280' };
  }
}

function statusPill(s: string | null | undefined): string {
  switch (s) {
    case 'completed': return '<span class="pill pill-green">Completed</span>';
    case 'failed': return '<span class="pill pill-red">Failed</span>';
    case 'running': return '<span class="pill pill-blue">Running</span>';
    default: return `<span class="pill pill-gray">${esc(s || 'Unknown')}</span>`;
  }
}

function errorRateClass(rate: number): string {
  if (rate === 0) return 'delta-good';
  if (rate < 1) return 'delta-neutral';
  if (rate < 5) return 'delta-warn';
  return 'delta-bad';
}

function severityPill(sev: string | null | undefined): string {
  switch (sev) {
    case 'severe': return '<span class="pill pill-red">Severe</span>';
    case 'moderate': return '<span class="pill pill-orange">Moderate</span>';
    case 'minor': return '<span class="pill pill-yellow">Minor</span>';
    default: return '<span class="pill pill-gray">-</span>';
  }
}

function pctBar(value: number, max: number, color: string): string {
  const pct = max > 0 ? Math.min((value / max) * 100, 100) : 0;
  return `<div class="pct-bar"><div class="pct-bar-fill" style="width:${pct.toFixed(1)}%;background:${color}"></div></div>`;
}

function formatDuration(seconds: number | null | undefined): string {
  if (!seconds) return '-';
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m < 60) return s > 0 ? `${m}m ${s}s` : `${m}m`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  return rm > 0 ? `${h}h ${rm}m` : `${h}h`;
}

export function generateHtmlReport(report: any): string {
  const snap = report.reportSnapshot || {};
  const sections: any[] = snap.sections || [];
  const sla = snap.consolidatedSla;
  const comparison = snap.runComparison;
  const v = verdictInfo(report.overallVerdict);
  const generatedAt = fmtDate(snap.generatedAt);

  const totalRequests = sections.reduce((sum: number, s: any) => sum + (s.totalRequests || 0), 0);
  const totalFailed = sections.reduce((sum: number, s: any) => sum + (s.failedRequests || 0), 0);
  const totalSuccessful = totalRequests - totalFailed;
  const avgResp = sections.length > 0
    ? sections.reduce((sum: number, s: any) => sum + (s.avgResponseTime || 0), 0) / sections.length : 0;
  const avgTps = sections.length > 0
    ? sections.reduce((sum: number, s: any) => sum + (s.throughput || 0), 0) / sections.length : 0;
  const overallErrorRate = totalRequests > 0 ? (totalFailed / totalRequests * 100) : 0;
  const maxRT = Math.max(...sections.map((s: any) => s.maxResponseTime || 0), 0);
  const minRT = Math.min(...sections.filter((s: any) => s.minResponseTime > 0).map((s: any) => s.minResponseTime), Infinity);
  const avgP90 = sections.length > 0
    ? sections.filter((s: any) => s.p90).reduce((sum: number, s: any) => sum + s.p90, 0) / sections.filter((s: any) => s.p90).length : 0;
  const avgP95 = sections.length > 0
    ? sections.filter((s: any) => s.p95).reduce((sum: number, s: any) => sum + s.p95, 0) / sections.filter((s: any) => s.p95).length : 0;
  const avgP99 = sections.length > 0
    ? sections.filter((s: any) => s.p99).reduce((sum: number, s: any) => sum + s.p99, 0) / sections.filter((s: any) => s.p99).length : 0;

  const allTransactions: any[] = [];
  sections.forEach(s => {
    (s.transactionDetails || []).forEach((t: any) => {
      allTransactions.push({ ...t, testType: s.testType, executionId: s.executionId });
    });
  });
  const errorTransactions = allTransactions.filter(t => (t.errorCount || 0) > 0);

  const tocItems = [
    { id: 'executive-summary', label: 'Executive Summary' },
    { id: 'kpi-dashboard', label: 'KPI Dashboard' },
    ...(report.objective || report.scope || report.environmentNotes ? [{ id: 'test-context', label: 'Test Context & Scope' }] : []),
    { id: 'test-executions', label: 'Test Execution Results' },
    { id: 'transaction-analysis', label: 'Transaction Analysis' },
    ...(comparison && comparison.pairComparisons?.length > 0 ? [{ id: 'run-comparison', label: 'Baseline Comparison' }] : []),
  ];

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${esc(report.title)} - PerfHub Report</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
:root {
  --primary: #4f46e5; --primary-light: #818cf8; --primary-bg: #eef2ff;
  --bg: #f9fafb; --surface: #ffffff; --surface-alt: #f3f4f6;
  --border: #e5e7eb; --border-light: #f3f4f6;
  --text: #111827; --text-secondary: #6b7280; --text-muted: #9ca3af;
  --green: #059669; --green-bg: #ecfdf5; --green-border: #a7f3d0;
  --red: #dc2626; --red-bg: #fef2f2; --red-border: #fecaca;
  --yellow: #d97706; --yellow-bg: #fffbeb; --yellow-border: #fde68a;
  --orange: #ea580c; --orange-bg: #fff7ed; --orange-border: #fed7aa;
  --blue: #2563eb; --blue-bg: #eff6ff; --blue-border: #bfdbfe;
  --radius: 12px; --radius-sm: 8px; --shadow: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
  --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.07), 0 2px 4px -2px rgba(0,0,0,0.05);
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--bg); color: var(--text); line-height: 1.6; font-size: 14px;
  -webkit-print-color-adjust: exact; print-color-adjust: exact;
}
.page { max-width: 1140px; margin: 0 auto; padding: 32px 24px; }
@media print {
  .page { padding: 0; max-width: 100%; }
  .no-print { display: none !important; }
  .page-break { page-break-before: always; }
  body { background: #fff; }
}

/* ─── Cover Header ─── */
.cover {
  background: linear-gradient(135deg, #1e1b4b 0%, #312e81 40%, #4338ca 100%);
  color: #fff; padding: 48px 44px; border-radius: var(--radius); margin-bottom: 28px;
  position: relative; overflow: hidden;
}
.cover::before {
  content: ''; position: absolute; top: -60px; right: -40px;
  width: 320px; height: 320px;
  background: radial-gradient(circle, rgba(129,140,248,0.2) 0%, transparent 70%);
  border-radius: 50%;
}
.cover::after {
  content: ''; position: absolute; bottom: -80px; left: 30%;
  width: 400px; height: 200px;
  background: radial-gradient(ellipse, rgba(99,102,241,0.15) 0%, transparent 70%);
}
.cover-inner { position: relative; z-index: 1; }
.cover-brand {
  display: inline-flex; align-items: center; gap: 8px;
  font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 2.5px;
  color: rgba(199,210,254,0.8); margin-bottom: 24px;
}
.cover-brand svg { width: 20px; height: 20px; stroke: var(--primary-light); }
.cover h1 { font-size: 32px; font-weight: 800; line-height: 1.2; margin-bottom: 8px; letter-spacing: -0.5px; }
.cover-sub { color: rgba(199,210,254,0.7); font-size: 15px; font-weight: 400; }
.cover-meta {
  display: flex; gap: 32px; margin-top: 28px; padding-top: 20px;
  border-top: 1px solid rgba(255,255,255,0.12); flex-wrap: wrap;
}
.cover-meta-item { display: flex; flex-direction: column; gap: 3px; }
.cover-meta-item .lbl {
  font-size: 10px; text-transform: uppercase; letter-spacing: 1.5px;
  color: rgba(199,210,254,0.5); font-weight: 600;
}
.cover-meta-item .val { font-size: 14px; font-weight: 500; color: #e0e7ff; }

/* ─── Verdict ─── */
.verdict-strip {
  display: flex; align-items: stretch; border-radius: var(--radius);
  margin-bottom: 28px; overflow: hidden; box-shadow: var(--shadow);
}
.verdict-badge {
  display: flex; align-items: center; justify-content: center;
  padding: 20px 28px; min-width: 140px; flex-direction: column; gap: 4px;
}
.verdict-badge-icon {
  width: 44px; height: 44px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 22px; font-weight: 800; color: #fff;
}
.verdict-badge-label { font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: 2px; }
.verdict-body {
  flex: 1; padding: 20px 28px; display: flex; flex-direction: column; justify-content: center;
  background: var(--surface); border: 1px solid var(--border); border-left: none;
  border-radius: 0 var(--radius) var(--radius) 0;
}
.verdict-body-title { font-size: 15px; font-weight: 600; color: var(--text); margin-bottom: 2px; }
.verdict-body-notes { font-size: 13px; color: var(--text-secondary); }
.verdict-go .verdict-badge { background: var(--green); color: #fff; }
.verdict-go .verdict-badge-icon { background: rgba(255,255,255,0.25); }
.verdict-nogo .verdict-badge { background: var(--red); color: #fff; }
.verdict-nogo .verdict-badge-icon { background: rgba(255,255,255,0.25); }
.verdict-conditional .verdict-badge { background: var(--yellow); color: #fff; }
.verdict-conditional .verdict-badge-icon { background: rgba(255,255,255,0.25); }
.verdict-pending .verdict-badge { background: #6b7280; color: #fff; }
.verdict-pending .verdict-badge-icon { background: rgba(255,255,255,0.25); }

/* ─── Table of Contents ─── */
.toc {
  background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
  padding: 24px 28px; margin-bottom: 28px; box-shadow: var(--shadow);
}
.toc-title {
  font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px;
  color: var(--text-muted); margin-bottom: 12px;
}
.toc-list { list-style: none; display: flex; flex-wrap: wrap; gap: 6px 16px; }
.toc-list li a {
  font-size: 13px; color: var(--primary); text-decoration: none; font-weight: 500;
  padding: 4px 12px; border-radius: 6px; background: var(--primary-bg);
  display: inline-block; transition: all 0.15s;
}
.toc-list li a:hover { background: var(--primary); color: #fff; }

/* ─── Section Headings ─── */
.section { margin-bottom: 32px; }
.section-header {
  display: flex; align-items: center; gap: 10px; margin-bottom: 18px;
  padding-bottom: 10px; border-bottom: 2px solid var(--primary);
}
.section-icon {
  width: 32px; height: 32px; border-radius: var(--radius-sm);
  background: var(--primary-bg); display: flex; align-items: center; justify-content: center;
}
.section-icon svg { width: 16px; height: 16px; stroke: var(--primary); }
.section-title { font-size: 18px; font-weight: 700; color: var(--text); }
.section-num { font-size: 12px; color: var(--text-muted); font-weight: 500; }

/* ─── Cards ─── */
.card {
  background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
  box-shadow: var(--shadow); margin-bottom: 20px; overflow: hidden;
}
.card-head {
  padding: 16px 24px; border-bottom: 1px solid var(--border-light);
  display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
  background: linear-gradient(to right, var(--surface-alt), var(--surface));
}
.card-head-title { font-size: 15px; font-weight: 700; }
.card-body { padding: 20px 24px; }

/* ─── KPI Grid ─── */
.kpi-row { display: grid; gap: 16px; margin-bottom: 24px; }
.kpi-row-4 { grid-template-columns: repeat(4, 1fr); }
.kpi-row-6 { grid-template-columns: repeat(6, 1fr); }
.kpi-row-3 { grid-template-columns: repeat(3, 1fr); }
@media (max-width: 768px) {
  .kpi-row-4, .kpi-row-6 { grid-template-columns: repeat(2, 1fr); }
  .kpi-row-3 { grid-template-columns: 1fr; }
}
.kpi {
  background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
  padding: 20px; text-align: center; box-shadow: var(--shadow); position: relative; overflow: hidden;
}
.kpi::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; }
.kpi-indigo::before { background: var(--primary); }
.kpi-green::before { background: var(--green); }
.kpi-red::before { background: var(--red); }
.kpi-yellow::before { background: var(--yellow); }
.kpi-blue::before { background: var(--blue); }
.kpi-orange::before { background: var(--orange); }
.kpi-value { font-size: 28px; font-weight: 800; color: var(--text); line-height: 1.1; margin-bottom: 4px; }
.kpi-label {
  font-size: 11px; text-transform: uppercase; letter-spacing: 1px;
  color: var(--text-muted); font-weight: 600;
}
.kpi-sub { font-size: 11px; color: var(--text-secondary); margin-top: 4px; }
.kpi-sm .kpi-value { font-size: 20px; }

/* ─── Tables ─── */
table { width: 100%; border-collapse: collapse; font-size: 13px; }
thead th {
  background: var(--surface-alt); font-weight: 600; text-align: left;
  padding: 10px 16px; font-size: 11px; text-transform: uppercase;
  letter-spacing: 0.5px; color: var(--text-secondary);
  border-bottom: 2px solid var(--border);
}
tbody td { padding: 10px 16px; border-bottom: 1px solid var(--border-light); vertical-align: middle; }
tbody tr:last-child td { border-bottom: none; }
tbody tr:hover { background: #fafbfc; }
.text-right { text-align: right; }
.text-center { text-align: center; }
.mono { font-family: 'SF Mono', 'Cascadia Code', Consolas, monospace; font-size: 12px; font-weight: 500; }
.font-medium { font-weight: 500; }

/* ─── Pills ─── */
.pill {
  display: inline-block; padding: 3px 10px; border-radius: 20px;
  font-size: 11px; font-weight: 600; line-height: 1.5;
}
.pill-green { background: var(--green-bg); color: var(--green); border: 1px solid var(--green-border); }
.pill-red { background: var(--red-bg); color: var(--red); border: 1px solid var(--red-border); }
.pill-yellow { background: var(--yellow-bg); color: var(--yellow); border: 1px solid var(--yellow-border); }
.pill-orange { background: var(--orange-bg); color: var(--orange); border: 1px solid var(--orange-border); }
.pill-blue { background: var(--blue-bg); color: var(--blue); border: 1px solid var(--blue-border); }
.pill-gray { background: var(--surface-alt); color: var(--text-secondary); border: 1px solid var(--border); }

/* ─── Deltas ─── */
.delta-good { color: var(--green); font-weight: 600; }
.delta-bad { color: var(--red); font-weight: 600; }
.delta-warn { color: var(--yellow); font-weight: 600; }
.delta-neutral { color: var(--text-muted); font-weight: 500; }

/* ─── Info Grid ─── */
.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
@media (max-width: 600px) { .info-grid { grid-template-columns: 1fr; } }
.info-cell {
  padding: 14px 0; border-bottom: 1px solid var(--border-light);
  display: flex; flex-direction: column; gap: 2px;
}
.info-cell:nth-child(odd) { padding-right: 24px; }
.info-cell:nth-child(even) { padding-left: 24px; border-left: 1px solid var(--border-light); }
.info-lbl {
  font-size: 11px; text-transform: uppercase; letter-spacing: 1px;
  color: var(--text-muted); font-weight: 600;
}
.info-val { font-size: 14px; color: var(--text); line-height: 1.5; }

/* ─── SLA Bar ─── */
.sla-visual { display: flex; gap: 2px; height: 12px; border-radius: 6px; overflow: hidden; margin: 10px 0; background: var(--surface-alt); }
.sla-visual .seg-pass { background: var(--green); border-radius: 6px; }
.sla-visual .seg-fail { background: var(--red); border-radius: 6px; }

/* ─── Percentage bar ─── */
.pct-bar { width: 100%; height: 6px; background: var(--surface-alt); border-radius: 3px; overflow: hidden; }
.pct-bar-fill { height: 100%; border-radius: 3px; transition: width 0.3s; }

/* ─── Comparison pair ─── */
.pair-block { margin-bottom: 24px; }
.pair-header {
  display: flex; align-items: center; gap: 12px; margin-bottom: 14px;
  padding: 12px 16px; background: var(--primary-bg); border-radius: var(--radius-sm);
  border-left: 4px solid var(--primary);
}
.pair-title { font-size: 15px; font-weight: 700; color: var(--text); }
.pair-ids {
  font-size: 11px; color: var(--text-secondary); background: var(--surface);
  padding: 4px 10px; border-radius: 4px; font-weight: 500; border: 1px solid var(--border);
}

/* ─── Exec Card stripe ─── */
.exec-stripe {
  height: 4px; border-radius: var(--radius) var(--radius) 0 0;
}
.stripe-green { background: linear-gradient(90deg, var(--green), #34d399); }
.stripe-red { background: linear-gradient(90deg, var(--red), #f87171); }
.stripe-blue { background: linear-gradient(90deg, var(--blue), #60a5fa); }
.stripe-yellow { background: linear-gradient(90deg, var(--yellow), #fbbf24); }

/* ─── Footer ─── */
.report-footer {
  text-align: center; padding: 28px 20px; margin-top: 40px;
  border-top: 2px solid var(--border); color: var(--text-muted); font-size: 12px;
}
.report-footer strong { color: var(--text-secondary); }
.report-footer .divider { display: inline-block; margin: 0 8px; color: var(--border); }

/* ─── Highlight box ─── */
.highlight-box {
  padding: 14px 18px; border-radius: var(--radius-sm); margin-top: 12px;
  font-size: 13px; border: 1px solid;
}
.highlight-green { background: var(--green-bg); border-color: var(--green-border); color: #065f46; }
.highlight-red { background: var(--red-bg); border-color: var(--red-border); color: #991b1b; }
.highlight-yellow { background: var(--yellow-bg); border-color: var(--yellow-border); color: #92400e; }

.two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
@media (max-width: 768px) { .two-col { grid-template-columns: 1fr; } }

.page-break { page-break-before: always; }
</style>
</head>
<body>
<div class="page">

<!-- ════════ COVER ════════ -->
<div class="cover">
  <div class="cover-inner">
    <div class="cover-brand">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
      PerfHub &middot; Test Completion Report
    </div>
    <h1>${esc(report.title)}</h1>
    ${report.projectName || report.featureName ? `<div class="cover-sub">${[esc(report.projectName), esc(report.featureName)].filter(Boolean).join(' &mdash; ')}</div>` : ''}
    <div class="cover-meta">
      <div class="cover-meta-item"><span class="lbl">Report ID</span><span class="val">#${report.id}</span></div>
      <div class="cover-meta-item"><span class="lbl">Status</span><span class="val">${report.status === 'finalized' ? 'Finalized' : 'Draft'}</span></div>
      <div class="cover-meta-item"><span class="lbl">Test Executions</span><span class="val">${sections.length}</span></div>
      <div class="cover-meta-item"><span class="lbl">Report Generated</span><span class="val">${generatedAt}</span></div>
      <div class="cover-meta-item"><span class="lbl">Created</span><span class="val">${fmtDate(report.createdAt)}</span></div>
    </div>
  </div>
</div>

<!-- ════════ VERDICT ════════ -->
<div class="verdict-strip ${v.cls}">
  <div class="verdict-badge">
    <div class="verdict-badge-icon">${v.icon}</div>
    <div class="verdict-badge-label">${v.text}</div>
  </div>
  <div class="verdict-body">
    <div class="verdict-body-title">Overall Verdict: ${v.text}</div>
    ${report.verdictNotes ? `<div class="verdict-body-notes">${esc(report.verdictNotes)}</div>` : '<div class="verdict-body-notes">No verdict notes provided.</div>'}
  </div>
</div>

<!-- ════════ TABLE OF CONTENTS ════════ -->
<div class="toc no-print">
  <div class="toc-title">Report Sections</div>
  <ul class="toc-list">
    ${tocItems.map(item => `<li><a href="#${item.id}">${esc(item.label)}</a></li>`).join('')}
  </ul>
</div>

<!-- ════════ 1. EXECUTIVE SUMMARY ════════ -->
<div class="section" id="executive-summary">
  <div class="section-header">
    <div class="section-icon"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg></div>
    <div>
      <div class="section-title">Executive Summary</div>
      <div class="section-num">Section 1</div>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <div style="display:grid;grid-template-columns:2fr 1fr;gap:28px;align-items:start">
        <div>
          <p style="font-size:14px;line-height:1.7;color:var(--text-secondary);margin-bottom:16px">
            This report consolidates <strong>${sections.length} test execution(s)</strong> across
            <strong>${Array.from(new Set(sections.map((s: any) => s.testType))).length} test type(s)</strong>.
            The system processed a total of <strong>${fmtNum(totalRequests)} requests</strong>
            with an overall error rate of <strong class="${overallErrorRate > 5 ? 'delta-bad' : overallErrorRate > 0 ? 'delta-warn' : 'delta-good'}">${overallErrorRate.toFixed(2)}%</strong>
            and an average response time of <strong>${fmtNum(avgResp, 0)}ms</strong>.
          </p>
          ${report.objective ? `<div style="margin-bottom:10px"><span class="info-lbl">Objective</span><div class="info-val">${esc(report.objective)}</div></div>` : ''}
          ${report.recommendations ? `
          <div class="highlight-box highlight-yellow" style="margin-top:16px">
            <strong style="display:block;margin-bottom:4px">&#9888; Recommendations</strong>
            ${esc(report.recommendations)}
          </div>` : ''}
        </div>
        <div style="text-align:center;padding:20px;background:var(--surface-alt);border-radius:var(--radius);border:1px solid var(--border)">
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);font-weight:600;margin-bottom:8px">Success Rate</div>
          <div style="font-size:42px;font-weight:800;color:${overallErrorRate > 5 ? 'var(--red)' : overallErrorRate > 1 ? 'var(--yellow)' : 'var(--green)'}">${totalRequests > 0 ? ((totalSuccessful / totalRequests) * 100).toFixed(1) : '0'}%</div>
          <div style="font-size:12px;color:var(--text-secondary);margin-top:4px">${fmtNum(totalSuccessful)} of ${fmtNum(totalRequests)} requests</div>
          ${pctBar(totalSuccessful, totalRequests, overallErrorRate > 5 ? 'var(--red)' : overallErrorRate > 1 ? 'var(--yellow)' : 'var(--green)')}
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ════════ 2. KPI DASHBOARD ════════ -->
<div class="section" id="kpi-dashboard">
  <div class="section-header">
    <div class="section-icon"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg></div>
    <div>
      <div class="section-title">KPI Dashboard</div>
      <div class="section-num">Section 2</div>
    </div>
  </div>

  <div class="kpi-row kpi-row-4">
    <div class="kpi kpi-indigo">
      <div class="kpi-value">${fmtNum(totalRequests)}</div>
      <div class="kpi-label">Total Requests</div>
    </div>
    <div class="kpi ${totalFailed > 0 ? 'kpi-red' : 'kpi-green'}">
      <div class="kpi-value">${fmtNum(totalFailed)}</div>
      <div class="kpi-label">Failed Requests</div>
      <div class="kpi-sub">${overallErrorRate.toFixed(2)}% error rate</div>
    </div>
    <div class="kpi kpi-blue">
      <div class="kpi-value">${fmtNum(avgResp, 0)}<span style="font-size:14px;font-weight:400">ms</span></div>
      <div class="kpi-label">Avg Response Time</div>
    </div>
    <div class="kpi kpi-indigo">
      <div class="kpi-value">${fmtNum(avgTps, 1)}</div>
      <div class="kpi-label">Avg Throughput (TPS)</div>
    </div>
  </div>

  <div class="kpi-row kpi-row-6">
    <div class="kpi kpi-sm kpi-blue">
      <div class="kpi-value">${avgP90 > 0 ? fmtNum(avgP90, 0) + 'ms' : '-'}</div>
      <div class="kpi-label">Avg P90</div>
    </div>
    <div class="kpi kpi-sm kpi-blue">
      <div class="kpi-value">${avgP95 > 0 ? fmtNum(avgP95, 0) + 'ms' : '-'}</div>
      <div class="kpi-label">Avg P95</div>
    </div>
    <div class="kpi kpi-sm kpi-orange">
      <div class="kpi-value">${avgP99 > 0 ? fmtNum(avgP99, 0) + 'ms' : '-'}</div>
      <div class="kpi-label">Avg P99</div>
    </div>
    <div class="kpi kpi-sm kpi-yellow">
      <div class="kpi-value">${maxRT > 0 ? fmtNum(maxRT, 0) + 'ms' : '-'}</div>
      <div class="kpi-label">Max Response</div>
    </div>
    <div class="kpi kpi-sm kpi-green">
      <div class="kpi-value">${minRT < Infinity ? fmtNum(minRT, 0) + 'ms' : '-'}</div>
      <div class="kpi-label">Min Response</div>
    </div>
    <div class="kpi kpi-sm ${sla && sla.failed > 0 ? 'kpi-red' : 'kpi-green'}">
      <div class="kpi-value">${sla ? `${sla.passed}/${sla.passed + sla.failed}` : '-'}</div>
      <div class="kpi-label">SLA Rules Passed</div>
    </div>
  </div>
</div>

<!-- ════════ 3. TEST CONTEXT ════════ -->
${(report.objective || report.scope || report.environmentNotes) ? `
<div class="section" id="test-context">
  <div class="section-header">
    <div class="section-icon"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg></div>
    <div>
      <div class="section-title">Test Context &amp; Scope</div>
      <div class="section-num">Section 3</div>
    </div>
  </div>
  <div class="card">
    <div class="card-body">
      <div class="info-grid">
        ${report.objective ? `<div class="info-cell"><span class="info-lbl">Test Objective</span><span class="info-val">${esc(report.objective)}</span></div>` : ''}
        ${report.scope ? `<div class="info-cell"><span class="info-lbl">Scope</span><span class="info-val">${esc(report.scope)}</span></div>` : ''}
        ${report.environmentNotes ? `<div class="info-cell"><span class="info-lbl">Environment Details</span><span class="info-val">${esc(report.environmentNotes)}</span></div>` : ''}
        ${report.recommendations ? `<div class="info-cell"><span class="info-lbl">Recommendations</span><span class="info-val">${esc(report.recommendations)}</span></div>` : ''}
      </div>
    </div>
  </div>
</div>` : ''}

<!-- ════════ 4. TEST EXECUTION RESULTS ════════ -->
<div class="section page-break" id="test-executions">
  <div class="section-header">
    <div class="section-icon"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg></div>
    <div>
      <div class="section-title">Test Execution Results</div>
      <div class="section-num">Section 4 &mdash; ${sections.length} execution(s)</div>
    </div>
  </div>

  ${sections.map((s: any, idx: number) => {
    const stripeClass = s.status === 'completed' ? 'stripe-green' : s.status === 'failed' ? 'stripe-red' : 'stripe-blue';
    const errRate = s.totalRequests > 0 ? (s.failedRequests / s.totalRequests * 100) : 0;
    return `
  <div class="card" ${idx > 0 && idx % 2 === 0 ? 'style="page-break-before:always"' : ''}>
    <div class="exec-stripe ${stripeClass}"></div>
    <div class="card-head">
      <span class="card-head-title">${esc(s.testType)}</span>
      <span class="pill pill-blue">${esc(s.scheduleName)}</span>
      <span class="pill pill-gray">#${s.executionId}</span>
      ${statusPill(s.status)}
    </div>
    <div class="card-body">
      <div class="info-grid" style="margin-bottom:18px">
        <div class="info-cell"><span class="info-lbl">Script</span><span class="info-val">${esc(s.scriptName)}</span></div>
        <div class="info-cell"><span class="info-lbl">Environment</span><span class="info-val">${esc(s.environment)}</span></div>
        <div class="info-cell"><span class="info-lbl">Configuration</span><span class="info-val">${s.vusers || '-'} vUsers &middot; ${formatDuration(s.duration)}</span></div>
        <div class="info-cell"><span class="info-lbl">Time Window</span><span class="info-val">${fmtDate(s.startTime)} &rarr; ${fmtDate(s.endTime)}</span></div>
      </div>

      <div class="kpi-row kpi-row-6" style="margin-bottom:18px">
        <div class="kpi kpi-sm kpi-indigo"><div class="kpi-value">${fmtNum(s.totalRequests)}</div><div class="kpi-label">Requests</div></div>
        <div class="kpi kpi-sm ${s.failedRequests > 0 ? 'kpi-red' : 'kpi-green'}"><div class="kpi-value">${fmtNum(s.failedRequests)}</div><div class="kpi-label">Failed</div></div>
        <div class="kpi kpi-sm kpi-blue"><div class="kpi-value">${fmtNum(s.avgResponseTime, 0)}ms</div><div class="kpi-label">Avg RT</div></div>
        <div class="kpi kpi-sm kpi-indigo"><div class="kpi-value">${fmtNum(s.throughput, 1)}</div><div class="kpi-label">TPS</div></div>
        <div class="kpi kpi-sm kpi-orange"><div class="kpi-value">${s.p90 ? fmtNum(s.p90, 0) + 'ms' : '-'}</div><div class="kpi-label">P90</div></div>
        <div class="kpi kpi-sm kpi-yellow"><div class="kpi-value">${s.p95 ? fmtNum(s.p95, 0) + 'ms' : '-'}</div><div class="kpi-label">P95</div></div>
      </div>

      ${s.transactionDetails && s.transactionDetails.length > 0 ? `
      <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);margin-bottom:10px">Transaction Breakdown</div>
      <table>
        <thead>
          <tr>
            <th>Transaction</th>
            <th class="text-right">Samples</th>
            <th class="text-right">Avg (ms)</th>
            <th class="text-right">P90 (ms)</th>
            <th class="text-right">P95 (ms)</th>
            <th class="text-right">TPS</th>
            <th class="text-right">Errors</th>
            <th class="text-right">Error %</th>
          </tr>
        </thead>
        <tbody>
          ${s.transactionDetails.map((t: any) => {
            const tErrRate = t.errorRate !== undefined ? (t.errorRate * 100) : 0;
            return `
          <tr>
            <td class="font-medium">${esc(t.label)}</td>
            <td class="text-right mono">${fmtNum(t.count)}</td>
            <td class="text-right mono">${fmtNum(t.avg, 1)}</td>
            <td class="text-right mono">${fmtNum(t.p90, 0)}</td>
            <td class="text-right mono">${fmtNum(t.p95, 0)}</td>
            <td class="text-right mono">${fmtNum(t.throughput, 2)}</td>
            <td class="text-right mono ${(t.errorCount || 0) > 0 ? 'delta-bad' : ''}">${fmtNum(t.errorCount)}</td>
            <td class="text-right"><span class="${errorRateClass(tErrRate)}">${tErrRate.toFixed(1)}%</span></td>
          </tr>`;
          }).join('')}
        </tbody>
      </table>` : ''}

    </div>
  </div>`;
  }).join('')}
</div>

<!-- ════════ 5. TRANSACTION ANALYSIS ════════ -->
<div class="section page-break" id="transaction-analysis">
  <div class="section-header">
    <div class="section-icon"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></div>
    <div>
      <div class="section-title">Transaction Analysis</div>
      <div class="section-num">Section 5</div>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><span class="card-head-title">Transactions with Errors</span></div>
    <div class="card-body">
      ${errorTransactions.length > 0 ? `
      <table>
        <thead><tr><th>Transaction</th><th>Test</th><th class="text-right">Errors</th><th class="text-right">Error %</th></tr></thead>
        <tbody>
          ${errorTransactions.map((t: any) => `
          <tr>
            <td class="font-medium">${esc(t.label)}</td>
            <td style="font-size:12px;color:var(--text-secondary)">${esc(t.testType)}</td>
            <td class="text-right mono delta-bad">${fmtNum(t.errorCount)}</td>
            <td class="text-right"><span class="delta-bad">${t.errorRate !== undefined ? (t.errorRate * 100).toFixed(1) : '0'}%</span></td>
          </tr>`).join('')}
        </tbody>
      </table>` : `
      <div class="highlight-box highlight-green">
        <strong>&#10003; No transaction errors detected.</strong>
      </div>`}
    </div>
  </div>
</div>

<!-- ════════ 6. BASELINE COMPARISON ════════ -->
${comparison && comparison.pairComparisons && comparison.pairComparisons.length > 0 ? `
<div class="section page-break" id="run-comparison">
  <div class="section-header">
    <div class="section-icon"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><circle cx="18" cy="18" r="3"/><circle cx="6" cy="6" r="3"/><path d="M13 6h3a2 2 0 0 1 2 2v7"/><path d="M11 18H8a2 2 0 0 1-2-2V9"/></svg></div>
    <div>
      <div class="section-title">Baseline Comparison</div>
      <div class="section-num">Section 6 &mdash; ${comparison.pairComparisons.length} pair(s)</div>
    </div>
  </div>

  <div class="kpi-row kpi-row-3" style="margin-bottom:20px">
    <div class="kpi kpi-indigo"><div class="kpi-value">${comparison.pairComparisons.length}</div><div class="kpi-label">Matched Pairs</div></div>
    <div class="kpi kpi-yellow"><div class="kpi-value">${comparison.unmatchedCurrent?.length || 0}</div><div class="kpi-label">Unmatched Current</div></div>
    <div class="kpi kpi-orange"><div class="kpi-value">${comparison.unmatchedCompare?.length || 0}</div><div class="kpi-label">Unmatched Compare</div></div>
  </div>

  ${comparison.pairComparisons.map((pair: any) => `
  <div class="card">
    <div class="card-body">
      <div class="pair-block">
        <div class="pair-header">
          <div>
            <div class="pair-title">${esc(pair.testType)} &mdash; ${esc(pair.scheduleName)}</div>
          </div>
          <div class="pair-ids">Current #${pair.currentExecutionId} vs Compare #${pair.compareExecutionId}</div>
        </div>

        <table>
          <thead><tr><th>Metric</th><th class="text-right">Current Run</th><th class="text-right">Compare Run</th><th class="text-right">Change</th></tr></thead>
          <tbody>
            ${pair.metrics?.avgResponseTime ? `<tr><td class="font-medium">Avg Response Time</td><td class="text-right mono">${fmtNum(pair.metrics.avgResponseTime.current, 0)}ms</td><td class="text-right mono">${fmtNum(pair.metrics.avgResponseTime.compare, 0)}ms</td><td class="text-right">${changeArrow(pair.metrics.avgResponseTime.changePercent, true)}</td></tr>` : ''}
            ${pair.metrics?.throughput ? `<tr><td class="font-medium">Throughput (TPS)</td><td class="text-right mono">${fmtNum(pair.metrics.throughput.current, 1)}</td><td class="text-right mono">${fmtNum(pair.metrics.throughput.compare, 1)}</td><td class="text-right">${changeArrow(pair.metrics.throughput.changePercent, false)}</td></tr>` : ''}
            ${pair.metrics?.errorRate ? `<tr><td class="font-medium">Error Rate</td><td class="text-right mono">${fmtNum(pair.metrics.errorRate.current, 2)}%</td><td class="text-right mono">${fmtNum(pair.metrics.errorRate.compare, 2)}%</td><td class="text-right">${changeArrow(pair.metrics.errorRate.changePercent, true)}</td></tr>` : ''}
            ${pair.metrics?.p90 ? `<tr><td class="font-medium">P90 Response Time</td><td class="text-right mono">${fmtNum(pair.metrics.p90.current, 0)}ms</td><td class="text-right mono">${fmtNum(pair.metrics.p90.compare, 0)}ms</td><td class="text-right">${changeArrow(pair.metrics.p90.changePercent, true)}</td></tr>` : ''}
            ${pair.metrics?.p95 ? `<tr><td class="font-medium">P95 Response Time</td><td class="text-right mono">${fmtNum(pair.metrics.p95.current, 0)}ms</td><td class="text-right mono">${fmtNum(pair.metrics.p95.compare, 0)}ms</td><td class="text-right">${changeArrow(pair.metrics.p95.changePercent, true)}</td></tr>` : ''}
            ${pair.metrics?.totalRequests ? `<tr><td class="font-medium">Total Requests</td><td class="text-right mono">${fmtNum(pair.metrics.totalRequests.current)}</td><td class="text-right mono">${fmtNum(pair.metrics.totalRequests.compare)}</td><td class="text-right delta-neutral">-</td></tr>` : ''}
          </tbody>
        </table>

        ${pair.transactionComparison && pair.transactionComparison.length > 0 ? `
        <div style="margin-top:18px">
          <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);margin-bottom:10px">Transaction-Level Comparison</div>
          <table>
            <thead>
              <tr>
                <th>Transaction</th>
                <th class="text-right">Avg Curr (ms)</th>
                <th class="text-right">Avg Comp (ms)</th>
                <th class="text-right">Avg &Delta;</th>
                <th class="text-right">P90 Curr (ms)</th>
                <th class="text-right">P90 Comp (ms)</th>
                <th class="text-right">P90 &Delta;</th>
              </tr>
            </thead>
            <tbody>
              ${pair.transactionComparison.map((txn: any) => `
              <tr>
                <td class="font-medium">${esc(txn.label)}</td>
                <td class="text-right mono">${fmtNum(txn.avgCurrent, 0)}</td>
                <td class="text-right mono">${fmtNum(txn.avgCompare, 0)}</td>
                <td class="text-right">${changeArrow(txn.avgChange, true)}</td>
                <td class="text-right mono">${fmtNum(txn.p90Current, 0)}</td>
                <td class="text-right mono">${fmtNum(txn.p90Compare, 0)}</td>
                <td class="text-right">${changeArrow(txn.p90Change, true)}</td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>` : ''}
      </div>
    </div>
  </div>`).join('')}
</div>` : ''}

<!-- ════════ FOOTER ════════ -->
<div class="report-footer">
  <strong>PerfHub V3</strong>
  <span class="divider">|</span>
  Performance Engineering Platform
  <span class="divider">|</span>
  Report #${report.id}
  <span class="divider">|</span>
  Generated ${generatedAt}
  <br>
  <span style="font-size:11px;color:var(--text-muted);margin-top:6px;display:inline-block">
    This report is auto-generated. Data accuracy depends on test execution results at the time of snapshot.
  </span>
</div>

</div>
</body>
</html>`;
}

export function generateReportPreviewHtml(report: any, approvals?: any[]): string {
  const snap = report.reportSnapshot || {};
  const sections: any[] = snap.sections || [];
  const sla = snap.consolidatedSla;
  const comparison = snap.runComparison;
  const vi = verdictInfo(report.overallVerdict);
  const generatedAt = fmtDate(snap.generatedAt);
  const customSections: any[] = snap.customSections || [];

  const totReqs = sections.reduce((s: number, x: any) => s + (x.totalRequests || 0), 0);
  const totFail = sections.reduce((s: number, x: any) => s + (x.failedRequests || 0), 0);
  const errRate = totReqs > 0 ? (totFail / totReqs * 100) : 0;
  const successRate = totReqs > 0 ? ((totReqs - totFail) / totReqs * 100) : 100;
  const avgRT = sections.length > 0
    ? sections.reduce((s: number, x: any) => s + (x.avgResponseTime || 0), 0) / sections.length : 0;
  const avgTPS = sections.length > 0
    ? sections.reduce((s: number, x: any) => s + (x.throughput || 0), 0) / sections.length : 0;

  const avgOf = (key: string) => {
    const vals = sections.filter((x: any) => x[key]).map((x: any) => x[key]);
    return vals.length > 0 ? vals.reduce((a: number, b: number) => a + b, 0) / vals.length : 0;
  };

  let healthScore = 100;
  if (errRate > 5) healthScore -= 40;
  else if (errRate > 1) healthScore -= 20;
  else if (errRate > 0.1) healthScore -= 5;
  const slaViolationCount = sla?.violations?.length || 0;
  healthScore -= Math.min(slaViolationCount * 10, 40);
  healthScore = Math.max(0, Math.min(100, healthScore));

  const allTxn: any[] = [];
  sections.forEach((s: any) => {
    (s.transactionDetails || []).forEach((t: any) => {
      allTxn.push({ ...t, testType: s.testType, executionId: s.executionId });
    });
  });

  const approvalsHtml = (approvals && approvals.length > 0) ? `
    <div class="section">
      <h2>Approval Workflow</h2>
      <table class="data-table">
        <thead><tr><th>Step</th><th>Reviewer</th><th>Status</th><th>Comment</th><th>Date</th></tr></thead>
        <tbody>
          ${approvals.map((a: any) => {
            const statusLabel = a.status === "approved" ? "Approved" : a.status === "rejected" ? "Rejected" : a.status === "changes_requested" ? "Changes Requested" : "Pending";
            const statusCls = a.status === "approved" ? "delta-good" : a.status === "rejected" ? "delta-bad" : a.status === "changes_requested" ? "delta-warn" : "delta-neutral";
            return `<tr><td>${a.stepOrder}</td><td>${esc(a.reviewerName || a.reviewerEmail || '-')}</td><td><span class="${statusCls}">${statusLabel}</span></td><td>${esc(a.comment || '-')}</td><td>${a.actedAt ? fmtDate(a.actedAt) : '-'}</td></tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>` : '';

  const comparisonHtml = (comparison?.pairComparisons?.length > 0) ? `
    <div class="section">
      <h2>Current vs Baseline Comparison</h2>
      ${comparison.pairComparisons.map((pair: any) => {
        const m = pair.metrics || {};
        const rows = [
          { label: 'Avg Response Time', cur: `${fmtNum(m.avgResponseTime?.current, 0)}ms`, cmp: `${fmtNum(m.avgResponseTime?.compare, 0)}ms`, chg: m.avgResponseTime?.changePercent, bad: true },
          { label: 'Throughput', cur: `${fmtNum(m.throughput?.current, 1)} rps`, cmp: `${fmtNum(m.throughput?.compare, 1)} rps`, chg: m.throughput?.changePercent, bad: false },
          { label: 'Error Rate', cur: `${(m.errorRate?.current || 0).toFixed(2)}%`, cmp: `${(m.errorRate?.compare || 0).toFixed(2)}%`, chg: m.errorRate?.changePercent, bad: true },
          { label: 'Total Requests', cur: fmtNum(m.totalRequests?.current), cmp: fmtNum(m.totalRequests?.compare), chg: null, bad: false },
        ];
        if (m.p90) rows.splice(3, 0, { label: 'P90', cur: `${fmtNum(m.p90.current, 0)}ms`, cmp: `${fmtNum(m.p90.compare, 0)}ms`, chg: m.p90.changePercent, bad: true });
        if (m.p95) rows.splice(4, 0, { label: 'P95', cur: `${fmtNum(m.p95.current, 0)}ms`, cmp: `${fmtNum(m.p95.compare, 0)}ms`, chg: m.p95.changePercent, bad: true });

        const txnHtml = (pair.transactionComparison?.length > 0) ? `
          <h3 style="margin-top:16px;">Transaction-Level Comparison</h3>
          <table class="data-table">
            <thead><tr><th>Transaction</th><th>Avg Current</th><th>Avg Baseline</th><th>Avg Change</th><th>P90 Current</th><th>P90 Baseline</th><th>P90 Change</th></tr></thead>
            <tbody>
              ${pair.transactionComparison.map((tc: any) => `
                <tr>
                  <td><strong>${esc(tc.label)}</strong></td>
                  <td>${fmtNum(tc.avgCurrent, 0)}ms</td>
                  <td>${fmtNum(tc.avgCompare, 0)}ms</td>
                  <td>${changeArrow(tc.avgChange, true)}</td>
                  <td>${fmtNum(tc.p90Current, 0)}ms</td>
                  <td>${fmtNum(tc.p90Compare, 0)}ms</td>
                  <td>${changeArrow(tc.p90Change, true)}</td>
                </tr>`).join('')}
            </tbody>
          </table>` : '';

        return `
          <div style="background:#f8fafc;border-radius:8px;padding:16px;margin-bottom:16px;border:1px solid #e5e7eb;">
            <h3 style="margin:0 0 12px 0;color:#312e81;">${esc(pair.testType || 'Test')} &mdash; ${esc(pair.scheduleName || '')}</h3>
            <p style="font-size:12px;color:#6b7280;margin-bottom:12px;">Current #${pair.currentExecutionId || '?'} vs Baseline #${pair.compareExecutionId || '?'}</p>
            <table class="data-table">
              <thead><tr><th>Metric</th><th>Current</th><th>Baseline</th><th>Change</th></tr></thead>
              <tbody>${rows.map(r => `<tr><td><strong>${esc(r.label)}</strong></td><td>${r.cur}</td><td>${r.cmp}</td><td>${r.chg !== null ? changeArrow(r.chg, r.bad) : '-'}</td></tr>`).join('')}</tbody>
            </table>
            ${txnHtml}
          </div>`;
      }).join('')}
    </div>` : '';

  const txnDetailsHtml = sections.map((s: any) => {
    if (!s.transactionDetails || s.transactionDetails.length === 0) return '';
    return `
      <div style="margin-bottom:20px;">
        <h3 style="color:#312e81;">${esc(s.testType || 'Test')} &mdash; ${esc(s.scheduleName || s.scriptName || '')}</h3>
        <table class="data-table">
          <thead><tr><th>Transaction</th><th>Count</th><th>Avg (ms)</th><th>P90 (ms)</th><th>P95 (ms)</th><th>TPS</th><th>Errors</th><th>Err %</th></tr></thead>
          <tbody>
            ${s.transactionDetails.map((t: any) => {
              const te = t.errorRate !== undefined ? (typeof t.errorRate === "number" && t.errorRate <= 1 ? t.errorRate * 100 : t.errorRate) : 0;
              return `<tr>
                <td><strong>${esc(t.label || '-')}</strong></td>
                <td>${fmtNum(t.count)}</td>
                <td>${fmtNum(t.avg, 0)}</td>
                <td>${fmtNum(t.p90, 0)}</td>
                <td>${fmtNum(t.p95, 0)}</td>
                <td>${fmtNum(t.throughput, 2)}</td>
                <td class="${(t.errorCount || 0) > 0 ? 'delta-bad' : ''}">${fmtNum(t.errorCount)}</td>
                <td class="${te > 0 ? 'delta-bad' : 'delta-good'}">${te.toFixed(1)}%</td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>`;
  }).join('');

  const customSectionsHtml = customSections.map((cs: any) => `
    <div class="section">
      <h2>${esc(cs.title)}</h2>
      <div style="white-space:pre-wrap;font-size:13px;color:#374151;">${esc(cs.content)}</div>
    </div>`).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Report Preview - ${esc(report.title)}</title>
<style>
  :root { --brand: #4338ca; --brand-dark: #312e81; --brand-light: #eef2ff; --success: #059669; --danger: #dc2626; --warning: #d97706; --text: #111827; --text-sec: #374151; --text-muted: #6b7280; --surface: #f9fafb; --border: #e5e7eb; }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Segoe UI', system-ui, sans-serif; background: #fff; color: var(--text); line-height: 1.5; padding: 24px; max-width: 900px; margin: 0 auto; }
  h1 { font-size: 28px; color: var(--brand-dark); margin-bottom: 4px; }
  h2 { font-size: 18px; color: var(--brand-dark); border-bottom: 2px solid var(--brand); padding-bottom: 6px; margin: 24px 0 12px 0; }
  h3 { font-size: 15px; color: var(--brand-dark); margin: 12px 0 8px 0; }
  .section { margin-bottom: 24px; }
  .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin: 12px 0; }
  .kpi-card { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 12px; text-align: center; }
  .kpi-value { font-size: 22px; font-weight: 700; color: var(--brand); }
  .kpi-label { font-size: 11px; color: var(--text-muted); margin-top: 2px; }
  .data-table { width: 100%; border-collapse: collapse; font-size: 12px; margin: 8px 0; }
  .data-table th { background: var(--brand); color: #fff; padding: 6px 10px; text-align: left; font-size: 11px; font-weight: 600; }
  .data-table td { padding: 5px 10px; border-bottom: 1px solid var(--border); }
  .data-table tr:nth-child(even) { background: var(--surface); }
  .verdict-banner { text-align: center; padding: 12px; border-radius: 8px; color: #fff; font-weight: 700; font-size: 16px; margin: 12px 0; }
  .delta-good { color: var(--success); font-weight: 600; }
  .delta-bad { color: var(--danger); font-weight: 600; }
  .delta-warn { color: var(--warning); font-weight: 600; }
  .delta-neutral { color: var(--text-muted); }
  .meta-table { width: auto; border-collapse: collapse; margin: 12px auto; }
  .meta-table td { padding: 4px 16px; font-size: 13px; }
  .meta-table td:first-child { font-weight: 600; color: var(--text-muted); }
  .footer { text-align: center; font-size: 11px; color: var(--text-muted); border-top: 1px solid var(--border); padding-top: 12px; margin-top: 32px; }
</style>
</head>
<body>

<div style="text-align:center;margin-bottom:24px;">
  <div style="font-size:12px;color:var(--brand);font-weight:700;letter-spacing:2px;margin-bottom:4px;">PERFHUB</div>
  <h1>${esc(report.title || 'Sign-Off Report')}</h1>
  ${(report.projectName || report.featureName) ? `<div style="color:var(--text-muted);font-size:14px;">${esc([report.projectName, report.featureName].filter(Boolean).join(' — '))}</div>` : ''}
  <table class="meta-table" style="margin-top:12px;">
    <tr><td>Report ID</td><td>#${report.id}</td></tr>
    <tr><td>Status</td><td>${report.status === 'finalized' ? 'Finalized' : 'Draft'}</td></tr>
    <tr><td>Test Executions</td><td>${sections.length}</td></tr>
    <tr><td>Generated</td><td>${generatedAt}</td></tr>
  </table>
  <div class="verdict-banner" style="background:${vi.color};">Overall Verdict: ${vi.text}</div>
  ${report.verdictNotes ? `<div style="color:var(--text-muted);font-style:italic;font-size:13px;">${esc(report.verdictNotes)}</div>` : ''}
</div>

<div class="section">
  <h2>Key Performance Indicators</h2>
  <div class="kpi-grid">
    <div class="kpi-card"><div class="kpi-value">${fmtNum(totReqs)}</div><div class="kpi-label">Total Requests</div></div>
    <div class="kpi-card"><div class="kpi-value" style="color:${totFail > 0 ? 'var(--danger)' : 'var(--success)'}">${fmtNum(totFail)}</div><div class="kpi-label">Failed Requests</div></div>
    <div class="kpi-card"><div class="kpi-value" style="color:${successRate >= 99 ? 'var(--success)' : successRate >= 95 ? 'var(--warning)' : 'var(--danger)'}">${successRate.toFixed(1)}%</div><div class="kpi-label">Success Rate</div></div>
    <div class="kpi-card"><div class="kpi-value">${fmtNum(avgRT, 0)}ms</div><div class="kpi-label">Avg Response Time</div></div>
  </div>
  <div class="kpi-grid">
    <div class="kpi-card"><div class="kpi-value">${fmtNum(avgTPS, 1)}</div><div class="kpi-label">Throughput (rps)</div></div>
    <div class="kpi-card"><div class="kpi-value">${fmtNum(avgOf('p90'), 0)}ms</div><div class="kpi-label">P90</div></div>
    <div class="kpi-card"><div class="kpi-value">${fmtNum(avgOf('p95'), 0)}ms</div><div class="kpi-label">P95</div></div>
    <div class="kpi-card"><div class="kpi-value" style="color:${healthScore >= 80 ? 'var(--success)' : healthScore >= 50 ? 'var(--warning)' : 'var(--danger)'}">${healthScore}%</div><div class="kpi-label">Health Score</div></div>
  </div>
</div>

${(report.objective || report.scope || report.environmentNotes) ? `
<div class="section">
  <h2>Test Context &amp; Scope</h2>
  ${report.objective ? `<h3>Test Objective</h3><div style="white-space:pre-wrap;font-size:13px;color:var(--text-sec);margin-bottom:12px;">${esc(report.objective)}</div>` : ''}
  ${report.scope ? `<h3>Scope</h3><div style="white-space:pre-wrap;font-size:13px;color:var(--text-sec);margin-bottom:12px;">${esc(report.scope)}</div>` : ''}
  ${report.environmentNotes ? `<h3>Environment Notes</h3><div style="white-space:pre-wrap;font-size:13px;color:var(--text-sec);margin-bottom:12px;">${esc(report.environmentNotes)}</div>` : ''}
</div>` : ''}

${customSectionsHtml}

${txnDetailsHtml ? `<div class="section"><h2>Transaction Details</h2>${txnDetailsHtml}</div>` : ''}

${comparisonHtml}

${sla && sla.violations?.length > 0 ? `
<div class="section">
  <h2>SLA Violations</h2>
  <table class="data-table">
    <thead><tr><th>Metric</th><th>Test Type</th><th>Threshold</th><th>Actual</th><th>Status</th></tr></thead>
    <tbody>
      ${sla.violations.map((v: any) => `
        <tr>
          <td><strong>${esc(v.label ? `${v.metric} (${v.label})` : v.metric || '-')}</strong></td>
          <td>${esc(v.testType || '-')}</td>
          <td>${typeof v.threshold === 'number' ? fmtNum(v.threshold, 2) : v.threshold}</td>
          <td class="delta-bad"><strong>${typeof v.actual === 'number' ? fmtNum(v.actual, 2) : v.actual}</strong></td>
          <td class="delta-bad"><strong>FAIL</strong></td>
        </tr>`).join('')}
    </tbody>
  </table>
</div>` : ''}

${approvalsHtml}

${report.recommendations ? `
<div class="section">
  <h2>Recommendations</h2>
  <div style="white-space:pre-wrap;font-size:13px;color:var(--text-sec);">${esc(report.recommendations)}</div>
</div>` : ''}

<div class="footer">
  <strong>PerfHub</strong> | Performance Engineering Platform | Report #${report.id} | Generated ${generatedAt}
  <br><span style="font-size:10px;">This report is auto-generated. Data accuracy depends on test execution results at the time of snapshot.</span>
</div>

</body>
</html>`;
}
