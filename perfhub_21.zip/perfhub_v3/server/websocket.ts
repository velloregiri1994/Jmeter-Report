import { WebSocketServer, WebSocket } from "ws";
import type { Server } from "http";
import type { IncomingMessage } from "http";
import type { LiveMetricsSnapshot } from "./live-metrics/aggregator";
import cookie from "cookie";
import { logger } from "./logger";
import signature from "cookie-signature";
import { pool } from "./db";

let wss: WebSocketServer | null = null;
let heartbeatInterval: ReturnType<typeof setInterval> | null = null;

const HEARTBEAT_INTERVAL_MS = 30_000;

export interface ExecutionUpdate {
  type: "execution_update";
  executionId: number;
  status: string;
  resultSummary?: any;
}

export interface ScheduleUpdate {
  type: "schedule_update";
  scheduleId: number;
  status: string;
}

export interface LiveMetricsUpdate {
  type: "live_metrics_update";
  executionId: number;
  runId: string;
  snapshot: LiveMetricsSnapshot;
}

export type WsMessage = ExecutionUpdate | ScheduleUpdate | LiveMetricsUpdate;

async function authenticateWsConnection(req: IncomingMessage): Promise<boolean> {
  try {
    const cookies = cookie.parse(req.headers.cookie || "");
    const signedSid = cookies["connect.sid"];

    if (!signedSid) {
      return false;
    }

    const secret = process.env.SESSION_SECRET || 'perfhub-dev-only-not-for-production';

    if (!signedSid.startsWith("s:")) return false;
    const unsigned = signature.unsign(signedSid.slice(2), secret);
    if (unsigned === false) return false;

    const result = await pool.query(
      `SELECT sess FROM "session" WHERE sid = $1 AND expire > NOW()`,
      [unsigned]
    );

    if (result.rows.length === 0) return false;

    const sess = result.rows[0].sess;
    const sessionData = typeof sess === "string" ? JSON.parse(sess) : sess;
    return !!(sessionData?.user?.id);
  } catch (err) {
    logger.error(`Auth check failed: ${err}`, "websocket");
    return false;
  }
}

export function initWebSocket(server: Server): WebSocketServer {
  wss = new WebSocketServer({ server, path: "/ws" });

  wss.on("connection", async (ws: WebSocket & { isAlive?: boolean }, req) => {
    const hasCookie = !!(req.headers.cookie);
    const isAuthenticated = await authenticateWsConnection(req);
    if (!isAuthenticated) {
      console.log(`[websocket] Connection rejected (hasCookie=${hasCookie})`);
      ws.close(4401, "Authentication required");
      return;
    }

    ws.isAlive = true;

    ws.on("pong", () => {
      (ws as WebSocket & { isAlive?: boolean }).isAlive = true;
    });

    logger.info("Client connected", "websocket");

    ws.on("close", () => {
      logger.info("Client disconnected", "websocket");
    });

    ws.on("error", (err) => {
      logger.error(`Error: ${err.message}`, "websocket");
    });
  });

  heartbeatInterval = setInterval(() => {
    if (!wss) return;
    wss.clients.forEach((ws: WebSocket & { isAlive?: boolean }) => {
      if (ws.isAlive === false) {
        logger.warn("Terminating unresponsive client", "websocket");
        return ws.terminate();
      }
      ws.isAlive = false;
      ws.ping();
    });
  }, HEARTBEAT_INTERVAL_MS);

  wss.on("close", () => {
    if (heartbeatInterval) {
      clearInterval(heartbeatInterval);
      heartbeatInterval = null;
    }
  });

  logger.info("WebSocket server initialized on /ws", "websocket");
  return wss;
}

export function broadcast(message: WsMessage): void {
  if (!wss) {
    logger.warn("No WSS instance, cannot broadcast", "websocket");
    return;
  }

  const data = JSON.stringify(message);
  let sentCount = 0;
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
      sentCount++;
    }
  });
}

export function broadcastExecutionUpdate(
  executionId: number,
  status: string,
  resultSummary?: any
): void {
  broadcast({
    type: "execution_update",
    executionId,
    status,
    resultSummary,
  });
}

export function broadcastScheduleUpdate(
  scheduleId: number,
  status: string
): void {
  broadcast({
    type: "schedule_update",
    scheduleId,
    status,
  });
}

export function broadcastLiveMetrics(
  executionId: number,
  runId: string,
  snapshot: LiveMetricsSnapshot
): void {
  broadcast({
    type: "live_metrics_update",
    executionId,
    runId,
    snapshot,
  });
}

export function getWss(): WebSocketServer | null {
  return wss;
}
