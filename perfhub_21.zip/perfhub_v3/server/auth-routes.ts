import { type Express } from "express";
import rateLimit from "express-rate-limit";
import { storage } from "./storage";
import { sanitizeUser, hashPassword, verifyPassword } from "./route-middleware";
import { validate, z } from "./validation";
import { logAudit } from "./audit-logger";
import { asyncHandler } from "./error-handler";

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  message: { message: "Too many attempts. Please try again after 15 minutes." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || req.socket.remoteAddress || 'unknown',
});

const signupLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: { message: "Too many signup attempts. Please try again after 1 hour." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || req.socket.remoteAddress || 'unknown',
});

const passwordResetLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { message: "Too many password reset attempts. Please try again after 15 minutes." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || req.socket.remoteAddress || 'unknown',
});

export function registerAuthRoutes(app: Express): void {

  app.get("/api/auth/session", (req, res) => {
    if (req.session && (req.session as any).user) {
      const user = (req.session as any).user;
      res.json({ user: sanitizeUser(user), isAuthenticated: true });
    } else {
      res.json({ user: null, isAuthenticated: false });
    }
  });

  app.post("/api/auth/login", authLimiter, validate({
    body: z.object({
      username: z.string().min(1, "Username is required"),
      password: z.string().min(1, "Password is required"),
    }),
  }), asyncHandler(async (req, res) => {
    const { username, password } = req.body;

    const user = await storage.getUserByUsername(username);
    if (!user) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    const passwordValid = await verifyPassword(password, user.password);
    if (!passwordValid) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    if (!user.isApproved) {
      return res.status(403).json({ message: "Your account is pending approval. Please wait for an administrator to approve your access." });
    }

    const { password: _pw, ...sessionUser } = user;
    (req.session as any).user = sessionUser;
    
    req.session.save((err) => {
      if (err) {
        console.error('Session save error:', err);
        return res.status(500).json({ message: "Failed to create session" });
      }
      logAudit(req, "login", "auth", user.id);
      res.json({ user: sanitizeUser(user), message: "Login successful" });
    });
  }));

  app.post("/api/auth/signup", signupLimiter, validate({
    body: z.object({
      username: z.string().min(3, "Username must be at least 3 characters"),
      password: z.string()
        .min(8, "Password must be at least 8 characters")
        .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
        .regex(/[a-z]/, "Password must contain at least one lowercase letter")
        .regex(/[0-9]/, "Password must contain at least one number")
        .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
      email: z.string().email().optional().nullable(),
    }),
  }), asyncHandler(async (req, res) => {
    const { username, email, password } = req.body;

    const existingUser = await storage.getUserByUsername(username);
    if (existingUser) {
      return res.status(409).json({ message: "Username already exists" });
    }

    const normalizedEmail = email ? email.trim().toLowerCase() : null;

    if (normalizedEmail) {
      const existingEmail = await storage.getUserByEmail(normalizedEmail);
      if (existingEmail) {
        return res.status(409).json({ message: "An account with this email already exists" });
      }
    }

    const hashedPassword = await hashPassword(password);
    
    const { user: newUser, isFirstUser } = await storage.createUserWithFirstAdminCheck({
      username,
      email: normalizedEmail,
      password: hashedPassword,
      role: "engineer",
      isApproved: false
    });

    logAudit(req, "signup", "auth", newUser.id);
    if (isFirstUser) {
      res.status(201).json({ 
        message: "Account created successfully. You are the first user and have been granted admin access.",
        user: sanitizeUser(newUser)
      });
    } else {
      const { sendNewUserSignupNotification } = await import("./email/email-service");
      const appBaseUrl = process.env.APP_BASE_URL
        || (process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : null)
        || `http://localhost:${process.env.PORT || 5000}`;
      sendNewUserSignupNotification({
        newUsername: username,
        newEmail: email || null,
        appBaseUrl,
      });
      res.status(201).json({ 
        message: "Account created successfully. Please wait for an administrator to approve your access.",
        user: sanitizeUser(newUser)
      });
    }
  }));

  app.post("/api/auth/logout", (req, res) => {
    const userId = (req.session as any)?.user?.id;
    logAudit(req, "logout", "auth", userId);
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.post("/api/auth/forgot-password", passwordResetLimiter, validate({
    body: z.object({
      identifier: z.string().min(1, "Username or email is required"),
    }),
  }), asyncHandler(async (req, res) => {
    const { identifier } = req.body;

    const user = await storage.getUserByUsernameOrEmail(identifier);
    if (!user) {
      return res.json({ message: "If an account with that username or email exists, password reset instructions have been sent." });
    }

    const crypto = await import("crypto");
    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

    await storage.createPasswordResetToken(user.id, token, expiresAt);

    res.json({
      message: "If an account with that username or email exists, password reset instructions have been sent.",
      resetToken: process.env.NODE_ENV !== 'production' ? token : undefined,
    });
  }));

  app.post("/api/auth/reset-password", passwordResetLimiter, validate({
    body: z.object({
      token: z.string().min(1, "Token is required"),
      newPassword: z.string()
        .min(8, "Password must be at least 8 characters")
        .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
        .regex(/[a-z]/, "Password must contain at least one lowercase letter")
        .regex(/[0-9]/, "Password must contain at least one number")
        .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
    }),
  }), asyncHandler(async (req, res) => {
    const { token, newPassword } = req.body;

    const resetToken = await storage.getPasswordResetToken(token);
    if (!resetToken) {
      return res.status(400).json({ message: "Invalid or expired reset token" });
    }

    if (resetToken.used) {
      return res.status(400).json({ message: "This reset token has already been used" });
    }

    if (new Date() > resetToken.expiresAt) {
      return res.status(400).json({ message: "This reset token has expired" });
    }

    const hashedPassword = await hashPassword(newPassword);
    await storage.updateUserPassword(resetToken.userId, hashedPassword);
    await storage.markPasswordResetTokenUsed(token);

    res.json({ message: "Password has been reset successfully. You can now log in with your new password." });
  }));
}
