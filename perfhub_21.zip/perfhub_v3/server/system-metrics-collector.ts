import os from "os";
import fs from "fs";
import path from "path";
import { log } from "./index";

interface SystemMetricsSample {
  ts: number;
  cpuPercent: number;
  memUsedMb: number;
  memTotalMb: number;
  memPercent: number;
  diskReadMbps: number;
  diskWriteMbps: number;
  jmeterCpuPercent: number | null;
  jmeterMemMb: number | null;
}

interface SystemMetricsSummary {
  avgCpu: number;
  maxCpu: number;
  avgMemPercent: number;
  maxMemPercent: number;
  maxMemMb: number;
  peakJmeterMemMb: number | null;
  peakJmeterCpu: number | null;
  peakDiskReadMbps: number;
  peakDiskWriteMbps: number;
  sampleCount: number;
  durationSeconds: number;
}

interface CollectorState {
  intervalId: ReturnType<typeof setInterval>;
  filePath: string;
  pid: number | null;
  previousCpuTimes: { idle: number; total: number } | null;
  previousDiskStats: { readBytes: number; writeBytes: number; ts: number } | null;
  previousProcessCpu: { ticks: number; ts: number } | null;
  sampleCount: number;
  startTime: number;
}

const activeCollectors = new Map<number, CollectorState>();
const latestSamples = new Map<number, SystemMetricsSample>();
const sampleHistories = new Map<number, SystemMetricsSample[]>();
const MAX_HISTORY_SAMPLES = 120;

const SAMPLE_INTERVAL_MS = 5000;

function getCpuTimes(): { idle: number; total: number } {
  const cpus = os.cpus();
  let idle = 0;
  let total = 0;
  for (const cpu of cpus) {
    idle += cpu.times.idle;
    total += cpu.times.user + cpu.times.nice + cpu.times.sys + cpu.times.idle + cpu.times.irq;
  }
  return { idle, total };
}

function getCpuPercent(prev: { idle: number; total: number }): { percent: number; current: { idle: number; total: number } } {
  const current = getCpuTimes();
  const idleDiff = current.idle - prev.idle;
  const totalDiff = current.total - prev.total;
  const percent = totalDiff > 0 ? Math.round(((totalDiff - idleDiff) / totalDiff) * 10000) / 100 : 0;
  return { percent, current };
}

function getMemoryUsage(): { usedMb: number; totalMb: number; percent: number } {
  const totalMb = Math.round(os.totalmem() / (1024 * 1024));
  const freeMb = Math.round(os.freemem() / (1024 * 1024));
  const usedMb = totalMb - freeMb;
  const percent = Math.round((usedMb / totalMb) * 10000) / 100;
  return { usedMb, totalMb, percent };
}

function getDiskStats(): { readBytes: number; writeBytes: number } | null {
  try {
    if (!fs.existsSync("/proc/diskstats")) return null;
    const content = fs.readFileSync("/proc/diskstats", "utf-8");
    let totalReadSectors = 0;
    let totalWriteSectors = 0;
    for (const line of content.trim().split("\n")) {
      const parts = line.trim().split(/\s+/);
      if (parts.length < 14) continue;
      const devName = parts[2];
      if (devName.match(/^(sd[a-z]|nvme\d+n\d+|vd[a-z]|xvd[a-z])$/)) {
        totalReadSectors += parseInt(parts[5]) || 0;
        totalWriteSectors += parseInt(parts[9]) || 0;
      }
    }
    return { readBytes: totalReadSectors * 512, writeBytes: totalWriteSectors * 512 };
  } catch {
    return null;
  }
}

function getProcessCpuTicks(pid: number): number | null {
  try {
    const readTicks = (p: number): number => {
      const stat = fs.readFileSync(`/proc/${p}/stat`, "utf-8");
      const afterComm = stat.split(") ");
      if (afterComm.length < 2) return 0;
      const fields = afterComm[1].split(" ");
      const utime = parseInt(fields[11]) || 0;
      const stime = parseInt(fields[12]) || 0;
      return utime + stime;
    };

    let totalTicks = readTicks(pid);

    try {
      const childrenFile = `/proc/${pid}/task/${pid}/children`;
      if (fs.existsSync(childrenFile)) {
        const childPids = fs.readFileSync(childrenFile, "utf-8").trim().split(/\s+/).filter(Boolean);
        for (const cp of childPids) {
          try { totalTicks += readTicks(parseInt(cp)); } catch { /* skip */ }
        }
      }
    } catch { /* skip */ }

    return totalTicks;
  } catch {
    return null;
  }
}

function getProcessMemMb(pid: number): number | null {
  try {
    if (!fs.existsSync(`/proc/${pid}/stat`)) return null;

    const statContent = fs.readFileSync(`/proc/${pid}/stat`, "utf-8");
    const statParts = statContent.split(") ");
    if (statParts.length < 2) return null;
    const fields = statParts[1].split(" ");
    const rss = parseInt(fields[21]) || 0;
    const pageSize = 4096;
    const memMb = (rss * pageSize) / (1024 * 1024);

    let totalChildMem = 0;
    try {
      const childrenFile = `/proc/${pid}/task/${pid}/children`;
      if (fs.existsSync(childrenFile)) {
        const childPids = fs.readFileSync(childrenFile, "utf-8").trim().split(/\s+/).filter(Boolean);
        for (const cp of childPids) {
          try {
            const childStat = fs.readFileSync(`/proc/${cp}/stat`, "utf-8");
            const childParts = childStat.split(") ");
            if (childParts.length >= 2) {
              const childFields = childParts[1].split(" ");
              const childRss = parseInt(childFields[21]) || 0;
              totalChildMem += (childRss * pageSize) / (1024 * 1024);
            }
          } catch { /* skip */ }
        }
      }
    } catch { /* skip */ }

    return Math.round((memMb + totalChildMem) * 100) / 100;
  } catch {
    return null;
  }
}

function findJmeterPid(): number | null {
  try {
    if (!fs.existsSync("/proc")) return null;
    const entries = fs.readdirSync("/proc").filter(e => /^\d+$/.test(e));
    for (const entry of entries) {
      try {
        const cmdline = fs.readFileSync(`/proc/${entry}/cmdline`, "utf-8");
        if (cmdline.includes("jmeter") || cmdline.includes("JMeter") || cmdline.includes("ApacheJMeter")) {
          return parseInt(entry);
        }
      } catch { /* skip */ }
    }
  } catch { /* skip */ }
  return null;
}

function collectSample(state: CollectorState): SystemMetricsSample | null {
  try {
    const now = Date.now();

    let cpuPercent = 0;
    if (state.previousCpuTimes) {
      const result = getCpuPercent(state.previousCpuTimes);
      cpuPercent = result.percent;
      state.previousCpuTimes = result.current;
    } else {
      state.previousCpuTimes = getCpuTimes();
    }

    const mem = getMemoryUsage();

    let diskReadMbps = 0;
    let diskWriteMbps = 0;
    const diskStats = getDiskStats();
    if (diskStats && state.previousDiskStats) {
      const elapsed = (now - state.previousDiskStats.ts) / 1000;
      if (elapsed > 0) {
        diskReadMbps = Math.round(((diskStats.readBytes - state.previousDiskStats.readBytes) / (1024 * 1024) / elapsed) * 100) / 100;
        diskWriteMbps = Math.round(((diskStats.writeBytes - state.previousDiskStats.writeBytes) / (1024 * 1024) / elapsed) * 100) / 100;
      }
    }
    if (diskStats) {
      state.previousDiskStats = { ...diskStats, ts: now };
    }

    let jmeterCpuPercent: number | null = null;
    let jmeterMemMb: number | null = null;
    if (state.pid) {
      jmeterMemMb = getProcessMemMb(state.pid);

      const currentTicks = getProcessCpuTicks(state.pid);
      if (currentTicks !== null && state.previousProcessCpu) {
        const tickDelta = currentTicks - state.previousProcessCpu.ticks;
        const timeDeltaSec = (now - state.previousProcessCpu.ts) / 1000;
        if (timeDeltaSec > 0) {
          const clockTicksPerSec = 100;
          const numCpus = os.cpus().length;
          jmeterCpuPercent = Math.round((tickDelta / (timeDeltaSec * clockTicksPerSec * numCpus)) * 100 * 100) / 100;
          jmeterCpuPercent = Math.min(jmeterCpuPercent, 100);
        }
      }
      if (currentTicks !== null) {
        state.previousProcessCpu = { ticks: currentTicks, ts: now };
      }
    }

    return {
      ts: now,
      cpuPercent,
      memUsedMb: mem.usedMb,
      memTotalMb: mem.totalMb,
      memPercent: mem.percent,
      diskReadMbps: Math.max(0, diskReadMbps),
      diskWriteMbps: Math.max(0, diskWriteMbps),
      jmeterCpuPercent,
      jmeterMemMb,
    };
  } catch (err) {
    log(`System metrics sample error: ${err}`, "sys-metrics");
    return null;
  }
}

function appendSample(filePath: string, sample: SystemMetricsSample): void {
  try {
    const line = JSON.stringify(sample) + "\n";
    fs.appendFileSync(filePath, line, "utf-8");
  } catch (err) {
    log(`Failed to write system metrics sample: ${err}`, "sys-metrics");
  }
}

export function startSystemMetrics(executionId: number, runDir: string, jmeterPid?: number): void {
  if (activeCollectors.has(executionId)) {
    log(`System metrics already active for execution ${executionId}`, "sys-metrics");
    return;
  }

  const filePath = path.join(runDir, "system-metrics.jsonl");
  const startTime = Date.now();

  const state: CollectorState = {
    intervalId: null as any,
    filePath,
    pid: jmeterPid ?? null,
    previousCpuTimes: getCpuTimes(),
    previousDiskStats: getDiskStats() ? { ...getDiskStats()!, ts: startTime } : null,
    previousProcessCpu: jmeterPid ? (() => { const t = getProcessCpuTicks(jmeterPid); return t !== null ? { ticks: t, ts: startTime } : null; })() : null,
    sampleCount: 0,
    startTime,
  };

  sampleHistories.set(executionId, []);

  state.intervalId = setInterval(() => {
    const sample = collectSample(state);
    if (sample) {
      appendSample(filePath, sample);
      state.sampleCount++;
      latestSamples.set(executionId, sample);
      const history = sampleHistories.get(executionId);
      if (history) {
        history.push(sample);
        while (history.length > MAX_HISTORY_SAMPLES) {
          history.shift();
        }
      }
    }
  }, SAMPLE_INTERVAL_MS);

  activeCollectors.set(executionId, state);
  log(`System metrics collector started for execution ${executionId} -> ${filePath}`, "sys-metrics");
}

export function stopSystemMetrics(executionId: number): SystemMetricsSummary | null {
  const state = activeCollectors.get(executionId);
  if (!state) return null;

  clearInterval(state.intervalId);
  activeCollectors.delete(executionId);
  latestSamples.delete(executionId);
  sampleHistories.delete(executionId);

  const endTime = Date.now();
  const durationSeconds = Math.round((endTime - state.startTime) / 1000);

  log(`System metrics collector stopped for execution ${executionId} (${state.sampleCount} samples, ${durationSeconds}s)`, "sys-metrics");

  try {
    return computeSummary(state.filePath, durationSeconds);
  } catch (err) {
    log(`Failed to compute system metrics summary: ${err}`, "sys-metrics");
    return null;
  }
}

function computeSummary(filePath: string, durationSeconds: number): SystemMetricsSummary | null {
  if (!fs.existsSync(filePath)) return null;

  const content = fs.readFileSync(filePath, "utf-8").trim();
  if (!content) return null;

  const lines = content.split("\n");
  let totalCpu = 0;
  let maxCpu = 0;
  let totalMemPercent = 0;
  let maxMemPercent = 0;
  let maxMemMb = 0;
  let peakJmeterMem: number | null = null;
  let peakJmeterCpu: number | null = null;
  let peakDiskRead = 0;
  let peakDiskWrite = 0;
  let count = 0;

  for (const line of lines) {
    try {
      const sample: SystemMetricsSample = JSON.parse(line);
      totalCpu += sample.cpuPercent;
      maxCpu = Math.max(maxCpu, sample.cpuPercent);
      totalMemPercent += sample.memPercent;
      maxMemPercent = Math.max(maxMemPercent, sample.memPercent);
      maxMemMb = Math.max(maxMemMb, sample.memUsedMb);
      peakDiskRead = Math.max(peakDiskRead, sample.diskReadMbps);
      peakDiskWrite = Math.max(peakDiskWrite, sample.diskWriteMbps);
      if (sample.jmeterMemMb !== null) {
        peakJmeterMem = Math.max(peakJmeterMem ?? 0, sample.jmeterMemMb);
      }
      if (sample.jmeterCpuPercent !== null) {
        peakJmeterCpu = Math.max(peakJmeterCpu ?? 0, sample.jmeterCpuPercent);
      }
      count++;
    } catch { /* skip malformed lines */ }
  }

  if (count === 0) return null;

  return {
    avgCpu: Math.round((totalCpu / count) * 100) / 100,
    maxCpu: Math.round(maxCpu * 100) / 100,
    avgMemPercent: Math.round((totalMemPercent / count) * 100) / 100,
    maxMemPercent: Math.round(maxMemPercent * 100) / 100,
    maxMemMb,
    peakJmeterMemMb: peakJmeterMem !== null ? Math.round(peakJmeterMem * 100) / 100 : null,
    peakJmeterCpu: peakJmeterCpu !== null ? Math.round(peakJmeterCpu * 100) / 100 : null,
    peakDiskReadMbps: Math.round(peakDiskRead * 100) / 100,
    peakDiskWriteMbps: Math.round(peakDiskWrite * 100) / 100,
    sampleCount: count,
    durationSeconds,
  };
}

export function readSystemMetricsTimeseries(runDir: string): SystemMetricsSample[] {
  const filePath = path.join(runDir, "system-metrics.jsonl");
  if (!fs.existsSync(filePath)) return [];

  try {
    const content = fs.readFileSync(filePath, "utf-8").trim();
    if (!content) return [];

    const samples: SystemMetricsSample[] = [];
    for (const line of content.split("\n")) {
      try {
        samples.push(JSON.parse(line));
      } catch { /* skip */ }
    }
    return samples;
  } catch {
    return [];
  }
}

export interface LiveSystemMetrics {
  latest: SystemMetricsSample | null;
  history: SystemMetricsSample[];
}

export function getLiveSystemMetrics(executionId: number): LiveSystemMetrics {
  return {
    latest: latestSamples.get(executionId) ?? null,
    history: sampleHistories.get(executionId) ?? [],
  };
}

export function readSystemMetricsSummary(runDir: string): SystemMetricsSummary | null {
  const filePath = path.join(runDir, "system-metrics.jsonl");
  if (!fs.existsSync(filePath)) return null;
  try {
    const stat = fs.statSync(filePath);
    if (stat.size === 0) return null;
    return computeSummary(filePath, 0);
  } catch {
    return null;
  }
}
