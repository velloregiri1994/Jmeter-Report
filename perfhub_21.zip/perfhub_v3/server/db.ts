import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import fs from "fs";
import path from "path";
import * as schema from "@shared/schema";

const { Pool } = pg;

// Load database URL from config.json or environment variable
function getDatabaseUrl(): string {
  // 1. Check config.json first
  try {
    const configPath = path.join(process.cwd(), "config.json");
    if (fs.existsSync(configPath)) {
      const content = fs.readFileSync(configPath, "utf-8");
      const config = JSON.parse(content);
      if (config.database?.url && config.database.url.trim()) {
        return config.database.url.trim();
      }
    }
  } catch (err) {
    // Config file not found or invalid, continue to env var
  }
  
  // 2. Check environment variable
  if (process.env.DATABASE_URL) {
    return process.env.DATABASE_URL;
  }
  
  throw new Error(
    "DATABASE_URL must be set in config.json or as an environment variable.",
  );
}

const databaseUrl = getDatabaseUrl();

// Configure connection pool for optimal performance and stability
const poolConfig = {
  connectionString: databaseUrl,
  // Pool size configuration
  max: parseInt(process.env.DB_POOL_MAX || "20", 10), // Maximum connections
  min: parseInt(process.env.DB_POOL_MIN || "2", 10), // Minimum connections
  // Timeout configuration
  idleTimeoutMillis: parseInt(process.env.DB_IDLE_TIMEOUT || "30000", 10), // 30 seconds
  connectionTimeoutMillis: parseInt(process.env.DB_CONNECTION_TIMEOUT || "2000", 10), // 2 seconds
  // Validation query to ensure connections are still alive
  validationQuery: "SELECT 1",
  allowExitOnIdle: true,
};

export const pool = new Pool(poolConfig);

// Handle pool errors
pool.on('error', (err) => {
  console.error('[Database Pool Error]', err);
});

// Log pool size information on startup
pool.on('connect', () => {
  if (pool.totalCount === 1) {
    console.log(`[Database] Connection pool initialized with max ${poolConfig.max} connections`);
  }
});

export const db = drizzle(pool, { schema });
