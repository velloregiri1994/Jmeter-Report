import { Router, type Request, type Response } from "express";
import { db } from "./db";
import { reportTemplates } from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { requireAuth, requireNonViewer } from "./route-middleware";
import { asyncHandler } from "./error-handler";
import { z } from "zod";

const sectionSchema = z.object({
  id: z.string(),
  type: z.enum(["builtin", "custom"]),
  key: z.string().optional(),
  title: z.string().min(1),
  defaultContent: z.string().optional(),
  enabled: z.boolean(),
});

const createTemplateSchema = z.object({
  name: z.string().min(1).max(200),
  description: z.string().max(1000).optional(),
  sections: z.array(sectionSchema).min(1),
  isDefault: z.boolean().optional(),
});

const updateTemplateSchema = z.object({
  name: z.string().min(1).max(200).optional(),
  description: z.string().max(1000).optional().nullable(),
  sections: z.array(sectionSchema).min(1).optional(),
  isDefault: z.boolean().optional(),
});

export function registerReportTemplateRoutes(app: Router) {
  app.get("/api/report-templates", requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const templates = await db.select().from(reportTemplates).orderBy(desc(reportTemplates.createdAt));
    res.json(templates);
  }));

  app.get("/api/report-templates/:id", requireAuth, asyncHandler(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid template ID" });

    const [template] = await db.select().from(reportTemplates).where(eq(reportTemplates.id, id));
    if (!template) return res.status(404).json({ message: "Template not found" });

    res.json(template);
  }));

  app.post("/api/report-templates", requireNonViewer, asyncHandler(async (req: Request, res: Response) => {
    const userId = (req.session as any).user?.id;
    const parsed = createTemplateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Invalid template data", errors: parsed.error.flatten() });

    const { name, description, sections, isDefault } = parsed.data;

    if (isDefault) {
      await db.update(reportTemplates).set({ isDefault: false }).where(eq(reportTemplates.isDefault, true));
    }

    const [template] = await db.insert(reportTemplates).values({
      name,
      description: description || null,
      sections,
      isDefault: isDefault || false,
      createdBy: userId,
    }).returning();

    res.status(201).json(template);
  }));

  app.patch("/api/report-templates/:id", requireNonViewer, asyncHandler(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid template ID" });

    const userId = (req.session as any).user?.id;
    const [existing] = await db.select().from(reportTemplates).where(eq(reportTemplates.id, id));
    if (!existing) return res.status(404).json({ message: "Template not found" });

    const parsed = updateTemplateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Invalid template data", errors: parsed.error.flatten() });

    const updates: any = { updatedAt: new Date().toISOString() };
    if (parsed.data.name !== undefined) updates.name = parsed.data.name;
    if (parsed.data.description !== undefined) updates.description = parsed.data.description;
    if (parsed.data.sections !== undefined) updates.sections = parsed.data.sections;
    if (parsed.data.isDefault !== undefined) {
      if (parsed.data.isDefault) {
        await db.update(reportTemplates).set({ isDefault: false }).where(eq(reportTemplates.isDefault, true));
      }
      updates.isDefault = parsed.data.isDefault;
    }

    const [updated] = await db.update(reportTemplates).set(updates).where(eq(reportTemplates.id, id)).returning();
    res.json(updated);
  }));

  app.delete("/api/report-templates/:id", requireNonViewer, asyncHandler(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid template ID" });

    const [existing] = await db.select().from(reportTemplates).where(eq(reportTemplates.id, id));
    if (!existing) return res.status(404).json({ message: "Template not found" });

    await db.delete(reportTemplates).where(eq(reportTemplates.id, id));
    res.json({ message: "Template deleted" });
  }));

  app.post("/api/report-templates/:id/duplicate", requireNonViewer, asyncHandler(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid template ID" });

    const userId = (req.session as any).user?.id;
    const [original] = await db.select().from(reportTemplates).where(eq(reportTemplates.id, id));
    if (!original) return res.status(404).json({ message: "Template not found" });

    const [duplicate] = await db.insert(reportTemplates).values({
      name: `${original.name} (Copy)`,
      description: original.description,
      sections: original.sections,
      isDefault: false,
      createdBy: userId,
    }).returning();

    res.status(201).json(duplicate);
  }));

  app.patch("/api/report-templates/:id/default", requireNonViewer, asyncHandler(async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid template ID" });

    const [existing] = await db.select().from(reportTemplates).where(eq(reportTemplates.id, id));
    if (!existing) return res.status(404).json({ message: "Template not found" });

    await db.update(reportTemplates).set({ isDefault: false }).where(eq(reportTemplates.isDefault, true));
    const [updated] = await db.update(reportTemplates).set({ isDefault: true, updatedAt: new Date().toISOString() }).where(eq(reportTemplates.id, id)).returning();

    res.json(updated);
  }));
}
