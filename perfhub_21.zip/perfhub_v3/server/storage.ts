import { db } from "./db";
import {
  users, scripts, testSchedules, testExecutions, comments,
  tags, scriptTags, favorites, testTemplates, baselineExecutions, folders,
  notifications, notificationPreferences, testCheckpoints, dataRetentionSettings, customEnvironments,
  auditLogs, slaRules, executionSlaRules, executionMetricBuckets, projects, testTypes, testTracker, passwordResetTokens,
  regressionThresholds, savedFilterViews, autoAbortRules, executionAutoAbortRules,
  executionWorkloadTargets,
  type InsertUser, type InsertScript,
  type InsertTestSchedule, type InsertTestExecution, type InsertComment,
  type InsertTag, type InsertFavorite, type InsertTestTemplate, type InsertBaselineExecution,
  type InsertFolder, type InsertNotification, type InsertTestCheckpoint,
  type InsertCustomEnvironment, type InsertAuditLog, type InsertSlaRule,
  type InsertExecutionSlaRule, type ExecutionSlaRule,
  type InsertRegressionThreshold, type RegressionThreshold,
  type InsertAutoAbortRule, type AutoAbortRule,
  type InsertExecutionAutoAbortRule, type ExecutionAutoAbortRule,
  type ExecutionWorkloadTarget, type InsertExecutionWorkloadTarget,
  type NotificationPreferences,
  type User, type Script, type TestSchedule, type TestExecution, type Comment,
  type Tag, type Favorite, type TestTemplate, type BaselineExecution, type Notification,
  type Folder, type TestCheckpoint, type DataRetentionSetting,
  type CustomEnvironment, type AuditLog, type SlaRule,
  type ScheduleWithDetails, type ExecutionWithDetails, type DashboardStats
} from "@shared/schema";

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;
export type TestType = typeof testTypes.$inferSelect;
export type InsertTestType = typeof testTypes.$inferInsert;
export type TestTrackerRecord = typeof testTracker.$inferSelect;
export type InsertTestTracker = typeof testTracker.$inferInsert;
export type SavedFilterView = typeof savedFilterViews.$inferSelect;
export type InsertSavedFilterView = typeof savedFilterViews.$inferInsert;
import { eq, desc, sql, and, inArray, isNull, isNotNull, lte, gte, gt, asc, ilike } from "drizzle-orm";

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  getAdminUsers(): Promise<User[]>;
  getPendingUsers(): Promise<User[]>;
  getUserCount(): Promise<number>;
  createUser(user: InsertUser): Promise<User>;
  createUserWithFirstAdminCheck(user: InsertUser): Promise<{ user: User; isFirstUser: boolean }>;
  updateUser(id: number, updates: Partial<InsertUser & { isApproved: boolean }>): Promise<User>;
  deleteUser(id: number): Promise<void>;

  // Folders
  getFolders(): Promise<Folder[]>;
  getFolder(id: number): Promise<Folder | undefined>;
  createFolder(folder: InsertFolder): Promise<Folder>;
  updateFolder(id: number, updates: Partial<InsertFolder>): Promise<Folder>;
  deleteFolder(id: number): Promise<void>;

  // Scripts
  getScripts(): Promise<Script[]>;
  getScriptsPaginated(opts: { page?: number; pageSize?: number; search?: string; protocol?: string; folderId?: number | null }): Promise<PaginatedResult<Script>>;
  getScriptsByFolder(folderId: number | null): Promise<Script[]>;
  getScript(id: number): Promise<Script | undefined>;
  createScript(script: InsertScript): Promise<Script>;
  updateScript(id: number, updates: Partial<InsertScript>): Promise<Script>;
  deleteScript(id: number): Promise<void>;

  // Schedules
  getSchedules(): Promise<ScheduleWithDetails[]>;
  getSchedulesPaginated(opts: { page?: number; pageSize?: number }): Promise<PaginatedResult<ScheduleWithDetails>>;
  getSchedule(id: number): Promise<ScheduleWithDetails | undefined>;
  getPendingSchedulesToRun(): Promise<TestSchedule[]>;
  createSchedule(schedule: InsertTestSchedule): Promise<TestSchedule>;
  updateSchedule(id: number, updates: Partial<InsertTestSchedule>): Promise<TestSchedule>;

  // Executions
  getExecutions(limit?: number, status?: string, offset?: number): Promise<ExecutionWithDetails[]>;
  getExecutionCount(status?: string): Promise<number>;
  getExecution(id: number): Promise<ExecutionWithDetails | undefined>;
  getQueuedExecutions(): Promise<ExecutionWithDetails[]>;
  claimQueuedExecution(id: number): Promise<TestExecution | undefined>;
  createExecution(execution: InsertTestExecution): Promise<TestExecution>;
  updateExecution(id: number, updates: Partial<InsertTestExecution>): Promise<TestExecution>;
  cancelExecution(id: number): Promise<TestExecution | undefined>;
  hasActiveExecution(scheduleId: number): Promise<boolean>;
  atomicClaimSchedule(scheduleId: number, executionId: string): Promise<{ execution: TestExecution } | null>;
  
  // Comments
  createComment(comment: InsertComment): Promise<Comment>;
  getCommentsByExecutionId(executionId: number): Promise<Comment[]>;
  deleteComment(id: number): Promise<void>;
  
  // Dashboard
  getDashboardStats(): Promise<DashboardStats>;

  // Notifications
  getNotifications(userId: number): Promise<Notification[]>;
  getNotificationsPaginated(userId: number, opts: { page?: number; pageSize?: number; type?: string; read?: boolean }): Promise<PaginatedResult<Notification>>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number, userId: number): Promise<void>;
  markAllNotificationsAsRead(userId: number): Promise<void>;
  deleteNotification(id: number, userId: number): Promise<void>;
  clearAllNotifications(userId: number): Promise<void>;
  getUnreadNotificationCount(userId: number): Promise<number>;
  getNotificationPreferences(userId: number): Promise<NotificationPreferences | null>;
  upsertNotificationPreferences(userId: number, prefs: Partial<NotificationPreferences>): Promise<NotificationPreferences>;
  shouldSendNotification(userId: number, category: string): Promise<boolean>;

  // Audit Logs
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(userId?: number, resourceType?: string, limit?: number): Promise<AuditLog[]>;
  getAuditLogsForResource(resourceType: string, resourceId: string): Promise<AuditLog[]>;

  // Baselines
  getBaseline(scriptId: number): Promise<BaselineExecution | undefined>;
  getBaselineWithExecution(scriptId: number): Promise<{ baseline: BaselineExecution; execution: TestExecution } | undefined>;
  setBaseline(scriptId: number, executionId: number, userId: number, name?: string, notes?: string): Promise<BaselineExecution>;
  removeBaseline(scriptId: number): Promise<void>;
  getBaselineHistory(scriptId: number): Promise<BaselineExecution[]>;

  // Regression Thresholds
  getRegressionThresholds(scriptId: number): Promise<RegressionThreshold[]>;
  upsertRegressionThreshold(data: InsertRegressionThreshold): Promise<RegressionThreshold>;
  deleteRegressionThreshold(id: number): Promise<void>;
  getEnabledRegressionThresholds(scriptId: number): Promise<RegressionThreshold[]>;

  // SLA Rules
  getSlaRules(scriptId: number): Promise<SlaRule[]>;
  getSlaRule(id: number): Promise<SlaRule | undefined>;
  createSlaRule(rule: InsertSlaRule): Promise<SlaRule>;
  updateSlaRule(id: number, updates: Partial<InsertSlaRule>): Promise<SlaRule | undefined>;
  deleteSlaRule(id: number): Promise<void>;
  getEnabledSlaRules(scriptId: number): Promise<SlaRule[]>;

  // Execution SLA Rules
  getExecutionSlaRules(executionId: number): Promise<ExecutionSlaRule[]>;
  getEnabledExecutionSlaRules(executionId: number): Promise<ExecutionSlaRule[]>;
  createExecutionSlaRule(rule: InsertExecutionSlaRule): Promise<ExecutionSlaRule>;
  updateExecutionSlaRule(id: number, updates: Partial<InsertExecutionSlaRule>): Promise<ExecutionSlaRule | undefined>;
  deleteExecutionSlaRule(id: number): Promise<void>;

  // Trend Analysis helpers
  getExecutionsByScheduleId(scheduleId: number, limit?: number): Promise<TestExecution[]>;
  getExecutionsByScriptId(scriptId: number, limit?: number): Promise<TestExecution[]>;

  // Projects
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, updates: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<void>;

  // Test Types
  getTestTypes(): Promise<TestType[]>;
  getTestType(id: number): Promise<TestType | undefined>;
  createTestType(testType: InsertTestType): Promise<TestType>;
  updateTestType(id: number, updates: Partial<InsertTestType>): Promise<TestType | undefined>;
  deleteTestType(id: number): Promise<void>;

  // Test Tracker
  getTestTrackerRecords(filters?: { 
    projectId?: number;
    projectName?: string;
    testTypeId?: number; 
    environment?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
    releaseTag?: string;
  }): Promise<TestTrackerRecord[]>;
  getTestTrackerRecordsPaginated(filters: {
    projectId?: number;
    projectName?: string;
    testTypeId?: number;
    environment?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
    releaseTag?: string;
  }, opts: { page?: number; pageSize?: number; sortBy?: string; sortDir?: 'asc' | 'desc' }): Promise<PaginatedResult<TestTrackerRecord>>;
  createTestTrackerRecord(record: InsertTestTracker): Promise<TestTrackerRecord>;
  updateTestTrackerComment(id: number, comments: string): Promise<void>;

  getSavedFilterViews(userId: number, page: string): Promise<SavedFilterView[]>;
  createSavedFilterView(view: InsertSavedFilterView): Promise<SavedFilterView>;
  deleteSavedFilterView(id: number, userId: number): Promise<void>;
  updateSavedFilterViewDefault(id: number, userId: number, page: string, isDefault: boolean): Promise<void>;

  // Auto-Abort Rules
  getAutoAbortRules(scriptId: number): Promise<AutoAbortRule[]>;
  getEnabledAutoAbortRules(scriptId: number): Promise<AutoAbortRule[]>;
  createAutoAbortRule(rule: InsertAutoAbortRule): Promise<AutoAbortRule>;
  updateAutoAbortRule(id: number, updates: Partial<InsertAutoAbortRule>): Promise<AutoAbortRule | undefined>;
  deleteAutoAbortRule(id: number): Promise<void>;

  // Execution Auto-Abort Rules
  getExecutionAutoAbortRules(executionId: number): Promise<ExecutionAutoAbortRule[]>;
  getEnabledExecutionAutoAbortRules(executionId: number): Promise<ExecutionAutoAbortRule[]>;
  createExecutionAutoAbortRule(rule: InsertExecutionAutoAbortRule): Promise<ExecutionAutoAbortRule>;
  updateExecutionAutoAbortRule(id: number, updates: Partial<InsertExecutionAutoAbortRule>): Promise<ExecutionAutoAbortRule | undefined>;
  deleteExecutionAutoAbortRule(id: number): Promise<void>;

  // Execution Workload Targets
  getExecutionWorkloadTargets(executionId: number): Promise<ExecutionWorkloadTarget | undefined>;
  setExecutionWorkloadTargets(target: InsertExecutionWorkloadTarget): Promise<ExecutionWorkloadTarget>;
  deleteExecutionWorkloadTargets(executionId: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // ... existing methods ...

  async getNotifications(userId: number): Promise<Notification[]> {
    return await db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
      .limit(500);
  }

  async getNotificationsPaginated(userId: number, opts: { page?: number; pageSize?: number; type?: string; read?: boolean }): Promise<PaginatedResult<Notification>> {
    const page = opts.page || 1;
    const pageSize = Math.min(opts.pageSize || 50, 100);
    const offset = (page - 1) * pageSize;

    const conditions: any[] = [eq(notifications.userId, userId)];
    if (opts.type) {
      conditions.push(eq(notifications.type, opts.type));
    }
    if (opts.read !== undefined) {
      conditions.push(eq(notifications.read, opts.read));
    }

    const whereClause = and(...conditions);

    const [data, countResult] = await Promise.all([
      db.select().from(notifications).where(whereClause).orderBy(desc(notifications.createdAt)).limit(pageSize).offset(offset),
      db.select({ count: sql<number>`count(*)::int` }).from(notifications).where(whereClause),
    ]);

    return { data, total: countResult[0]?.count || 0, page, pageSize };
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotif] = await db.insert(notifications).values(notification).returning();
    return newNotif;
  }

  async markNotificationAsRead(id: number, userId: number): Promise<void> {
    await db.update(notifications).set({ read: true })
      .where(and(eq(notifications.id, id), eq(notifications.userId, userId)));
  }

  async markAllNotificationsAsRead(userId: number): Promise<void> {
    await db.update(notifications).set({ read: true })
      .where(and(eq(notifications.userId, userId), eq(notifications.read, false)));
  }

  async deleteNotification(id: number, userId: number): Promise<void> {
    await db.delete(notifications).where(and(eq(notifications.id, id), eq(notifications.userId, userId)));
  }

  async clearAllNotifications(userId: number): Promise<void> {
    await db.delete(notifications).where(eq(notifications.userId, userId));
  }

  async getUnreadNotificationCount(userId: number): Promise<number> {
    const [result] = await db.select({ count: sql<number>`count(*)` })
      .from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.read, false)));
    return Number(result.count || 0);
  }

  async getNotificationPreferences(userId: number): Promise<NotificationPreferences | null> {
    const [prefs] = await db.select().from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId));
    return prefs || null;
  }

  async upsertNotificationPreferences(userId: number, prefs: Partial<NotificationPreferences>): Promise<NotificationPreferences> {
    const existing = await this.getNotificationPreferences(userId);
    if (existing) {
      const [updated] = await db.update(notificationPreferences)
        .set({ ...prefs, updatedAt: new Date() })
        .where(eq(notificationPreferences.userId, userId))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(notificationPreferences)
        .values({ userId, ...prefs })
        .returning();
      return created;
    }
  }

  async shouldSendNotification(userId: number, category: string): Promise<boolean> {
    const prefs = await this.getNotificationPreferences(userId);
    if (!prefs) return true;

    const categoryMap: Record<string, keyof NotificationPreferences> = {
      'test_completed': 'testCompleted',
      'info': 'testCompleted',
      'test_failed': 'testFailed',
      'error': 'testFailed',
      'sla_violation': 'slaViolation',
      'regression': 'regressionDetected',
      'warning': 'regressionDetected',
      'approval': 'approvalRequested',
      'system': 'systemAlerts',
    };

    const prefKey = categoryMap[category];
    if (!prefKey) return true;
    return prefs[prefKey] as boolean;
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(sql`lower(${users.email}) = ${email.toLowerCase()}`);
    return user;
  }

  async getUserByUsernameOrEmail(identifier: string): Promise<User | undefined> {
    const [user] = await db.select().from(users)
      .where(sql`${users.username} = ${identifier} OR ${users.email} = ${identifier}`);
    return user;
  }

  async createPasswordResetToken(userId: number, token: string, expiresAt: Date): Promise<void> {
    await db.insert(passwordResetTokens).values({ userId, token, expiresAt });
  }

  async getPasswordResetToken(token: string): Promise<{ id: number; userId: number; token: string; expiresAt: Date; used: boolean } | undefined> {
    const [row] = await db.select().from(passwordResetTokens).where(eq(passwordResetTokens.token, token));
    return row ? { ...row, expiresAt: new Date(row.expiresAt) } : undefined;
  }

  async markPasswordResetTokenUsed(token: string): Promise<void> {
    await db.update(passwordResetTokens).set({ used: true }).where(eq(passwordResetTokens.token, token));
  }

  async updateUserPassword(userId: number, hashedPassword: string): Promise<void> {
    await db.update(users).set({ password: hashedPassword }).where(eq(users.id, userId));
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async createUserWithFirstAdminCheck(user: InsertUser): Promise<{ user: User; isFirstUser: boolean }> {
    // Use a transaction with serializable isolation to prevent race conditions
    // where multiple concurrent signups could all become admins
    // Retry logic handles serialization conflicts during concurrent signups
    const maxRetries = 3;
    let lastError: Error | null = null;
    
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        const result = await db.transaction(async (tx) => {
          // Count users within the transaction
          const [countResult] = await tx.select({ count: sql<number>`count(*)` }).from(users);
          const isFirstUser = Number(countResult.count || 0) === 0;
          
          // Create user with appropriate role and approval status
          const [newUser] = await tx.insert(users).values({
            ...user,
            role: isFirstUser ? "admin" : user.role,
            isApproved: isFirstUser ? true : user.isApproved
          }).returning();
          
          return { user: newUser, isFirstUser };
        }, { isolationLevel: 'serializable' });
        
        return result;
      } catch (error: any) {
        lastError = error;
        // PostgreSQL serialization error code is 40001
        if (error?.code === '40001' && attempt < maxRetries - 1) {
          // Wait briefly before retry with exponential backoff
          await new Promise(resolve => setTimeout(resolve, 50 * Math.pow(2, attempt)));
          continue;
        }
        throw error;
      }
    }
    
    throw lastError || new Error('Failed to create user after retries');
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt)).limit(500);
  }

  async getAdminUsers(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, "admin")).limit(100);
  }

  async getPendingUsers(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.isApproved, false)).orderBy(desc(users.createdAt)).limit(100);
  }

  async getUserCount(): Promise<number> {
    const [result] = await db.select({ count: sql<number>`count(*)` }).from(users);
    return Number(result.count || 0);
  }

  async updateUser(id: number, updates: Partial<InsertUser & { isApproved: boolean }>): Promise<User> {
    const [updated] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return updated;
  }

  async deleteUser(id: number): Promise<void> {
    await db.delete(favorites).where(eq(favorites.userId, id));
    await db.delete(notifications).where(eq(notifications.userId, id));
    await db.delete(comments).where(eq(comments.userId, id));
    await db.delete(passwordResetTokens).where(eq(passwordResetTokens.userId, id));
    await db.delete(users).where(eq(users.id, id));
  }

  // Folders
  async getFolders(): Promise<Folder[]> {
    return await db.select().from(folders).orderBy(folders.name).limit(500);
  }

  async getFolder(id: number): Promise<Folder | undefined> {
    const [folder] = await db.select().from(folders).where(eq(folders.id, id));
    return folder;
  }

  async createFolder(folder: InsertFolder): Promise<Folder> {
    const [newFolder] = await db.insert(folders).values(folder).returning();
    return newFolder;
  }

  async updateFolder(id: number, updates: Partial<InsertFolder>): Promise<Folder> {
    const [updated] = await db.update(folders).set(updates).where(eq(folders.id, id)).returning();
    return updated;
  }

  async deleteFolder(id: number): Promise<void> {
    await db.update(scripts).set({ folderId: null }).where(eq(scripts.folderId, id));
    await db.delete(folders).where(eq(folders.id, id));
  }

  // Scripts
  async getScripts(): Promise<Script[]> {
    return await db.select().from(scripts).orderBy(desc(scripts.createdAt)).limit(500);
  }

  async getScriptsPaginated(opts: { page?: number; pageSize?: number; search?: string; protocol?: string; folderId?: number | null }): Promise<PaginatedResult<Script>> {
    const page = opts.page || 1;
    const pageSize = Math.min(opts.pageSize || 50, 100);
    const offset = (page - 1) * pageSize;

    const conditions: any[] = [];
    if (opts.search) {
      conditions.push(ilike(scripts.name, `%${opts.search}%`));
    }
    if (opts.protocol) {
      conditions.push(eq(scripts.protocol, opts.protocol));
    }
    if (opts.folderId !== undefined) {
      if (opts.folderId === null) {
        conditions.push(isNull(scripts.folderId));
      } else {
        conditions.push(eq(scripts.folderId, opts.folderId));
      }
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const [data, countResult] = await Promise.all([
      db.select().from(scripts).where(whereClause).orderBy(desc(scripts.createdAt)).limit(pageSize).offset(offset),
      db.select({ count: sql<number>`count(*)::int` }).from(scripts).where(whereClause),
    ]);

    return { data, total: countResult[0]?.count || 0, page, pageSize };
  }

  async getScriptByName(name: string): Promise<Script | undefined> {
    const [script] = await db.select().from(scripts).where(eq(scripts.name, name));
    return script;
  }

  async getScript(id: number): Promise<Script | undefined> {
    const [script] = await db.select().from(scripts).where(eq(scripts.id, id));
    return script;
  }

  async createScript(script: InsertScript): Promise<Script> {
    const [newScript] = await db.insert(scripts).values(script).returning();
    return newScript;
  }

  async updateScript(id: number, updates: Partial<InsertScript>): Promise<Script> {
    const [updated] = await db.update(scripts).set(updates).where(eq(scripts.id, id)).returning();
    return updated;
  }

  async deleteScript(id: number): Promise<void> {
    // Use transaction to ensure consistency
    await db.transaction(async (tx) => {
      // 1. Get script first to verify it exists
      const script = await tx.select().from(scripts).where(eq(scripts.id, id));
      if (!script || script.length === 0) {
        throw new Error(`Script with id ${id} not found`);
      }

      // 2. Get all related schedules
      const scriptSchedules = await tx.select({ id: testSchedules.id }).from(testSchedules)
        .where(eq(testSchedules.scriptId, id));
      
      const scheduleIds = scriptSchedules.map(s => s.id);

      // 3. Set scriptId to null in schedules instead of deleting to preserve execution history
      // This prevents orphaned executions from losing their schedule context
      if (scheduleIds.length > 0) {
        await tx.update(testSchedules)
          .set({ 
            scriptId: null, // Remove reference to deleted script
            // Mark as cancelled if pending/running to prevent execution
            status: sql`CASE WHEN status IN ('pending', 'queued') THEN 'cancelled' ELSE status END`,
            // Update recurrence to 'none' so schedules don't retrigger
            recurrence: 'none'
          })
          .where(inArray(testSchedules.id, scheduleIds));
        
        // Note: Executions are preserved and schedules remain with null scriptId
        // This allows reports and analytics to still show historical context
      }

      // 4. Delete script-related metadata
      await tx.delete(scriptTags).where(eq(scriptTags.scriptId, id));
      await tx.delete(favorites).where(eq(favorites.scriptId, id));
      await tx.delete(baselineExecutions).where(eq(baselineExecutions.scriptId, id));
      
      // 5. Finally delete the script
      await tx.delete(scripts).where(eq(scripts.id, id));
    });
  }

  async getScriptsByFolder(folderId: number | null): Promise<Script[]> {
    const condition = folderId === null ? isNull(scripts.folderId) : eq(scripts.folderId, folderId);
    return await db.select().from(scripts).where(condition).orderBy(desc(scripts.createdAt));
  }

  // Schedules
  async getSchedules(): Promise<ScheduleWithDetails[]> {
    const results = await db.query.testSchedules.findMany({
      orderBy: [desc(testSchedules.scheduledTime)],
      with: {
        script: true,
        creator: true,
        executions: true
      }
    });
    return results as ScheduleWithDetails[];
  }

  async getSchedulesPaginated(opts: { page?: number; pageSize?: number }): Promise<PaginatedResult<ScheduleWithDetails>> {
    const page = opts.page || 1;
    const pageSize = Math.min(opts.pageSize || 20, 100);
    const offset = (page - 1) * pageSize;

    const [results, countResult] = await Promise.all([
      db.query.testSchedules.findMany({
        orderBy: [desc(testSchedules.scheduledTime)],
        limit: pageSize,
        offset,
        with: {
          script: true,
          creator: true,
          executions: true
        }
      }),
      db.select({ count: sql<number>`count(*)::int` }).from(testSchedules),
    ]);

    return { data: results as ScheduleWithDetails[], total: countResult[0]?.count || 0, page, pageSize };
  }

  async getSchedule(id: number): Promise<ScheduleWithDetails | undefined> {
    const result = await db.query.testSchedules.findFirst({
      where: eq(testSchedules.id, id),
      with: {
        script: true,
        creator: true,
        executions: true
      }
    });
    return result as ScheduleWithDetails | undefined;
  }

  async getScheduleByName(name: string): Promise<TestSchedule | undefined> {
    const [schedule] = await db.select().from(testSchedules)
      .where(eq(testSchedules.name, name));
    return schedule;
  }

  async getPendingSchedulesToRun(): Promise<TestSchedule[]> {
    // Find pending schedules whose scheduled time has passed
    const now = new Date().toISOString();
    const results = await db.select()
      .from(testSchedules)
      .where(
        and(
          eq(testSchedules.status, 'pending'),
          lte(testSchedules.scheduledTime, now)
        )
      );
    return results;
  }

  async createSchedule(schedule: InsertTestSchedule): Promise<TestSchedule> {
    // Ensure scheduledTime is an ISO string
    const scheduledTime = typeof schedule.scheduledTime === 'string' 
      ? schedule.scheduledTime 
      : new Date(schedule.scheduledTime as any).toISOString();
    
    const [newSchedule] = await db.insert(testSchedules).values({
      ...schedule,
      scheduledTime,
      configuration: schedule.configuration as any
    }).returning();
    return newSchedule;
  }

  async updateSchedule(id: number, updates: Partial<InsertTestSchedule>): Promise<TestSchedule> {
    const [updated] = await db.update(testSchedules).set({
      ...updates,
      configuration: updates.configuration as any
    }).where(eq(testSchedules.id, id)).returning();
    return updated;
  }

  // Executions
  async getExecutions(limit?: number, status?: string, offset?: number): Promise<ExecutionWithDetails[]> {
    const conditions = status ? eq(testExecutions.status, status) : undefined;
    
    const results = await db.query.testExecutions.findMany({
      where: conditions,
      limit: limit || 100,
      offset: offset || 0,
      orderBy: [desc(testExecutions.startTime)],
      with: {
        schedule: {
          with: {
            script: true
          }
        },
        comments: {
          with: { user: true },
          orderBy: (comments, { desc }) => [desc(comments.createdAt)]
        }
      }
    });
    return results as ExecutionWithDetails[];
  }

  async getExecutionCount(status?: string): Promise<number> {
    const conditions = status ? eq(testExecutions.status, status) : undefined;
    const result = await db.select({ count: sql<number>`count(*)` })
      .from(testExecutions)
      .where(conditions);
    return Number(result[0]?.count || 0);
  }

  async getExecution(id: number): Promise<ExecutionWithDetails | undefined> {
    const result = await db.query.testExecutions.findFirst({
      where: eq(testExecutions.id, id),
      with: {
        schedule: {
          with: {
            script: true
          }
        },
        comments: {
          with: { user: true },
          orderBy: (comments, { desc }) => [desc(comments.createdAt)]
        }
      }
    });
    return result as ExecutionWithDetails | undefined;
  }

  async getExecutionByExecutionId(executionId: string): Promise<TestExecution | undefined> {
    const [execution] = await db.select().from(testExecutions)
      .where(eq(testExecutions.executionId, executionId));
    return execution;
  }

  async getQueuedExecutions(): Promise<ExecutionWithDetails[]> {
    const results = await db.query.testExecutions.findMany({
      where: eq(testExecutions.status, 'queued'),
      orderBy: [desc(testExecutions.id)],
      with: {
        schedule: {
          with: {
            script: true
          }
        },
        comments: {
          with: { user: true },
          orderBy: (comments, { desc }) => [desc(comments.createdAt)]
        }
      }
    });
    return results as ExecutionWithDetails[];
  }

  async claimQueuedExecution(id: number): Promise<TestExecution | undefined> {
    // Use atomic SELECT FOR UPDATE to prevent race conditions
    // This ensures only one worker can claim an execution at a time
    try {
      const result = await db.execute(
        sql`
          UPDATE test_executions 
          SET status = 'running', start_time = NOW()
          WHERE id = ${id} AND status = 'queued'
          RETURNING *
        `
      );
      
      const rows = (result as any).rows || result;
      if (!rows || rows.length === 0) {
        return undefined;
      }
      
      return rows[0] as TestExecution;
    } catch (error) {
      // If update fails, execution was already claimed by another worker
      return undefined;
    }
  }

  async createExecution(execution: InsertTestExecution): Promise<TestExecution> {
    const [newExecution] = await db.insert(testExecutions).values({
      ...execution,
      resultSummary: execution.resultSummary as any,
      liveMetrics: execution.liveMetrics as any,
      slaViolations: (execution as any).slaViolations as any
    } as any).returning();
    return newExecution;
  }

  async updateExecution(id: number, updates: Partial<InsertTestExecution>): Promise<TestExecution> {
    const [updated] = await db.update(testExecutions).set({
      ...updates,
      resultSummary: updates.resultSummary as any,
      liveMetrics: (updates as any).liveMetrics as any
    } as any).where(eq(testExecutions.id, id)).returning();
    return updated;
  }

  async cancelExecution(id: number): Promise<TestExecution | undefined> {
    const execution = await this.getExecution(id);
    if (!execution || (execution.status !== 'running' && execution.status !== 'queued')) return undefined;

    const [updated] = await db.update(testExecutions)
      .set({ status: 'cancelled', endTime: new Date().toISOString() })
      .where(eq(testExecutions.id, id))
      .returning();

    if (execution.scheduleId) {
      await db.update(testSchedules)
        .set({ status: 'cancelled' })
        .where(eq(testSchedules.id, execution.scheduleId));
    }

    return updated;
  }

  async hasActiveExecution(scheduleId: number): Promise<boolean> {
    const executions = await db.select().from(testExecutions)
      .where(and(
        eq(testExecutions.scheduleId, scheduleId),
        sql`${testExecutions.status} IN ('queued', 'running')`
      ));
    return executions.length > 0;
  }

  async atomicClaimSchedule(scheduleId: number, executionId: string): Promise<{ execution: TestExecution } | null> {
    return await db.transaction(async (tx) => {
      const lockResult = await tx.execute(
        sql`SELECT * FROM test_schedules WHERE id = ${scheduleId} AND status = 'pending' FOR UPDATE SKIP LOCKED`
      );
      const lockedRows = (lockResult as any).rows || lockResult;
      if (!lockedRows || lockedRows.length === 0) {
        return null;
      }

      const activeCheck = await tx.select().from(testExecutions)
        .where(and(
          eq(testExecutions.scheduleId, scheduleId),
          sql`${testExecutions.status} IN ('queued', 'running')`
        ));
      if (activeCheck.length > 0) {
        return null;
      }

      const [execution] = await tx.insert(testExecutions).values({
        executionId,
        scheduleId,
        status: "queued",
        startTime: new Date().toISOString(),
      } as any).returning();

      await tx.update(testSchedules)
        .set({ status: "active" })
        .where(eq(testSchedules.id, scheduleId));

      return { execution };
    });
  }

  // Comments
  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    return newComment;
  }

  async getCommentsByExecutionId(executionId: number): Promise<Comment[]> {
    return db.select().from(comments).where(eq(comments.executionId, executionId)).orderBy(comments.createdAt);
  }

  async deleteComment(id: number): Promise<void> {
    await db.delete(comments).where(eq(comments.id, id));
  }

  // Dashboard - optimized with parallel queries
  async getDashboardStats(): Promise<DashboardStats> {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const [countsResult, recentExecutions, todayResult] = await Promise.all([
      db.execute(sql`
        SELECT 
          (SELECT count(*) FROM scripts) as script_count,
          (SELECT count(*) FROM test_executions) as exec_count,
          (SELECT count(*) FROM test_executions WHERE status = 'completed') as pass_count,
          (SELECT count(*) FROM test_executions WHERE status = 'running') as active_count
      `),
      this.getExecutions(10),
      db.execute(sql`
        SELECT
          count(*) FILTER (WHERE status = 'completed') as today_completed,
          count(*) FILTER (WHERE status = 'failed') as today_failed,
          count(*) FILTER (WHERE status = 'running') as today_running
        FROM test_executions
        WHERE start_time >= ${todayStart.toISOString()}
      `)
    ]);

    const rows = (countsResult as any).rows || [];
    const counts = rows[0] || {};
    const scriptCount = Number(counts.script_count || 0);
    const totalExecutions = Number(counts.exec_count || 0);
    const passed = Number(counts.pass_count || 0);
    const activeTests = Number(counts.active_count || 0);

    const todayRows = (todayResult as any).rows || [];
    const todayCounts = todayRows[0] || {};

    const filteredExecutions = recentExecutions.filter(exec => {
      return exec != null;
    }).slice(0, 8);

    let performanceMetrics;
    const completedWithResults = filteredExecutions.filter(
      (e: any) => e.status === 'completed' && e.resultSummary?.avgResponseTime
    );
    if (completedWithResults.length > 0) {
      const sumRT = completedWithResults.reduce((s: number, e: any) => s + (e.resultSummary?.avgResponseTime || 0), 0);
      const sumTP = completedWithResults.reduce((s: number, e: any) => s + (e.resultSummary?.throughput || 0), 0);
      const sumP95 = completedWithResults.reduce((s: number, e: any) => s + (e.resultSummary?.p95 || 0), 0);
      const sumER = completedWithResults.reduce((s: number, e: any) => s + (e.resultSummary?.errorRate || 0), 0);
      const n = completedWithResults.length;
      performanceMetrics = {
        avgResponseTime: Math.round(sumRT / n),
        avgThroughput: Math.round((sumTP / n) * 100) / 100,
        avgP95: Math.round(sumP95 / n),
        avgErrorRate: Math.round((sumER / n) * 100) / 100,
        testsAnalyzed: n,
      };
    }
    
    return {
      totalScripts: scriptCount,
      totalExecutions,
      passRate: totalExecutions > 0 ? (passed / totalExecutions) * 100 : 0,
      activeTests,
      recentExecutions: filteredExecutions,
      performanceMetrics,
      todayStats: {
        completed: Number(todayCounts.today_completed || 0),
        failed: Number(todayCounts.today_failed || 0),
        running: Number(todayCounts.today_running || 0),
        scheduled: 0,
      },
    };
  }

  // Tags
  async getTags(): Promise<Tag[]> {
    return await db.select().from(tags).orderBy(tags.name).limit(500);
  }

  async createTag(tag: InsertTag): Promise<Tag> {
    const [newTag] = await db.insert(tags).values(tag).returning();
    return newTag;
  }

  async deleteTag(id: number): Promise<void> {
    await db.delete(scriptTags).where(eq(scriptTags.tagId, id));
    await db.delete(tags).where(eq(tags.id, id));
  }

  async addTagToScript(scriptId: number, tagId: number): Promise<void> {
    await db.insert(scriptTags).values({ scriptId, tagId }).onConflictDoNothing();
  }

  async removeTagFromScript(scriptId: number, tagId: number): Promise<void> {
    await db.delete(scriptTags).where(and(
      eq(scriptTags.scriptId, scriptId),
      eq(scriptTags.tagId, tagId)
    ));
  }

  async getScriptTags(scriptId: number): Promise<Tag[]> {
    const result = await db.select({ tag: tags })
      .from(scriptTags)
      .innerJoin(tags, eq(scriptTags.tagId, tags.id))
      .where(eq(scriptTags.scriptId, scriptId));
    return result.map(r => r.tag);
  }

  // Favorites
  async getFavorites(userId: number): Promise<number[]> {
    const result = await db.select({ scriptId: favorites.scriptId })
      .from(favorites)
      .where(eq(favorites.userId, userId));
    return result.map(r => r.scriptId);
  }

  async addFavorite(userId: number, scriptId: number): Promise<Favorite> {
    const [fav] = await db.insert(favorites).values({ userId, scriptId }).returning();
    return fav;
  }

  async removeFavorite(userId: number, scriptId: number): Promise<void> {
    await db.delete(favorites).where(and(
      eq(favorites.userId, userId),
      eq(favorites.scriptId, scriptId)
    ));
  }

  // Templates
  async getTemplates(): Promise<TestTemplate[]> {
    return await db.select().from(testTemplates).orderBy(desc(testTemplates.createdAt)).limit(500);
  }

  async getTemplate(id: number): Promise<TestTemplate | undefined> {
    const [template] = await db.select().from(testTemplates).where(eq(testTemplates.id, id));
    return template;
  }

  async createTemplate(template: InsertTestTemplate): Promise<TestTemplate> {
    const [newTemplate] = await db.insert(testTemplates).values({
      ...template,
      configuration: template.configuration as any
    } as any).returning();
    return newTemplate;
  }

  async deleteTemplate(id: number): Promise<void> {
    await db.delete(testTemplates).where(eq(testTemplates.id, id));
  }

  // Baselines
  async getBaseline(scriptId: number): Promise<BaselineExecution | undefined> {
    const [baseline] = await db.select().from(baselineExecutions)
      .where(and(eq(baselineExecutions.scriptId, scriptId), eq(baselineExecutions.isActive, true)));
    return baseline;
  }

  async getBaselineWithExecution(scriptId: number): Promise<{ baseline: BaselineExecution; execution: TestExecution } | undefined> {
    const baseline = await this.getBaseline(scriptId);
    if (!baseline) return undefined;
    const [execution] = await db.select().from(testExecutions)
      .where(eq(testExecutions.id, baseline.executionId));
    if (!execution) return undefined;
    return { baseline, execution };
  }

  async setBaseline(scriptId: number, executionId: number, userId: number, name?: string, notes?: string): Promise<BaselineExecution> {
    await db.update(baselineExecutions)
      .set({ isActive: false })
      .where(eq(baselineExecutions.scriptId, scriptId));
    const [baseline] = await db.insert(baselineExecutions)
      .values({ scriptId, executionId, setBy: userId, isActive: true, name, notes })
      .returning();
    return baseline;
  }

  async removeBaseline(scriptId: number): Promise<void> {
    await db.update(baselineExecutions)
      .set({ isActive: false })
      .where(eq(baselineExecutions.scriptId, scriptId));
  }

  async getBaselineHistory(scriptId: number): Promise<BaselineExecution[]> {
    return await db.select().from(baselineExecutions)
      .where(eq(baselineExecutions.scriptId, scriptId))
      .orderBy(desc(baselineExecutions.createdAt));
  }

  // Regression Thresholds
  async getRegressionThresholds(scriptId: number): Promise<RegressionThreshold[]> {
    return await db.select().from(regressionThresholds)
      .where(eq(regressionThresholds.scriptId, scriptId))
      .orderBy(regressionThresholds.metric);
  }

  async upsertRegressionThreshold(data: InsertRegressionThreshold): Promise<RegressionThreshold> {
    const existing = await db.select().from(regressionThresholds)
      .where(and(
        eq(regressionThresholds.scriptId, data.scriptId),
        eq(regressionThresholds.metric, data.metric)
      ));
    if (existing.length > 0) {
      const [updated] = await db.update(regressionThresholds)
        .set({ warningPercent: data.warningPercent, criticalPercent: data.criticalPercent, isEnabled: data.isEnabled, updatedAt: new Date() })
        .where(eq(regressionThresholds.id, existing[0].id))
        .returning();
      return updated;
    }
    const [created] = await db.insert(regressionThresholds).values(data).returning();
    return created;
  }

  async deleteRegressionThreshold(id: number): Promise<void> {
    await db.delete(regressionThresholds).where(eq(regressionThresholds.id, id));
  }

  async getEnabledRegressionThresholds(scriptId: number): Promise<RegressionThreshold[]> {
    return await db.select().from(regressionThresholds)
      .where(and(
        eq(regressionThresholds.scriptId, scriptId),
        eq(regressionThresholds.isEnabled, true)
      ));
  }

  // SLA Rules
  async getSlaRules(scriptId: number): Promise<SlaRule[]> {
    return await db.select().from(slaRules)
      .where(eq(slaRules.scriptId, scriptId))
      .orderBy(slaRules.transactionLabel, slaRules.metric);
  }

  async getSlaRule(id: number): Promise<SlaRule | undefined> {
    const [rule] = await db.select().from(slaRules)
      .where(eq(slaRules.id, id));
    return rule;
  }

  async createSlaRule(rule: InsertSlaRule): Promise<SlaRule> {
    const [created] = await db.insert(slaRules).values(rule).returning();
    return created;
  }

  async updateSlaRule(id: number, updates: Partial<InsertSlaRule>): Promise<SlaRule | undefined> {
    const [updated] = await db.update(slaRules)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(slaRules.id, id))
      .returning();
    return updated;
  }

  async deleteSlaRule(id: number): Promise<void> {
    await db.delete(slaRules).where(eq(slaRules.id, id));
  }

  async getEnabledSlaRules(scriptId: number): Promise<SlaRule[]> {
    return await db.select().from(slaRules)
      .where(and(eq(slaRules.scriptId, scriptId), eq(slaRules.isEnabled, true)));
  }

  async getExecutionSlaRules(executionId: number): Promise<ExecutionSlaRule[]> {
    return await db.select().from(executionSlaRules)
      .where(eq(executionSlaRules.executionId, executionId))
      .orderBy(executionSlaRules.transactionLabel, executionSlaRules.metric);
  }

  async getEnabledExecutionSlaRules(executionId: number): Promise<ExecutionSlaRule[]> {
    return await db.select().from(executionSlaRules)
      .where(and(eq(executionSlaRules.executionId, executionId), eq(executionSlaRules.isEnabled, true)));
  }

  async createExecutionSlaRule(rule: InsertExecutionSlaRule): Promise<ExecutionSlaRule> {
    const [created] = await db.insert(executionSlaRules).values(rule).returning();
    return created;
  }

  async updateExecutionSlaRule(id: number, updates: Partial<InsertExecutionSlaRule>): Promise<ExecutionSlaRule | undefined> {
    const [updated] = await db.update(executionSlaRules)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(executionSlaRules.id, id))
      .returning();
    return updated;
  }

  async deleteExecutionSlaRule(id: number): Promise<void> {
    await db.delete(executionSlaRules).where(eq(executionSlaRules.id, id));
  }

  // Trend Analysis helpers
  async getExecutionsByScheduleId(scheduleId: number, limit: number = 20): Promise<TestExecution[]> {
    return await db.select().from(testExecutions)
      .where(eq(testExecutions.scheduleId, scheduleId))
      .orderBy(desc(testExecutions.startTime))
      .limit(limit);
  }

  async getExecutionsByScriptId(scriptId: number, limit: number = 20): Promise<TestExecution[]> {
    const schedules = await db.select({ id: testSchedules.id }).from(testSchedules)
      .where(eq(testSchedules.scriptId, scriptId));
    
    if (schedules.length === 0) return [];
    
    const scheduleIds = schedules.map(s => s.id);
    return await db.select().from(testExecutions)
      .where(inArray(testExecutions.scheduleId, scheduleIds))
      .orderBy(desc(testExecutions.startTime))
      .limit(limit);
  }

  // Bulk operations
  async bulkDeleteSchedules(ids: number[]): Promise<void> {
    if (ids.length === 0) return;
    // Delete schedules but preserve their executions for historical reference
    await db.delete(testSchedules).where(inArray(testSchedules.id, ids));
  }

  async bulkCancelSchedules(ids: number[]): Promise<void> {
    if (ids.length === 0) return;
    await db.update(testSchedules).set({ status: 'cancelled' }).where(inArray(testSchedules.id, ids));
    await db.update(testExecutions).set({ status: 'cancelled', endTime: new Date().toISOString() })
      .where(and(
        inArray(testExecutions.scheduleId, ids),
        sql`${testExecutions.status} IN ('queued', 'running')`
      ));
  }

  async cloneSchedule(id: number): Promise<TestSchedule | undefined> {
    const schedule = await this.getSchedule(id);
    if (!schedule) return undefined;
    
    const [cloned] = await db.insert(testSchedules).values({
      name: `${schedule.name} (Copy)`,
      scriptId: schedule.scriptId,
      scheduledTime: new Date(),
      status: 'pending',
      recurrence: schedule.recurrence,
      configuration: schedule.configuration as any,
      createdBy: schedule.createdBy
    } as any).returning();
    return cloned;
  }

  // === TEST CHECKPOINT METHODS ===

  async createCheckpoint(checkpoint: InsertTestCheckpoint): Promise<TestCheckpoint> {
    const [newCheckpoint] = await db.insert(testCheckpoints).values(checkpoint).returning();
    return newCheckpoint;
  }

  async getCheckpoint(executionId: number): Promise<TestCheckpoint | undefined> {
    const [checkpoint] = await db.select().from(testCheckpoints)
      .where(eq(testCheckpoints.executionId, executionId));
    return checkpoint;
  }

  async updateCheckpoint(executionId: number, updates: Partial<InsertTestCheckpoint>): Promise<TestCheckpoint | undefined> {
    const [updated] = await db.update(testCheckpoints)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(testCheckpoints.executionId, executionId))
      .returning();
    return updated;
  }

  async deleteCheckpoint(executionId: number): Promise<void> {
    await db.delete(testCheckpoints).where(eq(testCheckpoints.executionId, executionId));
  }

  async getResumableCheckpoints(): Promise<TestCheckpoint[]> {
    return await db.select().from(testCheckpoints)
      .where(eq(testCheckpoints.state, 'resumable'))
      .orderBy(desc(testCheckpoints.updatedAt))
      .limit(100);
  }

  async getIncompleteCheckpoints(): Promise<TestCheckpoint[]> {
    return await db.select().from(testCheckpoints)
      .where(
        sql`${testCheckpoints.state} IN ('running', 'queued') 
            OR (${testCheckpoints.state} = 'resumable' AND ${testCheckpoints.progress} < 100)`
      )
      .orderBy(desc(testCheckpoints.updatedAt))
      .limit(100);
  }

  // === DATA RETENTION SETTINGS METHODS ===

  async getRetentionSetting(key: string): Promise<number> {
    const [setting] = await db.select().from(dataRetentionSettings)
      .where(eq(dataRetentionSettings.settingKey, key));
    return setting?.settingValue || 30; // default 30 days
  }

  async updateRetentionSetting(key: string, value: number, userId?: number): Promise<void> {
    await db.insert(dataRetentionSettings)
      .values({ settingKey: key, settingValue: value, updatedBy: userId })
      .onConflictDoUpdate({
        target: dataRetentionSettings.settingKey,
        set: { settingValue: value, updatedAt: new Date(), updatedBy: userId }
      });
  }

  async getAllRetentionSettings(): Promise<DataRetentionSetting[]> {
    return await db.select().from(dataRetentionSettings).limit(100);
  }

  // === CUSTOM ENVIRONMENT METHODS ===

  async getCustomEnvironments(): Promise<CustomEnvironment[]> {
    return await db.select().from(customEnvironments).orderBy(asc(customEnvironments.name)).limit(500);
  }

  async createCustomEnvironment(env: InsertCustomEnvironment): Promise<CustomEnvironment> {
    const [newEnv] = await db.insert(customEnvironments).values(env).returning();
    return newEnv;
  }

  async deleteCustomEnvironment(id: number): Promise<void> {
    await db.delete(customEnvironments).where(eq(customEnvironments.id, id));
  }

  // === AUDIT LOG METHODS ===

  async createAuditLog(log: InsertAuditLog): Promise<AuditLog> {
    const [newLog] = await db.insert(auditLogs).values(log).returning();
    return newLog;
  }

  async getAuditLogs(userId?: number, resourceType?: string, limit: number = 100): Promise<AuditLog[]> {
    let query = db.select().from(auditLogs);
    
    const conditions = [];
    if (userId) {
      conditions.push(eq(auditLogs.userId, userId));
    }
    if (resourceType) {
      conditions.push(eq(auditLogs.resourceType, resourceType));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }
    
    return await query.orderBy(desc(auditLogs.timestamp)).limit(limit);
  }

  async getAuditLogsForResource(resourceType: string, resourceId: string): Promise<AuditLog[]> {
    return await db.select().from(auditLogs)
      .where(and(
        eq(auditLogs.resourceType, resourceType),
        eq(auditLogs.resourceId, resourceId)
      ))
      .orderBy(desc(auditLogs.timestamp))
      .limit(100);
  }

  // === PROJECT METHODS ===

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(asc(projects.name)).limit(500);
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async updateProject(id: number, updates: Partial<InsertProject>): Promise<Project | undefined> {
    const [updated] = await db.update(projects).set(updates).where(eq(projects.id, id)).returning();
    return updated;
  }

  async deleteProject(id: number): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  // === TEST TYPE METHODS ===

  async getTestTypes(): Promise<TestType[]> {
    return await db.select().from(testTypes).orderBy(asc(testTypes.name)).limit(500);
  }

  async getTestType(id: number): Promise<TestType | undefined> {
    const [testType] = await db.select().from(testTypes).where(eq(testTypes.id, id));
    return testType;
  }

  async createTestType(testType: InsertTestType): Promise<TestType> {
    const [newType] = await db.insert(testTypes).values(testType).returning();
    return newType;
  }

  async updateTestType(id: number, updates: Partial<InsertTestType>): Promise<TestType | undefined> {
    const [updated] = await db.update(testTypes).set(updates).where(eq(testTypes.id, id)).returning();
    return updated;
  }

  async deleteTestType(id: number): Promise<void> {
    await db.delete(testTypes).where(eq(testTypes.id, id));
  }

  // === TEST TRACKER METHODS ===

  async getTestTrackerRecords(filters?: { 
    projectId?: number; 
    projectName?: string;
    testTypeId?: number; 
    environment?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
    releaseTag?: string;
  }): Promise<TestTrackerRecord[]> {
    const conditions = [];
    
    if (filters?.projectId) {
      conditions.push(eq(testTracker.projectId, filters.projectId));
    }
    if (filters?.projectName) {
      conditions.push(eq(testTracker.projectName, filters.projectName));
    }
    if (filters?.testTypeId) {
      conditions.push(eq(testTracker.testTypeId, filters.testTypeId));
    }
    if (filters?.environment) {
      conditions.push(eq(testTracker.environment, filters.environment));
    }
    if (filters?.status) {
      conditions.push(eq(testTracker.status, filters.status));
    }
    if (filters?.startDate) {
      conditions.push(gte(testTracker.executionTimestamp, filters.startDate));
    }
    if (filters?.endDate) {
      conditions.push(lte(testTracker.executionTimestamp, filters.endDate));
    }
    if (filters?.releaseTag) {
      conditions.push(eq(testTracker.releaseTag, filters.releaseTag));
    }

    let query = db.select().from(testTracker);
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }
    
    return await query.orderBy(desc(testTracker.executionTimestamp)).limit(1000);
  }

  async getTestTrackerRecordsPaginated(
    filters: {
      projectId?: number;
      projectName?: string;
      testTypeId?: number;
      environment?: string;
      status?: string;
      startDate?: string;
      endDate?: string;
      releaseTag?: string;
    },
    opts: { page?: number; pageSize?: number; sortBy?: string; sortDir?: 'asc' | 'desc' }
  ): Promise<PaginatedResult<TestTrackerRecord>> {
    const page = opts.page || 1;
    const pageSize = Math.min(opts.pageSize || 25, 100);
    const offset = (page - 1) * pageSize;

    const conditions: any[] = [];
    if (filters.projectId) conditions.push(eq(testTracker.projectId, filters.projectId));
    if (filters.projectName) conditions.push(eq(testTracker.projectName, filters.projectName));
    if (filters.testTypeId) conditions.push(eq(testTracker.testTypeId, filters.testTypeId));
    if (filters.environment) conditions.push(eq(testTracker.environment, filters.environment));
    if (filters.status) conditions.push(eq(testTracker.status, filters.status));
    if (filters.startDate) conditions.push(gte(testTracker.executionTimestamp, filters.startDate));
    if (filters.endDate) conditions.push(lte(testTracker.executionTimestamp, filters.endDate));
    if (filters.releaseTag) conditions.push(eq(testTracker.releaseTag, filters.releaseTag));

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const sortColumnMap: Record<string, any> = {
      executionTimestamp: testTracker.executionTimestamp,
      avgResponseTime: testTracker.avgResponseTime,
      p95: testTracker.p95,
      throughput: testTracker.throughput,
      errorRate: testTracker.errorRate,
      durationSeconds: testTracker.durationSeconds,
      projectName: testTracker.projectName,
      featureName: testTracker.featureName,
      status: testTracker.status,
    };

    const sortColumn = sortColumnMap[opts.sortBy || ''] || testTracker.executionTimestamp;
    const orderFn = opts.sortDir === 'asc' ? asc : desc;

    const [data, countResult] = await Promise.all([
      db.select().from(testTracker).where(whereClause).orderBy(orderFn(sortColumn)).limit(pageSize).offset(offset),
      db.select({ count: sql<number>`count(*)::int` }).from(testTracker).where(whereClause),
    ]);

    return { data, total: countResult[0]?.count || 0, page, pageSize };
  }

  async createTestTrackerRecord(record: InsertTestTracker): Promise<TestTrackerRecord> {
    const [newRecord] = await db.insert(testTracker).values(record).returning();
    return newRecord;
  }

  async updateTestTrackerComment(id: number, comments: string): Promise<void> {
    await db.update(testTracker).set({ comments }).where(eq(testTracker.id, id));
  }

  async deleteExecution(id: number): Promise<void> {
    const execution = await db.select({ artifactsPath: testExecutions.artifactsPath })
      .from(testExecutions).where(eq(testExecutions.id, id)).limit(1);
    const artifactsPath = execution[0]?.artifactsPath;

    await db.transaction(async (tx) => {
      await tx.delete(comments).where(eq(comments.executionId, id));
      await tx.delete(testTracker).where(eq(testTracker.executionId, id));
      await tx.delete(executionSlaRules).where(eq(executionSlaRules.executionId, id));
      await tx.delete(executionMetricBuckets).where(eq(executionMetricBuckets.executionId, id));
      await tx.delete(testExecutions).where(eq(testExecutions.id, id));
    });

    if (artifactsPath) {
      try {
        const fs = await import("fs");
        if (fs.existsSync(artifactsPath)) {
          fs.rmSync(artifactsPath, { recursive: true, force: true });
        }
      } catch {}
    }
  }

  async deleteTrackerRecord(id: number): Promise<void> {
    await db.delete(testTracker).where(eq(testTracker.id, id));
  }

  async getSavedFilterViews(userId: number, page: string): Promise<SavedFilterView[]> {
    return await db.select().from(savedFilterViews)
      .where(and(eq(savedFilterViews.userId, userId), eq(savedFilterViews.page, page)))
      .orderBy(desc(savedFilterViews.createdAt));
  }

  async createSavedFilterView(view: InsertSavedFilterView): Promise<SavedFilterView> {
    const [created] = await db.insert(savedFilterViews).values(view).returning();
    return created;
  }

  async deleteSavedFilterView(id: number, userId: number): Promise<void> {
    await db.delete(savedFilterViews).where(and(eq(savedFilterViews.id, id), eq(savedFilterViews.userId, userId)));
  }

  async updateSavedFilterViewDefault(id: number, userId: number, page: string, isDefault: boolean): Promise<void> {
    if (isDefault) {
      await db.update(savedFilterViews).set({ isDefault: false })
        .where(and(eq(savedFilterViews.userId, userId), eq(savedFilterViews.page, page)));
    }
    await db.update(savedFilterViews).set({ isDefault })
      .where(and(eq(savedFilterViews.id, id), eq(savedFilterViews.userId, userId)));
  }

  async updateExecutionPin(id: number, isPinned: boolean, userId: number): Promise<void> {
    await db.update(testExecutions).set({
      isPinned,
      pinnedAt: isPinned ? new Date().toISOString() : null,
      pinnedBy: isPinned ? userId : null,
    }).where(eq(testExecutions.id, id));
  }

  // === AUTO-ABORT RULES METHODS ===

  async getAutoAbortRules(scriptId: number): Promise<AutoAbortRule[]> {
    return await db.select().from(autoAbortRules)
      .where(eq(autoAbortRules.scriptId, scriptId))
      .orderBy(desc(autoAbortRules.createdAt));
  }

  async getEnabledAutoAbortRules(scriptId: number): Promise<AutoAbortRule[]> {
    return await db.select().from(autoAbortRules)
      .where(and(eq(autoAbortRules.scriptId, scriptId), eq(autoAbortRules.isEnabled, true)))
      .orderBy(desc(autoAbortRules.createdAt));
  }

  async createAutoAbortRule(rule: InsertAutoAbortRule): Promise<AutoAbortRule> {
    const [newRule] = await db.insert(autoAbortRules).values(rule).returning();
    return newRule;
  }

  async updateAutoAbortRule(id: number, updates: Partial<InsertAutoAbortRule>): Promise<AutoAbortRule | undefined> {
    const [updated] = await db.update(autoAbortRules)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(autoAbortRules.id, id))
      .returning();
    return updated;
  }

  async deleteAutoAbortRule(id: number): Promise<void> {
    await db.delete(autoAbortRules).where(eq(autoAbortRules.id, id));
  }

  async getExecutionAutoAbortRules(executionId: number): Promise<ExecutionAutoAbortRule[]> {
    return await db.select().from(executionAutoAbortRules)
      .where(eq(executionAutoAbortRules.executionId, executionId))
      .orderBy(executionAutoAbortRules.metric);
  }

  async getEnabledExecutionAutoAbortRules(executionId: number): Promise<ExecutionAutoAbortRule[]> {
    return await db.select().from(executionAutoAbortRules)
      .where(and(eq(executionAutoAbortRules.executionId, executionId), eq(executionAutoAbortRules.isEnabled, true)));
  }

  async createExecutionAutoAbortRule(rule: InsertExecutionAutoAbortRule): Promise<ExecutionAutoAbortRule> {
    const [created] = await db.insert(executionAutoAbortRules).values(rule).returning();
    return created;
  }

  async updateExecutionAutoAbortRule(id: number, updates: Partial<InsertExecutionAutoAbortRule>): Promise<ExecutionAutoAbortRule | undefined> {
    const [updated] = await db.update(executionAutoAbortRules)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(executionAutoAbortRules.id, id))
      .returning();
    return updated;
  }

  async deleteExecutionAutoAbortRule(id: number): Promise<void> {
    await db.delete(executionAutoAbortRules).where(eq(executionAutoAbortRules.id, id));
  }

  async getExecutionWorkloadTargets(executionId: number): Promise<ExecutionWorkloadTarget | undefined> {
    const [target] = await db.select().from(executionWorkloadTargets)
      .where(eq(executionWorkloadTargets.executionId, executionId))
      .limit(1);
    return target;
  }

  async setExecutionWorkloadTargets(target: InsertExecutionWorkloadTarget): Promise<ExecutionWorkloadTarget> {
    await db.delete(executionWorkloadTargets).where(eq(executionWorkloadTargets.executionId, target.executionId));
    const [created] = await db.insert(executionWorkloadTargets).values(target).returning();
    return created;
  }

  async deleteExecutionWorkloadTargets(executionId: number): Promise<void> {
    await db.delete(executionWorkloadTargets).where(eq(executionWorkloadTargets.executionId, executionId));
  }
}

export const storage = new DatabaseStorage();
