import { type Express } from "express";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { requireAuth, requireEngineerOrAdmin, generateExecutionId } from "./route-middleware";
import { cacheService, CACHE_KEYS, CACHE_TTL } from "./cache";
import { queueJMeterRun, generateRunId } from "./jmeter-worker";
import { validate, z, idParam } from "./validation";
import { asyncHandler } from "./error-handler";

export function registerScheduleRoutes(app: Express): void {

  app.get(api.schedules.list.path, requireAuth, asyncHandler(async (req, res) => {
    const { page, pageSize } = req.query as any;

    if (page) {
      const result = await storage.getSchedulesPaginated({
        page: Number(page),
        pageSize: pageSize ? Number(pageSize) : 20,
      });
      return res.json(result);
    }

    const cached = await cacheService.get<any[]>(CACHE_KEYS.SCHEDULES_LIST);
    if (cached) {
      return res.json(cached);
    }
    const schedules = await storage.getSchedules();
    await cacheService.set(CACHE_KEYS.SCHEDULES_LIST, schedules, CACHE_TTL.SCHEDULES_LIST);
    res.json(schedules);
  }));

  app.get(api.schedules.get.path, requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const schedule = await storage.getSchedule(id);
    if (!schedule) return res.status(404).json({ message: "Schedule not found" });
    res.json(schedule);
  }));

  app.post(api.schedules.create.path, requireEngineerOrAdmin, validate({ body: z.object({
    name: z.string().min(1, "Name is required"),
    scriptId: z.number().int().positive("Please select a script"),
    scheduledTime: z.string().min(1),
    recurrence: z.enum(["none", "daily", "weekly", "monthly"]).optional(),
    configuration: z.object({
      vusers: z.number().int().positive().optional(),
      rampUp: z.number().int().min(0).optional(),
      duration: z.number().int().positive().optional(),
      timeoutMinutes: z.number().int().positive().optional(),
      environment: z.string().min(1),
      timezone: z.string().optional(),
      isDistributed: z.boolean().optional(),
      workerNodes: z.number().int().positive().optional(),
      testTypeId: z.number().int().optional(),
      testTypeName: z.string().optional(),
      volume: z.string().optional(),
      releaseTag: z.string().max(100).optional(),
      slas: z.record(z.number()).optional(),
    }).optional(),
  }) }), asyncHandler(async (req, res) => {
    const userId = (req.session as any)?.user?.id || 1;
    
    const script = await storage.getScript(req.body.scriptId);
    if (!script) {
      return res.status(400).json({ message: 'Selected script not found. Please choose a valid script.' });
    }
    if (!script.filePath) {
      return res.status(400).json({ 
        message: `Script "${script.name}" does not have a test file uploaded. Please upload a test file to the script before scheduling.` 
      });
    }
    
    const scheduleData = {
      ...req.body,
      createdBy: userId,
      scheduledTime: new Date(req.body.scheduledTime)
    };
    const schedule = await storage.createSchedule(scheduleData);
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    res.status(201).json(schedule);
  }));

  app.patch(api.schedules.update.path, requireEngineerOrAdmin, validate({ params: idParam, body: z.object({
    name: z.string().min(1).optional(),
    scriptId: z.number().int().positive().optional(),
    scheduledTime: z.string().optional(),
    status: z.enum(["pending", "running", "completed", "failed", "cancelled"]).optional(),
    recurrence: z.enum(["none", "daily", "weekly", "monthly"]).optional(),
    configuration: z.object({
      vusers: z.number().int().positive().optional(),
      rampUp: z.number().int().min(0).optional(),
      duration: z.number().int().positive().optional(),
      timeoutMinutes: z.number().int().positive().optional(),
      environment: z.string().min(1),
      timezone: z.string().optional(),
      isDistributed: z.boolean().optional(),
      workerNodes: z.number().int().positive().optional(),
      testTypeId: z.number().int().optional(),
      testTypeName: z.string().optional(),
      volume: z.string().optional(),
      releaseTag: z.string().max(100).optional(),
      slas: z.record(z.number()).optional(),
    }).optional(),
  }) }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const schedule = await storage.updateSchedule(id, req.body);
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    res.json(schedule);
  }));

  app.post("/api/schedules/:id/queue", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const scheduleId = req.params.id as unknown as number;

    const schedule = await storage.getSchedule(scheduleId);
    if (!schedule) return res.status(404).json({ message: "Schedule not found" });

    if (!schedule.script?.filePath) {
      return res.status(400).json({ message: "Script does not have a JMX file uploaded" });
    }

    const hasActive = await storage.hasActiveExecution(scheduleId);
    if (hasActive) {
      return res.status(400).json({ message: "Test is already queued or running" });
    }

    const executionId = generateExecutionId();
    const execution = await storage.createExecution({
      executionId,
      scheduleId,
      status: "queued",
      startTime: null,
      endTime: null,
      resultSummary: null,
      artifactsPath: null,
      reportHtmlPath: null,
      reportComments: null,
      liveMetrics: null,
      releaseTag: (schedule.configuration as any)?.releaseTag || null,
    } as any);

    await storage.updateSchedule(scheduleId, { status: "queued" });
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);

    queueJMeterRun(execution.id, {
      executionId,
      jmxPath: schedule.script.filePath,
      dependencyFiles: (schedule.script as any).dependencyFiles || [],
      jarFiles: (schedule.script as any).jarFiles || [],
      vusers: schedule.configuration?.vusers,
      rampUp: schedule.configuration?.rampUp,
      duration: schedule.configuration?.duration,
    });

    res.status(201).json(execution);
  }));

  app.post("/api/schedules/bulk/delete", requireEngineerOrAdmin, validate({ body: z.object({ ids: z.array(z.number().int()).min(1) }) }), asyncHandler(async (req, res) => {
    await storage.bulkDeleteSchedules(req.body.ids);
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    res.sendStatus(204);
  }));

  app.post("/api/schedules/bulk/cancel", requireEngineerOrAdmin, validate({ body: z.object({ ids: z.array(z.number().int()).min(1) }) }), asyncHandler(async (req, res) => {
    await storage.bulkCancelSchedules(req.body.ids);
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    res.sendStatus(204);
  }));

  app.post("/api/schedules/bulk/run", requireEngineerOrAdmin, validate({ body: z.object({ ids: z.array(z.number().int()).min(1, "Invalid ids array") }) }), asyncHandler(async (req, res) => {
    const ids: number[] = req.body.ids;
    const results: any[] = [];
    for (const id of ids) {
      const schedule = await storage.getSchedule(id);
      if (!schedule || !schedule.script?.filePath) continue;
      const hasActive = await storage.hasActiveExecution(id);
      if (hasActive) continue;
      const executionId = generateExecutionId();
      const execution = await storage.createExecution({
        executionId,
        scheduleId: id,
        status: "queued",
        startTime: null,
        endTime: null,
        resultSummary: null,
        artifactsPath: null,
        reportHtmlPath: null,
        reportComments: null,
        liveMetrics: null,
      } as any);
      await storage.updateSchedule(id, { status: "queued" });
      
      queueJMeterRun(execution.id, {
        executionId,
        jmxPath: schedule.script.filePath,
        dependencyFiles: (schedule.script as any).dependencyFiles || [],
        jarFiles: (schedule.script as any).jarFiles || [],
        vusers: schedule.configuration?.vusers,
        rampUp: schedule.configuration?.rampUp,
        duration: schedule.configuration?.duration,
      });
      
      results.push(execution);
    }
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    res.json({ queued: results.length });
  }));

  app.post("/api/schedules/:id/clone", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const cloned = await storage.cloneSchedule(req.params.id as unknown as number);
    if (!cloned) return res.status(404).json({ message: "Schedule not found" });
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    res.json(cloned);
  }));

  app.post("/api/schedules/:id/cancel", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const scheduleId = req.params.id as unknown as number;
    await storage.bulkCancelSchedules([scheduleId]);
    await cacheService.delete(CACHE_KEYS.SCHEDULES_LIST);
    await cacheService.delete(CACHE_KEYS.DASHBOARD_STATS);
    res.json({ success: true, message: "Schedule cancelled" });
  }));
}
