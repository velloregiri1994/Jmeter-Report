import nodemailer from "nodemailer";
import type { Transporter } from "nodemailer";

interface SmtpConfig {
  host: string;
  port: number;
  email: string;
  password: string;
}

let cachedTransporter: Transporter | null = null;
let cachedConfigHash = "";

function configHash(config: SmtpConfig): string {
  return `${config.host}:${config.port}:${config.email}`;
}

function getTransporter(config: SmtpConfig): Transporter {
  const hash = configHash(config);
  if (cachedTransporter && cachedConfigHash === hash) {
    return cachedTransporter;
  }

  cachedTransporter = nodemailer.createTransport({
    host: config.host,
    port: config.port,
    secure: false,
    auth: {
      user: config.email,
      pass: config.password,
    },
    tls: {
      minVersion: "TLSv1.2",
    },
    requireTLS: true,
    connectionTimeout: 10000,
    greetingTimeout: 10000,
    socketTimeout: 15000,
  });
  cachedConfigHash = hash;
  return cachedTransporter;
}

export async function verifyConnection(config: SmtpConfig): Promise<{ success: boolean; error?: string }> {
  try {
    const transporter = getTransporter(config);
    await transporter.verify();
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message || "Connection failed" };
  }
}

export interface EmailAttachment {
  filename: string;
  content?: string | Buffer;
  path?: string;
  contentType?: string;
}

export async function sendEmail(
  config: SmtpConfig,
  to: string[],
  subject: string,
  html: string,
  attachments?: EmailAttachment[],
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    const transporter = getTransporter(config);
    const mailOptions: any = {
      from: config.email,
      to: to.join(", "),
      subject,
      html,
    };
    if (attachments && attachments.length > 0) {
      mailOptions.attachments = attachments.map(a => ({
        filename: a.filename,
        ...(a.content ? { content: a.content } : {}),
        ...(a.path ? { path: a.path } : {}),
        ...(a.contentType ? { contentType: a.contentType } : {}),
      }));
    }
    const info = await transporter.sendMail(mailOptions);
    return { success: true, messageId: info.messageId };
  } catch (err: any) {
    return { success: false, error: err.message || "Send failed" };
  }
}

export function clearTransporterCache(): void {
  if (cachedTransporter) {
    cachedTransporter.close();
    cachedTransporter = null;
    cachedConfigHash = "";
  }
}
