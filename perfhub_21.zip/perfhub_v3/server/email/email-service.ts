import { db } from "../db";
import { emailSettings, emailLog } from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";
import { sendEmail, verifyConnection, clearTransporterCache } from "./email-provider";
import type { EmailAttachment } from "./email-provider";
import { buildTestResultEmail, buildSubjectLine, buildLiveSlaBbreachEmail, buildNewUserSignupEmail, formatDuration, formatDateTime } from "./email-templates";
import { generateHtmlReport } from "../report-generator";
import * as fs from "fs";
import * as path from "path";

const MAX_RETRIES = 3;
const RETRY_DELAYS = [2000, 5000, 15000];

function log(message: string, level: "info" | "error" | "warn" = "info") {
  const prefix = `[email-service]`;
  if (level === "error") console.error(`${prefix} ${message}`);
  else if (level === "warn") console.warn(`${prefix} ${message}`);
  else console.log(`${prefix} ${message}`);
}

export async function getEmailSettings() {
  const [settings] = await db.select().from(emailSettings).limit(1);
  return settings || null;
}

export async function saveEmailSettings(data: {
  smtpHost: string;
  smtpPort: number;
  senderEmail: string;
  senderPassword: string;
  defaultRecipients: string[];
  enabled: boolean;
  updatedBy: number;
}) {
  const existing = await getEmailSettings();
  if (existing) {
    const [updated] = await db.update(emailSettings)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(emailSettings.id, existing.id))
      .returning();
    clearTransporterCache();
    return updated;
  } else {
    const [created] = await db.insert(emailSettings).values(data).returning();
    return created;
  }
}

export async function testEmailConnection(): Promise<{ success: boolean; error?: string }> {
  const settings = await getEmailSettings();
  if (!settings) return { success: false, error: "Email settings not configured" };
  if (!settings.enabled) return { success: false, error: "Email notifications are disabled" };

  return verifyConnection({
    host: settings.smtpHost,
    port: settings.smtpPort,
    email: settings.senderEmail,
    password: settings.senderPassword,
  });
}

export async function sendTestEmail(recipientEmail: string): Promise<{ success: boolean; error?: string }> {
  const settings = await getEmailSettings();
  if (!settings) return { success: false, error: "Email settings not configured" };

  const html = buildTestResultEmail({
    testName: "Sample Test — Connection Verification",
    executionId: "EXE-SAMPLE-001",
    environment: "Staging",
    status: "PASS",
    startTime: formatDateTime(new Date().toISOString()),
    endTime: formatDateTime(new Date().toISOString()),
    duration: "1m 30s",
    totalRequests: 1500,
    successfulRequests: 1485,
    failedRequests: 15,
    errorRate: "1.00%",
    errorRateNum: 0.01,
    avgResponseTime: "245ms",
    avgResponseTimeMs: 245,
    p50: "198ms",
    p90: "412ms",
    p95: "512ms",
    p99: "890ms",
    throughput: "25 rps",
    throughputNum: 25,
    peakRps: 32,
    dashboardLink: "#",
    transactions: [
      { label: "Login", avg: 198, p95: 310, p99: 450, errorRate: 0, count: 500, throughput: 8.3 },
      { label: "Search Products", avg: 245, p95: 512, p99: 890, errorRate: 0.005, count: 500, throughput: 8.3 },
      { label: "Checkout", avg: 312, p95: 680, p99: 1100, errorRate: 0.025, count: 500, throughput: 8.3 },
    ],
  });

  return sendEmail(
    {
      host: settings.smtpHost,
      port: settings.smtpPort,
      email: settings.senderEmail,
      password: settings.senderPassword,
    },
    [recipientEmail],
    "\u2705 [PerfHub] Test Email — Connection Verified",
    html,
  );
}

function validateEmails(emails: string[]): string[] {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emails.filter(e => emailRegex.test(e.trim()));
}

async function isDuplicateEmail(executionId: number, eventType: string): Promise<boolean> {
  const [existing] = await db.select()
    .from(emailLog)
    .where(and(
      eq(emailLog.executionId, executionId),
      eq(emailLog.eventType, eventType),
      eq(emailLog.status, "sent"),
    ))
    .limit(1);
  return !!existing;
}

async function createLogEntry(executionId: number, eventType: string, recipients: string[], subject: string) {
  const [entry] = await db.insert(emailLog).values({
    executionId,
    eventType,
    recipients,
    subject,
    status: "pending",
    attempts: 0,
  }).returning();
  return entry;
}

async function updateLogEntry(id: number, updates: { status: string; attempts: number; lastError?: string; sentAt?: Date }) {
  await db.update(emailLog)
    .set(updates)
    .where(eq(emailLog.id, id));
}

async function sendWithRetry(
  config: { host: string; port: number; email: string; password: string },
  recipients: string[],
  subject: string,
  html: string,
  logId: number,
  attachments?: EmailAttachment[],
) {
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    const result = await sendEmail(config, recipients, subject, html, attachments);

    if (result.success) {
      await updateLogEntry(logId, { status: "sent", attempts: attempt, sentAt: new Date() });
      log(`Email sent successfully (attempt ${attempt}): ${subject}`);
      return;
    }

    log(`Send attempt ${attempt}/${MAX_RETRIES} failed: ${result.error}`, "warn");
    await updateLogEntry(logId, { status: "retrying", attempts: attempt, lastError: result.error });

    if (attempt < MAX_RETRIES) {
      await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt - 1]));
    } else {
      await updateLogEntry(logId, { status: "failed", attempts: attempt, lastError: result.error });
      log(`Email delivery failed after ${MAX_RETRIES} attempts: ${subject}`, "error");
    }
  }
}

function tryGetOrGenerateReport(execution: any): { filePath: string } | null {
  try {
    if (!execution) return null;

    if (execution.reportHtmlPath) {
      const existingPath = path.join(process.cwd(), "attached_assets", execution.reportHtmlPath.replace(/^\//, ""));
      if (fs.existsSync(existingPath)) {
        log(`Using existing HTML report for attachment: ${execution.reportHtmlPath}`);
        return { filePath: existingPath };
      }
    }

    if (!execution.schedule) return null;

    const html = generateHtmlReport(execution);
    const reportName = `report_email_${execution.id}_${Date.now()}.html`;
    const reportDir = path.join(process.cwd(), "attached_assets", "reports");
    fs.mkdirSync(reportDir, { recursive: true });
    const filePath = path.join(reportDir, reportName);
    fs.writeFileSync(filePath, html);
    log(`Generated HTML report for attachment: ${reportName}`);
    return { filePath };
  } catch (err) {
    log(`Could not generate HTML report for attachment: ${err}`, "warn");
    return null;
  }
}

export interface TestCompletionEmailData {
  executionId: number;
  testName: string;
  status: "completed" | "failed";
  startTime: string;
  endTime: string;
  resultSummary: any;
  slaViolations?: any;
  dashboardBaseUrl: string;
  scheduleConfig?: any;
  execution?: any;
}

export async function sendTestCompletionEmail(data: TestCompletionEmailData): Promise<void> {
  try {
    const settings = await getEmailSettings();
    if (!settings || !settings.enabled) return;

    const emailConfig = data.scheduleConfig?.emailNotification;
    const isSuccess = data.status === "completed";
    const isFail = data.status === "failed";
    const hasSlaViolations = data.slaViolations && (
      data.slaViolations.perTransaction?.length > 0 || data.slaViolations.global?.length > 0
    );

    const shouldSendOnSuccess = emailConfig?.sendOnSuccess ?? true;
    const shouldSendOnFailure = emailConfig?.sendOnFailure ?? true;
    const shouldSendOnSlaBreach = emailConfig?.sendOnSlaBreach ?? true;

    let eventType = isSuccess ? "test_success" : "test_failure";
    let shouldSend = false;

    if (isSuccess && shouldSendOnSuccess) shouldSend = true;
    if (isFail && shouldSendOnFailure) shouldSend = true;
    if (hasSlaViolations && shouldSendOnSlaBreach) {
      shouldSend = true;
      eventType = "sla_breach";
    }

    if (!shouldSend) {
      log(`Email skipped for execution ${data.executionId} (event: ${eventType}, toggles off)`);
      return;
    }

    const perTestRecipients = validateEmails(emailConfig?.recipients || []);
    const defaultRecipients = validateEmails(settings.defaultRecipients || []);
    const uniqueSet = new Set([...perTestRecipients, ...defaultRecipients]);
    const allRecipients = Array.from(uniqueSet);

    if (allRecipients.length === 0) {
      log(`No recipients configured for execution ${data.executionId}, skipping email`);
      return;
    }

    if (await isDuplicateEmail(data.executionId, eventType)) {
      log(`Duplicate email prevented for execution ${data.executionId}, event: ${eventType}`);
      return;
    }

    const summary = data.resultSummary || {};
    const totalReqs = summary.totalRequests || 0;
    const failedReqs = summary.failedRequests || 0;
    const successReqs = summary.successfulRequests ?? (totalReqs - failedReqs);
    const environment = data.scheduleConfig?.environment || "Unknown";

    const subject = buildSubjectLine(data.status, data.testName, !!hasSlaViolations);
    const dashboardLink = `${data.dashboardBaseUrl}/executions/${data.executionId}`;

    let slaViolationsList: Array<{ rule: string; threshold: string; actual: string }> | undefined;
    if (hasSlaViolations) {
      slaViolationsList = [];
      const violations = data.slaViolations.perTransaction || data.slaViolations.global || [];
      for (const v of violations) {
        slaViolationsList.push({
          rule: v.ruleName || v.label || v.metric || "SLA Rule",
          threshold: String(v.threshold ?? v.expected ?? ""),
          actual: String(v.actual ?? v.value ?? ""),
        });
      }
    }

    const transactions = summary.transactionDetails?.map((t: any) => ({
      label: t.label,
      avg: t.avg || 0,
      p95: t.p95 || 0,
      p99: t.p99 || 0,
      errorRate: t.errorRate || 0,
      count: t.count || 0,
      throughput: t.throughput || 0,
    })) || [];

    const errorDetails = summary.errorDetails?.map((e: any) => ({
      label: e.label || "Unknown",
      response_code: e.response_code || "N/A",
      count: e.count || 0,
      pct: e.pct || 0,
    })) || [];

    let reportAttachment: EmailAttachment | undefined;
    let hasReportAttachment = false;

    if (data.execution) {
      const report = tryGetOrGenerateReport(data.execution);
      if (report) {
        reportAttachment = {
          filename: `PerfHub_Report_${data.testName.replace(/[^a-zA-Z0-9_-]/g, "_")}.html`,
          path: report.filePath,
          contentType: "text/html",
        };
        hasReportAttachment = true;
      }
    }

    const html = buildTestResultEmail({
      testName: data.testName,
      executionId: `EXE-${data.executionId}`,
      environment,
      status: isSuccess && !hasSlaViolations ? "PASS" : "FAIL",
      startTime: formatDateTime(data.startTime),
      endTime: formatDateTime(data.endTime),
      duration: formatDuration(data.startTime, data.endTime),
      totalRequests: totalReqs,
      successfulRequests: successReqs,
      failedRequests: failedReqs,
      errorRate: `${((summary.errorRate || 0) * 100).toFixed(2)}%`,
      errorRateNum: summary.errorRate || 0,
      avgResponseTime: `${Math.round(summary.avgResponseTime || 0)}ms`,
      avgResponseTimeMs: summary.avgResponseTime || 0,
      p50: `${Math.round(summary.p50 || 0)}ms`,
      p90: `${Math.round(summary.p90 || 0)}ms`,
      p95: `${Math.round(summary.p95 || 0)}ms`,
      p99: `${Math.round(summary.p99 || 0)}ms`,
      throughput: `${(summary.throughput || 0).toFixed(1)} rps`,
      throughputNum: summary.throughput || 0,
      peakRps: summary.peakRps || 0,
      dashboardLink,
      slaViolations: slaViolationsList,
      transactions,
      errorDetails: errorDetails.length > 0 ? errorDetails : undefined,
      errorMessage: summary.error,
      hasReportAttachment,
    });

    const logEntry = await createLogEntry(data.executionId, eventType, allRecipients, subject);
    const attachments = reportAttachment ? [reportAttachment] : undefined;

    setImmediate(() => {
      sendWithRetry(
        {
          host: settings.smtpHost,
          port: settings.smtpPort,
          email: settings.senderEmail,
          password: settings.senderPassword,
        },
        allRecipients,
        subject,
        html,
        logEntry.id,
        attachments,
      ).catch(err => {
        log(`Unexpected error in email retry loop: ${err}`, "error");
      });
    });

    log(`Email queued for execution ${data.executionId} -> ${allRecipients.join(", ")}${hasReportAttachment ? " (with report)" : ""}`);
  } catch (err) {
    log(`Failed to queue email for execution ${data.executionId}: ${err}`, "error");
  }
}

export interface LiveSlaBreachEmailData {
  executionId: number;
  testName: string;
  environment: string;
  elapsedSeconds: number;
  dashboardBaseUrl: string;
  violations: Array<{ metric: string; threshold: string; actual: string; transaction?: string }>;
  currentMetrics: { avgResponseTime: number; p95: number; errorRate: number; throughput: number; totalRequests: number };
  scheduleConfig?: any;
}

export async function sendLiveSlaBbreachEmail(data: LiveSlaBreachEmailData): Promise<void> {
  try {
    const settings = await getEmailSettings();
    if (!settings || !settings.enabled) return;

    const emailConfig = data.scheduleConfig?.emailNotification;
    const shouldSendOnSlaBreach = emailConfig?.sendOnSlaBreach ?? true;
    if (!shouldSendOnSlaBreach) {
      log(`Live SLA breach email skipped (toggle off) for execution ${data.executionId}`);
      return;
    }

    const perTestRecipients = validateEmails(emailConfig?.recipients || []);
    const defaultRecipients = validateEmails(settings.defaultRecipients || []);
    const uniqueSet = new Set([...perTestRecipients, ...defaultRecipients]);
    const allRecipients = Array.from(uniqueSet);

    if (allRecipients.length === 0) {
      log(`No recipients for live SLA breach email, execution ${data.executionId}`);
      return;
    }

    const eventType = `live_sla_breach_${Date.now()}`;

    const dashboardLink = `${data.dashboardBaseUrl}/executions/${data.executionId}`;
    const subject = `\u26A0\uFE0F [PerfHub] LIVE SLA BREACH — ${data.testName}`;

    const html = buildLiveSlaBbreachEmail({
      testName: data.testName,
      executionId: `EXE-${data.executionId}`,
      environment: data.environment,
      elapsedSeconds: data.elapsedSeconds,
      dashboardLink,
      violations: data.violations,
      currentMetrics: data.currentMetrics,
    });

    const logEntry = await createLogEntry(data.executionId, eventType, allRecipients, subject);

    setImmediate(() => {
      sendWithRetry(
        {
          host: settings.smtpHost,
          port: settings.smtpPort,
          email: settings.senderEmail,
          password: settings.senderPassword,
        },
        allRecipients,
        subject,
        html,
        logEntry.id,
      ).catch(err => {
        log(`Unexpected error in live SLA breach email retry: ${err}`, "error");
      });
    });

    log(`Live SLA breach email queued for execution ${data.executionId} -> ${allRecipients.join(", ")}`);
  } catch (err) {
    log(`Failed to queue live SLA breach email for execution ${data.executionId}: ${err}`, "error");
  }
}

export async function getEmailLogs(limit = 50) {
  return db.select().from(emailLog).orderBy(desc(emailLog.createdAt)).limit(limit);
}

export async function sendNewUserSignupNotification(data: {
  newUsername: string;
  newEmail: string | null;
  appBaseUrl: string;
}) {
  try {
    const settings = await getEmailSettings();
    if (!settings || !settings.enabled) {
      log("Signup notification skipped — email not configured or disabled", "warn");
      return;
    }

    const { storage } = await import("../storage");
    const admins = await storage.getAdminUsers();
    const adminEmails = validateEmails(
      admins.map(a => a.email).filter((e): e is string => !!e)
    );

    const defaultRecipients = validateEmails(settings.defaultRecipients || []);
    const allRecipients = Array.from(new Set([...adminEmails, ...defaultRecipients]));

    if (allRecipients.length === 0) {
      log("Signup notification skipped — no admin emails or default recipients configured", "warn");
      return;
    }

    const subject = `👤 [PerfHub] New User Signup — ${data.newUsername} awaiting approval`;
    const html = buildNewUserSignupEmail({
      newUsername: data.newUsername,
      newEmail: data.newEmail,
      signupTime: formatDateTime(new Date().toISOString()),
      approvalLink: `${data.appBaseUrl}/admin/users`,
    });

    const config = {
      host: settings.smtpHost,
      port: settings.smtpPort,
      email: settings.senderEmail,
      password: settings.senderPassword,
    };

    setImmediate(async () => {
      try {
        const result = await sendEmail(config, allRecipients, subject, html);
        if (result.success) {
          log(`Signup notification sent for user "${data.newUsername}" -> ${allRecipients.join(", ")}`);
        } else {
          log(`Signup notification failed for user "${data.newUsername}": ${result.error}`, "error");
        }
      } catch (err) {
        log(`Signup notification error for user "${data.newUsername}": ${err}`, "error");
      }
    });

    log(`Signup notification queued for user "${data.newUsername}" -> ${allRecipients.join(", ")}`);
  } catch (err) {
    log(`Failed to queue signup notification for user "${data.newUsername}": ${err}`, "error");
  }
}
