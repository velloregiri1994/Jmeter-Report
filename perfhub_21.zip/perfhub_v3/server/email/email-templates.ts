interface TransactionDetail {
  label: string;
  avg: number;
  p95: number;
  p99: number;
  errorRate: number;
  count: number;
  throughput: number;
}

interface TestResultData {
  testName: string;
  executionId: string;
  environment: string;
  status: "PASS" | "FAIL";
  startTime: string;
  endTime: string;
  duration: string;
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  errorRate: string;
  errorRateNum: number;
  avgResponseTime: string;
  avgResponseTimeMs: number;
  p50: string;
  p90: string;
  p95: string;
  p99: string;
  throughput: string;
  throughputNum: number;
  peakRps: number;
  dashboardLink: string;
  slaViolations?: Array<{ rule: string; threshold: string; actual: string }>;
  transactions?: TransactionDetail[];
  errorDetails?: Array<{ label: string; response_code: string; count: number; pct: number }>;
  errorMessage?: string;
  hasReportAttachment?: boolean;
}

function esc(v: string | number | undefined): string {
  return String(v ?? "—")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function pctBar(pct: number, color: string): string {
  const width = Math.min(Math.max(pct, 0), 100);
  return `<div style="background:#e2e8f0;border-radius:4px;height:6px;width:100%;margin-top:4px;">
    <div style="background:${color};border-radius:4px;height:6px;width:${width}%;"></div>
  </div>`;
}

function ratingColor(ms: number): string {
  if (ms <= 200) return "#10b981";
  if (ms <= 500) return "#f59e0b";
  if (ms <= 1000) return "#f97316";
  return "#ef4444";
}

function errorRateColor(rate: number): string {
  if (rate === 0) return "#10b981";
  if (rate < 0.01) return "#f59e0b";
  return "#ef4444";
}

export function buildTestResultEmail(data: TestResultData): string {
  const isPassing = data.status === "PASS";
  const accentColor = isPassing ? "#10b981" : "#ef4444";
  const accentBg = isPassing ? "#ecfdf5" : "#fef2f2";
  const statusIcon = isPassing ? "&#10003;" : "&#10007;";
  const statusLabel = isPassing ? "PASSED" : "FAILED";

  const successRate = data.totalRequests > 0 ? ((data.successfulRequests / data.totalRequests) * 100) : 0;

  const transactionsSection = data.transactions && data.transactions.length > 0
    ? `<tr><td style="padding:0 32px 24px;">
        <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;">
          <tr>
            <td style="background:linear-gradient(135deg,#1e293b,#334155);padding:14px 18px;">
              <span style="color:#fff;font-size:14px;font-weight:700;letter-spacing:0.3px;">Transaction Breakdown</span>
              <span style="color:#94a3b8;font-size:12px;margin-left:8px;">${data.transactions.length} sampler${data.transactions.length !== 1 ? "s" : ""}</span>
            </td>
          </tr>
          <tr>
            <td style="padding:0;">
              <table width="100%" cellpadding="0" cellspacing="0" style="font-size:12px;">
                <tr style="background:#f8fafc;">
                  <td style="padding:10px 14px;font-weight:700;color:#475569;border-bottom:2px solid #e2e8f0;">Transaction</td>
                  <td style="padding:10px 10px;font-weight:700;color:#475569;border-bottom:2px solid #e2e8f0;text-align:right;">Count</td>
                  <td style="padding:10px 10px;font-weight:700;color:#475569;border-bottom:2px solid #e2e8f0;text-align:right;">Avg (ms)</td>
                  <td style="padding:10px 10px;font-weight:700;color:#475569;border-bottom:2px solid #e2e8f0;text-align:right;">P95 (ms)</td>
                  <td style="padding:10px 10px;font-weight:700;color:#475569;border-bottom:2px solid #e2e8f0;text-align:right;">P99 (ms)</td>
                  <td style="padding:10px 10px;font-weight:700;color:#475569;border-bottom:2px solid #e2e8f0;text-align:right;">Error %</td>
                  <td style="padding:10px 14px;font-weight:700;color:#475569;border-bottom:2px solid #e2e8f0;text-align:right;">RPS</td>
                </tr>
                ${data.transactions.map((t, i) => {
                  const rowBg = i % 2 === 0 ? "#ffffff" : "#f8fafc";
                  const errPct = (t.errorRate * 100);
                  const errColor = errorRateColor(t.errorRate);
                  const avgColor = ratingColor(t.avg);
                  return `<tr style="background:${rowBg};">
                    <td style="padding:9px 14px;border-bottom:1px solid #f1f5f9;color:#1e293b;font-weight:500;max-width:180px;overflow:hidden;text-overflow:ellipsis;">${esc(t.label)}</td>
                    <td style="padding:9px 10px;border-bottom:1px solid #f1f5f9;text-align:right;color:#64748b;">${t.count.toLocaleString()}</td>
                    <td style="padding:9px 10px;border-bottom:1px solid #f1f5f9;text-align:right;color:${avgColor};font-weight:600;">${Math.round(t.avg)}</td>
                    <td style="padding:9px 10px;border-bottom:1px solid #f1f5f9;text-align:right;color:#475569;">${Math.round(t.p95)}</td>
                    <td style="padding:9px 10px;border-bottom:1px solid #f1f5f9;text-align:right;color:#475569;">${Math.round(t.p99)}</td>
                    <td style="padding:9px 10px;border-bottom:1px solid #f1f5f9;text-align:right;color:${errColor};font-weight:${errPct > 0 ? '700' : '400'};">${errPct.toFixed(1)}%</td>
                    <td style="padding:9px 14px;border-bottom:1px solid #f1f5f9;text-align:right;color:#64748b;">${t.throughput.toFixed(1)}</td>
                  </tr>`;
                }).join("")}
              </table>
            </td>
          </tr>
        </table>
      </td></tr>`
    : "";

  const slaSection = data.slaViolations && data.slaViolations.length > 0
    ? `<tr><td style="padding:0 32px 24px;">
        <table width="100%" cellpadding="0" cellspacing="0" style="border:2px solid #ef4444;border-radius:10px;overflow:hidden;">
          <tr>
            <td style="background:linear-gradient(135deg,#991b1b,#dc2626);padding:12px 18px;">
              <span style="color:#fff;font-size:13px;font-weight:700;letter-spacing:0.5px;">&#9888; SLA VIOLATIONS</span>
              <span style="color:#fca5a5;font-size:12px;margin-left:6px;">${data.slaViolations.length} breach${data.slaViolations.length !== 1 ? "es" : ""}</span>
            </td>
          </tr>
          <tr>
            <td style="padding:0;">
              <table width="100%" cellpadding="0" cellspacing="0" style="font-size:12px;">
                <tr style="background:#fef2f2;">
                  <td style="padding:10px 14px;font-weight:700;color:#991b1b;border-bottom:1px solid #fecaca;">Rule</td>
                  <td style="padding:10px 14px;font-weight:700;color:#991b1b;border-bottom:1px solid #fecaca;text-align:right;">Threshold</td>
                  <td style="padding:10px 14px;font-weight:700;color:#991b1b;border-bottom:1px solid #fecaca;text-align:right;">Actual</td>
                </tr>
                ${data.slaViolations.map(v => `<tr>
                  <td style="padding:9px 14px;border-bottom:1px solid #fee2e2;color:#1e293b;">${esc(v.rule)}</td>
                  <td style="padding:9px 14px;border-bottom:1px solid #fee2e2;text-align:right;color:#64748b;">${esc(v.threshold)}</td>
                  <td style="padding:9px 14px;border-bottom:1px solid #fee2e2;text-align:right;color:#dc2626;font-weight:700;">${esc(v.actual)}</td>
                </tr>`).join("")}
              </table>
            </td>
          </tr>
        </table>
      </td></tr>`
    : "";

  const topErrorsSection = data.errorDetails && data.errorDetails.length > 0
    ? `<tr><td style="padding:0 32px 24px;">
        <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #fed7aa;border-radius:10px;overflow:hidden;">
          <tr>
            <td style="background:linear-gradient(135deg,#92400e,#d97706);padding:12px 18px;">
              <span style="color:#fff;font-size:13px;font-weight:700;">Top Errors</span>
            </td>
          </tr>
          <tr>
            <td style="padding:0;">
              <table width="100%" cellpadding="0" cellspacing="0" style="font-size:12px;">
                ${data.errorDetails.slice(0, 5).map((e, i) => {
                  const bg = i % 2 === 0 ? "#fffbeb" : "#ffffff";
                  return `<tr style="background:${bg};">
                    <td style="padding:9px 14px;border-bottom:1px solid #fef3c7;color:#1e293b;">${esc(e.label)}</td>
                    <td style="padding:9px 14px;border-bottom:1px solid #fef3c7;color:#92400e;text-align:center;white-space:nowrap;">${esc(e.response_code)}</td>
                    <td style="padding:9px 14px;border-bottom:1px solid #fef3c7;color:#92400e;text-align:right;font-weight:600;">${e.count} (${(e.pct * 100).toFixed(0)}%)</td>
                  </tr>`;
                }).join("")}
              </table>
            </td>
          </tr>
        </table>
      </td></tr>`
    : "";

  const errorMsgSection = data.errorMessage
    ? `<tr><td style="padding:0 32px 24px;">
        <table width="100%" cellpadding="0" cellspacing="0" style="background:#fef2f2;border:1px solid #fecaca;border-radius:10px;">
          <tr>
            <td style="padding:14px 18px;font-size:13px;">
              <strong style="color:#dc2626;">Error: </strong>
              <span style="color:#7f1d1d;">${esc(data.errorMessage)}</span>
            </td>
          </tr>
        </table>
      </td></tr>`
    : "";

  const attachmentNote = data.hasReportAttachment
    ? `<tr><td style="padding:0 32px 16px;">
        <table width="100%" cellpadding="0" cellspacing="0" style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;">
          <tr>
            <td style="padding:12px 18px;font-size:13px;color:#1e40af;">
              <strong>&#128206; Report Attached</strong> &mdash; Open the attached HTML file for the full interactive performance report with charts and detailed analysis.
            </td>
          </tr>
        </table>
      </td></tr>`
    : "";

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${esc(data.testName)} - Test Results</title>
  <!--[if mso]>
  <noscript>
    <xml>
      <o:OfficeDocumentSettings>
        <o:PixelsPerInch>96</o:PixelsPerInch>
      </o:OfficeDocumentSettings>
    </xml>
  </noscript>
  <![endif]-->
</head>
<body style="margin:0;padding:0;background-color:#f1f5f9;font-family:'Segoe UI',Roboto,Arial,Helvetica,sans-serif;-webkit-font-smoothing:antialiased;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f1f5f9;padding:32px 16px;">
    <tr>
      <td align="center">
        <table width="680" cellpadding="0" cellspacing="0" style="max-width:680px;width:100%;background-color:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">

          <!-- Header with gradient -->
          <tr>
            <td style="background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#334155 100%);padding:0;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="padding:28px 32px 12px;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td>
                          <span style="color:#3b82f6;font-size:11px;font-weight:800;letter-spacing:2px;text-transform:uppercase;">PerfHub</span>
                        </td>
                        <td align="right">
                          <span style="display:inline-block;background:${accentBg};color:${accentColor};padding:5px 14px;border-radius:20px;font-size:12px;font-weight:800;letter-spacing:0.5px;">
                            ${statusIcon} ${statusLabel}
                          </span>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding:4px 32px 6px;">
                    <h1 style="margin:0;color:#ffffff;font-size:22px;font-weight:700;line-height:1.3;">${esc(data.testName)}</h1>
                  </td>
                </tr>
                <tr>
                  <td style="padding:0 32px 24px;">
                    <table cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="padding-right:16px;">
                          <span style="color:#64748b;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;">ID</span><br>
                          <span style="color:#cbd5e1;font-size:13px;">${esc(data.executionId)}</span>
                        </td>
                        <td style="padding-right:16px;border-left:1px solid #475569;padding-left:16px;">
                          <span style="color:#64748b;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;">Environment</span><br>
                          <span style="color:#cbd5e1;font-size:13px;">${esc(data.environment)}</span>
                        </td>
                        <td style="border-left:1px solid #475569;padding-left:16px;">
                          <span style="color:#64748b;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;">Duration</span><br>
                          <span style="color:#cbd5e1;font-size:13px;font-weight:600;">${esc(data.duration)}</span>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Timing bar -->
          <tr>
            <td style="padding:20px 32px 4px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="color:#94a3b8;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;">Started</td>
                  <td style="color:#94a3b8;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;" align="right">Completed</td>
                </tr>
                <tr>
                  <td style="color:#334155;font-size:13px;padding-top:2px;">${esc(data.startTime)}</td>
                  <td style="color:#334155;font-size:13px;padding-top:2px;" align="right">${esc(data.endTime)}</td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Metrics cards row -->
          <tr>
            <td style="padding:20px 32px 24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <!-- Avg Response Time -->
                  <td width="24%" style="padding:16px 14px;background:#f8fafc;border-radius:12px;text-align:center;border:1px solid #e2e8f0;vertical-align:top;">
                    <div style="color:#94a3b8;font-size:10px;text-transform:uppercase;font-weight:700;letter-spacing:1px;">Avg Response</div>
                    <div style="color:${ratingColor(data.avgResponseTimeMs)};font-size:24px;font-weight:800;margin-top:6px;line-height:1;">${esc(data.avgResponseTime)}</div>
                    ${pctBar(Math.min((data.avgResponseTimeMs / 1000) * 100, 100), ratingColor(data.avgResponseTimeMs))}
                  </td>
                  <td width="2%"></td>
                  <!-- Throughput -->
                  <td width="24%" style="padding:16px 14px;background:#f8fafc;border-radius:12px;text-align:center;border:1px solid #e2e8f0;vertical-align:top;">
                    <div style="color:#94a3b8;font-size:10px;text-transform:uppercase;font-weight:700;letter-spacing:1px;">Throughput</div>
                    <div style="color:#3b82f6;font-size:24px;font-weight:800;margin-top:6px;line-height:1;">${esc(data.throughput)}</div>
                    <div style="color:#94a3b8;font-size:10px;margin-top:6px;">Peak: ${data.peakRps} rps</div>
                  </td>
                  <td width="2%"></td>
                  <!-- Error Rate -->
                  <td width="24%" style="padding:16px 14px;background:#f8fafc;border-radius:12px;text-align:center;border:1px solid #e2e8f0;vertical-align:top;">
                    <div style="color:#94a3b8;font-size:10px;text-transform:uppercase;font-weight:700;letter-spacing:1px;">Error Rate</div>
                    <div style="color:${errorRateColor(data.errorRateNum)};font-size:24px;font-weight:800;margin-top:6px;line-height:1;">${esc(data.errorRate)}</div>
                    <div style="color:#94a3b8;font-size:10px;margin-top:6px;">${data.failedRequests.toLocaleString()} / ${data.totalRequests.toLocaleString()}</div>
                  </td>
                  <td width="2%"></td>
                  <!-- Success Rate -->
                  <td width="24%" style="padding:16px 14px;background:#f8fafc;border-radius:12px;text-align:center;border:1px solid #e2e8f0;vertical-align:top;">
                    <div style="color:#94a3b8;font-size:10px;text-transform:uppercase;font-weight:700;letter-spacing:1px;">Success</div>
                    <div style="color:${successRate >= 99 ? '#10b981' : successRate >= 95 ? '#f59e0b' : '#ef4444'};font-size:24px;font-weight:800;margin-top:6px;line-height:1;">${successRate.toFixed(1)}%</div>
                    ${pctBar(successRate, successRate >= 99 ? '#10b981' : successRate >= 95 ? '#f59e0b' : '#ef4444')}
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Percentile metrics -->
          <tr>
            <td style="padding:0 32px 24px;">
              <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;">
                <tr style="background:linear-gradient(135deg,#1e293b,#334155);">
                  <td colspan="4" style="padding:12px 18px;">
                    <span style="color:#fff;font-size:13px;font-weight:700;letter-spacing:0.3px;">Response Time Percentiles</span>
                  </td>
                </tr>
                <tr style="background:#f8fafc;">
                  <td width="25%" style="padding:14px 18px;text-align:center;border-right:1px solid #e2e8f0;">
                    <div style="color:#94a3b8;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;">P50</div>
                    <div style="color:#1e293b;font-size:18px;font-weight:700;margin-top:4px;">${esc(data.p50)}</div>
                  </td>
                  <td width="25%" style="padding:14px 18px;text-align:center;border-right:1px solid #e2e8f0;">
                    <div style="color:#94a3b8;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;">P90</div>
                    <div style="color:#1e293b;font-size:18px;font-weight:700;margin-top:4px;">${esc(data.p90)}</div>
                  </td>
                  <td width="25%" style="padding:14px 18px;text-align:center;border-right:1px solid #e2e8f0;">
                    <div style="color:#94a3b8;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;">P95</div>
                    <div style="color:#1e293b;font-size:18px;font-weight:700;margin-top:4px;">${esc(data.p95)}</div>
                  </td>
                  <td width="25%" style="padding:14px 18px;text-align:center;">
                    <div style="color:#94a3b8;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;">P99</div>
                    <div style="color:#1e293b;font-size:18px;font-weight:700;margin-top:4px;">${esc(data.p99)}</div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          ${transactionsSection}
          ${slaSection}
          ${topErrorsSection}
          ${errorMsgSection}
          ${attachmentNote}

          <!-- CTA Button -->
          <tr>
            <td style="padding:8px 32px 32px;" align="center">
              <table cellpadding="0" cellspacing="0">
                <tr>
                  <td style="border-radius:10px;background:linear-gradient(135deg,#2563eb,#3b82f6);" align="center">
                    <a href="${data.dashboardLink}" style="display:inline-block;padding:14px 40px;color:#ffffff;text-decoration:none;font-size:14px;font-weight:700;letter-spacing:0.3px;">
                      View Full Dashboard &#8594;
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:20px 32px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td>
                    <span style="color:#3b82f6;font-size:11px;font-weight:800;letter-spacing:1.5px;">PERFHUB</span>
                    <span style="color:#cbd5e1;font-size:11px;margin-left:4px;">Performance Engineering Platform</span>
                  </td>
                  <td align="right">
                    <span style="color:#94a3b8;font-size:11px;">Automated notification</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

export function buildSubjectLine(status: string, testName: string, hasSlaViolations?: boolean): string {
  let statusLabel: string;
  if (hasSlaViolations) {
    statusLabel = "SLA BREACH";
  } else if (status === "completed") {
    statusLabel = "PASSED";
  } else if (status === "failed") {
    statusLabel = "FAILED";
  } else {
    statusLabel = status.toUpperCase();
  }
  const icon = status === "completed" && !hasSlaViolations ? "\u2705" : "\u274C";
  return `${icon} [PerfHub] ${statusLabel} — ${testName}`;
}

export function buildLiveSlaBbreachEmail(data: {
  testName: string;
  executionId: string;
  environment: string;
  elapsedSeconds: number;
  dashboardLink: string;
  violations: Array<{ metric: string; threshold: string; actual: string; transaction?: string }>;
  currentMetrics: { avgResponseTime: number; p95: number; errorRate: number; throughput: number; totalRequests: number };
}): string {
  const elapsed = data.elapsedSeconds >= 60
    ? `${Math.floor(data.elapsedSeconds / 60)}m ${data.elapsedSeconds % 60}s`
    : `${data.elapsedSeconds}s`;

  const violationRows = data.violations.map(v => `<tr>
    <td style="padding:8px 12px;border-bottom:1px solid #334155;color:#f1f5f9;font-size:13px;">${esc(v.transaction || "Overall")}</td>
    <td style="padding:8px 12px;border-bottom:1px solid #334155;color:#f1f5f9;font-size:13px;">${esc(v.metric)}</td>
    <td style="padding:8px 12px;border-bottom:1px solid #334155;color:#fca5a5;font-size:13px;">${esc(v.actual)}</td>
    <td style="padding:8px 12px;border-bottom:1px solid #334155;color:#86efac;font-size:13px;">${esc(v.threshold)}</td>
  </tr>`).join("");

  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>
<body style="margin:0;padding:0;background:#0f172a;font-family:Arial,Helvetica,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0f172a;padding:20px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#1e293b;border-radius:12px;overflow:hidden;border:1px solid #334155;">
        <tr><td style="background:linear-gradient(135deg,#dc2626,#b91c1c);padding:24px 32px;">
          <h1 style="margin:0;color:#fff;font-size:20px;">&#x26A0;&#xFE0F; Live SLA Breach Alert</h1>
          <p style="margin:6px 0 0;color:#fecaca;font-size:14px;">Test is still running — SLA thresholds exceeded</p>
        </td></tr>
        <tr><td style="padding:24px 32px;">
          <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:20px;">
            <tr><td style="color:#94a3b8;font-size:12px;padding:4px 0;">Test Name</td><td style="color:#f1f5f9;font-size:14px;padding:4px 0;text-align:right;font-weight:bold;">${esc(data.testName)}</td></tr>
            <tr><td style="color:#94a3b8;font-size:12px;padding:4px 0;">Execution ID</td><td style="color:#f1f5f9;font-size:14px;padding:4px 0;text-align:right;">${esc(data.executionId)}</td></tr>
            <tr><td style="color:#94a3b8;font-size:12px;padding:4px 0;">Environment</td><td style="color:#f1f5f9;font-size:14px;padding:4px 0;text-align:right;">${esc(data.environment)}</td></tr>
            <tr><td style="color:#94a3b8;font-size:12px;padding:4px 0;">Elapsed</td><td style="color:#f1f5f9;font-size:14px;padding:4px 0;text-align:right;">${elapsed}</td></tr>
          </table>
          <h3 style="color:#fca5a5;font-size:14px;margin:16px 0 8px;border-bottom:1px solid #334155;padding-bottom:8px;">SLA Violations (${data.violations.length})</h3>
          <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #334155;border-radius:8px;overflow:hidden;">
            <tr style="background:#0f172a;">
              <th style="padding:8px 12px;color:#94a3b8;font-size:11px;text-align:left;">Transaction</th>
              <th style="padding:8px 12px;color:#94a3b8;font-size:11px;text-align:left;">Metric</th>
              <th style="padding:8px 12px;color:#94a3b8;font-size:11px;text-align:left;">Actual</th>
              <th style="padding:8px 12px;color:#94a3b8;font-size:11px;text-align:left;">Threshold</th>
            </tr>
            ${violationRows}
          </table>
          <h3 style="color:#94a3b8;font-size:14px;margin:20px 0 8px;border-bottom:1px solid #334155;padding-bottom:8px;">Current Metrics</h3>
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="padding:8px;text-align:center;background:#0f172a;border-radius:8px;margin:4px;">
                <div style="color:#94a3b8;font-size:10px;">AVG RT</div>
                <div style="color:#f1f5f9;font-size:18px;font-weight:bold;">${Math.round(data.currentMetrics.avgResponseTime)}ms</div>
              </td>
              <td width="8"></td>
              <td style="padding:8px;text-align:center;background:#0f172a;border-radius:8px;">
                <div style="color:#94a3b8;font-size:10px;">P95</div>
                <div style="color:#f1f5f9;font-size:18px;font-weight:bold;">${Math.round(data.currentMetrics.p95)}ms</div>
              </td>
              <td width="8"></td>
              <td style="padding:8px;text-align:center;background:#0f172a;border-radius:8px;">
                <div style="color:#94a3b8;font-size:10px;">ERROR RATE</div>
                <div style="color:${data.currentMetrics.errorRate > 5 ? '#fca5a5' : '#f1f5f9'};font-size:18px;font-weight:bold;">${data.currentMetrics.errorRate.toFixed(1)}%</div>
              </td>
              <td width="8"></td>
              <td style="padding:8px;text-align:center;background:#0f172a;border-radius:8px;">
                <div style="color:#94a3b8;font-size:10px;">THROUGHPUT</div>
                <div style="color:#f1f5f9;font-size:18px;font-weight:bold;">${data.currentMetrics.throughput.toFixed(1)} rps</div>
              </td>
            </tr>
          </table>
          <div style="margin-top:24px;text-align:center;">
            <a href="${esc(data.dashboardLink)}" style="display:inline-block;background:#3b82f6;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-size:14px;font-weight:bold;">View Live Dashboard</a>
          </div>
          <p style="color:#64748b;font-size:11px;margin-top:16px;text-align:center;">This is an automated mid-test alert. Final results will follow after test completion.</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

export function formatDuration(startTime: string, endTime: string): string {
  const start = new Date(startTime).getTime();
  const end = new Date(endTime).getTime();
  const diffMs = end - start;
  if (diffMs < 0) return "N/A";
  const seconds = Math.floor(diffMs / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  const remainingSeconds = seconds % 60;
  if (hours > 0) return `${hours}h ${remainingMinutes}m ${remainingSeconds}s`;
  if (minutes > 0) return `${minutes}m ${remainingSeconds}s`;
  return `${seconds}s`;
}

export function formatDateTime(isoString: string): string {
  try {
    const d = new Date(isoString);
    return d.toLocaleString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    });
  } catch {
    return isoString;
  }
}

export function buildNewUserSignupEmail(data: {
  newUsername: string;
  newEmail: string | null;
  signupTime: string;
  approvalLink: string;
}): string {
  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
<div style="max-width:560px;margin:32px auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
  <div style="background:linear-gradient(135deg,#2563eb,#1d4ed8);padding:28px 32px;text-align:center;">
    <h1 style="margin:0;color:#ffffff;font-size:20px;font-weight:700;">⚡ PerfHub V3</h1>
    <p style="margin:6px 0 0;color:rgba(255,255,255,0.85);font-size:13px;">New User Signup Notification</p>
  </div>
  <div style="padding:28px 32px;">
    <p style="margin:0 0 16px;color:#334155;font-size:15px;line-height:1.6;">
      A new user has signed up and is waiting for your approval.
    </p>
    <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px 20px;margin-bottom:20px;">
      <table style="width:100%;border-collapse:collapse;">
        <tr>
          <td style="padding:6px 0;color:#64748b;font-size:13px;width:110px;">Username</td>
          <td style="padding:6px 0;color:#1e293b;font-size:14px;font-weight:600;">${esc(data.newUsername)}</td>
        </tr>
        <tr>
          <td style="padding:6px 0;color:#64748b;font-size:13px;">Email</td>
          <td style="padding:6px 0;color:#1e293b;font-size:14px;">${data.newEmail ? esc(data.newEmail) : '<span style="color:#94a3b8;">Not provided</span>'}</td>
        </tr>
        <tr>
          <td style="padding:6px 0;color:#64748b;font-size:13px;">Signed Up</td>
          <td style="padding:6px 0;color:#1e293b;font-size:14px;">${esc(data.signupTime)}</td>
        </tr>
        <tr>
          <td style="padding:6px 0;color:#64748b;font-size:13px;">Status</td>
          <td style="padding:6px 0;"><span style="background:#fef3c7;color:#92400e;padding:2px 10px;border-radius:12px;font-size:12px;font-weight:600;">PENDING APPROVAL</span></td>
        </tr>
      </table>
    </div>
    <div style="text-align:center;margin:24px 0;">
      <a href="${esc(data.approvalLink)}" style="display:inline-block;background:#2563eb;color:#ffffff;text-decoration:none;padding:12px 32px;border-radius:8px;font-size:14px;font-weight:600;">
        Review & Approve User
      </a>
    </div>
    <p style="margin:16px 0 0;color:#94a3b8;font-size:12px;text-align:center;">
      You can also approve this user from the Admin &rarr; User Management section in PerfHub.
    </p>
  </div>
  <div style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:16px 32px;text-align:center;">
    <p style="margin:0;color:#94a3b8;font-size:11px;">This is an automated notification from PerfHub V3</p>
  </div>
</div>
</body>
</html>`;
}
