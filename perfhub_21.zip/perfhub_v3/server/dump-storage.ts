import { db } from "./db";
import {
  dumpFiles, dumpAnalysis, dumpComparisons, dumpAnnotations, dumpBookmarks,
  type InsertDumpFile, type InsertDumpAnalysis, type InsertDumpComparison,
  type InsertDumpAnnotation, type InsertDumpBookmark,
  type DumpFile, type DumpAnalysis, type DumpComparison, type DumpFileWithAnalysis,
  type DumpAnnotation, type DumpBookmark
} from "@shared/schema";
import { eq, desc, inArray, and } from "drizzle-orm";

export async function getDumpFiles(): Promise<DumpFile[]> {
  return await db.select().from(dumpFiles).orderBy(desc(dumpFiles.createdAt));
}

export async function getDumpFile(id: number): Promise<DumpFile | undefined> {
  const [file] = await db.select().from(dumpFiles).where(eq(dumpFiles.id, id));
  return file;
}

export async function getDumpFileWithAnalysis(id: number): Promise<DumpFileWithAnalysis | undefined> {
  const [file] = await db.select().from(dumpFiles).where(eq(dumpFiles.id, id));
  if (!file) return undefined;
  
  const analyses = await db.select().from(dumpAnalysis).where(eq(dumpAnalysis.dumpFileId, id));
  
  return {
    ...file,
    analyses,
    uploader: { id: file.uploadedBy, username: 'user', email: '', password: '', role: 'engineer', isApproved: true, createdAt: null }
  };
}

export async function createDumpFile(data: InsertDumpFile): Promise<DumpFile> {
  const [file] = await db.insert(dumpFiles).values(data).returning();
  return file;
}

export async function updateDumpFile(id: number, updates: Partial<InsertDumpFile>): Promise<DumpFile> {
  const [file] = await db.update(dumpFiles).set(updates).where(eq(dumpFiles.id, id)).returning();
  return file;
}

export async function deleteDumpFile(id: number): Promise<void> {
  await db.delete(dumpAnalysis).where(eq(dumpAnalysis.dumpFileId, id));
  await db.delete(dumpFiles).where(eq(dumpFiles.id, id));
}

export async function getAnalysis(dumpFileId: number): Promise<DumpAnalysis | undefined> {
  const [analysis] = await db.select().from(dumpAnalysis).where(eq(dumpAnalysis.dumpFileId, dumpFileId));
  return analysis;
}

export async function createAnalysis(data: InsertDumpAnalysis): Promise<DumpAnalysis> {
  const [analysis] = await db.insert(dumpAnalysis).values(data).returning();
  return analysis;
}

export async function updateAnalysis(id: number, updates: Partial<InsertDumpAnalysis>): Promise<DumpAnalysis> {
  const [analysis] = await db.update(dumpAnalysis).set(updates).where(eq(dumpAnalysis.id, id)).returning();
  return analysis;
}

export async function getDumpComparisons(): Promise<DumpComparison[]> {
  return await db.select().from(dumpComparisons).orderBy(desc(dumpComparisons.createdAt));
}

export async function getDumpComparison(id: number): Promise<DumpComparison | undefined> {
  const [comparison] = await db.select().from(dumpComparisons).where(eq(dumpComparisons.id, id));
  return comparison;
}

export async function createDumpComparison(data: InsertDumpComparison): Promise<DumpComparison> {
  const [comparison] = await db.insert(dumpComparisons).values(data).returning();
  return comparison;
}

export async function deleteDumpComparison(id: number): Promise<void> {
  await db.delete(dumpComparisons).where(eq(dumpComparisons.id, id));
}

export async function getDumpFilesByIds(ids: number[]): Promise<DumpFile[]> {
  if (ids.length === 0) return [];
  return await db.select().from(dumpFiles).where(inArray(dumpFiles.id, ids));
}

export async function getAnalysesByDumpIds(dumpIds: number[]): Promise<DumpAnalysis[]> {
  if (dumpIds.length === 0) return [];
  return await db.select().from(dumpAnalysis).where(inArray(dumpAnalysis.dumpFileId, dumpIds));
}

export async function getAnnotations(dumpFileId: number): Promise<DumpAnnotation[]> {
  return await db.select().from(dumpAnnotations).where(eq(dumpAnnotations.dumpFileId, dumpFileId)).orderBy(desc(dumpAnnotations.createdAt));
}

export async function createAnnotation(data: InsertDumpAnnotation): Promise<DumpAnnotation> {
  const [annotation] = await db.insert(dumpAnnotations).values(data).returning();
  return annotation;
}

export async function deleteAnnotation(id: number): Promise<void> {
  await db.delete(dumpAnnotations).where(eq(dumpAnnotations.id, id));
}

export async function getBookmarks(dumpFileId: number): Promise<DumpBookmark[]> {
  return await db.select().from(dumpBookmarks).where(eq(dumpBookmarks.dumpFileId, dumpFileId)).orderBy(desc(dumpBookmarks.createdAt));
}

export async function createBookmark(data: InsertDumpBookmark): Promise<DumpBookmark> {
  const [bookmark] = await db.insert(dumpBookmarks).values(data).returning();
  return bookmark;
}

export async function deleteBookmark(id: number): Promise<void> {
  await db.delete(dumpBookmarks).where(eq(dumpBookmarks.id, id));
}

export async function toggleBookmark(dumpFileId: number, threadName: string, userId: number): Promise<{ bookmarked: boolean; bookmark?: DumpBookmark }> {
  const [existing] = await db.select().from(dumpBookmarks).where(
    and(eq(dumpBookmarks.dumpFileId, dumpFileId), eq(dumpBookmarks.threadName, threadName), eq(dumpBookmarks.createdBy, userId))
  );
  if (existing) {
    await db.delete(dumpBookmarks).where(eq(dumpBookmarks.id, existing.id));
    return { bookmarked: false };
  }
  const [bookmark] = await db.insert(dumpBookmarks).values({ dumpFileId, threadName, createdBy: userId }).returning();
  return { bookmarked: true, bookmark };
}
