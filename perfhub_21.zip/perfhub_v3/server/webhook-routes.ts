import { type Express } from "express";
import { db } from "./db";
import { webhooks, webhookDeliveries } from "@shared/schema";
import { eq, desc, and } from "drizzle-orm";
import { requireAuth, requireEngineerOrAdmin, requireAdmin } from "./route-middleware";
import { validate, z, idParam } from "./validation";
import { logAudit } from "./audit-logger";
import { dispatchWebhookEvent, deliverToWebhook, WEBHOOK_EVENTS } from "./webhook-dispatcher";
import { asyncHandler } from "./error-handler";

const BLOCKED_HOSTS = new Set([
  "localhost", "0.0.0.0", "::1", "::0",
  "metadata.google.internal", "metadata.google",
  "169.254.169.254", "metadata",
]);

function isPrivateOrReservedIP(hostname: string): boolean {
  const parts = hostname.split(".").map(Number);
  if (parts.length === 4 && parts.every(n => !isNaN(n) && n >= 0 && n <= 255)) {
    const [a, b] = parts;
    if (a === 127) return true;
    if (a === 10) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 169 && b === 254) return true;
    if (a === 0) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    if (a === 198 && (b === 18 || b === 19)) return true;
    if (a >= 224) return true;
  }
  if (hostname.includes(":")) {
    const lower = hostname.replace(/\[|\]/g, "").toLowerCase();
    if (lower.startsWith("fe80")) return true;
    if (lower.startsWith("fc") || lower.startsWith("fd")) return true;
    if (lower === "::1" || lower === "::0" || lower === "::") return true;
    if (lower.startsWith("::ffff:")) return true;
  }
  return false;
}

function isUrlSafe(urlStr: string): boolean {
  try {
    const parsed = new URL(urlStr);
    if (!["https:", "http:"].includes(parsed.protocol)) return false;
    const hostname = parsed.hostname.toLowerCase();
    if (BLOCKED_HOSTS.has(hostname)) return false;
    if (isPrivateOrReservedIP(hostname)) return false;
    if (hostname.endsWith(".local") || hostname.endsWith(".internal") || hostname.endsWith(".localhost")) return false;
    if (!hostname.includes(".") && !hostname.includes(":")) return false;
    return true;
  } catch {
    return false;
  }
}

export function registerWebhookRoutes(app: Express): void {

  app.get("/api/webhooks", requireAuth, asyncHandler(async (req, res) => {
    const allWebhooks = await db.select().from(webhooks).orderBy(desc(webhooks.createdAt));
    res.json(allWebhooks);
  }));

  app.get("/api/webhook-events", requireAuth, asyncHandler(async (req, res) => {
    res.json(Object.values(WEBHOOK_EVENTS));
  }));

  app.get("/api/webhooks/:id", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const [webhook] = await db.select().from(webhooks).where(eq(webhooks.id, id));
    if (!webhook) return res.status(404).json({ message: "Webhook not found" });
    res.json(webhook);
  }));

  app.post("/api/webhooks", requireEngineerOrAdmin, validate({
    body: z.object({
      name: z.string().min(1, "Name is required"),
      url: z.string().url("Must be a valid URL"),
      type: z.enum(["slack", "teams", "pagerduty", "generic"], { message: "Invalid webhook type" }),
      events: z.array(z.string()).min(1, "At least one event is required"),
      enabled: z.boolean().optional(),
      secret: z.string().optional(),
      headers: z.record(z.string()).optional(),
    }),
  }), asyncHandler(async (req, res) => {
    const sessionUser = (req.session as any).user;
    const { name, url, type, events, enabled, secret, headers } = req.body;

    if (!isUrlSafe(url)) {
      return res.status(400).json({ message: "Webhook URL targets a blocked or internal address" });
    }

    const [webhook] = await db.insert(webhooks).values({
      name,
      url,
      type,
      events,
      enabled: enabled ?? true,
      secret: secret || null,
      headers: headers || null,
      createdBy: sessionUser.id,
    }).returning();

    logAudit(req, "webhook_create", "webhook", webhook.id, { name, type });
    res.status(201).json(webhook);
  }));

  app.patch("/api/webhooks/:id", requireEngineerOrAdmin, validate({
    params: idParam,
    body: z.object({
      name: z.string().min(1).optional(),
      url: z.string().url().optional(),
      type: z.enum(["slack", "teams", "pagerduty", "generic"]).optional(),
      events: z.array(z.string()).optional(),
      enabled: z.boolean().optional(),
      secret: z.string().optional().nullable(),
      headers: z.record(z.string()).optional().nullable(),
    }),
  }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const [existing] = await db.select().from(webhooks).where(eq(webhooks.id, id));
    if (!existing) return res.status(404).json({ message: "Webhook not found" });

    if (req.body.url && !isUrlSafe(req.body.url)) {
      return res.status(400).json({ message: "Webhook URL targets a blocked or internal address" });
    }

    const updates: any = { ...req.body, updatedAt: new Date().toISOString() };

    const [updated] = await db.update(webhooks).set(updates).where(eq(webhooks.id, id)).returning();
    logAudit(req, "webhook_update", "webhook", id);
    res.json(updated);
  }));

  app.delete("/api/webhooks/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const [existing] = await db.select().from(webhooks).where(eq(webhooks.id, id));
    if (!existing) return res.status(404).json({ message: "Webhook not found" });

    await db.delete(webhooks).where(eq(webhooks.id, id));
    logAudit(req, "webhook_delete", "webhook", id, { name: existing.name });
    res.json({ message: "Webhook deleted" });
  }));

  app.post("/api/webhooks/:id/test", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const [webhook] = await db.select().from(webhooks).where(eq(webhooks.id, id));
    if (!webhook) return res.status(404).json({ message: "Webhook not found" });

    const testPayload = {
      event: "test",
      message: "Test webhook delivery from PerfHub",
      timestamp: new Date().toISOString(),
    };

    await deliverToWebhook(webhook, "test", testPayload);
    logAudit(req, "webhook_test", "webhook", id);
    res.json({ message: "Test delivery sent", payload: testPayload });
  }));

  app.get("/api/webhooks/:id/deliveries", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const id = req.params.id as unknown as number;
    const deliveries = await db
      .select()
      .from(webhookDeliveries)
      .where(eq(webhookDeliveries.webhookId, id))
      .orderBy(desc(webhookDeliveries.deliveredAt))
      .limit(50);
    res.json(deliveries);
  }));
}
