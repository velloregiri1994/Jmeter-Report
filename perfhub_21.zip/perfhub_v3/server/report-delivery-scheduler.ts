import { db } from "./db";
import { reportDeliverySchedules, testExecutions, testSchedules, scripts, emailSettings } from "@shared/schema";
import { eq, and, lte, gte, desc, isNotNull } from "drizzle-orm";
import { sendEmail } from "./email/email-provider";
import { generateHtmlReport } from "./report-generator";
import { computeNextRun } from "./report-delivery-routes";
import * as fs from "fs";
import * as path from "path";
import { format } from "date-fns";

const CHECK_INTERVAL_MS = 60_000;
let schedulerInterval: NodeJS.Timeout | null = null;

function log(msg: string, level: "info" | "error" | "warn" = "info") {
  const prefix = "[report-delivery]";
  if (level === "error") console.error(`${prefix} ${msg}`);
  else if (level === "warn") console.warn(`${prefix} ${msg}`);
  else console.log(`${prefix} ${msg}`);
}

export function startReportDeliveryScheduler() {
  if (schedulerInterval) return;
  log("Report delivery scheduler started");
  schedulerInterval = setInterval(checkDueSchedules, CHECK_INTERVAL_MS);
  setTimeout(checkDueSchedules, 5000);
}

async function checkDueSchedules() {
  try {
    const now = new Date();
    const dueSchedules = await db.select()
      .from(reportDeliverySchedules)
      .where(
        and(
          eq(reportDeliverySchedules.enabled, true),
          lte(reportDeliverySchedules.nextRunAt, now.toISOString())
        )
      );

    for (const schedule of dueSchedules) {
      try {
        await processSchedule(schedule);
      } catch (err: any) {
        log(`Failed to process schedule ${schedule.id}: ${err.message}`, "error");
      }
    }
  } catch (err: any) {
    log(`Scheduler tick error: ${err.message}`, "error");
  }
}

async function processSchedule(schedule: any) {
  log(`Processing report delivery: "${schedule.name}" (ID: ${schedule.id})`);

  const settings = await db.select().from(emailSettings).limit(1);
  const emailConfig = settings[0];
  if (!emailConfig || !emailConfig.enabled) {
    log("Email not configured or disabled, skipping delivery", "warn");
    return;
  }

  const sinceDate = schedule.lastSentAt ? new Date(schedule.lastSentAt) : new Date(Date.now() - getPeriodMs(schedule.frequency));

  let query = db.select({
    execution: testExecutions,
    schedule: testSchedules,
    script: scripts,
  })
    .from(testExecutions)
    .leftJoin(testSchedules, eq(testExecutions.scheduleId, testSchedules.id))
    .leftJoin(scripts, eq(testSchedules.scriptId, scripts.id))
    .where(
      and(
        eq(testExecutions.status, "completed"),
        gte(testExecutions.endTime, sinceDate.toISOString())
      )
    )
    .orderBy(desc(testExecutions.endTime))
    .limit(50);

  const results = await query;

  let executions = results.map(r => ({
    ...r.execution,
    scheduleName: r.schedule?.name || "Unknown",
    scriptName: r.script?.name || "Unknown",
    environment: (r.schedule?.configuration as any)?.environment || "N/A",
  }));

  const filters = schedule.filters as any;
  if (filters?.environment) {
    executions = executions.filter(e => e.environment === filters.environment);
  }

  if (executions.length === 0) {
    log(`No executions found for schedule "${schedule.name}" since ${sinceDate.toISOString()}`);
  }

  const html = buildDigestEmail(schedule, executions);

  const smtpConfig = {
    host: emailConfig.smtpHost,
    port: emailConfig.smtpPort,
    email: emailConfig.senderEmail,
    password: emailConfig.senderPassword,
  };

  let attachments: any[] = [];
  if (schedule.includeAttachments && executions.length > 0) {
    for (const exec of executions.slice(0, 5)) {
      if (exec.reportHtmlPath) {
        const filePath = path.join(process.cwd(), "attached_assets", exec.reportHtmlPath.replace(/^\//, ""));
        if (fs.existsSync(filePath)) {
          attachments.push({
            filename: `report-${exec.executionId || exec.id}.html`,
            path: filePath,
            contentType: "text/html",
          });
        }
      }
    }
  }

  const periodLabel = schedule.frequency === "daily" ? "Daily" : schedule.frequency === "weekly" ? "Weekly" : "Monthly";
  const subject = `${periodLabel} Performance Report Digest - ${schedule.name} (${executions.length} test${executions.length !== 1 ? "s" : ""})`;

  const result = await sendEmail(smtpConfig, schedule.recipients, subject, html, attachments.length > 0 ? attachments : undefined);

  if (result.success) {
    log(`Digest sent for "${schedule.name}" to ${schedule.recipients.length} recipients`);
  } else {
    log(`Failed to send digest for "${schedule.name}": ${result.error}`, "error");
  }

  const nextRun = computeNextRun(schedule.frequency, schedule.timeOfDay, schedule.timezone, schedule.dayOfWeek, schedule.dayOfMonth);
  await db.update(reportDeliverySchedules)
    .set({
      lastSentAt: new Date().toISOString(),
      nextRunAt: nextRun.toISOString(),
      updatedAt: new Date().toISOString(),
    })
    .where(eq(reportDeliverySchedules.id, schedule.id));
}

function getPeriodMs(frequency: string): number {
  switch (frequency) {
    case "daily": return 24 * 60 * 60 * 1000;
    case "weekly": return 7 * 24 * 60 * 60 * 1000;
    case "monthly": return 30 * 24 * 60 * 60 * 1000;
    default: return 7 * 24 * 60 * 60 * 1000;
  }
}

function buildDigestEmail(schedule: any, executions: any[]): string {
  const periodLabel = schedule.frequency === "daily" ? "Daily" : schedule.frequency === "weekly" ? "Weekly" : "Monthly";
  const now = format(new Date(), "MMM d, yyyy");

  let totalTests = executions.length;
  let totalRequests = 0;
  let totalFailed = 0;
  let avgResponseTime = 0;
  let rtCount = 0;

  for (const exec of executions) {
    const rs = exec.resultSummary as any;
    if (rs) {
      totalRequests += rs.totalRequests || 0;
      totalFailed += rs.failedRequests || 0;
      if (rs.avgResponseTime) {
        avgResponseTime += rs.avgResponseTime;
        rtCount++;
      }
    }
  }
  const overallAvgRT = rtCount > 0 ? (avgResponseTime / rtCount).toFixed(0) : "N/A";
  const overallErrorRate = totalRequests > 0 ? ((totalFailed / totalRequests) * 100).toFixed(2) : "0.00";

  const executionRows = executions.map((exec, i) => {
    const rs = exec.resultSummary as any;
    const successRate = rs?.totalRequests > 0 ? (((rs.totalRequests - (rs.failedRequests || 0)) / rs.totalRequests) * 100).toFixed(1) : "N/A";
    const endTime = exec.endTime ? format(new Date(exec.endTime), "MMM d, HH:mm") : "N/A";
    const errRate = rs?.errorRate != null ? (rs.errorRate * 100).toFixed(2) : "0.00";
    const rt = rs?.avgResponseTime ? Math.round(rs.avgResponseTime) : "N/A";
    const bgColor = i % 2 === 0 ? "#f8fafc" : "#ffffff";

    return `<tr style="background:${bgColor};">
      <td style="padding:10px 14px;font-size:13px;color:#1e293b;border-bottom:1px solid #e2e8f0;">${exec.scheduleName}</td>
      <td style="padding:10px 14px;font-size:13px;color:#64748b;border-bottom:1px solid #e2e8f0;">${exec.environment}</td>
      <td style="padding:10px 14px;font-size:13px;color:#64748b;border-bottom:1px solid #e2e8f0;">${endTime}</td>
      <td style="padding:10px 14px;font-size:13px;color:#1e293b;border-bottom:1px solid #e2e8f0;font-weight:600;">${successRate}%</td>
      <td style="padding:10px 14px;font-size:13px;color:${Number(errRate) > 5 ? '#ef4444' : '#64748b'};border-bottom:1px solid #e2e8f0;">${errRate}%</td>
      <td style="padding:10px 14px;font-size:13px;color:#64748b;border-bottom:1px solid #e2e8f0;">${rt}ms</td>
      <td style="padding:10px 14px;font-size:13px;color:#64748b;border-bottom:1px solid #e2e8f0;">${rs?.throughput ? rs.throughput.toFixed(1) : 'N/A'} rps</td>
    </tr>`;
  }).join("");

  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:32px 0;">
    <tr><td align="center">
      <table width="640" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
        <tr><td style="background:linear-gradient(135deg,#4f46e5,#7c3aed);padding:32px 40px;">
          <h1 style="margin:0;color:#fff;font-size:22px;font-weight:700;">&#128202; ${periodLabel} Performance Digest</h1>
          <p style="margin:6px 0 0;color:#c7d2fe;font-size:14px;">${schedule.name} &middot; ${now}</p>
        </td></tr>

        <tr><td style="padding:24px 40px 16px;">
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="background:#f0f9ff;border-radius:12px;padding:16px;text-align:center;width:25%;">
                <div style="color:#0369a1;font-size:24px;font-weight:700;">${totalTests}</div>
                <div style="color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;margin-top:4px;">Tests Run</div>
              </td>
              <td width="12"></td>
              <td style="background:#f0fdf4;border-radius:12px;padding:16px;text-align:center;width:25%;">
                <div style="color:#15803d;font-size:24px;font-weight:700;">${totalRequests.toLocaleString()}</div>
                <div style="color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;margin-top:4px;">Total Requests</div>
              </td>
              <td width="12"></td>
              <td style="background:${Number(overallErrorRate) > 5 ? '#fef2f2' : '#f0fdf4'};border-radius:12px;padding:16px;text-align:center;width:25%;">
                <div style="color:${Number(overallErrorRate) > 5 ? '#dc2626' : '#15803d'};font-size:24px;font-weight:700;">${overallErrorRate}%</div>
                <div style="color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;margin-top:4px;">Error Rate</div>
              </td>
              <td width="12"></td>
              <td style="background:#fefce8;border-radius:12px;padding:16px;text-align:center;width:25%;">
                <div style="color:#a16207;font-size:24px;font-weight:700;">${overallAvgRT}</div>
                <div style="color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;margin-top:4px;">Avg RT (ms)</div>
              </td>
            </tr>
          </table>
        </td></tr>

        ${executions.length > 0 ? `
        <tr><td style="padding:8px 40px 24px;">
          <h3 style="color:#1e293b;font-size:15px;margin:0 0 12px;font-weight:600;">Test Executions</h3>
          <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;">
            <tr style="background:#f8fafc;">
              <th style="padding:10px 14px;font-size:11px;color:#64748b;text-align:left;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">Test</th>
              <th style="padding:10px 14px;font-size:11px;color:#64748b;text-align:left;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">Env</th>
              <th style="padding:10px 14px;font-size:11px;color:#64748b;text-align:left;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">Completed</th>
              <th style="padding:10px 14px;font-size:11px;color:#64748b;text-align:left;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">Success</th>
              <th style="padding:10px 14px;font-size:11px;color:#64748b;text-align:left;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">Errors</th>
              <th style="padding:10px 14px;font-size:11px;color:#64748b;text-align:left;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">Avg RT</th>
              <th style="padding:10px 14px;font-size:11px;color:#64748b;text-align:left;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">Throughput</th>
            </tr>
            ${executionRows}
          </table>
        </td></tr>
        ` : `
        <tr><td style="padding:16px 40px 24px;text-align:center;">
          <p style="color:#94a3b8;font-size:14px;">No completed test executions in this period.</p>
        </td></tr>
        `}

        <tr><td style="padding:0 40px 24px;">
          <p style="color:#94a3b8;font-size:11px;text-align:center;margin:0;">
            This is an automated ${periodLabel.toLowerCase()} digest from PerfHub. Manage delivery settings in the HTML Reports section.
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
}
