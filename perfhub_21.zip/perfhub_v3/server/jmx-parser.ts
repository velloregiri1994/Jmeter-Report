import * as fs from "fs";
import * as path from "path";
import { XMLParser, XMLBuilder } from "fast-xml-parser";

export interface JMXConfig {
  threadCount: number;
  rampUpPeriod: number;
  loopCount: number;
  duration: number;
  schedulerEnabled: boolean;
  testName: string;
  threadGroups: ThreadGroupConfig[];
}

export interface ThreadGroupConfig {
  name: string;
  enabled: boolean;
  threadCount: number;
  rampUpPeriod: number;
  loopCount: number;
  duration: number;
  schedulerEnabled: boolean;
}

function getPropertyValue(props: any, propName: string, defaultValue: any = null): any {
  if (!props) return defaultValue;
  
  const propTypes = ['stringProp', 'intProp', 'longProp', 'boolProp'];
  
  for (const propType of propTypes) {
    const propList = props[propType];
    if (!propList) continue;
    
    const items = Array.isArray(propList) ? propList : [propList];
    for (const item of items) {
      if (item?.['@_name'] === propName) {
        const value = item['#text'] ?? item;
        if (propType === 'boolProp') {
          return String(value).toLowerCase() === 'true';
        }
        if (propType === 'intProp' || propType === 'longProp') {
          return parseInt(String(value), 10) || defaultValue;
        }
        return value;
      }
    }
  }
  
  return defaultValue;
}

function findThreadGroups(obj: any, results: any[] = []): any[] {
  if (!obj || typeof obj !== 'object') return results;
  
  const threadGroupTypes = [
    'ThreadGroup',
    'SetupThreadGroup', 
    'TearDownThreadGroup',
    'kg.apc.jmeter.threads.SteppingThreadGroup',
    'com.blazemeter.jmeter.threads.concurrency.ConcurrencyThreadGroup',
    'com.blazemeter.jmeter.threads.arrivals.ArrivalsThreadGroup'
  ];
  
  for (const tgType of threadGroupTypes) {
    if (obj[tgType]) {
      const groups = Array.isArray(obj[tgType]) ? obj[tgType] : [obj[tgType]];
      results.push(...groups);
    }
  }
  
  for (const key of Object.keys(obj)) {
    if (typeof obj[key] === 'object') {
      findThreadGroups(obj[key], results);
    }
  }
  
  return results;
}

function parseThreadGroup(tg: any): ThreadGroupConfig {
  const name = tg['@_testname'] || 'Thread Group';
  const enabled = tg['@_enabled'] !== 'false';
  
  let threadCount = 1;
  let rampUpPeriod = 1;
  let loopCount = 1;
  let duration = 0;
  let schedulerEnabled = false;
  
  threadCount = getPropertyValue(tg, 'ThreadGroup.num_threads', 1);
  if (threadCount === 1) {
    threadCount = getPropertyValue(tg, 'numThreads', 1);
  }
  
  rampUpPeriod = getPropertyValue(tg, 'ThreadGroup.ramp_time', 1);
  if (rampUpPeriod === 1) {
    rampUpPeriod = getPropertyValue(tg, 'rampUp', 1);
  }
  
  duration = getPropertyValue(tg, 'ThreadGroup.duration', 0);
  schedulerEnabled = getPropertyValue(tg, 'ThreadGroup.scheduler', false);
  
  const rawElementProp = tg.elementProp || tg.LoopController;
  if (rawElementProp) {
    const elementProps = Array.isArray(rawElementProp) ? rawElementProp : [rawElementProp];
    const loopController = elementProps.find((ep: any) =>
      ep?.['@_name'] === 'ThreadGroup.main_controller' ||
      ep?.['@_elementType'] === 'LoopController' ||
      (!ep?.['@_name'] && !ep?.['@_elementType'])
    ) || elementProps[0];
    if (loopController) {
      const loops = getPropertyValue(loopController, 'LoopController.loops', 1);
      loopCount = loops === -1 ? -1 : (parseInt(String(loops), 10) || 1);
    }
  }
  
  return {
    name,
    enabled,
    threadCount: parseInt(String(threadCount), 10) || 1,
    rampUpPeriod: parseInt(String(rampUpPeriod), 10) || 1,
    loopCount,
    duration: parseInt(String(duration), 10) || 0,
    schedulerEnabled
  };
}

function extractTestPlanName(parsed: any): string {
  if (parsed?.jmeterTestPlan?.hashTree?.TestPlan) {
    const testPlan = parsed.jmeterTestPlan.hashTree.TestPlan;
    return testPlan['@_testname'] || 'JMeter Test Plan';
  }
  return 'JMeter Test Plan';
}

export function parseJMXFile(filePath: string): JMXConfig | null {
  try {
    if (!fs.existsSync(filePath)) {
      console.log(`JMX file not found: ${filePath}`);
      return null;
    }
    
    const content = fs.readFileSync(filePath, "utf-8");
    return parseJMXContent(content);
  } catch (error) {
    console.error(`Error parsing JMX file: ${error}`);
    return null;
  }
}

export function parseJMXContent(content: string): JMXConfig | null {
  try {
    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: '@_',
      textNodeName: '#text',
      parseAttributeValue: false,
      parseTagValue: false
    });
    
    const parsed = parser.parse(content);
    const testName = extractTestPlanName(parsed);
    
    const rawThreadGroups = findThreadGroups(parsed);
    const threadGroups = rawThreadGroups.map(parseThreadGroup);
    
    if (threadGroups.length === 0) {
      console.log('No thread groups found in JMX file');
      return {
        threadCount: 1,
        rampUpPeriod: 1,
        loopCount: 1,
        duration: 60,
        schedulerEnabled: false,
        testName,
        threadGroups: []
      };
    }
    
    const enabledGroups = threadGroups.filter(g => g.enabled);
    const activeGroups = enabledGroups.length > 0 ? enabledGroups : threadGroups;
    
    const totalThreads = activeGroups.reduce((sum, g) => sum + g.threadCount, 0);
    const maxRampUp = Math.max(...activeGroups.map(g => g.rampUpPeriod));
    const maxDuration = Math.max(...activeGroups.map(g => g.duration));
    const hasScheduler = activeGroups.some(g => g.schedulerEnabled);
    
    let effectiveDuration = maxDuration;
    
    if (hasScheduler && effectiveDuration > 0) {
      effectiveDuration = maxDuration;
    } else {
      const finiteLoops = activeGroups.filter(g => g.loopCount !== -1);
      if (finiteLoops.length > 0) {
        const maxLoops = Math.max(...finiteLoops.map(g => g.loopCount));
        effectiveDuration = Math.max(30, maxLoops * 5 + maxRampUp);
      } else {
        effectiveDuration = 60;
      }
    }
    
    const totalLoops = activeGroups.reduce((sum, g) => {
      if (g.loopCount === -1) return sum;
      return sum + g.loopCount;
    }, 0);
    
    console.log(`Parsed JMX: ${totalThreads} threads, ${effectiveDuration}s duration, ${threadGroups.length} thread groups`);
    
    return {
      threadCount: totalThreads || 1,
      rampUpPeriod: maxRampUp || 1,
      loopCount: totalLoops || 1,
      duration: effectiveDuration,
      schedulerEnabled: hasScheduler,
      testName,
      threadGroups
    };
  } catch (error) {
    console.error(`Error parsing JMX content: ${error}`);
    return null;
  }
}

export interface TimerConfig {
  index: number;
  name: string;
  enabled: boolean;
  throughput: number;
  calcMode: number;
}

const CALC_MODE_LABELS: Record<number, string> = {
  0: 'This Thread Only',
  1: 'All Active Threads',
  2: 'All Threads in Current Thread Group',
  3: 'All Threads in Current Thread Group (shared)',
  4: 'All Active Threads (shared)',
  5: 'All Threads in Current Thread Group (shared)',
};

function findTimers(obj: any, results: any[] = []): any[] {
  if (!obj || typeof obj !== 'object') return results;

  if (obj['ConstantThroughputTimer']) {
    const timers = Array.isArray(obj['ConstantThroughputTimer'])
      ? obj['ConstantThroughputTimer']
      : [obj['ConstantThroughputTimer']];
    results.push(...timers);
  }

  for (const key of Object.keys(obj)) {
    if (typeof obj[key] === 'object') {
      findTimers(obj[key], results);
    }
  }

  return results;
}

function getDoublePropValue(obj: any, propName: string, defaultValue: number = 0): number {
  if (!obj) return defaultValue;

  const doubleProp = obj['doubleProp'];
  if (!doubleProp) return defaultValue;

  const items = Array.isArray(doubleProp) ? doubleProp : [doubleProp];
  for (const item of items) {
    if (item?.name === propName || item?.['@_name'] === propName) {
      const val = item.value ?? item['#text'] ?? item;
      const parsed = parseFloat(String(val));
      if (!isNaN(parsed)) return parsed;
    }
  }
  return defaultValue;
}

function setDoublePropValue(obj: any, propName: string, value: number): void {
  if (!obj) return;

  const doubleProp = obj['doubleProp'];
  if (!doubleProp) return;

  const items = Array.isArray(doubleProp) ? doubleProp : [doubleProp];
  for (const item of items) {
    if (item?.name === propName) {
      item.value = String(value);
      return;
    }
    if (item?.['@_name'] === propName) {
      item['#text'] = String(value);
      return;
    }
  }
}

function parseTimer(timer: any, index: number): TimerConfig {
  const name = timer['@_testname'] || 'Constant Throughput Timer';
  const enabled = timer['@_enabled'] !== 'false';
  const throughput = getDoublePropValue(timer, 'throughput', 0);
  const calcMode = parseInt(String(getPropertyValue(timer, 'calcMode', 0)), 10) || 0;

  return { index, name, enabled, throughput, calcMode };
}

export function parseTimersFromContent(content: string): { timers: TimerConfig[]; calcModeLabels: Record<number, string> } | null {
  try {
    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: '@_',
      textNodeName: '#text',
      parseAttributeValue: false,
      parseTagValue: false,
    });
    const parsed = parser.parse(content);
    const rawTimers = findTimers(parsed);
    const timers = rawTimers.map((t, i) => parseTimer(t, i));
    return { timers, calcModeLabels: CALC_MODE_LABELS };
  } catch (error) {
    console.error(`Error parsing timers: ${error}`);
    return null;
  }
}

export interface TimerUpdate {
  index: number;
  throughput: number;
  calcMode: number;
  enabled: boolean;
}

function findTimerRangesInText(xmlContent: string): { start: number; end: number }[] {
  const ranges: { start: number; end: number }[] = [];
  const tagPattern = /<ConstantThroughputTimer\s[^>]*>/g;
  const closingTag = '</ConstantThroughputTimer>';

  let match;
  while ((match = tagPattern.exec(xmlContent)) !== null) {
    const startPos = match.index;
    const endPos = xmlContent.indexOf(closingTag, startPos);
    if (endPos === -1) continue;
    ranges.push({ start: startPos, end: endPos + closingTag.length });
  }

  return ranges;
}

function replaceTimerPropertyInBlock(block: string, propName: string, newValue: any): string {
  const escaped = propName.replace(/\./g, '\\.');
  const propRegex = new RegExp(
    `(<(?:stringProp|intProp|longProp|boolProp)\\s+name="${escaped}"[^>]*>)([^<]*)(</(?:stringProp|intProp|longProp|boolProp)>)`,
    'g'
  );
  return block.replace(propRegex, `$1${String(newValue)}$3`);
}

function replaceDoublePropInBlock(block: string, propName: string, newValue: number): string {
  const escaped = propName.replace(/\./g, '\\.');
  const doublePropRegex = new RegExp(
    `(<doubleProp>\\s*<name>${escaped}</name>\\s*<value>)([^<]*)(</value>)`,
    'g'
  );
  let result = block.replace(doublePropRegex, `$1${String(newValue)}$3`);
  if (result === block) {
    const altRegex = new RegExp(
      `(<doubleProp\\s+name="${escaped}"[^>]*>)([^<]*)(</doubleProp>)`,
      'g'
    );
    result = block.replace(altRegex, `$1${String(newValue)}$3`);
  }
  return result;
}

function replaceEnabledAttr(block: string, tagName: string, enabled: boolean): string {
  const escaped = tagName.replace(/\./g, '\\.');
  const attrRegex = new RegExp(`(<${escaped}\\s[^>]*enabled=")([^"]*)(")`, '');
  return block.replace(attrRegex, `$1${String(enabled)}$3`);
}

export function updateTimersInXml(xmlContent: string, updates: TimerUpdate[]): string {
  const ranges = findTimerRangesInText(xmlContent);
  let result = xmlContent;
  let offset = 0;

  for (const update of updates) {
    if (update.index < 0 || update.index >= ranges.length) continue;

    const range = ranges[update.index];
    const adjustedStart = range.start + offset;
    const adjustedEnd = range.end + offset;
    let block = result.substring(adjustedStart, adjustedEnd);

    block = replaceDoublePropInBlock(block, 'throughput', update.throughput);
    block = replaceTimerPropertyInBlock(block, 'calcMode', update.calcMode);
    block = replaceEnabledAttr(block, 'ConstantThroughputTimer', update.enabled);

    const oldLength = adjustedEnd - adjustedStart;
    result = result.substring(0, adjustedStart) + block + result.substring(adjustedEnd);
    offset += block.length - oldLength;
  }

  return result;
}

export interface ThreadGroupUpdate {
  index: number;
  threadCount: number;
  rampUpPeriod: number;
  loopCount: number | -1;
  schedulerEnabled: boolean;
  duration: number;
}

function setPropertyValue(props: any, propName: string, value: any): void {
  if (!props) return;

  const propTypes = ['stringProp', 'intProp', 'longProp', 'boolProp'];

  for (const propType of propTypes) {
    const propList = props[propType];
    if (!propList) continue;

    const items = Array.isArray(propList) ? propList : [propList];
    for (const item of items) {
      if (item?.['@_name'] === propName) {
        item['#text'] = String(value);
        return;
      }
    }
  }
}

function applyThreadGroupUpdate(tg: any, update: ThreadGroupUpdate): void {
  setPropertyValue(tg, 'ThreadGroup.num_threads', update.threadCount);
  setPropertyValue(tg, 'numThreads', update.threadCount);
  setPropertyValue(tg, 'ThreadGroup.ramp_time', update.rampUpPeriod);
  setPropertyValue(tg, 'rampUp', update.rampUpPeriod);
  setPropertyValue(tg, 'ThreadGroup.scheduler', update.schedulerEnabled);
  setPropertyValue(tg, 'ThreadGroup.duration', update.duration);

  const loopController = tg.elementProp || tg.LoopController;
  if (loopController) {
    setPropertyValue(loopController, 'LoopController.loops', update.loopCount);
    setPropertyValue(loopController, 'LoopController.continue_forever', update.loopCount === -1);
  }
}

/** @deprecated Use updateThreadGroupWithAdapter from thread-group-adapters.ts instead. This function uses XMLBuilder which corrupts JMeter hashTree structure. */
export function updateThreadGroupsInXml(_xmlContent: string, _updates: ThreadGroupUpdate[]): string {
  throw new Error('updateThreadGroupsInXml is deprecated — use updateThreadGroupWithAdapter from thread-group-adapters.ts instead to avoid JMX corruption');
}

export interface PluginInfo {
  className: string;
  displayName: string;
  category: 'thread-group' | 'timer' | 'sampler' | 'listener' | 'assertion' | 'extractor' | 'controller' | 'config' | 'preprocessor' | 'postprocessor' | 'other';
  source: string;
  installed: 'unknown';
}

const CORE_JMETER_ELEMENTS = new Set([
  'ThreadGroup', 'SetupThreadGroup', 'TearDownThreadGroup',
  'TestPlan', 'hashTree',
  'HTTPSamplerProxy', 'FTPSampler', 'JDBCSampler', 'TCPSampler', 'JSR223Sampler', 'BeanShellSampler', 'JavaSampler', 'DebugSampler', 'SmtpSampler', 'JMSSampler', 'LDAPExtSampler', 'MailReaderSampler',
  'LoopController', 'IfController', 'WhileController', 'ForEachController', 'TransactionController', 'IncludeController', 'ModuleController', 'OnceOnlyController', 'InterleaveController', 'RandomController', 'RandomOrderController', 'ThroughputController', 'SwitchController', 'RuntimeController', 'CriticalSectionController',
  'ConstantTimer', 'UniformRandomTimer', 'GaussianRandomTimer', 'PoissonRandomTimer', 'ConstantThroughputTimer', 'SynchronizingTimer', 'BeanShellTimer', 'JSR223Timer', 'PreciseThroughputTimer',
  'ResponseAssertion', 'JSONPathAssertion', 'DurationAssertion', 'SizeAssertion', 'XPathAssertion', 'HTMLAssertion', 'XMLAssertion', 'BeanShellAssertion', 'JSR223Assertion', 'MD5HexAssertion', 'CompareAssertion', 'SMIMEAssertion',
  'RegexExtractor', 'XPathExtractor', 'JSONPathExtractor', 'BoundaryExtractor', 'CSSJQueryExtractor', 'HtmlExtractor', 'BeanShellPostProcessor', 'JSR223PostProcessor', 'DebugPostProcessor', 'ResultStatusActionHandler',
  'BeanShellPreProcessor', 'JSR223PreProcessor', 'UserParameters', 'HTMLLinkExtractor',
  'ViewResultsFullVisualizer', 'ResultCollector', 'Summariser', 'BackendListener',
  'CSVDataSet', 'HeaderManager', 'CookieManager', 'CacheManager', 'AuthManager', 'DNSCacheManager', 'KeystoreConfig', 'LoginConfig', 'SimpleConfigElement', 'Arguments', 'HTTPDefaults',
  'elementProp', 'collectionProp', 'objProp', 'stringProp', 'intProp', 'longProp', 'boolProp', 'doubleProp', 'floatProp', 'TestElement', 'testelement', 'property', 'jmeterTestPlan',
]);

const KNOWN_PLUGINS: Record<string, { displayName: string; category: PluginInfo['category']; source: string }> = {
  'com.blazemeter.jmeter.threads.concurrency.ConcurrencyThreadGroup': { displayName: 'Concurrency Thread Group', category: 'thread-group', source: 'Custom Thread Groups (BlazeMeter)' },
  'com.blazemeter.jmeter.threads.arrivals.ArrivalsThreadGroup': { displayName: 'Arrivals Thread Group', category: 'thread-group', source: 'Custom Thread Groups (BlazeMeter)' },
  'kg.apc.jmeter.threads.SteppingThreadGroup': { displayName: 'Stepping Thread Group', category: 'thread-group', source: 'Custom Thread Groups' },
  'kg.apc.jmeter.threads.UltimateThreadGroup': { displayName: 'Ultimate Thread Group', category: 'thread-group', source: 'Custom Thread Groups' },
  'kg.apc.jmeter.timers.VariableThroughputTimer': { displayName: 'Variable Throughput Timer', category: 'timer', source: 'Throughput Shaping Timer Plugin' },
  'com.blazemeter.jmeter.RandomCSVDataSetConfig': { displayName: 'Random CSV Data Set', category: 'config', source: 'BlazeMeter Plugins' },
  'kg.apc.jmeter.reporters.FlexibleFileWriter': { displayName: 'Flexible File Writer', category: 'listener', source: 'JMeter Plugins (Standard)' },
  'kg.apc.jmeter.perfmon.PerfMonCollector': { displayName: 'PerfMon Metrics Collector', category: 'listener', source: 'PerfMon Plugin' },
  'kg.apc.jmeter.vizualizers.CorrectedResultCollector': { displayName: 'Corrected Result Collector', category: 'listener', source: 'JMeter Plugins (Standard)' },
  'com.blazemeter.jmeter.http2.sampler.HTTP2Request': { displayName: 'HTTP/2 Request', category: 'sampler', source: 'HTTP/2 Plugin (BlazeMeter)' },
  'com.googlecode.jmeter.plugins.webdriver.sampler.WebDriverSampler': { displayName: 'WebDriver Sampler', category: 'sampler', source: 'Selenium WebDriver Plugin' },
  'kg.apc.jmeter.samplers.DummySampler': { displayName: 'Dummy Sampler', category: 'sampler', source: 'JMeter Plugins (Standard)' },
};

function collectTagNames(obj: any, tags: Set<string>): void {
  if (!obj || typeof obj !== 'object') return;
  for (const key of Object.keys(obj)) {
    if (key.startsWith('@_') || key === '#text') continue;
    tags.add(key);
    const child = obj[key];
    if (Array.isArray(child)) {
      for (const item of child) {
        collectTagNames(item, tags);
      }
    } else if (typeof child === 'object' && child !== null) {
      collectTagNames(child, tags);
    }
  }
}

function categorizeByPackage(className: string): PluginInfo['category'] {
  const lower = className.toLowerCase();
  if (lower.includes('thread') && lower.includes('group')) return 'thread-group';
  if (lower.includes('timer')) return 'timer';
  if (lower.includes('sampler') || lower.includes('request')) return 'sampler';
  if (lower.includes('listener') || lower.includes('collector') || lower.includes('reporter') || lower.includes('vizualizer') || lower.includes('visualizer')) return 'listener';
  if (lower.includes('assertion')) return 'assertion';
  if (lower.includes('extractor')) return 'extractor';
  if (lower.includes('controller')) return 'controller';
  if (lower.includes('config') || lower.includes('dataset') || lower.includes('manager')) return 'config';
  if (lower.includes('preprocessor') || lower.includes('pre_processor')) return 'preprocessor';
  if (lower.includes('postprocessor') || lower.includes('post_processor')) return 'postprocessor';
  return 'other';
}

function identifyPlugin(className: string): PluginInfo | null {
  if (KNOWN_PLUGINS[className]) {
    const known = KNOWN_PLUGINS[className];
    return { className, displayName: known.displayName, category: known.category, source: known.source, installed: 'unknown' };
  }

  if (className.startsWith('kg.apc.')) {
    return { className, displayName: className.split('.').pop() || className, category: categorizeByPackage(className), source: 'JMeter Plugins (Custom)', installed: 'unknown' };
  }
  if (className.startsWith('com.blazemeter.')) {
    return { className, displayName: className.split('.').pop() || className, category: categorizeByPackage(className), source: 'BlazeMeter', installed: 'unknown' };
  }
  if (className.startsWith('com.googlecode.jmeter.plugins.')) {
    return { className, displayName: className.split('.').pop() || className, category: categorizeByPackage(className), source: 'JMeter Plugin', installed: 'unknown' };
  }

  if (className.includes('.')) {
    return { className, displayName: className.split('.').pop() || className, category: categorizeByPackage(className), source: 'Unknown Plugin', installed: 'unknown' };
  }

  return null;
}

export function detectPlugins(content: string): { plugins: PluginInfo[]; hasPlugins: boolean } {
  try {
    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: '@_',
      textNodeName: '#text',
      parseAttributeValue: false,
      parseTagValue: false,
    });
    const parsed = parser.parse(content);
    const tags = new Set<string>();
    collectTagNames(parsed, tags);

    const plugins: PluginInfo[] = [];
    for (const tag of tags) {
      if (CORE_JMETER_ELEMENTS.has(tag)) continue;
      const plugin = identifyPlugin(tag);
      if (plugin) {
        plugins.push(plugin);
      }
    }

    return { plugins, hasPlugins: plugins.length > 0 };
  } catch (error) {
    console.error(`Error detecting plugins: ${error}`);
    return { plugins: [], hasPlugins: false };
  }
}

export function resolveScriptPath(scriptPath: string | null | undefined): string | null {
  if (!scriptPath) return null;
  
  const possiblePaths = [
    scriptPath,
    path.join(process.cwd(), scriptPath),
    path.join(process.cwd(), "uploads", scriptPath),
    path.join(process.cwd(), "uploads", "scripts", path.basename(scriptPath)),
  ];
  
  for (const p of possiblePaths) {
    if (fs.existsSync(p)) {
      return p;
    }
  }
  
  return null;
}
