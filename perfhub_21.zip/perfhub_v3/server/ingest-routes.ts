import { Router, type Request, type Response } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { createHash, randomBytes, timingSafeEqual } from "crypto";
import { gunzipSync } from "zlib";
import { db } from "./db";
import { remoteIngestTokens, testExecutions } from "@shared/schema";
import { eq, isNull, and, sql } from "drizzle-orm";
import { feedRemoteSamples, startRemoteStream, isRemoteStreamActive, feedRemoteMachineMetrics, updateRemoteStreamTestName, isAborted, getAbortInfo, type RemoteMachineMetricsSample } from "./live-metrics/remote-stream";
import { broadcastExecutionUpdate } from "./websocket";
import { storage } from "./storage";
import type { JtlRow } from "./live-metrics/tailer";

const router = Router();

const sampleIngestLimiter = rateLimit({
  windowMs: 1000,
  max: 100,
  message: { error: "Too many sample ingestion requests. Please slow down." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || req.socket.remoteAddress || 'unknown',
});

const executionCreationLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { error: "Too many execution creation requests. Please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || req.socket.remoteAddress || 'unknown',
});

const heartbeatLimiter = rateLimit({
  windowMs: 1000,
  max: 100,
  message: { error: "Too many heartbeat requests. Please slow down." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || req.socket.remoteAddress || 'unknown',
});

const metricsIngestLimiter = rateLimit({
  windowMs: 1000,
  max: 100,
  message: { error: "Too many metrics ingestion requests. Please slow down." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || req.socket.remoteAddress || 'unknown',
});

const MAX_PAYLOAD_BYTES = 50 * 1024 * 1024;
const MAX_SAMPLES_PER_BATCH = 10_000;

const MAX_MAP_SIZE = 10_000;
const MAP_ENTRY_TTL_MS = 24 * 60 * 60 * 1000;
const MAP_CLEANUP_INTERVAL_MS = 5 * 60 * 1000;

const TOKEN_CACHE_TTL_MS = 60_000;
const tokenCache = new Map<string, { tokenId: number; createdBy: number | null; cachedAt: number }>();

function getCachedToken(tokenHash: string): { tokenId: number; createdBy: number | null } | null {
  const entry = tokenCache.get(tokenHash);
  if (!entry) return null;
  if (Date.now() - entry.cachedAt > TOKEN_CACHE_TTL_MS) {
    tokenCache.delete(tokenHash);
    return null;
  }
  return { tokenId: entry.tokenId, createdBy: entry.createdBy };
}

function setCachedToken(tokenHash: string, tokenId: number, createdBy: number | null): void {
  if (tokenCache.size >= 1000) {
    const firstKey = tokenCache.keys().next().value;
    if (firstKey) tokenCache.delete(firstKey);
  }
  tokenCache.set(tokenHash, { tokenId, createdBy, cachedAt: Date.now() });
}

export function invalidateTokenCache(tokenId?: number): void {
  if (!tokenId) {
    tokenCache.clear();
    return;
  }
  for (const [hash, entry] of tokenCache) {
    if (entry.tokenId === tokenId) {
      tokenCache.delete(hash);
      break;
    }
  }
}

const runIdToExecutionId = new Map<string, { executionId: number; createdAt: number }>();

function setRunIdMapping(runId: string, executionId: number): void {
  if (runIdToExecutionId.size >= MAX_MAP_SIZE && !runIdToExecutionId.has(runId)) {
    let oldestKey: string | null = null;
    let oldestTime = Infinity;
    runIdToExecutionId.forEach((entry, key) => {
      if (entry.createdAt < oldestTime) {
        oldestTime = entry.createdAt;
        oldestKey = key;
      }
    });
    if (oldestKey) {
      runIdToExecutionId.delete(oldestKey);
    }
  }
  runIdToExecutionId.set(runId, { executionId, createdAt: Date.now() });
}

function getRunIdMapping(runId: string): number | undefined {
  const entry = runIdToExecutionId.get(runId);
  if (entry) {
    entry.createdAt = Date.now();
  }
  return entry?.executionId;
}

function cleanupExpiredEntries(): void {
  const now = Date.now();
  const keysToDelete: string[] = [];
  runIdToExecutionId.forEach((entry, key) => {
    if (now - entry.createdAt > MAP_ENTRY_TTL_MS) {
      keysToDelete.push(key);
    }
  });
  keysToDelete.forEach((key) => runIdToExecutionId.delete(key));
}

const mapCleanupInterval = setInterval(cleanupExpiredEntries, MAP_CLEANUP_INTERVAL_MS);
mapCleanupInterval.unref();

const sampleSchema = z.object({
  timestamp: z.number(),
  elapsed: z.number(),
  label: z.string().max(500),
  responseCode: z.string().max(50).default("200"),
  success: z.boolean(),
  allThreads: z.number().int().min(0).default(1),
  responseMessage: z.string().max(1000).default(""),
  parentSample: z.boolean().optional().default(false),
});

const inlineMetricsSchema = z.object({
  cpuPercent: z.number().min(0).max(100),
  memUsedMb: z.number().min(0),
  memTotalMb: z.number().min(0),
  memPercent: z.number().min(0).max(100),
  diskReadMbps: z.number().min(0).default(0),
  diskWriteMbps: z.number().min(0).default(0),
}).optional();

const batchSchema = z.object({
  executionId: z.number().int().positive().optional(),
  runId: z.string().min(1).max(100),
  nodeId: z.string().max(100).optional(),
  testName: z.string().max(200).optional(),
  environment: z.string().max(100).optional(),
  labels: z.array(z.string().max(50)).max(20).optional(),
  scheduleId: z.number().int().positive().optional(),
  samples: z.array(sampleSchema).min(1).max(MAX_SAMPLES_PER_BATCH),
  systemMetrics: inlineMetricsSchema,
  idleTimeoutSeconds: z.number().int().min(60).max(86400).optional(),
});

export function hashToken(raw: string): string {
  return createHash("sha256").update(raw).digest("hex");
}

export function generateToken(): { raw: string; prefix: string; hash: string } {
  const raw = `phi_${randomBytes(32).toString("hex")}`;
  const prefix = raw.slice(0, 8);
  const hash = hashToken(raw);
  return { raw, prefix, hash };
}

async function validateBearerToken(authHeader: string | undefined): Promise<{ valid: boolean; tokenId?: number; createdBy?: number | null }> {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return { valid: false };
  }

  const rawToken = authHeader.slice(7);
  if (!rawToken || rawToken.length < 10) {
    return { valid: false };
  }

  const tokenHash = hashToken(rawToken);

  const cached = getCachedToken(tokenHash);
  if (cached) {
    return { valid: true, tokenId: cached.tokenId, createdBy: cached.createdBy };
  }

  const prefix = rawToken.slice(0, 8);

  const [token] = await db
    .select()
    .from(remoteIngestTokens)
    .where(
      and(
        eq(remoteIngestTokens.tokenPrefix, prefix),
        isNull(remoteIngestTokens.revokedAt)
      )
    )
    .limit(1);

  if (!token) {
    return { valid: false };
  }

  const storedBuf = Buffer.from(token.tokenHash, "hex");
  const incomingBuf = Buffer.from(tokenHash, "hex");
  if (storedBuf.length !== incomingBuf.length || !timingSafeEqual(storedBuf, incomingBuf)) {
    return { valid: false };
  }

  setCachedToken(tokenHash, token.id, token.createdBy);

  db.update(remoteIngestTokens)
    .set({ lastUsedAt: new Date().toISOString() })
    .where(eq(remoteIngestTokens.id, token.id))
    .execute()
    .catch((err) => console.warn("[ingest] Failed to update token lastUsedAt:", err?.message));

  return { valid: true, tokenId: token.id, createdBy: token.createdBy };
}

async function resolveOrCreateExecution(parsed: z.infer<typeof batchSchema>, tokenId?: number): Promise<{ executionId: number; autoCreated: boolean }> {
  if (parsed.executionId) {
    const [execution] = await db
      .select()
      .from(testExecutions)
      .where(eq(testExecutions.id, parsed.executionId))
      .limit(1);

    if (!execution) {
      throw { status: 404, error: `Execution ${parsed.executionId} not found` };
    }

    if (execution.status !== "running") {
      if (execution.status === "queued" || execution.status === "pending") {
        await db
          .update(testExecutions)
          .set({ status: "running", startTime: new Date().toISOString() })
          .where(eq(testExecutions.id, parsed.executionId));
        broadcastExecutionUpdate(parsed.executionId, "running");
      } else {
        const isAbortedState = execution.status === "aborted" || execution.status === "cancelled";
        throw {
          status: 409,
          error: `Execution ${parsed.executionId} is in '${execution.status}' state, not accepting samples`,
          abort: isAbortedState,
          abortReason: isAbortedState ? `Execution ${execution.status} by server` : undefined,
        };
      }
    }

    return { executionId: parsed.executionId, autoCreated: false };
  }

  const cached = getRunIdMapping(parsed.runId);
  if (cached) {
    return { executionId: cached, autoCreated: false };
  }

  const [existingByRunId] = await db
    .select()
    .from(testExecutions)
    .where(eq(testExecutions.executionId, parsed.runId))
    .limit(1);

  if (existingByRunId) {
    if (existingByRunId.status === "queued" || existingByRunId.status === "pending") {
      await db
        .update(testExecutions)
        .set({ status: "running", startTime: new Date().toISOString() })
        .where(eq(testExecutions.id, existingByRunId.id));
      broadcastExecutionUpdate(existingByRunId.id, "running");
      setRunIdMapping(parsed.runId, existingByRunId.id);
      return { executionId: existingByRunId.id, autoCreated: false };
    } else if (existingByRunId.status === "running") {
      setRunIdMapping(parsed.runId, existingByRunId.id);
      return { executionId: existingByRunId.id, autoCreated: false };
    }
  }

  let uniqueExecId = parsed.runId;
  if (existingByRunId) {
    const timestamp = Date.now().toString(36);
    uniqueExecId = `${parsed.runId}-${timestamp}`;
    console.log(`[ingest] RunId '${parsed.runId}' already used (status: ${existingByRunId.status}), creating new execution as '${uniqueExecId}'`);
  }

  try {
    const [newExecution] = await db
      .insert(testExecutions)
      .values({
        executionId: uniqueExecId,
        scheduleId: parsed.scheduleId || null,
        testName: parsed.testName || null,
        environment: parsed.environment || null,
        executionLabels: parsed.labels && parsed.labels.length > 0 ? parsed.labels : null,
        remoteAgentTokenId: tokenId || null,
        status: "running",
        startTime: new Date().toISOString(),
        resultSummary: null,
        artifactsPath: null,
        liveMetrics: null,
      } as any)
      .returning();

    setRunIdMapping(parsed.runId, newExecution.id);
    broadcastExecutionUpdate(newExecution.id, "running");
    console.log(`[ingest] Auto-created execution #${newExecution.id} for runId '${parsed.runId}' (executionId: '${uniqueExecId}')`);

    if (tokenId) {
      db.update(remoteIngestTokens)
        .set({ activeExecutionCount: sql`COALESCE(active_execution_count, 0) + 1` } as any)
        .where(eq(remoteIngestTokens.id, tokenId))
        .execute()
        .catch((err) => console.warn("[ingest] Failed to update token activeExecutionCount:", err?.message));
    }

    return { executionId: newExecution.id, autoCreated: true };
  } catch (insertErr: any) {
    if (insertErr.code === "23505") {
      const [raceWinner] = await db
        .select()
        .from(testExecutions)
        .where(eq(testExecutions.executionId, parsed.runId))
        .limit(1);
      if (raceWinner && raceWinner.status === "running") {
        setRunIdMapping(parsed.runId, raceWinner.id);
        return { executionId: raceWinner.id, autoCreated: false };
      }
    }
    throw insertErr;
  }
}

router.head("/api/ingest/samples", (_req: Request, res: Response) => {
  res.status(200).end();
});

router.get("/api/ingest/samples", (_req: Request, res: Response) => {
  res.json({ status: "ok", endpoint: "ingest/samples", method: "POST" });
});

router.post("/api/ingest/samples", sampleIngestLimiter, async (req: Request, res: Response) => {
  try {
    const { valid, tokenId, createdBy } = await validateBearerToken(req.headers.authorization);
    if (!valid) {
      return res.status(401).json({ error: "Invalid or revoked token" });
    }

    const rawBody = Buffer.isBuffer(req.body) ? req.body : null;
    if (!rawBody || rawBody.length === 0) {
      return res.status(400).json({ error: "Empty request body" });
    }
    if (rawBody.length > MAX_PAYLOAD_BYTES) {
      return res.status(413).json({ error: `Payload exceeds ${MAX_PAYLOAD_BYTES} bytes` });
    }

    let bodyStr: string;
    const contentEncoding = req.headers["content-encoding"];

    if (contentEncoding === "gzip") {
      try {
        bodyStr = gunzipSync(rawBody).toString("utf-8");
      } catch {
        return res.status(400).json({ error: "Invalid gzip content" });
      }
    } else {
      bodyStr = rawBody.toString("utf-8");
    }

    let parsed: z.infer<typeof batchSchema>;
    try {
      const raw = JSON.parse(bodyStr);
      parsed = batchSchema.parse(raw);
    } catch (err: any) {
      return res.status(400).json({ error: "Invalid payload schema", details: err.message });
    }

    let executionId: number;
    let autoCreated = false;
    try {
      const result = await resolveOrCreateExecution(parsed, tokenId);
      executionId = result.executionId;
      autoCreated = result.autoCreated;
    } catch (err: any) {
      if (err.status) {
        const response: any = { error: err.error };
        if (err.abort) {
          response.abort = true;
          response.abortReason = err.abortReason;
        }
        return res.status(err.status).json(response);
      }
      throw err;
    }

    const { runId, samples, nodeId, testName, environment, labels, systemMetrics: inlineMetrics, idleTimeoutSeconds } = parsed;

    if (!isRemoteStreamActive(executionId)) {
      const exec = await storage.getExecution(executionId);
      const wasCompleted = exec && exec.status === "completed";
      if (wasCompleted) {
        await db.update(testExecutions).set({
          status: "running",
          endTime: null,
        } as any).where(eq(testExecutions.id, executionId));
        console.log(`[ingest] Execution ${executionId} was completed (idle timeout), re-opening as running — samples still arriving`);
      }
      await startRemoteStream(executionId, runId, testName);
      if (wasCompleted) {
        const { setRemoteStreamIdleTimeout } = await import("./live-metrics/remote-stream");
        setRemoteStreamIdleTimeout(executionId, 2_700_000);
      } else if (idleTimeoutSeconds && typeof idleTimeoutSeconds === "number" && idleTimeoutSeconds > 0) {
        const { setRemoteStreamIdleTimeout } = await import("./live-metrics/remote-stream");
        setRemoteStreamIdleTimeout(executionId, idleTimeoutSeconds * 1000);
      }
    } else {
      if (testName) updateRemoteStreamTestName(executionId, testName);
      if (idleTimeoutSeconds && typeof idleTimeoutSeconds === "number" && idleTimeoutSeconds > 0) {
        const { setRemoteStreamIdleTimeout } = await import("./live-metrics/remote-stream");
        setRemoteStreamIdleTimeout(executionId, idleTimeoutSeconds * 1000);
      }
    }

    if (autoCreated === false) {
      const updates: Record<string, any> = {};
      if (testName) updates.testName = testName;
      if (environment) updates.environment = environment;
      if (labels && labels.length > 0) updates.executionLabels = labels;
      if (tokenId) updates.remoteAgentTokenId = tokenId;
      if (Object.keys(updates).length > 0) {
        await db.update(testExecutions).set(updates as any).where(eq(testExecutions.id, executionId));
      }
    }

    if (tokenId) {
      db.update(remoteIngestTokens)
        .set({
          lastHeartbeatAt: new Date().toISOString(),
          lastNodeId: nodeId || null,
          totalSamplesIngested: sql`COALESCE(total_samples_ingested, 0) + ${samples.length}`,
        } as any)
        .where(eq(remoteIngestTokens.id, tokenId))
        .execute()
        .catch((err) => console.warn("[ingest] Failed to update token heartbeat:", err?.message));
    }

    const jtlRows: JtlRow[] = samples.map((s) => ({
      timestamp: s.timestamp,
      elapsed: s.elapsed,
      label: s.label,
      responseCode: s.responseCode,
      success: s.success,
      allThreads: s.allThreads,
      responseMessage: s.responseMessage,
      parentSample: s.parentSample || false,
    }));

    feedRemoteSamples(executionId, jtlRows);

    if (inlineMetrics) {
      const metricNodeId = nodeId || "default";
      const sample: RemoteMachineMetricsSample = {
        ts: Date.now(),
        cpuPercent: inlineMetrics.cpuPercent,
        memUsedMb: inlineMetrics.memUsedMb,
        memTotalMb: inlineMetrics.memTotalMb,
        memPercent: inlineMetrics.memPercent,
        diskReadMbps: inlineMetrics.diskReadMbps,
        diskWriteMbps: inlineMetrics.diskWriteMbps,
      };
      feedRemoteMachineMetrics(executionId, metricNodeId, sample);
    }

    const abortInfo = getAbortInfo(executionId);
    if (abortInfo) {
      return res.status(202).json({
        accepted: samples.length,
        executionId,
        runId,
        autoCreated,
        abort: true,
        abortReason: abortInfo.reason,
      });
    }

    return res.status(202).json({
      accepted: samples.length,
      executionId,
      runId,
      autoCreated,
    });
  } catch (err: any) {
    console.error("[ingest] Error processing samples:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/api/ingest/heartbeat", heartbeatLimiter, async (req: Request, res: Response) => {
  try {
    const { valid } = await validateBearerToken(req.headers.authorization);
    if (!valid) {
      return res.status(401).json({ error: "Invalid or revoked token" });
    }

    const rawBody = Buffer.isBuffer(req.body) ? req.body.toString("utf-8") : "";
    let body: any;
    try {
      body = JSON.parse(rawBody);
    } catch {
      return res.status(400).json({ error: "Invalid JSON" });
    }
    if (!body || (!body.executionId && !body.runId)) {
      return res.status(400).json({ error: "executionId or runId required" });
    }
    let execId = body.executionId;
    if (!execId && body.runId) {
      execId = getRunIdMapping(body.runId);
    }

    if (!execId) {
      return res.status(404).json({ error: "Could not resolve execution" });
    }

    const { heartbeatRemoteStream, setRemoteStreamIdleTimeout, getRemoteStreamStatus, getAbortInfo } = await import("./live-metrics/remote-stream");
    const alive = heartbeatRemoteStream(execId);
    if (alive) {
      if (body.idleTimeoutSeconds && typeof body.idleTimeoutSeconds === "number" && body.idleTimeoutSeconds > 0) {
        setRemoteStreamIdleTimeout(execId, body.idleTimeoutSeconds * 1000);
      }
      const status = getRemoteStreamStatus(execId);

      const abortInfo = getAbortInfo(execId);
      if (abortInfo) {
        return res.json({ ok: true, stream: status, abort: true, abortReason: abortInfo.reason });
      }

      return res.json({ ok: true, stream: status });
    } else {
      const abortInfo = getAbortInfo(execId);
      if (abortInfo) {
        return res.json({ ok: false, abort: true, abortReason: abortInfo.reason });
      }
      return res.status(404).json({ error: "No active stream for this execution" });
    }
  } catch (err: any) {
    console.error("[ingest] Heartbeat error:", err?.message);
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/api/ingest/complete", executionCreationLimiter, async (req: Request, res: Response) => {
  try {
    const { valid } = await validateBearerToken(req.headers.authorization);
    if (!valid) {
      return res.status(401).json({ error: "Invalid or revoked token" });
    }

    const rawBody = Buffer.isBuffer(req.body) ? req.body.toString("utf-8") : "";
    const body = z.object({
      executionId: z.number().int().positive().optional(),
      runId: z.string().min(1),
    }).parse(JSON.parse(rawBody));

    let execId = body.executionId;
    if (!execId && body.runId) {
      execId = getRunIdMapping(body.runId);
      if (!execId) {
        const [found] = await db
          .select()
          .from(testExecutions)
          .where(eq(testExecutions.executionId, body.runId))
          .limit(1);
        if (found) execId = found.id;
      }
    }

    if (!execId) {
      return res.status(404).json({ error: "Could not resolve execution from runId or executionId" });
    }

    const { stopRemoteStream, isRemoteStreamActive } = await import("./live-metrics/remote-stream");
    const hadActiveStream = isRemoteStreamActive(execId);
    await stopRemoteStream(execId);

    if (!hadActiveStream) {
      const [currentExec] = await db.select().from(testExecutions).where(eq(testExecutions.id, execId)).limit(1);
      if (currentExec && currentExec.status === "running") {
        console.log(`[ingest] No active in-memory stream for execution ${execId} — server may have restarted. Marking as completed with available data.`);
        const endTime = new Date().toISOString();
        const startTime = currentExec.startTime || endTime;
        const durationSeconds = Math.round((new Date(endTime).getTime() - new Date(startTime).getTime()) / 1000);
        const resultSummary = {
          totalRequests: 0,
          successfulRequests: 0,
          failedRequests: 0,
          avgResponseTime: 0,
          minResponseTime: 0,
          maxResponseTime: 0,
          throughput: 0,
          peakRps: 0,
          p50: 0, p90: 0, p95: 0, p99: 0,
          errorRate: 0,
          durationSeconds,
          startTime,
          endTime,
          transactionDetails: [],
          errorSummary: [],
          errorDetails: [],
          timeseries: [],
          anomalies: [],
          anomalySummary: { total: 0, warning: 0, critical: 0 },
          insights: [],
          insightSummary: { total: 0, byType: {}, warning: 0, critical: 0 },
          machineMetrics: null,
          note: "Server restarted during test execution. Live metrics were lost. If a JTL file is available, re-import the results for full metrics.",
        };
        await db.update(testExecutions).set({
          status: "completed",
          endTime,
          resultSummary,
        }).where(eq(testExecutions.id, execId));
        broadcastExecutionUpdate(execId, "completed", resultSummary);
        console.log(`[ingest] Execution ${execId} marked completed (no in-memory data available)`);
      }
    }

    runIdToExecutionId.delete(body.runId);

    const [exec] = await db.select({ remoteAgentTokenId: testExecutions.remoteAgentTokenId }).from(testExecutions).where(eq(testExecutions.id, execId)).limit(1);
    if (exec?.remoteAgentTokenId) {
      db.update(remoteIngestTokens)
        .set({
          completedExecutionCount: sql`COALESCE(completed_execution_count, 0) + 1`,
          activeExecutionCount: sql`GREATEST(COALESCE(active_execution_count, 0) - 1, 0)`,
        } as any)
        .where(eq(remoteIngestTokens.id, exec.remoteAgentTokenId))
        .execute()
        .catch((err) => console.warn("[ingest] Failed to update token completion count:", err?.message));
    }

    console.log(`[ingest] Execution ${execId} completed for runId '${body.runId}'`);

    try {
      const { dispatchWebhookEvent, WEBHOOK_EVENTS } = await import("./webhook-dispatcher");
      const execution = await storage.getExecution(execId);
      if (execution) {
        const event = execution.status === "failed" ? WEBHOOK_EVENTS.EXECUTION_FAILED : WEBHOOK_EVENTS.EXECUTION_COMPLETED;
        dispatchWebhookEvent(event, {
          executionId: execId,
          runId: body.runId,
          status: execution.status,
          scriptName: (execution as any).scriptName || "Unknown",
          startTime: execution.startTime,
          endTime: execution.endTime,
        });
      }
    } catch {}

    return res.status(200).json({ status: "completed", executionId: execId });
  } catch (err: any) {
    console.error("[ingest] Error completing:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

const metricsSchema = z.object({
  executionId: z.number().int().positive().optional(),
  runId: z.string().min(1),
  nodeId: z.string().min(1).max(200),
  metrics: z.object({
    cpuPercent: z.number().min(0).max(100),
    memUsedMb: z.number().min(0),
    memTotalMb: z.number().min(0),
    memPercent: z.number().min(0).max(100),
    diskReadMbps: z.number().min(0).default(0),
    diskWriteMbps: z.number().min(0).default(0),
  }),
});

router.post("/api/ingest/metrics", metricsIngestLimiter, async (req: Request, res: Response) => {
  try {
    const { valid } = await validateBearerToken(req.headers.authorization);
    if (!valid) {
      return res.status(401).json({ error: "Invalid or revoked token" });
    }

    const rawBody = Buffer.isBuffer(req.body) ? req.body.toString("utf-8") : "";
    let parsed: z.infer<typeof metricsSchema>;
    try {
      parsed = metricsSchema.parse(JSON.parse(rawBody));
    } catch (err: any) {
      return res.status(400).json({ error: "Invalid payload schema", details: err.message });
    }

    let executionId = parsed.executionId;
    if (!executionId && parsed.runId) {
      executionId = getRunIdMapping(parsed.runId);
      if (!executionId) {
        const [found] = await db
          .select()
          .from(testExecutions)
          .where(eq(testExecutions.executionId, parsed.runId))
          .limit(1);
        if (found) executionId = found.id;
      }
    }

    if (!executionId) {
      return res.status(404).json({ error: "Could not resolve execution from runId or executionId" });
    }

    const sample: RemoteMachineMetricsSample = {
      ts: Date.now(),
      cpuPercent: parsed.metrics.cpuPercent,
      memUsedMb: parsed.metrics.memUsedMb,
      memTotalMb: parsed.metrics.memTotalMb,
      memPercent: parsed.metrics.memPercent,
      diskReadMbps: parsed.metrics.diskReadMbps,
      diskWriteMbps: parsed.metrics.diskWriteMbps,
    };

    feedRemoteMachineMetrics(executionId, parsed.nodeId, sample);

    return res.status(202).json({ accepted: true, executionId, nodeId: parsed.nodeId });
  } catch (err: any) {
    console.error("[ingest] Error processing metrics:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
