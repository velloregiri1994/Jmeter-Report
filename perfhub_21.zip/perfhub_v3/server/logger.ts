import fs from "fs";
import path from "path";

export type LogLevel = "debug" | "info" | "warn" | "error" | "fatal";

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  source: string;
  message: string;
  meta?: Record<string, any>;
}

const LOG_DIR = path.resolve(process.cwd(), "logs");
const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024;
const MAX_LOG_FILES = 10;

const LEVEL_PRIORITY: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
  fatal: 4,
};

let currentLogFile = "";
let writeStream: fs.WriteStream | null = null;
let inMemoryBuffer: LogEntry[] = [];
const MAX_BUFFER = 2000;

function ensureLogDir() {
  if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  }
}

function getLogFileName(): string {
  const now = new Date();
  const date = now.toISOString().split("T")[0];
  return `perfhub-${date}.log`;
}

function rotateIfNeeded() {
  const filePath = path.join(LOG_DIR, currentLogFile);
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size >= MAX_FILE_SIZE_BYTES) {
        if (writeStream) {
          writeStream.end();
          writeStream = null;
        }
        const rotatedName = currentLogFile.replace(".log", `-${Date.now()}.log`);
        fs.renameSync(filePath, path.join(LOG_DIR, rotatedName));
        cleanOldLogs();
      }
    }
  } catch {
  }
}

function cleanOldLogs() {
  try {
    const files = fs.readdirSync(LOG_DIR)
      .filter(f => f.startsWith("perfhub-") && f.endsWith(".log"))
      .map(f => ({ name: f, time: fs.statSync(path.join(LOG_DIR, f)).mtimeMs }))
      .sort((a, b) => b.time - a.time);

    if (files.length > MAX_LOG_FILES) {
      for (const file of files.slice(MAX_LOG_FILES)) {
        fs.unlinkSync(path.join(LOG_DIR, file.name));
      }
    }
  } catch {
  }
}

function getWriteStream(): fs.WriteStream {
  const fileName = getLogFileName();
  if (fileName !== currentLogFile || !writeStream) {
    if (writeStream) {
      writeStream.end();
    }
    currentLogFile = fileName;
    ensureLogDir();
    const filePath = path.join(LOG_DIR, fileName);
    writeStream = fs.createWriteStream(filePath, { flags: "a" });
  }
  return writeStream;
}

function formatLogLine(entry: LogEntry): string {
  const levelTag = entry.level.toUpperCase().padEnd(5);
  let line = `${entry.timestamp} [${levelTag}] [${entry.source}] ${entry.message}`;
  if (entry.meta && Object.keys(entry.meta).length > 0) {
    line += ` | ${JSON.stringify(entry.meta)}`;
  }
  return line;
}

function writeEntry(entry: LogEntry) {
  inMemoryBuffer.push(entry);
  if (inMemoryBuffer.length > MAX_BUFFER) {
    inMemoryBuffer = inMemoryBuffer.slice(-MAX_BUFFER);
  }

  try {
    rotateIfNeeded();
    const stream = getWriteStream();
    stream.write(formatLogLine(entry) + "\n");
  } catch {
  }

  const consoleLine = formatLogLine(entry);
  if (entry.level === "error" || entry.level === "fatal") {
    console.error(consoleLine);
  } else if (entry.level === "warn") {
    console.warn(consoleLine);
  } else {
    console.log(consoleLine);
  }
}

function createTimestamp(): string {
  return new Date().toISOString();
}

export const logger = {
  debug(message: string, source = "app", meta?: Record<string, any>) {
    writeEntry({ timestamp: createTimestamp(), level: "debug", source, message, meta });
  },
  info(message: string, source = "app", meta?: Record<string, any>) {
    writeEntry({ timestamp: createTimestamp(), level: "info", source, message, meta });
  },
  warn(message: string, source = "app", meta?: Record<string, any>) {
    writeEntry({ timestamp: createTimestamp(), level: "warn", source, message, meta });
  },
  error(message: string, source = "app", meta?: Record<string, any>) {
    writeEntry({ timestamp: createTimestamp(), level: "error", source, message, meta });
  },
  fatal(message: string, source = "app", meta?: Record<string, any>) {
    writeEntry({ timestamp: createTimestamp(), level: "fatal", source, message, meta });
  },

  getRecentLogs(opts: {
    level?: LogLevel;
    source?: string;
    search?: string;
    limit?: number;
    offset?: number;
  } = {}): { entries: LogEntry[]; total: number } {
    const { level, source, search, limit = 100, offset = 0 } = opts;
    let filtered = [...inMemoryBuffer];

    if (level) {
      const minPriority = LEVEL_PRIORITY[level];
      filtered = filtered.filter(e => LEVEL_PRIORITY[e.level] >= minPriority);
    }
    if (source) {
      filtered = filtered.filter(e => e.source === source);
    }
    if (search) {
      const lower = search.toLowerCase();
      filtered = filtered.filter(e =>
        e.message.toLowerCase().includes(lower) ||
        e.source.toLowerCase().includes(lower) ||
        (e.meta && JSON.stringify(e.meta).toLowerCase().includes(lower))
      );
    }

    filtered.reverse();
    const total = filtered.length;
    const entries = filtered.slice(offset, offset + limit);
    return { entries, total };
  },

  getSources(): string[] {
    const sources = new Set<string>();
    for (const entry of inMemoryBuffer) {
      sources.add(entry.source);
    }
    return Array.from(sources).sort();
  },

  getStats(): { total: number; byLevel: Record<LogLevel, number>; bySource: Record<string, number> } {
    const byLevel: Record<LogLevel, number> = { debug: 0, info: 0, warn: 0, error: 0, fatal: 0 };
    const bySource: Record<string, number> = {};
    for (const entry of inMemoryBuffer) {
      byLevel[entry.level]++;
      bySource[entry.source] = (bySource[entry.source] || 0) + 1;
    }
    return { total: inMemoryBuffer.length, byLevel, bySource };
  },

  getLogFiles(): { name: string; size: number; modified: string }[] {
    try {
      ensureLogDir();
      return fs.readdirSync(LOG_DIR)
        .filter(f => f.startsWith("perfhub-") && f.endsWith(".log"))
        .map(f => {
          const stats = fs.statSync(path.join(LOG_DIR, f));
          return { name: f, size: stats.size, modified: stats.mtime.toISOString() };
        })
        .sort((a, b) => b.modified.localeCompare(a.modified));
    } catch {
      return [];
    }
  },

  readLogFile(fileName: string, opts: { tail?: number } = {}): string {
    const sanitized = path.basename(fileName);
    if (!sanitized.startsWith("perfhub-") || !sanitized.endsWith(".log") || sanitized.includes("..")) {
      throw new Error("Invalid log file name");
    }
    const filePath = path.join(LOG_DIR, sanitized);
    const resolved = path.resolve(filePath);
    if (!resolved.startsWith(path.resolve(LOG_DIR))) {
      throw new Error("Invalid log file path");
    }
    if (!fs.existsSync(resolved)) {
      throw new Error("Log file not found");
    }
    const content = fs.readFileSync(resolved, "utf-8");
    if (opts.tail) {
      const lines = content.split("\n").filter(Boolean);
      return lines.slice(-opts.tail).join("\n");
    }
    return content;
  },
};

ensureLogDir();
