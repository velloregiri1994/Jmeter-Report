import { JtlTailer, type JtlRow } from "./tailer";
import { MetricsAggregator, type LiveMetricsSnapshot, type SlaRuleConfig, type SlaViolation } from "./aggregator";
import { broadcastLiveMetrics, broadcast } from "../websocket";
import { storage } from "../storage";
import { sendLiveSlaBbreachEmail } from "../email/email-service";
import { getLiveSystemMetrics } from "../system-metrics-collector";
import type { AutoAbortRule } from "@shared/schema";
import { triggerAbort, isAborted } from "./remote-stream";

interface AutoAbortBreachState {
  startedAt: number;
}

interface LiveStream {
  tailer: JtlTailer;
  aggregator: MetricsAggregator;
  emitInterval: ReturnType<typeof setInterval>;
  executionId: number;
  runId: string;
  warning: string | null;
  notifiedViolationKeys: Set<string>;
  emailedViolationKeys: Set<string>;
  notifiedAnomalyIds: Set<string>;
  scheduleConfig: any;
  testName: string;
  environment: string;
  createdBy: number | null;
  linkedScriptId: number | null;
  autoAbortRules: AutoAbortRule[];
  autoAbortRulesLastRefresh: number;
  breachTracking: Map<number, AutoAbortBreachState>;
}

const activeStreams: Map<number, LiveStream> = new Map();

const EMIT_INTERVAL_MS = 2000;
const MIN_SAMPLES_FOR_SLA = 10;

function violationKey(v: SlaViolation): string {
  return `${v.ruleId}::${v.transactionLabel || "__global__"}::${v.metric}::${v.comparator}::${v.threshold}`;
}

function metricDisplayName(metric: string): string {
  const names: Record<string, string> = {
    avg: "Avg Response Time",
    p90: "P90 Latency",
    p95: "P95 Latency",
    p99: "P99 Latency",
    max: "Max Response Time",
    errorRate: "Error Rate",
    throughput: "Throughput",
  };
  return names[metric] || metric;
}

function formatMetricValue(metric: string, value: number): string {
  if (metric === "errorRate") return `${value.toFixed(2)}%`;
  if (metric === "throughput") return `${value.toFixed(1)} rps`;
  return `${Math.round(value)}ms`;
}

export async function startLiveMetrics(executionId: number, runId: string, jtlPath: string): Promise<void> {
  if (activeStreams.has(executionId)) {
    console.log(`[live-metrics] Stream already active for execution ${executionId}`);
    return;
  }

  console.log(`[live-metrics] Starting live metrics for execution ${executionId} (${runId})`);

  const tailer = new JtlTailer(jtlPath, 500);
  const aggregator = new MetricsAggregator();

  let scheduleConfig: any = {};
  let testName = "Unknown Test";
  let environment = "Unknown";
  let createdBy: number | null = null;
  let resolvedScriptId: number | null = null;
  let loadedAutoAbortRules: AutoAbortRule[] = [];
  const allSlaConfigs: SlaRuleConfig[] = [];

  try {
    let ruleIdCounter = 1000;

    const execution = await storage.getExecution(executionId);
    if (execution?.scheduleId) {
      const schedule = await storage.getSchedule(execution.scheduleId);
      if (schedule) {
        testName = schedule.name || testName;
        const config = schedule.configuration as any;
        scheduleConfig = config || {};
        environment = config?.environment || environment;
        if (config?.rampUp && typeof config.rampUp === 'number' && config.rampUp > 0) {
          aggregator.setRampUpDuration(config.rampUp);
          console.log(`[live-metrics] Set ramp-up duration to ${config.rampUp}s for execution ${executionId}`);
        }
        createdBy = schedule.createdBy;

        if (schedule.scriptId) {
          resolvedScriptId = schedule.scriptId;
          const dbRules = await storage.getEnabledSlaRules(schedule.scriptId);
          if (dbRules.length > 0) {
            for (const r of dbRules) {
              allSlaConfigs.push({
                id: r.id,
                transactionLabel: r.transactionLabel,
                metric: r.metric,
                comparator: r.comparator,
                threshold: r.threshold,
              });
            }
          }
          try {
            loadedAutoAbortRules = await storage.getEnabledAutoAbortRules(schedule.scriptId);
            if (loadedAutoAbortRules.length > 0) {
              console.log(`[live-metrics] Loaded ${loadedAutoAbortRules.length} auto-abort rules for execution ${executionId} from script ${schedule.scriptId}`);
            }
          } catch (abortErr) {
            console.warn(`[live-metrics] Failed to load auto-abort rules for execution ${executionId}:`, abortErr);
          }
        }

        const scheduleSlas = config?.slas;
        if (scheduleSlas && typeof scheduleSlas === "object") {
          const slaMetricMap: Record<string, { metric: string; comparator: string; unit: string }> = {
            avgResponseTime: { metric: "avg", comparator: "gt", unit: "ms" },
            p90: { metric: "p90", comparator: "gt", unit: "ms" },
            p95: { metric: "p95", comparator: "gt", unit: "ms" },
            p99: { metric: "p99", comparator: "gt", unit: "ms" },
            errorRate: { metric: "errorRate", comparator: "gt", unit: "%" },
            throughput: { metric: "throughput", comparator: "lt", unit: "rps" },
          };

          for (const [key, mapping] of Object.entries(slaMetricMap)) {
            const rawThreshold = scheduleSlas[key];
            if (rawThreshold !== undefined && rawThreshold !== null && rawThreshold !== "") {
              let threshold = parseFloat(String(rawThreshold));
              if (isNaN(threshold) || threshold < 0) continue;
              allSlaConfigs.push({
                id: ruleIdCounter++,
                transactionLabel: null,
                metric: mapping.metric,
                comparator: mapping.comparator,
                threshold,
              });
            }
          }
        }

        if (allSlaConfigs.length > 0) {
          aggregator.setSlaRules(allSlaConfigs);
          console.log(`[live-metrics] Loaded ${allSlaConfigs.length} SLA rules for execution ${executionId}`);
        }
      }
    }

    const execRules = await storage.getEnabledExecutionSlaRules(executionId);
    if (execRules.length > 0) {
      for (const r of execRules) {
        allSlaConfigs.push({
          id: r.id + 1000000,
          transactionLabel: r.transactionLabel,
          metric: r.metric,
          comparator: r.comparator,
          threshold: r.threshold,
        });
      }
      aggregator.setSlaRules(allSlaConfigs);
      console.log(`[live-metrics] Loaded ${execRules.length} execution-level SLA rules for execution ${executionId}`);
    }

    const execAbortRules = await storage.getEnabledExecutionAutoAbortRules(executionId);
    if (execAbortRules.length > 0) {
      const mapped = execAbortRules.map(r => ({ ...r, id: r.id + 2000000, scriptId: 0 }));
      loadedAutoAbortRules = [...loadedAutoAbortRules, ...mapped];
      console.log(`[live-metrics] Loaded ${execAbortRules.length} execution-level auto-abort rules for execution ${executionId}`);
    }
  } catch (err) {
    console.warn(`[live-metrics] Failed to load SLA rules for execution ${executionId}:`, err);
  }

  const stream: LiveStream = {
    tailer,
    aggregator,
    emitInterval: null as any,
    executionId,
    runId,
    warning: null,
    notifiedViolationKeys: new Set(),
    emailedViolationKeys: new Set(),
    notifiedAnomalyIds: new Set(),
    scheduleConfig,
    testName,
    environment,
    createdBy,
    linkedScriptId: resolvedScriptId,
    autoAbortRules: loadedAutoAbortRules,
    autoAbortRulesLastRefresh: Date.now(),
    breachTracking: new Map(),
  };

  tailer.on("rows", (rows: JtlRow[]) => {
    for (const row of rows) {
      aggregator.addSample(row);
    }
    if (stream.warning) {
      stream.warning = null;
    }
  });

  tailer.on("warning", (msg: string) => {
    stream.warning = msg;
    console.warn(`[live-metrics] Warning for execution ${executionId}: ${msg}`);
  });

  const scriptLevelRules = allSlaConfigs.filter(r => r.id < 1000000);
  let localSlaRefreshCounter = 0;

  stream.emitInterval = setInterval(() => {
    localSlaRefreshCounter++;
    if (localSlaRefreshCounter % 6 === 0) {
      storage.getEnabledExecutionSlaRules(executionId).then((execRules: any[]) => {
        const execConfigs: SlaRuleConfig[] = execRules.map((r: any) => ({
          id: r.id + 1000000,
          transactionLabel: r.transactionLabel,
          metric: r.metric,
          comparator: r.comparator,
          threshold: r.threshold,
        }));
        aggregator.setSlaRules([...scriptLevelRules, ...execConfigs]);
      }).catch((err) => console.warn("[live-metrics] Failed to refresh SLA rules:", err?.message));
    }

    const snapshot = aggregator.getSnapshot();

    const sysMetrics = getLiveSystemMetrics(executionId);
    if (sysMetrics.latest || sysMetrics.history.length > 0) {
      snapshot.systemMetrics = {
        latest: sysMetrics.latest,
        history: sysMetrics.history.map(s => ({
          ts: s.ts,
          cpuPercent: s.cpuPercent,
          memPercent: s.memPercent,
          diskReadMbps: s.diskReadMbps,
          diskWriteMbps: s.diskWriteMbps,
          jmeterCpuPercent: s.jmeterCpuPercent,
        })),
      };
    }

    if (snapshot.summary.totalRequests > 0) {
      broadcastLiveMetrics(executionId, runId, snapshot);
    }

    if (snapshot.slaViolations.length > 0 && snapshot.summary.totalRequests >= MIN_SAMPLES_FOR_SLA) {
      handleLiveSlaViolations(stream, snapshot);
    }

    if (stream.autoAbortRules.length > 0 && snapshot.summary.totalRequests >= MIN_SAMPLES_FOR_SLA) {
      evaluateLocalAutoAbortRules(stream, snapshot);
    }

    if (snapshot.anomalies && snapshot.anomalies.length > 0) {
      const newAnomalies = snapshot.anomalies.filter(a => {
        const key = `${a.metricType}_${a.timestamp}`;
        return !stream.notifiedAnomalyIds.has(key);
      });
      if (newAnomalies.length > 0) {
        for (const a of newAnomalies) {
          stream.notifiedAnomalyIds.add(`${a.metricType}_${a.timestamp}`);
        }
        import("../webhook-dispatcher").then(({ dispatchWebhookEvent, WEBHOOK_EVENTS }) => {
          dispatchWebhookEvent(WEBHOOK_EVENTS.ANOMALY_DETECTED, {
            executionId: stream.executionId,
            testName: stream.testName,
            environment: stream.environment,
            anomalies: newAnomalies.map(a => ({
              severity: a.severity,
              metricType: a.metricType,
              description: a.description,
              value: a.value,
              rollingMedian: a.rollingMedian,
              zScore: a.zScore,
            })),
            timestamp: Date.now(),
          });
        }).catch(() => {});
      }
    }
  }, EMIT_INTERVAL_MS);

  activeStreams.set(executionId, stream);

  tailer.start();
}

async function handleLiveSlaViolations(stream: LiveStream, snapshot: LiveMetricsSnapshot): Promise<void> {
  const newViolations: SlaViolation[] = [];

  for (const v of snapshot.slaViolations) {
    const key = violationKey(v);
    if (!stream.notifiedViolationKeys.has(key)) {
      stream.notifiedViolationKeys.add(key);
      newViolations.push(v);
    }
  }

  if (newViolations.length === 0) return;

  console.log(`[live-metrics] ${newViolations.length} new SLA violation(s) detected for execution ${stream.executionId}`);

  if (stream.createdBy) {
    const createdByUserId = stream.createdBy;
    const violationSummary = newViolations
      .map(v => {
        const txLabel = v.transactionLabel ? `[${v.transactionLabel}] ` : "";
        return `${txLabel}${metricDisplayName(v.metric)}: ${formatMetricValue(v.metric, v.actualValue)} (threshold: ${formatMetricValue(v.metric, v.threshold)})`;
      })
      .join("; ");

    storage.shouldSendNotification(createdByUserId, 'sla_violation').then(shouldNotify => {
      if (shouldNotify) {
        storage.createNotification({
          userId: createdByUserId,
          title: `Live SLA Breach — ${stream.testName}`,
          message: `SLA violation detected during running test: ${violationSummary}`,
          type: "warning",
          link: `/executions/${stream.executionId}`,
        }).catch(err => {
          console.warn(`[live-metrics] Failed to create SLA breach notification:`, err);
        });
      }
    }).catch(err => {
      console.warn(`[live-metrics] Failed to check notification preferences:`, err);
    });

    import("../webhook-dispatcher").then(({ dispatchWebhookEvent, WEBHOOK_EVENTS }) => {
      dispatchWebhookEvent(WEBHOOK_EVENTS.SLA_BREACH, {
        executionId: stream.executionId,
        testName: stream.testName,
        violations: newViolations.map(v => ({
          metric: v.metric,
          threshold: v.threshold,
          actual: v.actualValue,
        })),
      });
    }).catch((err) => console.warn("[live-metrics] Failed to dispatch SLA breach webhook:", err?.message));
  }

  const unEmailedViolations = newViolations.filter(v => !stream.emailedViolationKeys.has(violationKey(v)));
  if (unEmailedViolations.length > 0) {
    for (const v of unEmailedViolations) {
      stream.emailedViolationKeys.add(violationKey(v));
    }
    try {
      const emailViolations = unEmailedViolations.map(v => ({
        metric: metricDisplayName(v.metric),
        threshold: formatMetricValue(v.metric, v.threshold),
        actual: formatMetricValue(v.metric, v.actualValue),
        transaction: v.transactionLabel || undefined,
      }));

      const baseUrl = process.env.APP_BASE_URL || `http://localhost:${process.env.PORT || 5000}`;

      sendLiveSlaBbreachEmail({
        executionId: stream.executionId,
        testName: stream.testName,
        environment: stream.environment,
        elapsedSeconds: snapshot.summary.elapsedSeconds,
        dashboardBaseUrl: baseUrl,
        violations: emailViolations,
        currentMetrics: {
          avgResponseTime: snapshot.summary.avgResponseTime,
          p95: snapshot.summary.p95,
          errorRate: snapshot.summary.errorRate,
          throughput: snapshot.summary.throughput,
          totalRequests: snapshot.summary.totalRequests,
        },
        scheduleConfig: stream.scheduleConfig,
      }).catch(err => {
        console.warn(`[live-metrics] Failed to send live SLA breach email:`, err);
        for (const v of unEmailedViolations) {
          stream.emailedViolationKeys.delete(violationKey(v));
        }
      });
    } catch (err) {
      console.warn(`[live-metrics] Failed to queue live SLA breach email:`, err);
      for (const v of unEmailedViolations) {
        stream.emailedViolationKeys.delete(violationKey(v));
      }
    }
  }
}

const AUTO_ABORT_RULES_REFRESH_MS = 30_000;

function getLocalAutoAbortMetricValue(snapshot: LiveMetricsSnapshot, metric: string): number | null {
  switch (metric) {
    case "errorRate": return snapshot.summary.errorRate;
    case "avgResponseTime": return snapshot.summary.avgResponseTime;
    case "p95": return snapshot.summary.p95;
    case "p99": return snapshot.summary.p99;
    case "p90": {
      const txs = snapshot.allTransactions;
      if (txs.length === 0) return null;
      let total = 0, count = 0;
      for (const tx of txs) { total += tx.p90 * tx.count; count += tx.count; }
      return count > 0 ? total / count : null;
    }
    case "maxResponseTime": {
      let maxVal = 0;
      for (const tx of snapshot.allTransactions) {
        if (tx.max > maxVal) maxVal = tx.max;
      }
      return maxVal;
    }
    case "throughput": return snapshot.summary.throughput;
    default: return null;
  }
}

function isLocalAutoAbortBreached(actual: number, threshold: number, comparator: string): boolean {
  switch (comparator) {
    case "gt": return actual > threshold;
    case "gte": return actual >= threshold;
    case "lt": return actual < threshold;
    case "lte": return actual <= threshold;
    default: return false;
  }
}

function evaluateLocalAutoAbortRules(stream: LiveStream, snapshot: LiveMetricsSnapshot): void {
  if (isAborted(stream.executionId)) return;

  const now = Date.now();
  if (now - stream.autoAbortRulesLastRefresh > AUTO_ABORT_RULES_REFRESH_MS) {
    stream.autoAbortRulesLastRefresh = now;
    const refreshPromises: Promise<any>[] = [];

    if (stream.linkedScriptId) {
      refreshPromises.push(
        storage.getEnabledAutoAbortRules(stream.linkedScriptId).then(rules => {
          const execRuleIds = stream.autoAbortRules.filter(r => r.id >= 2000000);
          stream.autoAbortRules = [...rules, ...execRuleIds];
        }).catch((err) => console.warn("[live-metrics] Failed to refresh script auto-abort rules:", err?.message))
      );
    }

    refreshPromises.push(
      storage.getEnabledExecutionAutoAbortRules(stream.executionId).then(execRules => {
        const mapped = execRules.map(r => ({ ...r, id: r.id + 2000000, scriptId: 0 }));
        const scriptRules = stream.autoAbortRules.filter(r => r.id < 2000000);
        stream.autoAbortRules = [...scriptRules, ...mapped];
      }).catch((err) => console.warn("[live-metrics] Failed to refresh execution auto-abort rules:", err?.message))
    );

    Promise.all(refreshPromises).catch(() => {});
  }

  const activeRuleIds = new Set<number>();

  for (const rule of stream.autoAbortRules) {
    activeRuleIds.add(rule.id);
    const actualValue = getLocalAutoAbortMetricValue(snapshot, rule.metric);
    if (actualValue === null) continue;

    const breached = isLocalAutoAbortBreached(actualValue, rule.threshold, rule.comparator);

    if (breached) {
      if (!stream.breachTracking.has(rule.id)) {
        stream.breachTracking.set(rule.id, { startedAt: now });
        console.log(`[live-metrics][auto-abort] Breach started for rule ${rule.id} (${rule.metric} ${rule.comparator} ${rule.threshold}): actual=${actualValue.toFixed(2)}, execution ${stream.executionId}`);

        broadcast({
          type: "execution_update",
          executionId: stream.executionId,
          status: "running",
          resultSummary: {
            _autoAbortWarning: {
              ruleId: rule.id,
              metric: rule.metric,
              comparator: rule.comparator,
              threshold: rule.threshold,
              actualValue,
              sustainedSeconds: rule.sustainedSeconds,
              breachStartedAt: now,
            },
          },
        });
      }

      const breach = stream.breachTracking.get(rule.id)!;
      const breachDurationSec = (now - breach.startedAt) / 1000;

      if (breachDurationSec >= rule.sustainedSeconds) {
        const reason = `Auto-abort: ${rule.metric} ${rule.comparator} ${rule.threshold} breached for ${Math.round(breachDurationSec)}s (actual: ${actualValue.toFixed(2)}, sustained threshold: ${rule.sustainedSeconds}s)`;
        console.log(`[live-metrics][auto-abort] Triggering abort for execution ${stream.executionId}: ${reason}`);

        triggerAbort(stream.executionId, reason);

        try {
          const { cancelRun } = require("../jmeter-worker");
          cancelRun(stream.executionId);
        } catch (err) {
          console.error(`[live-metrics][auto-abort] Failed to cancel local JMeter run for execution ${stream.executionId}:`, err);
        }

        if (stream.createdBy) {
          storage.shouldSendNotification(stream.createdBy, 'sla_violation').then(shouldNotify => {
            if (shouldNotify) {
              storage.createNotification({
                userId: stream.createdBy!,
                title: `Test Auto-Aborted — ${stream.testName}`,
                message: reason,
                type: "error",
                link: `/executions/${stream.executionId}`,
              }).catch((err) => console.warn("[live-metrics] Failed to create auto-abort notification:", err?.message));
            }
          }).catch((err) => console.warn("[live-metrics] Failed to check notification preferences:", err?.message));
        }

        return;
      }
    } else {
      if (stream.breachTracking.has(rule.id)) {
        console.log(`[live-metrics][auto-abort] Breach recovered for rule ${rule.id} (${rule.metric}), execution ${stream.executionId}`);
        stream.breachTracking.delete(rule.id);
      }
    }
  }

  const trackedRuleIds = Array.from(stream.breachTracking.keys());
  for (const ruleId of trackedRuleIds) {
    if (!activeRuleIds.has(ruleId)) {
      stream.breachTracking.delete(ruleId);
    }
  }
}

export function stopLiveMetrics(executionId: number): void {
  const stream = activeStreams.get(executionId);
  if (!stream) return;

  console.log(`[live-metrics] Stopping live metrics for execution ${executionId}`);

  stream.tailer.stop();
  clearInterval(stream.emitInterval);

  stream.aggregator.finalize();
  const finalSnapshot = stream.aggregator.getSnapshot();
  if (finalSnapshot.summary.totalRequests > 0) {
    broadcastLiveMetrics(executionId, stream.runId, finalSnapshot);
  }

  stream.aggregator.reset();
  activeStreams.delete(executionId);
}

export function isLiveMetricsActive(executionId: number): boolean {
  return activeStreams.has(executionId);
}

export function getLiveSnapshot(executionId: number): { snapshot: LiveMetricsSnapshot | null; warning: string | null } {
  const stream = activeStreams.get(executionId);
  if (!stream) return { snapshot: null, warning: null };
  const snapshot = stream.aggregator.getSnapshot();
  const sysMetrics = getLiveSystemMetrics(executionId);
  if (sysMetrics.latest || sysMetrics.history.length > 0) {
    snapshot.systemMetrics = {
      latest: sysMetrics.latest,
      history: sysMetrics.history.map(s => ({
        ts: s.ts,
        cpuPercent: s.cpuPercent,
        memPercent: s.memPercent,
        diskReadMbps: s.diskReadMbps,
        diskWriteMbps: s.diskWriteMbps,
        jmeterCpuPercent: s.jmeterCpuPercent,
      })),
    };
  }
  return { snapshot, warning: stream.warning };
}

export function stopAllLiveMetrics(): void {
  const ids = Array.from(activeStreams.keys());
  ids.forEach((executionId) => {
    stopLiveMetrics(executionId);
  });
}
