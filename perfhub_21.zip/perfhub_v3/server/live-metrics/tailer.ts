import fs from "fs";
import { EventEmitter } from "events";

export interface JtlRow {
  timestamp: number;
  elapsed: number;
  label: string;
  responseCode: string;
  success: boolean;
  allThreads: number;
  responseMessage: string;
  parentSample?: boolean;
}

const MAX_CHUNK_BYTES = 4 * 1024 * 1024;
const FILE_WAIT_TIMEOUT_MS = 60000;
const BATCH_YIELD_SIZE = 5000;

export class JtlTailer extends EventEmitter {
  private filePath: string;
  private offset: number = 0;
  private partialLine: string = "";
  private headers: string[] | null = null;
  private headerMap: Map<string, number> = new Map();
  private pollInterval: ReturnType<typeof setInterval> | null = null;
  private fileExistsPoll: ReturnType<typeof setInterval> | null = null;
  private stopped: boolean = false;
  private reading: boolean = false;
  private pollMs: number;
  private fileWaitStart: number = 0;
  private readBuffer: Buffer | null = null;

  constructor(filePath: string, pollMs: number = 500) {
    super();
    this.filePath = filePath;
    this.pollMs = pollMs;
  }

  start(): void {
    if (this.stopped) return;

    if (fs.existsSync(this.filePath)) {
      this.startTailing();
    } else {
      this.fileWaitStart = Date.now();
      this.fileExistsPoll = setInterval(() => {
        if (this.stopped) {
          if (this.fileExistsPoll) clearInterval(this.fileExistsPoll);
          return;
        }
        if (fs.existsSync(this.filePath)) {
          if (this.fileExistsPoll) clearInterval(this.fileExistsPoll);
          this.fileExistsPoll = null;
          this.startTailing();
        } else if (Date.now() - this.fileWaitStart > FILE_WAIT_TIMEOUT_MS) {
          console.warn(`[live-metrics] JTL file not found after ${FILE_WAIT_TIMEOUT_MS / 1000}s: ${this.filePath}`);
          this.emit("warning", `JTL file not found: ${this.filePath}`);
          this.fileWaitStart = Date.now();
        }
      }, 1000);
    }
  }

  stop(): void {
    this.stopped = true;
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    if (this.fileExistsPoll) {
      clearInterval(this.fileExistsPoll);
      this.fileExistsPoll = null;
    }
    this.flush();
    this.readBuffer = null;
  }

  private startTailing(): void {
    this.readNewDataAsync();
    this.pollInterval = setInterval(() => {
      if (this.stopped) {
        if (this.pollInterval) clearInterval(this.pollInterval);
        return;
      }
      this.readNewDataAsync();
    }, this.pollMs);
  }

  private readNewDataAsync(): void {
    if (this.reading) return;
    this.reading = true;
    this.readChunked().finally(() => {
      this.reading = false;
    });
  }

  private async readChunked(): Promise<void> {
    try {
      const stat = await fs.promises.stat(this.filePath);
      const fileSize = stat.size;

      if (fileSize < this.offset) {
        this.offset = 0;
        this.headers = null;
        this.headerMap.clear();
        this.partialLine = "";
      }

      if (fileSize <= this.offset) return;

      let remaining = fileSize - this.offset;
      const fd = await fs.promises.open(this.filePath, "r");
      try {
        while (remaining > 0 && !this.stopped) {
          const chunkSize = Math.min(remaining, MAX_CHUNK_BYTES);
          if (!this.readBuffer || this.readBuffer.length < chunkSize) {
            this.readBuffer = Buffer.allocUnsafe(chunkSize);
          }
          const { bytesRead } = await fd.read(this.readBuffer, 0, chunkSize, this.offset);
          if (bytesRead === 0) break;

          this.offset += bytesRead;
          remaining -= bytesRead;

          const chunk = this.readBuffer.toString("utf-8", 0, bytesRead);
          await this.processChunk(chunk);
        }
      } finally {
        await fd.close();
      }
    } catch (err: any) {
      if (err?.code !== 'ENOENT') {
        console.error(`[live-metrics] Error reading JTL file ${this.filePath}:`, err?.message || err);
      }
    }
  }

  private async processChunk(chunk: string): Promise<void> {
    const text = this.partialLine + chunk;
    const lines = text.split("\n");
    this.partialLine = lines.pop() || "";

    const batch: JtlRow[] = [];

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;

      if (!this.headers) {
        this.parseHeader(trimmed);
        continue;
      }

      const row = this.parseLine(trimmed);
      if (row) {
        batch.push(row);

        if (batch.length >= BATCH_YIELD_SIZE) {
          this.emit("rows", batch.splice(0));
          await new Promise<void>(resolve => setImmediate(resolve));
          if (this.stopped) return;
        }
      }
    }

    if (batch.length > 0) {
      this.emit("rows", batch);
    }
  }

  private flush(): void {
    if (this.partialLine.trim() && this.headers) {
      const row = this.parseLine(this.partialLine.trim());
      if (row) {
        this.emit("rows", [row]);
      }
      this.partialLine = "";
    }
  }

  private parseHeader(line: string): void {
    this.headers = line.split(",").map((h) => h.trim());
    this.headers.forEach((h, i) => this.headerMap.set(h, i));
  }

  private parseLine(line: string): JtlRow | null {
    try {
      const fields = line.indexOf('"') >= 0 ? this.parseCSVLineQuoted(line) : line.split(",");
      if (fields.length < this.headers!.length - 2) return null;

      const get = (name: string): string => {
        const idx = this.headerMap.get(name);
        return idx !== undefined && idx < fields.length ? fields[idx] : "";
      };

      const tsStr = get("timeStamp") || get("timestamp");
      const elapsedStr = get("elapsed");

      if (!tsStr || !elapsedStr) return null;

      const timestamp = parseInt(tsStr, 10);
      const elapsed = parseFloat(elapsedStr);

      if (isNaN(timestamp) || isNaN(elapsed)) return null;

      const label = get("label") || "UNKNOWN";
      const responseCode = get("responseCode") || "";
      const successRaw = (get("success") || "true").toLowerCase();
      const success = successRaw === "true" || successRaw === "1" || successRaw === "yes";
      const atStr = get("allThreads") || get("all_threads") || "0";
      const allThreads = parseInt(atStr, 10) || 0;
      const responseMessage = get("responseMessage") || get("failureMessage") || "";
      const parentSample = responseMessage.includes("Number of samples in transaction");

      return { timestamp, elapsed, label, responseCode, success, allThreads, responseMessage, parentSample };
    } catch {
      return null;
    }
  }

  private parseCSVLineQuoted(line: string): string[] {
    const fields: string[] = [];
    let current = "";
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const ch = line.charCodeAt(i);
      if (inQuotes) {
        if (ch === 34 && i + 1 < line.length && line.charCodeAt(i + 1) === 34) {
          current += '"';
          i++;
        } else if (ch === 34) {
          inQuotes = false;
        } else {
          current += line[i];
        }
      } else {
        if (ch === 34) {
          inQuotes = true;
        } else if (ch === 44) {
          fields.push(current);
          current = "";
        } else {
          current += line[i];
        }
      }
    }
    fields.push(current);
    return fields;
  }
}
