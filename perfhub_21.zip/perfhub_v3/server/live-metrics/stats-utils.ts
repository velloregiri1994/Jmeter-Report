export class RollingStats {
  private buffer: number[];
  private head: number = 0;
  private _count: number = 0;
  private _capacity: number;

  constructor(capacity: number) {
    this._capacity = capacity;
    this.buffer = new Array(capacity).fill(0);
  }

  push(value: number): void {
    this.buffer[this.head] = value;
    this.head = (this.head + 1) % this._capacity;
    if (this._count < this._capacity) this._count++;
  }

  get size(): number {
    return this._count;
  }

  get count(): number {
    return this._count;
  }

  get capacity(): number {
    return this._capacity;
  }

  values(): number[] {
    if (this._count === 0) return [];
    const result: number[] = [];
    const start = this._count < this._capacity ? 0 : this.head;
    for (let i = 0; i < this._count; i++) {
      result.push(this.buffer[(start + i) % this._capacity]);
    }
    return result;
  }

  private getSorted(): number[] {
    return this.values().sort((a, b) => a - b);
  }

  get median(): number {
    if (this._count === 0) return 0;
    const sorted = this.getSorted();
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 === 0
      ? (sorted[mid - 1] + sorted[mid]) / 2
      : sorted[mid];
  }

  get mad(): number {
    if (this._count < 3) return 0;
    const med = this.median;
    const deviations = this.values().map(v => Math.abs(v - med));
    deviations.sort((a, b) => a - b);
    const mid = Math.floor(deviations.length / 2);
    const rawMad = deviations.length % 2 === 0
      ? (deviations[mid - 1] + deviations[mid]) / 2
      : deviations[mid];
    return rawMad * 1.4826;
  }

  reset(): void {
    this.buffer.fill(0);
    this.head = 0;
    this._count = 0;
  }
}

export interface NormalizedTimeseriesPoint {
  sec: number;
  avg_ms: number;
  errors: number;
  rps: number;
  active_threads?: number;
  p95_ms?: number;
  p99_ms?: number;
  p50_ms?: number;
  errorRate?: number;
}

export function getErrorRate(p: NormalizedTimeseriesPoint | { errorRate?: number; errors?: number; rps?: number }): number {
  if (typeof (p as any).errorRate === 'number') return Math.min((p as any).errorRate, 100);
  const errors = (p as any).errors || 0;
  const rps = (p as any).rps || 0;
  if (rps > 0 && errors >= 0) {
    const bucketRequests = Math.max(rps, errors);
    if (bucketRequests > 0) return Math.min((errors / bucketRequests) * 100, 100);
  }
  return 0;
}

export function normalizeTimeseries(raw: any[]): NormalizedTimeseriesPoint[] {
  if (!raw || raw.length === 0) return [];
  const first = raw[0];
  const isAggregatorFormat = 't' in first && 'avgRT' in first;

  return raw.map((p: any) => {
    if (isAggregatorFormat) {
      return {
        sec: typeof p.t === 'number' ? Math.round(p.t / 1000) : 0,
        avg_ms: p.avgRT || 0,
        errors: p.errors || 0,
        rps: p.throughput || 0,
        active_threads: p.activeThreads || 0,
        p95_ms: p.p95 || undefined,
        errorRate: typeof p.errorRate === 'number' ? p.errorRate : undefined,
      };
    }
    return {
      sec: p.sec || 0,
      avg_ms: p.avg_ms || 0,
      errors: p.errors || 0,
      rps: p.rps || 0,
      active_threads: p.active_threads || 0,
      p95_ms: p.p95_ms || undefined,
      p99_ms: p.p99_ms || undefined,
      p50_ms: p.p50_ms || undefined,
      errorRate: typeof p.errorRate === 'number' ? p.errorRate : undefined,
    };
  });
}

export function linearRegressionSlope(values: number[]): number {
  const n = values.length;
  if (n < 3) return 0;
  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  for (let i = 0; i < n; i++) {
    sumX += i;
    sumY += values[i];
    sumXY += i * values[i];
    sumX2 += i * i;
  }
  const denom = n * sumX2 - sumX * sumX;
  if (denom === 0) return 0;
  return (n * sumXY - sumX * sumY) / denom;
}

export function medianOf(arr: number[]): number {
  if (arr.length === 0) return 0;
  const sorted = arr.slice().sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}

export function madOf(arr: number[]): number {
  if (arr.length < 3) return 0;
  const med = medianOf(arr);
  const deviations = arr.map(v => Math.abs(v - med)).sort((a, b) => a - b);
  const mid = Math.floor(deviations.length / 2);
  const rawMad = deviations.length % 2 === 0
    ? (deviations[mid - 1] + deviations[mid]) / 2
    : deviations[mid];
  return rawMad * 1.4826;
}

export function stddev(arr: number[]): number {
  if (arr.length < 2) return 0;
  const mean = arr.reduce((s, v) => s + v, 0) / arr.length;
  const variance = arr.reduce((s, v) => s + (v - mean) ** 2, 0) / (arr.length - 1);
  return Math.sqrt(variance);
}

export function percentileOf(arr: number[], p: number): number {
  if (arr.length === 0) return 0;
  const sorted = arr.slice().sort((a, b) => a - b);
  const idx = (p / 100) * (sorted.length - 1);
  const lo = Math.floor(idx);
  const hi = Math.ceil(idx);
  if (lo === hi) return sorted[lo];
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
}

export function modifiedZScore(value: number, arr: number[]): number {
  const m = madOf(arr);
  if (m < 0.001) return 0;
  return (value - medianOf(arr)) / m;
}

export function resizeRollingStats(stats: RollingStats, newSize: number): RollingStats {
  if (newSize <= stats.capacity) return stats;
  const oldValues = stats.values();
  const newStats = new RollingStats(newSize);
  for (const v of oldValues) newStats.push(v);
  return newStats;
}
