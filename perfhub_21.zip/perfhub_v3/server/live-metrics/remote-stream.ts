import { MetricsAggregator, type SlaRuleConfig, type SlaViolation, type LiveMetricsSnapshot, type AggregatorCheckpoint } from "./aggregator";
import { broadcastLiveMetrics, broadcastExecutionUpdate, broadcast } from "../websocket";
import { storage } from "../storage";
import { db } from "../db";
import { testExecutions } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import type { JtlRow } from "./tailer";
import type { AutoAbortRule } from "@shared/schema";

export interface RemoteMachineMetricsSample {
  ts: number;
  cpuPercent: number;
  memUsedMb: number;
  memTotalMb: number;
  memPercent: number;
  diskReadMbps: number;
  diskWriteMbps: number;
}

interface NodeMetricsState {
  latest: RemoteMachineMetricsSample | null;
  history: RemoteMachineMetricsSample[];
}

type SysMetricsEntry = {
  ts: number;
  cpuPercent: number;
  memUsedMb: number;
  memTotalMb: number;
  memPercent: number;
  diskReadMbps: number;
  diskWriteMbps: number;
  jmeterCpuPercent: number | null;
  jmeterMemMb: number | null;
};

function buildAggregatedSystemMetrics(nodeMetrics: Map<string, NodeMetricsState>): { latest: SysMetricsEntry | null; history: SysMetricsEntry[] } | null {
  if (nodeMetrics.size === 0) return null;

  const allHistory: SysMetricsEntry[] = [];
  let latestEntry: SysMetricsEntry | null = null;

  nodeMetrics.forEach((state) => {
    for (const s of state.history) {
      allHistory.push({
        ts: s.ts, cpuPercent: s.cpuPercent, memPercent: s.memPercent,
        memUsedMb: s.memUsedMb, memTotalMb: s.memTotalMb,
        diskReadMbps: s.diskReadMbps, diskWriteMbps: s.diskWriteMbps,
        jmeterCpuPercent: null, jmeterMemMb: null,
      });
    }
    if (state.latest && (!latestEntry || state.latest.ts > latestEntry.ts)) {
      latestEntry = {
        ts: state.latest.ts, cpuPercent: state.latest.cpuPercent, memPercent: state.latest.memPercent,
        memUsedMb: state.latest.memUsedMb, memTotalMb: state.latest.memTotalMb,
        diskReadMbps: state.latest.diskReadMbps, diskWriteMbps: state.latest.diskWriteMbps,
        jmeterCpuPercent: null, jmeterMemMb: null,
      };
    }
  });

  if (allHistory.length === 0) return null;

  allHistory.sort((a, b) => a.ts - b.ts);
  const merged: SysMetricsEntry[] = [];
  let i = 0;
  while (i < allHistory.length) {
    const bucket = [allHistory[i]];
    const bucketTs = allHistory[i].ts;
    let j = i + 1;
    while (j < allHistory.length && allHistory[j].ts - bucketTs < 2000) { bucket.push(allHistory[j]); j++; }
    const len = bucket.length;
    merged.push({
      ts: bucketTs,
      cpuPercent: Math.round(bucket.reduce((s, b) => s + b.cpuPercent, 0) / len * 100) / 100,
      memPercent: Math.round(bucket.reduce((s, b) => s + b.memPercent, 0) / len * 100) / 100,
      memUsedMb: Math.round(bucket.reduce((s, b) => s + b.memUsedMb, 0) / len),
      memTotalMb: Math.round(bucket.reduce((s, b) => s + b.memTotalMb, 0) / len),
      diskReadMbps: Math.round(bucket.reduce((s, b) => s + b.diskReadMbps, 0) / len * 100) / 100,
      diskWriteMbps: Math.round(bucket.reduce((s, b) => s + b.diskWriteMbps, 0) / len * 100) / 100,
      jmeterCpuPercent: null,
      jmeterMemMb: null,
    });
    i = j;
  }

  return { latest: latestEntry, history: merged };
}

interface PriorResultSummary {
  totalRequests: number;
  totalErrors: number;
  totalBytes: number;
  firstSampleTs: number | null;
}

interface AutoAbortBreachState {
  startedAt: number;
}

interface RemoteStream {
  aggregator: MetricsAggregator;
  emitInterval: ReturnType<typeof setInterval>;
  executionId: number;
  runId: string;
  testName: string | null;
  sampleCount: number;
  lastSampleAt: number;
  firstSampleTs: number | null;
  latestSampleTs: number;
  idleCheckInterval: ReturnType<typeof setInterval>;
  checkpointInterval: ReturnType<typeof setInterval>;
  lastCheckpointSampleCount: number;
  nodeMetrics: Map<string, NodeMetricsState>;
  notifiedViolationKeys: Set<string>;
  notifiedAnomalyIds: Set<string>;
  createdBy: number | null;
  priorResults: PriorResultSummary | null;
  streamStartedAt: number;
  idleTimeoutMs: number;
  idleWarningBroadcast: boolean;
  reconnectCount: number;
  linkedScriptId: number | null;
  autoAbortRules: AutoAbortRule[];
  autoAbortRulesLastRefresh: number;
  breachTracking: Map<number, AutoAbortBreachState>;
  isLocalJmeter: boolean;
}

const remoteStreams: Map<number, RemoteStream> = new Map();
const pendingStreamCreation: Map<number, Promise<void>> = new Map();
const stoppedWhilePending: Set<number> = new Set();
const MAX_NODE_HISTORY = 120;
const MAX_NODES = 500;

const abortedExecutions: Map<number, { reason: string; abortedAt: number }> = new Map();

export function triggerAbort(executionId: number, reason: string): void {
  abortedExecutions.set(executionId, { reason, abortedAt: Date.now() });
  console.log(`[remote-stream] Abort triggered for execution ${executionId}: ${reason}`);

  (async () => {
    try {
      const stream = remoteStreams.get(executionId);
      if (stream) {
        clearInterval(stream.emitInterval);
        clearInterval(stream.idleCheckInterval);
        clearInterval(stream.checkpointInterval);

        stream.aggregator.finalize();
        const finalSnapshot = stream.aggregator.getSnapshot();
        const finalSysMetrics = buildAggregatedSystemMetrics(stream.nodeMetrics);
        if (finalSysMetrics) {
          finalSnapshot.systemMetrics = finalSysMetrics;
        }
        if (finalSnapshot.summary.totalRequests > 0) {
          broadcastLiveMetrics(executionId, stream.runId, finalSnapshot);
        }

        const resultSummary = buildResultSummary(stream, finalSnapshot, true);
        (resultSummary as any).abortReason = reason;

        await db
          .update(testExecutions)
          .set({
            status: "aborted",
            endTime: new Date().toISOString(),
            resultSummary,
          } as any)
          .where(eq(testExecutions.id, executionId));

        broadcastExecutionUpdate(executionId, "aborted", resultSummary);
        console.log(`[remote-stream] Execution ${executionId} marked as aborted with ${resultSummary.totalRequests} total requests`);

        stream.aggregator.reset();
        remoteStreams.delete(executionId);
      } else {
        await db
          .update(testExecutions)
          .set({
            status: "aborted",
            endTime: new Date().toISOString(),
          } as any)
          .where(eq(testExecutions.id, executionId));
        broadcastExecutionUpdate(executionId, "aborted");
      }
    } catch (err) {
      console.error(`[remote-stream] Failed to finalize abort for execution ${executionId}:`, err);
    }
  })();
}

export function isAborted(executionId: number): boolean {
  return abortedExecutions.has(executionId);
}

export function getAbortInfo(executionId: number): { reason: string; abortedAt: number } | undefined {
  return abortedExecutions.get(executionId);
}

const EMIT_INTERVAL_MS = 2000;
const DEFAULT_IDLE_TIMEOUT_MS = 1_800_000;
const MIN_IDLE_TIMEOUT_MS = 300_000;
const IDLE_CHECK_MS = 30_000;
const CHECKPOINT_INTERVAL_MS = 60_000;
const IDLE_WARNING_THRESHOLD = 0.7;

function getEffectiveIdleTimeout(stream: RemoteStream): number {
  const runDurationMs = Date.now() - stream.streamStartedAt;
  const runDurationMin = runDurationMs / 60_000;

  let timeout = stream.idleTimeoutMs;

  if (runDurationMin > 60) {
    timeout = Math.max(timeout, 3_600_000);
  } else if (runDurationMin > 30) {
    timeout = Math.max(timeout, 2_700_000);
  }

  if (stream.sampleCount > 100_000) {
    timeout = Math.max(timeout, 2_700_000);
  }

  return Math.max(timeout, MIN_IDLE_TIMEOUT_MS);
}

function buildResultSummary(stream: RemoteStream, snapshot: any, isFinal: boolean): Record<string, any> {
  const summary = snapshot.summary;
  const fullTxDetails = stream.aggregator.getFullTransactionDetails();
  let peakRps = 0;

  const transactionDetails = fullTxDetails.map((t) => {
    const errorRate = t.count > 0 ? Math.round((t.errors / t.count) * 10000) / 100 : 0;
    const txElapsedMs = t.lastEndTimestamp > 0 && t.firstTimestamp > 0
      ? Math.max(1, t.lastEndTimestamp - t.firstTimestamp)
      : (summary.elapsedSeconds * 1000 || 1);
    const throughput = txElapsedMs > 0 ? Math.round((t.count / (txElapsedMs / 1000)) * 100) / 100 : 0;
    return {
      label: t.label,
      count: t.count,
      avg: t.avg,
      min: t.min,
      max: t.max,
      p50: t.p50,
      p90: t.p90,
      p95: t.p95,
      p99: t.p99,
      errorRate,
      errorCount: t.errors,
      throughput,
      hitsPerSec: throughput,
    };
  });

  if (snapshot.series && snapshot.series.length > 0) {
    peakRps = Math.max(...snapshot.series.map((s: any) => s.throughput || 0));
  }

  const globalPercentiles = stream.aggregator.getGlobalExactPercentiles();

  const prior = stream.priorResults;
  const cumulativeTotalRequests = summary.totalRequests + (prior?.totalRequests || 0);
  const cumulativeTotalErrors = summary.totalErrors + (prior?.totalErrors || 0);
  const cumulativeSuccessful = cumulativeTotalRequests - cumulativeTotalErrors;
  const cumulativeErrorRate = cumulativeTotalRequests > 0
    ? Math.round((cumulativeTotalErrors / cumulativeTotalRequests) * 10000) / 100
    : 0;

  const effectiveFirstTs = prior?.firstSampleTs && stream.firstSampleTs
    ? Math.min(prior.firstSampleTs, stream.firstSampleTs)
    : prior?.firstSampleTs || stream.firstSampleTs;
  const effectiveEndTs = stream.latestSampleTs > 0 ? stream.latestSampleTs : null;
  const effectiveDuration = effectiveFirstTs && effectiveEndTs
    ? Math.round((effectiveEndTs - effectiveFirstTs) / 1000)
    : summary.elapsedSeconds;
  const effectiveThroughput = effectiveDuration > 0
    ? Math.round((cumulativeTotalRequests / effectiveDuration) * 100) / 100
    : summary.throughput;

  return {
    totalRequests: cumulativeTotalRequests,
    successfulRequests: cumulativeSuccessful,
    failedRequests: cumulativeTotalErrors,
    avgResponseTime: summary.avgResponseTime,
    minResponseTime: globalPercentiles.min,
    maxResponseTime: globalPercentiles.max,
    throughput: effectiveThroughput,
    peakRps,
    p50: globalPercentiles.p50,
    p90: globalPercentiles.p90,
    p95: globalPercentiles.p95,
    p99: globalPercentiles.p99,
    errorRate: cumulativeErrorRate,
    durationSeconds: effectiveDuration,
    startTime: effectiveFirstTs ? new Date(effectiveFirstTs).toISOString() : null,
    endTime: effectiveEndTs ? new Date(effectiveEndTs).toISOString() : null,
    transactionDetails,
    errorSummary: [],
    errorDetails: snapshot.topErrors?.map((e: any) => ({
      label: e.label,
      count: e.errorCount,
      pct: e.errorRate / 100,
      response_code: e.errorCodes?.[0]?.code || "unknown",
      response_message: "",
    })) || [],
    timeseries: snapshot.series || [],
    anomalies: snapshot.anomalies || [],
    anomalySummary: snapshot.anomalySummary || { total: 0, warning: 0, critical: 0 },
    insights: snapshot.insights || [],
    insightSummary: snapshot.insightSummary || { total: 0, byType: {}, warning: 0, critical: 0 },
    correlationEvents: snapshot.correlationEvents || snapshot.insights || [],
    correlationSummary: snapshot.correlationSummary || snapshot.insightSummary || { total: 0, byType: {}, warning: 0, critical: 0 },
    machineMetrics: buildMachineMetricsSummary(stream),
    ...(prior ? { resumed: true, priorSampleCount: prior.totalRequests } : {}),
    ...(isFinal
      ? {}
      : {
          checkpoint: true,
          checkpointTime: new Date().toISOString(),
          _checkpoint: stream.aggregator.exportCheckpoint(),
        }),
  };
}

async function flushCheckpoint(stream: RemoteStream): Promise<void> {
  if (stream.sampleCount === 0 || stream.sampleCount === stream.lastCheckpointSampleCount) {
    return;
  }

  if (!remoteStreams.has(stream.executionId)) {
    return;
  }

  try {
    const snapshot = stream.aggregator.getSnapshot();
    const resultSummary = buildResultSummary(stream, snapshot, false);

    const result = await db
      .update(testExecutions)
      .set({ resultSummary } as any)
      .where(and(eq(testExecutions.id, stream.executionId), eq(testExecutions.status, "running")));

    if ((result as any)?.rowCount === 0) {
      return;
    }

    stream.lastCheckpointSampleCount = stream.sampleCount;
    console.log(`[remote-stream] Checkpoint saved for execution ${stream.executionId} (${stream.sampleCount} samples)`);
  } catch (err: any) {
    console.error(`[remote-stream] Checkpoint save failed for execution ${stream.executionId}:`, err?.message);
  }
}

export async function startRemoteStream(executionId: number, runId: string, testName?: string): Promise<void> {
  if (remoteStreams.has(executionId)) {
    console.log(`[remote-stream] Stream already active for execution ${executionId}`);
    return;
  }

  const pending = pendingStreamCreation.get(executionId);
  if (pending) {
    await pending;
    return;
  }

  const creationPromise = startRemoteStreamInternal(executionId, runId, testName);
  pendingStreamCreation.set(executionId, creationPromise);
  try {
    await creationPromise;
  } finally {
    pendingStreamCreation.delete(executionId);
  }
}

async function startRemoteStreamInternal(executionId: number, runId: string, testName?: string): Promise<void> {
  if (remoteStreams.has(executionId)) {
    return;
  }

  if (stoppedWhilePending.has(executionId)) {
    stoppedWhilePending.delete(executionId);
    console.log(`[remote-stream] Stream creation cancelled for execution ${executionId} (stop was requested)`);
    return;
  }

  console.log(`[remote-stream] Starting remote stream for execution ${executionId} (${runId})`);

  const aggregator = new MetricsAggregator();

  let scriptSlaRules: SlaRuleConfig[] = [];
  let resolvedScriptId: number | null = null;
  let loadedAutoAbortRules: AutoAbortRule[] = [];
  try {
    const execution = await storage.getExecution(executionId);
    if (execution?.scheduleId) {
      const schedule = await storage.getSchedule(execution.scheduleId);
      if (schedule?.scriptId) resolvedScriptId = schedule.scriptId;
      const schedConfig = schedule?.configuration as any;
      if (schedConfig?.rampUp && typeof schedConfig.rampUp === 'number' && schedConfig.rampUp > 0) {
        aggregator.setRampUpDuration(schedConfig.rampUp);
        console.log(`[remote-stream] Set ramp-up duration to ${schedConfig.rampUp}s for execution ${executionId}`);
      }
    }
    if (!resolvedScriptId && (execution as any)?.scriptId) {
      resolvedScriptId = (execution as any).scriptId;
    }
    if (resolvedScriptId) {
      const dbRules = await storage.getEnabledSlaRules(resolvedScriptId);
      if (dbRules.length > 0) {
        scriptSlaRules = dbRules.map((r) => ({
          id: r.id,
          transactionLabel: r.transactionLabel,
          metric: r.metric,
          comparator: r.comparator,
          threshold: r.threshold,
        }));
        aggregator.setSlaRules(scriptSlaRules);
        console.log(`[remote-stream] Loaded ${scriptSlaRules.length} SLA rules for execution ${executionId} from script ${resolvedScriptId}`);
      }
      try {
        loadedAutoAbortRules = await storage.getEnabledAutoAbortRules(resolvedScriptId);
        if (loadedAutoAbortRules.length > 0) {
          console.log(`[remote-stream] Loaded ${loadedAutoAbortRules.length} auto-abort rules for execution ${executionId} from script ${resolvedScriptId}`);
        }
      } catch (abortErr) {
        console.warn(`[remote-stream] Failed to load auto-abort rules for execution ${executionId}:`, abortErr);
      }
    }
  } catch (err) {
    console.warn(`[remote-stream] Failed to load SLA rules for execution ${executionId}:`, err);
  }

  try {
    const execRules = await storage.getEnabledExecutionSlaRules(executionId);
    if (execRules.length > 0) {
      const execConfigs: SlaRuleConfig[] = execRules.map((r) => ({
        id: r.id + 1000000,
        transactionLabel: r.transactionLabel,
        metric: r.metric,
        comparator: r.comparator,
        threshold: r.threshold,
      }));
      const merged = [...scriptSlaRules, ...execConfigs];
      aggregator.setSlaRules(merged);
      console.log(`[remote-stream] Loaded ${execRules.length} execution-level SLA rules for execution ${executionId}`);
    }
  } catch (err) {
    console.warn(`[remote-stream] Failed to load execution SLA rules:`, err);
  }

  try {
    const execAbortRules = await storage.getEnabledExecutionAutoAbortRules(executionId);
    if (execAbortRules.length > 0) {
      const mapped = execAbortRules.map(r => ({
        ...r,
        id: r.id + 2000000,
        scriptId: 0,
      }));
      loadedAutoAbortRules = [...loadedAutoAbortRules, ...mapped];
      console.log(`[remote-stream] Loaded ${execAbortRules.length} execution-level auto-abort rules for execution ${executionId}`);
    }
  } catch (err) {
    console.warn(`[remote-stream] Failed to load execution auto-abort rules:`, err);
  }

  let createdByUser: number | null = null;
  let priorResults: PriorResultSummary | null = null;
  try {
    const exec = await storage.getExecution(executionId);
    if (exec?.scheduleId) {
      const sched = await storage.getSchedule(exec.scheduleId);
      if (sched) createdByUser = sched.createdBy ?? null;
    }
    if (exec?.resultSummary && typeof exec.resultSummary === "object") {
      const prev = exec.resultSummary as any;
      if (prev.totalRequests > 0) {
        priorResults = {
          totalRequests: prev.totalRequests || 0,
          totalErrors: prev.totalErrors || 0,
          totalBytes: prev.totalBytes || 0,
          firstSampleTs: prev.startTime ? new Date(prev.startTime).getTime() : null,
        };
        console.log(`[remote-stream] Loaded prior results for execution ${executionId}: ${priorResults.totalRequests} requests, ${priorResults.totalErrors} errors`);

        if (prev._checkpoint && typeof prev._checkpoint === "object" && [2, 3, 4].includes(prev._checkpoint.version)) {
          aggregator.importCheckpoint(prev._checkpoint as AggregatorCheckpoint);
          priorResults = null;
          console.log(`[remote-stream] Imported checkpoint v${prev._checkpoint.version} for execution ${executionId} — metrics restored from prior state`);
        }
      }
    }
  } catch {}

  const stream: RemoteStream = {
    aggregator,
    emitInterval: null as any,
    executionId,
    runId,
    testName: testName || null,
    sampleCount: 0,
    lastSampleAt: Date.now(),
    firstSampleTs: null,
    latestSampleTs: 0,
    idleCheckInterval: null as any,
    checkpointInterval: null as any,
    lastCheckpointSampleCount: 0,
    nodeMetrics: new Map(),
    notifiedViolationKeys: new Set(),
    notifiedAnomalyIds: new Set(),
    createdBy: createdByUser,
    priorResults,
    streamStartedAt: Date.now(),
    idleTimeoutMs: DEFAULT_IDLE_TIMEOUT_MS,
    idleWarningBroadcast: false,
    reconnectCount: 0,
    linkedScriptId: resolvedScriptId,
    autoAbortRules: loadedAutoAbortRules,
    autoAbortRulesLastRefresh: Date.now(),
    breachTracking: new Map(),
    isLocalJmeter: false,
  };

  let slaRefreshCounter = 0;
  stream.emitInterval = setInterval(() => {
    slaRefreshCounter++;
    if (slaRefreshCounter % 6 === 0) {
      storage.getEnabledExecutionSlaRules(executionId).then(execRules => {
        const execConfigs: SlaRuleConfig[] = execRules.map((r) => ({
          id: r.id + 1000000,
          transactionLabel: r.transactionLabel,
          metric: r.metric,
          comparator: r.comparator,
          threshold: r.threshold,
        }));
        const merged = [...scriptSlaRules, ...execConfigs];
        aggregator.setSlaRules(merged);
      }).catch((err) => console.warn("[remote-stream] Failed to refresh SLA rules:", err?.message));
    }

    const snapshot = aggregator.getSnapshot();
    if (stream.nodeMetrics.size > 0) {
      const nodesObj: Record<string, { latest: RemoteMachineMetricsSample | null; history: Array<{ ts: number; cpuPercent: number; memPercent: number; diskReadMbps: number; diskWriteMbps: number }> }> = {};
      stream.nodeMetrics.forEach((state, nodeId) => {
        nodesObj[nodeId] = {
          latest: state.latest,
          history: state.history.map(s => ({
            ts: s.ts,
            cpuPercent: s.cpuPercent,
            memPercent: s.memPercent,
            diskReadMbps: s.diskReadMbps,
            diskWriteMbps: s.diskWriteMbps,
          })),
        };
      });
      (snapshot as any).machineMetrics = nodesObj;

      const aggSysMetrics = buildAggregatedSystemMetrics(stream.nodeMetrics);
      if (aggSysMetrics) {
        snapshot.systemMetrics = aggSysMetrics;
      }
    }

    if (snapshot.summary.totalRequests > 0) {
      broadcastLiveMetrics(executionId, runId, snapshot);
    }

    if (snapshot.slaViolations && snapshot.slaViolations.length > 0 && snapshot.summary.totalRequests >= 100) {
      handleRemoteSlaViolations(stream, snapshot);
    }

    if (snapshot.summary.totalRequests >= 100) {
      evaluateAutoAbortRules(stream, snapshot);
    }

    if (snapshot.anomalies && snapshot.anomalies.length > 0) {
      const newAnomalies = snapshot.anomalies.filter(a => {
        const key = `${a.metricType}_${a.timestamp}`;
        return !stream.notifiedAnomalyIds.has(key);
      });
      if (newAnomalies.length > 0) {
        for (const a of newAnomalies) {
          stream.notifiedAnomalyIds.add(`${a.metricType}_${a.timestamp}`);
        }
        import("../webhook-dispatcher").then(({ dispatchWebhookEvent, WEBHOOK_EVENTS }) => {
          dispatchWebhookEvent(WEBHOOK_EVENTS.ANOMALY_DETECTED, {
            executionId: stream.executionId,
            testName: stream.testName,
            environment: "remote",
            anomalies: newAnomalies.map(a => ({
              severity: a.severity,
              metricType: a.metricType,
              description: a.description,
              value: a.value,
              rollingMedian: a.rollingMedian,
              zScore: a.zScore,
            })),
            timestamp: Date.now(),
          });
        }).catch(() => {});
      }
    }
  }, EMIT_INTERVAL_MS);

  stream.idleCheckInterval = setInterval(async () => {
    const idleMs = Date.now() - stream.lastSampleAt;
    const effectiveTimeout = getEffectiveIdleTimeout(stream);

    const warningThresholdMs = effectiveTimeout * IDLE_WARNING_THRESHOLD;
    if (idleMs > warningThresholdMs && !stream.idleWarningBroadcast) {
      stream.idleWarningBroadcast = true;
      const remainingSec = Math.round((effectiveTimeout - idleMs) / 1000);
      console.log(`[remote-stream] WARNING: Execution ${executionId} idle for ${Math.round(idleMs / 1000)}s, will auto-complete in ~${remainingSec}s if no samples arrive`);
      broadcastLiveMetrics(executionId, stream.runId, {
        ...stream.aggregator.getSnapshot(),
        _idleWarning: {
          idleSeconds: Math.round(idleMs / 1000),
          timeoutSeconds: Math.round(effectiveTimeout / 1000),
          remainingSeconds: remainingSec,
        },
      } as any);
      try {
        await flushCheckpoint(stream);
      } catch {}
    }

    if (idleMs > effectiveTimeout) {
      console.log(`[remote-stream] Execution ${executionId} idle for ${Math.round(idleMs / 1000)}s (timeout: ${Math.round(effectiveTimeout / 1000)}s), stopping stream`);
      await stopRemoteStream(executionId);
    }
  }, IDLE_CHECK_MS);

  stream.checkpointInterval = setInterval(() => {
    flushCheckpoint(stream).catch((err) => {
      console.error(`[remote-stream] Checkpoint error for execution ${executionId}:`, err?.message);
    });
  }, CHECKPOINT_INTERVAL_MS);

  if (stoppedWhilePending.has(executionId)) {
    stoppedWhilePending.delete(executionId);
    clearInterval(stream.emitInterval);
    clearInterval(stream.idleCheckInterval);
    clearInterval(stream.checkpointInterval);
    console.log(`[remote-stream] Stream creation cancelled late for execution ${executionId} (stop was requested during init)`);
    return;
  }

  remoteStreams.set(executionId, stream);
}

export function feedRemoteSamples(executionId: number, rows: JtlRow[]): void {
  const stream = remoteStreams.get(executionId);
  if (!stream) {
    console.warn(`[remote-stream] No active stream for execution ${executionId}`);
    return;
  }

  let nonParentCount = 0;
  let minTs = stream.firstSampleTs ?? Infinity;
  let maxTs = stream.latestSampleTs;

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    stream.aggregator.addSample(row);
    if (!row.parentSample) {
      nonParentCount++;
    }
    const ts = row.timestamp;
    if (ts > 0) {
      if (ts < minTs) minTs = ts;
      if (ts > maxTs) maxTs = ts;
    }
  }

  if (minTs < Infinity) {
    if (stream.firstSampleTs === null || minTs < stream.firstSampleTs) {
      stream.firstSampleTs = minTs;
    }
  }
  if (maxTs > stream.latestSampleTs) {
    stream.latestSampleTs = maxTs;
  }

  stream.sampleCount += nonParentCount;
  stream.lastSampleAt = Date.now();
  if (stream.idleWarningBroadcast) {
    stream.idleWarningBroadcast = false;
    console.log(`[remote-stream] Execution ${executionId} resumed receiving samples after idle warning`);
  }
}

export function updateRemoteStreamTestName(executionId: number, testName: string): void {
  const stream = remoteStreams.get(executionId);
  if (stream && !stream.testName) {
    stream.testName = testName;
  }
}

export function heartbeatRemoteStream(executionId: number): boolean {
  const stream = remoteStreams.get(executionId);
  if (!stream) return false;
  stream.lastSampleAt = Date.now();
  if (stream.idleWarningBroadcast) {
    stream.idleWarningBroadcast = false;
  }
  return true;
}

export function setRemoteStreamIdleTimeout(executionId: number, timeoutMs: number): boolean {
  const stream = remoteStreams.get(executionId);
  if (!stream) return false;
  stream.idleTimeoutMs = Math.max(timeoutMs, MIN_IDLE_TIMEOUT_MS);
  console.log(`[remote-stream] Idle timeout for execution ${executionId} set to ${Math.round(stream.idleTimeoutMs / 1000)}s`);
  return true;
}

export function getRemoteStreamStatus(executionId: number): { active: boolean; idleSeconds: number; timeoutSeconds: number; sampleCount: number; reconnectCount: number } | null {
  const stream = remoteStreams.get(executionId);
  if (!stream) return null;
  return {
    active: true,
    idleSeconds: Math.round((Date.now() - stream.lastSampleAt) / 1000),
    timeoutSeconds: Math.round(getEffectiveIdleTimeout(stream) / 1000),
    sampleCount: stream.sampleCount,
    reconnectCount: stream.reconnectCount,
  };
}

export async function stopRemoteStream(executionId: number): Promise<void> {
  if (pendingStreamCreation.has(executionId)) {
    stoppedWhilePending.add(executionId);
    console.log(`[remote-stream] Stop requested while stream creation pending for execution ${executionId}, marking for cleanup`);
    try {
      await pendingStreamCreation.get(executionId);
    } catch {}
  }

  const stream = remoteStreams.get(executionId);
  if (!stream) return;

  console.log(`[remote-stream] Stopping remote stream for execution ${executionId} (${stream.sampleCount} total samples)`);

  clearInterval(stream.emitInterval);
  clearInterval(stream.idleCheckInterval);
  clearInterval(stream.checkpointInterval);

  stream.aggregator.finalize();
  const finalSnapshot = stream.aggregator.getSnapshot();
  const finalSysMetrics = buildAggregatedSystemMetrics(stream.nodeMetrics);
  if (finalSysMetrics) {
    finalSnapshot.systemMetrics = finalSysMetrics;
  }
  if (finalSnapshot.summary.totalRequests > 0) {
    broadcastLiveMetrics(executionId, stream.runId, finalSnapshot);
  }

  try {
    const resultSummary = buildResultSummary(stream, finalSnapshot, true);

    console.log(`[remote-stream] Execution ${executionId} final metrics:`);
    console.log(`  Total samples: ${resultSummary.totalRequests}, Avg RT: ${resultSummary.avgResponseTime}ms, Throughput: ${resultSummary.throughput}/sec`);
    console.log(`  P50: ${resultSummary.p50}, P90: ${resultSummary.p90}, P95: ${resultSummary.p95}, P99: ${resultSummary.p99}`);

    await db
      .update(testExecutions)
      .set({
        status: "completed",
        endTime: new Date().toISOString(),
        resultSummary,
      } as any)
      .where(eq(testExecutions.id, executionId));

    broadcastExecutionUpdate(executionId, "completed", resultSummary);
    console.log(`[remote-stream] Execution ${executionId} marked as completed with ${resultSummary.totalRequests} total requests`);

    try {
      const startMs = stream.firstSampleTs || 0;
      const endMs = stream.latestSampleTs || Date.now();
      const durationSeconds = startMs ? Math.round((endMs - startMs) / 1000) : 0;

      const executionRow = await db.select({ releaseTag: testExecutions.releaseTag }).from(testExecutions).where(eq(testExecutions.id, executionId)).limit(1);
      await storage.createTestTrackerRecord({
        runId: stream.runId,
        executionTimestamp: startMs ? new Date(startMs).toISOString() : new Date().toISOString(),
        projectId: null,
        projectName: stream.testName || stream.runId || `remote-${executionId}`,
        featureName: `${stream.testName || stream.runId || 'remote'} #${executionId}`,
        testTypeId: null,
        testTypeName: null,
        volume: null,
        environment: "remote",
        comments: null,
        status: "completed",
        durationSeconds,
        avgResponseTime: Math.round(resultSummary.avgResponseTime || 0),
        p95: resultSummary.p95 ? Math.round(resultSummary.p95) : null,
        p99: resultSummary.p99 ? Math.round(resultSummary.p99) : null,
        throughput: Math.round(resultSummary.throughput || 0),
        errorRate: Math.round((resultSummary.errorRate || 0) * 100),
        executionId,
        releaseTag: executionRow[0]?.releaseTag || null,
      });
      console.log(`[remote-stream] Tracker record created for remote execution ${executionId}`);
    } catch (trackerError) {
      console.error(`[remote-stream] Failed to create tracker record for execution ${executionId}:`, trackerError);
    }
  } catch (err) {
    console.error(`[remote-stream] Failed to finalize execution ${executionId}:`, err);
  }

  stream.aggregator.reset();
  remoteStreams.delete(executionId);
}

export function isRemoteStreamActive(executionId: number): boolean {
  return remoteStreams.has(executionId) || pendingStreamCreation.has(executionId);
}

export function getRemoteStreamSnapshot(executionId: number) {
  const stream = remoteStreams.get(executionId);
  if (!stream) return null;
  const snapshot = stream.aggregator.getSnapshot();

  const aggSysMetrics = buildAggregatedSystemMetrics(stream.nodeMetrics);
  if (aggSysMetrics) {
    snapshot.systemMetrics = aggSysMetrics;
  }

  return snapshot;
}

export async function stopAllRemoteStreams(): Promise<void> {
  const ids = Array.from(remoteStreams.keys());
  for (const executionId of ids) {
    await stopRemoteStream(executionId);
  }
}

export function feedRemoteMachineMetrics(executionId: number, nodeId: string, sample: RemoteMachineMetricsSample): void {
  const stream = remoteStreams.get(executionId);
  if (!stream) return;

  let state = stream.nodeMetrics.get(nodeId);
  if (!state) {
    if (stream.nodeMetrics.size >= MAX_NODES) return;
    state = { latest: null, history: [] };
    stream.nodeMetrics.set(nodeId, state);
  }

  state.latest = sample;
  state.history.push(sample);
  while (state.history.length > MAX_NODE_HISTORY) {
    state.history.shift();
  }
}

export function getRemoteMachineMetrics(executionId: number): Record<string, { latest: RemoteMachineMetricsSample | null; history: RemoteMachineMetricsSample[] }> | null {
  const stream = remoteStreams.get(executionId);
  if (!stream || stream.nodeMetrics.size === 0) return null;

  const result: Record<string, { latest: RemoteMachineMetricsSample | null; history: RemoteMachineMetricsSample[] }> = {};
  stream.nodeMetrics.forEach((state, nodeId) => {
    result[nodeId] = { latest: state.latest, history: [...state.history] };
  });
  return result;
}

function violationKey(v: SlaViolation): string {
  return `${v.ruleId}:${v.metric}:${v.transactionLabel || "__global__"}`;
}

function handleRemoteSlaViolations(stream: RemoteStream, snapshot: LiveMetricsSnapshot): void {
  const newViolations: SlaViolation[] = [];
  for (const v of snapshot.slaViolations) {
    const key = violationKey(v);
    if (!stream.notifiedViolationKeys.has(key)) {
      stream.notifiedViolationKeys.add(key);
      newViolations.push(v);
    }
  }
  if (newViolations.length === 0) return;

  console.log(`[remote-stream] ${newViolations.length} SLA violation(s) detected for remote execution ${stream.executionId}`);

  const notifyUserId = stream.createdBy;
  if (!notifyUserId) {
    storage.getAdminUsers().then(admins => {
      for (const admin of admins) {
        createSlaNotification(admin.id, stream, newViolations);
      }
    }).catch((err) => console.warn("[remote-stream] Failed to fetch admin users for SLA notification:", err?.message));
  } else {
    createSlaNotification(notifyUserId, stream, newViolations);
  }
}

function createSlaNotification(userId: number, stream: RemoteStream, violations: SlaViolation[]): void {
  const summary = violations.map(v => {
    const tx = v.transactionLabel ? `[${v.transactionLabel}] ` : "";
    return `${tx}${v.metric}: ${v.actualValue.toFixed(2)} (limit: ${v.threshold})`;
  }).join("; ");

  storage.shouldSendNotification(userId, 'sla_violation').then(shouldNotify => {
    if (shouldNotify) {
      storage.createNotification({
        userId,
        title: `SLA Breach — ${stream.testName || 'Remote Execution'}`,
        message: `SLA violation in remote test: ${summary}`,
        type: "warning",
        link: `/executions/${stream.executionId}`,
      }).catch((err) => console.warn("[remote-stream] Failed to create SLA notification:", err?.message));
    }
  }).catch((err) => console.warn("[remote-stream] Failed to check notification preferences:", err?.message));
}

const AUTO_ABORT_RULES_REFRESH_MS = 10_000;

function getAutoAbortMetricValue(
  snapshot: LiveMetricsSnapshot,
  metric: string
): number | null {
  switch (metric) {
    case "errorRate":
      return snapshot.summary.errorRate;
    case "avgResponseTime":
      return snapshot.summary.avgResponseTime;
    case "p90": {
      const p90Tx = snapshot.allTransactions;
      if (p90Tx.length === 0) return null;
      let total = 0, count = 0;
      for (const tx of p90Tx) { total += tx.p90 * tx.count; count += tx.count; }
      return count > 0 ? total / count : null;
    }
    case "p95":
      return snapshot.summary.p95;
    case "p99":
      return snapshot.summary.p99;
    case "maxResponseTime": {
      let maxVal = 0;
      for (const tx of snapshot.allTransactions) {
        if (tx.max > maxVal) maxVal = tx.max;
      }
      return maxVal;
    }
    case "throughput":
      return snapshot.summary.throughput;
    default:
      return null;
  }
}

function isAutoAbortBreached(actualValue: number, threshold: number, comparator: string): boolean {
  switch (comparator) {
    case "gt": return actualValue > threshold;
    case "gte": return actualValue >= threshold;
    case "lt": return actualValue < threshold;
    case "lte": return actualValue <= threshold;
    default: return false;
  }
}

async function evaluateAutoAbortRules(stream: RemoteStream, snapshot: LiveMetricsSnapshot): Promise<void> {
  if (isAborted(stream.executionId)) return;

  const now = Date.now();
  if (now - stream.autoAbortRulesLastRefresh > AUTO_ABORT_RULES_REFRESH_MS) {
    stream.autoAbortRulesLastRefresh = now;
    try {
      let scriptRules: AutoAbortRule[] = [];
      if (stream.linkedScriptId) {
        try {
          scriptRules = await storage.getEnabledAutoAbortRules(stream.linkedScriptId);
        } catch (err: any) {
          console.warn("[remote-stream] Failed to refresh script auto-abort rules:", err?.message);
          scriptRules = stream.autoAbortRules.filter(r => r.id < 2000000);
        }
      }

      let execMapped: AutoAbortRule[] = [];
      try {
        const execRules = await storage.getEnabledExecutionAutoAbortRules(stream.executionId);
        execMapped = execRules.map(r => ({ ...r, id: r.id + 2000000, scriptId: 0 }));
      } catch (err: any) {
        console.warn("[remote-stream] Failed to refresh execution auto-abort rules:", err?.message);
        execMapped = stream.autoAbortRules.filter(r => r.id >= 2000000);
      }

      stream.autoAbortRules = [...scriptRules, ...execMapped];
    } catch (err) {
      console.warn("[remote-stream] Failed to refresh auto-abort rules:", err);
    }
  }

  if (stream.autoAbortRules.length === 0) return;

  const activeRuleIds = new Set<number>();

  for (const rule of stream.autoAbortRules) {
    activeRuleIds.add(rule.id);
    const actualValue = getAutoAbortMetricValue(snapshot, rule.metric);
    if (actualValue === null) continue;

    const breached = isAutoAbortBreached(actualValue, rule.threshold, rule.comparator);

    if (breached) {
      if (!stream.breachTracking.has(rule.id)) {
        stream.breachTracking.set(rule.id, { startedAt: now });
        console.log(`[auto-abort] Breach started for rule ${rule.id} (${rule.metric} ${rule.comparator} ${rule.threshold}): actual=${actualValue.toFixed(2)}, execution ${stream.executionId}`);

        broadcast({
          type: "execution_update",
          executionId: stream.executionId,
          status: "running",
          resultSummary: {
            _autoAbortWarning: {
              ruleId: rule.id,
              metric: rule.metric,
              comparator: rule.comparator,
              threshold: rule.threshold,
              actualValue,
              sustainedSeconds: rule.sustainedSeconds,
              breachStartedAt: now,
            },
          },
        });
      }

      const breach = stream.breachTracking.get(rule.id)!;
      const breachDurationSec = (now - breach.startedAt) / 1000;

      if (breachDurationSec >= rule.sustainedSeconds) {
        const reason = `Auto-abort: ${rule.metric} ${rule.comparator} ${rule.threshold} breached for ${Math.round(breachDurationSec)}s (actual: ${actualValue.toFixed(2)}, sustained threshold: ${rule.sustainedSeconds}s)`;
        console.log(`[auto-abort] Triggering abort for execution ${stream.executionId}: ${reason}`);

        triggerAbort(stream.executionId, reason);

        if (stream.isLocalJmeter) {
          try {
            const { cancelRun } = require("../jmeter-worker");
            cancelRun(stream.executionId);
          } catch (err) {
            console.error(`[auto-abort] Failed to cancel local JMeter run for execution ${stream.executionId}:`, err);
          }
        }

        if (stream.createdBy) {
          storage.shouldSendNotification(stream.createdBy, 'sla_violation').then(shouldNotify => {
            if (shouldNotify) {
              storage.createNotification({
                userId: stream.createdBy!,
                title: `Test Auto-Aborted — ${stream.testName || 'Execution'}`,
                message: reason,
                type: "error",
                link: `/executions/${stream.executionId}`,
              }).catch((err) => console.warn("[remote-stream] Failed to create auto-abort notification:", err?.message));
            }
          }).catch((err) => console.warn("[remote-stream] Failed to check notification preferences:", err?.message));
        } else {
          storage.getAdminUsers().then(admins => {
            for (const admin of admins) {
              storage.createNotification({
                userId: admin.id,
                title: `Test Auto-Aborted — ${stream.testName || 'Execution'}`,
                message: reason,
                type: "error",
                link: `/executions/${stream.executionId}`,
              }).catch((err) => console.warn("[remote-stream] Failed to create admin auto-abort notification:", err?.message));
            }
          }).catch((err) => console.warn("[remote-stream] Failed to fetch admin users:", err?.message));
        }

        return;
      }
    } else {
      if (stream.breachTracking.has(rule.id)) {
        console.log(`[auto-abort] Breach recovered for rule ${rule.id} (${rule.metric}), execution ${stream.executionId}`);
        stream.breachTracking.delete(rule.id);
      }
    }
  }

  const trackedRuleIds = Array.from(stream.breachTracking.keys());
  for (const ruleId of trackedRuleIds) {
    if (!activeRuleIds.has(ruleId)) {
      stream.breachTracking.delete(ruleId);
    }
  }
}

function buildMachineMetricsSummary(stream: RemoteStream): Record<string, any> | null {
  if (stream.nodeMetrics.size === 0) return null;

  const nodes: Record<string, any> = {};
  stream.nodeMetrics.forEach((state, nodeId) => {
    const history = state.history;
    if (history.length === 0) {
      nodes[nodeId] = { timeseries: [], summary: null };
      return;
    }

    let totalCpu = 0, maxCpu = 0, totalMemPercent = 0, maxMemPercent = 0, maxMemMb = 0;
    let peakDiskRead = 0, peakDiskWrite = 0;
    for (const s of history) {
      totalCpu += s.cpuPercent;
      maxCpu = Math.max(maxCpu, s.cpuPercent);
      totalMemPercent += s.memPercent;
      maxMemPercent = Math.max(maxMemPercent, s.memPercent);
      maxMemMb = Math.max(maxMemMb, s.memUsedMb);
      peakDiskRead = Math.max(peakDiskRead, s.diskReadMbps);
      peakDiskWrite = Math.max(peakDiskWrite, s.diskWriteMbps);
    }

    nodes[nodeId] = {
      timeseries: history,
      summary: {
        avgCpu: Math.round((totalCpu / history.length) * 100) / 100,
        maxCpu: Math.round(maxCpu * 100) / 100,
        avgMemPercent: Math.round((totalMemPercent / history.length) * 100) / 100,
        maxMemPercent: Math.round(maxMemPercent * 100) / 100,
        maxMemMb,
        memTotalMb: history[history.length - 1].memTotalMb,
        peakDiskReadMbps: Math.round(peakDiskRead * 100) / 100,
        peakDiskWriteMbps: Math.round(peakDiskWrite * 100) / 100,
        sampleCount: history.length,
      },
    };
  });

  return nodes;
}
