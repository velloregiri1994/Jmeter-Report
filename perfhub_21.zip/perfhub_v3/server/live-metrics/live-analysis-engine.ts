import { RollingStats, getErrorRate, linearRegressionSlope, type NormalizedTimeseriesPoint } from "./stats-utils";

export type MetricType = "response_time" | "error_rate" | "throughput";
export type Severity = "warning" | "critical";

export interface Anomaly {
  metricType: MetricType;
  timestamp: number;
  severity: Severity;
  value: number;
  rollingMedian: number;
  zScore: number;
  description: string;
  explanation: string;
  confidence?: number;
}

export type InsightType =
  | "error_spike"
  | "server_overloaded"
  | "throughput_collapse"
  | "backend_slowdown"
  | "gradual_degradation"
  | "tail_latency";

export type InsightSeverity = "warning" | "critical";

export interface PerformanceInsight {
  type: InsightType;
  severity: InsightSeverity;
  title: string;
  description: string;
  startTimestamp: number;
  endTimestamp: number;
  evidence: {
    responseTime?: { value: number; baseline: number };
    errorRate?: { value: number; baseline: number };
    throughput?: { value: number; baseline: number };
    p95?: { value: number; baseline: number };
  };
}

export interface LiveAnalysisConfig {
  windowSize: number;
  degradationWindowSize: number;
  minSamples: number;
  cooldownSec: number;
  warningZ: number;
  criticalZ: number;
  ewmaAlpha: number;
  insightCooldownMs: number;
  enabled: {
    response_time: boolean;
    error_rate: boolean;
    throughput: boolean;
  };
}

const DEFAULT_CONFIG: LiveAnalysisConfig = {
  windowSize: 30,
  degradationWindowSize: 60,
  minSamples: 15,
  cooldownSec: 45,
  warningZ: 2.5,
  criticalZ: 4,
  ewmaAlpha: 0.15,
  insightCooldownMs: 60000,
  enabled: {
    response_time: true,
    error_rate: true,
    throughput: true,
  },
};

const INSIGHT_TITLES: Record<InsightType, string> = {
  error_spike: "High Error Rate",
  server_overloaded: "Server Overloaded",
  throughput_collapse: "Throughput Collapse",
  backend_slowdown: "Backend Slowdown",
  gradual_degradation: "Gradual Performance Decline",
  tail_latency: "Tail Latency Issue",
};

export interface AnalysisResult {
  anomalies: Anomaly[];
  insights: PerformanceInsight[];
}

export class LiveAnalysisEngine {
  private config: LiveAnalysisConfig;

  private rtStats: RollingStats;
  private errStats: RollingStats;
  private tpStats: RollingStats;
  private p95Stats: RollingStats;
  private rtLongBuf: RollingStats;

  private sampleIndex: number = 0;
  private totalExpectedSamples: number = 0;
  private rampUpDurationMs: number = 0;
  private firstDataPointTime: number = 0;
  private lastDataPointTime: number = 0;

  private ewmaRT: number = 0;
  private ewmaErr: number = 0;
  private ewmaTp: number = 0;
  private ewmaInitialized: boolean = false;

  private lastAnomalyTime: Record<MetricType, number> = {
    response_time: 0,
    error_rate: 0,
    throughput: 0,
  };
  private anomalies: Anomaly[] = [];
  private maxStoredAnomalies: number = 500;

  private insights: PerformanceInsight[] = [];
  private maxStoredInsights: number = 100;
  private activeInsights: Map<InsightType, PerformanceInsight> = new Map();
  private lastInsightEmitTime: Map<InsightType, number> = new Map();

  constructor(config?: Partial<LiveAnalysisConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    if (config?.enabled) {
      this.config.enabled = { ...DEFAULT_CONFIG.enabled, ...config.enabled };
    }
    this.rtStats = new RollingStats(this.config.windowSize);
    this.errStats = new RollingStats(this.config.windowSize);
    this.tpStats = new RollingStats(this.config.windowSize);
    this.p95Stats = new RollingStats(this.config.windowSize);
    this.rtLongBuf = new RollingStats(this.config.degradationWindowSize);
  }

  setTotalExpectedSamples(total: number): void {
    this.totalExpectedSamples = total;
  }

  setRampUpDuration(seconds: number): void {
    this.rampUpDurationMs = seconds * 1000;
  }

  getWindowSize(): number {
    return this.config.windowSize;
  }

  resizeWindow(newSize: number): void {
    if (newSize <= this.config.windowSize) return;
    this.config.windowSize = newSize;
    this.rtStats = this.rebuildStats(this.rtStats, newSize);
    this.errStats = this.rebuildStats(this.errStats, newSize);
    this.tpStats = this.rebuildStats(this.tpStats, newSize);
    this.p95Stats = this.rebuildStats(this.p95Stats, newSize);
    const newDegSize = Math.max(this.config.degradationWindowSize, newSize * 2);
    if (newDegSize > this.rtLongBuf.capacity) {
      this.config.degradationWindowSize = newDegSize;
      this.rtLongBuf = this.rebuildStats(this.rtLongBuf, newDegSize);
    }
  }

  private rebuildStats(old: RollingStats, newSize: number): RollingStats {
    const vals = old.values();
    const s = new RollingStats(newSize);
    for (const v of vals) s.push(v);
    return s;
  }

  addDataPoint(
    timestamp: number,
    avgResponseTime: number,
    p95ResponseTime: number,
    errorRate: number,
    throughput: number,
    activeThreads: number
  ): AnalysisResult {
    this.sampleIndex++;
    if (this.firstDataPointTime === 0 && timestamp > 0) {
      this.firstDataPointTime = timestamp;
    }
    if (timestamp > 0) {
      this.lastDataPointTime = timestamp;
    }

    this.updateEwma(avgResponseTime, errorRate, throughput);

    const result: AnalysisResult = { anomalies: [], insights: [] };

    if (this.isInTransientPhase()) {
      this.pushAllBuffers(avgResponseTime, p95ResponseTime, errorRate, throughput);
      return result;
    }

    if (this.config.enabled.response_time) {
      const a = this.checkResponseTimeSpike(timestamp, avgResponseTime);
      if (a) result.anomalies.push(a);
    }
    if (this.config.enabled.error_rate) {
      const a = this.checkErrorRateSpike(timestamp, errorRate);
      if (a) result.anomalies.push(a);
    }
    if (this.config.enabled.throughput) {
      const a = this.checkThroughputDrop(timestamp, throughput);
      if (a) result.anomalies.push(a);
    }

    if (this.sampleIndex > this.config.minSamples) {
      const ctx = this.buildInsightContext(timestamp, avgResponseTime, p95ResponseTime, errorRate, throughput);
      this.detectInsights(ctx, result.insights);
    }

    this.pushAllBuffers(avgResponseTime, p95ResponseTime, errorRate, throughput);

    for (const a of result.anomalies) {
      this.anomalies.push(a);
    }
    if (this.anomalies.length > this.maxStoredAnomalies) {
      this.anomalies = this.anomalies.slice(-this.maxStoredAnomalies);
    }

    for (const ins of result.insights) {
      this.insights.push(ins);
    }
    if (this.insights.length > this.maxStoredInsights) {
      this.insights = this.insights.slice(-this.maxStoredInsights);
    }

    return result;
  }

  private pushAllBuffers(avgRT: number, p95: number, errRate: number, tp: number): void {
    this.rtStats.push(avgRT);
    this.errStats.push(errRate);
    this.tpStats.push(tp);
    this.p95Stats.push(p95);
    this.rtLongBuf.push(avgRT);
  }

  private isInTransientPhase(): boolean {
    if (this.rampUpDurationMs > 0 && this.firstDataPointTime > 0) {
      const lastTs = this.lastDataPointTime || this.firstDataPointTime;
      const elapsedMs = lastTs - this.firstDataPointTime;
      if (elapsedMs < this.rampUpDurationMs) return true;
    }
    if (this.sampleIndex <= this.config.minSamples) return true;
    if (this.totalExpectedSamples > 0) {
      const pct = this.sampleIndex / this.totalExpectedSamples;
      if (pct < 0.1) return true;
      if (pct > 0.95) return true;
    }
    return false;
  }

  private updateEwma(rt: number, err: number, tp: number): void {
    const alpha = this.config.ewmaAlpha;
    if (!this.ewmaInitialized) {
      this.ewmaRT = rt;
      this.ewmaErr = err;
      this.ewmaTp = tp;
      this.ewmaInitialized = true;
    } else {
      this.ewmaRT = alpha * rt + (1 - alpha) * this.ewmaRT;
      this.ewmaErr = alpha * err + (1 - alpha) * this.ewmaErr;
      this.ewmaTp = alpha * tp + (1 - alpha) * this.ewmaTp;
    }
  }

  private computeModifiedZ(value: number, stats: RollingStats): { z: number; median: number; mad: number; lowVariance: boolean } {
    const median = stats.median;
    const mad = stats.mad;
    if (mad < 0.001) {
      const diff = Math.abs(value - median);
      const syntheticZ = median > 0 ? (diff / median) * 10 : (diff > 1 ? diff : 0);
      return { z: syntheticZ, median, mad, lowVariance: true };
    }
    const z = (value - median) / mad;
    return { z, median, mad, lowVariance: false };
  }

  private computeConfidence(absZ: number, sampleCount: number, ewmaDivergence: number): number {
    const zComponent = Math.min(absZ / 6, 1) * 40;
    const sampleComponent = Math.min(sampleCount / 60, 1) * 30;
    const ewmaComponent = Math.min(ewmaDivergence, 1) * 30;
    return Math.round(Math.min(zComponent + sampleComponent + ewmaComponent, 100));
  }

  private isInCooldown(metric: MetricType, timestamp: number): boolean {
    const lastTime = this.lastAnomalyTime[metric];
    if (lastTime === 0) return false;
    return (timestamp - lastTime) < this.config.cooldownSec * 1000;
  }

  private checkResponseTimeSpike(timestamp: number, value: number): Anomaly | null {
    if (this.rtStats.size < this.config.minSamples) return null;
    const { z, median, lowVariance } = this.computeModifiedZ(value, this.rtStats);

    if (lowVariance) {
      const absDiff = value - median;
      const pctChange = median > 0 ? (absDiff / median) * 100 : 0;
      if (absDiff < 50 && pctChange < 25) return null;
    } else {
      if (z < this.config.warningZ) return null;
    }

    const absDiff = value - median;
    let minAbsDiff: number;
    let minPctChange: number;
    if (median < 100) {
      minAbsDiff = 50; minPctChange = 25;
    } else if (median > 2000) {
      minAbsDiff = 500; minPctChange = 15;
    } else {
      minAbsDiff = 100; minPctChange = 25;
    }
    if (absDiff < minAbsDiff) return null;
    const pctChange = median > 0 ? (absDiff / median) * 100 : 0;
    if (pctChange < minPctChange) return null;
    if (this.isInCooldown("response_time", timestamp)) return null;

    this.lastAnomalyTime.response_time = timestamp;
    const severity: Severity = z >= this.config.criticalZ ? "critical" : "warning";
    const pctStr = Math.round(pctChange);
    const ewmaDivergence = this.ewmaRT > 0 ? Math.abs(value - this.ewmaRT) / this.ewmaRT : 0;
    const confidence = this.computeConfidence(z, this.rtStats.size, ewmaDivergence);

    return {
      metricType: "response_time",
      timestamp,
      severity,
      value: Math.round(value * 100) / 100,
      rollingMedian: Math.round(median * 100) / 100,
      zScore: Math.round(z * 100) / 100,
      description: `Response time spiked to ${Math.round(value)}ms (+${pctStr}% from baseline ${Math.round(median)}ms)`,
      explanation: `Response time jumped from a baseline of ${Math.round(median)}ms to ${Math.round(value)}ms, an increase of ${Math.round(absDiff)}ms (${pctStr}%).`,
      confidence,
    };
  }

  private checkErrorRateSpike(timestamp: number, value: number): Anomaly | null {
    if (this.errStats.size < this.config.minSamples) return null;
    const median = this.errStats.median;
    if (value < 5) return null;
    const absDiff = value - median;
    if (absDiff < 3) return null;

    if (median < 1 && value >= 5) {
      if (this.isInCooldown("error_rate", timestamp)) return null;
      this.lastAnomalyTime.error_rate = timestamp;
      const severity: Severity = value >= 50 ? "critical" : "warning";
      const zApprox = value / 5;
      const ewmaDivergence = this.ewmaErr > 0 ? Math.abs(value - this.ewmaErr) / Math.max(this.ewmaErr, 1) : 0;
      const confidence = this.computeConfidence(zApprox, this.errStats.size, ewmaDivergence);
      return {
        metricType: "error_rate",
        timestamp,
        severity,
        value: Math.round(value * 100) / 100,
        rollingMedian: Math.round(median * 100) / 100,
        zScore: Math.round(zApprox * 100) / 100,
        description: `Error rate jumped to ${value.toFixed(1)}% (baseline was ~${median.toFixed(1)}%)`,
        explanation: `Error rate surged from ${median.toFixed(1)}% to ${value.toFixed(1)}%. ${value >= 50 ? "More than half of all requests are failing." : "A significant portion of requests are now failing."}`,
        confidence,
      };
    }

    const { z, lowVariance } = this.computeModifiedZ(value, this.errStats);
    if (!lowVariance && z < this.config.warningZ) return null;
    if (this.isInCooldown("error_rate", timestamp)) return null;

    this.lastAnomalyTime.error_rate = timestamp;
    const severity: Severity = z >= this.config.criticalZ || value >= 50 ? "critical" : "warning";
    const ewmaDivergence = this.ewmaErr > 0 ? Math.abs(value - this.ewmaErr) / Math.max(this.ewmaErr, 1) : 0;
    const confidence = this.computeConfidence(z, this.errStats.size, ewmaDivergence);
    return {
      metricType: "error_rate",
      timestamp,
      severity,
      value: Math.round(value * 100) / 100,
      rollingMedian: Math.round(median * 100) / 100,
      zScore: Math.round(z * 100) / 100,
      description: `Error rate jumped to ${value.toFixed(1)}% (baseline ${median.toFixed(1)}%)`,
      explanation: `Error rate increased from ${median.toFixed(1)}% to ${value.toFixed(1)}%.`,
      confidence,
    };
  }

  private checkThroughputDrop(timestamp: number, value: number): Anomaly | null {
    if (this.tpStats.size < this.config.minSamples) return null;
    const { z, median, mad } = this.computeModifiedZ(value, this.tpStats);
    if (median < 0.5) return null;

    const dropPct = ((median - value) / median) * 100;
    const cv = median > 0 ? mad / median : 0;
    let dropThreshold: number;
    if (cv < 0.1) dropThreshold = 30;
    else if (cv > 0.3) dropThreshold = 50;
    else dropThreshold = 40;

    if (dropPct < dropThreshold) return null;
    const absZ = Math.abs(z);
    if (absZ < this.config.warningZ && dropPct < 60) return null;
    if (this.isInCooldown("throughput", timestamp)) return null;

    this.lastAnomalyTime.throughput = timestamp;
    const severity: Severity = absZ >= this.config.criticalZ || dropPct >= 80 ? "critical" : "warning";
    const ewmaDivergence = this.ewmaTp > 0 ? Math.abs(value - this.ewmaTp) / this.ewmaTp : 0;
    const confidence = this.computeConfidence(absZ, this.tpStats.size, ewmaDivergence);

    return {
      metricType: "throughput",
      timestamp,
      severity,
      value: Math.round(value * 100) / 100,
      rollingMedian: Math.round(median * 100) / 100,
      zScore: Math.round(absZ * 100) / 100,
      description: `Throughput dropped to ${value.toFixed(1)} req/s (−${Math.round(dropPct)}% from ${median.toFixed(1)} req/s)`,
      explanation: `Throughput fell from ${median.toFixed(1)} req/s to ${value.toFixed(1)} req/s, a ${Math.round(dropPct)}% decrease.`,
      confidence,
    };
  }

  private buildInsightContext(ts: number, avgRT: number, p95: number, errRate: number, tp: number) {
    return {
      timestamp: ts,
      avgResponseTime: avgRT,
      p95ResponseTime: p95,
      errorRate: errRate,
      throughput: tp,
      rtMedian: this.rtStats.median,
      p95Median: this.p95Stats.median,
      errMedian: this.errStats.median,
      tpMedian: this.tpStats.median,
    };
  }

  private detectInsights(ctx: ReturnType<typeof this.buildInsightContext>, out: PerformanceInsight[]): void {
    const errInsight = this.checkErrorSpikeInsight(ctx);
    if (errInsight) {
      out.push(errInsight);
    }

    if (!errInsight) {
      const overloaded = this.checkServerOverloaded(ctx);
      if (overloaded) out.push(overloaded);

      if (!overloaded) {
        const tpCollapse = this.checkThroughputCollapse(ctx);
        if (tpCollapse) out.push(tpCollapse);

        const slowdown = this.checkBackendSlowdown(ctx);
        if (slowdown) out.push(slowdown);
      }
    }

    const tailLatency = this.checkTailLatency(ctx);
    if (tailLatency) out.push(tailLatency);

    if (this.rtLongBuf.count >= 24 && out.length === 0) {
      const degradation = this.checkGradualDegradation(ctx);
      if (degradation) out.push(degradation);
    }
  }

  private getAdaptiveRtThresholds(rtMedian: number): { minPctIncrease: number; minAbsDiff: number } {
    const rtVariance = this.computeRtVarianceRatio();
    let minPctIncrease: number;
    let minAbsDiff: number;
    if (rtMedian < 100) {
      minPctIncrease = 50; minAbsDiff = 50;
    } else if (rtMedian > 2000) {
      minPctIncrease = 15; minAbsDiff = 500;
    } else {
      minPctIncrease = 50; minAbsDiff = 100;
    }
    if (rtVariance > 0.3) {
      minPctIncrease = Math.min(minPctIncrease * 1.5, 80);
      minAbsDiff = Math.round(minAbsDiff * 1.3);
    } else if (rtVariance < 0.1 && rtVariance > 0) {
      minPctIncrease = Math.max(minPctIncrease * 0.7, 15);
      minAbsDiff = Math.round(minAbsDiff * 0.7);
    }
    return { minPctIncrease, minAbsDiff };
  }

  private computeRtVarianceRatio(): number {
    const vals = this.rtStats.values();
    if (vals.length < 5) return 0;
    const sorted = vals.slice().sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    const med = sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
    if (med < 1) return 0;
    const deviations = vals.map(v => Math.abs(v - med)).sort((a, b) => a - b);
    const devMid = Math.floor(deviations.length / 2);
    const madVal = deviations.length % 2 === 0 ? (deviations[devMid - 1] + deviations[devMid]) / 2 : deviations[devMid];
    return (madVal * 1.4826) / med;
  }

  private checkErrorSpikeInsight(ctx: ReturnType<typeof this.buildInsightContext>): PerformanceInsight | null {
    if (ctx.errorRate < 5) return null;
    const absDiff = ctx.errorRate - ctx.errMedian;
    if (absDiff < 3) return null;

    const severity: InsightSeverity = ctx.errorRate >= 50 ? "critical" : "warning";
    const evidence: PerformanceInsight["evidence"] = {
      errorRate: { value: ctx.errorRate, baseline: ctx.errMedian },
    };

    let desc = `Error rate jumped to ${ctx.errorRate.toFixed(1)}% from a baseline of ${ctx.errMedian.toFixed(1)}%.`;
    if (ctx.tpMedian > 0.5) {
      const tpDrop = ((ctx.tpMedian - ctx.throughput) / ctx.tpMedian) * 100;
      if (tpDrop > 20) {
        desc += ` Throughput also dropped ${Math.round(tpDrop)}% (${ctx.throughput.toFixed(1)} req/s from ${ctx.tpMedian.toFixed(1)} req/s).`;
        evidence.throughput = { value: ctx.throughput, baseline: ctx.tpMedian };
      }
    }
    const rtChange = ctx.rtMedian > 0 ? ((ctx.avgResponseTime - ctx.rtMedian) / ctx.rtMedian) * 100 : 0;
    if (Math.abs(rtChange) < 15) {
      desc += ` Response times remain stable, suggesting the server is rejecting requests quickly rather than timing out.`;
    }

    return this.emitInsightOrConsolidate("error_spike", ctx.timestamp, severity, desc, evidence);
  }

  private checkServerOverloaded(ctx: ReturnType<typeof this.buildInsightContext>): PerformanceInsight | null {
    if (ctx.rtMedian < 1 || ctx.tpMedian < 0.3) return null;
    const { minPctIncrease, minAbsDiff } = this.getAdaptiveRtThresholds(ctx.rtMedian);
    const rtIncrease = ((ctx.avgResponseTime - ctx.rtMedian) / ctx.rtMedian) * 100;
    if (rtIncrease < minPctIncrease) return null;
    if (ctx.avgResponseTime - ctx.rtMedian < minAbsDiff) return null;
    const tpDrop = ((ctx.tpMedian - ctx.throughput) / ctx.tpMedian) * 100;
    if (tpDrop < 25) return null;

    return this.emitInsightOrConsolidate("server_overloaded", ctx.timestamp, "critical",
      `Response times jumped to ${Math.round(ctx.avgResponseTime)}ms (+${Math.round(rtIncrease)}% from ${Math.round(ctx.rtMedian)}ms) while throughput dropped ${Math.round(tpDrop)}% to ${ctx.throughput.toFixed(1)} req/s. The system appears unable to keep up with the load.`,
      {
        responseTime: { value: ctx.avgResponseTime, baseline: ctx.rtMedian },
        throughput: { value: ctx.throughput, baseline: ctx.tpMedian },
      }
    );
  }

  private checkThroughputCollapse(ctx: ReturnType<typeof this.buildInsightContext>): PerformanceInsight | null {
    if (ctx.tpMedian < 0.5) return null;
    const tpDrop = ((ctx.tpMedian - ctx.throughput) / ctx.tpMedian) * 100;
    if (tpDrop < 50) return null;
    const errStable = ctx.errMedian < 1 ? ctx.errorRate < 3 : ctx.errorRate < ctx.errMedian * 1.5;
    if (!errStable) return null;

    return this.emitInsightOrConsolidate("throughput_collapse", ctx.timestamp, "critical",
      `Throughput dropped ${Math.round(tpDrop)}% to ${ctx.throughput.toFixed(1)} req/s (baseline: ${ctx.tpMedian.toFixed(1)} req/s) while error rates remain stable. Requests may be blocked or throttled before reaching the server.`,
      {
        throughput: { value: ctx.throughput, baseline: ctx.tpMedian },
        errorRate: { value: ctx.errorRate, baseline: ctx.errMedian },
      }
    );
  }

  private checkBackendSlowdown(ctx: ReturnType<typeof this.buildInsightContext>): PerformanceInsight | null {
    if (ctx.rtMedian < 1) return null;
    const { minPctIncrease, minAbsDiff } = this.getAdaptiveRtThresholds(ctx.rtMedian);
    const rtIncrease = ((ctx.avgResponseTime - ctx.rtMedian) / ctx.rtMedian) * 100;
    if (rtIncrease < minPctIncrease) return null;
    if (ctx.avgResponseTime - ctx.rtMedian < minAbsDiff) return null;
    if (ctx.tpMedian > 0.3) {
      const tpDelta = Math.abs(ctx.throughput - ctx.tpMedian) / ctx.tpMedian;
      if (tpDelta > 0.15) return null;
    }
    const errStable = ctx.errMedian < 1 ? ctx.errorRate < 3 : ctx.errorRate < ctx.errMedian * 1.5;
    if (!errStable) return null;

    return this.emitInsightOrConsolidate("backend_slowdown", ctx.timestamp, "warning",
      `Response times increased to ${Math.round(ctx.avgResponseTime)}ms (+${Math.round(rtIncrease)}% from ${Math.round(ctx.rtMedian)}ms) while throughput and error rates remain stable. The server is processing requests more slowly.`,
      {
        responseTime: { value: ctx.avgResponseTime, baseline: ctx.rtMedian },
        throughput: { value: ctx.throughput, baseline: ctx.tpMedian },
      }
    );
  }

  private checkTailLatency(ctx: ReturnType<typeof this.buildInsightContext>): PerformanceInsight | null {
    if (ctx.p95Median < 1) return null;
    const p95Increase = ((ctx.p95ResponseTime - ctx.p95Median) / ctx.p95Median) * 100;
    if (p95Increase < 80) return null;
    if (ctx.p95ResponseTime - ctx.p95Median < 200) return null;
    if (ctx.rtMedian < 1) return null;
    const rtDelta = Math.abs(ctx.avgResponseTime - ctx.rtMedian) / ctx.rtMedian;
    if (rtDelta > 0.15) return null;

    return this.emitInsightOrConsolidate("tail_latency", ctx.timestamp, "warning",
      `P95 response time spiked to ${Math.round(ctx.p95ResponseTime)}ms (+${Math.round(p95Increase)}% from ${Math.round(ctx.p95Median)}ms) while average response time remains stable at ${Math.round(ctx.avgResponseTime)}ms. A small percentage of requests are experiencing significantly longer wait times.`,
      {
        p95: { value: ctx.p95ResponseTime, baseline: ctx.p95Median },
        responseTime: { value: ctx.avgResponseTime, baseline: ctx.rtMedian },
      }
    );
  }

  private checkGradualDegradation(ctx: ReturnType<typeof this.buildInsightContext>): PerformanceInsight | null {
    const vals = this.rtLongBuf.values();
    const slope = linearRegressionSlope(vals);
    const relativeSlope = ctx.rtMedian > 0 ? slope / ctx.rtMedian : 0;
    if (relativeSlope < 0.005) return null;
    if (slope < 1) return null;
    if (ctx.errorRate > 5) return null;

    const windowDurationSec = vals.length * 5;
    const windowMins = Math.round(windowDurationSec / 60);

    return this.emitInsightOrConsolidate("gradual_degradation", ctx.timestamp, "warning",
      `Response times have been steadily increasing over the last ${windowMins > 0 ? windowMins + ' minute(s)' : windowDurationSec + ' seconds'}, now at ${Math.round(ctx.avgResponseTime)}ms (slope: +${slope.toFixed(1)}ms/sample). This trend may indicate a memory leak, growing queue sizes, or cache degradation.`,
      {
        responseTime: { value: ctx.avgResponseTime, baseline: ctx.rtMedian },
      }
    );
  }

  private emitInsightOrConsolidate(
    type: InsightType,
    timestamp: number,
    severity: InsightSeverity,
    description: string,
    evidence: PerformanceInsight["evidence"]
  ): PerformanceInsight | null {
    const lastEmit = this.lastInsightEmitTime.get(type) || 0;
    const active = this.activeInsights.get(type);

    if (active && (timestamp - active.endTimestamp) < this.config.insightCooldownMs * 2) {
      active.endTimestamp = timestamp;
      active.description = description;
      active.evidence = evidence;
      if (severity === "critical") active.severity = severity;
      return null;
    }

    if ((timestamp - lastEmit) < this.config.insightCooldownMs) {
      return null;
    }

    const insight: PerformanceInsight = {
      type,
      severity,
      title: INSIGHT_TITLES[type],
      startTimestamp: timestamp,
      endTimestamp: timestamp,
      description,
      evidence,
    };

    this.activeInsights.set(type, insight);
    this.lastInsightEmitTime.set(type, timestamp);
    return insight;
  }

  getAnomalies(): Anomaly[] {
    return [...this.anomalies];
  }

  getAnomalyCount(): { total: number; warning: number; critical: number } {
    let warning = 0;
    let critical = 0;
    for (const a of this.anomalies) {
      if (a.severity === "critical") critical++;
      else warning++;
    }
    return { total: this.anomalies.length, warning, critical };
  }

  getInsights(): PerformanceInsight[] {
    return [...this.insights];
  }

  getInsightSummary(): { total: number; warning: number; critical: number; byType: Record<string, number> } {
    let warning = 0, critical = 0;
    const byType: Record<string, number> = {};
    for (const e of this.insights) {
      if (e.severity === "critical") critical++;
      else warning++;
      byType[e.type] = (byType[e.type] || 0) + 1;
    }
    return { total: this.insights.length, warning, critical, byType };
  }

  reset(): void {
    this.rtStats.reset();
    this.errStats.reset();
    this.tpStats.reset();
    this.p95Stats.reset();
    this.rtLongBuf.reset();
    this.lastAnomalyTime = { response_time: 0, error_rate: 0, throughput: 0 };
    this.anomalies = [];
    this.insights = [];
    this.activeInsights.clear();
    this.lastInsightEmitTime.clear();
    this.sampleIndex = 0;
    this.firstDataPointTime = 0;
    this.lastDataPointTime = 0;
    this.ewmaRT = 0;
    this.ewmaErr = 0;
    this.ewmaTp = 0;
    this.ewmaInitialized = false;
  }
}

export function buildUnifiedInsights(
  anomalies: Anomaly[],
  insights: PerformanceInsight[]
): PerformanceInsight[] {
  const insightMap = new Map<InsightType, PerformanceInsight>();

  for (const ins of insights) {
    const existing = insightMap.get(ins.type);
    if (!existing || ins.severity === "critical") {
      insightMap.set(ins.type, { ...ins });
    }
  }

  for (const a of anomalies) {
    if (a.metricType === "error_rate" && !insightMap.has("error_spike")) {
      insightMap.set("error_spike", {
        type: "error_spike",
        severity: a.severity,
        title: INSIGHT_TITLES.error_spike,
        startTimestamp: a.timestamp,
        endTimestamp: a.timestamp,
        description: a.description + " " + a.explanation,
        evidence: { errorRate: { value: a.value, baseline: a.rollingMedian } },
      });
    }
  }

  const result = Array.from(insightMap.values());
  result.sort((a, b) => {
    if (a.severity !== b.severity) return a.severity === "critical" ? -1 : 1;
    return b.startTimestamp - a.startTimestamp;
  });

  return result;
}

export function detectFromTimeseries(
  timeseries: Array<{
    sec: number;
    avg_ms: number;
    errors: number;
    rps: number;
    active_threads?: number;
    p95_ms?: number;
  }>,
  config?: Partial<LiveAnalysisConfig>
): { anomalies: Anomaly[]; insights: PerformanceInsight[] } {
  if (!timeseries || timeseries.length < 15) return { anomalies: [], insights: [] };

  const adaptiveConfig: Partial<LiveAnalysisConfig> = { ...config };
  const durationSec = timeseries.length;
  if (durationSec < 120) {
    adaptiveConfig.degradationWindowSize = Math.max(24, Math.floor(durationSec * 0.4));
  } else if (durationSec < 300) {
    adaptiveConfig.degradationWindowSize = 60;
  } else {
    adaptiveConfig.degradationWindowSize = 120;
  }

  const engine = new LiveAnalysisEngine(adaptiveConfig);
  engine.setTotalExpectedSamples(timeseries.length);

  const allAnomalies: Anomaly[] = [];
  const allInsights: PerformanceInsight[] = [];

  for (const point of timeseries) {
    const errorRate = getErrorRate(point as unknown as NormalizedTimeseriesPoint);
    const p95 = point.p95_ms ?? point.avg_ms * 1.3;

    const result = engine.addDataPoint(
      point.sec * 1000,
      point.avg_ms,
      p95,
      errorRate,
      point.rps,
      point.active_threads ?? 0
    );

    allAnomalies.push(...result.anomalies);
    allInsights.push(...result.insights);
  }

  return { anomalies: allAnomalies, insights: allInsights };
}
