const MAX_VALUE = 60_000;
const BUCKET_COUNT = MAX_VALUE + 1;
const OVERFLOW_INDEX = MAX_VALUE;

export class FixedHistogram {
  private counts: Int32Array;
  private _count: number = 0;
  private _min: number = -1;
  private _max: number = -1;
  private _overflowValues: number[] = [];

  constructor() {
    this.counts = new Int32Array(BUCKET_COUNT);
  }

  record(value: number): void {
    const rounded = Math.round(value < 0 ? 0 : value);
    if (rounded >= MAX_VALUE) {
      this.counts[OVERFLOW_INDEX]++;
      this._overflowValues.push(rounded);
    } else {
      this.counts[rounded]++;
    }
    this._count++;
    if (this._min < 0 || rounded < this._min) this._min = rounded;
    if (rounded > this._max) this._max = rounded;
  }

  percentile(p: number): number {
    if (this._count === 0) return 0;
    if (p <= 0) return this._min < 0 ? 0 : this._min;
    if (p >= 100) return this._max < 0 ? 0 : this._max;

    const target = this._count * (p / 100);
    let cumulative = 0;
    for (let i = 0; i < OVERFLOW_INDEX; i++) {
      if (this.counts[i] === 0) continue;
      cumulative += this.counts[i];
      if (cumulative >= target) {
        return i;
      }
    }
    if (this._overflowValues.length > 0) {
      const sorted = [...this._overflowValues].sort((a, b) => a - b);
      const remaining = target - cumulative;
      const idx = Math.max(0, Math.ceil(remaining) - 1);
      return sorted[Math.min(idx, sorted.length - 1)];
    }
    return OVERFLOW_INDEX;
  }

  p50(): number { return this.percentile(50); }
  p90(): number { return this.percentile(90); }
  p95(): number { return this.percentile(95); }
  p99(): number { return this.percentile(99); }

  count(): number { return this._count; }

  min(): number { return this._min < 0 ? 0 : this._min; }
  max(): number { return this._max < 0 ? 0 : this._max; }

  merge(other: FixedHistogram): void {
    for (let i = 0; i < BUCKET_COUNT; i++) {
      this.counts[i] += other.counts[i];
    }
    this._count += other._count;
    if (other._min >= 0 && (this._min < 0 || other._min < this._min)) {
      this._min = other._min;
    }
    if (other._max > this._max) {
      this._max = other._max;
    }
    if (other._overflowValues.length > 0) {
      this._overflowValues.push(...other._overflowValues);
    }
  }

  exportCounts(): number[] {
    const sparse: number[] = [];
    for (let i = 0; i < OVERFLOW_INDEX; i++) {
      if (this.counts[i] > 0) {
        sparse.push(i, this.counts[i]);
      }
    }
    for (const v of this._overflowValues) {
      sparse.push(v, 1);
    }
    return sparse;
  }

  importCounts(sparse: number[]): void {
    for (let i = 0; i < sparse.length; i += 2) {
      const idx = sparse[i];
      const cnt = sparse[i + 1];
      if (idx >= 0 && cnt > 0) {
        if (idx < MAX_VALUE) {
          this.counts[idx] += cnt;
        } else {
          this.counts[OVERFLOW_INDEX] += cnt;
          for (let j = 0; j < cnt; j++) {
            this._overflowValues.push(idx);
          }
        }
        this._count += cnt;
        if (this._min < 0 || idx < this._min) this._min = idx;
        if (idx > this._max) this._max = idx;
      }
    }
  }

  reset(): void {
    this.counts.fill(0);
    this._count = 0;
    this._min = -1;
    this._max = -1;
    this._overflowValues = [];
  }
}

export function mergeHistogramCounts(sparseArrays: number[][]): number[] {
  const merged = new Int32Array(BUCKET_COUNT);
  const overflowEntries: number[] = [];
  for (const sparse of sparseArrays) {
    for (let i = 0; i < sparse.length; i += 2) {
      const idx = sparse[i];
      const cnt = sparse[i + 1];
      if (idx >= 0) {
        if (idx < MAX_VALUE) {
          merged[idx] += cnt;
        } else {
          overflowEntries.push(idx, cnt);
        }
      }
    }
  }
  const result: number[] = [];
  for (let i = 0; i < OVERFLOW_INDEX; i++) {
    if (merged[i] > 0) {
      result.push(i, merged[i]);
    }
  }
  result.push(...overflowEntries);
  return result;
}

export function percentileFromHistogramCounts(sparse: number[], p: number): number {
  if (sparse.length === 0) return 0;

  let totalCount = 0;
  for (let i = 1; i < sparse.length; i += 2) {
    totalCount += sparse[i];
  }
  if (totalCount === 0) return 0;

  if (p <= 0) return sparse[0];
  if (p >= 100) {
    let maxVal = 0;
    for (let i = 0; i < sparse.length; i += 2) {
      if (sparse[i] > maxVal) maxVal = sparse[i];
    }
    return maxVal;
  }

  const entries: Array<[number, number]> = [];
  for (let i = 0; i < sparse.length; i += 2) {
    entries.push([sparse[i], sparse[i + 1]]);
  }
  entries.sort((a, b) => a[0] - b[0]);

  const target = totalCount * (p / 100);
  let cumulative = 0;
  for (const [val, cnt] of entries) {
    if (cnt === 0) continue;
    cumulative += cnt;
    if (cumulative >= target) {
      return val;
    }
  }
  return entries[entries.length - 1][0];
}

export { MAX_VALUE, BUCKET_COUNT };
