import { FixedHistogram } from "./fixed-histogram";
import type { JtlRow } from "./tailer";
import { LiveAnalysisEngine, buildUnifiedInsights, type Anomaly, type PerformanceInsight } from "./live-analysis-engine";

export interface TransactionCheckpoint {
  histogramCounts?: number[];
  values?: number[];
  count: number;
  errors: number;
  sumElapsed: number;
  minElapsed: number;
  maxElapsed: number;
  firstTimestamp: number;
  lastEndTimestamp: number;
  errorCodes: Record<string, number>;
  isParent?: boolean;
}

export interface AggregatorCheckpoint {
  version: 4;
  globalHistogramCounts?: number[];
  globalValues?: number[];
  totalCount: number;
  totalErrors: number;
  sumElapsed: number;
  parentSampleCount: number;
  parentSumElapsed: number;
  excludeParentFromGlobal: boolean;
  hasTransactionControllers?: boolean;
  firstTimestamp: number;
  lastTimestamp: number;
  lastEndTimestamp: number;
  transactions: Record<string, TransactionCheckpoint>;
}

interface TransactionStats {
  count: number;
  errors: number;
  sumElapsed: number;
  minElapsed: number;
  maxElapsed: number;
  histogram: FixedHistogram;
  errorCodes: Map<string, number>;
  firstTimestamp: number;
  lastEndTimestamp: number;
  isParent: boolean;
}

interface TimeSeriesPoint {
  t: number;
  throughput: number;
  avgRT: number;
  p50: number;
  p90: number;
  p95: number;
  p99: number;
  errorRate: number;
  errors: number;
  activeThreads: number;
}

const BUCKET_MS = 5000;
const MAX_SERIES_POINTS = 43200;
const DOWNSAMPLE_THRESHOLD = 14400;
const THROUGHPUT_WINDOW_SEC = 10;
const THROUGHPUT_SLOTS = THROUGHPUT_WINDOW_SEC;
const MAX_TRANSACTIONS = 10000;

export interface SlaViolation {
  ruleId: number;
  metric: string;
  comparator: string;
  threshold: number;
  actualValue: number;
  transactionLabel: string | null;
}

export interface SlaRuleConfig {
  id: number;
  transactionLabel: string | null;
  metric: string;
  comparator: string;
  threshold: number;
}

export interface LiveMetricsSnapshot {
  summary: {
    throughput: number;
    avgResponseTime: number;
    p95: number;
    p99: number;
    errorRate: number;
    activeThreads: number;
    totalRequests: number;
    totalErrors: number;
    elapsedSeconds: number;
    parentSamplesExcluded?: number;
  };
  topErrors: Array<{
    label: string;
    errorRate: number;
    errorCount: number;
    totalCount: number;
    errorCodes: Array<{ code: string; count: number }>;
  }>;
  topSlow: Array<{
    label: string;
    avg: number;
    p95: number;
    p99: number;
    count: number;
  }>;
  allTransactions: Array<{
    label: string;
    count: number;
    errors: number;
    errorRate: number;
    avg: number;
    min: number;
    max: number;
    p50: number;
    p90: number;
    p95: number;
    p99: number;
    throughput: number;
  }>;
  series: TimeSeriesPoint[];
  slaViolations: SlaViolation[];
  anomalies: Anomaly[];
  anomalySummary: { total: number; warning: number; critical: number };
  insights: PerformanceInsight[];
  insightSummary: { total: number; warning: number; critical: number; byType: Record<string, number> };
  correlationEvents: PerformanceInsight[];
  correlationSummary: { total: number; warning: number; critical: number; byType: Record<string, number> };
  systemMetrics?: {
    latest: { ts: number; cpuPercent: number; memUsedMb: number; memTotalMb: number; memPercent: number; diskReadMbps: number; diskWriteMbps: number; jmeterCpuPercent: number | null; jmeterMemMb: number | null } | null;
    history: Array<{ ts: number; cpuPercent: number; memPercent: number; diskReadMbps: number; diskWriteMbps: number; jmeterCpuPercent: number | null }>;
  };
}

export class MetricsAggregator {
  private totalCount: number = 0;
  private totalErrors: number = 0;
  private sumElapsed: number = 0;
  private parentSampleCount: number = 0;
  private parentSumElapsed: number = 0;
  private globalHistogram: FixedHistogram = new FixedHistogram();
  private lastActiveThreads: number = 0;
  private firstTimestamp: number = 0;
  private lastTimestamp: number = 0;
  private lastEndTimestamp: number = 0;
  private slaRules: SlaRuleConfig[] = [];
  private analysisEngine: LiveAnalysisEngine = new LiveAnalysisEngine();
  private excludeParentFromGlobal: boolean = true;
  private hasTransactionControllers: boolean = false;

  private transactions: Map<string, TransactionStats> = new Map();

  private series: TimeSeriesPoint[] = [];
  private currentBucket: {
    startTime: number;
    count: number;
    errors: number;
    sumElapsed: number;
    maxThreads: number;
    histogram: FixedHistogram;
  } | null = null;
  private lateBuckets: Map<number, {
    startTime: number;
    count: number;
    errors: number;
    sumElapsed: number;
    maxThreads: number;
    histogram: FixedHistogram;
  }> = new Map();
  private seriesRawCounts: Map<number, { count: number; errors: number; sumElapsed: number }> = new Map();
  private static readonly LATE_BUCKET_TOLERANCE = 3;

  private throughputSlots: number[] = new Array(THROUGHPUT_SLOTS).fill(0);
  private throughputSlotBase: number = 0;

  setSlaRules(rules: SlaRuleConfig[]): void {
    this.slaRules = rules;
  }

  setRampUpDuration(seconds: number): void {
    this.analysisEngine.setRampUpDuration(seconds);
  }

  addSample(row: JtlRow): void {
    const isParent = row.parentSample === true;

    this.totalCount++;
    this.sumElapsed += row.elapsed;

    if (isParent) {
      this.parentSampleCount++;
      this.parentSumElapsed += row.elapsed;
    }

    if (!row.success && !isParent) {
      this.totalErrors++;
    }

    if (!isParent) {
      this.globalHistogram.record(row.elapsed);
    }
    this.lastActiveThreads = row.allThreads;

    if (this.firstTimestamp === 0 || row.timestamp < this.firstTimestamp) {
      this.firstTimestamp = row.timestamp;
    }
    if (row.timestamp > this.lastTimestamp) {
      this.lastTimestamp = row.timestamp;
    }

    const sampleEnd = row.timestamp + row.elapsed;
    if (sampleEnd > this.lastEndTimestamp) {
      this.lastEndTimestamp = sampleEnd;
    }

    if (isParent) {
      this.hasTransactionControllers = true;
    }

    let txStats = this.transactions.get(row.label);
    if (!txStats) {
      if (this.transactions.size >= MAX_TRANSACTIONS) {
        return;
      }
      txStats = {
        count: 0,
        errors: 0,
        sumElapsed: 0,
        minElapsed: Infinity,
        maxElapsed: 0,
        histogram: new FixedHistogram(),
        errorCodes: new Map(),
        firstTimestamp: row.timestamp,
        lastEndTimestamp: sampleEnd,
        isParent: isParent,
      };
      this.transactions.set(row.label, txStats);
    }

    if (!isParent && txStats.isParent) {
      this.recordThroughputSample(row.timestamp);
      this.updateTimeSeries(row);
      return;
    }

    if (isParent && !txStats.isParent) {
      txStats.isParent = true;
      txStats.count = 0;
      txStats.errors = 0;
      txStats.sumElapsed = 0;
      txStats.minElapsed = Infinity;
      txStats.maxElapsed = 0;
      txStats.histogram.reset();
      txStats.errorCodes.clear();
      txStats.firstTimestamp = row.timestamp;
      txStats.lastEndTimestamp = sampleEnd;
    }

    if (row.timestamp < txStats.firstTimestamp) {
      txStats.firstTimestamp = row.timestamp;
    }
    if (sampleEnd > txStats.lastEndTimestamp) {
      txStats.lastEndTimestamp = sampleEnd;
    }
    txStats.count++;
    if (!row.success) {
      txStats.errors++;
      const code = row.responseCode || "Unknown";
      txStats.errorCodes.set(code, (txStats.errorCodes.get(code) || 0) + 1);
    } else if (isParent) {
      const match = row.responseMessage.match(/number of failing samples\s*:\s*(\d+)/i);
      if (match && parseInt(match[1], 10) > 0) {
        txStats.errors++;
        const code = row.responseCode || "500";
        txStats.errorCodes.set(code, (txStats.errorCodes.get(code) || 0) + 1);
      }
    }
    txStats.sumElapsed += row.elapsed;
    txStats.minElapsed = Math.min(txStats.minElapsed, row.elapsed);
    txStats.maxElapsed = Math.max(txStats.maxElapsed, row.elapsed);
    txStats.histogram.record(row.elapsed);

    if (!isParent) {
      this.recordThroughputSample(row.timestamp);
      this.updateTimeSeries(row);
    }
  }

  private recordThroughputSample(timestampMs: number): void {
    const slotSec = Math.floor(timestampMs / 1000);
    if (this.throughputSlotBase === 0) {
      this.throughputSlotBase = slotSec;
    }

    const offset = slotSec - this.throughputSlotBase;
    if (offset < -2) return;

    if (offset < 0) {
      const idx = THROUGHPUT_SLOTS + offset;
      if (idx >= 0 && idx < THROUGHPUT_SLOTS) {
        this.throughputSlots[idx]++;
      }
      return;
    }

    if (offset >= THROUGHPUT_SLOTS) {
      const shift = offset - THROUGHPUT_SLOTS + 1;
      for (let i = 0; i < THROUGHPUT_SLOTS; i++) {
        if (i + shift < THROUGHPUT_SLOTS) {
          this.throughputSlots[i] = this.throughputSlots[i + shift];
        } else {
          this.throughputSlots[i] = 0;
        }
      }
      this.throughputSlotBase += shift;
    }

    const idx = slotSec - this.throughputSlotBase;
    if (idx >= 0 && idx < THROUGHPUT_SLOTS) {
      this.throughputSlots[idx]++;
    }
  }

  private getCurrentThroughput(): number {
    let total = 0;
    for (let i = 0; i < THROUGHPUT_SLOTS; i++) {
      total += this.throughputSlots[i];
    }
    return Math.round((total / THROUGHPUT_WINDOW_SEC) * 100) / 100;
  }

  private updateTimeSeries(row: JtlRow): void {
    const bucketTime = Math.floor(row.timestamp / BUCKET_MS) * BUCKET_MS;

    if (this.currentBucket && bucketTime < this.currentBucket.startTime) {
      const bucketsBack = (this.currentBucket.startTime - bucketTime) / BUCKET_MS;
      if (bucketsBack <= MetricsAggregator.LATE_BUCKET_TOLERANCE) {
        let lateBucket = this.lateBuckets.get(bucketTime);
        if (!lateBucket) {
          lateBucket = {
            startTime: bucketTime,
            count: 0,
            errors: 0,
            sumElapsed: 0,
            maxThreads: 0,
            histogram: new FixedHistogram(),
          };
          this.lateBuckets.set(bucketTime, lateBucket);
        }
        lateBucket.count++;
        if (!row.success) lateBucket.errors++;
        lateBucket.sumElapsed += row.elapsed;
        lateBucket.maxThreads = Math.max(lateBucket.maxThreads, row.allThreads);
        lateBucket.histogram.record(row.elapsed);
      }
      return;
    }

    if (!this.currentBucket || this.currentBucket.startTime !== bucketTime) {
      if (this.currentBucket) {
        this.flushBucket();
      }
      this.currentBucket = {
        startTime: bucketTime,
        count: 0,
        errors: 0,
        sumElapsed: 0,
        maxThreads: 0,
        histogram: new FixedHistogram(),
      };
    }

    this.currentBucket.count++;
    if (!row.success) this.currentBucket.errors++;
    this.currentBucket.sumElapsed += row.elapsed;
    this.currentBucket.maxThreads = Math.max(this.currentBucket.maxThreads, row.allThreads);
    this.currentBucket.histogram.record(row.elapsed);
  }

  private flushBucket(): void {
    if (!this.currentBucket || this.currentBucket.count === 0) return;

    this.flushLateBuckets();

    const b = this.currentBucket;
    const durationSec = BUCKET_MS / 1000;

    const throughput = Math.round((b.count / durationSec) * 100) / 100;
    const avgRT = Math.round((b.sumElapsed / b.count) * 100) / 100;
    const errorRate = b.count > 0 ? Math.round((b.errors / b.count) * 10000) / 100 : 0;

    this.series.push({
      t: b.startTime,
      throughput,
      avgRT,
      p50: b.histogram.p50(),
      p90: b.histogram.p90(),
      p95: b.histogram.p95(),
      p99: b.histogram.p99(),
      errorRate,
      errors: b.errors,
      activeThreads: b.maxThreads,
    });

    this.seriesRawCounts.set(b.startTime, {
      count: b.count,
      errors: b.errors,
      sumElapsed: b.sumElapsed,
    });

    const p95Val = b.histogram.p95();
    this.analysisEngine.addDataPoint(b.startTime, avgRT, p95Val, errorRate, throughput, b.maxThreads);

    if (this.series.length > DOWNSAMPLE_THRESHOLD) {
      this.downsampleSeries();
    }

    while (this.series.length > MAX_SERIES_POINTS) {
      const removed = this.series.shift();
      if (removed) this.seriesRawCounts.delete(removed.t);
    }

    this.scaleBufferSizes();
  }

  private flushLateBuckets(): void {
    if (this.lateBuckets.size === 0) return;

    const sortedTimes = Array.from(this.lateBuckets.keys()).sort((a, b) => a - b);
    const durationSec = BUCKET_MS / 1000;

    for (const bucketTime of sortedTimes) {
      const lb = this.lateBuckets.get(bucketTime)!;
      if (lb.count === 0) continue;

      const raw = this.seriesRawCounts.get(bucketTime);
      const existingIdx = this.series.findIndex(p => p.t === bucketTime);
      if (existingIdx >= 0 && raw) {
        const existing = this.series[existingIdx];
        const totalCount = raw.count + lb.count;
        const totalErrors = raw.errors + lb.errors;
        const totalSum = raw.sumElapsed + lb.sumElapsed;
        existing.throughput = Math.round((totalCount / durationSec) * 100) / 100;
        existing.avgRT = totalCount > 0 ? Math.round((totalSum / totalCount) * 100) / 100 : 0;
        existing.errors = totalErrors;
        existing.errorRate = totalCount > 0 ? Math.round((totalErrors / totalCount) * 10000) / 100 : 0;
        existing.p50 = Math.round(((existing.p50 + lb.histogram.p50()) / 2) * 100) / 100;
        existing.p90 = Math.round(Math.max(existing.p90, lb.histogram.p90()) * 100) / 100;
        existing.p95 = Math.round(Math.max(existing.p95, lb.histogram.p95()) * 100) / 100;
        existing.p99 = Math.round(Math.max(existing.p99, lb.histogram.p99()) * 100) / 100;
        existing.activeThreads = Math.max(existing.activeThreads, lb.maxThreads);
        raw.count = totalCount;
        raw.errors = totalErrors;
        raw.sumElapsed = totalSum;
      } else {
        const throughput = Math.round((lb.count / durationSec) * 100) / 100;
        const avgRT = Math.round((lb.sumElapsed / lb.count) * 100) / 100;
        const errorRate = lb.count > 0 ? Math.round((lb.errors / lb.count) * 10000) / 100 : 0;

        this.series.push({
          t: bucketTime,
          throughput,
          avgRT,
          p50: lb.histogram.p50(),
          p90: lb.histogram.p90(),
          p95: lb.histogram.p95(),
          p99: lb.histogram.p99(),
          errorRate,
          errors: lb.errors,
          activeThreads: lb.maxThreads,
        });

        this.seriesRawCounts.set(bucketTime, {
          count: lb.count,
          errors: lb.errors,
          sumElapsed: lb.sumElapsed,
        });
      }
    }

    const correctedTimes = new Set(sortedTimes);

    this.lateBuckets.clear();

    this.series.sort((a, b) => a.t - b.t);

    for (const point of this.series) {
      if (correctedTimes.has(point.t)) {
        this.analysisEngine.addDataPoint(
          point.t,
          point.avgRT,
          point.p95,
          point.errorRate,
          point.throughput,
          point.activeThreads
        );
      }
    }
  }

  finalize(): void {
    this.flushLateBuckets();
    this.flushBucket();
    this.currentBucket = null;
  }

  private downsampleSeries(): void {
    const merged: TimeSeriesPoint[] = [];
    const newRawCounts = new Map<number, { count: number; errors: number; sumElapsed: number }>();
    let i = 0;
    for (; i + 1 < this.series.length; i += 2) {
      const a = this.series[i];
      const b = this.series[i + 1];
      const rawA = this.seriesRawCounts.get(a.t);
      const rawB = this.seriesRawCounts.get(b.t);
      if (rawA && rawB) {
        newRawCounts.set(a.t, {
          count: rawA.count + rawB.count,
          errors: rawA.errors + rawB.errors,
          sumElapsed: rawA.sumElapsed + rawB.sumElapsed,
        });
      } else if (rawA) {
        newRawCounts.set(a.t, { ...rawA });
      }
      const hasRaw = rawA != null && rawB != null;
      const totalCount = hasRaw ? rawA.count + rawB.count : 0;
      const wA = hasRaw && totalCount > 0 ? rawA.count / totalCount : 0.5;
      const wB = hasRaw && totalCount > 0 ? rawB.count / totalCount : 0.5;
      const mergedErrors = (rawA?.errors ?? 0) + (rawB?.errors ?? 0);
      merged.push({
        t: a.t,
        throughput: Math.round(((a.throughput + b.throughput) / 2) * 100) / 100,
        avgRT: Math.round((a.avgRT * wA + b.avgRT * wB) * 100) / 100,
        p50: Math.round((a.p50 * wA + b.p50 * wB) * 100) / 100,
        p90: Math.round(Math.max(a.p90, b.p90) * 100) / 100,
        p95: Math.round(Math.max(a.p95, b.p95) * 100) / 100,
        p99: Math.round(Math.max(a.p99, b.p99) * 100) / 100,
        errorRate: totalCount > 0 ? Math.round((mergedErrors / totalCount) * 10000) / 100 : Math.round(((a.errorRate + b.errorRate) / 2) * 100) / 100,
        errors: mergedErrors,
        activeThreads: Math.max(a.activeThreads, b.activeThreads),
      });
    }
    if (i < this.series.length) {
      const last = this.series[i];
      merged.push(last);
      const rawLast = this.seriesRawCounts.get(last.t);
      if (rawLast) newRawCounts.set(last.t, rawLast);
    }
    this.series = merged;
    this.seriesRawCounts = newRawCounts;
  }

  private scaleBufferSizes(): void {
    const elapsedMs = this.lastTimestamp > 0 && this.firstTimestamp > 0
      ? this.lastTimestamp - this.firstTimestamp
      : 0;
    const elapsedMinutes = elapsedMs / 60000;

    let targetSize: number;
    if (elapsedMinutes > 120) {
      targetSize = 120;
    } else if (elapsedMinutes > 30) {
      targetSize = 60;
    } else {
      targetSize = 30;
    }

    if (targetSize > this.analysisEngine.getWindowSize()) {
      this.analysisEngine.resizeWindow(targetSize);
    }
  }

  getSnapshot(): LiveMetricsSnapshot {
    let previewPoint: TimeSeriesPoint | null = null;
    if (this.currentBucket && this.currentBucket.count > 0) {
      const b = this.currentBucket;
      const durationSec = BUCKET_MS / 1000;
      previewPoint = {
        t: b.startTime,
        throughput: Math.round((b.count / durationSec) * 100) / 100,
        avgRT: Math.round((b.sumElapsed / b.count) * 100) / 100,
        p50: b.histogram.p50(),
        p90: b.histogram.p90(),
        p95: b.histogram.p95(),
        p99: b.histogram.p99(),
        errorRate: b.count > 0 ? Math.round((b.errors / b.count) * 10000) / 100 : 0,
        errors: b.errors,
        activeThreads: b.maxThreads,
      };
    }

    const effectiveCount = this.excludeParentFromGlobal
      ? this.totalCount - this.parentSampleCount
      : this.totalCount;
    const effectiveSum = this.excludeParentFromGlobal
      ? this.sumElapsed - this.parentSumElapsed
      : this.sumElapsed;

    const elapsedMs = this.lastEndTimestamp > 0 && this.firstTimestamp > 0
      ? Math.max(1, this.lastEndTimestamp - this.firstTimestamp)
      : (this.firstTimestamp > 0 ? Math.max(1000, (this.lastTimestamp - this.firstTimestamp)) : 0);
    const elapsedSeconds = elapsedMs / 1000;

    const throughput = elapsedMs > 0
      ? Math.round((effectiveCount / elapsedSeconds) * 100) / 100
      : 0;

    const avgResponseTime = effectiveCount > 0
      ? Math.round((effectiveSum / effectiveCount) * 100) / 100
      : 0;

    const p95 = effectiveCount > 0
      ? this.globalHistogram.p95()
      : 0;

    const p99 = effectiveCount > 0
      ? this.globalHistogram.p99()
      : 0;

    const errorRate = effectiveCount > 0
      ? Math.round((this.totalErrors / effectiveCount) * 10000) / 100
      : 0;

    const topErrors = this.getTopErrors(10);
    const topSlow = this.getTopSlow(10);

    const fullTx = this.getFullTransactionDetails();
    const allTransactions = fullTx.map(tx => {
      const txThroughput = elapsedSeconds > 0 ? Math.round((tx.count / elapsedSeconds) * 100) / 100 : 0;
      return {
        label: tx.label,
        count: tx.count,
        errors: tx.errors,
        errorRate: tx.count > 0 ? Math.round((tx.errors / tx.count) * 10000) / 100 : 0,
        avg: tx.avg,
        min: tx.min,
        max: tx.max,
        p50: tx.p50,
        p90: tx.p90,
        p95: tx.p95,
        p99: tx.p99,
        throughput: txThroughput,
      };
    });

    const slaViolations = this.evaluateSlaRules(throughput, avgResponseTime, p95, p99, errorRate);

    const anomalies = this.analysisEngine.getAnomalies();
    const insights = buildUnifiedInsights(anomalies, this.analysisEngine.getInsights());
    const insightSummary = this.analysisEngine.getInsightSummary();

    return {
      summary: {
        throughput,
        avgResponseTime,
        p95,
        p99,
        errorRate,
        activeThreads: this.lastActiveThreads,
        totalRequests: effectiveCount,
        totalErrors: this.totalErrors,
        elapsedSeconds: Math.round(elapsedSeconds),
        parentSamplesExcluded: this.parentSampleCount,
      },
      topErrors,
      topSlow,
      allTransactions,
      series: previewPoint ? [...this.series, previewPoint] : [...this.series],
      slaViolations,
      anomalies,
      anomalySummary: this.analysisEngine.getAnomalyCount(),
      insights,
      insightSummary,
      correlationEvents: insights,
      correlationSummary: insightSummary,
    };
  }

  private isHiddenChild(_label: string, stats: TransactionStats): boolean {
    if (!this.hasTransactionControllers) return false;
    return !stats.isParent;
  }

  private getTopErrors(limit: number): LiveMetricsSnapshot["topErrors"] {
    const result: LiveMetricsSnapshot["topErrors"] = [];

    this.transactions.forEach((stats, label) => {
      if (stats.errors > 0 && !this.isHiddenChild(label, stats)) {
        const errorCodes: Array<{ code: string; count: number }> = [];
        stats.errorCodes.forEach((count, code) => {
          errorCodes.push({ code, count });
        });
        errorCodes.sort((a, b) => b.count - a.count);

        result.push({
          label,
          errorRate: Math.round((stats.errors / stats.count) * 10000) / 100,
          errorCount: stats.errors,
          totalCount: stats.count,
          errorCodes: errorCodes.slice(0, 5),
        });
      }
    });

    result.sort((a, b) => b.errorRate - a.errorRate);
    return result.slice(0, limit);
  }

  private getTopSlow(limit: number): LiveMetricsSnapshot["topSlow"] {
    const result: LiveMetricsSnapshot["topSlow"] = [];

    this.transactions.forEach((stats, label) => {
      if (stats.count > 0 && !this.isHiddenChild(label, stats)) {
        result.push({
          label,
          avg: Math.round((stats.sumElapsed / stats.count) * 100) / 100,
          p95: stats.histogram.p95(),
          p99: stats.histogram.p99(),
          count: stats.count,
        });
      }
    });

    result.sort((a, b) => b.avg - a.avg);
    return result.slice(0, limit);
  }

  getFullTransactionDetails(): Array<{
    label: string;
    count: number;
    errors: number;
    avg: number;
    min: number;
    max: number;
    p50: number;
    p90: number;
    p95: number;
    p99: number;
    errorCodes: Array<{ code: string; count: number }>;
    firstTimestamp: number;
    lastEndTimestamp: number;
  }> {
    const result: Array<{
      label: string; count: number; errors: number;
      avg: number; min: number; max: number;
      p50: number; p90: number; p95: number; p99: number;
      errorCodes: Array<{ code: string; count: number }>;
      firstTimestamp: number; lastEndTimestamp: number;
    }> = [];

    this.transactions.forEach((stats, label) => {
      if (stats.count > 0 && !this.isHiddenChild(label, stats)) {
        const errorCodes: Array<{ code: string; count: number }> = [];
        stats.errorCodes.forEach((count, code) => {
          errorCodes.push({ code, count });
        });
        errorCodes.sort((a, b) => b.count - a.count);

        result.push({
          label,
          count: stats.count,
          errors: stats.errors,
          avg: Math.round((stats.sumElapsed / stats.count) * 100) / 100,
          min: stats.histogram.min(),
          max: stats.histogram.max(),
          p50: stats.histogram.p50(),
          p90: stats.histogram.p90(),
          p95: stats.histogram.p95(),
          p99: stats.histogram.p99(),
          errorCodes,
          firstTimestamp: stats.firstTimestamp,
          lastEndTimestamp: stats.lastEndTimestamp,
        });
      }
    });

    return result;
  }

  getGlobalExactPercentiles(): { p50: number; p90: number; p95: number; p99: number; min: number; max: number } {
    return {
      p50: this.globalHistogram.p50(),
      p90: this.globalHistogram.p90(),
      p95: this.globalHistogram.p95(),
      p99: this.globalHistogram.p99(),
      min: this.globalHistogram.min(),
      max: this.globalHistogram.max(),
    };
  }

  private evaluateSlaRules(
    throughput: number,
    avgResponseTime: number,
    p95: number,
    p99: number,
    errorRate: number
  ): SlaViolation[] {
    if (this.slaRules.length === 0 || this.totalCount < 10) return [];

    const violations: SlaViolation[] = [];

    for (const rule of this.slaRules) {
      let actualValue: number | null = null;

      if (rule.transactionLabel) {
        const txStats = this.transactions.get(rule.transactionLabel);
        if (!txStats || txStats.count < 5) continue;

        switch (rule.metric) {
          case "avg":
            actualValue = Math.round((txStats.sumElapsed / txStats.count) * 100) / 100;
            break;
          case "p95":
            actualValue = txStats.histogram.p95();
            break;
          case "p99":
            actualValue = txStats.histogram.p99();
            break;
          case "p90":
            actualValue = txStats.histogram.p90();
            break;
          case "max":
            actualValue = txStats.maxElapsed;
            break;
          case "errorRate":
            actualValue = Math.round((txStats.errors / txStats.count) * 10000) / 100;
            break;
        }
      } else {
        switch (rule.metric) {
          case "avg":
            actualValue = avgResponseTime;
            break;
          case "p95":
            actualValue = p95;
            break;
          case "p99":
            actualValue = p99;
            break;
          case "p90":
            actualValue = this.totalCount > 0
              ? this.globalHistogram.p90()
              : 0;
            break;
          case "max":
            actualValue = 0;
            this.transactions.forEach((s) => {
              actualValue = Math.max(actualValue!, s.maxElapsed);
            });
            break;
          case "errorRate":
            actualValue = errorRate;
            break;
          case "throughput":
            actualValue = throughput;
            break;
        }
      }

      if (actualValue === null) continue;

      let violated = false;
      switch (rule.comparator) {
        case "gt":
          violated = actualValue > rule.threshold;
          break;
        case "gte":
          violated = actualValue >= rule.threshold;
          break;
        case "lt":
          violated = actualValue < rule.threshold;
          break;
        case "lte":
          violated = actualValue <= rule.threshold;
          break;
      }

      if (violated) {
        violations.push({
          ruleId: rule.id,
          metric: rule.metric,
          comparator: rule.comparator,
          threshold: rule.threshold,
          actualValue,
          transactionLabel: rule.transactionLabel,
        });
      }
    }

    return violations;
  }

  reset(): void {
    this.totalCount = 0;
    this.totalErrors = 0;
    this.sumElapsed = 0;
    this.parentSampleCount = 0;
    this.parentSumElapsed = 0;
    this.hasTransactionControllers = false;
    this.globalHistogram.reset();
    this.lastActiveThreads = 0;
    this.firstTimestamp = 0;
    this.lastTimestamp = 0;
    this.lastEndTimestamp = 0;
    this.transactions.clear();
    this.series = [];
    this.currentBucket = null;
    this.lateBuckets.clear();
    this.seriesRawCounts.clear();
    this.throughputSlots = new Array(THROUGHPUT_SLOTS).fill(0);
    this.throughputSlotBase = 0;
    this.analysisEngine.reset();
  }

  exportCheckpoint(): AggregatorCheckpoint {
    const transactions: Record<string, TransactionCheckpoint> = {};
    this.transactions.forEach((stats, label) => {
      transactions[label] = {
        histogramCounts: stats.histogram.exportCounts(),
        count: stats.count,
        errors: stats.errors,
        sumElapsed: stats.sumElapsed,
        minElapsed: stats.minElapsed === Infinity ? 0 : stats.minElapsed,
        maxElapsed: stats.maxElapsed,
        firstTimestamp: stats.firstTimestamp,
        lastEndTimestamp: stats.lastEndTimestamp,
        errorCodes: Object.fromEntries(stats.errorCodes),
        isParent: stats.isParent,
      };
    });

    return {
      version: 4,
      globalHistogramCounts: this.globalHistogram.exportCounts(),
      totalCount: this.totalCount,
      totalErrors: this.totalErrors,
      sumElapsed: this.sumElapsed,
      parentSampleCount: this.parentSampleCount,
      parentSumElapsed: this.parentSumElapsed,
      excludeParentFromGlobal: this.excludeParentFromGlobal,
      hasTransactionControllers: this.hasTransactionControllers,
      firstTimestamp: this.firstTimestamp,
      lastTimestamp: this.lastTimestamp,
      lastEndTimestamp: this.lastEndTimestamp,
      transactions,
    };
  }

  importCheckpoint(checkpoint: AggregatorCheckpoint): void {
    this.totalCount = checkpoint.totalCount;
    this.totalErrors = checkpoint.totalErrors;
    this.sumElapsed = checkpoint.sumElapsed;
    this.parentSampleCount = checkpoint.parentSampleCount || 0;
    this.parentSumElapsed = checkpoint.parentSumElapsed || 0;
    if (checkpoint.excludeParentFromGlobal !== undefined) {
      this.excludeParentFromGlobal = checkpoint.excludeParentFromGlobal;
    }
    if (checkpoint.hasTransactionControllers !== undefined) {
      this.hasTransactionControllers = checkpoint.hasTransactionControllers;
    }
    this.firstTimestamp = checkpoint.firstTimestamp;
    this.lastTimestamp = checkpoint.lastTimestamp;
    this.lastEndTimestamp = checkpoint.lastEndTimestamp;

    const globalHistCounts = (checkpoint as any).globalHistogramCounts;
    if (globalHistCounts && globalHistCounts.length > 0) {
      this.globalHistogram.importCounts(globalHistCounts);
    } else {
      const globalValues = (checkpoint as any).globalValues || (checkpoint as any).globalCentroids;
      if (globalValues && globalValues.length > 0) {
        if (typeof globalValues[0] === "number") {
          for (const v of globalValues) {
            this.globalHistogram.record(v);
          }
        } else if (Array.isArray(globalValues[0])) {
          for (const [mean, count] of globalValues) {
            const idx = Math.min(Math.round(mean), 60000);
            for (let i = 0; i < count; i++) {
              this.globalHistogram.record(idx);
            }
          }
        }
      }
    }

    for (const [label, data] of Object.entries(checkpoint.transactions)) {
      const txStats: TransactionStats = {
        count: data.count,
        errors: data.errors,
        sumElapsed: data.sumElapsed,
        minElapsed: data.minElapsed,
        maxElapsed: data.maxElapsed,
        histogram: new FixedHistogram(),
        errorCodes: new Map(),
        firstTimestamp: data.firstTimestamp,
        lastEndTimestamp: data.lastEndTimestamp,
        isParent: data.isParent || false,
      };

      const txHistCounts = (data as any).histogramCounts;
      if (txHistCounts && txHistCounts.length > 0) {
        txStats.histogram.importCounts(txHistCounts);
      } else {
        const txValues = (data as any).values || (data as any).centroids;
        if (txValues && txValues.length > 0) {
          if (typeof txValues[0] === "number") {
            for (const v of txValues) {
              txStats.histogram.record(v);
            }
          } else if (Array.isArray(txValues[0])) {
            for (const [mean, count] of txValues) {
              const idx = Math.min(Math.round(mean), 60000);
              for (let i = 0; i < count; i++) {
                txStats.histogram.record(idx);
              }
            }
          }
        }
      }

      if (data.errorCodes) {
        for (const [code, cnt] of Object.entries(data.errorCodes)) {
          txStats.errorCodes.set(code, cnt as number);
        }
      }

      this.transactions.set(label, txStats);
    }
  }
}
