import { type Express, type Request, type Response } from "express";
import { db } from "./db";
import { releaseTags, testExecutions } from "@shared/schema";
import { eq, asc } from "drizzle-orm";
import { requireAuth, requireEngineerOrAdmin } from "./route-middleware";
import { validate, z, idParam } from "./validation";
import { asyncHandler } from "./error-handler";

export function registerReleaseTagRoutes(app: Express): void {
  app.get("/api/release-tags", requireAuth, asyncHandler(async (_req: Request, res: Response) => {
    const tags = await db.select().from(releaseTags).orderBy(asc(releaseTags.name));
    res.json(tags);
  }));

  app.post("/api/release-tags", requireEngineerOrAdmin, validate({
    body: z.object({
      name: z.string().min(1).max(100).trim(),
      description: z.string().max(500).optional(),
      color: z.string().max(20).optional(),
    }),
  }), asyncHandler(async (req: Request, res: Response) => {
    const userId = (req.session as any)?.user?.id;
    const { name, description, color } = req.body;

    const existing = await db.select().from(releaseTags).where(eq(releaseTags.name, name)).limit(1);
    if (existing.length > 0) {
      return res.status(409).json({ message: "A release tag with this name already exists" });
    }

    const [tag] = await db.insert(releaseTags).values({
      name,
      description: description || null,
      color: color || null,
      createdBy: userId || null,
    }).returning();

    res.status(201).json(tag);
  }));

  app.delete("/api/release-tags/:id", requireEngineerOrAdmin, validate({ params: idParam }), asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as unknown as number;
    const [deleted] = await db.delete(releaseTags).where(eq(releaseTags.id, id)).returning();
    if (!deleted) return res.status(404).json({ message: "Release tag not found" });
    res.sendStatus(204);
  }));

  app.patch("/api/executions/:id/release-tag", requireEngineerOrAdmin, validate({
    params: idParam,
    body: z.object({
      releaseTag: z.string().trim().min(1).max(100).nullable(),
    }),
  }), asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as unknown as number;
    const rawTag = req.body.releaseTag;
    const releaseTag = rawTag && rawTag.trim() ? rawTag.trim() : null;

    const [updated] = await db.update(testExecutions)
      .set({ releaseTag })
      .where(eq(testExecutions.id, id))
      .returning({ id: testExecutions.id, releaseTag: testExecutions.releaseTag });

    if (!updated) return res.status(404).json({ message: "Execution not found" });

    if (releaseTag) {
      const existing = await db.select().from(releaseTags).where(eq(releaseTags.name, releaseTag)).limit(1);
      if (existing.length === 0) {
        const userId = (req.session as any)?.user?.id;
        await db.insert(releaseTags).values({
          name: releaseTag,
          createdBy: userId || null,
        }).onConflictDoNothing();
      }
    }

    res.json(updated);
  }));
}
