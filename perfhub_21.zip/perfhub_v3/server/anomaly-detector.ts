import {
  getErrorRate,
  normalizeTimeseries,
  linearRegressionSlope,
  medianOf,
  madOf,
  type NormalizedTimeseriesPoint,
} from './live-metrics/stats-utils';

export type AnomalySeverity = "critical" | "warning" | "info";
export type AnomalyCategory =
  | "baseline_deviation"
  | "tail_latency_spread"
  | "throughput_saturation"
  | "error_step_change"
  | "transaction_regression"
  | "time_window_hotspot"
  | "throughput_drop"
  | "gradual_degradation";

export interface AnomalyEvidence {
  metric: string;
  current: number;
  baseline?: number;
  threshold?: number;
  zScore?: number;
  pctChange?: number;
  unit: string;
}

export interface DetectedAnomaly {
  id: string;
  category: AnomalyCategory;
  severity: AnomalySeverity;
  confidence: number;
  title: string;
  description: string;
  recommendation: string;
  evidence: AnomalyEvidence[];
  timestamp?: number;
  timeWindowStart?: number;
  timeWindowEnd?: number;
  transaction?: string;
}

export interface AnomalyDetectionResult {
  healthScore: number;
  overallVerdict: "healthy" | "degraded" | "critical";
  anomalies: DetectedAnomaly[];
  summary: {
    critical: number;
    warning: number;
    info: number;
    total: number;
    categoryCounts: Record<string, number>;
  };
  baselineUsed: boolean;
  baselineExecutionId?: number;
  detectionTimestamp: number;
}

type TimeseriesPoint = NormalizedTimeseriesPoint;

interface TransactionDetail {
  label: string;
  count: number;
  avg: number;
  min: number;
  max: number;
  p50?: number;
  p90?: number;
  p95?: number;
  p99?: number;
  errorRate?: number;
  errorCount?: number;
  throughput?: number;
}

interface ExecutionMetrics {
  totalRequests: number;
  errorCount: number;
  errorRate: number;
  avgResponseTime: number;
  minResponseTime: number;
  maxResponseTime: number;
  throughput: number;
  p50?: number;
  p90?: number;
  p95?: number;
  p99?: number;
  durationSeconds: number;
}

interface BaselineMetrics {
  avgResponseTime: number;
  p50?: number;
  p90?: number;
  p95?: number;
  p99?: number;
  errorRate: number;
  throughput: number;
  totalRequests: number;
  stdResponseTime?: number;
  stdP95?: number;
  stdP99?: number;
  stdThroughput?: number;
  stdErrorRate?: number;
  transactionDetails?: TransactionDetail[];
}

let anomalyIdCounter = 0;
function nextId(): string {
  return `anomaly_${Date.now()}_${++anomalyIdCounter}`;
}

function clampConfidence(raw: number): number {
  return Math.max(0, Math.min(100, Math.round(raw)));
}

function detectBaselineDeviation(
  current: ExecutionMetrics,
  baseline: BaselineMetrics,
  minSampleSize: number
): DetectedAnomaly[] {
  const anomalies: DetectedAnomaly[] = [];
  if (baseline.totalRequests < minSampleSize) return anomalies;

  const checks: Array<{
    metric: string;
    currentVal: number;
    baselineVal: number;
    baselineStd?: number;
    unit: string;
    higherIsBad: boolean;
    warningZ: number;
    criticalZ: number;
    fallbackWarningPct: number;
    fallbackCriticalPct: number;
    minAbsDiff: number;
    absThreshold?: number;
  }> = [
    { metric: "Avg Response Time", currentVal: current.avgResponseTime, baselineVal: baseline.avgResponseTime, baselineStd: baseline.stdResponseTime, unit: "ms", higherIsBad: true, warningZ: 2.5, criticalZ: 4, fallbackWarningPct: 15, fallbackCriticalPct: 40, minAbsDiff: 50 },
    { metric: "P95 Response Time", currentVal: current.p95 || 0, baselineVal: baseline.p95 || 0, baselineStd: baseline.stdP95, unit: "ms", higherIsBad: true, warningZ: 2.5, criticalZ: 4, fallbackWarningPct: 20, fallbackCriticalPct: 50, minAbsDiff: 100 },
    { metric: "P99 Response Time", currentVal: current.p99 || 0, baselineVal: baseline.p99 || 0, baselineStd: baseline.stdP99 ?? baseline.stdP95, unit: "ms", higherIsBad: true, warningZ: 2.5, criticalZ: 4, fallbackWarningPct: 25, fallbackCriticalPct: 60, minAbsDiff: 150 },
    { metric: "Error Rate", currentVal: current.errorRate * 100, baselineVal: baseline.errorRate * 100, baselineStd: baseline.stdErrorRate ? baseline.stdErrorRate * 100 : undefined, unit: "%", higherIsBad: true, warningZ: 2.5, criticalZ: 4, fallbackWarningPct: 50, fallbackCriticalPct: 200, minAbsDiff: 2, absThreshold: 5 },
    { metric: "Throughput", currentVal: current.throughput, baselineVal: baseline.throughput, baselineStd: baseline.stdThroughput, unit: "req/s", higherIsBad: false, warningZ: 2.5, criticalZ: 4, fallbackWarningPct: 15, fallbackCriticalPct: 35, minAbsDiff: 5 },
  ];

  for (const check of checks) {
    if (check.baselineVal < 0.001 && check.currentVal < 0.001) continue;

    if (check.baselineVal < 0.001 && check.currentVal >= (check.absThreshold || check.minAbsDiff)) {
      const severity: AnomalySeverity = check.currentVal >= (check.absThreshold || check.minAbsDiff) * 3 ? "critical" : "warning";
      anomalies.push({
        id: nextId(),
        category: "baseline_deviation",
        severity,
        confidence: clampConfidence(Math.min(90, 60 + check.currentVal * 2)),
        title: `${check.metric} Baseline Deviation`,
        description: `${check.metric} appeared at ${check.currentVal.toFixed(1)}${check.unit} where baseline had ~0${check.unit}. This is a new regression not present in the baseline run.`,
        recommendation: check.metric === "Error Rate"
          ? "New errors appeared that were absent in baseline. Check application logs for new exception types."
          : "Investigate what changed since the baseline run.",
        evidence: [{
          metric: check.metric,
          current: Math.round(check.currentVal * 100) / 100,
          baseline: 0,
          unit: check.unit,
        }],
      });
      continue;
    }

    if (check.baselineVal < 0.001) continue;

    const absDiff = Math.abs(check.currentVal - check.baselineVal);
    if (absDiff < check.minAbsDiff) continue;

    const pctChange = ((check.currentVal - check.baselineVal) / check.baselineVal) * 100;
    const isRegression = check.higherIsBad ? pctChange > 0 : pctChange < 0;
    if (!isRegression) continue;

    let zScore: number | undefined;
    let severity: AnomalySeverity | null = null;

    const baselineStd = check.baselineStd;
    if (baselineStd && baselineStd > 0.001) {
      zScore = Math.abs((check.currentVal - check.baselineVal) / baselineStd);
      if (zScore >= check.criticalZ) severity = "critical";
      else if (zScore >= check.warningZ) severity = "warning";
    }

    if (!severity) {
      const absPct = Math.abs(pctChange);
      if (absPct >= check.fallbackCriticalPct) severity = "critical";
      else if (absPct >= check.fallbackWarningPct) severity = "warning";
    }

    if (!severity) continue;

    let confidence = 50;
    const absPct = Math.abs(pctChange);
    if (zScore && zScore > 2) {
      confidence = Math.min(98, 55 + zScore * 8);
    } else {
      confidence = Math.min(92, 50 + absPct * 0.5);
    }

    const direction = check.higherIsBad ? "increased" : "decreased";
    anomalies.push({
      id: nextId(),
      category: "baseline_deviation",
      severity,
      confidence: clampConfidence(confidence),
      title: `${check.metric} Baseline Deviation`,
      description: `${check.metric} ${direction} by ${absPct.toFixed(1)}% compared to baseline (${check.currentVal.toFixed(1)}${check.unit} vs baseline ${check.baselineVal.toFixed(1)}${check.unit}).${zScore ? ` Modified Z-score: ${zScore.toFixed(1)}\u03C3.` : ""}`,
      recommendation: check.metric.includes("Response Time")
        ? "Investigate recent code changes, infrastructure modifications, or increased data volumes that may explain the regression."
        : check.metric === "Error Rate"
        ? "Check application logs for new error patterns. Verify external dependencies and database connectivity."
        : "Analyze if load profile changed. Check for resource constraints (CPU, memory, connections).",
      evidence: [{
        metric: check.metric,
        current: Math.round(check.currentVal * 100) / 100,
        baseline: Math.round(check.baselineVal * 100) / 100,
        zScore: zScore ? Math.round(zScore * 100) / 100 : undefined,
        pctChange: Math.round(pctChange * 100) / 100,
        unit: check.unit,
      }],
    });
  }

  return anomalies;
}

function detectTailLatencySpread(
  current: ExecutionMetrics,
  timeseries: TimeseriesPoint[]
): DetectedAnomaly[] {
  const anomalies: DetectedAnomaly[] = [];

  const p50 = current.p50 || 0;
  const p95 = current.p95 || 0;
  const p99 = current.p99 || 0;

  if (p50 < 1) return anomalies;

  const p99p50Ratio = p99 / p50;
  const p95p50Ratio = p95 / p50;

  if (p99p50Ratio > 10 && p99 > 500) {
    anomalies.push({
      id: nextId(),
      category: "tail_latency_spread",
      severity: "critical",
      confidence: clampConfidence(Math.min(95, 60 + (p99p50Ratio - 10) * 3)),
      title: "Severe Tail Latency Spread",
      description: `P99 is ${p99p50Ratio.toFixed(1)}x the P50 (${Math.round(p99)}ms vs ${Math.round(p50)}ms). A small percentage of requests experience dramatically longer response times.`,
      recommendation: "Investigate GC pauses, lock contention, database slow queries, or external service timeouts affecting a subset of requests. Check thread dumps during P99 windows.",
      evidence: [
        { metric: "P99/P50 Ratio", current: Math.round(p99p50Ratio * 10) / 10, threshold: 10, unit: "x" },
        { metric: "P99", current: Math.round(p99), unit: "ms" },
        { metric: "P50", current: Math.round(p50), unit: "ms" },
      ],
    });
  } else if (p99p50Ratio > 5 && p99 > 300) {
    anomalies.push({
      id: nextId(),
      category: "tail_latency_spread",
      severity: "warning",
      confidence: clampConfidence(Math.min(85, 50 + (p99p50Ratio - 5) * 4)),
      title: "Elevated Tail Latency Spread",
      description: `P99 is ${p99p50Ratio.toFixed(1)}x the P50 (${Math.round(p99)}ms vs ${Math.round(p50)}ms). Some requests experience significantly longer response times.`,
      recommendation: "Review slow query logs and check for intermittent resource contention. Consider profiling requests that hit the P99 latency band.",
      evidence: [
        { metric: "P99/P50 Ratio", current: Math.round(p99p50Ratio * 10) / 10, threshold: 5, unit: "x" },
        { metric: "P99", current: Math.round(p99), unit: "ms" },
        { metric: "P50", current: Math.round(p50), unit: "ms" },
      ],
    });
  }

  if (p95p50Ratio > 4 && p95 > 200 && !anomalies.length) {
    anomalies.push({
      id: nextId(),
      category: "tail_latency_spread",
      severity: "warning",
      confidence: clampConfidence(Math.min(80, 45 + (p95p50Ratio - 4) * 5)),
      title: "P95 Latency Spread",
      description: `P95 is ${p95p50Ratio.toFixed(1)}x the P50 (${Math.round(p95)}ms vs ${Math.round(p50)}ms).`,
      recommendation: "5% of requests are significantly slower. Check for variability in backend processing paths.",
      evidence: [
        { metric: "P95/P50 Ratio", current: Math.round(p95p50Ratio * 10) / 10, threshold: 4, unit: "x" },
      ],
    });
  }

  return anomalies;
}

function detectThroughputSaturation(
  timeseries: TimeseriesPoint[]
): DetectedAnomaly[] {
  const anomalies: DetectedAnomaly[] = [];
  if (timeseries.length < 20) return anomalies;

  const windowSize = Math.max(10, Math.floor(timeseries.length * 0.1));
  const windows: Array<{ avgTP: number; avgThreads: number; avgRT: number; startIdx: number }> = [];
  const stepSize = Math.max(1, Math.floor(windowSize / 2));

  let sumTP = 0, sumThreads = 0, sumRT = 0;
  for (let j = 0; j < windowSize && j < timeseries.length; j++) {
    sumTP += timeseries[j].rps;
    sumThreads += (timeseries[j].active_threads || 0);
    sumRT += timeseries[j].avg_ms;
  }
  if (timeseries.length >= windowSize) {
    windows.push({ avgTP: sumTP / windowSize, avgThreads: sumThreads / windowSize, avgRT: sumRT / windowSize, startIdx: 0 });
  }

  for (let i = stepSize; i <= timeseries.length - windowSize; i += stepSize) {
    let wSumTP = 0, wSumThreads = 0, wSumRT = 0;
    for (let j = i; j < i + windowSize; j++) {
      wSumTP += timeseries[j].rps;
      wSumThreads += (timeseries[j].active_threads || 0);
      wSumRT += timeseries[j].avg_ms;
    }
    windows.push({ avgTP: wSumTP / windowSize, avgThreads: wSumThreads / windowSize, avgRT: wSumRT / windowSize, startIdx: i });
  }

  if (windows.length < 3) return anomalies;

  let saturationDetected = false;
  for (let i = 1; i < windows.length; i++) {
    const prev = windows[i - 1];
    const curr = windows[i];
    if (prev.avgThreads < 1 || prev.avgTP < 0.5) continue;

    const threadIncrease = ((curr.avgThreads - prev.avgThreads) / prev.avgThreads) * 100;
    const tpChange = ((curr.avgTP - prev.avgTP) / prev.avgTP) * 100;
    const rtChange = ((curr.avgRT - prev.avgRT) / prev.avgRT) * 100;

    if (threadIncrease > 20 && tpChange < 5 && rtChange > 30) {
      saturationDetected = true;
      const satPointSec = timeseries[curr.startIdx]?.sec || 0;

      anomalies.push({
        id: nextId(),
        category: "throughput_saturation",
        severity: rtChange > 80 ? "critical" : "warning",
        confidence: clampConfidence(Math.min(90, 55 + threadIncrease * 0.3 + rtChange * 0.2)),
        title: "Throughput Saturation Detected",
        description: `Concurrency increased ${threadIncrease.toFixed(0)}% but throughput stayed flat (${tpChange > 0 ? "+" : ""}${tpChange.toFixed(1)}%) while response time grew ${rtChange.toFixed(0)}%. System hit its capacity ceiling.`,
        recommendation: "This is the breaking point. Reduce concurrency to the level before saturation, or scale infrastructure (add nodes, increase connection pools, optimize slow queries).",
        evidence: [
          { metric: "Thread Increase", current: Math.round(curr.avgThreads), baseline: Math.round(prev.avgThreads), pctChange: Math.round(threadIncrease), unit: "threads" },
          { metric: "Throughput Change", current: Math.round(curr.avgTP * 10) / 10, baseline: Math.round(prev.avgTP * 10) / 10, pctChange: Math.round(tpChange), unit: "req/s" },
          { metric: "RT Increase", current: Math.round(curr.avgRT), baseline: Math.round(prev.avgRT), pctChange: Math.round(rtChange), unit: "ms" },
        ],
        timestamp: satPointSec * 1000,
      });
      break;
    }
  }

  if (!saturationDetected && windows.length >= 4) {
    const tpValues = windows.map(w => w.avgTP);
    const threadValues = windows.map(w => w.avgThreads);
    const tpSlope = linearRegressionSlope(tpValues);
    const threadSlope = linearRegressionSlope(threadValues);

    if (threadSlope > 0.5 && Math.abs(tpSlope) < 0.1 && medianOf(tpValues) > 1) {
      anomalies.push({
        id: nextId(),
        category: "throughput_saturation",
        severity: "info",
        confidence: clampConfidence(55),
        title: "Throughput Plateau",
        description: `Throughput plateaued around ${medianOf(tpValues).toFixed(1)} req/s while concurrency was increasing. The system may be approaching its capacity limit.`,
        recommendation: "Monitor closely. If concurrency continues to increase, expect response time degradation.",
        evidence: [
          { metric: "Throughput Plateau", current: Math.round(medianOf(tpValues) * 10) / 10, unit: "req/s" },
          { metric: "Concurrency Trend", current: Math.round(threadSlope * 100) / 100, unit: "threads/window" },
        ],
      });
    }
  }

  return anomalies;
}

function detectErrorStepChanges(
  timeseries: TimeseriesPoint[],
  testStartSec: number
): DetectedAnomaly[] {
  const anomalies: DetectedAnomaly[] = [];
  if (timeseries.length < 20) return anomalies;

  const skipStart = Math.max(5, Math.floor(timeseries.length * 0.1));
  const skipEnd = Math.max(5, Math.floor(timeseries.length * 0.05));
  const analysisStart = skipStart;
  const analysisEnd = timeseries.length - skipEnd;
  if (analysisEnd - analysisStart < 20) return anomalies;

  const errorRates: number[] = timeseries.map(p => getErrorRate(p));

  const windowSize = Math.max(10, Math.floor(timeseries.length * 0.08));
  let bestShift = 0;
  let bestIdx = -1;
  let bestBefore = 0;
  let bestAfter = 0;

  const loopStart = Math.max(analysisStart, windowSize);
  const loopEnd = Math.min(analysisEnd, errorRates.length - windowSize);

  if (loopStart < loopEnd) {
    let sumBefore = 0;
    for (let j = loopStart - windowSize; j < loopStart; j++) {
      sumBefore += errorRates[j];
    }
    let sumAfter = 0;
    for (let j = loopStart; j < loopStart + windowSize; j++) {
      sumAfter += errorRates[j];
    }

    for (let i = loopStart; i < loopEnd; i++) {
      if (i > loopStart) {
        sumBefore += errorRates[i - 1];
        sumBefore -= errorRates[i - 1 - windowSize];
        sumAfter += errorRates[i + windowSize - 1];
        sumAfter -= errorRates[i - 1];
      }
      const avgBefore = sumBefore / windowSize;
      const avgAfter = sumAfter / windowSize;
      const shift = avgAfter - avgBefore;

      if (shift > bestShift && shift > 2 && avgAfter > 2) {
        bestShift = shift;
        bestIdx = i;
        bestBefore = avgBefore;
        bestAfter = avgAfter;
      }
    }
  }

  if (bestIdx >= 0 && bestShift > 2 && bestAfter > 2) {
    const stepTimeSec = timeseries[bestIdx]?.sec || 0;
    const severity: AnomalySeverity = bestAfter > 30 ? "critical" : bestAfter > 5 ? "warning" : "info";

    anomalies.push({
      id: nextId(),
      category: "error_step_change",
      severity,
      confidence: clampConfidence(Math.min(92, 50 + bestShift * 1.5)),
      title: "Error Rate Step Change",
      description: `Error rate jumped from ${bestBefore.toFixed(1)}% to ${bestAfter.toFixed(1)}% (step of +${bestShift.toFixed(1)}pp) at approximately ${formatTimestamp(stepTimeSec, testStartSec)}.`,
      recommendation: "Check application logs around this timestamp for new exceptions or dependency failures. This pattern typically indicates an infrastructure event or deployment issue.",
      evidence: [
        { metric: "Error Rate Before", current: Math.round(bestBefore * 10) / 10, unit: "%" },
        { metric: "Error Rate After", current: Math.round(bestAfter * 10) / 10, unit: "%" },
        { metric: "Step Magnitude", current: Math.round(bestShift * 10) / 10, unit: "pp" },
      ],
      timestamp: stepTimeSec * 1000,
    });
  }

  return anomalies;
}

function detectHighErrorRate(
  current: ExecutionMetrics
): DetectedAnomaly[] {
  const anomalies: DetectedAnomaly[] = [];
  const errorPct = current.errorRate * 100;

  if (current.totalRequests < 10) return anomalies;

  if (errorPct >= 1) {
    const severity: AnomalySeverity =
      errorPct >= 10 ? "critical" : errorPct >= 5 ? "warning" : "info";
    const confidence = clampConfidence(
      Math.min(95, 50 + errorPct * 3 + Math.min(current.errorCount, 100) * 0.2)
    );

    anomalies.push({
      id: nextId(),
      category: "error_step_change",
      severity,
      confidence,
      title: "Elevated Error Rate",
      description: `${errorPct.toFixed(2)}% of requests failed (${current.errorCount} errors out of ${current.totalRequests} total requests). ${
        errorPct >= 10
          ? "This is a critically high failure rate indicating a major issue."
          : errorPct >= 5
          ? "This error level likely impacts end-user experience."
          : "While below critical thresholds, any errors warrant investigation."
      }`,
      recommendation:
        "Review error responses in the JMeter results to identify the failing endpoints and error types. Check application logs for exceptions or infrastructure issues during the test window.",
      evidence: [
        { metric: "Error Rate", current: Math.round(errorPct * 100) / 100, unit: "%" },
        { metric: "Error Count", current: current.errorCount, unit: "errors" },
        { metric: "Total Requests", current: current.totalRequests, unit: "requests" },
      ],
    });
  }

  return anomalies;
}

function detectTransactionRegression(
  currentTx: TransactionDetail[],
  baselineTx: TransactionDetail[] | undefined,
  minRequests: number
): DetectedAnomaly[] {
  const anomalies: DetectedAnomaly[] = [];
  if (!baselineTx || baselineTx.length === 0) return anomalies;

  const baselineMap = new Map<string, TransactionDetail>();
  for (const tx of baselineTx) {
    baselineMap.set(tx.label, tx);
  }

  const regressions: Array<{ tx: TransactionDetail; base: TransactionDetail; score: number; pctChange: number }> = [];

  for (const tx of currentTx) {
    if (tx.count < minRequests) continue;
    const base = baselineMap.get(tx.label);
    if (!base || base.count < minRequests) continue;
    if (base.avg < 1) continue;

    const pctChange = ((tx.avg - base.avg) / base.avg) * 100;
    const absDiff = tx.avg - base.avg;
    if (absDiff < 20) continue;
    if (pctChange < 10) continue;

    const score = pctChange / 10;
    regressions.push({ tx, base, score, pctChange });
  }

  regressions.sort((a, b) => b.score - a.score);

  for (const r of regressions.slice(0, 10)) {
    const severity: AnomalySeverity = r.pctChange >= 50 ? "critical" : r.pctChange >= 20 ? "warning" : "info";

    const evidence: AnomalyEvidence[] = [
      { metric: "Avg RT", current: Math.round(r.tx.avg), baseline: Math.round(r.base.avg), pctChange: Math.round(r.pctChange), unit: "ms" },
    ];

    if (r.tx.p95 && r.base.p95 && r.base.p95 > 0) {
      const p95Change = ((r.tx.p95 - r.base.p95) / r.base.p95) * 100;
      evidence.push({ metric: "P95 RT", current: Math.round(r.tx.p95), baseline: Math.round(r.base.p95), pctChange: Math.round(p95Change), unit: "ms" });
    }

    if (r.tx.errorRate != null && r.base.errorRate != null) {
      const errCurrent = (r.tx.errorRate || 0) * 100;
      const errBase = (r.base.errorRate || 0) * 100;
      if (errCurrent > errBase + 1) {
        evidence.push({ metric: "Error Rate", current: Math.round(errCurrent * 10) / 10, baseline: Math.round(errBase * 10) / 10, unit: "%" });
      }
    }

    anomalies.push({
      id: nextId(),
      category: "transaction_regression",
      severity,
      confidence: clampConfidence(Math.min(92, 50 + r.score * 3)),
      title: `Transaction Regression: ${r.tx.label}`,
      description: `"${r.tx.label}" degraded by ${r.pctChange.toFixed(0)}% (${Math.round(r.tx.avg)}ms vs baseline ${Math.round(r.base.avg)}ms, ${r.tx.count} samples).`,
      recommendation: `Profile the "${r.tx.label}" endpoint. Check for N+1 queries, missing indexes, or increased payload sizes.`,
      evidence,
      transaction: r.tx.label,
    });
  }

  return anomalies;
}

function detectTimeWindowHotspots(
  timeseries: TimeseriesPoint[],
  testStartSec: number
): DetectedAnomaly[] {
  const anomalies: DetectedAnomaly[] = [];
  if (timeseries.length < 30) return anomalies;

  const rtValues = timeseries.map(p => p.avg_ms);
  const globalMedian = medianOf(rtValues);
  const globalMad = madOf(rtValues);

  if (globalMad < 1) {
    const globalMean = rtValues.reduce((s, v) => s + v, 0) / rtValues.length;
    const maxRT = Math.max(...rtValues);
    if (globalMean > 0 && maxRT > globalMean * 3 && maxRT > 500) {
      const peakIdx = rtValues.indexOf(maxRT);
      const peakSec = timeseries[peakIdx]?.sec || 0;
      anomalies.push({
        id: nextId(),
        category: "time_window_hotspot",
        severity: maxRT > globalMean * 10 ? "critical" : "warning",
        confidence: clampConfidence(Math.min(90, 60 + (maxRT / globalMean) * 5)),
        title: "Response Time Spike on Stable Baseline",
        description: `Response time spiked to ${Math.round(maxRT)}ms at ${formatTimestamp(peakSec, testStartSec)} on a very stable baseline of ~${Math.round(globalMean)}ms (${(maxRT / globalMean).toFixed(1)}x higher).`,
        recommendation: "This isolated spike on an otherwise stable test suggests a transient issue — GC pause, connection timeout, or infrastructure blip. Check system metrics around this timestamp.",
        evidence: [
          { metric: "Peak RT", current: Math.round(maxRT), unit: "ms" },
          { metric: "Baseline Avg RT", current: Math.round(globalMean), unit: "ms" },
          { metric: "Spike Ratio", current: Math.round((maxRT / globalMean) * 10) / 10, unit: "x" },
        ],
        timestamp: peakSec * 1000,
      });
    }
    return anomalies;
  }

  const windowSize = Math.max(5, Math.floor(timeseries.length * 0.05));
  const hotspots: Array<{ startIdx: number; endIdx: number; avgRT: number; maxRT: number; zScore: number }> = [];

  let windowSum = 0;
  for (let j = 0; j < windowSize; j++) {
    windowSum += rtValues[j];
  }

  let i = 0;
  while (i <= timeseries.length - windowSize) {
    if (i > 0) {
      windowSum = windowSum - rtValues[i - 1] + rtValues[i + windowSize - 1];
    }
    const windowAvg = windowSum / windowSize;
    const z = (windowAvg - globalMedian) / globalMad;

    if (z > 2.5) {
      let endIdx = i + windowSize;
      while (endIdx < timeseries.length) {
        const nextZ = (rtValues[endIdx] - globalMedian) / globalMad;
        if (nextZ < 1.5) break;
        endIdx++;
      }
      let extSum = 0, extMax = -Infinity;
      for (let j = i; j < endIdx; j++) {
        extSum += rtValues[j];
        if (rtValues[j] > extMax) extMax = rtValues[j];
      }
      const extAvg = extSum / (endIdx - i);
      const extZ = (extAvg - globalMedian) / globalMad;

      hotspots.push({ startIdx: i, endIdx, avgRT: extAvg, maxRT: extMax, zScore: extZ });

      i = endIdx;
      if (i <= timeseries.length - windowSize) {
        windowSum = 0;
        for (let j = i; j < i + windowSize; j++) {
          windowSum += rtValues[j];
        }
        i++;
        continue;
      }
      break;
    } else {
      i++;
    }
  }

  for (const hs of hotspots.slice(0, 5)) {
    const startSec = timeseries[hs.startIdx]?.sec || 0;
    const endSec = timeseries[Math.min(hs.endIdx, timeseries.length - 1)]?.sec || 0;
    const durationSec = endSec - startSec;

    let errRateSum = 0;
    const count = hs.endIdx - hs.startIdx;
    for (let j = hs.startIdx; j < hs.endIdx; j++) {
      errRateSum += getErrorRate(timeseries[j]);
    }
    const errRate = count > 0 ? errRateSum / count : 0;

    const severity: AnomalySeverity = hs.zScore > 4 ? "critical" : hs.zScore > 3 ? "warning" : "info";

    anomalies.push({
      id: nextId(),
      category: "time_window_hotspot",
      severity,
      confidence: clampConfidence(Math.min(90, 50 + hs.zScore * 8)),
      title: "Response Time Hotspot",
      description: `Localized RT spike from ${formatTimestamp(startSec, testStartSec)} to ${formatTimestamp(endSec, testStartSec)} (${durationSec}s). Average RT was ${Math.round(hs.avgRT)}ms (peak ${Math.round(hs.maxRT)}ms) vs test median of ${Math.round(globalMedian)}ms.`,
      recommendation: "Correlate this time window with infrastructure metrics (CPU, GC, network). Check for scheduled jobs, cache evictions, or connection pool exhaustion during this period.",
      evidence: [
        { metric: "Window Avg RT", current: Math.round(hs.avgRT), baseline: Math.round(globalMedian), unit: "ms" },
        { metric: "Window Peak RT", current: Math.round(hs.maxRT), unit: "ms" },
        { metric: "Window Error Rate", current: Math.round(errRate * 10) / 10, unit: "%" },
        { metric: "Z-Score", current: Math.round(hs.zScore * 10) / 10, unit: "σ" },
      ],
      timeWindowStart: startSec * 1000,
      timeWindowEnd: endSec * 1000,
    });
  }

  return anomalies;
}

function detectThroughputDrops(
  timeseries: TimeseriesPoint[],
  testStartSec: number
): DetectedAnomaly[] {
  const anomalies: DetectedAnomaly[] = [];
  if (timeseries.length < 30) return anomalies;

  const tpValues = timeseries.map(p => p.throughput ?? p.rps ?? 0);
  const skipStart = Math.max(5, Math.floor(timeseries.length * 0.1));
  const skipEnd = Math.max(3, Math.floor(timeseries.length * 0.05));
  const stableSlice = tpValues.slice(skipStart, tpValues.length - skipEnd);
  if (stableSlice.length < 20) return anomalies;

  const medianTP = medianOf(stableSlice);
  const madTP = madOf(stableSlice);

  if (medianTP < 1) return anomalies;

  const windowSize = Math.max(5, Math.floor(stableSlice.length * 0.05));
  const drops: Array<{ startIdx: number; endIdx: number; avgTP: number; minTP: number; zScore: number }> = [];

  const effectiveMad = madTP < 0.5 ? medianTP * 0.1 : madTP;

  let i = 0;
  while (i <= stableSlice.length - windowSize) {
    let windowSum = 0;
    for (let j = i; j < i + windowSize; j++) windowSum += stableSlice[j];
    const windowAvg = windowSum / windowSize;
    const z = (medianTP - windowAvg) / effectiveMad;

    if (z > 2.5 && windowAvg < medianTP * 0.7) {
      let endIdx = i + windowSize;
      while (endIdx < stableSlice.length) {
        const nextZ = (medianTP - stableSlice[endIdx]) / effectiveMad;
        if (nextZ < 1.5) break;
        endIdx++;
      }
      let extSum = 0, extMin = Infinity;
      for (let j = i; j < endIdx; j++) {
        extSum += stableSlice[j];
        if (stableSlice[j] < extMin) extMin = stableSlice[j];
      }
      const extAvg = extSum / (endIdx - i);
      const extZ = (medianTP - extAvg) / effectiveMad;

      drops.push({ startIdx: i + skipStart, endIdx: endIdx + skipStart, avgTP: extAvg, minTP: extMin, zScore: extZ });
      i = endIdx;
      continue;
    }
    i++;
  }

  for (const drop of drops.slice(0, 3)) {
    const startSec = timeseries[drop.startIdx]?.sec || 0;
    const endSec = timeseries[Math.min(drop.endIdx, timeseries.length - 1)]?.sec || 0;
    const durationSec = endSec - startSec;
    const dropPct = ((medianTP - drop.avgTP) / medianTP) * 100;

    const severity: AnomalySeverity = dropPct > 60 ? "critical" : dropPct > 30 ? "warning" : "info";

    anomalies.push({
      id: nextId(),
      category: "throughput_drop",
      severity,
      confidence: clampConfidence(Math.min(92, 50 + dropPct * 0.8)),
      title: "Throughput Drop",
      description: `Throughput dropped to ${drop.avgTP.toFixed(1)} req/s (${dropPct.toFixed(0)}% below median of ${medianTP.toFixed(1)} req/s) from ${formatTimestamp(startSec, testStartSec)} to ${formatTimestamp(endSec, testStartSec)} (${durationSec}s). Minimum throughput in this window was ${drop.minTP.toFixed(1)} req/s.`,
      recommendation: "Throughput drops often indicate server-side bottlenecks — connection pool exhaustion, thread starvation, or backend dependency slowdowns. Correlate with response time and CPU metrics during this window.",
      evidence: [
        { metric: "Window Avg Throughput", current: Math.round(drop.avgTP * 10) / 10, baseline: Math.round(medianTP * 10) / 10, unit: "req/s" },
        { metric: "Window Min Throughput", current: Math.round(drop.minTP * 10) / 10, unit: "req/s" },
        { metric: "Drop Magnitude", current: Math.round(dropPct), unit: "%" },
        { metric: "Duration", current: durationSec, unit: "s" },
      ],
      timeWindowStart: startSec * 1000,
      timeWindowEnd: endSec * 1000,
    });
  }

  return anomalies;
}

function detectGradualDegradation(
  timeseries: TimeseriesPoint[]
): DetectedAnomaly[] {
  const anomalies: DetectedAnomaly[] = [];
  if (timeseries.length < 30) return anomalies;

  const rtValues = timeseries.map(p => p.avg_ms);
  const slope = linearRegressionSlope(rtValues);
  const medRT = medianOf(rtValues);

  if (medRT < 1) return anomalies;

  const relativeSlope = slope / medRT;
  if (relativeSlope < 0.003 || slope < 0.5) return anomalies;

  const firstQuarter = rtValues.slice(0, Math.floor(rtValues.length * 0.25));
  const lastQuarter = rtValues.slice(Math.floor(rtValues.length * 0.75));
  const firstAvg = firstQuarter.reduce((s, v) => s + v, 0) / firstQuarter.length;
  const lastAvg = lastQuarter.reduce((s, v) => s + v, 0) / lastQuarter.length;
  const totalIncrease = lastAvg - firstAvg;
  const pctIncrease = firstAvg > 0 ? (totalIncrease / firstAvg) * 100 : 0;

  if (pctIncrease < 15) return anomalies;

  const severity: AnomalySeverity = pctIncrease > 60 ? "critical" : pctIncrease > 30 ? "warning" : "info";

  anomalies.push({
    id: nextId(),
    category: "gradual_degradation",
    severity,
    confidence: clampConfidence(Math.min(88, 45 + pctIncrease * 0.5)),
    title: "Gradual Performance Degradation",
    description: `Response times increased steadily throughout the test, from ~${Math.round(firstAvg)}ms to ~${Math.round(lastAvg)}ms (+${pctIncrease.toFixed(0)}%). Slope: +${slope.toFixed(2)}ms per sample.`,
    recommendation: "Investigate memory leaks (growing heap), connection pool exhaustion, cache degradation, or accumulating queue depth. Run the test with heap profiling enabled.",
    evidence: [
      { metric: "First Quarter Avg", current: Math.round(firstAvg), unit: "ms" },
      { metric: "Last Quarter Avg", current: Math.round(lastAvg), unit: "ms" },
      { metric: "Total Increase", current: Math.round(pctIncrease), unit: "%" },
      { metric: "Slope", current: Math.round(slope * 100) / 100, unit: "ms/sample" },
    ],
  });

  return anomalies;
}

function computeHealthScore(anomalies: DetectedAnomaly[]): number {
  let score = 100;

  for (const a of anomalies) {
    const weight = a.confidence / 100;
    if (a.severity === "critical") score -= 20 * weight;
    else if (a.severity === "warning") score -= 8 * weight;
    else score -= 2 * weight;
  }

  return Math.max(0, Math.min(100, Math.round(score)));
}

function formatElapsed(elapsedSec: number): string {
  const totalSec = Math.max(0, Math.round(elapsedSec));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}h${m.toString().padStart(2, "0")}m${s.toString().padStart(2, "0")}s`;
  if (m > 0) return `${m}m${s.toString().padStart(2, "0")}s`;
  return `${s}s`;
}

function formatTimestamp(epochSec: number, testStartSec: number): string {
  return formatElapsed(epochSec - testStartSec);
}

export function runAnomalyDetection(
  currentMetrics: ExecutionMetrics,
  rawTimeseries: any[],
  transactionDetails: TransactionDetail[],
  baseline?: BaselineMetrics | null,
  baselineExecutionId?: number
): AnomalyDetectionResult {
  const timeseries = normalizeTimeseries(rawTimeseries);
  const allAnomalies: DetectedAnomaly[] = [];
  const hasBaseline = baseline != null && baseline.totalRequests > 0;

  if (hasBaseline) {
    allAnomalies.push(...detectBaselineDeviation(currentMetrics, baseline!, 10));
    allAnomalies.push(...detectTransactionRegression(transactionDetails, baseline!.transactionDetails, 5));
  }

  allAnomalies.push(...detectTailLatencySpread(currentMetrics, timeseries));
  allAnomalies.push(...detectThroughputSaturation(timeseries));
  allAnomalies.push(...detectHighErrorRate(currentMetrics));
  const testStartSec = timeseries.length > 0 ? timeseries[0].sec : 0;
  allAnomalies.push(...detectErrorStepChanges(timeseries, testStartSec));
  allAnomalies.push(...detectTimeWindowHotspots(timeseries, testStartSec));
  allAnomalies.push(...detectThroughputDrops(timeseries, testStartSec));
  allAnomalies.push(...detectGradualDegradation(timeseries));

  allAnomalies.sort((a, b) => {
    const severityOrder = { critical: 0, warning: 1, info: 2 };
    if (severityOrder[a.severity] !== severityOrder[b.severity]) {
      return severityOrder[a.severity] - severityOrder[b.severity];
    }
    return b.confidence - a.confidence;
  });

  const healthScore = computeHealthScore(allAnomalies);
  const critical = allAnomalies.filter(a => a.severity === "critical").length;
  const warning = allAnomalies.filter(a => a.severity === "warning").length;
  const info = allAnomalies.filter(a => a.severity === "info").length;

  const categoryCounts: Record<string, number> = {};
  for (const a of allAnomalies) {
    categoryCounts[a.category] = (categoryCounts[a.category] || 0) + 1;
  }

  return {
    healthScore,
    overallVerdict: critical > 0 ? "critical" : warning > 0 ? "degraded" : "healthy",
    anomalies: allAnomalies,
    summary: {
      critical,
      warning,
      info,
      total: allAnomalies.length,
      categoryCounts,
    },
    baselineUsed: hasBaseline,
    baselineExecutionId: hasBaseline ? baselineExecutionId : undefined,
    detectionTimestamp: Date.now(),
  };
}
