import { type Express } from "express";
import { storage } from "./storage";
import { requireAuth } from "./route-middleware";
import { validate, z, idParam } from "./validation";
import { asyncHandler } from "./error-handler";

export function registerNotificationRoutes(app: Express): void {

  app.get("/api/notifications", requireAuth, asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    const { page, pageSize, type, read } = req.query as any;

    if (page) {
      const result = await storage.getNotificationsPaginated(userId, {
        page: Number(page),
        pageSize: pageSize ? Number(pageSize) : 50,
        type: type || undefined,
        read: read !== undefined ? read === 'true' : undefined,
      });
      return res.json(result);
    }

    const notifs = await storage.getNotifications(userId);
    res.json(notifs);
  }));

  app.get("/api/notifications/unread-count", requireAuth, asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    const count = await storage.getUnreadNotificationCount(userId);
    res.json({ count });
  }));

  app.post("/api/notifications/mark-all-read", requireAuth, asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    await storage.markAllNotificationsAsRead(userId);
    res.sendStatus(200);
  }));

  app.post("/api/notifications/:id/read", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    await storage.markNotificationAsRead(req.params.id as unknown as number, userId);
    res.sendStatus(200);
  }));

  app.delete("/api/notifications", requireAuth, asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    await storage.clearAllNotifications(userId);
    res.sendStatus(200);
  }));

  app.delete("/api/notifications/:id", requireAuth, validate({ params: idParam }), asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    await storage.deleteNotification(req.params.id as unknown as number, userId);
    res.sendStatus(200);
  }));

  app.get("/api/notification-preferences", requireAuth, asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    const prefs = await storage.getNotificationPreferences(userId);
    if (prefs) {
      res.json(prefs);
    } else {
      res.json({
        userId,
        testCompleted: true,
        testFailed: true,
        slaViolation: true,
        regressionDetected: true,
        approvalRequested: true,
        systemAlerts: true,
        emailEnabled: false,
        emailDigestFrequency: 'instant',
        emailDigestTime: '09:00',
        emailDigestDay: 'monday',
        quietHoursEnabled: false,
        quietHoursStart: '22:00',
        quietHoursEnd: '07:00',
      });
    }
  }));

  app.put("/api/notification-preferences", requireAuth, validate({
    body: z.object({
      testCompleted: z.boolean().optional(),
      testFailed: z.boolean().optional(),
      slaViolation: z.boolean().optional(),
      regressionDetected: z.boolean().optional(),
      approvalRequested: z.boolean().optional(),
      systemAlerts: z.boolean().optional(),
      emailEnabled: z.boolean().optional(),
      emailDigestFrequency: z.enum(["instant", "daily", "weekly"]).optional(),
      emailDigestTime: z.string().optional(),
      emailDigestDay: z.string().optional(),
      quietHoursEnabled: z.boolean().optional(),
      quietHoursStart: z.string().optional(),
      quietHoursEnd: z.string().optional(),
    })
  }), asyncHandler(async (req, res) => {
    const userId = (req.session as any).user.id;
    const {
      testCompleted, testFailed, slaViolation, regressionDetected,
      approvalRequested, systemAlerts, emailEnabled, emailDigestFrequency,
      emailDigestTime, emailDigestDay, quietHoursEnabled, quietHoursStart, quietHoursEnd,
    } = req.body;

    const prefs = await storage.upsertNotificationPreferences(userId, {
      testCompleted, testFailed, slaViolation, regressionDetected,
      approvalRequested, systemAlerts, emailEnabled, emailDigestFrequency,
      emailDigestTime, emailDigestDay, quietHoursEnabled, quietHoursStart, quietHoursEnd,
    });
    res.json(prefs);
  }));
}
