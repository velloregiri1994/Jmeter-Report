package com.example.jmeter.controller;

import java.io.Serializable;

import org.apache.jmeter.control.GenericController;
import org.apache.jmeter.control.NextIsNullException;
import org.apache.jmeter.samplers.Sampler;
import org.apache.jmeter.threads.JMeterContextService;

/**
 * Timed Specified Controller.
 *
 * Runs its children based on elapsed time from when this controller is first
 * reached in a test run. Two modes:
 *  - ONCE (default): children run exactly once, after the configured interval.
 *  - REPEAT: children run every time the configured interval has elapsed.
 *
 * Optional start behavior:
 *  - run immediately: run once as soon as the thread reaches this controller,
 *    then continue with the configured schedule.
 *
 * Scope:
 *  - per thread (default): every thread keeps its own schedule.
 *  - global: one schedule for the whole test; only one thread runs the children
 *    for each due time.
 *
 * Note: the controller is only evaluated when a thread loops past it, so keep
 * a sampler (for example a Flow Control Action pause) beside it in the Thread
 * Group. The actual run time is the first loop iteration at or after the due time.
 */
public class TimedSpecifiedController extends GenericController implements Serializable {

    private static final long serialVersionUID = 2L;

    public static final String INTERVAL = "TimedSpecifiedController.interval";
    public static final String UNIT = "TimedSpecifiedController.unit";
    public static final String REPEAT = "TimedSpecifiedController.repeat";
    public static final String GLOBAL_SCOPE = "TimedSpecifiedController.globalScope";
    public static final String RUN_IMMEDIATE = "TimedSpecifiedController.runImmediate";

    public static final String UNIT_SECONDS = "Seconds";
    public static final String UNIT_MINUTES = "Minutes";

    // Shared by thread clones of this controller in "global" scope.
    private transient GlobalSchedule globalSchedule;

    // Per-thread state (JMeter clones the controller for every thread).
    private transient boolean running;
    private transient boolean executed;
    private transient long nextDue = -1;

    // ---- properties -------------------------------------------------------

    public double getInterval() {
        String raw = getPropertyAsString(INTERVAL, "1");
        try {
            double v = Double.parseDouble(raw.trim());
            return Double.isFinite(v) && v >= 0 ? v : 1.0;
        } catch (NumberFormatException e) {
            return 1.0;
        }
    }

    public void setInterval(double interval) {
        setProperty(INTERVAL, String.valueOf(interval));
    }

    public String getUnit() {
        String unit = getPropertyAsString(UNIT, UNIT_MINUTES);
        return UNIT_SECONDS.equalsIgnoreCase(unit) ? UNIT_SECONDS : UNIT_MINUTES;
    }

    public void setUnit(String unit) {
        setProperty(UNIT, unit);
    }

    public boolean isRepeat() {
        return getPropertyAsBoolean(REPEAT, false);
    }

    public void setRepeat(boolean repeat) {
        setProperty(REPEAT, repeat);
    }

    public boolean isGlobalScope() {
        return getPropertyAsBoolean(GLOBAL_SCOPE, false);
    }

    public void setGlobalScope(boolean globalScope) {
        setProperty(GLOBAL_SCOPE, globalScope);
    }

    public boolean isRunImmediate() {
        return getPropertyAsBoolean(RUN_IMMEDIATE, false);
    }

    public void setRunImmediate(boolean runImmediate) {
        setProperty(RUN_IMMEDIATE, runImmediate);
    }

    private long intervalMillis() {
        double factor = UNIT_SECONDS.equals(getUnit()) ? 1000d : 60_000d;
        double millis = getInterval() * factor;
        return millis >= Long.MAX_VALUE ? Long.MAX_VALUE : Math.max(1L, (long) millis);
    }

    @Override
    public Object clone() {
        GlobalSchedule sharedSchedule = getGlobalSchedule();
        TimedSpecifiedController clone = (TimedSpecifiedController) super.clone();
        clone.globalSchedule = sharedSchedule;
        return clone;
    }

    private synchronized GlobalSchedule getGlobalSchedule() {
        if (globalSchedule == null) {
            globalSchedule = new GlobalSchedule();
        }
        return globalSchedule;
    }

    // ---- controller logic -------------------------------------------------

    @Override
    public Sampler next() {
        if (running) {
            Sampler sampler = super.next();
            if (sampler == null) {
                // children finished this run
                running = false;
            }
            return sampler;
        }

        if (!isDue()) {
            return skip();
        }

        running = true;
        Sampler sampler = super.next();
        if (sampler == null) {
            // no enabled children
            running = false;
        }
        return sampler;
    }

    private Sampler skip() {
        try {
            return nextIsNull();
        } catch (NextIsNullException e) {
            return null;
        }
    }

    /** Decides whether the children should start now, and updates the schedule if so. */
    private boolean isDue() {
        boolean repeat = isRepeat();
        boolean runImmediate = isRunImmediate();
        if (!repeat && executed) {
            return false;
        }

        long now = System.currentTimeMillis();
        long testStart = JMeterContextService.getTestStartTime();
        long interval = intervalMillis();

        if (isGlobalScope()) {
            return claimGlobal(repeat, runImmediate, now, testStart, interval);
        }

        if (nextDue < 0) {
            nextDue = initialDue(runImmediate, now, interval);
        }
        if (now < nextDue) {
            return false;
        }
        if (repeat) {
            nextDue = advance(nextDue, now, interval);
        } else {
            executed = true;
        }
        return true;
    }

    private boolean claimGlobal(boolean repeat, boolean runImmediate, long now, long testStart,
            long interval) {
        GlobalSchedule schedule = getGlobalSchedule();
        synchronized (schedule) {
            if (schedule.testStart != testStart) {
                // new test run: reset the shared schedule
                schedule.testStart = testStart;
                schedule.nextDue = initialDue(runImmediate, now, interval);
                schedule.fired = false;
            }
            if (!repeat && schedule.fired) {
                return false;
            }
            if (now < schedule.nextDue) {
                return false;
            }
            if (repeat) {
                schedule.nextDue = advance(schedule.nextDue, now, interval);
            } else {
                schedule.fired = true;
            }
            return true;
        }
    }

    /** Next due time: previous due + interval, but never in the past (avoids bursts after a stall). */
    private static long advance(long due, long now, long interval) {
        long next = addMillis(due, interval);
        return next <= now ? addMillis(now, interval) : next;
    }

    private static long initialDue(boolean runImmediate, long now, long interval) {
        return runImmediate ? now : addMillis(now, interval);
    }

    private static long addMillis(long time, long interval) {
        return time > Long.MAX_VALUE - interval ? Long.MAX_VALUE : time + interval;
    }

    private static final class GlobalSchedule {
        private long testStart = Long.MIN_VALUE;
        private long nextDue;
        private boolean fired;
    }

    @Override
    public void triggerEndOfLoop() {
        super.triggerEndOfLoop();
        running = false;
    }
}
