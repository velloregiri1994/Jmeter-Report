import {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  WidthType, AlignmentType, BorderStyle, ShadingType,
  TableLayoutType, VerticalAlign, PageBreak, Header, Footer, ImageRun,
  BookmarkStart, BookmarkEnd, PageNumber, PageNumberSeparator,
  HeadingLevel,
} from "docx";
import { ChartJSNodeCanvas } from "chartjs-node-canvas";
import sizeOf from "image-size";
import JSZip from "jszip";

const BRAND = "4338CA";
const BRAND_DARK = "312E81";
const BRAND_LIGHT = "EEF2FF";
const SUCCESS = "059669";
const DANGER = "DC2626";
const WARNING = "D97706";
const MUTED = "6B7280";
const MUTED_LIGHT = "9CA3AF";
const SURFACE = "F9FAFB";
const BORDER = "E5E7EB";
const TEXT = "111827";
const TEXT_SEC = "374151";
const WHITE = "FFFFFF";

interface ReportData {
  id: number;
  title?: string | null;
  projectName?: string | null;
  featureName?: string | null;
  status?: string | null;
  overallVerdict?: string | null;
  verdictNotes?: string | null;
  objective?: string | null;
  scope?: string | null;
  environmentNotes?: string | null;
  recommendations?: string | null;
  reviewStatus?: string | null;
  finalApprovedAt?: string | null;
  reportSnapshot?: {
    generatedAt?: string;
    sections?: ExecutionSection[];
    consolidatedSla?: SlaData;
    runComparison?: ComparisonData;
    customSections?: CustomSection[];
  } | null;
}

interface ExecutionSection {
  executionId?: number;
  scheduleName?: string;
  scriptName?: string;
  testType?: string;
  environment?: string;
  vusers?: number;
  duration?: number;
  status?: string;
  totalRequests?: number;
  failedRequests?: number;
  avgResponseTime?: number;
  maxResponseTime?: number;
  minResponseTime?: number;
  throughput?: number;
  errorRate?: number;
  p90?: number;
  p95?: number;
  p99?: number;
  transactionDetails?: TransactionDetail[];
}

interface TransactionDetail {
  label?: string;
  count?: number;
  avg?: number;
  p90?: number;
  p95?: number;
  throughput?: number;
  errorCount?: number;
  errorRate?: number;
}

interface SlaData {
  totalRules?: number;
  passed?: number;
  failed?: number;
  violations?: SlaViolation[];
}

interface SlaViolation {
  metric?: string;
  label?: string;
  testType?: string;
  threshold?: number | string;
  actual?: number | string;
}

interface ComparisonData {
  pairComparisons?: PairComparison[];
  unmatchedCurrent?: unknown[];
  unmatchedCompare?: unknown[];
}

interface PairComparison {
  testType?: string;
  scheduleName?: string;
  scriptName?: string;
  currentExecutionId?: number;
  compareExecutionId?: number;
  metrics?: Record<string, { current?: number; compare?: number; changePercent?: number }>;
  transactionComparison?: TxnComparison[];
}

interface TxnComparison {
  label?: string;
  avgCurrent?: number;
  avgCompare?: number;
  avgChange?: number;
  p90Current?: number;
  p90Compare?: number;
  p90Change?: number;
}

interface CustomSection {
  title?: string;
  content?: string;
}

interface ApprovalEntry {
  stepOrder?: number;
  reviewerName?: string | null;
  reviewerEmail?: string | null;
  status?: string;
  comment?: string | null;
  actedAt?: string | null;
}

function fmt(d: string | null | undefined): string {
  if (!d) return "N/A";
  try {
    return new Date(d).toLocaleString("en-US", {
      month: "short", day: "numeric", year: "numeric",
      hour: "numeric", minute: "2-digit",
    });
  } catch { return d || "N/A"; }
}

function num(n: number | null | undefined, dec = 0): string {
  if (n === null || n === undefined || isNaN(n)) return "-";
  return Number(n).toLocaleString("en-US", {
    minimumFractionDigits: dec,
    maximumFractionDigits: dec,
  });
}

function pct(n: number | null | undefined): string {
  if (n === null || n === undefined || isNaN(n)) return "-";
  const abs = Math.abs(n);
  if (abs < 0.5) return "~0%";
  return `${n > 0 ? "+" : ""}${n.toFixed(1)}%`;
}

function pctColor(n: number | null | undefined, higherBad: boolean): string {
  if (n === null || n === undefined || isNaN(n) || Math.abs(n) < 0.5) return MUTED;
  return (higherBad ? n > 0 : n < 0) ? DANGER : SUCCESS;
}

function verdict(v: string | null | undefined): { label: string; color: string } {
  switch (v) {
    case "go": return { label: "GO", color: SUCCESS };
    case "no_go": return { label: "NO GO", color: DANGER };
    case "conditional": return { label: "CONDITIONAL", color: WARNING };
    default: return { label: "PENDING", color: MUTED };
  }
}

function duration(sec: number): string {
  if (!sec || sec <= 0) return "N/A";
  if (sec < 60) return `${sec}s`;
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return s > 0 ? `${m}m ${s}s` : `${m}m`;
}

const thin = { style: BorderStyle.SINGLE, size: 1, color: BORDER };
const none = { style: BorderStyle.NONE, size: 0, color: WHITE };
const thinBorders = { top: thin, bottom: thin, left: thin, right: thin };
const noBorders = { top: none, bottom: none, left: none, right: none };

const PAGE_WIDTH_DXA = 10800;

function dxa(pct: number, base = PAGE_WIDTH_DXA): number {
  return Math.round(pct * base / 100);
}

function tblWidth(pct: number): { size: number; type: typeof WidthType.DXA } {
  return { size: dxa(pct), type: WidthType.DXA };
}

function cellWidth(pct: number, base = PAGE_WIDTH_DXA): { size: number; type: typeof WidthType.DXA } {
  return { size: dxa(pct, base), type: WidthType.DXA };
}

function gap(pts = 100): Paragraph {
  return new Paragraph({ spacing: { before: pts, after: 0 }, children: [] });
}

function makeHeading(bmCounter: { value: number }) {
  return function heading(text: string, n: number): Paragraph {
    const bmNum = ++bmCounter.value;
    const bmName = `heading_${bmNum}`;
    return new Paragraph({
      heading: HeadingLevel.HEADING_1,
      children: [
        new (BookmarkStart as any)(bmName, bmNum),
        new TextRun({ text: `${n}.  `, bold: true, size: 28, color: BRAND, font: "Calibri" }),
        new TextRun({ text, bold: true, size: 28, color: BRAND_DARK, font: "Calibri" }),
        new (BookmarkEnd as any)(bmNum),
      ],
      spacing: { before: 360, after: 160 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: BRAND } },
    });
  };
}

function subheading(text: string, color?: string): Paragraph {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text, bold: true, size: 22, color: color || BRAND, font: "Calibri" })],
    spacing: { before: 200, after: 100 },
  });
}

function body(text: string): Paragraph {
  return new Paragraph({
    children: [new TextRun({ text, size: 20, color: TEXT_SEC, font: "Calibri" })],
    spacing: { before: 60, after: 100 },
  });
}

function parseContentWithImages(text: string): (Paragraph | Table)[] {
  const IMG_RE = /<<IMG:([^|]+)\|data:image\/(png|jpe?g);base64,([^>]+)>>/g;
  const out: (Paragraph | Table)[] = [];
  let lastIdx = 0;
  let match: RegExpExecArray | null;
  while ((match = IMG_RE.exec(text)) !== null) {
    const before = text.slice(lastIdx, match.index).trim();
    if (before) {
      before.split(/\r?\n/).forEach(line => out.push(body(line)));
    }
    const filename = match[1];
    const imgType = match[2].replace('jpeg', 'jpg') as 'png' | 'jpg';
    const b64 = match[3];
    try {
      const buf = Buffer.from(b64, 'base64');
      const dims = getImageDimensions(buf);
      out.push(new Paragraph({
        children: [new ImageRun({
          data: buf,
          transformation: { width: dims.width, height: dims.height },
          type: imgType === 'png' ? 'png' : 'jpg',
        })],
        spacing: { before: 120, after: 40 },
        alignment: AlignmentType.CENTER,
      }));
      out.push(new Paragraph({
        children: [new TextRun({ text: filename, size: 16, color: MUTED, font: "Calibri", italics: true })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 20, after: 100 },
      }));
    } catch {
      out.push(body(`[Image: ${filename}]`));
    }
    lastIdx = IMG_RE.lastIndex;
  }
  const remaining = text.slice(lastIdx).trim();
  if (remaining) {
    remaining.split(/\r?\n/).forEach(line => out.push(body(line)));
  }
  return out;
}

const MAX_IMG_WIDTH = 460;

function getImageDimensions(buf: Buffer): { width: number; height: number } {
  try {
    const info = sizeOf(buf);
    if (info.width && info.height) {
      const w = info.width;
      const h = info.height;
      if (w > MAX_IMG_WIDTH) {
        const scale = MAX_IMG_WIDTH / w;
        return { width: MAX_IMG_WIDTH, height: Math.round(h * scale) };
      }
      return { width: w, height: h };
    }
  } catch {}
  return { width: 460, height: 300 };
}

function cell(text: string, w: number, opts?: {
  bold?: boolean; color?: string; bg?: string; align?: (typeof AlignmentType)[keyof typeof AlignmentType];
  font?: number; borders?: typeof thinBorders; base?: number;
}): TableCell {
  return new TableCell({
    children: [new Paragraph({
      children: [new TextRun({
        text,
        bold: opts?.bold,
        size: opts?.font || 18,
        font: "Calibri",
        color: opts?.color || TEXT,
      })],
      alignment: opts?.align || AlignmentType.LEFT,
      spacing: { before: 60, after: 60 },
    })],
    borders: opts?.borders || thinBorders,
    verticalAlign: VerticalAlign.CENTER,
    width: cellWidth(w, opts?.base),
    ...(opts?.bg ? { shading: { type: ShadingType.SOLID, color: opts.bg } } : {}),
  });
}

function multiLineCell(text: string, w: number, opts?: {
  bold?: boolean; color?: string; bg?: string; font?: number; borders?: typeof thinBorders;
}): TableCell {
  const lines = (text || "").split(/\r?\n/);
  const paragraphs = lines.map((line, i) => new Paragraph({
    children: [new TextRun({
      text: line,
      bold: opts?.bold,
      size: opts?.font || 18,
      font: "Calibri",
      color: opts?.color || TEXT,
    })],
    alignment: AlignmentType.LEFT,
    spacing: { before: i === 0 ? 60 : 30, after: i === lines.length - 1 ? 60 : 30 },
  }));
  return new TableCell({
    children: paragraphs,
    borders: opts?.borders || thinBorders,
    verticalAlign: VerticalAlign.TOP,
    width: cellWidth(w),
    ...(opts?.bg ? { shading: { type: ShadingType.SOLID, color: opts.bg } } : {}),
  });
}

function hdrCell(text: string, w: number, align?: (typeof AlignmentType)[keyof typeof AlignmentType], font?: number): TableCell {
  return cell(text, w, { bold: true, color: WHITE, bg: BRAND, align: align || AlignmentType.CENTER, font: font || 17 });
}

function kpiBlock(value: string, label: string, w: number, valColor?: string): TableCell {
  return new TableCell({
    children: [
      new Paragraph({
        children: [new TextRun({ text: value, bold: true, size: 28, font: "Calibri", color: valColor || BRAND })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 100, after: 30 },
      }),
      new Paragraph({
        children: [new TextRun({ text: label, size: 15, color: MUTED, font: "Calibri" })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 100 },
      }),
    ],
    borders: thinBorders,
    shading: { type: ShadingType.SOLID, color: SURFACE },
    verticalAlign: VerticalAlign.CENTER,
    width: cellWidth(w),
  });
}

function kpiRow(items: { label: string; value: string; color?: string }[]): Table {
  const w = Math.floor(100 / items.length);
  return new Table({
    width: tblWidth(100),
    layout: TableLayoutType.FIXED,
    rows: [new TableRow({
      children: items.map((item, i) =>
        kpiBlock(item.value, item.label, i === items.length - 1 ? 100 - w * (items.length - 1) : w, item.color)
      ),
    })],
  });
}

function banner(text: string, color: string): Table {
  return new Table({
    width: tblWidth(100),
    layout: TableLayoutType.FIXED,
    rows: [new TableRow({
      children: [new TableCell({
        children: [new Paragraph({
          children: [new TextRun({ text, bold: true, size: 24, color: WHITE, font: "Calibri" })],
          alignment: AlignmentType.CENTER,
          spacing: { before: 120, after: 120 },
        })],
        shading: { type: ShadingType.SOLID, color },
        borders: noBorders,
        width: cellWidth(100),
      })],
    })],
  });
}

function sectionBanner(lines: string[]): Table {
  return new Table({
    width: tblWidth(100),
    layout: TableLayoutType.FIXED,
    rows: [new TableRow({
      children: [new TableCell({
        children: lines.map((line, i) => new Paragraph({
          children: [new TextRun({
            text: line,
            bold: i === 0,
            size: i === 0 ? 22 : 17,
            color: WHITE,
            font: "Calibri",
            italics: i > 0,
          })],
          spacing: { before: i === 0 ? 80 : 20, after: i === lines.length - 1 ? 80 : 0 },
        })),
        shading: { type: ShadingType.SOLID, color: BRAND },
        borders: noBorders,
        width: cellWidth(100),
      })],
    })],
  });
}

const CHART_W = 720;
const CHART_H = 380;
const CHART_W_HALF = 560;
const CHART_H_HALF = 340;
const CHART_DOC_W = 520;
const CHART_DOC_H = 274;
const CHART_DOC_W_HALF = 400;
const CHART_DOC_H_HALF = 242;
const chartRenderer = new ChartJSNodeCanvas({ width: CHART_W, height: CHART_H, backgroundColour: "white" });
const chartRendererSmall = new ChartJSNodeCanvas({ width: CHART_W_HALF, height: CHART_H_HALF, backgroundColour: "white" });

const CHART_FONT = "Calibri, Segoe UI, Arial, sans-serif";

async function renderBarChart(
  labels: string[], values: number[], title: string, yLabel: string,
  bgColors: string[], borderColors: string[]
): Promise<Buffer> {
  return await chartRenderer.renderToBuffer({
    type: "bar" as const,
    data: {
      labels,
      datasets: [{
        label: title,
        data: values,
        backgroundColor: bgColors,
        borderColor: borderColors,
        borderWidth: 1,
        borderRadius: 4,
        maxBarThickness: 56,
      }],
    },
    options: {
      responsive: false,
      indexAxis: "x",
      plugins: {
        title: { display: true, text: title, font: { size: 14, weight: "bold" as const, family: CHART_FONT }, color: "#1f2937", padding: { bottom: 14 } },
        legend: { display: false },
      },
      scales: {
        y: {
          beginAtZero: true,
          title: { display: true, text: yLabel, font: { size: 11, family: CHART_FONT }, color: "#6b7280" },
          grid: { color: "#f3f4f6" },
          ticks: { font: { size: 10, family: CHART_FONT }, color: "#6b7280" },
        },
        x: {
          grid: { display: false },
          ticks: { font: { size: 10, family: CHART_FONT }, color: "#374151", maxRotation: 45, minRotation: 0 },
        },
      },
      layout: { padding: { left: 12, right: 20, top: 8, bottom: 8 } },
    },
  });
}

async function renderHorizontalBarChart(
  labels: string[], values: number[], title: string, xLabel: string,
  bgColors: string[], borderColors: string[]
): Promise<Buffer> {
  return await chartRenderer.renderToBuffer({
    type: "bar" as const,
    data: {
      labels,
      datasets: [{
        label: title,
        data: values,
        backgroundColor: bgColors,
        borderColor: borderColors,
        borderWidth: 1,
        borderRadius: 4,
        maxBarThickness: 28,
      }],
    },
    options: {
      responsive: false,
      indexAxis: "y" as const,
      plugins: {
        title: { display: true, text: title, font: { size: 14, weight: "bold" as const, family: CHART_FONT }, color: "#1f2937", padding: { bottom: 14 } },
        legend: { display: false },
      },
      scales: {
        x: {
          beginAtZero: true,
          title: { display: true, text: xLabel, font: { size: 11, family: CHART_FONT }, color: "#6b7280" },
          grid: { color: "#f3f4f6" },
          ticks: { font: { size: 10, family: CHART_FONT }, color: "#6b7280" },
        },
        y: {
          grid: { display: false },
          ticks: { font: { size: 10, family: CHART_FONT }, color: "#374151" },
        },
      },
      layout: { padding: { left: 12, right: 20, top: 8, bottom: 8 } },
    },
  });
}

async function renderLineChart(
  labels: string[],
  datasets: { label: string; data: number[]; color: string; dashed?: boolean }[],
  title: string, yLabel: string
): Promise<Buffer> {
  return await chartRenderer.renderToBuffer({
    type: "line" as const,
    data: {
      labels,
      datasets: datasets.map(ds => ({
        label: ds.label,
        data: ds.data,
        borderColor: ds.color,
        backgroundColor: ds.color.replace("1)", "0.1)"),
        borderWidth: 2,
        pointRadius: labels.length > 20 ? 0 : 3,
        pointHoverRadius: 5,
        fill: datasets.length === 1,
        tension: 0.3,
        borderDash: ds.dashed ? [6, 3] : [],
      })),
    },
    options: {
      responsive: false,
      plugins: {
        title: { display: true, text: title, font: { size: 14, weight: "bold" as const, family: CHART_FONT }, color: "#1f2937", padding: { bottom: 14 } },
        legend: { display: datasets.length > 1, position: "bottom" as const, labels: { font: { size: 11, family: CHART_FONT }, usePointStyle: true, padding: 16 } },
      },
      scales: {
        y: {
          beginAtZero: true,
          title: { display: true, text: yLabel, font: { size: 11, family: CHART_FONT }, color: "#6b7280" },
          grid: { color: "#f3f4f6" },
          ticks: { font: { size: 10, family: CHART_FONT }, color: "#6b7280" },
        },
        x: {
          grid: { color: "#f9fafb" },
          ticks: { font: { size: 9, family: CHART_FONT }, color: "#374151", maxRotation: 45, minRotation: 0, maxTicksLimit: 15 },
        },
      },
      layout: { padding: { left: 12, right: 20, top: 8, bottom: 8 } },
    },
  });
}

async function renderPieChart(
  labels: string[], values: number[], title: string,
  bgColors: string[], borderColors: string[]
): Promise<Buffer> {
  return await chartRendererSmall.renderToBuffer({
    type: "doughnut" as const,
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: bgColors,
        borderColor: borderColors,
        borderWidth: 2,
        hoverOffset: 8,
      }],
    },
    options: {
      responsive: false,
      plugins: {
        title: { display: true, text: title, font: { size: 14, weight: "bold" as const, family: CHART_FONT }, color: "#1f2937", padding: { bottom: 14 } },
        legend: { position: "bottom" as const, labels: { font: { size: 12, family: CHART_FONT }, usePointStyle: true, padding: 16 } },
      },
      layout: { padding: { left: 20, right: 20, top: 8, bottom: 8 } },
    },
  });
}

async function renderGroupedBarChart(
  labels: string[],
  datasets: { label: string; data: number[]; bgColor: string; borderColor: string }[],
  title: string, yLabel: string
): Promise<Buffer> {
  return await chartRenderer.renderToBuffer({
    type: "bar" as const,
    data: {
      labels,
      datasets: datasets.map(ds => ({
        label: ds.label,
        data: ds.data,
        backgroundColor: ds.bgColor,
        borderColor: ds.borderColor,
        borderWidth: 1,
        borderRadius: 4,
        maxBarThickness: 40,
      })),
    },
    options: {
      responsive: false,
      plugins: {
        title: { display: true, text: title, font: { size: 14, weight: "bold" as const, family: CHART_FONT }, color: "#1f2937", padding: { bottom: 14 } },
        legend: { position: "bottom" as const, labels: { font: { size: 11, family: CHART_FONT }, usePointStyle: true, padding: 16 } },
      },
      scales: {
        y: {
          beginAtZero: true,
          title: { display: true, text: yLabel, font: { size: 11, family: CHART_FONT }, color: "#6b7280" },
          grid: { color: "#f3f4f6" },
          ticks: { font: { size: 10, family: CHART_FONT }, color: "#6b7280" },
        },
        x: {
          grid: { display: false },
          ticks: { font: { size: 10, family: CHART_FONT }, color: "#374151", maxRotation: 45, minRotation: 0 },
        },
      },
      layout: { padding: { left: 12, right: 20, top: 8, bottom: 8 } },
    },
  });
}

function chartImage(buf: Buffer, w = CHART_DOC_W, h = CHART_DOC_H): Paragraph {
  return new Paragraph({
    children: [new ImageRun({ data: buf, transformation: { width: w, height: h }, type: "png" })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 100, after: 100 },
  });
}

function chartSeparator(): Paragraph {
  return new Paragraph({
    children: [new TextRun({ text: " ", size: 2, font: "Calibri" })],
    border: { bottom: { style: BorderStyle.SINGLE, size: 1, color: BORDER, space: 1 } },
    spacing: { before: 80, after: 80 },
  });
}

function bulletPoint(text: string): Paragraph {
  return new Paragraph({
    children: [new TextRun({ text: `\u2022  ${text}`, size: 20, color: TEXT_SEC, font: "Calibri" })],
    spacing: { before: 40, after: 40 },
    indent: { left: 360 },
  });
}

function numberedItem(n: number, text: string): Paragraph {
  return new Paragraph({
    children: [
      new TextRun({ text: `${n}.  `, size: 20, color: BRAND, font: "Calibri", bold: true }),
      new TextRun({ text, size: 20, color: TEXT_SEC, font: "Calibri" }),
    ],
    spacing: { before: 40, after: 40 },
    indent: { left: 360 },
  });
}

function sectionIntro(text: string): Paragraph {
  return new Paragraph({
    children: [new TextRun({ text, size: 19, color: MUTED, font: "Calibri", italics: true })],
    spacing: { before: 40, after: 120 },
  });
}

function chartCaption(text: string): Paragraph {
  return new Paragraph({
    children: [new TextRun({ text, size: 16, color: MUTED, font: "Calibri", italics: true })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 120 },
  });
}

function chartPlaceholder(chartName: string): Paragraph {
  return new Paragraph({
    children: [new TextRun({
      text: `[Chart unavailable: ${chartName}]`,
      size: 18, color: MUTED_LIGHT, font: "Calibri", italics: true,
    })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 80, after: 80 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 1, color: BORDER } },
  });
}

function healthColor(score: number): string {
  return score >= 80 ? SUCCESS : score >= 50 ? WARNING : DANGER;
}

function healthLabel(score: number): string {
  if (score >= 90) return "Excellent";
  if (score >= 80) return "Good";
  if (score >= 60) return "Fair";
  if (score >= 40) return "Degraded";
  return "Critical";
}

function executiveDashboardTable(stats: {
  verdict: { label: string; color: string };
  totReqs: number; totFail: number; successRate: number; errRate: number;
  avgRT: number; avgP95: number; avgTPS: number; healthScore: number;
  slaPass: number; slaFail: number; slaTotal: number;
  testCount: number;
}): Table {
  const s = stats;
  return new Table({
    width: tblWidth(100),
    layout: TableLayoutType.FIXED,
    rows: [
      new TableRow({
        children: [
          new TableCell({
            children: [
              new Paragraph({
                children: [new TextRun({ text: "READINESS VERDICT", size: 14, color: WHITE, font: "Calibri", bold: true })],
                alignment: AlignmentType.CENTER,
                spacing: { before: 60, after: 20 },
              }),
              new Paragraph({
                children: [new TextRun({ text: s.verdict.label, size: 44, color: WHITE, font: "Calibri", bold: true })],
                alignment: AlignmentType.CENTER,
                spacing: { before: 10, after: 60 },
              }),
            ],
            shading: { type: ShadingType.SOLID, color: s.verdict.color },
            borders: noBorders,
            width: cellWidth(30),
            verticalAlign: VerticalAlign.CENTER,
          }),
          new TableCell({
            children: [
              new Paragraph({
                children: [
                  new TextRun({ text: "Success Rate  ", size: 16, color: MUTED, font: "Calibri" }),
                  new TextRun({ text: `${s.successRate.toFixed(1)}%`, size: 22, color: s.successRate >= 99 ? SUCCESS : s.successRate >= 95 ? WARNING : DANGER, font: "Calibri", bold: true }),
                  new TextRun({ text: "    Avg RT  ", size: 16, color: MUTED, font: "Calibri" }),
                  new TextRun({ text: `${num(s.avgRT, 0)}ms`, size: 22, color: BRAND, font: "Calibri", bold: true }),
                ],
                spacing: { before: 70, after: 40 },
              }),
              new Paragraph({
                children: [
                  new TextRun({ text: "P95  ", size: 16, color: MUTED, font: "Calibri" }),
                  new TextRun({ text: `${num(s.avgP95, 0)}ms`, size: 22, color: BRAND, font: "Calibri", bold: true }),
                  new TextRun({ text: "    Throughput  ", size: 16, color: MUTED, font: "Calibri" }),
                  new TextRun({ text: `${num(s.avgTPS, 1)} req/s`, size: 22, color: BRAND, font: "Calibri", bold: true }),
                ],
                spacing: { before: 20, after: 40 },
              }),
              new Paragraph({
                children: [
                  new TextRun({ text: "Health  ", size: 16, color: MUTED, font: "Calibri" }),
                  new TextRun({ text: `${s.healthScore}% ${healthLabel(s.healthScore)}`, size: 22, color: healthColor(s.healthScore), font: "Calibri", bold: true }),
                  new TextRun({ text: `    SLA  `, size: 16, color: MUTED, font: "Calibri" }),
                  new TextRun({ text: `${s.slaPass}/${s.slaTotal} passed`, size: 22, color: s.slaFail > 0 ? DANGER : SUCCESS, font: "Calibri", bold: true }),
                ],
                spacing: { before: 20, after: 70 },
              }),
            ],
            borders: { top: thin, bottom: thin, left: none, right: thin },
            width: cellWidth(70),
            verticalAlign: VerticalAlign.CENTER,
          }),
        ],
      }),
    ],
  });
}

function truncLabel(label: string, max = 24): string {
  return label.length > max ? label.substring(0, max - 3) + "..." : label;
}

export async function generateDocxReport(report: ReportData, approvals?: ApprovalEntry[]): Promise<Buffer> {
  const heading = makeHeading({ value: 0 });

  const snap = report.reportSnapshot || {};
  const sections: ExecutionSection[] = snap.sections || [];
  const sla = snap.consolidatedSla;
  const comparison = snap.runComparison;
  const v = verdict(report.overallVerdict);
  const genAt = fmt(snap.generatedAt);

  const totReqs = sections.reduce((s, x) => s + (x.totalRequests || 0), 0);
  const totFail = sections.reduce((s, x) => s + (x.failedRequests || 0), 0);
  const errRate = totReqs > 0 ? (totFail / totReqs * 100) : 0;
  const successRate = totReqs > 0 ? ((totReqs - totFail) / totReqs * 100) : 100;
  const avgRT = sections.length > 0
    ? sections.reduce((s, x) => s + (x.avgResponseTime || 0), 0) / sections.length : 0;
  const avgTPS = sections.length > 0
    ? sections.reduce((s, x) => s + (x.throughput || 0), 0) / sections.length : 0;
  const maxRT = Math.max(...sections.map(x => x.maxResponseTime || 0), 0);
  const minRTs = sections.filter(x => (x.minResponseTime || 0) > 0).map(x => x.minResponseTime!);
  const minRT = minRTs.length > 0 ? Math.min(...minRTs) : 0;

  const avgOf = (key: keyof ExecutionSection) => {
    const vals = sections.filter(x => x[key]).map(x => x[key] as number);
    return vals.length > 0 ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
  };
  const avgP90 = avgOf("p90");
  const avgP95 = avgOf("p95");
  const avgP99 = avgOf("p99");

  let healthScore = 100;
  if (errRate > 5) healthScore -= 40;
  else if (errRate > 1) healthScore -= 20;
  else if (errRate > 0.1) healthScore -= 5;
  const slaViolationCount = sla?.violations?.length || 0;
  healthScore -= Math.min(slaViolationCount * 10, 40);
  healthScore = Math.max(0, Math.min(100, healthScore));

  const allTxn: (TransactionDetail & { testType?: string; executionId?: number })[] = [];
  sections.forEach(s => {
    (s.transactionDetails || []).forEach(t => {
      allTxn.push({ ...t, testType: s.testType, executionId: s.executionId });
    });
  });
  const errTxn = allTxn.filter(t => (t.errorCount || 0) > 0);

  const out: (Paragraph | Table)[] = [];
  let secNum = 1;

  // =========================================================================
  // COVER PAGE
  // =========================================================================
  out.push(gap(80));
  out.push(new Paragraph({
    children: [new TextRun({ text: "CONFIDENTIAL", size: 16, color: MUTED_LIGHT, font: "Calibri", bold: true, allCaps: true })],
    alignment: AlignmentType.RIGHT,
    spacing: { before: 0, after: 0 },
  }));
  out.push(gap(300));
  out.push(new Paragraph({
    children: [new TextRun({ text: "PERFHUB", size: 20, color: BRAND, font: "Calibri", bold: true, allCaps: true })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 20 },
  }));
  out.push(new Paragraph({
    children: [new TextRun({ text: "Performance Test", size: 36, color: BRAND_DARK, font: "Calibri" })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 0 },
  }));
  out.push(new Paragraph({
    children: [new TextRun({ text: "Sign-Off Report", size: 52, bold: true, color: BRAND_DARK, font: "Calibri" })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 80 },
  }));
  out.push(new Paragraph({
    children: [new TextRun({ text: " ", size: 2, font: "Calibri" })],
    border: { bottom: { style: BorderStyle.SINGLE, size: 3, color: BRAND, space: 4 } },
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 0 },
  }));
  out.push(gap(140));
  out.push(new Paragraph({
    children: [new TextRun({ text: report.title || "Performance Test Completion Report", size: 30, color: TEXT, font: "Calibri" })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 40 },
  }));
  if (report.projectName || report.featureName) {
    out.push(new Paragraph({
      children: [new TextRun({ text: [report.projectName, report.featureName].filter(Boolean).join(" — "), size: 22, color: MUTED, font: "Calibri" })],
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: 60 },
    }));
  }
  out.push(gap(120));

  const coverRows: [string, string][] = [
    ["Report ID", `#${report.id}`],
    ["Application", report.projectName || "N/A"],
    ["Release / Feature", report.featureName || "N/A"],
    ["Test Executions", `${sections.length}`],
    ["Status", report.status === "finalized" ? "Finalized" : "Draft"],
    ["Overall Verdict", v.label],
    ["Report Date", genAt],
  ];
  const coverTblDxa = dxa(60);
  out.push(new Table({
    width: tblWidth(60),
    layout: TableLayoutType.FIXED,
    alignment: AlignmentType.CENTER,
    rows: coverRows.map(([k, val]) => new TableRow({
      children: [
        cell(k, 40, { bold: true, color: MUTED, bg: SURFACE, base: coverTblDxa }),
        cell(val, 60, { bold: val === v.label, color: val === v.label ? v.color : undefined, base: coverTblDxa }),
      ],
    })),
  }));
  out.push(gap(120));
  out.push(banner(`Overall Verdict:  ${v.label}`, v.color));

  if (report.verdictNotes) {
    out.push(gap(80));
    out.push(new Paragraph({
      children: [new TextRun({ text: report.verdictNotes, size: 19, color: MUTED, font: "Calibri", italics: true })],
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: 80 },
    }));
  }

  // =========================================================================
  // TABLE OF CONTENTS
  // =========================================================================
  out.push(new Paragraph({ children: [new PageBreak()] }));

  out.push(new Paragraph({
    children: [new TextRun({ text: "Table of Contents", bold: true, size: 28, color: BRAND_DARK, font: "Calibri" })],
    spacing: { before: 200, after: 200 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: BRAND } },
  }));

  const tocEntries: { num: number; title: string; indent?: boolean }[] = [];
  let tocNum = 1;
  tocEntries.push({ num: tocNum++, title: "Executive Summary" });
  tocEntries.push({ num: tocNum++, title: "Key Performance Indicators" });
  if (report.objective || report.scope || report.environmentNotes) {
    tocEntries.push({ num: tocNum++, title: "Test Context & Scope" });
  }
  tocEntries.push({ num: tocNum++, title: "Test Execution Summary" });
  tocEntries.push({ num: tocNum++, title: "Transaction Performance" });
  if (sla && ((sla.violations?.length || 0) > 0 || (sla.totalRules || 0) > 0)) {
    tocEntries.push({ num: tocNum++, title: "SLA Compliance" });
  }
  if (comparison && comparison.pairComparisons && comparison.pairComparisons.length > 0) {
    tocEntries.push({ num: tocNum++, title: "Baseline Comparison" });
  }
  tocEntries.push({ num: tocNum++, title: "Performance Charts" });
  const customSectionsForToc: CustomSection[] = snap.customSections || [];
  customSectionsForToc.forEach(cs => {
    tocEntries.push({ num: tocNum++, title: cs.title || "Additional Section" });
  });
  if (report.recommendations) {
    tocEntries.push({ num: tocNum++, title: "Recommendations" });
  }
  if (approvals && approvals.length > 0) {
    tocEntries.push({ num: tocNum++, title: "Sign-Off Approval" });
  }

  tocEntries.forEach(entry => {
    const dots = " " + ".".repeat(Math.max(2, 80 - entry.title.length - 4));
    out.push(new Paragraph({
      children: [
        new TextRun({ text: `${entry.num}.  `, bold: true, size: 20, color: BRAND, font: "Calibri" }),
        new TextRun({ text: entry.title, size: 20, color: TEXT, font: "Calibri" }),
        new TextRun({ text: dots, size: 20, color: BORDER, font: "Calibri" }),
      ],
      spacing: { before: 80, after: 80 },
    }));
  });
  out.push(gap(60));

  // =========================================================================
  // 1. EXECUTIVE SUMMARY
  // =========================================================================
  out.push(new Paragraph({ children: [new PageBreak()] }));
  out.push(heading("Executive Summary", secNum++));

  out.push(executiveDashboardTable({
    verdict: v,
    totReqs, totFail, successRate, errRate,
    avgRT, avgP95, avgTPS, healthScore,
    slaPass: sla?.passed || 0,
    slaFail: sla?.failed || 0,
    slaTotal: sla?.totalRules || 0,
    testCount: sections.length,
  }));
  out.push(gap(100));

  const summaryLines: string[] = [];
  summaryLines.push(
    `This performance sign-off report consolidates the results of ${sections.length} test execution${sections.length !== 1 ? "s" : ""} ` +
    `comprising ${num(totReqs)} total requests. The system achieved a ${successRate.toFixed(1)}% success rate ` +
    `with an average response time of ${num(avgRT, 0)}ms and sustained throughput of ${num(avgTPS, 1)} requests per second.`
  );
  if (sla && sla.totalRules) {
    const slaPassRate = (sla.passed || 0) + (sla.failed || 0) > 0
      ? Math.round(((sla.passed || 0) / ((sla.passed || 0) + (sla.failed || 0))) * 100) : 100;
    summaryLines.push(
      `SLA compliance stands at ${slaPassRate}% with ${sla.passed || 0} of ${sla.totalRules} rules passing` +
      `${(sla.failed || 0) > 0 ? ` and ${sla.failed} violation${sla.failed !== 1 ? "s" : ""} requiring attention` : ""}.`
    );
  }
  if (errTxn.length > 0) {
    summaryLines.push(
      `${errTxn.length} transaction${errTxn.length !== 1 ? "s" : ""} reported errors during testing, detailed in the Transaction Performance section.`
    );
  }
  let verdictExplanation: string;
  if (v.label === "GO") {
    if (healthScore >= 80 && errRate < 1) {
      verdictExplanation = "Based on the results, the system meets the defined performance criteria and is recommended for production release.";
    } else {
      const concerns: string[] = [];
      if (errRate >= 5) concerns.push(`a ${errRate.toFixed(1)}% error rate`);
      else if (errRate >= 1) concerns.push(`a ${errRate.toFixed(2)}% error rate`);
      if (healthScore < 60) concerns.push(`a health score of ${healthScore}% (${healthLabel(healthScore)})`);
      else if (healthScore < 80) concerns.push(`a health score of ${healthScore}% (${healthLabel(healthScore)})`);
      if (slaViolationCount > 0) concerns.push(`${slaViolationCount} SLA violation${slaViolationCount !== 1 ? "s" : ""}`);
      verdictExplanation = concerns.length > 0
        ? `The overall verdict is GO; however, the results show ${concerns.join(", ")}. These observations should be reviewed to confirm readiness for production release.`
        : "Based on the results, the system meets the defined performance criteria and is recommended for production release.";
    }
  } else if (v.label === "NO GO") {
    const issues: string[] = [];
    if (errRate >= 1) issues.push(`${errRate.toFixed(2)}% error rate`);
    if (healthScore < 60) issues.push(`health score of ${healthScore}% (${healthLabel(healthScore)})`);
    if (slaViolationCount > 0) issues.push(`${slaViolationCount} SLA violation${slaViolationCount !== 1 ? "s" : ""}`);
    verdictExplanation = issues.length > 0
      ? `The test results indicate performance issues — including ${issues.join(", ")} — that must be resolved before proceeding to production.`
      : "The test results indicate performance issues that must be resolved before proceeding to production.";
  } else if (v.label === "CONDITIONAL") {
    verdictExplanation = "The system partially meets performance criteria. Specific conditions must be addressed before final production approval.";
    if (healthScore < 80 || errRate >= 1 || slaViolationCount > 0) {
      const notes: string[] = [];
      if (errRate >= 1) notes.push(`error rate of ${errRate.toFixed(2)}%`);
      if (healthScore < 80) notes.push(`health score of ${healthScore}% (${healthLabel(healthScore)})`);
      if (slaViolationCount > 0) notes.push(`${slaViolationCount} SLA violation${slaViolationCount !== 1 ? "s" : ""}`);
      verdictExplanation += ` Key areas of concern: ${notes.join(", ")}.`;
    }
  } else {
    verdictExplanation = "The verdict is pending review and stakeholder sign-off.";
  }
  summaryLines.push(verdictExplanation);
  summaryLines.forEach(line => out.push(body(line)));

  // =========================================================================
  // 2. KPI DASHBOARD
  // =========================================================================
  out.push(heading("Key Performance Indicators", secNum++));
  out.push(sectionIntro("Consolidated metrics across all test executions — critical values are highlighted in red, warnings in amber."));
  out.push(kpiRow([
    { label: "Total Requests", value: num(totReqs) },
    { label: "Failed Requests", value: num(totFail), color: totFail > 0 ? DANGER : SUCCESS },
    { label: "Success Rate", value: `${successRate.toFixed(1)}%`, color: successRate >= 99 ? SUCCESS : successRate >= 95 ? WARNING : DANGER },
    { label: "Error Rate", value: `${errRate.toFixed(2)}%`, color: errRate > 1 ? DANGER : errRate > 0 ? WARNING : SUCCESS },
  ]));
  out.push(gap(60));
  out.push(kpiRow([
    { label: "Avg Response Time", value: `${num(avgRT, 0)}ms` },
    { label: "P90", value: `${num(avgP90, 0)}ms` },
    { label: "P95", value: `${num(avgP95, 0)}ms` },
    { label: "P99", value: `${num(avgP99, 0)}ms` },
  ]));
  out.push(gap(60));
  out.push(kpiRow([
    { label: "Throughput", value: `${num(avgTPS, 1)} req/s` },
    { label: "Max Response Time", value: `${num(maxRT, 0)}ms`, color: DANGER },
    { label: "Min Response Time", value: minRT > 0 ? `${num(minRT, 0)}ms` : "-", color: SUCCESS },
    { label: "Health Score", value: `${healthScore}% ${healthLabel(healthScore)}`, color: healthColor(healthScore) },
  ]));
  out.push(gap(60));
  out.push(kpiRow([
    { label: "SLA Rules", value: sla ? `${sla.passed}/${sla.totalRules} passed` : "N/A" },
    { label: "SLA Violations", value: `${slaViolationCount}`, color: slaViolationCount > 0 ? DANGER : SUCCESS },
    { label: "Review Status", value: report.reviewStatus ? report.reviewStatus.replace(/_/g, ' ').replace(/\b\w/g, (c: string) => c.toUpperCase()) : "N/A" },
    { label: "Report Status", value: report.status === "finalized" ? "Finalized" : "Draft" },
  ]));

  // =========================================================================
  // 3. TEST CONTEXT & SCOPE
  // =========================================================================
  if (report.objective || report.scope || report.environmentNotes) {
    out.push(heading("Test Context & Scope", secNum++));
    const ctxRows: [string, string][] = [];
    if (report.objective) ctxRows.push(["Test Objective", report.objective]);
    if (report.scope) ctxRows.push(["Scope", report.scope]);
    if (report.environmentNotes) ctxRows.push(["Environment Notes", report.environmentNotes]);

    ctxRows.forEach(([label, content]) => {
      const contentHasImg = /<<IMG:[^|]+\|data:image\//.test(content);
      out.push(new Table({
        width: tblWidth(100),
        layout: TableLayoutType.FIXED,
        rows: [
          new TableRow({
            children: [
              cell(label, 100, { bold: true, color: WHITE, bg: BRAND, font: 17 }),
            ],
          }),
          ...(!contentHasImg ? [new TableRow({
            children: [
              multiLineCell(content, 100),
            ],
          })] : []),
        ],
      }));
      if (contentHasImg) {
        parseContentWithImages(content).forEach(p => out.push(p));
      }
      out.push(gap(80));
    });
  }

  // =========================================================================
  // 4. TEST EXECUTION SUMMARY
  // =========================================================================
  out.push(heading("Test Execution Summary", secNum++));
  out.push(sectionIntro(`Overview of ${sections.length} test execution${sections.length !== 1 ? "s" : ""} included in this report.`));

  for (let sIdx = 0; sIdx < sections.length; sIdx++) {
    const s = sections[sIdx];
    if (sIdx > 0) out.push(gap(200));

    const testLabel = `${s.testType || "Test"}  |  ${s.scheduleName || s.scriptName || "N/A"}  [${(s.status || "N/A").toUpperCase()}]`;
    out.push(sectionBanner([testLabel]));

    out.push(new Table({
      width: tblWidth(100),
      layout: TableLayoutType.FIXED,
      rows: [
        new TableRow({
          children: [
            cell("Execution ID", 15, { bold: true, color: MUTED, bg: SURFACE }),
            cell(s.executionId ? `#${s.executionId}` : "N/A", 35),
            cell("Environment", 15, { bold: true, color: MUTED, bg: SURFACE }),
            cell(s.environment || "N/A", 35),
          ],
        }),
        new TableRow({
          children: [
            cell("Script", 15, { bold: true, color: MUTED, bg: SURFACE }),
            cell(s.scriptName || "N/A", 35),
            cell("Test Type", 15, { bold: true, color: MUTED, bg: SURFACE }),
            cell(s.testType || "N/A", 35),
          ],
        }),
        new TableRow({
          children: [
            cell("Virtual Users", 15, { bold: true, color: MUTED, bg: SURFACE }),
            cell(s.vusers ? `${s.vusers}` : "-", 35),
            cell("Duration", 15, { bold: true, color: MUTED, bg: SURFACE }),
            cell(duration(s.duration || 0), 35),
          ],
        }),
      ],
    }));
    out.push(gap(60));

    out.push(kpiRow([
      { label: "Total Requests", value: num(s.totalRequests) },
      { label: "Failed", value: num(s.failedRequests), color: (s.failedRequests || 0) > 0 ? DANGER : SUCCESS },
      { label: "Avg RT", value: `${num(s.avgResponseTime, 0)}ms` },
      { label: "Throughput", value: `${num(s.throughput, 1)} TPS` },
      { label: "Error Rate", value: `${(s.errorRate || 0).toFixed(2)}%`, color: (s.errorRate || 0) > 1 ? DANGER : (s.errorRate || 0) > 0 ? WARNING : SUCCESS },
    ]));
  }

  // =========================================================================
  // 5. TRANSACTION PERFORMANCE TABLE
  // =========================================================================
  out.push(heading("Transaction Performance", secNum++));
  out.push(sectionIntro("Detailed performance metrics for each transaction across all test executions."));

  for (let sIdx = 0; sIdx < sections.length; sIdx++) {
    const s = sections[sIdx];
    if (!s.transactionDetails || s.transactionDetails.length === 0) continue;

    if (sIdx > 0) out.push(gap(160));
    out.push(subheading(`${s.scheduleName || s.scriptName || "Execution"} — Transactions`));

    out.push(new Table({
      width: tblWidth(100),
      layout: TableLayoutType.FIXED,
      rows: [
        new TableRow({
          children: [
            hdrCell("Transaction", 24, AlignmentType.LEFT, 15),
            hdrCell("Count", 10, AlignmentType.RIGHT, 15),
            hdrCell("Avg (ms)", 11, AlignmentType.RIGHT, 15),
            hdrCell("P90 (ms)", 11, AlignmentType.RIGHT, 15),
            hdrCell("P95 (ms)", 11, AlignmentType.RIGHT, 15),
            hdrCell("TPS", 10, AlignmentType.RIGHT, 15),
            hdrCell("Errors", 11, AlignmentType.RIGHT, 15),
            hdrCell("Err %", 12, AlignmentType.RIGHT, 15),
          ],
        }),
        ...s.transactionDetails.map((t, tIdx) => {
          const te = t.errorRate !== undefined
            ? (typeof t.errorRate === "number" && t.errorRate <= 1 ? t.errorRate * 100 : t.errorRate) : 0;
          const bg = tIdx % 2 !== 0 ? SURFACE : undefined;
          return new TableRow({
            children: [
              cell(t.label || "-", 24, { bold: true, bg, font: 15 }),
              cell(num(t.count), 10, { align: AlignmentType.RIGHT, bg, font: 15 }),
              cell(num(t.avg, 0), 11, { align: AlignmentType.RIGHT, bg, font: 15 }),
              cell(num(t.p90, 0), 11, { align: AlignmentType.RIGHT, bg, font: 15 }),
              cell(num(t.p95, 0), 11, { align: AlignmentType.RIGHT, bg, font: 15 }),
              cell(num(t.throughput, 2), 10, { align: AlignmentType.RIGHT, bg, font: 15 }),
              cell(num(t.errorCount), 11, { align: AlignmentType.RIGHT, color: (t.errorCount || 0) > 0 ? DANGER : TEXT, bg, font: 15 }),
              cell(`${(te as number).toFixed(1)}%`, 12, { align: AlignmentType.RIGHT, color: (te as number) > 0 ? DANGER : SUCCESS, bg, font: 15 }),
            ],
          });
        }),
      ],
    }));
  }

  // Transaction error summary
  out.push(gap(160));
  out.push(subheading("Transactions with Errors", DANGER));
  if (errTxn.length > 0) {
    out.push(body(`${errTxn.length} of ${allTxn.length} transactions encountered errors during testing:`));
    out.push(gap(40));
    out.push(new Table({
      width: tblWidth(100),
      layout: TableLayoutType.FIXED,
      rows: [
        new TableRow({
          children: [
            hdrCell("Transaction", 35),
            hdrCell("Test Type", 25),
            hdrCell("Errors", 20, AlignmentType.RIGHT),
            hdrCell("Error %", 20, AlignmentType.RIGHT),
          ],
        }),
        ...errTxn.map((t, i) => {
          const te = t.errorRate !== undefined
            ? (typeof t.errorRate === "number" && t.errorRate <= 1 ? t.errorRate * 100 : t.errorRate) : 0;
          const bg = i % 2 !== 0 ? SURFACE : undefined;
          return new TableRow({
            children: [
              cell(t.label || "-", 35, { bold: true, bg }),
              cell(t.testType || "-", 25, { bg }),
              cell(num(t.errorCount), 20, { align: AlignmentType.RIGHT, color: DANGER, bold: true, bg }),
              cell(`${(te as number).toFixed(1)}%`, 20, { align: AlignmentType.RIGHT, color: DANGER, bg }),
            ],
          });
        }),
      ],
    }));
  } else {
    out.push(banner("No transaction errors detected", SUCCESS));
  }

  // =========================================================================
  // 6. SLA COMPLIANCE
  // =========================================================================
  if (sla && ((sla.violations?.length || 0) > 0 || (sla.totalRules || 0) > 0)) {
    out.push(heading("SLA Compliance", secNum++));

    out.push(kpiRow([
      { label: "Total Rules", value: `${sla.totalRules || 0}` },
      { label: "Passed", value: `${sla.passed || 0}`, color: SUCCESS },
      { label: "Failed", value: `${sla.failed || 0}`, color: (sla.failed || 0) > 0 ? DANGER : SUCCESS },
      { label: "Pass Rate", value: ((sla.passed || 0) + (sla.failed || 0)) > 0 ? `${Math.round(((sla.passed || 0) / ((sla.passed || 0) + (sla.failed || 0))) * 100)}%` : "N/A", color: (sla.failed || 0) === 0 ? SUCCESS : DANGER },
    ]));

    if (sla.violations && sla.violations.length > 0) {
      out.push(gap(100));
      out.push(subheading("SLA Violations", DANGER));

      out.push(new Table({
        width: tblWidth(100),
        layout: TableLayoutType.FIXED,
        rows: [
          new TableRow({
            children: [
              hdrCell("Metric", 25),
              hdrCell("Test Type", 20),
              hdrCell("Threshold", 18, AlignmentType.RIGHT),
              hdrCell("Actual", 18, AlignmentType.RIGHT),
              hdrCell("Status", 19, AlignmentType.CENTER),
            ],
          }),
          ...sla.violations.map((viol, i) => {
            const bg = i % 2 !== 0 ? SURFACE : undefined;
            return new TableRow({
              children: [
                cell(viol.label ? `${viol.metric} (${viol.label})` : viol.metric || "-", 25, { bold: true, bg }),
                cell(viol.testType || "-", 20, { bg }),
                cell(typeof viol.threshold === 'number' ? num(viol.threshold, 2) : `${viol.threshold}`, 18, { align: AlignmentType.RIGHT, bg }),
                cell(typeof viol.actual === 'number' ? num(viol.actual, 2) : `${viol.actual}`, 18, { align: AlignmentType.RIGHT, color: DANGER, bold: true, bg }),
                cell("FAIL", 19, { align: AlignmentType.CENTER, color: WHITE, bg: DANGER, bold: true }),
              ],
            });
          }),
        ],
      }));
    } else {
      out.push(gap(60));
      out.push(banner("All SLA rules passed", SUCCESS));
    }
  }

  // =========================================================================
  // 7. BASELINE COMPARISON (TABLE)
  // =========================================================================
  if (comparison && comparison.pairComparisons && comparison.pairComparisons.length > 0) {
    out.push(heading("Baseline Comparison", secNum++));

    out.push(kpiRow([
      { label: "Matched Pairs", value: `${comparison.pairComparisons.length}` },
      { label: "Unmatched Current", value: `${comparison.unmatchedCurrent?.length || 0}`, color: WARNING },
      { label: "Unmatched Compare", value: `${comparison.unmatchedCompare?.length || 0}`, color: WARNING },
    ]));

    comparison.pairComparisons.forEach(pair => {
      out.push(gap(180));

      const title = `${pair.testType || "Test"} — ${pair.scheduleName || pair.scriptName || "N/A"}`;
      const sub = `Current #${pair.currentExecutionId || "?"} vs Compare #${pair.compareExecutionId || "?"}`;
      out.push(sectionBanner([title, sub]));

      const m = pair.metrics || {};
      const rows: { label: string; cur: string; cmp: string; chg: number | null; bad: boolean }[] = [
        { label: "Avg Response Time", cur: `${num(m.avgResponseTime?.current, 0)}ms`, cmp: `${num(m.avgResponseTime?.compare, 0)}ms`, chg: m.avgResponseTime?.changePercent ?? null, bad: true },
        { label: "Throughput (TPS)", cur: num(m.throughput?.current, 1), cmp: num(m.throughput?.compare, 1), chg: m.throughput?.changePercent ?? null, bad: false },
        { label: "Error Rate", cur: `${(m.errorRate?.current || 0).toFixed(2)}%`, cmp: `${(m.errorRate?.compare || 0).toFixed(2)}%`, chg: m.errorRate?.changePercent ?? null, bad: true },
      ];
      if (m.p90) rows.push({ label: "P90", cur: `${num(m.p90.current, 0)}ms`, cmp: `${num(m.p90.compare, 0)}ms`, chg: m.p90.changePercent ?? null, bad: true });
      if (m.p95) rows.push({ label: "P95", cur: `${num(m.p95.current, 0)}ms`, cmp: `${num(m.p95.compare, 0)}ms`, chg: m.p95.changePercent ?? null, bad: true });
      rows.push({ label: "Total Requests", cur: num(m.totalRequests?.current), cmp: num(m.totalRequests?.compare), chg: null, bad: false });

      out.push(new Table({
        width: tblWidth(100),
        layout: TableLayoutType.FIXED,
        rows: [
          new TableRow({
            children: [
              hdrCell("Metric", 34),
              hdrCell("Current", 22, AlignmentType.RIGHT),
              hdrCell("Baseline", 22, AlignmentType.RIGHT),
              hdrCell("Change", 22, AlignmentType.RIGHT),
            ],
          }),
          ...rows.map((r, ri) => {
            const bg = ri % 2 !== 0 ? SURFACE : undefined;
            return new TableRow({
              children: [
                cell(r.label, 34, { bold: true, bg }),
                cell(r.cur, 22, { align: AlignmentType.RIGHT, bg }),
                cell(r.cmp, 22, { align: AlignmentType.RIGHT, bg }),
                cell(pct(r.chg), 22, { align: AlignmentType.RIGHT, bold: true, color: pctColor(r.chg, r.bad), bg }),
              ],
            });
          }),
        ],
      }));

      if (pair.transactionComparison && pair.transactionComparison.length > 0) {
        out.push(gap(100));
        out.push(subheading("Transaction-Level Comparison"));

        out.push(new Table({
          width: tblWidth(100),
          layout: TableLayoutType.FIXED,
          rows: [
            new TableRow({
              children: [
                hdrCell("Transaction", 22, AlignmentType.LEFT, 15),
                hdrCell("Avg Curr", 13, AlignmentType.RIGHT, 15),
                hdrCell("Avg Base", 13, AlignmentType.RIGHT, 15),
                hdrCell("Avg Chg", 13, AlignmentType.RIGHT, 15),
                hdrCell("P90 Curr", 13, AlignmentType.RIGHT, 15),
                hdrCell("P90 Base", 13, AlignmentType.RIGHT, 15),
                hdrCell("P90 Chg", 13, AlignmentType.RIGHT, 15),
              ],
            }),
            ...pair.transactionComparison.map((tc, tcIdx) => {
              const bg = tcIdx % 2 !== 0 ? SURFACE : undefined;
              return new TableRow({
                children: [
                  cell(tc.label || "-", 22, { bold: true, bg, font: 15 }),
                  cell(num(tc.avgCurrent, 0), 13, { align: AlignmentType.RIGHT, bg, font: 15 }),
                  cell(num(tc.avgCompare, 0), 13, { align: AlignmentType.RIGHT, bg, font: 15 }),
                  cell(pct(tc.avgChange), 13, { align: AlignmentType.RIGHT, bold: true, color: pctColor(tc.avgChange, true), bg, font: 15 }),
                  cell(num(tc.p90Current, 0), 13, { align: AlignmentType.RIGHT, bg, font: 15 }),
                  cell(num(tc.p90Compare, 0), 13, { align: AlignmentType.RIGHT, bg, font: 15 }),
                  cell(pct(tc.p90Change), 13, { align: AlignmentType.RIGHT, bold: true, color: pctColor(tc.p90Change, true), bg, font: 15 }),
                ],
              });
            }),
          ],
        }));
      }
    });
  }

  // =========================================================================
  // 8. PERFORMANCE CHARTS
  // =========================================================================
  out.push(new Paragraph({ children: [new PageBreak()] }));
  out.push(heading("Performance Charts", secNum++));
  out.push(sectionIntro("Visual representation of key performance metrics across all test executions."));
  out.push(gap(40));

  // --- Chart 1: Response Time Distribution (Avg, P90, P95, P99) ---
  try {
    const rtLabels = ["Avg Response Time", "P90", "P95", "P99"];
    const rtValues = [avgRT, avgP90, avgP95, avgP99];
    const rtColors = [
      "rgba(67, 56, 202, 0.85)",
      "rgba(99, 102, 241, 0.85)",
      "rgba(139, 92, 246, 0.85)",
      "rgba(168, 85, 247, 0.85)",
    ];
    const rtBorders = rtColors.map(c => c.replace("0.85)", "1)"));
    const rtBuf = await renderBarChart(rtLabels, rtValues, "Response Time Distribution (ms)", "Response Time (ms)", rtColors, rtBorders);
    out.push(subheading("Response Time Distribution"));
    out.push(chartImage(rtBuf));
    out.push(chartCaption("Consolidated response time percentiles across all test executions"));
    out.push(chartSeparator());
  } catch (e) {
    console.error("[docx-chart] RT Distribution:", e);
    out.push(chartPlaceholder("Response Time Distribution"));
  }

  // --- Chart 2: Throughput Trend (per-execution) ---
  if (sections.length > 1) {
    try {
      const tpLabels = sections.map((s, i) => truncLabel(s.scheduleName || s.scriptName || `Exec ${i + 1}`, 18));
      const tpValues = sections.map(s => s.throughput || 0);
      const tpBuf = await renderLineChart(
        tpLabels,
        [{ label: "Throughput (req/s)", data: tpValues, color: "rgba(6, 182, 212, 1)" }],
        "Throughput Across Executions", "Requests/sec"
      );
      out.push(subheading("Throughput Trend"));
      out.push(chartImage(tpBuf));
      out.push(chartCaption("Throughput comparison across test executions"));
      out.push(chartSeparator());
    } catch (e) {
      console.error("[docx-chart] Throughput Trend:", e);
      out.push(chartPlaceholder("Throughput Trend"));
    }
  }

  // --- Chart 3: Response Time Trend (Avg + P95 per-execution) ---
  if (sections.length > 1) {
    try {
      const rtTrendLabels = sections.map((s, i) => truncLabel(s.scheduleName || s.scriptName || `Exec ${i + 1}`, 18));
      const rtTrendBuf = await renderLineChart(
        rtTrendLabels,
        [
          { label: "Avg Response Time (ms)", data: sections.map(s => s.avgResponseTime || 0), color: "rgba(67, 56, 202, 1)" },
          { label: "P95 Response Time (ms)", data: sections.map(s => s.p95 || 0), color: "rgba(234, 88, 12, 1)", dashed: true },
        ],
        "Response Time Trend", "Response Time (ms)"
      );
      out.push(subheading("Response Time Trend"));
      out.push(chartImage(rtTrendBuf));
      out.push(chartCaption("Average and P95 response time comparison across test executions"));
      out.push(chartSeparator());
    } catch (e) {
      console.error("[docx-chart] RT Trend:", e);
      out.push(chartPlaceholder("Response Time Trend"));
    }
  }

  // --- Chart 4: Error Rate (Success vs Failed doughnut) ---
  if (totReqs > 0) {
    try {
      const successReqs = totReqs - totFail;
      const errBuf = await renderPieChart(
        [`Successful (${num(successReqs)})`, `Failed (${num(totFail)})`],
        [successReqs, totFail],
        "Request Success vs Failure",
        ["rgba(5, 150, 105, 0.85)", "rgba(220, 38, 38, 0.85)"],
        ["rgba(5, 150, 105, 1)", "rgba(220, 38, 38, 1)"]
      );
      out.push(subheading("Error Rate Distribution"));
      out.push(chartImage(errBuf, CHART_DOC_W_HALF, CHART_DOC_H_HALF));
      out.push(chartCaption(`${successRate.toFixed(1)}% success rate — ${num(totReqs)} total requests`));
      out.push(chartSeparator());
    } catch (e) {
      console.error("[docx-chart] Error Rate:", e);
      out.push(chartPlaceholder("Error Rate Distribution"));
    }
  }

  // --- Chart 5: Transaction Response Time (horizontal bar) ---
  if (allTxn.length > 0) {
    try {
      const txnSorted = [...allTxn].sort((a, b) => (b.avg || 0) - (a.avg || 0)).slice(0, 15);
      const txnLabels = txnSorted.map(t => truncLabel(t.label || "?", 28));
      const txnValues = txnSorted.map(t => t.avg || 0);
      const txnColors = txnValues.map(v => v > avgRT * 2 ? "rgba(220, 38, 38, 0.8)" : v > avgRT ? "rgba(217, 119, 6, 0.8)" : "rgba(67, 56, 202, 0.8)");
      const txnBorders = txnColors.map(c => c.replace("0.8)", "1)"));
      const txnBuf = await renderHorizontalBarChart(
        txnLabels, txnValues,
        "Transaction Avg Response Time (ms)", "Response Time (ms)",
        txnColors, txnBorders
      );
      out.push(subheading("Transaction Response Times"));
      out.push(chartImage(txnBuf));
      out.push(chartCaption("Average response time per transaction — red indicates >2x overall average, amber >1x"));
      out.push(chartSeparator());
    } catch (e) {
      console.error("[docx-chart] Txn RT:", e);
      out.push(chartPlaceholder("Transaction Response Times"));
    }
  }

  // --- Chart 6: Transaction Error Distribution ---
  if (errTxn.length > 0) {
    try {
      const errSorted = [...errTxn].sort((a, b) => (b.errorCount || 0) - (a.errorCount || 0)).slice(0, 15);
      const errLabels = errSorted.map(t => truncLabel(t.label || "?", 28));
      const errValues = errSorted.map(t => t.errorCount || 0);
      const errColors = errValues.map(() => "rgba(220, 38, 38, 0.8)");
      const errBorders = errValues.map(() => "rgba(220, 38, 38, 1)");
      const errBuf = await renderBarChart(
        errLabels, errValues,
        "Transaction Error Distribution", "Error Count",
        errColors, errBorders
      );
      out.push(subheading("Transaction Error Distribution"));
      out.push(chartImage(errBuf));
      out.push(chartCaption(`${errTxn.length} transaction${errTxn.length !== 1 ? "s" : ""} with errors out of ${allTxn.length} total`));
      out.push(chartSeparator());
    } catch (e) {
      console.error("[docx-chart] Txn Errors:", e);
      out.push(chartPlaceholder("Transaction Error Distribution"));
    }
  }

  // --- Chart 7: Baseline Comparison (grouped bar) ---
  if (comparison && comparison.pairComparisons && comparison.pairComparisons.length > 0) {
    try {
      const metrics = ["avgResponseTime", "throughput", "p95", "errorRate"];
      const metricLabels = ["Avg RT (ms)", "Throughput", "P95 (ms)", "Error Rate (%)"];
      const currentVals: number[] = [];
      const baselineVals: number[] = [];
      for (const mk of metrics) {
        const pairs = comparison.pairComparisons.filter(p => p.metrics?.[mk]);
        if (pairs.length > 0) {
          currentVals.push(pairs.reduce((s, p) => s + (p.metrics?.[mk]?.current || 0), 0) / pairs.length);
          baselineVals.push(pairs.reduce((s, p) => s + (p.metrics?.[mk]?.compare || 0), 0) / pairs.length);
        } else {
          currentVals.push(0);
          baselineVals.push(0);
        }
      }
      const baselineBuf = await renderGroupedBarChart(
        metricLabels,
        [
          { label: "Current", data: currentVals, bgColor: "rgba(67, 56, 202, 0.8)", borderColor: "rgba(67, 56, 202, 1)" },
          { label: "Baseline", data: baselineVals, bgColor: "rgba(156, 163, 175, 0.6)", borderColor: "rgba(156, 163, 175, 1)" },
        ],
        "Current vs Baseline Performance", "Value"
      );
      out.push(subheading("Baseline Comparison"));
      out.push(chartImage(baselineBuf));
      out.push(chartCaption("Side-by-side comparison of current test results against baseline metrics"));
    } catch (e) {
      console.error("[docx-chart] Baseline:", e);
      out.push(chartPlaceholder("Baseline Comparison"));
    }
  }

  // =========================================================================
  // 9. CUSTOM SECTIONS (after charts)
  // =========================================================================
  const customSections: CustomSection[] = snap.customSections || [];
  if (customSections.length > 0) {
    customSections.forEach(cs => {
      out.push(gap(200));
      out.push(heading(cs.title || "Additional Section", secNum++));
      const contentHasImg = /<<IMG:[^|]+\|data:image\//.test(cs.content || '');
      if (contentHasImg) {
        parseContentWithImages(cs.content || '').forEach(p => out.push(p));
      } else {
        const lines = (cs.content || '').split(/\r?\n/);
        lines.forEach(line => out.push(body(line)));
      }
    });
  }

  // =========================================================================
  // 10. RECOMMENDATIONS
  // =========================================================================
  if (report.recommendations) {
    out.push(heading("Recommendations", secNum++));
    out.push(sectionIntro("Action items and suggestions based on test results."));
    const recLines = report.recommendations.split(/\r?\n/);
    let numberedCounter = 0;
    recLines.forEach(line => {
      const trimmed = line.trim();
      if (!trimmed) {
        out.push(gap(40));
      } else if (/^[-•]\s+/.test(trimmed)) {
        out.push(bulletPoint(trimmed.replace(/^[-•]\s+/, '')));
      } else if (/^\d+[.)]\s+/.test(trimmed)) {
        numberedCounter++;
        out.push(numberedItem(numberedCounter, trimmed.replace(/^\d+[.)]\s+/, '')));
      } else {
        numberedCounter = 0;
        out.push(body(trimmed));
      }
    });
  }

  // =========================================================================
  // 11. SIGN-OFF APPROVAL
  // =========================================================================
  if (approvals && approvals.length > 0) {
    out.push(new Paragraph({ children: [new PageBreak()] }));
    out.push(heading("Sign-Off Approval", secNum++));

    const reviewLabel = report.reviewStatus
      ? report.reviewStatus.replace(/_/g, ' ').replace(/\b\w/g, (c: string) => c.toUpperCase())
      : "Not Started";
    const reviewColor = report.reviewStatus === "approved" ? SUCCESS
      : report.reviewStatus === "rejected" ? DANGER
      : report.reviewStatus === "changes_requested" ? WARNING
      : MUTED;
    out.push(banner(`Review Status:  ${reviewLabel}`, reviewColor));
    out.push(gap(80));

    out.push(new Table({
      width: tblWidth(100),
      layout: TableLayoutType.FIXED,
      rows: [
        new TableRow({
          children: [
            hdrCell("Step", 10, AlignmentType.CENTER),
            hdrCell("Reviewer", 30),
            hdrCell("Status", 20, AlignmentType.CENTER),
            hdrCell("Comment", 25),
            hdrCell("Date", 15),
          ],
        }),
        ...approvals.map((a, i) => {
          const bg = i % 2 !== 0 ? SURFACE : undefined;
          const statusLabel = a.status === "approved" ? "Approved" : a.status === "rejected" ? "Rejected" : a.status === "changes_requested" ? "Changes Requested" : "Pending";
          const statusColor = a.status === "approved" ? SUCCESS : a.status === "rejected" ? DANGER : a.status === "changes_requested" ? WARNING : MUTED;
          return new TableRow({
            children: [
              cell(`${a.stepOrder}`, 10, { align: AlignmentType.CENTER, bg }),
              cell(a.reviewerName || a.reviewerEmail || "-", 30, { bold: true, bg }),
              cell(statusLabel, 20, { align: AlignmentType.CENTER, color: statusColor, bold: true, bg }),
              cell(a.comment || "-", 25, { bg, color: MUTED }),
              cell(a.actedAt ? fmt(a.actedAt) : "-", 15, { bg, color: MUTED }),
            ],
          });
        }),
      ],
    }));

    if (report.finalApprovedAt) {
      out.push(gap(60));
      out.push(body(`Final approval granted on ${fmt(report.finalApprovedAt)}.`));
    }

    out.push(gap(120));
    out.push(new Table({
      width: tblWidth(100),
      layout: TableLayoutType.FIXED,
      rows: [
        new TableRow({
          children: [
            cell("Signature", 20, { bold: true, color: MUTED, bg: SURFACE }),
            cell("", 30, { borders: { ...thinBorders, bottom: { style: BorderStyle.SINGLE, size: 1, color: TEXT } } }),
            cell("Date", 15, { bold: true, color: MUTED, bg: SURFACE, align: AlignmentType.CENTER }),
            cell("", 35, { borders: { ...thinBorders, bottom: { style: BorderStyle.SINGLE, size: 1, color: TEXT } } }),
          ],
        }),
        new TableRow({
          children: [
            cell("Name", 20, { bold: true, color: MUTED, bg: SURFACE }),
            cell("", 30),
            cell("Role", 15, { bold: true, color: MUTED, bg: SURFACE, align: AlignmentType.CENTER }),
            cell("", 35),
          ],
        }),
      ],
    }));
  }

  // =========================================================================
  // FOOTER DISCLAIMER
  // =========================================================================
  out.push(gap(300));
  out.push(new Paragraph({
    children: [new TextRun({
      text: "This report was auto-generated by PerfHub. Data reflects test conditions at the time of execution and may not represent production behavior.",
      size: 15, color: MUTED_LIGHT, font: "Calibri", italics: true,
    })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 60, after: 60 },
    border: { top: { style: BorderStyle.SINGLE, size: 1, color: BORDER } },
  }));

  // =========================================================================
  // DOCUMENT ASSEMBLY
  // =========================================================================
  const doc = new Document({
    title: report.title || "PerfHub Sign-Off Report",
    description: `Performance test sign-off report for ${report.projectName || "N/A"} — generated by PerfHub`,
    creator: "PerfHub Performance Platform",
    features: {
      updateFields: true,
    },
    styles: {
      default: {
        document: { run: { font: "Calibri", size: 20, color: TEXT } },
        heading1: {
          run: { font: "Calibri", size: 28, bold: true, color: BRAND_DARK },
          paragraph: { spacing: { before: 360, after: 160 } },
        },
        heading2: {
          run: { font: "Calibri", size: 22, bold: true, color: BRAND },
          paragraph: { spacing: { before: 200, after: 100 } },
        },
        heading3: {
          run: { font: "Calibri", size: 20, bold: true, color: TEXT_SEC },
          paragraph: { spacing: { before: 160, after: 80 } },
        },
        listParagraph: {
          run: { font: "Calibri", size: 20, color: TEXT_SEC },
        },
      },
    },
    sections: [{
      properties: {
        page: {
          margin: { top: 720, bottom: 720, left: 720, right: 720 },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            children: [
              new TextRun({ text: "PerfHub", bold: true, size: 15, color: BRAND, font: "Calibri" }),
              new TextRun({ text: `  |  ${report.projectName || "Performance Report"}`, size: 15, color: MUTED, font: "Calibri" }),
              new TextRun({ text: `  |  ${report.title || "Sign-Off Report"}`, size: 15, color: MUTED, font: "Calibri" }),
            ],
            border: { bottom: { style: BorderStyle.SINGLE, size: 1, color: BORDER } },
            spacing: { after: 80 },
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            children: [
              new TextRun({ text: `Report #${report.id}`, size: 13, color: MUTED, font: "Calibri" }),
              new TextRun({ text: `  |  ${report.projectName || ""}  |  Generated: ${genAt}  |  Page `, size: 13, color: MUTED, font: "Calibri" }),
              new TextRun({ children: [PageNumber.CURRENT], size: 13, color: MUTED, font: "Calibri" }),
              new TextRun({ text: " of ", size: 13, color: MUTED, font: "Calibri" }),
              new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 13, color: MUTED, font: "Calibri" }),
            ],
            alignment: AlignmentType.CENTER,
            border: { top: { style: BorderStyle.SINGLE, size: 1, color: BORDER } },
            spacing: { before: 80 },
          })],
        }),
      },
      children: out,
    }],
  });

  const rawBuf = Buffer.from(await Packer.toBuffer(doc));
  return fixGridColWidths(rawBuf);
}

async function fixGridColWidths(docxBuf: Buffer): Promise<Buffer> {
  const zip = await JSZip.loadAsync(docxBuf);
  const docFile = zip.file("word/document.xml");
  if (!docFile) return docxBuf;

  let xml = await docFile.async("string");

  xml = xml.replace(/<w:tbl>[\s\S]*?<\/w:tbl>/g, (tbl) => {
    const firstRow = tbl.match(/<w:tr[ >][\s\S]*?<\/w:tr>/);
    if (!firstRow) return tbl;

    const cellWidths: number[] = [];
    const cellRe = /<w:tcW\s[^/]*w:w="(\d+)"[^/]*\/>/g;
    let m: RegExpExecArray | null;
    while ((m = cellRe.exec(firstRow[0])) !== null) {
      cellWidths.push(parseInt(m[1], 10));
    }
    if (cellWidths.length === 0) return tbl;

    const spanRe = /<w:gridSpan\s[^/]*w:val="(\d+)"[^/]*\/>/g;
    const spans: number[] = [];
    let sm: RegExpExecArray | null;
    while ((sm = spanRe.exec(firstRow[0])) !== null) {
      spans.push(parseInt(sm[1], 10));
    }

    const gridCols: number[] = [];
    for (let i = 0; i < cellWidths.length; i++) {
      const span = spans[i] || 1;
      if (span > 1) {
        const each = Math.round(cellWidths[i] / span);
        for (let s = 0; s < span; s++) gridCols.push(each);
      } else {
        gridCols.push(cellWidths[i]);
      }
    }

    const newGrid = "<w:tblGrid>" +
      gridCols.map(w => `<w:gridCol w:w="${w}"/>`).join("") +
      "</w:tblGrid>";

    return tbl.replace(/<w:tblGrid>[\s\S]*?<\/w:tblGrid>/, newGrid);
  });

  zip.file("word/document.xml", xml);
  const out = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
  return Buffer.from(out);
}
