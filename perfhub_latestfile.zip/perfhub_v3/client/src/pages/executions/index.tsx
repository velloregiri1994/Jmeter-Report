import { useExecutions } from "@/hooks/use-executions";
import { useAuth } from "@/hooks/use-auth";
import { StatusBadge } from "@/components/status-badge";
import { Link, useSearch } from "wouter";
import { format, formatDistanceToNow } from "date-fns";
import { useState, useMemo, useEffect, useCallback } from "react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, Activity, Clock, RotateCw, Search, AlertTriangle, XCircle, Trash2, Shield, ShieldAlert,
  CheckCircle2, Timer, Radio, Globe, Calendar, ChevronLeft, ChevronRight,
  Gauge, BarChart3, Play, Upload, Target, Tag
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { QueryErrorFallback } from "@/components/error-boundary";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { PageHeader } from "@/components/page-header";
import { QuickActionFab } from "@/components/quick-action-fab";
import { EmptyState, emptyStates } from "@/components/empty-state";
import { ExecutionSlaDialog } from "@/components/execution-sla-dialog";
import { ExecutionAutoAbortDialog } from "@/components/execution-auto-abort-dialog";
import { ExecutionWorkloadTargetsDialog } from "@/components/execution-workload-targets-dialog";
import { ImportResultsDialog } from "@/components/import-results-dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

function AnimatedCounter({ value, suffix = "" }: { value: number; suffix?: string }) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    if (value === 0) { setDisplay(0); return; }
    const duration = 600;
    const steps = 20;
    const increment = value / steps;
    let current = 0;
    let step = 0;
    const timer = setInterval(() => {
      step++;
      current = Math.min(Math.round(increment * step), value);
      setDisplay(current);
      if (step >= steps) clearInterval(timer);
    }, duration / steps);
    return () => clearInterval(timer);
  }, [value]);
  return <span>{display}{suffix}</span>;
}

function RelativeTime({ date }: { date: string }) {
  const d = new Date(date);
  const relative = formatDistanceToNow(d, { addSuffix: true });
  const exact = format(d, "MMM d, yyyy HH:mm:ss");
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span className="cursor-default">{relative}</span>
        </TooltipTrigger>
        <TooltipContent side="top">
          <span className="font-mono text-xs">{exact}</span>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function LivePulse() {
  return (
    <span className="relative flex h-2.5 w-2.5">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
    </span>
  );
}

function RunningProgressBar() {
  const [progress, setProgress] = useState(15);
  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(prev => {
        const next = prev + Math.random() * 3;
        return next > 90 ? 15 : next;
      });
    }, 2000);
    return () => clearInterval(timer);
  }, []);
  return (
    <div className="w-full h-1 bg-blue-100 dark:bg-blue-900/30 rounded-full overflow-hidden">
      <div
        className="h-full bg-gradient-to-r from-blue-500 via-cyan-400 to-blue-500 rounded-full transition-all duration-1000 ease-in-out"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}

export default function ExecutionsPage() {
  const searchString = useSearch();
  const urlParams = new URLSearchParams(searchString);
  const statusParam = urlParams.get('status');
  
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [releaseTagFilter, setReleaseTagFilter] = useState<string>("all");
  const [importDialogOpen, setImportDialogOpen] = useState(false);

  const { data: releaseTags = [] } = useQuery({
    queryKey: ["/api/release-tags"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/release-tags");
      return res.json() as Promise<Array<{ id: number; name: string; description?: string; color?: string }>>;
    },
    staleTime: 60000,
  });

  const [activeTab, setActiveTab] = useState<string>(() => {
    if (statusParam === 'failed') return 'failed';
    if (statusParam === 'running') return 'live';
    return 'live';
  });
  
  useEffect(() => {
    if (statusParam === 'failed') {
      setActiveTab('failed');
    } else if (statusParam === 'running') {
      setActiveTab('live');
    }
  }, [statusParam]);

  const { data: allResponse } = useExecutions({ limit: 100 });
  const allExecs = allResponse?.data || [];
  const liveCount = allExecs.filter(e => e.status === 'running' || e.status === 'queued').length;
  const historyCount = allExecs.filter(e => e.status !== 'running' && e.status !== 'queued').length;
  const failedCount = allExecs.filter(e => e.status === 'failed').length;
  const completedCount = allExecs.filter(e => e.status === 'completed').length;
  const totalCount = allExecs.length;
  const successRate = totalCount > 0 ? Math.round((completedCount / Math.max(totalCount - liveCount, 1)) * 100) : 0;

  const avgDuration = useMemo(() => {
    const finished = allExecs.filter(e => e.endTime && e.startTime);
    if (finished.length === 0) return 0;
    const total = finished.reduce((sum, e) => {
      return sum + (new Date(e.endTime!).getTime() - new Date(e.startTime!).getTime());
    }, 0);
    return Math.round(total / finished.length / 1000 / 60);
  }, [allExecs]);

  const statCards = [
    {
      label: "Total Executions",
      value: totalCount,
      suffix: "",
      icon: BarChart3,
      gradient: "from-blue-500/10 to-indigo-500/10",
      borderColor: "border-l-blue-500",
      iconColor: "text-blue-500",
    },
    {
      label: "Active Now",
      value: liveCount,
      suffix: "",
      icon: Radio,
      gradient: "from-emerald-500/10 to-teal-500/10",
      borderColor: "border-l-emerald-500",
      iconColor: "text-emerald-500",
      pulse: liveCount > 0,
    },
    {
      label: "Success Rate",
      value: successRate,
      suffix: "%",
      icon: CheckCircle2,
      gradient: "from-violet-500/10 to-purple-500/10",
      borderColor: "border-l-violet-500",
      iconColor: "text-violet-500",
    },
    {
      label: "Avg Duration",
      value: avgDuration,
      suffix: " min",
      icon: Timer,
      gradient: "from-amber-500/10 to-orange-500/10",
      borderColor: "border-l-amber-500",
      iconColor: "text-amber-500",
    },
  ];

  return (
    <div className="section-gap">
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shimmer {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
        @keyframes glow {
          0%, 100% { box-shadow: 0 0 4px hsl(var(--primary) / 0.2); }
          50% { box-shadow: 0 0 16px hsl(var(--primary) / 0.3); }
        }
        @keyframes borderGlow {
          0%, 100% { border-color: hsl(217 91% 55% / 0.2); }
          50% { border-color: hsl(217 91% 55% / 0.5); }
        }
        .stat-shimmer {
          background: linear-gradient(90deg, transparent 25%, hsl(var(--primary) / 0.04) 50%, transparent 75%);
          background-size: 200% 100%;
          animation: shimmer 3s ease-in-out infinite;
        }
        .tab-content-enter {
          animation: fadeSlideIn 0.25s ease-out;
        }
      `}</style>

      <PageHeader
        title="Executions"
        subtitle="Command center for all test runs"
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2" onClick={() => setImportDialogOpen(true)}>
              <Upload className="w-4 h-4" /> Import CSV
            </Button>
            <Link href="/schedule">
              <Button className="gap-2 btn-primary-glow">
                <Play className="w-4 h-4" /> Schedule New Test
              </Button>
            </Link>
          </div>
        }
      />

      <ImportResultsDialog open={importDialogOpen} onOpenChange={setImportDialogOpen} />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, i) => (
          <div
            key={card.label}
            className={`relative overflow-hidden rounded-xl border border-l-4 ${card.borderColor} bg-card p-4 transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 group`}
            style={{ animation: `fadeSlideIn 0.3s ease-out ${i * 0.08}s both` }}
          >
            <div className={`absolute inset-0 bg-gradient-to-br ${card.gradient} opacity-50 group-hover:opacity-80 transition-opacity`} />
            <div className="relative">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{card.label}</span>
                <div className="flex items-center gap-1.5">
                  {card.pulse && <LivePulse />}
                  <card.icon className={`w-4 h-4 ${card.iconColor} opacity-70`} />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-bold tracking-tight">
                <AnimatedCounter value={card.value} suffix={card.suffix} />
              </div>
            </div>
            <div className="absolute inset-0 stat-shimmer pointer-events-none" />
          </div>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row flex-wrap gap-3">
        <div className="flex items-center gap-3 bg-card/80 backdrop-blur-sm p-3 rounded-xl shadow-sm flex-1 border border-border/50 focus-within:border-primary/40 focus-within:shadow-md transition-all duration-200">
          <Search className="text-primary/50 w-4 h-4 shrink-0" />
          <Input 
            placeholder="Search by test name, script, or execution ID..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="border-none shadow-none focus-visible:ring-0 px-0 h-auto text-sm bg-transparent"
            aria-label="Search executions"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery("")} className="text-muted-foreground hover:text-foreground transition-colors">
              <XCircle className="w-4 h-4" />
            </button>
          )}
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-[180px] bg-card/80 backdrop-blur-sm" aria-label="Filter by status">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="running">Running</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
            <SelectItem value="queued">Queued</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
            <SelectItem value="aborted">Aborted</SelectItem>
          </SelectContent>
        </Select>
        <Select value={releaseTagFilter} onValueChange={setReleaseTagFilter}>
          <SelectTrigger className="w-full sm:w-[180px] bg-card/80 backdrop-blur-sm" aria-label="Filter by release tag">
            <div className="flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-muted-foreground" />
              <SelectValue placeholder="Filter by release" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Releases</SelectItem>
            {releaseTags.map((tag) => (
              <SelectItem key={tag.id} value={tag.name}>{tag.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full max-w-lg grid-cols-3 bg-muted/50 backdrop-blur-sm">
          <TabsTrigger value="live" className="gap-1.5 data-[state=active]:shadow-md transition-all">
            {liveCount > 0 && <LivePulse />}
            Live
            {liveCount > 0 && (
              <span className="ml-1 inline-flex items-center justify-center rounded-full bg-emerald-500/15 text-emerald-600 text-[10px] font-bold min-w-[18px] h-[18px] px-1">
                {liveCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-1.5 data-[state=active]:shadow-md transition-all">
            History
            {historyCount > 0 && (
              <span className="ml-1 inline-flex items-center justify-center rounded-full bg-muted-foreground/15 text-muted-foreground text-[10px] font-semibold min-w-[18px] h-[18px] px-1">
                {historyCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="failed" className="text-rose-600 data-[state=active]:text-rose-600 gap-1.5 data-[state=active]:shadow-md transition-all">
            <XCircle className="w-3.5 h-3.5" /> Failed
            {failedCount > 0 && (
              <span className="ml-1 inline-flex items-center justify-center rounded-full bg-rose-500/15 text-rose-600 text-[10px] font-bold min-w-[18px] h-[18px] px-1">
                {failedCount}
              </span>
            )}
          </TabsTrigger>
        </TabsList>
        <TabsContent value="live" className="mt-6 tab-content-enter">
          <ExecutionsTable status="running" searchQuery={searchQuery} statusFilter={statusFilter} releaseTagFilter={releaseTagFilter} />
        </TabsContent>
        <TabsContent value="history" className="mt-6 tab-content-enter">
          <ExecutionsTable status="history" searchQuery={searchQuery} statusFilter={statusFilter} releaseTagFilter={releaseTagFilter} />
        </TabsContent>
        <TabsContent value="failed" className="mt-6 tab-content-enter">
          <ExecutionsTable status="failed" searchQuery={searchQuery} statusFilter={statusFilter} releaseTagFilter={releaseTagFilter} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ExecutionsTable({ status, searchQuery, statusFilter, releaseTagFilter }: { status?: 'running' | 'history' | 'failed'; searchQuery?: string; statusFilter?: string; releaseTagFilter?: string }) {
  const { canWrite } = useAuth();
  const [currentPage, setCurrentPage] = useState(1);
  const [slaDialogExec, setSlaDialogExec] = useState<{ id: number; name: string } | null>(null);
  const [autoAbortDialogExec, setAutoAbortDialogExec] = useState<{ id: number; name: string } | null>(null);
  const [workloadTargetsExec, setWorkloadTargetsExec] = useState<{ id: number; name: string } | null>(null);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/executions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (q) => String(q.queryKey[0]).includes("/api/executions") });
      queryClient.invalidateQueries({ predicate: (q) => String(q.queryKey[0]).includes("/api/test-tracker") });
      toast({ title: "Execution deleted" });
    },
    onError: (err: Error) => {
      toast({ title: "Delete failed", description: err.message, variant: "destructive" });
    },
  });

  const { data: response, isLoading, isError, error, refetch } = useExecutions(
    status === 'running' 
      ? { limit: 100 } 
      : status === 'failed'
      ? { status: 'failed', limit: 50, page: currentPage }
      : { limit: 50, page: currentPage }
  );
  
  const executions = response?.data || [];
  const pagination = response?.pagination;

  const handleRefresh = useCallback(() => {
    refetch();
    setLastRefresh(new Date());
  }, [refetch]);

  useEffect(() => {
    if (status !== 'running') return;
    const interval = setInterval(() => {
      refetch();
      setLastRefresh(new Date());
    }, 5000);
    return () => clearInterval(interval);
  }, [status, refetch]);

  const filteredExecutions = useMemo(() => {
    if (!executions || !Array.isArray(executions)) return [];
    
    return executions.filter(exec => {
      if (!exec) return false;

      if (status === 'running') {
        if (exec.status !== 'running' && exec.status !== 'queued') return false;
      } else if (status === 'history') {
        if (exec.status === 'running' || exec.status === 'queued') return false;
      } else if (status === 'failed') {
        if (exec.status !== 'failed') return false;
      }

      const executionId = (exec as any).executionId || '';
      const isRemote = !exec.scheduleId;
      const testName = (exec as any).testName || '';
      const scheduleName = exec.schedule?.name || testName || (isRemote ? 'Remote Execution' : 'Deleted schedule');
      const scriptName = exec.schedule?.script?.name || (isRemote ? '-' : 'Deleted script');

      const matchesSearch = !searchQuery || 
        scheduleName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        scriptName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        testName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        executionId.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesStatus = !statusFilter || statusFilter === 'all' || exec.status === statusFilter;

      const matchesReleaseTag = !releaseTagFilter || releaseTagFilter === 'all' || (exec as any).releaseTag === releaseTagFilter;
      
      return matchesSearch && matchesStatus && matchesReleaseTag;
    });
  }, [executions, searchQuery, statusFilter, releaseTagFilter]);

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="rounded-xl border bg-card p-4" style={{ animationDelay: `${i * 0.1}s` }}>
            <div className="flex items-center gap-4">
              <Skeleton className="w-10 h-10 rounded-lg" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-48" />
                <Skeleton className="h-3 w-32" />
              </div>
              <Skeleton className="h-6 w-20 rounded-full" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (isError) return <QueryErrorFallback error={error} onRetry={refetch} title="Failed to load executions" />;

  if (filteredExecutions?.length === 0) {
    if (!searchQuery && statusFilter === 'all' && !status) {
      return <EmptyState {...emptyStates.executions} />;
    }

    return (
      <div className="flex flex-col items-center justify-center p-16 border border-dashed rounded-2xl bg-gradient-to-b from-muted/10 to-muted/30">
        {status === 'failed' ? (
          <>
            <div className="mb-5 rounded-full p-4 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 ring-1 ring-emerald-500/20">
              <CheckCircle2 className="h-10 w-10 text-emerald-500" />
            </div>
            <h3 className="text-lg font-semibold">All Systems Stable</h3>
            <p className="text-muted-foreground text-sm mt-1.5 text-center max-w-xs">
              No failed tests detected. Your performance infrastructure is running cleanly.
            </p>
          </>
        ) : status === 'running' ? (
          <>
            <div className="mb-5 rounded-full p-4 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 ring-1 ring-blue-500/20">
              <Gauge className="h-10 w-10 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold">No Active Tests</h3>
            <p className="text-muted-foreground text-sm mt-1.5 text-center max-w-xs">
              The test infrastructure is idle. Schedule a new test to begin monitoring.
            </p>
            <Link href="/schedule">
              <Button variant="outline" className="mt-4 gap-2">
                <Play className="w-4 h-4" /> Schedule Test
              </Button>
            </Link>
          </>
        ) : (
          <>
            <div className="mb-5 rounded-full p-4 bg-gradient-to-br from-primary/10 to-blue-500/10 ring-1 ring-primary/20">
              <Activity className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold">No Executions Found</h3>
            <p className="text-muted-foreground text-sm mt-1.5 text-center max-w-xs">
              {searchQuery || statusFilter !== 'all' ? "Try adjusting your search or filters." : "No execution history available."}
            </p>
          </>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-0">
      {status === 'running' && (
        <div className="flex items-center justify-between px-4 py-2.5 bg-gradient-to-r from-blue-500/5 via-cyan-500/5 to-blue-500/5 border border-blue-500/10 rounded-t-xl mb-0">
          <div className="flex items-center gap-2.5 text-sm">
            <LivePulse />
            <span className="font-medium text-blue-700 dark:text-blue-300">
              {filteredExecutions.length} test{filteredExecutions.length !== 1 ? 's' : ''} running
            </span>
            <span className="text-muted-foreground text-xs">
              &middot; refreshed {formatDistanceToNow(lastRefresh, { addSuffix: true })}
            </span>
          </div>
          <Button variant="ghost" size="sm" onClick={handleRefresh} className="text-xs h-7 gap-1.5 text-blue-600 hover:text-blue-700 hover:bg-blue-500/10">
            <RotateCw className="w-3 h-3" /> Refresh
          </Button>
        </div>
      )}
      
      <div className={`table-container ${status === 'running' ? 'rounded-t-none border-t-0' : ''}`}>
        <Table>
          <TableHeader className="bg-muted/30">
            <TableRow>
              <TableHead className="w-[100px]">ID</TableHead>
              <TableHead>Test Name</TableHead>
              <TableHead className="hidden md:table-cell">Script</TableHead>
              <TableHead>Started</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden sm:table-cell">Duration</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredExecutions?.map((exec, index) => {
              const isRemote = !exec.scheduleId;
              const scheduleName = exec.schedule?.name || (exec as any).testName || (isRemote ? 'Remote Execution' : 'Deleted schedule');
              const scriptName = exec.schedule?.script?.name || (isRemote ? '-' : 'Deleted script');
              const hasSlaViolations = (exec as any).slaViolations && Object.keys((exec as any).slaViolations).length > 0;
              const isRunning = exec.status === 'running';
              const isQueued = exec.status === 'queued';
              const duration = exec.endTime && exec.startTime
                ? Math.round((new Date(exec.endTime).getTime() - new Date(exec.startTime).getTime()) / 1000 / 60)
                : null;

              return (
                <TableRow 
                  key={exec.id} 
                  className={`group transition-all duration-200 ${isRunning ? 'bg-blue-500/[0.02] hover:bg-blue-500/[0.06]' : 'hover:bg-primary/[0.04]'}`}
                  style={{ animation: `fadeSlideIn 0.25s ease-out ${index * 0.03}s both` }}
                >
                  <TableCell>
                    <span className="font-mono text-[11px] text-muted-foreground bg-muted/50 px-1.5 py-0.5 rounded">
                      {(exec as any).executionId ? String((exec as any).executionId).substring(0, 8) : `#${exec.id}`}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Link href={`/executions/${exec.id}`} className="font-medium hover:text-primary hover:underline underline-offset-2 transition-colors">
                          {scheduleName}
                        </Link>
                        {isRemote && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-medium text-cyan-700 dark:text-cyan-400 bg-cyan-500/10 px-1.5 py-0.5 rounded">
                            <Globe className="w-2.5 h-2.5" /> Remote
                          </span>
                        )}
                        {!isRemote && exec.scheduleId && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-medium text-violet-700 dark:text-violet-400 bg-violet-500/10 px-1.5 py-0.5 rounded">
                            <Calendar className="w-2.5 h-2.5" /> Scheduled
                          </span>
                        )}
                        {exec.status === 'aborted' && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-orange-700 dark:text-orange-400 bg-orange-500/10 border border-orange-500/20 px-1.5 py-0.5 rounded-full">
                            <XCircle className="w-2.5 h-2.5" /> Auto-Aborted
                          </span>
                        )}
                        {hasSlaViolations && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-700 dark:text-amber-400 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded-full">
                            <AlertTriangle className="w-2.5 h-2.5" /> SLA Breach
                          </span>
                        )}
                        {(exec as any).releaseTag && (
                          <Badge variant="outline" className="text-[10px] font-medium gap-1 px-1.5 py-0 h-[18px] border-indigo-500/30 text-indigo-700 dark:text-indigo-400 bg-indigo-500/5">
                            <Tag className="w-2.5 h-2.5" /> {(exec as any).releaseTag}
                          </Badge>
                        )}
                      </div>
                      {isRunning && <RunningProgressBar />}
                    </div>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    <span className="text-sm text-muted-foreground">{scriptName}</span>
                  </TableCell>
                  <TableCell>
                    {exec.startTime ? (
                      <span className="text-sm">
                        <RelativeTime date={exec.startTime} />
                      </span>
                    ) : (
                      <span className="text-muted-foreground text-sm">-</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={exec.status} />
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">
                    {isRunning ? (
                      <span className="inline-flex items-center gap-1.5 text-blue-600 dark:text-blue-400 text-xs font-medium">
                        <Clock className="w-3 h-3 animate-pulse" />
                        In progress
                      </span>
                    ) : isQueued ? (
                      <span className="inline-flex items-center gap-1.5 text-violet-600 dark:text-violet-400 text-xs font-medium">
                        <Clock className="w-3 h-3" />
                        Waiting
                      </span>
                    ) : duration !== null ? (
                      <span className="font-mono text-xs text-muted-foreground">{duration} min</span>
                    ) : (
                      <span className="text-muted-foreground text-xs">-</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {(isRunning || isQueued) && (
                        <>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-8 w-8 border-blue-200 dark:border-blue-800 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all"
                                  onClick={() => setSlaDialogExec({ id: exec.id, name: scheduleName })}
                                >
                                  <Shield className="w-3.5 h-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Manage SLA Rules</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-8 w-8 border-rose-200 dark:border-rose-800 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-all"
                                  onClick={() => setAutoAbortDialogExec({ id: exec.id, name: scheduleName })}
                                >
                                  <ShieldAlert className="w-3.5 h-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Manage Auto-Abort Rules</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </>
                      )}
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8 border-purple-200 dark:border-purple-800 text-purple-600 hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-all"
                              onClick={() => setWorkloadTargetsExec({ id: exec.id, name: scheduleName })}
                            >
                              <Target className="w-3.5 h-3.5" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Set Workload Targets</TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="sm" asChild className="h-8 text-xs gap-1 text-primary border-primary/20 hover:bg-primary/5 hover:border-primary/40 transition-all">
                              <Link href={`/executions/${exec.id}`}>
                                View <ArrowRight className="w-3 h-3" />
                              </Link>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>View execution details</TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      {canWrite && !isRunning && !isQueued && (
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground/50 hover:text-destructive opacity-0 group-hover:opacity-100 transition-all" aria-label="Delete execution">
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Execution</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently delete this execution and all associated data. This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteMutation.mutate(exec.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
        
        {pagination && pagination.totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t bg-muted/10">
            <div className="text-xs text-muted-foreground">
              {pagination.offset + 1}–{Math.min(pagination.offset + executions.length, pagination.total)} of {pagination.total}
            </div>
            <div className="flex items-center gap-1.5">
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage <= 1}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <span className="text-xs px-3 font-medium">
                {pagination.page} / {pagination.totalPages}
              </span>
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8"
                onClick={() => setCurrentPage(p => p + 1)}
                disabled={!pagination.hasMore}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
      </div>

      <QuickActionFab href="/schedule" label="Schedule New Test" />

      {slaDialogExec && (
        <ExecutionSlaDialog
          executionId={slaDialogExec.id}
          executionName={slaDialogExec.name}
          open={!!slaDialogExec}
          onOpenChange={(open) => { if (!open) setSlaDialogExec(null); }}
        />
      )}

      {autoAbortDialogExec && (
        <ExecutionAutoAbortDialog
          executionId={autoAbortDialogExec.id}
          executionName={autoAbortDialogExec.name}
          open={!!autoAbortDialogExec}
          onOpenChange={(open) => { if (!open) setAutoAbortDialogExec(null); }}
        />
      )}

      {workloadTargetsExec && (
        <ExecutionWorkloadTargetsDialog
          executionId={workloadTargetsExec.id}
          executionName={workloadTargetsExec.name}
          open={!!workloadTargetsExec}
          onOpenChange={(open) => { if (!open) setWorkloadTargetsExec(null); }}
        />
      )}
    </div>
  );
}
